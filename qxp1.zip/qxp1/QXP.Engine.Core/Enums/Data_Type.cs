using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type de donn�e autoris� dans un Inparam
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:08:50</date>    
	public enum Data_Type
	{
        /// <summary>
        /// Inconnue
        /// </summary>
		Unspecified     = 0,
		/// <summary>
		/// String
		/// </summary>
        Text            = 1,
        /// <summary>
        /// Entier
        /// </summary>
		Int             = 2,
		/// <summary>
		/// D�cimale
		/// </summary>
        Decimal         = 3,
        /// <summary>
        /// Date
        /// </summary>
		Date            = 4,
        /// <summary>
        /// Date et heure
        /// </summary>
		DateTime        = 5,
        /// <summary>
        /// Money
        /// </summary>
		Currency        = 6,
        /// <summary>
        /// Pourcentage
        /// </summary>
		Pourcentage     = 7,
        /// <summary>
        /// Personalis�e
        /// </summary>
		/// <remarks>
		/// TODO ajouter une info de custom pattern sur l'object Task
		/// </remarks>
		Custom          = 99, 
	}
}
