using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type de template TBox
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/03/2010 11:08:50</date>    
	public enum TBox_Type
	{
		/// <summary>
		/// Type de bloc inconnu
		/// </summary>
		CT_UNKNOWN,
		/// <summary>
		/// Bloc Presentation (exemple filet)
		/// </summary>
		CT_NONE,
		/// <summary>
		/// Bloc de type Text
		/// </summary>
		CT_TEXT,
		/// <summary>
		/// Bloc de type image
		/// </summary>
		CT_PICT
	}
}
