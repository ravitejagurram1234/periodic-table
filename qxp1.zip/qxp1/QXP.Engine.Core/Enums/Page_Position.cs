using System;

/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini les positions possible d'une page par rapport � la reliure
	/// </summary>
	/// <author>doufarm</author>
	/// <date>28/06/2010 14:41:28</date>    
	public class Page_Position
	{
		//La page est positionn� � droite de la reliure (valeur par d�faut des nouvelles pages)
		public const string RIGHTOFSPINE	= "RIGHTOFSPINE";
		//La page est positionn� � gauche de la reliure
		public const string LEFTOFSPINE		= "LEFTOFSPINE";
	}
}
