using System;

/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Ensembles des types rapport des runs
	/// </summary>
	/// <author>doufarm</author>
	/// <date>27/05/2010 17:00:38</date>    
	public enum Type_Rapport
	{
		Unknown					= 0,
		Rapport_Annuel			= 1,
		Plaquette				= 2,
		Propectus				= 3,
		Rapport_Compartiment	= 4,
        DICI                    = 5,
	}
} 
