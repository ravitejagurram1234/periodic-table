using System;

/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type de stockage des donn�es du run.
	/// </summary>
	/// <author>doufarm</author>
	/// <date>20/09/2010 11:00:50</date> 
	[Flags]
    public enum Store_Data_Type
    {
        /// <summary>
        /// Aucun stockage
        /// </summary>
		NONE		= 0x00,
        /// <summary>
        /// mise � jour d'une valeur
        /// </summary>
		SQL			= 0x01,
        /// <summary>
        /// creation de quelque chose
        /// </summary>
		DOCUMENT	= 0x02,

		/// <summary>
		/// Toutes les formes de stockages possibles
		/// </summary>
		ALL			= 0xFF,
    }
}
