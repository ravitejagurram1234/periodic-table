using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type de tache exception possible
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 13:25:41</date>    
    public enum Task_Exception_Type
    {
        NONE,
        /// <summary>
        /// Exception sur une ligne quark
        /// </summary>
		LINE,
		/// <summary>
		/// Exception sur une Table quark
		/// </summary>
        TABLE,
		/// <summary>
		/// Exception sur un group
		/// </summary>
		/// <remarks>
		/// � impl�menter plus tard
		/// </remarks>
		GROUP,
    }
}
