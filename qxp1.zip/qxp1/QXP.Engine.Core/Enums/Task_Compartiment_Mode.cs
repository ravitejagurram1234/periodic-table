using System;

/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini les modes d'�x�cution des taches compartiment
	/// </summary>
	/// <author>doufarm</author>
	/// <date>27/05/2010 10:26:26</date>    
	[Flags]
	public enum Task_Compartiment_Mode
	{
		/// <summary>
		/// Inconnu
		/// </summary>
		Unknown						= 0x00,
		/// <summary>
		/// Il faut g�n�rer les runs de la tache
		/// </summary>
		Generate					= 0x01,
		/// <summary>
		/// Il faut incorporer les donn�es des anciens runs de la tache
		/// </summary>
		Incorporate					= 0x02,
		/// <summary>
		/// Il faut g�n�rer et Incorporer les runs de la tache
		/// </summary>
		Generate_And_Incorporate	= 0x03,
	}
}
