using System;

/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Ensembles operations r�alisable sur un bloc
	/// </summary>
	/// <author>doufarm</author>
	/// <date>28/05/2010 17:36:25</date>    
	public class Bloc_Operation
	{
		/// <summary>
		/// Creation d'un �l�ment
		/// </summary>
		public const string CREATE = "CREATE";
		/// <summary>
		/// Suppression d'un �l�ment
		/// </summary>
		public const string DELETE = "DELETE";
	}
}
