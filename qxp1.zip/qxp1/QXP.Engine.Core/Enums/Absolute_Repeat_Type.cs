using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type r�p�tition des blocs absolus
	/// </summary>
	/// <author>doufarm</author>
	/// <date>27/04/2010 09:35:50</date>    
	[Flags]
    public enum Absolute_Repeat_Type
    {
        /// <summary>
        /// Par default le bloc absolu apparait que sur la premiere page
        /// </summary>
		Default		= 0x00,
        /// <summary>
        /// Le bloc absolu apparait sur la premiere page
        /// </summary>
		First_Page	= 0x01,
        /// <summary>
        /// Le bloc absolu apparait sur les autres pages (mais pas la premi�re)
        /// </summary>
		Other_Page	= 0x02,
        /// <summary>
        /// Absolute Bloc appears in the last page
        /// </summary>
        Last_Page = 0x04,
		/// <summary>
		/// Le bloc absolu apparait sur toutes les pages
		/// </summary>
		All			= 0xFF
    }
}
