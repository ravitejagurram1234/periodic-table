using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type d'erreur pouvant survenir lors de l'�x�cution d'un run
	/// Ce sont des types d'erreur control�es, cad qu'elle ne g�n�re pas D'exception contrairement a Run_Exception qui survient lors d'une Erreur impr�vue
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:08:50</date>    
	public enum Error_Type
    {
        /// <summary>
        /// Non sp�cifi�e
        /// </summary>
		Unspecified     = 1,
        /// <summary>
        /// Critique (interrompt la tache en cours par exemple)
        /// </summary>
		Critique        = 2,
		/// <summary>
		/// Bloquante (interrompt l'ex�cution du run)
		/// </summary>
        Bloquante       = 3,
    }
}
