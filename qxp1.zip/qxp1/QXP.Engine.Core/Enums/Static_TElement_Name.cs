using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Nom des templates element static utilis�s par certaines taches
	/// </summary>
	/// <author>doufarm</author>
	/// <date>08/04/2010 11:06:02</date>    
	public enum Static_TElement_Name
	{
		/// <summary>
		/// Premier bloc pdf d'une liste (bloc en mise � jour uniquement)
		/// </summary>
		PDF_1, 
		/// <summary>
		/// Les blocs suivant pour le pdf (peut �tre en cr�ation ou modification en fonction de la propri�t� CreateBloc)
		/// </summary>
		PDF_N, 
		/// <summary>
		/// Les images
		/// </summary>
		IMG,
		/// <summary>
		/// Les document de type RTF / DOC ou XTG (fragment de document quark)
		/// </summary>
		RTF_DOC_XTG,
		/// <summary>
		/// Permet de d�placer un bloc d'une page � une autre
		/// </summary>
		MOVE_BLOC,
		/// <summary>
		/// Permet de d�placer un bloc d'une page � une autre et de mettre � jour sa valeur
		/// </summary>
		MOVE_BLOC_VALUE,
		/// <summary>
		/// Repr�sente un bloc vide sans aucune propri�t�
		/// </summary>
		EMPTY_BLOC,
		/// <summary>
		/// Repr�sente une table vide sans aucune propri�t�
		/// </summary>
		EMPTY_TABLE
	}
}
