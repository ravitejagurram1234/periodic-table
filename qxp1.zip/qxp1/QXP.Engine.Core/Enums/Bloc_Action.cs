using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type d'action r�alisable sur un bloc Quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:08:50</date>    
    public enum Bloc_Action
    {
        /// <summary>
        /// Aucune action r�alis� par ce bloc
        /// </summary>
		NONE,
        /// <summary>
        /// mise � jour d'une valeur
        /// </summary>
		UPDATE,
        /// <summary>
        /// creation de quelque chose
        /// </summary>
		CREATE,
        /// <summary>
        /// suppression de quelque chose
        /// </summary>
		REMOVE, 
        /// <summary>
        /// deplacement de quelque chose
        /// </summary>
		MOVE,
    }
}
