using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Ensembles des status d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:08:50</date>    
    public enum Run_Status
    {
        /// <summary>
        /// � g�n�rer
        /// </summary>
		ToGenerate  = 1,
		/// <summary>
		/// G�n�r�
		/// </summary>
        Generated   = 2,
		/// <summary>
		/// En erreur
		/// </summary>
        Error       = 3,
		/// <summary>
		/// En cours de g�n�ration
		/// </summary>
        Running     = 4,
    }
}
