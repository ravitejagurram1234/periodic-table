using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type de tache possible
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:08:50</date>    
    public enum Task_Type
    {
        /// <summary>
        /// Tache syst�me
        /// </summary>
		SYSTEM	= 0,
        /// <summary>
        /// Tache SQL (donn�e chiffr�e ajout� dans des bloc existant)
        /// </summary>
		SQL		= 1,
		/// <summary>
		/// Tache Document (ajout d'un document ou fragment de document existant)
		/// </summary>
        DOC_EOS = 2,
		/// <summary>
		/// Tache Document QXP g�n�r� pr�cedemment
		/// </summary>
        DOC_QXP = 3,			
		/// <summary>
		/// Tache SQL (permettant la cr�ation/remplissage de nouveau bloc ou groupe de blocs)
		/// </summary>
		SQL_DYNAMIQUE = 4,		
		/// <summary>
		/// Tache Compartiment (permettant la g�n�ration/incorporation de run fils)
		/// </summary>
		COMPARTIMENTS = 5,		
    }
}
