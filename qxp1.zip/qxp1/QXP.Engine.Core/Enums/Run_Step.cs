using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// repr�sente l'�tape en cours d'�x�cution dans le run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:39:21</date>    
	public enum Run_Step
    {
        Unknown,
        /// <summary>
        /// D�but de run
        /// </summary>
		Start,
		/// <summary>
		/// Chargement de run
		/// </summary>
        Load,
		/// <summary>
		/// Pr�paration des taches d'un run
		/// </summary>
        Prepare,
		/// <summary>
		/// Ex�cution des taches d'un run
		/// </summary>
        Process,
		/// <summary>
		/// Appel � quark server pour la modification du document
		/// </summary>
        Process_Steps,
		/// <summary>
		/// Appel � quark server pour le rendu des modifications g�n�r�es par le run
		/// </summary>
        Render,
        /// <summary>
        /// V�rification du document quark
        /// </summary>
		Check,
		/// <summary>
		/// Fin du run
		/// </summary>
        End
    }
}
