using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Niveau de la compression d'image
	/// Utilis�e par exemple pour la g�n�ration des pdfs
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:08:50</date>    
    public enum Image_Compression
    {
        /// <summary>
        /// Niveau de Compression faible 75
        /// </summary>
		LOW,
        /// <summary>
        /// Niveau de Compression faible 150
        /// </summary>
        MEDIUM,
        /// <summary>
        /// Niveau de Compression faible 300
        /// </summary>
        HIGH,
    }
}
