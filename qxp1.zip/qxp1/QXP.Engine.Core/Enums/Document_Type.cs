using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type de document
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:54:21</date>    
    public enum Document_Type
    {
        /// <summary>
        /// Inconnu
        /// </summary>
		Unknown,
		/// <summary>
		/// gabarit quark (QXP)
		/// </summary>
        Gabarit,
		/// <summary>
		/// Image
		/// </summary>
        IMG,
		/// <summary>
		/// Fragment de document quark
		/// </summary>
        XTG,
		/// <summary>
		/// Document QXP
		/// </summary>
        QXP,
		/// <summary>
		/// Document word
		/// </summary>
        DOC,
		/// <summary>
		/// Document RTF
		/// </summary>
        RTF,
        /// <summary>
        /// Document PDF
        /// </summary>
		PDF,
    }
}
