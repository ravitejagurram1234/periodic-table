using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Type d'action effectu�e par une tache
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:08:50</date>    
    public enum Task_Action_Type
    {
        NONE,
        /// <summary>
        /// Mise � jour de bloc
        /// </summary>
		UPDATE,
		/// <summary>
		/// Creation de bloc
		/// </summary>
        CREATE,
		/// <summary>
		/// Suppression de bloc
		/// </summary>
        REMOVE,
    }
}
