using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Sous type de tache possible
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:08:50</date>    
    public enum Sub_Task_Type
    {
        /// <summary>
        /// Inconnue
        /// </summary>
		Unknown,
		/// <summary>
		/// Valeur de bloc
		/// </summary>
        Value,			
        /// <summary>
        /// Fichier Image
        /// </summary>
		File_IMG,       
        /// <summary>
        /// Fichier XTG fragment d'un docuement QXP
        /// </summary>
		File_XTG,       
        /// <summary>
        /// Fichier word
        /// </summary>
		File_DOC,       
        /// <summary>
        /// Fichier RTF
        /// </summary>
		File_RTF,        
        /// <summary>
        /// Fichier PDF � couper 
        /// </summary>
		File_PDF,       
        /// <summary>
        /// Fichier en upload
        /// </summary>
		File_Upload,
        /// <summary>
        /// Fichier � supprimer
        /// </summary>
		File_Delete,
        /// <summary>
        /// Document QXP sp�cifi� par dernier suivi valider sur document en cours
        /// </summary>
		File_QXP_Previous,  
		/// <summary>
		/// Document QXP sp�cifi� par id_sous_cat/id_langue et (codeport ou societe)
		/// </summary>
        File_QXP_Data,
		/// <summary>
		/// Tache SQL
		/// </summary>
        SQL,				
        /// <summary>
        /// Boite quark
        /// </summary>
		Box,
        /// <summary>
        /// Table quark
        /// </summary>
		Table,
		/// <summary>
		/// Page quark
		/// </summary>
        Page,
    }
}
