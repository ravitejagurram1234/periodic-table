using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// contient les param�tres li�s � la requete qui va �tre effectu�e sur QXPS_Caller
	/// </summary>
	/// <author>doufarm</author>
	/// <date>25/03/2010 17:15:29</date>    
	public class QXPS_Caller_Request
	{
		#region Membres
		Run_Base			_run;

        bool				_renderQXP			= true;
        bool				_renderPDF			= true;
        bool				_renderJPG			= false;
        Image_Compression	_imageCompression	= Image_Compression.HIGH;   // Option de compression
        string				_valueCompression;				// Valeur de sous-�chantillonnage avec perte
        string				_modeCompression	= "true";   // true = colorimagecompression, grayscalecomression et monochromecompression = medium

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de QXPS_Caller_Request
		/// </summary>
		/// <param name="run">le run qui � cr�� cette requete</param>
		public QXPS_Caller_Request(Run_Base run)
		{
			_run = run;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet d'obtenir la liste des �tapes finale � ex�cuter sur quark server ou quark manager
		/// </summary>
        public QXPFrk.BaseList<Run_Task_Step> Get_Steps()
        {
            return _run.Run_Task.Get_Steps();
        }
		#endregion M�thodes

		#region Propri�t�s
                
        /// <summary>
        /// Faut-il effectuer un rendu du document finale en QXP
        /// </summary>
		public bool RenderQXP
        {
            get { return _renderQXP; }
            set { _renderQXP = value; }
        }
        
        /// <summary>
        /// Faut-il effectuer un rendu du document finale en PDF
        /// </summary>
		public bool RenderPDF
        {
            get { return _renderPDF; }
            set { _renderPDF = value; }
        }
        
        /// <summary>
        /// Faut-il effectuer un rendu du document finale en JPG
        /// </summary>
		public bool RenderJPG
        {
            get { return _renderJPG; }
            set { _renderJPG = value; }
        }
        
        /// <summary>
        /// Valeur de la compression des images
        /// </summary>
		public Image_Compression ImageCompression
        {
            get { return _imageCompression; }
            set { _imageCompression = value; }
        }
        
        /// <summary>
        /// Valeur de la compression 
        /// </summary>
		public string Value_Compression
        {
            get
            {
                switch (_imageCompression)
                {
                    case Image_Compression.LOW:
                        _valueCompression = "72";
                        break;
                    case Image_Compression.MEDIUM:
                        _valueCompression = "150";
                        break;
                    case Image_Compression.HIGH:
                        _valueCompression = "300";
                        break;
                }
                return _valueCompression;
            }
        }
        
        /// <summary>
        /// taux de compression (en dpi def = 300)
        /// </summary>
		public string Compression
        {
            get { return _modeCompression; }
            set { _modeCompression = value; }
        }

		/// <summary>
		/// Repr�sente le Run � l'origine de la l'appel de modification
		/// </summary>
		public Run_Base Run 
		{
			get { return _run; }
		}
		#endregion Propri�t�s
	}
}
