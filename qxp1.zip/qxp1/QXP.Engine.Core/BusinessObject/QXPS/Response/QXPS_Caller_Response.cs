using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// contient les r�ponses effectu�es par QXPS_Caller
	/// </summary>
	/// <author>doufarm</author>
	/// <date>25/03/2010 17:17:49</date>    
	public class QXPS_Caller_Response
	{
		#region Membres
        byte[] _jpg_data;
        byte[] _pdf_data;
        byte[] _qxp_data;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de QXPS_Caller_Response
		/// </summary>
		public QXPS_Caller_Response()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
        /// <summary>
        /// Donn�es du flux binaire du JPG (r�sultant de l'appel � quark server ou quark manager)
        /// </summary>
		public byte[] JPG_Data
        {
            get { return _jpg_data; }
            set { _jpg_data = value; }
        }
        
        /// <summary>
        /// Donn�es du flux binaire du PDF (r�sultant de l'appel � quark server ou quark manager)
        /// </summary>
		public byte[] PDF_Data
        {
            get { return _pdf_data; }
            set { _pdf_data = value; }
        }

        /// <summary>
        /// Donn�es du flux binaire du QXP (r�sultant de l'appel � quark server ou quark manager)
        /// </summary>
		public byte[] QXP_Data
        {
            get { return _qxp_data; }
            set { _qxp_data = value; }
        }
		#endregion Propri�t�s
	}
}
