using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;

using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;


/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet de manipuler QuarkXpress server
	/// </summary>
	/// <author>doufarm</author>
	/// <date>12/10/2010 10:32:47</date>    
	public class QXPS_Manager
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de QXPS_Manager
		/// </summary>
		public QXPS_Manager()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Demande l'arr�t de QuarkXpress server
		/// </summary>
		public static void ShutDownXpressServer()
		{
			QXPInteropQuarkServer.QXPS_Helper.ShutDownXpressServer();
		}

		/// <summary>
		/// Permet d'obtenir le process id du master sub renderer de quarkxpress server
		/// </summary>
		/// <returns></returns>
		public static int GetMasterProcessId()
		{
			string __masterpid = string.Empty;
			try
			{
				string __xml = QXPInteropQuarkServer.QXPS_Helper.Get_XpressServer_ProcessInfo();
				__masterpid = QXP_XML.Create_From_XML(__xml).GetMasterProcessID();
			}
			//on ignore les erreurs pas de log QuarkXpress server n'est probablement pas actif
			catch
			{

			}
			//quelque soit le resultat on retourne quelque chose
			//qui peut �tre int.minValue si quarkxpress server n'existe pas
            return QXPFrk.ConversionInvariante.ToInt(__masterpid);
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
