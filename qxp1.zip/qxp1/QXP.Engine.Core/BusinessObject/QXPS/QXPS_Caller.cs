using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPInterop			= QXP.Interop;
using QXPSMSDK			= com.quark.qxpsm;
using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente la class permettant d'appel� quark server avec toutes les modifications � effectuer
	/// </summary>
	/// <author>doufarm</author>
	/// <date>25/03/2010 17:08:11</date>    
	public class QXPS_Caller : QXPInteropQuarkServer.QXPS_Caller_Base
	{
		#region Membres
        QXPS_Caller_Request     _request;
        QXPS_Caller_Response    _response	 = new QXPS_Caller_Response();

        int                     _execution_count                   = 1;

		#endregion Membres

		#region Constantes
        const string NewGabaritNameWithIDPattern		= "{0}_{1}_{2}";
        const string NewGabaritNamePattern				= "{0}_{1}";
        const string NewGabaritNameExtWithIDPattern		= "{0}_{1}_{2}.{3}";
        const string NewGabaritNameExtPattern			= "{0}_{1}.{2}";

		const string ModifyNamePattern					= "Modify_{0:HHmmssff}.xml";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de QXP_Caller
		/// </summary>
		/// <param name="call_Info">les information permettant de contacter quark server ou quark manager</param>
		/// <param name="request">les requetes � ex�cuter sur quark server ou quark manager </param>
		public QXPS_Caller(QXPInteropQuarkServer.QXPS_Call_Info call_Info, QXPS_Caller_Request request): base(call_Info)
		{
			_request = request;
		}

		#endregion Constructeur

		#region M�thodes
		
		/// <summary>
		/// Lancement de toutes les �tapes de modification
		/// </summary>
		public void Process()
		{
			int		__lastBox		= -1;
			bool	__stopProcess	= false;

			//Lorsque le run est en mode d�grad� on n'�x�cute rien
			if (_request.Run.Mode_Degrade)
			{
				Trace_Helper.Log_Message("Mode d�grad� detect� aucune modification effectu�e");
			}
			else
			{
				Trace_Helper.Log_Message("D�but de l'�x�cution des �tapes de modifications");
				foreach(Run_Task_Step __step in _request.Get_Steps())
				{
					Trace_Helper.Log_Message("Pr�paration de l'�tape {0} de modification", __step.Index);
					
					__step.Prepare(__stopProcess);
					Trace_Helper.Log_Message("d�but de l'�x�cution de l'�tape {0} des modifications Add:{1} Update:{2} Ignored:{3}", __step.Index, __step.NbBoxAdded, __step.NbBoxUpdate, __step.NbBoxExcluded);
					
					if (__step.Full_Exclude)
					{
						Trace_Helper.Log_Message("l'�tape {0} � �t� exclue des modifications, car il n'y avait rien � effectu�.", __step.Index);
					}
					else
					{
						//Cette �tape poss�de une �tape de pr�paration
						if (QXPFrk.Validation.IsNotNull(__step.Prepare_Step))
						{
							Trace_Helper.Log_Message("Ex�cution d'une pr�paration d'�tape pour l'�tape {0}.", __step.Index);							
							Execute(__step.Prepare_Step);
						}
						Execute( __step);
					}
					
					__lastBox		= __step.NbBoxDoc;

					//L'arret du processing des �tapes doit etre activ�e �ventuellement ou continuer s'il est d�j� actif
					__stopProcess	= (__stopProcess || __step.Partial_Exclude);

					Trace_Helper.Log_Message("fin de l'�x�cution de l'�tape {0} des modifications", __step.Index);
				}
				//Il y a eu des Boxes exclues on log dans les erreurs utilisateurs
				int __nbExcludedBoxes = _request.Run.Run_Task.NbExcludeBoxes;
				if( __nbExcludedBoxes > 0)
				{
					_request.Run.Errors.Add(Error_Type.Critique, "La taille du document ({0} boxes) ne permettait pas d'effectuer toutes les modifications, {1} Boxes ont �t� exclues", _request.Run.Run_Task.LastNbMaxDocBoxes, __nbExcludedBoxes); 
				}
				Trace_Helper.Log_Message("fin de modification du document qui contient finalement {0} Boxes !", __lastBox);
			}
			
		}

		/// <summary>
		/// Ex�cution d'une �tape de modification
		/// </summary>
		/// <param name="step">Ex�cution d'une �tape de modification</param>
		private void Execute(Run_Task_Step step) 
		{
			//Il y a des mise � jour de valeur � effectuer
			if(step.NameValues.Count > 0) 
			{ 
				if(step.Direct_Call)
				{
					QXPInteropQuarkServer.QXPS_Message_ParamsValue	__messageParamsValue = new QXPInteropQuarkServer.QXPS_Message_ParamsValue();
					__messageParamsValue.NameValues = step.NameValues.ToArray();
					this.QXPS_Caller.Request_Message.Messages.Add(__messageParamsValue);
				}
				else
				{
					QXPInteropQuarkServer.QXPSM_Request_ParamsValue __requestValue = new QXPInteropQuarkServer.QXPSM_Request_ParamsValue(step.NameValues.ToArray());
					this.QXPSM_Caller.Requests.Add(__requestValue);
				}
			}

			//Il y a des modifications de structure � effectuer
			if(!step.Modifier.Empty) 
			{ 
				if(step.Direct_Call)
				{
					//Envoi du ficher XML sur le serveur
					string __modify_Name			= QXPS_File_Manager.GetPoolPath(string.Format(ModifyNamePattern, DateTime.Now));
					QXPS_File_Manager.Addfile(__modify_Name, step.Modifier.GetIOValue().To_Bytes());

					//Ajout de la commande modify en appel direct
					QXPInteropQuarkServer.QXPS_Message_Modify	__messageModifier = new QXPInteropQuarkServer.QXPS_Message_Modify();
					__messageModifier.Modify_File	= __modify_Name;
					this.QXPS_Caller.Request_Message.Messages.Add(__messageModifier);
				}
				else
				{
					QXPInteropQuarkServer.QXPSM_Request_Modifier	__requestModifier = new QXPInteropQuarkServer.QXPSM_Request_Modifier(step.Modifier.GetProject());
					this.QXPSM_Caller.Requests.Add(__requestModifier);
				}
			}

			//Puis on peut sauvegarder le fichier QXP
			if(step.Direct_Call)
			{
				QXPInteropQuarkServer.QXPS_Message_SaveAs	__messageSaveAs = new QXPInteropQuarkServer.QXPS_Message_SaveAs();
				__messageSaveAs.Path		= QXPS_File_Manager.GetPoolPathAbsolute(string.Empty);
				__messageSaveAs.New_Name	= GetNewGabaritNameExt();
				__messageSaveAs.Replace		= true;
				__messageSaveAs.SaveToPool	= false;
				
				this.QXPS_Caller.Request_Message.Messages.Add(__messageSaveAs);
			}
			else
			{
				QXPInteropQuarkServer.QXPSM_Request_SaveAs	__requestSaveAs;
				__requestSaveAs = new QXPInteropQuarkServer.QXPSM_Request_SaveAs(QXPS_File_Manager.GetPoolPathAbsolute(string.Empty)
																			, GetNewGabaritNameExt()
																			, true
																			, false); // � v�rifier avec true sans newfilePath si ca marche
				this.QXPSM_Caller.Requests.Add(__requestSaveAs);
			}

			//R�cup�ration de la nouvelle version du qxp
			//il faut d'abord ajouter un rendu en qxp avant de faire un saveas
			if(step.Direct_Call)
			{
				//Ajout de la commande rendu qxp
				QXPInteropQuarkServer.QXPS_Message_QXP	__messageQXP = new QXPInteropQuarkServer.QXPS_Message_QXP();
				this.QXPS_Caller.Request_Message.Messages.Add(__messageQXP);
			}
			else
			{
				QXPInteropQuarkServer.QXPSM_Request_QXP	__requestQXP = new QXPInteropQuarkServer.QXPSM_Request_QXP();
				this.QXPSM_Caller.Requests.Add(__requestQXP);
			}


			if(step.Direct_Call)
			{
				//appel direct � quark
				this.QXPS_Caller.SDKCall();
			}
			else
			{
				//appel � quark server � travers le manager quark
				this.QXPSM_Caller.SDKCall();
			}


			//on change le gabarit
			_request.Run.Gabarit.Change_Document(GetNewGabaritNameExt());

			//on r�cup�re le nouveau nom dans le pool path
			string __newPoolName = _request.Run.Gabarit.FilePoolPath;

			QXPS_File_Manager.Addfile_Inform(__newPoolName);

			//Faire du nouveau document la version de travail des 'Callers' pour les prochaines requetes !!
			this.QXPS_Caller.Request_Message.Call_Info.DocumentName = __newPoolName;
			if(QXPFrk.Validation.IsNotNull(this.QXPSM_Caller.SDK_Context))
			{
				this.QXPSM_Caller.SDK_Context.documentName = __newPoolName;
			}


			//Fin de l'�tape d'�x�cution, on incr�ment le compteur
			_execution_count++;

		}

		/// <summary>
		/// Ex�cution des diff�rents rendus (QXP, PDF etc.) du document final
		/// </summary>
		public void Render() { 
			
            Trace_Helper.Log_Message("d�but de rendu final qxp/pdf etc..");
			
			if(_request.RenderJPG)
			{
				QXPInteropQuarkServer.QXPS_Message_JPEG	__jpegMessage		= new QXPInteropQuarkServer.QXPS_Message_JPEG();
				this.QXPS_Caller.Request_Message.Messages.Add(__jpegMessage);
				this.QXPS_Caller.SDKCall();
                _response.JPG_Data = this.QXPS_Caller.Response_Message.Data;
            }

			//les erreurs de rendu pdf parce que le document est vide n'est plus source de blocage dans le rendu du run
			try
			{
				if (_request.RenderPDF)
				{
					QXPInteropQuarkServer.QXPS_Message_PDF __pdfMessage = new QXPInteropQuarkServer.QXPS_Message_PDF();
					//// Initialisation des infos de compression
					__pdfMessage.ColorImageDownSample = __pdfMessage.GrayscaleImageDownSample = __pdfMessage.MonochromeImagedownSample = _request.Value_Compression;
					__pdfMessage.ColorCompression = __pdfMessage.GrayscaleCompression = __pdfMessage.MonochromeCompression = _request.Compression;
					this.QXPS_Caller.Request_Message.Messages.Add(__pdfMessage);
					this.QXPS_Caller.SDKCall();
					_response.PDF_Data = this.QXPS_Caller.Response_Message.Data;

				}
			}
			catch (QXPInteropQuarkServer.QXPS_Exception qxps_exception)
			{
				this.Request.Run.Errors.Add(Error_Type.Critique, "Rendu Impossible du document pdf");
				Trace_Helper.Log_Message("Rendu PDF impossible \n{0}", qxps_exception.Message);
			}
			catch (Exception ex)
			{
				throw;
			}
            if(_request.RenderQXP)
			{
				//La derni�re version du document qxp est d�j� dans le Gabarit
				_response.QXP_Data = QXPInteropQuarkServer.QXPS_Helper.GetFileData(_request.Run.Gabarit.FilePoolPath);
            }
			
			Trace_Helper.Log_Message("fin de l'�x�cution des �tapes de rendu");

		}
		/// <summary>
		/// Permet d'obtenir le nouveau nom du gabarit
		/// </summary>
		/// <returns>le nouveau nom du gabarit en cours</returns>
		private string GetNewGabaritName()
		{ 
            Document __gabarit = _request.Run.Gabarit;
			if(QXPFrk.Validation.IsSet(__gabarit.ID, false))
				return string.Format(NewGabaritNameWithIDPattern, __gabarit.FilePrefix, __gabarit.ID, _execution_count);
			else
				return string.Format(NewGabaritNamePattern, __gabarit.Name, _execution_count);

		}
		
		/// <summary>
		/// Permet d'obtenir le nouveau nom du gabarit avec l'extension
		/// </summary>
		/// <returns>le nouveau + ext nom du gabarit en cours</returns>
		private string GetNewGabaritNameExt()
		{ 
            Document __gabarit = _request.Run.Gabarit;
            
			if(QXPFrk.Validation.IsSet(__gabarit.ID, false))
				return string.Format(NewGabaritNameExtWithIDPattern, __gabarit.FilePrefix, __gabarit.ID, _execution_count, __gabarit.Format);
			else
				return string.Format(NewGabaritNameExtPattern, __gabarit.Name, _execution_count, __gabarit.Format);
		}

		#endregion M�thodes

		#region Propri�t�s
        /// <summary>
        /// contient les informations � envoyer au serveur quark
        /// </summary>
		public QXPS_Caller_Request	Request
        {
            get { return _request; }
        }        

		/// <summary>
        /// contient les information re�u du serveur quark
        /// </summary>
		public QXPS_Caller_Response Response
        {
            get { return _response; }
        }        
		#endregion Propri�t�s
	}
}
