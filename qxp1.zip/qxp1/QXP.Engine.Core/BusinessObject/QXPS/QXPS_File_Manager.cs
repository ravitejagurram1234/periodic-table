using System;
using System.Collections.Generic;
using System.IO;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPIO = QXP.Framework.IO;
using QXPInterop = QXP.Interop;
using QXPInteropQuarkServer = QXP.Interop.QuarkServer;
using QXPSMSDK = com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet la manipulation des documents utilis�e lors du processus de g�n�ration d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>24/03/2010 15:01:14</date>    
	public class QXPS_File_Manager
	{
		#region Membres
        static QXPFrk.BaseList<string>		_addedFiles					= new QXPFrk.BaseList<string>();
		static Dictionary<string, Document>	_cachedFiles				= new Dictionary<string, Document>();
		static string						_currentPoolPath			= null;
		static string						_currentPoolPathAbsolute	= null;
		
		static string						_defaultPoolPathAbsolute	= null;
		static bool							_save_Used_Ressources		= true;                 // D�finit si les ressource utilis� sont sauvegarder sur le disque dure local de l'application !
		static string						_save_Used_Ressources_Path	= null;    // D�finit le nom du repertoire de l'application ou sont sont sauvergarde la copie des ressources utilis�es pour la g�n�ration
		static bool							_delete_QXPS_Ressources		= false;    
		static bool							_save_QXPS_Response			= true;

		#endregion Membres

		#region Constantes
        const string                        DocKeyCatPattern			= "{0}|{1}|{2}|{3}|{4}";
		const string                        DocKeyIdPattern				= "d{0}";
        const string                        DocCertifieKeyPattern		= "cert|{0}|{1}";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur
		/// <summary>
		/// Permet d'initialiser les param�tres du File Manager
		/// </summary>
		static QXPS_File_Manager()
		{ 
			try
			{
				_currentPoolPathAbsolute	=  _defaultPoolPathAbsolute	= EngineCoreSetting.Current.DefaultPoolPathAbsolute;
				_save_QXPS_Response			= EngineCoreSetting.Current.Save_QXPS_Response;
				_save_Used_Ressources		= EngineCoreSetting.Current.Save_Used_Ressources;
				_save_Used_Ressources_Path	= EngineCoreSetting.Current.Save_Used_Ressources_Path;
				_delete_QXPS_Ressources		= EngineCoreSetting.Current.Delete_QXPS_Ressources;
			}
			catch(Exception ex)
			{
				QXPDiagnostic.Log.LogError("Invalid or missing EngineCoreSetting", ex);
			}
		}
		#endregion Constructeur

		#region M�thodes
        /// <summary>
        /// Retourne le nom complet absolu du document dans le pool path en cours
        /// </summary>
        /// <param name="documentName">nom du document</param>
        /// <returns></returns>
		public static string						GetPoolPathAbsolute(string documentName)
        {
            return string.Concat(_currentPoolPathAbsolute, documentName).Replace("/", "\\");
        }
        
        /// <summary>
        /// Obtient le chemin absolu de sauvegarde de ressource local pour un document
        /// </summary>
        /// <param name="documentName"></param>
        /// <returns></returns>
		public static string						GetSaveUsedRessourcePathAbsolute(string documentName)
        {
            return string.Concat(_save_Used_Ressources_Path, documentName).Replace("/", "\\");
        }
		
		/// <summary>
		/// permet d'obtenir le chemin d'un fichier dans le pool (en tenant compte du chemin relatif (_currentPoolPath) ex: R_1451\)
		/// </summary>
		/// <param name="documentName">nom du document</param>
		/// <returns>chemin relatif du document dans le pool path quark</returns>
        public static string						GetPoolPath(string documentName)
        {
            return string.Concat(_currentPoolPath, documentName);
        }

		/// <summary>
		/// Permet d'ajouter un fichier dans le pool path quark. 
		/// Attention le nom du fichier doit tenir compte du r�pertoire relatif exemple "R_102\toto.qxp"
		/// </summary>
		/// <param name="MyDoc">le nom du document</param>
		/// <param name="MyFile">le flux binaire du document � ajouter</param>
        public static void							Addfile(string MyDoc, byte[] MyFile) {
            //Le document est d�j� pr�sent sur le serveur !!
            if(_addedFiles.Contains(MyDoc)) return;
			
            //Si cette fonction plante il ne faut pas arreter la g�n�ration c'est pour le debug uniquement
            string __file = string.Empty;
            try
			{
                if(_save_Used_Ressources)
				{
                    __file = string.Concat(_save_Used_Ressources_Path, MyDoc);
                    QXPIO.FileHelper.SaveFile(__file, MyFile, true);
                }
            }
			catch(Exception ex)
			{
                Trace_Helper.Log_Exception_Message(ex, "Impossible de sauvegarder le fichier {0}", __file);
            }

			try
			{
				//Permet l'ajout dans le document pool de QuarkXpress server en direct
                QXPInteropQuarkServer.QXPS_Helper.AddFile(MyDoc, MyFile);
				//Permet de garder une trace des fichiers (tous type confondus) ajouter sur le serveur quark
                _addedFiles.Add(MyDoc);
            }
			catch (Exception ex)
			{
                throw ex;
            }
		}
        
        /// <summary>
		/// Permet de supprimer un fichier dans le pool path quark. 
		/// Attention le nom du fichier doit tenir compte du r�pertoire relatif exemple "R_102\toto.qxp"
        /// Il faut �galement que le fichier en question ait �t� ajout� lors du run en cours
		/// </summary>
		/// <param name="MyDoc">le nom du document</param>
        public static void							Deletefile(string MyDoc) {
            //Le document est bien pr�sent sur le serveur et � �t� ajouter dans le m�me context que celui qui esssaye de supprimer
            if(!_addedFiles.Contains(MyDoc)) return;
			
            try
			{
				//Permet de supprimer le document pool de QuarkXpress server en direct
                QXPInteropQuarkServer.QXPS_Helper.DeleteFile(MyDoc);
				//Permet de supprimer la trace du fichier ajout� sur le serveur quark
                _addedFiles.Remove(MyDoc);
            }
			catch (Exception ex)
			{
                throw ex;
            }
		}

		/// <summary>
		/// Permet d'informer le manager qu'un nouveau fichier est pr�sent dans le document pool
		/// Cette methode est appeler par exemple lorsqu'une op�ration de type SaveAs est effectu�e
		/// </summary>
		/// <param name="MyDoc">le nom du document d�j� pr�sent dans le poolpath de quark server</param>
		public static void							Addfile_Inform(string MyDoc)
		{
            if(_addedFiles.Contains(MyDoc)) return;
            else _addedFiles.Add(MyDoc);
        }

		/// <summary>
		/// Permet de r�cup�rer un fichier depuis le pool en cours du document pool quark. 
		/// attention filename ne doit pas contenir le chemin relatif (ex "R_XXX\toto.qxp" est faut) il faut mettre toto.qxp puis la fonction ajoute le _currentPoolPath
		/// </summary>
		/// <param name="fileName">nom du document</param>
        public static Document						Get_FilePool(string fileName) {
            string __filePool = GetPoolPath(fileName);
			
			//Le document est d�j� pr�sent dans le cache local ont le renvoi !!
            if(_cachedFiles.ContainsKey(fileName)) return _cachedFiles[fileName];
			
			try
			{
				string __fileName	= GetFileName(__filePool);
				string __ext		= GetFileExt(__filePool);

				Document __doc =new Document(__fileName, QXPInteropQuarkServer.QXPS_Helper.GetFileData(__filePool), __ext);
				_cachedFiles.Add(__doc.FileName, __doc);
				return __doc;
            }
			catch (Exception ex)
			{
                throw ex;
            }
		}
		/// <summary>
		/// Permet d'obtenir la structure d'un document quark apr�s l'avoir envoy� au server
		/// </summary>
		/// <param name="doc">un document de l'Engine</param>
		/// <returns>un projet quark repr�sentation d'un fichier QXP</returns>
        public static QXPSMSDK.Project Get_Project(Document doc) 
		{ 
			return Get_Project(doc, true);
		}		

		/// <summary>
		/// Permet d'obtenir la structure d'un document quark apr�s l'avoir envoy� ou pas au server
		/// </summary>
		/// <param name="doc">document quark</param>
		/// <param name="addFile">true ajout le fichier dans le document pool du server</param>
		/// <returns>Une structure de projet Quark.</returns>
        public static QXPSMSDK.Project Get_Project(Document doc, bool addFile) 
		{ 
            //envoi du document QXP
			if(addFile) Addfile(doc.FilePoolPath, doc.Data);

			return QXPInteropQuarkServer.QXPSM_Helper.Get_Project(doc.FilePoolPath);
		}		

        /// <summary>
        /// Permet d'obtenir une r�f�rence permettant de manipuler la structure xml d'un document quark
        /// </summary>
        /// <param name="doc">le document quark � utilis� comme source xml</param>
        /// <returns>une structure permettant l'analyse xml du document qxp</returns>
		public static QXP_XML						Get_XML(Document doc)
		{
            
			return Get_XML(doc, true);    
		}

        /// <summary>
        /// Permet d'obtenir une r�f�rence permettant de manipuler la structure xml d'un document quark
        /// </summary>
        /// <param name="doc">le document quark � utilis� comme source xml</param>
		/// <param name="addFile">faut-il ajouter le document dans le document pool de quark server</param>
        /// <returns>une structure permettant l'analyse xml du document qxp</returns>
        public static QXP_XML						Get_XML(Document doc, bool addFile)
		{
            //envoi du document QXP
			if(addFile) Addfile(doc.FilePoolPath, doc.Data);

			QXP_XML		__xmlQXP	= QXP_XML.Create_From_File(doc.FilePoolPath);
            return __xmlQXP;  		
		}

        /// <summary>
        /// Permet d'obtenir un Document de reference dans la base de donn�e ou dans le cache si ce document � d�j� �t� charg�
        /// </summary>
        /// <param name="id_sous_categorie">id sous categorie</param>
        /// <param name="id_fnd_code">code du fond</param>
		/// <param name="id_unit_code">identifiant de la part du fond</param>
        /// <param name="societe">societe</param>
        /// <param name="id_langue">id langue</param>
        /// <param name="date_echeance">date echeance du document</param>
        /// <returns>Un document</returns>
		public static Document						Get_Document(int id_sous_categorie, string id_fnd_code, string id_unit_code, string societe, int id_langue, DateTime date_echeance)
		{
            string              __doc_key   = string.Format(DocKeyCatPattern, id_sous_categorie, id_fnd_code, id_unit_code, societe, id_langue);        
            Document			__doc       = null;
            if(_cachedFiles.ContainsKey(__doc_key))
			{
                __doc = _cachedFiles[__doc_key];
            }
			else
			{
                Proxy_Document __proxy = new Proxy_Document();
                __doc   = __proxy.Get_Document(id_sous_categorie, id_fnd_code, id_unit_code, societe, id_langue, date_echeance);
                _cachedFiles.Add(__doc_key, __doc);
            }
            return __doc;
        }
        
		/// <summary>
        /// Permet d'obtenir un Document de reference dans la base de donn�e ou dans le cache si ce document � d�j� �t� charg�
        /// </summary>
        /// <param name="id_document">id du document</param>
        /// <returns>Un document</returns>
		public static Document						Get_Document(int id_document)
		{
            string              __doc_key   = string.Format(DocKeyIdPattern, id_document);        
            Document			__doc       = null;
            if(_cachedFiles.ContainsKey(__doc_key))
			{
                __doc = _cachedFiles[__doc_key];
            }
			else
			{
                Proxy_Document __proxy = new Proxy_Document();
                __doc   = __proxy.Get_Document(id_document);
                _cachedFiles.Add(__doc_key, __doc);
            }
            return __doc;
        }

		/// <summary>
		/// Permet d'obtenir la derni�re version d'un document quark certifi�
		/// </summary>
		/// <param name="idSuivi">identifiant du suivi</param>
		/// <param name="idTypeRapport">identifiant du type de rapport</param>
		/// <param name="id_langue">identifiant de la langue du rapport</param>
		/// <returns>un document</returns>
		public static Document						Get_Last_Qxp_Certifie(int idSuivi, int idTypeRapport, int id_langue)
		{
            string __doc_key = string.Format(DocCertifieKeyPattern, idSuivi, idTypeRapport);
            Document __doc    = null;
            if (_cachedFiles.ContainsKey(__doc_key))
			{
                __doc = _cachedFiles[__doc_key];
            }
			else
            {
                Proxy_Document __proxy = new Proxy_Document();
                __doc = __proxy.Get_Last_Qxp_Certifie(idSuivi, idTypeRapport, id_langue);
                _cachedFiles.Add(__doc_key, __doc);
            }
            return __doc;
        }

		/// <summary>
		/// Purge de tous les fichiers ajouter par le file manager dans le document pool (du _currentPoolpath).
		/// Eventuellement suppression du folder qui contenait ces fichiers !!
		/// </summary>
		/// <param name="remove_folder">faut-il supprimer le r�pertoire (true = oui) sinon false</param>
		public static void							PurgeAddedFiles(bool remove_folder)
		{
			//suppression des fichiers pr�sent sur le serveur
			foreach(string __file in _addedFiles)
			{
				QXPInteropQuarkServer.QXPS_Helper.DeleteFile(__file);
			}
			//suppression de la liste des fichiers pr�sent sur le serveur !
			_addedFiles.Clear();
			
			//Suppression du r�pertoire
			if(remove_folder)
			{
				//S�curit� si _currentPoolPath est vide ccela veux dire que l'on travail � la racine du poolpath quark on ne doit pas le supprimer
				if(QXPFrk.Validation.IsSet(_currentPoolPath))
				{
					QXPInteropQuarkServer.QXPS_Helper.DeleteFile(_currentPoolPath);
				}
			}
		}

		#region Miscellaneous File analysis
		/// <summary>
		/// Permet de retrouver le nom du fichier sans extension contenu dans documentName (exemple test)
		/// </summary>
		/// <param name="documentName">nom complet du document</param>
		/// <returns></returns>
		public static string						GetFileName(string documentName)
		{
			return Path.GetFileNameWithoutExtension(documentName);
		}

		/// <summary>
		/// Permet de retrouver le nom + extension du fichier contenu dans documentName (exemple test.qxp)
		/// </summary>
		/// <param name="documentName">nom complet du document</param>
		/// <returns></returns>
		public static string						GetFileNameExt(string documentName)
		{
			return Path.GetFileName(documentName);
		
		}

		/// <summary>
		/// Permet de retrouver l'extension sans le point contenu dans documentName (exemple qxp)
		/// </summary>
		/// <param name="documentName">nom complet du document</param>
		/// <returns></returns>
		public static string						GetFileExt(string documentName)
		{
			return Path.GetExtension(documentName).Substring(1); ////Enl�ve le . de l'extension
		}

		/// <summary>
		/// Permet de retrouver le chemin contenu dans documentName (exemple R_1203/)
		/// </summary>
		/// <param name="documentName">nom complet du document</param>
		/// <returns></returns>
		public static string						GetFilePath(string documentName)
		{
			return Path.GetDirectoryName(documentName);
		}
		#endregion Miscellaneous File analysis

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Permet de d�finir le poolpath en cours et ainsi de d�duire le poolpathabsolute
		/// </summary>
		public static void SetPoolPath(string newPoolPath)
		{
			//au cas ou la chaine est vide
			_currentPoolPath			= QXPFrk.Conversion.ToString(newPoolPath).Replace("\\", "/");
			_currentPoolPathAbsolute	= string.Concat(_defaultPoolPathAbsolute, newPoolPath).Replace("/", "\\");
		}
		
		/// <summary>
		/// R�pertoire en cours dans le pool path du server quark (Ex: "R_1125\")
		/// </summary>
		public static string CurrentPoolPath 
		{
			get { return _currentPoolPath; }
		}
		
		/// <summary>
		/// Chemin absolu en cours dans le poolPath sur le server quark (ex "D:\Documents\R_1125")
		/// </summary>
		public static string CurrentAbsolutePoolPath 
		{
			get { return _currentPoolPathAbsolute; }
		}

		/// <summary>
		/// Chemin absolu du poolPath sur le server quark (ex "D:\Documents\"). 
		/// De ce chemin doit �tre d�duit le chemin en cours "CurrentAbsolutePoolPath" par l'application
		/// </summary>
		public static string QuarkAbsolutePoolPath 
		{
			get { return _currentPoolPathAbsolute; }
			set { _currentPoolPathAbsolute = value; }
		}

		/// <summary>
		/// Dans quel r�pertoire local faut-il sauvegarder les fichiers manipul�s
		/// </summary>
		public static string Save_Used_Ressources_Path 
		{
			get { return _save_Used_Ressources_Path; }
			set { _save_Used_Ressources_Path = value; }
		} 

		/// <summary>
		/// Faut-il sauvegarder localement les fichiers manipul�s (def : false - pas de sauvegarde locale)
		/// </summary>
		public static bool Save_Used_Ressources
		{
			get { return _save_Used_Ressources; }
			set { _save_Used_Ressources = value; }
		} 

		/// <summary>
		/// Faut-il sauvegarder localement les fichiers de la r�ponse finale (QXP/PDF/WORD)
		/// </summary>
		public static bool Save_QXPS_Response
		{
			get { return _save_QXPS_Response; }
			set { _save_QXPS_Response = value; }
		} 
		#endregion Propri�t�s
	}
}
