using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

using QXPFrk		= QXP.Framework;
using QXPDiagnostic	= QXP.Framework.Diagnostic;
using QXPIO			= QXP.Framework.IO;
using QXPAudit		= QXP.Audit;

using QXPInterop			= QXP.Interop;
using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;

namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini les methodes propri�t�s d'un run quark, cette class doit �tre d�riv�e afin de d�finir ces param�tres 
	/// Une tache repr�sente un ensemble de modification sur un document quark
	/// elle contient des param�tres qui d�finissent les op�rations � effectuer sur le document
	/// cette classe est d�riv�e en plusieurs type de tache qui effectue des op�rations sp�cifiques
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:18:09</date>    
	public abstract class Run_Base
	{
		#region Membres
		/// <summary>
		/// Cette propri�t� static permet de savoir si le context d'�x�cution des runs est d�finis
		/// </summary>
		/// <remarks>
		/// le contexte d'�x�cution des run est d�fini une fois pour toute par le premier run qui s'�x�cute dans le process, les autres runs utilierons le m�me contexte
		/// </remarks>
		static	bool	_isSetThreadContext	= false;

		int				_id;

		Guid			_uid					= Guid.NewGuid();
		DateTime		_debutGeneration		= DateTime.Now;
		DateTime		_finGeneration			= DateTime.MinValue;
		Run_Properties	_properties;
		InParams		_inParams;
		Run_Status		_status					= Run_Status.ToGenerate;
		Run_Step		_step					= Run_Step.Unknown;
		Errors			_errors;
		Tasks			_tasks					= new Tasks();
		Run_Result		_result					= new Run_Result();
		Run_Task		_run_Task;
		Audit			_audit					= null;
		Document		_gabarit				= null;
		Document		_gabarit_Template		= null;
		Templates		_templates				= new Templates();
		Trace_Context	_trace_Context			= null;
		QXPS_Caller		_caller					= null;
		DataNamesValues	_sqlDataNamesValues		= new DataNamesValues();
		DataNamesValues	_docDataNamesValues		= new DataNamesValues();


		int				SizeLimitBeforeFailSoft = EngineCoreSetting.Current.Size_Limit_Before_Fail_Soft;
		#endregion Membres

		#region Constantes
		private const string DebugInfoPattern	= "(R_{0}/S_{1})";

		private const string BoxStart			= "Box";
		private const string BracketOpen		= "[";
		private const string BracketClose		= "]";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Run_Base
		/// </summary>
		/// <param name="id">identifiant du run</param>
		protected Run_Base(int id)
		{
			_id			= id;
			_properties = new Run_Properties();
			_inParams	= new InParams();
			_errors		= new Errors();
			_run_Task	= new Run_Task(this);
		}
		#endregion Constructeur

		#region M�thodes
		
		#region Launch

		/// <summary>
		/// Lancement du run, point de d�part de la chaine d'�x�cution du run
		/// </summary>
		public void				Launch()
		{
			try
			{
				this.SetTraceContext();

				//D�but de l'audit
				_audit = new Audit(this);

				_status = Run_Status.Running;

				Launch_Start();
				
				Launch_Load();

				//on execute ces �tapes que si nous ne sommes pas en mode d�grad�
				if (!this.Mode_Degrade)
				{
					Launch_Prepare();

					Launch_Process();

					Launch_Process_Steps();

					Launch_Check();
				}
				
				Launch_Render();

				_status = Run_Status.Generated;

			}
			//C'est une exception control�e par l'application
			catch(Exception_Base cex)
			{
				QXPDiagnostic.Log.LogError(Constantes.Error_Messages.ApplicationError, cex);
				this.Errors.Add(cex.Type, cex);
				_status = Run_Status.Error;
			}
			catch(Exception ex)
			{
				//nous ne devrions plus arriver dans ce cas !!
				QXPDiagnostic.Log.LogError(Constantes.Error_Messages.ApplicationError, ex);
				this.Errors.Add(Error_Type.Bloquante, ex.Message);
				_status = Run_Status.Error;
			}
			finally
			{
				//si une erreur impr�vue se produit il faut mettre fin au run quand m�me
				_step			= Run_Step.End;
				_finGeneration	= DateTime.Now;

				if (this.Mode_Degrade)
				{
					this.Errors.Add(Error_Type.Critique, Constantes.Error_Messages.RunInSafeMode);
				}

				try
				{
					this.End();
				}
				catch(Exception ex)
				{
					QXPDiagnostic.Log.LogError(Constantes.Error_Messages.ApplicationError, ex);
				}
				finally
				{
					Trace_Helper.Log_Message("Fin du Run {0} Etape:{1} Status:{2} avec {3} erreurs", this.ID, _step, _status, _errors.Count);
				}
			}
			
		}

		/// <summary>
		/// D�but du run
		/// </summary>
		private void				Launch_Start()
		{
			_step	= Run_Step.Start;

			Trace_Helper.Log_Message("D�but du Run {0}", this.ID);
			
			Execution_Helper.Universal_Executer<Exception_Run>(this.Start, Exception_Run.MSG_Start_Run, this.ID);
		}

		/// <summary>
		/// Chargement du run
		/// </summary>
		private void				Launch_Load()
		{
			_step = Run_Step.Load;

			Trace_Helper.Log_Message("Chargement du Run {0}", this.ID);

			this.Load();
		}

		/// <summary>
		/// Pr�paration
		/// </summary>
		private void				Launch_Prepare()
		{
			_step = Run_Step.Prepare;
					
			Trace_Helper.Log_Message("Preparation du Run {0}", this.ID);
					
			this.Prepare();
		}

		/// <summary>
		/// Ex�cution des taches
		/// </summary>
		private void				Launch_Process()
		{
			_step = Run_Step.Process;

			Trace_Helper.Log_Message("Processing du Run {0}", this.ID);

			this.Process();		
		}


		/// <summary>
		/// Ex�cution des �tapes de modifications
		/// </summary>
		private void				Launch_Process_Steps()
		{
			_step = Run_Step.Process_Steps;

			Trace_Helper.Log_Message("Ex�cution des �tapes du Run {0}", this.ID);

			//Attention il s'agit d'un appel un peu particulier � l'universal executer
			//en effet si durant l'appel du render une exception de type  QXPInteropQuarkServer.QXPS_Exception est lev�e elle est intercepter par une autre exception pour analyse du contenue
			Execution_Helper.Universal_Executer<Exception_Run, QXPInteropQuarkServer.QXPS_Exception, Exception_Render>(this.Process_Steps, Exception_Run.MSG_Render_Run, this.ID);
			
		}

		/// <summary>
		/// V�rification du run
		/// </summary>
		private void			Launch_Check()
		{
			_step = Run_Step.Check;
				
			Trace_Helper.Log_Message("V�rification du Run {0}", this.ID);

			//Attention il s'agit d'un appel un peu particulier � l'universal executer
			//en effet si durant l'appel du render une exception de type  QXPInteropQuarkServer.QXPS_Exception est lev�e elle est intercepter par une autre exception pour analyse du contenue
			Execution_Helper.Universal_Executer<Exception_Run>(this.Check, Exception_Run.MSG_Check_Run, this.ID);
		}

		/// <summary>
		/// Execution du rendu
		/// </summary>
		private void			Launch_Render()
		{
			_step = Run_Step.Render;

			Trace_Helper.Log_Message("Rendu du Run {0}", this.ID);

			//Attention il s'agit d'un appel un peu particulier � l'universal executer
			//en effet si durant l'appel du render une exception de type  QXPInteropQuarkServer.QXPS_Exception est lev�e elle est intercepter par une autre exception pour analyse du contenue
			Execution_Helper.Universal_Executer<Exception_Run, QXPInteropQuarkServer.QXPS_Exception, Exception_Render>(this.Render, Exception_Run.MSG_Render_Run, this.ID);
		
		}
		
		#endregion

		/// <summary>
		/// Permet de d�finir le contexte de trace sur le run en cours
		/// </summary>
		public void				SetTraceContext()
		{
			Trace_Helper.Set_Trace_Context(this.Trace_Context);
		}

		/// <summary>
		/// D�but du run
		/// par exemple inscription dans la base de donn�e que le run est en cours
		/// </summary>
		protected virtual void	Start()
		{
		
		}

		/// <summary>
		/// Fin du run
		/// par exemple inscription dans la base de donn�e que le run est fini
		/// </summary>
		protected virtual void	End()
		{
			
		}

		/// <summary>
		/// Chargement du run 
		/// </summary>
		private	void			 Load()
		{
			Trace_Helper.Log_Message("Chargement des propri�t�s", this.ID);
			Execution_Helper.Universal_Executer<Exception_Run>(this.LoadProperties, Exception_Run.MSG_Load_Run_Properties, this.ID);
			
			if(!_isSetThreadContext) InitThreadContext(); 
			
			Trace_Helper.Log_Message("Pr�paration du gabarit {0}", this.Properties.ID_Gabarit);
			Execution_Helper.Universal_Executer<Exception_Run>(this.PrepareGabarit, Exception_Run.MSG_PrepareGabarit, this.ID);

			//si nous sommes en mode d�grad� nous ne pr�parons pas les taches et leurs param�tres
			if (!this.Mode_Degrade)
			{
				Trace_Helper.Log_Message("Chargement des InParams");
				Execution_Helper.Universal_Executer<Exception_Run>(this.LoadInParams, Exception_Run.MSG_Load_Run_InParams, this.ID);

				this.InParams.InitOraParameters();

				Trace_Helper.Log_Message("Chargement des Taches");
				Execution_Helper.Universal_Executer<Exception_Run>(this.LoadTasks, Exception_Run.MSG_Load_Run_Tasks, this.ID);

				Trace_Helper.Log_Message("Chargement des Templates");
				Execution_Helper.Universal_Executer<Exception_Run>(this.LoadTemplates, Exception_Run.MSG_Load_Run_Template, this.ID);
			}
		}

		/// <summary>
		/// Chargement des Propri�t�s d'un run
		/// </summary>
		protected virtual void	LoadProperties()
		{
		
		}

		/// <summary>
		/// Pr�paration du gabarit du Run
		/// </summary>
		protected virtual void	PrepareGabarit()
		{
		
		}

		/// <summary>
		/// Chargement des InParams du run <see cref="InParams"/>
		/// </summary>
		protected virtual void	LoadInParams()
		{
		
		}

		/// <summary>
		/// Chargement des taches � effectuer
		/// </summary>
		protected virtual void	LoadTasks()
		{
		
		}

		/// <summary>
		/// Chargement des templates et du gabarit template associ�s au run. 
		/// </summary>
		protected virtual void	LoadTemplates()
		{
		
		}
		
		/// <summary>
		/// Pr�paration des diff�rentes �tapes � r�aliser
		/// </summary>
		/// <remarks>
		/// Evaluation de diff�rents param�tres:
		/// R�cup�ration de document / envoi de fichier au server
		/// Analyse des fichiers r�cup�r�s
		/// </remarks>
		private void			Prepare()
		{
			foreach(Task_Base __task in _tasks.Values)
			{
				try
				{
					Execution_Helper.Universal_Executer<Exception_Task>(__task.Prepare, Exception_Task.MSG_Prepare_Task , __task.ID, this.Debug_Info);
				}
				catch(Exception ex)
				{
					this.Errors.Add(Error_Type.Critique, ex.Message, __task.ID);
					QXPDiagnostic.Log.LogError(Constantes.Error_Messages.ApplicationError, ex);
					__task.InError = true;
				}
			}
		}

		/// <summary>
		/// Ex�cution des diff�rentes taches � r�aliser
		/// </summary>
		/// <remarks>
		/// Pour chacune des taches, diff�rents types de Bloc_Base vont �tre cr��.
		/// </remarks>
		protected virtual void	Process()
		{
			_run_Task = new Run_Task(this);
			
			//Processing initial
			//ex�cution standard des taches
			foreach(Task_Base __task in _tasks.GetEnumerable<Task_Base>(true))
			{
				//Uniquement les taches en Todo est qui ne sont pas en erreur
				if(!__task.InError)
				{
					try
					{
						Trace_Helper.Log_Message("D�but du processing de la tache {0}", __task.ID);

						//La tache est-elle en mode d�grad�
						if (__task.Mode_Degrade)
						{
							this.Errors.Add(Error_Type.Critique, Constantes.Error_Messages.TaskFailSoftMode, __task.ID);
						}
						else
						{
							Execution_Helper.Universal_Executer<Exception_Task>(__task.Reset_Process, Exception_Task.MSG_Reset_Process_Task, __task.ID, this.Debug_Info);
							Execution_Helper.Universal_Executer<Exception_Task>(__task.Process, Exception_Task.MSG_Process_Task, __task.ID, this.Debug_Info);
						}
						

						Trace_Helper.Log_Message("Fin du processing de la tache {0} avec {1} blocs update {2} blocs modify", __task.ID, __task.Blocs_Update.Count, __task.Blocs_Modify.Count);
					}
					//Erreur maison
					catch (Exception_Base exb)
					{
						__task.InError = true;
						this.Errors.Add(Error_Type.Critique, exb);
						QXPDiagnostic.Log.LogError(Constantes.Error_Messages.ApplicationError, exb);
					}
					//erreur inconnu
					catch (Exception ex)
					{
						__task.InError = true;
						this.Errors.Add(Error_Type.Critique, Constantes.Error_Messages.TaskProcessing, __task.ID);
						QXPDiagnostic.Log.LogError(Constantes.Error_Messages.ApplicationError, ex);
					}
				}
			}

			//Processing secondaire
			//Certaines taches ont besoin d'�tre s�r que toutes les autres taches soient d�j� ex�cut�es (exemple DID_Task)
			//par exemple afin de pouvoir v�rifier certaines propri�t�s des blocs d�j� g�n�r�s.
			foreach(Task_Base __task in _tasks.GetEnumerable<Task_Base>(true))
			{
				//Uniquement les taches en Todo est qui ne sont pas en erreur ou en mode d�grad�
				if(!__task.InError && !__task.Mode_Degrade)
				{
					try
					{
						Trace_Helper.Log_Message("D�but du post processing de la tache {0}", __task.ID);

						Execution_Helper.Universal_Executer<Exception_Task>(__task.PostProcess, Exception_Task.MSG_PostProcess_Task, __task.ID, this.Debug_Info);
						
						Trace_Helper.Log_Message("Fin du post processing de la tache {0} avec {1} blocs update {2} blocs modify", __task.ID, __task.Blocs_Update.Count, __task.Blocs_Modify.Count);
					}
					//Erreur maison
					catch (Exception_Base exb)
					{
						__task.InError = true;
						this.Errors.Add(Error_Type.Critique, exb);
						QXPDiagnostic.Log.LogError(Constantes.Error_Messages.ApplicationError, exb);
					}
					//erreur inconnu
					catch (Exception ex)
					{
						__task.InError = true;
						this.Errors.Add(Error_Type.Critique, Constantes.Error_Messages.TaskProcessing, __task.ID);
						QXPDiagnostic.Log.LogError(Constantes.Error_Messages.ApplicationError, ex);
					}
				}
			}
			
			//V�rification des taches
			foreach(Task_Base __task in _tasks.GetEnumerable<Task_Base>(true))
			{
				//Uniquement les taches en Todo est qui ne sont pas en erreur ou en mode d�grad�e
				if(!__task.InError && !__task.Mode_Degrade)
				{
					//Si cette tache ne poss�de pas de bloc � mettre � jour alors on log l'erreur
					if (__task.Blocs_Update.Count == 0 && __task.Blocs_Modify.Count == 0)
					{
						this.Errors.Add(Constantes.Error_Messages.TaskSansBloc, __task.Debug_Info);
					}
					//Sinon on ajoute cette tache dans "l'aggregateur" de tache
					else
					{
						_run_Task.Add(__task);
					}
				}
			}
		}

		/// <summary>
		/// Apr�s avoir �valu�e toutes les modifications � effectu�es sur le document original
		/// On �x�cute ces modifications
		/// </summary>
		protected virtual void	Process_Steps()
		{
			
			this.Caller.Process();
			
		}

		/// <summary>
		/// un/des rendus du document finale (QXP/PDF/DOC ...)
		/// </summary>
		protected virtual void	Render()
		{
			this.Caller.Render();

			//Mise � jour des r�sultats dans le run
			Run_Result __result = this.Result;

			if(QXPFrk.Validation.IsSet(this.Caller.Response.JPG_Data))
			{
				__result.Final_JPG = new Document(this.ID, string.Format("DF_{0}", this.ID), Constantes.Document_Format.JPEG, Document.FileDocumentFinalPrefix, this.Caller.Response.JPG_Data);
			}

			if(QXPFrk.Validation.IsSet(this.Caller.Response.PDF_Data))
			{
				__result.Final_PDF = new Document(this.ID, string.Format("DF_{0}", this.ID), Constantes.Document_Format.PDF, Document.FileDocumentFinalPrefix, this.Caller.Response.PDF_Data);
			}

			if(QXPFrk.Validation.IsSet(this.Caller.Response.QXP_Data))
			{
				__result.Final_QXP = new Document(this.ID, string.Format("DF_{0}", this.ID), Constantes.Document_Format.QXP, Document.FileDocumentFinalPrefix, this.Caller.Response.QXP_Data);
			}


            //Generation du word
            //Commented by GAD for test 15/05/2018
			//if (this.Properties.Generate_To_Word && QXPFrk.Validation.IsNotNull(__result.Final_PDF))
   //         {
   //             QXPFrk.Word.PdfToWordConverter.ActivateLicence
   //             (
   //                       SolidFrameworkSetting.Current.LicenseName, SolidFrameworkSetting.Current.LicenseEmail
   //                     , SolidFrameworkSetting.Current.LicenceOrganisation, SolidFrameworkSetting.Current.LicenceCode
   //              );

   //             MemoryStream	__wordFile	= QXPFrk.Word.PdfToWordConverter.Current.ConvertPdfToWord(__result.Final_PDF.Data);
   //             byte[]			__buffer	= new byte[__wordFile.Length];
   //             __wordFile.Read(__buffer, 0, (int)__wordFile.Length);
   //             __result.Final_Word = new Document(this.ID, string.Format("DF_{0}", this.ID), Constantes.Document_Format.DOC, Document.FileDocumentFinalPrefix, __buffer);
   //         }

			this.Save_Result();			
			
		}

        /// <summary>
        /// Permet de sauvegarder les fichiers g�n�r�s par Quark
        /// </summary>
        protected void			Save_Result()
        {
            if (QXPS_File_Manager.Save_QXPS_Response)
            {
				string __file = string.Empty;
				Byte[] __data = null;
				//aucun r�sultat � sauvegarde, on sort
				if(QXPFrk.Validation.IsNull(_result)) return;
                try
                {
                    
                    //Fichier JPG
					if(QXPFrk.Validation.IsNotNull(_result.Final_JPG))
					{
						__file = QXPS_File_Manager.GetSaveUsedRessourcePathAbsolute(_result.Final_JPG.FilePoolPath);
						__data =  _result.Final_JPG.Data;
						QXPIO.FileHelper.SaveFile(__file, __data, true);
					}

                    //Fichier QXP
					if(QXPFrk.Validation.IsNotNull(_result.Final_QXP))
					{
						__file = QXPS_File_Manager.GetSaveUsedRessourcePathAbsolute(_result.Final_QXP.FilePoolPath);
						__data =  _result.Final_QXP.Data;
						QXPIO.FileHelper.SaveFile(__file, __data, true);
					}
                    
					//Fichier WORD
					if(QXPFrk.Validation.IsNotNull(_result.Final_Word))
					{
						__file = QXPS_File_Manager.GetSaveUsedRessourcePathAbsolute(_result.Final_Word.FilePoolPath);
						__data =  _result.Final_Word.Data;
						QXPIO.FileHelper.SaveFile(__file, __data, true);
					}
                    
					//Fichier PDF
					if(QXPFrk.Validation.IsNotNull(_result.Final_PDF))
					{
						__file = QXPS_File_Manager.GetSaveUsedRessourcePathAbsolute(_result.Final_PDF.FilePoolPath);
						__data =  _result.Final_PDF.Data;
						QXPIO.FileHelper.SaveFile(__file, __data, true);
					}                    
                }
                catch (Exception ex)
                {
                    Exception_Helper.Raise_Exception(new Exception_Run(ex, Exception_Run.MSG_Unable_To_Save_File, __file), Error_Type.Critique);
                }

            }
        }

		/// <summary>
		/// V�rification des param�tres du document final.
		/// Evaluation des donn�es du run
		/// </summary>
		protected virtual void	Check()
		{
			
			//Nous n'arrivons ici que si nous ne sommes pas en mode d�grad� donc pas besoin de tester

			//v�rification s'il y � une tache dans le run en control_overflow
			if (this.Control_Overflow)
			{
				Trace_Helper.Log_Message("Le Run {0} est en controle de l'overflow", this.ID);
				
				//r�cup�ration des blocs en overflow dans le document en cours
				QXPFrk.BaseList<string>		__overflowBoxes			= this.Gabarit.XML.GetOverflowBoxes();
				QXPFrk.BaseList<Task_Base>	__tasks_to_reprocess	= new QXPFrk.BaseList<Task_Base>();
				
				Trace_Helper.Log_Message("Le document contient {0} boxe(s) en overflow", __overflowBoxes.Count);

				//Il faut des box en overflow
				if (__overflowBoxes.Count >= 0)
				{
					//V�rification des taches dynamiques avec control de l'overflow
					foreach (Task_Dynamique __dyn_task in this.Tasks.GetEnumerable<Task_Dynamique>(true))
					{
						//Elle est bien en control overflow et en todo
						if (__dyn_task.Control_Overflow)
						{
							Trace_Helper.Log_Message("La tache {0} est en controle de l'overflow", __dyn_task.ID);
							//Il faut vider les anciennes boites en overflow
							__dyn_task.Overflow_Boxes.Clear();
							__dyn_task.Overflow_Boxes.AddRange(__dyn_task.Box_Names.FindAll(delegate(string name)
							{
								return __overflowBoxes.Contains(name);
							}));

							//il y � des bloc en overflow il faut r�ex�cuter la tache et mettre la liste des bloc en overflow
							if (__dyn_task.Overflow_Boxes.Count > 0)
							{
								//Cette tache est � r�x�cuter
								__tasks_to_reprocess.Add(__dyn_task);
								Trace_Helper.Log_Message("La tache {0} contient {1} boxe(s) en overflow, elle sera donc relanc�e", __dyn_task.ID, __dyn_task.Overflow_Boxes.Count);
							}
							else
							{
								Trace_Helper.Log_Message("pas d'overflow pour la tache {0}", __dyn_task.ID);
							}
						}
					}

					//toutes les taches en Todo passe � false, sauf les taches dynamiques avec control overflow contenant au moins un bloc en overflow
					foreach (Task_Base __t in this.Tasks.Values)
					{
						//Si la tache n'est pas � re-�x�cuter ET quelle n'est pas en AllwaysReprocess
						if (!__tasks_to_reprocess.Contains(__t) && !__t.AllwaysReprocess)
						{
							__t.Todo = false;
						}
					}

					//S'il y � au moins une tache � ex�cuter
					if (__tasks_to_reprocess.Count > 0)
					{

						//S'il y � au moins une tache en todo alors on reprocess le run
						this.Launch_Process();

						this.Launch_Process_Steps();
					}
				}
			}


			//1 - V�rification des donn�es SQL
			//en sql c'est le plus facile toutes les donn�es sont � sauvegarder
			if ((this.Properties.Store_Type & Store_Data_Type.SQL) == Store_Data_Type.SQL)
			{
				//Cas des taches SQL Dynamiques
				foreach (Task_Dynamique __task in this.Tasks.GetEnumerable<Task_Dynamique>(false))
				{
					if(__task.Store_Data && __task.DataNamesValues.Count > 0)
					{
						this.SQLDataNamesValues.AddRange(__task.DataNamesValues);
					}
				}
				//Cas des taches SQL Statiques
				foreach (Task_SQL __task in this.Tasks.GetEnumerable<Task_SQL>(false))
				{
					if(__task.Store_Data && __task.DataNamesValues.Count > 0)
					{
						this.SQLDataNamesValues.AddRange(__task.DataNamesValues);
					}
				}
			}

			//2 - V�rification des donn�es du document finale
			// R�cup�ration de toutes les boites Text. Nous allons devoir exclures les boites non significative
			if ((this.Properties.Store_Type & Store_Data_Type.DOCUMENT) == Store_Data_Type.DOCUMENT)
			{
				DataNamesValues		__docNamesValues	= this.Gabarit.XML.GetNamesValuesBoxes();
				
				//on exclu de la liste toute les boites qui commence par "Box..." nom automatique donn�e par quark
				//on exclu �galement les boites qui sont issus d'un nommage automatique de notre application cest noms sont issu des fonctions de clonage
				//et sont toujours entre crochet exemple [Bloc_2]
				string __name;
				foreach (DataNameValue __nameValue in __docNamesValues)
				{
					__name = __nameValue.Name;
					//Si le nom de la boite commence par Box ou est situer entre crochets
					if(__name.StartsWith(BoxStart) || (__name.StartsWith(BracketOpen) && __name.EndsWith(BracketClose)))
					{
						continue;
					}
					//sinon c'est bon on garde
					else
					{
						this.DocDataNamesValues.Add(__nameValue);
					}
				} 
			}

		}

		/// <summary>
		/// Initialisation des param�tres du thread dans lequel va s'�x�cuter le run en cours. 
		/// n'execute rien si le run en cours est un child_run car toutes ces informations ont d�j� �t� d�fini par le run parent
		/// </summary>
		protected void			InitThreadContext()
		{
			this.InitThreadFileManager();
			this.InitThreadCulture();
			//on conserve le faite que le contexte � �t� d�fini cette methode ne devra plus donc �tre appel�
			_isSetThreadContext = true;
		}

		/// <summary>
		/// Initialisation des param�tres du <see cref="QXPS_File_Manager"/> du thread dans lequel va s'�x�cuter le run en cours
		/// </summary>
		protected virtual void	InitThreadFileManager()
		{
			QXPS_File_Manager.SetPoolPath(this.PoolPath);
		}

		/// <summary>
		/// Initialisation des param�tres de culture du thread dans lequel va s'�x�cuter le run en cours
		/// </summary>
		protected void			InitThreadCulture()
		{
            
			CultureInfo __currentUICulture = CultureInfo.CreateSpecificCulture("FR");
            __currentUICulture.NumberFormat.NumberDecimalSeparator	= _properties.DecimalSeparator;
            __currentUICulture.NumberFormat.NumberGroupSeparator	= _properties.GroupSeparator;
            System.Threading.Thread.CurrentThread.CurrentCulture	= __currentUICulture;
            System.Threading.Thread.CurrentThread.CurrentUICulture	= __currentUICulture;
	
		}

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Classe d'audit associ� au run
		/// </summary>
		public Audit				Audit{
			get{return _audit;}
		}

		/// <summary>
		/// Identifiant du run (g�n�ralement en base de donn�e)
		/// </summary>
		public int					ID{
			get{return _id;}
		}

		/// <summary>
		/// Permet d'identifier l'ex�cution du run de mani�re totalement unique
		/// </summary>
		public Guid					UID
		{
			get{return _uid;}
		}

		/// <summary>
		/// Repr�sente le d�but de la g�n�ration du run, prend la valeur datetime.now � la cr�ation de l'instance du run
		/// </summary>
		public DateTime				Debut_Generation
		{
			get{return _debutGeneration;}
		}

		/// <summary>
		/// Repr�sente la fin de la g�n�ration du run, prend la valeur datetime.now � la fin du run
		/// </summary>
		public DateTime				Fin_Generation
		{
			get{
				if (QXPFrk.Validation.IsNotSet(_finGeneration))
				{
					_finGeneration = DateTime.Now;
				}
				return _finGeneration;
			}
		}

		/// <summary>
		/// Repr�sente le r�pertoire de travail dans le pool de quark serveur. 
		/// Si cette propri�t� n'est pas overrider ont travail dans la racine du pool
		/// </summary>
		protected virtual	string	PoolPath
		{
			get{return string.Empty;}
		}

		/// <summary>
		/// Contient les propri�t�s globales du run 
		/// </summary>
		public Run_Properties		Properties
		{
			get{return _properties;}
		}

		/// <summary>
		/// List des param�tres en entr�e qui seront transmis aux taches SQL
		/// </summary>
		public InParams				InParams
		{
			get{return _inParams;}
		}

		/// <summary>
		/// Status en cours du run
		/// </summary>
		public Run_Status			Status
		{
			get{return _status;}
			set{_status = value;}
		}

		/// <summary>
		/// Liste des erreurs qui sont survenus durant l'�x�cution du run
		/// </summary>
		public Errors				Errors
		{
			get{return _errors;}
		}

		/// <summary>
		/// Liste des taches du run
		/// </summary>
		public Tasks				Tasks
		{
			get{return _tasks;}
		}

        /// <summary>
        /// Le gabarit source associ� � ce run (qui peut �tre soit un vrai gabarit soit un ancien document qxp g�n�r�).
        /// </summary>
		public Document				Gabarit
        {
            get { return _gabarit; }
            set { _gabarit = value; }
        }

		/// <summary>
		/// Repr�sente le gabarit qui contient tous les templates �l�ments n�cessaire aux taches dynamique du run
		/// </summary>
		public Document				Gabarit_Template
		{
			get{return _gabarit_Template;}
			set{_gabarit_Template = value;}
		}

		/// <summary>
		/// Repr�sente la liste des templates disponibles pour les taches dynamique
		/// </summary>
		public Templates			Templates
		{
			get{return _templates;}
		}

        /// <summary>
        /// Fournit une aggr�gation en �tapes de toutes les modifications � effectuer sur le document finale
        /// </summary>
		public Run_Task				Run_Task
        {
            get { return _run_Task; }
        }

		/// <summary>
		/// Contient les diff�rents rendus (qxp/pdf/doc) du document finale obtenu apr�s l'�x�cution du run
		/// si aucun rendu renvoi null
		/// </summary>
		public Run_Result			Result{
			get{return _result;}
			set{_result = value;}
		}
		
		/// <summary>
		/// 
		/// </summary>
		public string				Debug_Info
		{
			get
			{
				return string.Format(DebugInfoPattern, this.ID, this.Properties.ID_Suivi);
			}
		}

		/// <summary>
		/// D�fini si le run fonctionne en mode degrad�. 
		/// Lorsque le gabarit ou le gabrit template atteint une certaine taille le run s'�x�cute en mode d�grad� et n'execute aucune tache y compris les taches DID
		/// dans ce cas il tente d'effectue uniquement un rendu pdf du document et r�cup�re le qxp correspondant sans modification
		/// </summary>
		public bool					Mode_Degrade
		{
			get
			{
				return 
					(
					(QXPFrk.Validation.IsNotNull(this.Gabarit) && this.Gabarit.Mode_Degrade) 
					||
					(QXPFrk.Validation.IsNotNull(this.Gabarit_Template) && this.Gabarit_Template.Mode_Degrade)
					);
			}
		}

		/// <summary>
		/// Context de trace du run
		/// </summary>
		public Trace_Context		Trace_Context
		{
			get
			{
				if(QXPFrk.Validation.IsNull(_trace_Context))
				{
					_trace_Context = new Trace_Context(string.Format("R_{0}", this.ID), string.Empty, string.Format("{0}_R_{1}", Trace_Context.AppName, this.ID), false);				
				}
				return _trace_Context;
			}
		}

		/// <summary>
		/// Interface d'�x�cution des appel vers quark serveur
		/// </summary>
		public QXPS_Caller	Caller
		{
			get
			{
				if (QXPFrk.Validation.IsNull(_caller))
				{
					QXPS_Caller_Request						__caller_Request	= new QXPS_Caller_Request(this);
					QXPInteropQuarkServer.QXPS_Call_Info	__info				= new QXPInteropQuarkServer.QXPS_Call_Info();
					__info.DocumentName = this.Gabarit.FilePoolPath;
					
					_caller = new QXPS_Caller(__info, __caller_Request);
				}
				return _caller;
			}
		}

		/// <summary>
		/// D�fini si le run � au moins une tache en todo est en controle de l'overflow
		/// </summary>
		public bool			Control_Overflow
		{
			get
			{
				foreach (Task_Dynamique __dyn_Task in this.Tasks.GetEnumerable<Task_Dynamique>(true))
				{
					if(__dyn_Task.Control_Overflow) return true;
				}
				return false;
			}

		}

		/// <summary>
		/// R�pr�sente l'ensembles des donn�es g�n�r�e par les taches sql
		/// </summary>
		public DataNamesValues		SQLDataNamesValues
		{
			get
			{
				return _sqlDataNamesValues;
			}
		}

		/// <summary>
		/// R�pr�sente l'ensembles des donn�es contenu dans le document finale apr�s g�n�ration
		/// </summary>
		public DataNamesValues		DocDataNamesValues
		{
			get
			{
				return _docDataNamesValues;
			}
		}
		#endregion Propri�t�s
	}
}
