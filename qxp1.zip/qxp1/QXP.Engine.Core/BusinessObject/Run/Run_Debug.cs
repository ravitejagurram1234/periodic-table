using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un Run standard mais SANS End (afin de pouvoir relancer le m�me run plusieurs fois) utilis� par EOS.Quality
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/05/2010 09:34:03</date>    
	public class Run_Debug : Run
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Run_Debug
		/// </summary>
		/// <param name="id_run">identifiant du run</param>
		public Run_Debug(int id_run): base(id_run)
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Fin du run 
		/// </summary>
		protected override void End()
		{
			//rien � faire dans un run debug !
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
