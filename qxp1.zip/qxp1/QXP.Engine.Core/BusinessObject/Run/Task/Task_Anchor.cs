using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g?n?r? avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Classe de base des taches manipulant des ancres
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/05/2010 14:41:42</date>    
	public abstract class Task_Anchor: Task_Base
	{
		#region Membres
		DBloc_Info	_startAnchor	= null;
		DBloc_Info	_endAnchor		= null;
		#endregion Membres

		#region Constantes
		private const string StartAnchorPattern				= "{0}_START";
		private const string EndAnchorPattern				= "{0}_END";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr?e une instance de Task_Anchor
		/// </summary>
		/// <param name="id_tache">identifiant de la tache</param>
		/// <param name="run">run qui poss?de cette tache</param>
		public Task_Anchor(int id_tache, Run_Base run): base(id_tache, run)
		{
			//Cette tache ? toujours le sous type File_QXP_Data (puisque les template viennent d'un document QXP
			this.Sub_Task_Type = Sub_Task_Type.File_QXP_Data;
		}

		#endregion Constructeur

		#region M?thodes
		/// <summary>
		/// Ordonne l'?valuation des derni?res informations de SpreadID et de LayoutName en fonction du Sub_Task_Type
		/// </summary>
		public override void	Evaluate_Info()
		{
			string __destination_Ancre	= this.Get_Anchor_Name(true); 
			
			//this.Properties.SpreadID	= this.Run.Gabarit.XML.GetSpreadId(__destination_Ancre);
			this.Properties.PageNum		= this.Run.Gabarit.XML.GetPageNum(__destination_Ancre);
			this.Properties.LayoutName	= this.Run.Gabarit.XML.GetLayoutName(__destination_Ancre);
		}

		/// <summary>
		/// Permet de d?terminer le nom de l'ancre li? ? une tache
		/// </summary>
		/// <remarks>
		/// Les bloc ANCRES dans le document gabarit signale la position d'insertion des donn?es de la tache dynamique, il y ? 2 ancres par tache une au d?but et une ? la fin.
		/// - Le bloc de d?but, doit s'appeller "X_Start" ou X correspond au DestinationBlocName. le point de d?part est en bas ? droite.
		/// - Le Bloc de fin, doit s'appeller "X_End" ou X correspond au DestinationBlocName. le point de fin est en haut ? gauche.
		/// </remarks>
		/// <param name="start">est-ce l'ancre de d?but (true) oou de fin (false)</param>
		/// <returns></returns>
		public string			Get_Anchor_Name(bool start)
		{
			if(start)
			{
				return string.Format(StartAnchorPattern, this.DestinationBlocName);
			}
			else
			{
				return string.Format(EndAnchorPattern, this.DestinationBlocName);
			}
		}

		/// <summary>
		/// Permet d'obtenir certaines informations (position nom etc.) sur une ancre
		/// </summary>
		/// <remarks>Si l'ancre est introuvable cette methode l?ve une exception</remarks>
		/// <param name="start">est-ce l'ancre de d?but (true) ou de fin (false)</param>
		/// <returns>Les information du bloc demand?</returns>
		public DBloc_Info		Get_Anchor_Info(bool start)
		{
			string		__anchorName	= this.Get_Anchor_Name(start);
			DBloc_Info	__dbloc_Info	= base.Get_Bloc_Info(__anchorName);
			
			if(QXPFrk.Validation.IsNotSet(__dbloc_Info.UID))
			{
				throw new Exception_Task(Exception_Task.MSG_Ancre_Introuvable, __anchorName);
			}

			return __dbloc_Info;
			
		}

		public override void Reset_Process()
		{
			base.Reset_Process();
			//les ancres
			_startAnchor	= null;
			_endAnchor		= null;

		}
		#endregion M?thodes

		#region Propri?t?s
		/// <summary>
		/// Point de d?marrage de la zone dynamique du rapport (Ancre de d?but)
		/// </summary>
		public DBloc_Info	StartAnchor
		{
			get{
				if (QXPFrk.Validation.IsNull(_startAnchor))
				{
					_startAnchor = this.Get_Anchor_Info(true);
				}
				return _startAnchor;
			}
		}

		/// <summary>
		/// Point de fin de la zone dynamique du rapport (Ancre de fin)
		/// </summary>
		public DBloc_Info	EndAnchor
		{
			get
			{
				if (QXPFrk.Validation.IsNull(_endAnchor))
				{
					_endAnchor = this.Get_Anchor_Info(false);
				}
				return _endAnchor;
			}
		}
		
		/// <summary>
		/// Retourne le nombre de page d?j? pr?sent entre les 2 ancres
		/// </summary>
		public int			Nb_Ancienne_Page
		{
			get
			{
				return (this.EndAnchor.Page - this.StartAnchor.Page + 1);
			}
		}

		#endregion Propri?t?s
	}
}
