using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr?sente une tache Dynamique permettant d'ajouter des blocs/table/page ? un document quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:55:55</date>    
	public class Task_Dynamique : Task_Anchor
	{
		#region Membres
		string					_sql;
		D_Break_Rules			_page_Break_Rules		= D_Break_Rules.Default;
		D_Break_Rules			_column_Break_Rules		= D_Break_Rules.Default;
		bool					_control_overflow		= false;
		bool					_store_data				= false;
		bool					_new_Page_Table			= false;
		int						_nb_Column				= 1;
		decimal					_column_Space			= 0;									
		QXPFrk.BaseList<string>	_box_Names				= new QXPFrk.BaseList<string>();
		QXPFrk.BaseList<string>	_overflow_Boxes			= new QXPFrk.BaseList<string>();
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr?e une instance de Task_Dynamique
		/// </summary>
		/// <param name="id_tache">identifiant de la tache</param>
		/// <param name="run">run qui poss?de cette tache</param>
		public Task_Dynamique(int id_tache, Run_Base run): base(id_tache, run)
		{
		}

		#endregion Constructeur

		#region M?thodes
		/// <summary>
		/// pr?paration de la tache avant ?x?cution
		/// </summary>
		public override void			Prepare()
		{
			if(this.Todo)
			{
				//Ajout du gabarit template dans le pool quark
				QXPS_File_Manager.Addfile(this.Run.Gabarit_Template.FilePoolPath, this.Run.Gabarit_Template.Data);
			}
		}

		/// <summary>
		/// Ex?cution de la tache
		/// </summary>
		public override void			Process()
		{
			Business.Process_Dynamique.Process(this);
		}
		#endregion M?thodes

		/// <summary>
		/// Post ex?cution de la tache
		/// </summary>
		public override void			PostProcess()
		{
			//Rien ? faire pour l'instant
		}

		#region Propri?t?s
		
		/// <summary>
		/// Source SQL de la tache d?finissant les templates ? ajouter 
		/// </summary>
		public string SQL
		{
			get{return _sql;}
			set{_sql = value;}
		}

		/// <summary>
		/// D?fini les r?gles de rupture des lignes en pages en fonction du Row_Level
		/// </summary>
		public D_Break_Rules		Page_Break_Rules
		{
			get{return _page_Break_Rules;}
			set{_page_Break_Rules = value;}
		}

		/// <summary>
		/// D?fini les r?gles de rupture des lignes en colonne en fonction du Row_Level
		/// </summary>
		public D_Break_Rules		Column_Break_Rules
		{
			get{return _column_Break_Rules;}
			set{_column_Break_Rules = value;}
		}

		/// <summary>
		/// Permet de d?finir si les blocs g?n?r?s doivent controler le d?passement de leur contenu par rapport au container
		/// s'il y ? overflow d'au moins un bloc de la tache un nouvelle g?n?ration doit avoir lieu et doit utiliser le template de type overflow
		/// </summary>
		public bool						Control_Overflow
		{
			get
			{
				return _control_overflow;
			}
			set
			{
				_control_overflow = value;
			}
		}


		/// <summary>
		/// Permet de d?finir si cette tache doit sauvegarder les donn?es g?n?r?es par l'?x?cution de la tache
		/// </summary>
		public bool						Store_Data
		{
			get
			{
				return _store_data;
			}
			set
			{
				_store_data = value;
			}
		}

		/// <summary>
		/// Repr?sente la liste des noms des Boxes cr??es par la tache 
		/// Disponible uniquement apr?s le processing de la tache
		/// </summary>
		public QXPFrk.BaseList<string>	Box_Names
		{
			get
			{
				return _box_Names;
			}
		}

		/// <summary>
		/// Repr?sente la liste des boites en overflow dans cette tache
		/// Cette collection est vide au premier passage dans Process_Dynamique, elle sera rempli si Control_Overflow = true et qu'il y ? des boites en overflow dans l'?tape Check du Run_Base
		/// </summary>
		public QXPFrk.BaseList<string>	Overflow_Boxes
		{
			get
			{
				return _overflow_Boxes;
			}
		}

		/// <summary>
		/// Defini si chaque nouveau tableau (sauf le premier) d'une tache dynamique commence sur une nouvelle page
		/// </summary>
		public bool New_Page_Table
		{
			get
			{
				return _new_Page_Table;
			}
			set
			{
				_new_Page_Table = value;
			}
		}

		/// <summary>
		/// D?fini le nombre maximum de colonne par page quark
		/// </summary>
		public int Nb_Column
		{
			get
			{
				return _nb_Column;
			}
			set
			{
				//Seulement si le nombre de colonne est sup?rieur ? 0
				if(value > 0) _nb_Column = value;
			}
		}

		/// <summary>
		/// Espace de s?paration entre les colonnes lors Nb_Column > 1
		/// (Def 0, aucun espace)
		/// </summary>
		public decimal Column_Space
		{
			get
			{
				return _column_Space;
			}
			set
			{
				//Seulement si la largeur est sup?rieure ? 0
				if(value > 0) _column_Space = value;
			}
		}
		#endregion Propri?t?s
	}
}
