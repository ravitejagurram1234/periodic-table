
using QXPFrk = QXP.Framework;

using QXPSMSDK			= com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente la tache de mise � jour du DID dans un document quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/06/2010 15:06:53</date>    
	public class Task_DID : Task_System
	{
		#region Membres

		#endregion Membres

		#region Constantes
		const string DID_BlocName = "DID";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Task_DID
		/// </summary>
		/// <param name="id">identifiant de la tache</param>
		/// <param name="run">run qui � cr�� cette tache</param>
		public Task_DID(int id, Run_Base run): base(id, run)
		{
			//cette tache est toujours � �x�cuter
			this.Todo					= true;
			//toujours la m�me destination
			this.DestinationBlocName	= DID_BlocName;
			//Cette tache sera � �x�cuter � chaque processing des taches
			this.AllwaysReprocess		= true;

			//un petit commentaire pour les debug info au cas ou !!
			this.Commentaire			= "DID updater";
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// rien � faire tout sera ex�cuter dans le post processing c'est � dire quand toutes les autres taches auront �t� �x�cut�es
		/// </summary>
		public override void  Process()
		{
		}

		/// <summary>
		/// Post processing de la tache (tout est fait ici)
		/// </summary>
		public override void  PostProcess()
		{
			bool __modifier = false;

			//1 Choix du mode de mise � jour 

			//Si une autre tache � g�n�r� un bloc_base avec pagination (cr�ation/suppresion de page) on sous entend que cela peut influencer la position du DID dans le document
			//dans ce cas ont s'assure de repositionner le DID et de mettre � jour sa valeur
			//Sinon on met juste � jour la valeur du DID
			foreach(Task_Base __task in this.Run.Tasks.Values)
			{
				//si nous trouvons au moins un Bloc_Base en pagination on arrete et le DID sera mise � jour en Modifier
				//sinon il sera mise � jour en NameValue
				foreach (Bloc_Base __bloc in __task.Blocs_Modify.Values)
				{
					if (__bloc.Pagination)
					{
						__modifier = true;
						break;
					}
				}
			}

			string __didValue = Document_Identity_Helper.Get_New_Identity(this.Run);

			//Si c'est un modifier la mise � jour du DID s'effectuera par une structure XML
			if (__modifier)
			{
				//on force le bloc did � rester sur la page ou il �tait auparavant
				this.TBox_Action = Bloc_Action.MOVE;
				//la mise � jour de la position du did doit �tre effectuer au moment de la repagination du document finale
				this.TBox_Pagination = true;

				//Get DID info
				DBloc_Info __did_Info = this.Get_Bloc_Info(DID_BlocName);

				//on v�rifie que le bloc existe (si le UID est null il n'existe pas !! tout les bloc quark ont un UID m�me ceux qui ne sont pas nomm�).
				if (QXPFrk.Validation.IsSet(__did_Info.UID))
				{
					
					TBox __tBox = TElement_Helper.Get_TElement(Static_TElement_Name.MOVE_BLOC_VALUE, this.DestinationBlocName) as TBox;

					QXPSMSDK.Box __box = __tBox.SrcBox;

					//Pour d�placer un bloc il faut au minimum les informations suivantes + __box.geometry.page (qui est d�finit plus tard dans le QXPS_Modifier)
					__box.geometry.position.left	= __did_Info.Left.ToString();
					__box.geometry.position.top		= __did_Info.Top.ToString();
					__box.geometry.position.right	= __did_Info.Right.ToString();
					__box.geometry.position.bottom	= __did_Info.Bottom.ToString();
					__box.UID						= __did_Info.UID;
					
					__box.content.value = __didValue;

					this.TBox			= __tBox;

				}
				else
				{
					this.Run.Errors.Add(Constantes.Error_Messages.MissingDID);
					return;
				}
			}
			//Sinon la mise � jour est un valeur
			else
			{
				//on v�rifie que le bloc existe
				if (QXPFrk.Validation.IsSet(this.Run.Gabarit.XML.GetUID(DID_BlocName)))
				{
					this.Value = __didValue;
				}
				else
				{
					this.Run.Errors.Add(Constantes.Error_Messages.MissingDID);
					return;
				}
			}
			
			
			//2 Ex�cution
			//elle est ensuite ex�cut� comme une tache system standard 
			Business.Process_System.Process(this);
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
