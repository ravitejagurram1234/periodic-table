using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini une liste de couples compartiment/id_run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>27/05/2010 15:42:15</date>    
	public class List_Compartiment_Run: QXPFrk.BaseList<KeyValuePair<string, int>>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de List_Compartiment_Run
		/// </summary>
		public List_Compartiment_Run()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet d'ajouter un couple compartiment/id_run
		/// </summary>
		/// <param name="compartiment">code du compartiment</param>
		/// <param name="id_run">identifiant du run</param>
		public void Add(string compartiment, int id_run)
		{
			KeyValuePair<string, int> __keyValue = new KeyValuePair<string,int>(compartiment, id_run);
			this.Add(__keyValue);
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
