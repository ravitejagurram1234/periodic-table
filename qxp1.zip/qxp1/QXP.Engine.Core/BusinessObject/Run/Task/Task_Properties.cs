using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// repr�sente les propri�t�s d'une tache, g�n�ralement ces valeurs sont �valuer durant la pr�paration/l'�x�cution de la tache
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 16:43:54</date>    
	public class Task_Properties
	{
		#region Membres
        string              _layoutName;							// Nom de la mise en page
        //string              _spreadID;								// ID du spread
        int					_pageNum;								// ID de la page
        int                 _indexLigne = int.MinValue;				// Index de la ligne � supprimer
        int                 _nbLigne	= int.MinValue;				// Nb de lignes � supprimer
        Task_Action_Type    _taskAction = Task_Action_Type.NONE;	// Action mener 
        string              _tableName	= null;						// Nom du tableau
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Task_Properties
		/// </summary>
		public Task_Properties()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// 
		/// </summary>
        public string               LayoutName
        {
            get { return _layoutName; }
            set { _layoutName = value; }
        }

		///// <summary>
		///// 
		///// </summary>
		//public string               SpreadID
		//{
		//    get { return _spreadID; }
		//    set { _spreadID = value; }
		//}

		/// <summary>
		/// Identifiant de la page initiale de la tache
		/// </summary>
        public int					PageNum 
		{
            get { return _pageNum; }
            set { _pageNum = value; }
        }

		///// <summary>
		///// Num�ro de la page initiale de la tache
		///// Cette valeur �st �valuer en fonction de la propri�t� PageID
		///// </summary>
		//public int					PageNum
		//{
		//    get
		//    {
		//        //TODO:
		//        // tenir compte du faite que la page peut �tre sur le pastbord ( _pageID> 2000) deconstruct namespace
		//        // ou 22* ou encore 24** pour xmld namespace
		//        return QXPFrk.Conversion.ToInt(_pageID);
		//    }
		//}

		/// <summary>
		/// 
		/// </summary>
		public int                  NbLigne
        {
            get { return _nbLigne; }
            set { _nbLigne = value; }
        }
        
		/// <summary>
		/// 
		/// </summary>
		public int                  IndexLigne
        {
            get { return _indexLigne; }
            set { _indexLigne = value; }
        }
        
		/// <summary>
		/// 
		/// </summary>
		public Task_Action_Type		Task_Action
        {
            get { return _taskAction; }
            set { _taskAction = value; }
        }
		
		/// <summary>
		/// 
		/// </summary>
		public string               TableName
		{
		    get { return _tableName; }
		    set { _tableName = value; }
		}
		#endregion Propri�t�s
	}
}
