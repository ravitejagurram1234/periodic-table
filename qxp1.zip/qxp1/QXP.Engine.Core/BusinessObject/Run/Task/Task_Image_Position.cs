using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk	= QXP.Framework;
using QXPAudit	= QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini la position d'une image dans certaine type de tache
	/// </summary>
	/// <author>doufarm</author>
	/// <date>05/10/2010 12:08:20</date>    
	public class Task_Image_Position
	{
		#region Membres
		string _left;
		string _top;
		string _right;
		string _bottom;
		
		static readonly Task_Image_Position Default = new Task_Image_Position(DefImagePositionValues);
		#endregion Membres

		#region Constantes
        public const string DefImagePositionValues = "42,52;56,693;552,756;785,197";
		
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur


		/// <summary>
		/// Cr�e une instance de Task_Image_Position � partir du param�tres values (left;top;right;bottom)
		/// </summary>
		/// <param name="values">valeur de d�calage � appliquer (ex "100|130")</param>
		public Task_Image_Position(string values)
		{
            string[] __values         = QXPFrk.Conversion.ToString(values).Split(';');
			//seulement s'il y � 4 valeurs
			if (__values.Length == 4)
			{
				_left	= __values[0];
				_top	= __values[1];
				_right	= __values[2];
				_bottom = __values[3];
			}
			else
			{
				_left	= Default.Left;
				_top	= Default.Top;
				_right  = Default.Right;
				_bottom = Default.Bottom;
			}
        }

		#endregion Constructeur

		#region M�thodes
        
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Position Gauche
		/// </summary>
		public string Left
		{
			get
			{
				return _left;
			}
		}

		/// <summary>
		/// position Haute
		/// </summary>
		public string Top
		{
			get
			{
				return _top;
			}
		}

		/// <summary>
		/// position droite
		/// </summary>
		public string Right
		{
			get
			{
				return _right;
			}
		}

		/// <summary>
		/// Position basse
		/// </summary>
		public string Bottom
		{
			get
			{
				return _bottom;
			}
		}

		#endregion Propri�t�s
	}
}
