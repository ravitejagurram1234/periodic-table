using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini l'offset de d�calage d'une image dans certaine type de tache
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 15:20:33</date>    
	public class Task_Image_Offset
	{
		#region Membres

		string[]        _values;
        int             _values_max;
		
		#endregion Membres

		#region Constantes
        
		const       int _no_Values  = -1;
		
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur


		/// <summary>
		/// Cr�e une instance de Task_Image_Offset � partir du param�tres values
		/// </summary>
		/// <param name="values">valeur de d�calage � appliquer (ex "100|130")</param>
		public Task_Image_Offset(string values)
		{
            _values         = QXP.Framework.Conversion.ToString(values).Split('|');
            _values_max     = _values.Length - 1;
        }

		#endregion Constructeur

		#region M�thodes
        
		/// <summary>
		/// 
		/// </summary>
		/// <param name="image_Number"></param>
		/// <returns></returns>
		public string GetOffset(int image_Number)
		{
            if(_values_max == _no_Values)   return string.Empty;
            if(image_Number > _values_max)  return _values[_values_max];
            else                            return _values[image_Number];
        }
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
