using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une tache syst�me (c'est � dire une tache ajouter par le syst�me pendant la g�n�ration)
	/// </summary>
	/// <remarks>
    /// Repr�sente une tache system (id:0, type modification de valeur)
	/// utilis� par le syst�me pour effectu�e des modifications de document non pr�sent dans le run
	/// exemple la modification du champs DID dans le document quark utilise ce type de tache
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:55:55</date>    
	public class Task_System : Task_Base
	{
		#region Membres
		
		bool		_showZero				= false;
		int			_nbDecimal				= 0;
        bool		_decimal_significative	= true;
        Data_Type	_dataType				= Data_Type.Unspecified;	// Type de donn�e en sortie 
		object		_value					= null;
		TBox		_tBox					= null;
        bool		_pagination				= false;
		Bloc_Action	_action					= Bloc_Action.NONE;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Task_System
		/// </summary>
		/// <param name="id">identifiant de la tache</param>
		/// <param name="run">run qui � cr�� cette tache</param>
		public Task_System(int id, Run_Base run): base(id, run)
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// pr�paration de la tache avant �x�cution
		/// </summary>
		public override void Prepare()
		{
			//Rien � faire pour l'instant
		}

		/// <summary>
		/// Ex�cution de la tache
		/// </summary>
		public override void Process()
		{
			Business.Process_System.Process(this);	
		}
		#endregion M�thodes

		/// <summary>
		/// Post ex�cution de la tache
		/// </summary>
		public override void PostProcess()
		{
			//rien � faire dans ce type de tache pour l'instant
		}

		#region Propri�t�s
		
		/// <summary>
		/// Affiche les valeurs 0 (par defaut false)
		/// </summary>
		public bool ShowZero
		{
			get { return _showZero; }
			set { _showZero = value; }
		}

		/// <summary>
		/// Nombre de d�cimal
		/// </summary>
		public int NbDecimal
		{
			get { return _nbDecimal; }
			set { _nbDecimal = value; }
		}

		/// <summary>
		/// Determine si les nombres affichent les 0 non significatifs dans la partie d�cimale d'un nombre (def true)
		/// </summary>
		public bool Decimal_Significative
		{
			get { return _decimal_significative; }
			set { _decimal_significative = value; }
		}

		/// <summary>
		/// Type de donn�e en sortie (text, int etc.))
		/// </summary>
		public Data_Type Data_Type
		{
			get { return _dataType; }
			set { _dataType = value; }
		}

		/// <summary>
		/// Valeur de la tache system
		/// </summary>
		public object	Value
		{
			get { return _value; }
			set { _value = value; }
		}

		/// <summary>
		/// Template box de mise � jour de la tache system
		/// </summary>
		public TBox		TBox
		{
			get
			{
				return _tBox;
			}
			set
			{
				_tBox = value;
			}
		}

		/// <summary>
		/// L'action qui doit �tre effectu�e par la TBox
		/// </summary>
		public Bloc_Action TBox_Action
		{
			get
			{
				return _action;
			}
			set
			{
				_action = value;
			}
		}
		
		/// <summary>
		/// Permet de d�finir si le TBox doit �tre appliqu� au moment de l'�tape de pagination de la g�n�ration
		///  (def false)
		/// </summary>
		public bool			TBox_Pagination
		{
			get
			{
				return _pagination;
			}
			set
			{
				_pagination = value;
			}
		}
		
		#endregion Propri�t�s
	}
}
