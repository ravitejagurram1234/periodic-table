using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une Exception dans une tache, cette exception � pour objectif de supprimer 1 ou N lignes ou encore 1 table
	/// si les crit�res requis ne sont pas pr�sent
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 15:12:14</date>    
	public class Task_Exception
	{
		#region Membres
        string					_name;								// Nom du bloc
		string					_tablename;							// Nom du tableau
		int[]					_indexlignes;						// Index des lignes � supprimer dans le tableau si la condition n'est pas respect�e
        Task_Exception_Type		_type  = Task_Exception_Type.NONE;	// Type d'objet � g�rer (ligne ou tableau)
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Task_Exception
		/// </summary>
        /// <param name="tablename">Non de la table � supprim� ou contenant la/les ligne(s) � supprimer</param>
        /// <param name="name">Nom du bloc conditionnel � tester afin de d�terminer si la tache exception doit r�ellement supprimer quelque chose</param>
        /// <param name="indexlignes">Liste des indexes de lignes � supprimer si la condition n'est pas valide cest � dire que le bloc attendu n'a pas de valeur</param>
        /// <param name="type">Type de la tache exception (LIGNE, TABLE)</param>
		public Task_Exception(string tablename, string name, int[] indexlignes, Task_Exception_Type type) {
			_tablename	    = tablename;
            _name		    = name;
			_indexlignes	= indexlignes;
            _type		    = type;
        }

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Non de la table � supprim� ou contenant la/les ligne(s) � supprimer
		/// </summary>
        public string           TableName{
            get{return _tablename;}
        }
        
		/// <summary>
        /// Nom du bloc conditionnel � tester afin de d�terminer si la tache exception doit r�ellement supprimer quelque chose
        /// </summary>
		public string           Name{
            get{return _name;}
        }

		/// <summary>
		/// Type de la tache exception (LIGNE, TABLE)
		/// </summary>
        public Task_Exception_Type   Type{
            get{return _type;}
        }
		
		/// <summary>
		/// Liste des indexes de lignes � supprimer si la condition n'est pas valide cest � dire que le bloc attendu n'a pas de valeur
		/// </summary>
		public int[]            IndexLignes {
			get { return _indexlignes; }
			set { _indexlignes = value; }
		}
		#endregion Propri�t�s
	}
}
