using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr?sente une tache SQL
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:55:55</date>    
	public class Task_SQL : Task_Base
	{
		#region Membres
		string		_sql;
		bool		_showZero				= false;
		int			_nbDecimal				= 0;
        bool		_decimal_significative	= true;
        Data_Type	_dataType				= Data_Type.Unspecified;	// Type de donn?e en sortie 
		bool		_store_data				= false;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr?e une instance de Task_SQL
		/// </summary>
		/// <param name="id_tache">identifiant de la tache</param>
		/// <param name="run">run qui poss?de cette tache</param>
		public Task_SQL(int id_tache, Run_Base run): base(id_tache, run)
		{
		}

		#endregion Constructeur

		#region M?thodes
		/// <summary>
		/// pr?paration de la tache avant ?x?cution
		/// </summary>
		public override void Prepare()
		{
			this.Sub_Task_Type = Sub_Task_Type.SQL;
		}

		/// <summary>
		/// Cr?ation des blocs de mise ? jour
		/// </summary>
		public override void Process()
		{
			Business.Process_SQL.Process(this);
		}
		#endregion M?thodes

		/// <summary>
		/// Post ex?cution de la tache
		/// </summary>
		public override void PostProcess()
		{
			//rien ? faire dans ce type de tache pour l'instant
		}

		#region Propri?t?s
		
		/// <summary>
		/// chaine sql de la tache
		/// </summary>
		public string SQL
		{
			get { return _sql; }
			set { _sql = value; }
		}

		/// <summary>
		/// Affiche les valeurs 0 (par defaut false)
		/// </summary>
		public bool ShowZero
		{
			get { return _showZero; }
			set { _showZero = value; }
		}

		/// <summary>
		/// Nombre de d?cimal
		/// </summary>
		public int NbDecimal
		{
			get { return _nbDecimal; }
			set { _nbDecimal = value; }
		}

		/// <summary>
		/// Determine si les nombres affichent les 0 non significatifs dans la partie d?cimale d'un nombre (def true)
		/// </summary>
		public bool Decimal_Significative
		{
			get { return _decimal_significative; }
			set { _decimal_significative = value; }
		}

		/// <summary>
		/// Type de donn?e en sortie (text, int etc.))
		/// </summary>
		public Data_Type				Data_Type
		{
			get { return _dataType; }
			set { _dataType = value; }
		}

		/// <summary>
		/// Permet de d?finir si cette tache doit sauvegarder les donn?es g?n?r?es par l'?x?cution de la tache
		/// </summary>
		public bool						Store_Data
		{
			get
			{
				return _store_data;
			}
			set
			{
				_store_data = value;
			}
		}

		#endregion Propri?t?s
	}
}
