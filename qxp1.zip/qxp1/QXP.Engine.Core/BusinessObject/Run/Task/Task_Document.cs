
using QXPFrk	= QXP.Framework;
using QXPIO		= QXP.Framework.IO;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une tache li� sur des documents � ins�rer
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:55:55</date>    
	public class Task_Document : Task_Base
	{
		#region Membres
		string				_format_Document;
        bool				_rotation_image			= false;    //Appliquer une rotation � 90� du contenu d'un bloc image
        int					_id_sous_categorie;					// Sous categorie du document associ� � la tache
		bool				_conserver_Style		= false;	// false = copier le contenu sans la forme
        string				_offset_Values			= null;     //Repr�sente les valeurs de d�calages des images (uniquement n�cessaire dans le cas d'un type de tache PDF .. normalement)
		Task_Image_Offset	_image_Offset			= null;		//Aide � l'�valuation des d�calages en fonction des pages
		Document			_document				= null;
		string				_position_Values		= null;     //repr�sente les valeurs de positions d'une image
		Task_Image_Position _image_Position;					//aide � l'�valuation d'une position						
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Task_Document
		/// </summary>
		/// <param name="id_tache">identifiant de la tache</param>
		/// <param name="run">run qui poss�de cette tache</param>
		public Task_Document(int id_tache, Run_Base run): base(id_tache, run)
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// pr�paration de la tache avant �x�cution
		/// </summary>
		public override void Prepare()
		{
			switch(QXPFrk.Conversion.ToString(this.Format_Document).ToUpper())
			{
				case Constantes.Document_Format.PDF:
					this.Sub_Task_Type = Sub_Task_Type.File_PDF;
					this.ToLoad = true;
					break;
				case Constantes.Document_Format.JPG:
				case Constantes.Document_Format.JPEG:
				case Constantes.Document_Format.EPS:
				case Constantes.Document_Format.TIF:
				case Constantes.Document_Format.TIFF:
				case Constantes.Document_Format.GIF:
					this.Sub_Task_Type = Sub_Task_Type.File_IMG;
					this.ToLoad = true;
					break;
				case Constantes.Document_Format.RTF:
					this.Sub_Task_Type = Sub_Task_Type.File_RTF;
					break;
				case Constantes.Document_Format.DOC:
					this.Sub_Task_Type = Sub_Task_Type.File_DOC;
					break;
				case Constantes.Document_Format.XTG:
					this.Sub_Task_Type = Sub_Task_Type.File_XTG;
					break;
				case Constantes.Document_Format.QXP:
					this.Sub_Task_Type = Sub_Task_Type.File_QXP_Data;
					break;
				default:
					this.Sub_Task_Type = Sub_Task_Type.Unknown;
					break;
			}			

            // Il s'agit d'un document de r�f�rence � charger puis � uploader sur le serveur
			if ((this.ToLoad || this.Todo) && QXPFrk.Validation.IsSet(this.Id_Sous_Categorie, false)) 
            {
                Document __doc = QXPS_File_Manager.Get_Document(this.Id_Sous_Categorie, this.Run.Properties.ID_Fnd_Code, this.Run.Properties.ID_Unit_Code, this.Run.Properties.Societe, this.Run.Properties.ID_Langue, this.Run.Properties.Date_Echeance);
                this.Document = __doc;
                if (QXPFrk.Validation.IsNotNull(__doc))
                {
                    switch (this.Sub_Task_Type)
                    {
                        case Sub_Task_Type.File_PDF:
                            // 2007/11/27 : Fichier PDF, il faut d�couper le fichier par page
                            QXPIO.Split_Preference			__pref = new QXPIO.Split_Preference();
                            QXPFrk.BaseList<QXPIO.PDF_File>	__pdfs = new QXPFrk.BaseList<QXPIO.PDF_File>(QXPIO.PDF_Tools.Split_PDF(new QXPIO.PDF_File(__doc.FileName, __doc.Data), __pref));
                            __doc.PDFFiles = __pdfs;

                            byte[] __data;
                            foreach (QXPIO.PDF_File __file in __pdfs)
                            {
                                //R�cup�ration des bytes de chaque fichiers.
                                __data = new byte[__file.Stream.Length];
                                __file.Stream.Read(__data, 0, __data.Length);
                                
								//Les fichiers sont d�pos�s sur le serveur Quark
                                QXPS_File_Manager.Addfile(__doc.GetPDFFilePoolPath(__file), __data);
                            }
                            break;
                        case Sub_Task_Type.File_QXP_Data:
                        default:
                            QXPS_File_Manager.Addfile(__doc.FilePoolPath, __doc.Data);
                            break;

                    }
                }
                else
                {
                    this.Run.Errors.Add(Constantes.Error_Messages.Document_Null, this.Run.Properties.ID_Fnd_Code, this.Run.Properties.ID_Unit_Code, this.Run.Properties.Societe, this.Id_Sous_Categorie, this.Run.Properties.ID_Langue, this.Debug_Info);
                }
            }
		}

		/// <summary>
		/// Ex�cution de la tache
		/// </summary>
		public override void Process()
		{
			Business.Process_Document.Process(this);
		}

		/// <summary>
		/// Post ex�cution de la tache
		/// </summary>
		public override void PostProcess()
		{
			//rien � faire dans ce type de tache pour l'instant
		}

		/// <summary>
		/// Ordonne l'�valuation des derni�res informations de SpreadID et de LayoutName en fonction du Sub_Task_Type
		/// </summary>
		public override void Evaluate_Info()
		{
			string __blocName = string.Empty;
			switch (this.Sub_Task_Type)
			{
			    case Sub_Task_Type.File_PDF:
			        __blocName = string.Format("{0}_1", this.DestinationBlocName);
			        break;
			    case Sub_Task_Type.File_QXP_Data:
		            string[]	__blocNames = QXPFrk.Conversion.ToString(this.DestinationBlocName).Split('|');
		            string		__oneName	= string.Empty;
					if(__blocNames.Length > 0)
					{
						__blocName = __blocNames[0];
					}
					else
					{
						__blocName = (this.DestinationBlocName);
					}
			        break;
				//case Sub_Task_Type.File_IMG:
				//case Sub_Task_Type.File_XTG:
				//case Sub_Task_Type.File_RTF:
				//case Sub_Task_Type.File_DOC:
			    default:
			        if(QXPFrk.Validation.IsSet(this.DestinationBlocName))
					{
						__blocName = this.DestinationBlocName;
					}
			        break;
			}
			if(QXPFrk.Validation.IsSet(__blocName))
			{
				this.Properties.PageNum		= this.Run.Gabarit.XML.GetPageNum(__blocName);
				this.Properties.LayoutName	= this.Run.Gabarit.XML.GetLayoutName(__blocName);

				if(QXPFrk.Validation.IsNotSet(this.Properties.PageNum))
				{
					this.Run.Errors.Add(Constantes.Error_Messages.MissingBlocNameInDocument, __blocName, this.Run.Gabarit.FilePoolPath);
				}
			}
			else
			{
				this.Run.Errors.Add(Constantes.Error_Messages.MissingDestinationBlocNameInTask, __blocName, this.Debug_Info);
			}
		}
		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// Format du document
		/// </summary>
		public string Format_Document
		{
			get { return _format_Document; }
			set { _format_Document = value; }
		}

		/// <summary>
		/// Faut-il applique une rotation de 90 du contenu d'un bloc image (def false)
		/// </summary>
		public bool Rotation_Image
		{
			get { return _rotation_image; }
			set { _rotation_image = value; }
		}

        /// <summary>
        /// Id de la sous categorie du document
        /// </summary>
		public int Id_Sous_Categorie
        {
            get { return _id_sous_categorie; }
            set { _id_sous_categorie = value; }
        }

        /// <summary>
        /// Repr�sente les valeurs de d�calages des images (uniquement n�cessaire dans le cas d'un type de tache PDF .. normalement)
        /// </summary>
		public string Offset_Values
        {
            get { return _offset_Values; }
            set { _offset_Values = value; }
        }

        /// <summary>
        /// Repr�sente les positions des images (uniquement n�cessaire dans le cas d'un type de tache PDF .. normalement)
        /// </summary>
		public string Position_Values
        {
            get { return _position_Values; }
            set { _position_Values = value; }
        }

		/// <summary>
		/// copier le contenu d'un bloc sans les styles (def false)
		/// </summary>
		public bool Conserver_Style
		{
			get { return _conserver_Style; }
			set { _conserver_Style = value; }
		}

		/// <summary>
		///  Aide � l'�valuation des d�calages en fonction des pages
		/// </summary>
		public Task_Image_Offset	Image_Offset
		{
			get { return _image_Offset; }
			set { _image_Offset = value; }
		}

		/// <summary>
		///  Aide � l'�valuation des positions en fonction des pages
		/// </summary>
		public Task_Image_Position Image_Position
		{
			get { return _image_Position; }
			set { _image_Position = value; }
		}

		/// <summary>
		/// Objet Document contenant des informations et le flux du document associ�e � la tache
		/// </summary>
		public Document			Document 
		{
			get { return _document; }
			set { _document = value; }
		}

		/// <summary>
		/// si cette tache est bas�e sur un document QXP est que la taille est trop grande la tache passe en mode d�grad�e
		/// </summary>
		public override bool	Mode_Degrade
		{
			get
			{
				if (QXPFrk.Validation.IsNotNull(this.Document))
				{
					return this.Document.Mode_Degrade;
				}
				else
				{
					return false;
				}
			}
		}
		#endregion Propri�t�s
	}
}
