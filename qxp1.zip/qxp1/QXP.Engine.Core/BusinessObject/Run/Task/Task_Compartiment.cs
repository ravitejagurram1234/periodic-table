using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr?sente une tache permettant la g?n?ration en cascade de nouveau document quark ? ins?rer dans le document en cours
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:55:55</date>    
	public class Task_Compartiment : Task_Anchor
	{
		#region Membres
		QXPFrk.BaseList<Run_Base>	_child_Runs = new QXPFrk.BaseList<Run_Base>();
		int							_id_Gabarit_Fils;
		bool						_evaluate_Runs = true;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr?e une instance de Task_Compartiment
		/// </summary>
		/// <param name="id_tache">identifiant de la tache</param>
		/// <param name="run">run qui poss?de cette tache</param>
		public Task_Compartiment(int id_tache, Run_Base run): base(id_tache, run)
		{

		}

		#endregion Constructeur

		#region M?thodes
		/// <summary>
		/// pr?paration de la tache avant ?x?cution
		/// </summary>
		public override void Prepare()
		{
			//Rien ? faire pour l'instant
		}

		/// <summary>
		/// Ex?cution de la tache
		/// </summary>
		public override void Process()
		{
			Business.Process_Compartiment.Process(this);
		}

		/// <summary>
		/// Post ex?cution de la tache
		/// </summary>
		public override void PostProcess()
		{
			//Rien ? faire pour l'instant
		}
		#endregion M?thodes

		#region Propri?t?s
		/// <summary>
		/// Repr?sente la liste des runs fils g?n?r? ou r?cup?rer par la tache en cours
		/// </summary>
		public QXPFrk.BaseList<Run_Base> Child_Runs
		{
			get
			{
				return _child_Runs;
			}
		}

		/// <summary>
		/// R?p?sente l'identifiant du gabarit fils associ? ? la tache compartiment
		/// </summary>
		public int ID_Gabarit_Fils
		{
			get
			{
				return _id_Gabarit_Fils;
			}
			set
			{
				_id_Gabarit_Fils = value;
			}
		}

		/// <summary>
		/// Cette propri?t? un peu sp?cial peut prendre la valeur false dans des cas tr?s particuliers pour des TEST
		/// Elle permet de d?sactiv? l'?valuation des run lors du processing de la tache
		/// </summary>
		public bool Evaluate_Runs
		{
			get
			{
				return _evaluate_Runs;
			}
			set
			{
				_evaluate_Runs = value;
			}
		}
		#endregion Propri?t?s
	}
}
