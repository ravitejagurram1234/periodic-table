using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Liste de Task_Exceptions.
	/// </summary>
	/// <remarks>
	/// Une tache peut poss�der plusieurs Taches Exceptions
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>23/03/2010 15:18:48</date>    
	public class Task_Exceptions : Dictionary<string, Task_Exception>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Task_Exceptions
		/// </summary>
		public Task_Exceptions()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
