using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une tache QXP Previous (R�cup�ration des donn�es dans un ancien document quark certifi�)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:55:55</date>    
	public class Task_QXP_Previous : Task_Base
	{
		#region Membres
		
		bool		_conserver_Style		= false;	// false = copier le contenu sans la forme
        string		_previous_type_rapport	= null;		//D�finit le type de rapport certif� pr�c�dent � utilis� comme source de donn�e lors de taches de type 3 (BLOC QXP) 
		Document	_document				= null;
		string		_position_BlocName		= string.Empty; //Peremt de retrouver dans le cas d'un Table le layout et le spread destination
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Task_QXP_Previous
		/// </summary>
		/// <param name="id_tache">identifiant de la tache</param>
		/// <param name="run">run qui poss�de cette tache</param>
		public Task_QXP_Previous(int id_tache, Run_Base run): base(id_tache, run)
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// pr�paration de la tache avant �x�cution
		/// </summary>
		public override void Prepare()
		{
			this.Sub_Task_Type = Sub_Task_Type.File_QXP_Previous;

            //Il faut que la tache soit � ex�cut� et qu'il n'y � pas d�j� de document qxp previous associ� � la tache (ce dernier test permet de debug plus facilement ce type de tache sans entrainer d'effet de bord).
            if (this.Todo && QXPFrk.Validation.IsNull(this.Document))
                {
                    // recuperation du type de rapport certif� � rechercher
                    int __previousTypeRapport = this.Run.Properties.ID_Type_Rapport; // par defaut ( valeur "same" ou nulle ) : on prend le type du document en cours de generation
                    if (QXPFrk.Validation.IsSet(this.Previous_Type_Rapport))
                    {
                        if (this.Previous_Type_Rapport.Equals("any"))
                        {
                            //si "any" on prend n'importe quel type de rapport
                            __previousTypeRapport = 0;
                        }
                        else if (!this.Previous_Type_Rapport.Equals("same"))
                        {
                            //sinon on prend le type de rapport sp�cifi�
                            int __parsingResult = QXPFrk.Conversion.ToInt(this.Previous_Type_Rapport, 0);
                            if (QXPFrk.Validation.IsSet(__parsingResult, false))
                            {
                                __previousTypeRapport = __parsingResult;
                            }
                        }
                    }

                    Document __doc = QXPS_File_Manager.Get_Last_Qxp_Certifie(this.Run.Properties.ID_Suivi, __previousTypeRapport, this.Run.Properties.ID_Langue);

                    if (QXPFrk.Validation.IsNotNull(__doc))
                    {
                        this.Document = __doc;
                    }
                    else
                    {
                        Run.Errors.Add(Constantes.Error_Messages.Document_LastQxp_Null, this.Run.Properties.ID_Suivi, __previousTypeRapport, this.Debug_Info);
                        this.Todo = false;
                    }
                }
		}

		/// <summary>
		/// Ex�cution de la tache
		/// </summary>
		public override void Process()
		{
			Business.Process_QXP_Previous.Process(this);
		}

		/// <summary>
		/// Evlauation sp�cifique de la destination
		/// </summary>
		public override void Evaluate_Info()
		{
			//Dans le cas d'une tache r�cup�rant une TTable cette propri�t� doit �tre d�finit
			if (QXPFrk.Validation.IsSet(this.Position_BlocName))
			{
				this.Properties.PageNum		= this.Run.Gabarit.XML.GetPageNum(this.Position_BlocName);
				this.Properties.LayoutName	= this.Run.Gabarit.XML.GetLayoutName(this.Position_BlocName);
			
			}
			//Sinon on r�cup�re des TBox et la DestinationBlocName est correcte
			else if(QXPFrk.Validation.IsSet(this.DestinationBlocName))
			{
				//si il y � plusieurs �l�m�ents � copier dans la tache ont prend la position du premier �l�ment
				//ce qui sous entend qu'ils doivent �tre situ�e sur le m�me spread
				string[]	__destinations	= this.DestinationBlocName.Split('|');
				string		__destination	= __destinations[0];
				
				this.Properties.PageNum		= this.Run.Gabarit.XML.GetPageNum(__destination);
				this.Properties.LayoutName	= this.Run.Gabarit.XML.GetLayoutName(__destination);
			}
			
		}
		#endregion M�thodes

		/// <summary>
		/// Post ex�cution de la tache
		/// </summary>
		public override void PostProcess()
		{
			//rien � faire dans ce type de tache pour l'instant
		}
		#region Propri�t�s
		
		/// <summary>
		/// D�finit le type de rapport certif� pr�c�dent � utilis� comme source de donn�e lors de taches de type 3 (BLOC QXP) 
		/// </summary>
		public string	Previous_Type_Rapport
		{
			get { return _previous_type_rapport; }
			set { _previous_type_rapport = value; }
		}

		/// <summary>
		/// copier le contenu d'un bloc avec les styles (def false c'est � dire juste la valeur)
		/// </summary>
		public bool		Conserver_Style
		{
			get { return _conserver_Style; }
			set { _conserver_Style = value; }
		}

		/// <summary>
		/// Objet Document contenant des informations et le flux du document associ�e � la tache
		/// </summary>
		public Document Document 
		{
			get { return _document; }
			set { _document = value; }
		}

		/// <summary>
		/// Permet de d�finir la destination sp�cifique de la tache (utiliser lors de la r�cup�ration de TTable)
		/// </summary>
		public string Position_BlocName
		{
			get
			{
				return _position_BlocName;
			}
			set
			{
				_position_BlocName = value;
			}
		}

		/// <summary>
		/// si cette tache est bas�e sur un document QXP est que la taille est trop grande la tache passe en mode d�grad�e
		/// </summary>
		public override bool Mode_Degrade
		{
			get
			{
				if (QXPFrk.Validation.IsNotNull(this.Document))
				{
					return this.Document.Mode_Degrade;
				}
				else
				{
					return false;
				}
			}
		}

		#endregion Propri�t�s
	}
}
