using QXPFrk = QXP.Framework;


/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Cette classe contiendra les informations li�es � la generation/pr�paration d'un rapport (DReport)
	/// Cela �vitera d'avoir � transmettre trop de param�tres lors des appels successifs
	/// de plus ces param�tres pourront �tre mise � jour et r�cup�r�s par tout les appels
	/// </summary>
	/// <author>doufarm</author>
	/// <date>08/09/2010 14:35:43</date>    
	public class Prepare_Report_Parameters 
	{
		#region Membres
		#region Global
		/// <summary>
		/// hauteur disponible sur la page
		/// </summary>
		public decimal					Available_Height;

		/// <summary>
		/// largeur disponible sur la page
		/// </summary>
		public decimal					Available_Width;

		/// <summary>
		/// Page en cours
		/// </summary>
		public int						Page = 0;

		/// <summary>
		/// Colonne en cours
		/// </summary>
		public int						Column = 1;

		#endregion Global

		#region Table
		
		/// <summary>
		/// Hauteur courante du tableau (utiliser lors de l'application des page break afin de retourner) la nouvelle hauteur apr�s traitement des pages break rules
		/// </summary>
		public	decimal					Current_Table_Height;

		/// <summary>
		/// Largeur courante du tableau
		/// </summary>
		public	decimal					Current_Table_Width;
		
		#endregion Table

		#region Rows
		/// <summary>
		/// Repr�sente les lignes � supprimer, dans le cadre des rupture de pages
		/// </summary>
		public	QXPFrk.BaseList<DRow>	Rows_2_Remove	= new QXPFrk.BaseList<DRow>();

		#endregion Rows

		#region Absolutes Cells
		/// <summary>
		/// Repr�sente les cellules absolues � ajouter sur les nouvelles pages
		/// </summary>
		public	QXPFrk.BaseList<DCell>	Repeated_Cells	= new QXPFrk.BaseList<DCell>();

        /// <summary>
        /// Represent all cellules to add in the last page
        /// </summary>
        public QXPFrk.BaseList<DCell> Last_Cells = new QXPFrk.BaseList<DCell>();

		/// <summary>
		/// Tache associ�e
		/// </summary>
		public	Task_Dynamique			Task			= null;
		#endregion

		#region Page Breaks

		/// <summary>
		/// Nombre de lignes ajout�es, en plus de ce qui �tait pr�vue initialement (cette valeur est g�n�r�e en fonction du nombre de row_break ajout�s)
		/// </summary>
		public int						Nb_Rows_Added	= 0;

		#endregion Page Breaks

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Prepare_Report_Parameters
		/// </summary>
		/// <param name="task">La tache dynamique associ�e � ces param�tres.</param>
		public Prepare_Report_Parameters(Task_Dynamique task)
		{
			Task = task;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Remet les param�tres de pr�paration du rapport dans leurs �tats initiales
		/// (sauf les param�tres: Nb_Rows_Added, Page)
		/// </summary>
		public void Reset()
		{
			//on repart sur la colonne 1
			this.Column = 1;
			//on vide la liste des lignes en page break � supprimer
			this.Rows_2_Remove.Clear();
			//on vide la liste des Celllules absolues � r�p�ter sur les pages
			this.Repeated_Cells.Clear();
            // Clear the absolute cells in the last_page
            this.Last_Cells.Clear();
		}

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
