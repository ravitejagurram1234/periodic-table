using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr?sente la partie commune de tout les types de taches que peut contenir un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 16:31:32</date>    
	public abstract class Task_Base
	{
		#region Membres
		int				_id;
		string			_commentaire;
		bool			_todo;
		bool			_toload;
		bool			_allwaysReprocess		= false;
		string			_debugInfo;
		string			_sourceBlocName;
		string			_destinationBlocName;
		string			_nullString				= DefNullString;
		DMaster_Page	_master_Page;
		Run_Base		_run;
		Sub_Task_Type	_subTaskType;
		Task_Properties _properties				= new Task_Properties();
		Task_Exceptions	_exceptions				= new Task_Exceptions();
		Blocs			_blocs_Update			= new Blocs();
		Blocs			_blocs_Modify			= new Blocs();
		bool			_InError				= false;
		DataNamesValues	_dataNamesValues		= new DataNamesValues();

		#endregion Membres

		#region Constantes
		private const string DefNullString		= " ";
		private const string DebugInfoPattern	= "[{0} - {1}]";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr?e une instance de Task_Base
		/// </summary>
		/// <param name="id_tache"></param>
		public Task_Base(int id_tache, Run_Base run)
		{
			_id				= id_tache;
			_run			= run;
			_master_Page	= DMaster_Page.Default;
		}

		#endregion Constructeur

		#region M?thodes
		
		/// <summary>
		/// Pr?paration de la tache
		/// </summary>
		public abstract void Prepare();

		/// <summary>
		/// Ex?cution de la tache, c'est ? dire cr?ation des diff?rents type de Bloc_Base n?cessaire aux modifications n?cessaires
		/// </summary>
		public abstract void Process();

		/// <summary>
		/// Post Ex?cution de la tache, c'est ? dire cr?ation des diff?rents type de Bloc_Base n?cessaire aux modifications n?cessaires
		/// </summary>
		/// <remarks>
		/// Certaines taches (exemple DID_Task) ont besoin d'?tre s?rs que toutes les autres taches soient d?j? ?x?cuter afin de v?rifier certaines valeurs
		/// </remarks>
		public abstract void PostProcess();


		/// <summary>
		/// Mise ? jour des propri?t?s li?es ? la derni?re version du gabarit
		/// s'?x?cute entre chaque ?tape avant l'?x?cution r?elle
		/// </summary>
        public virtual void Evaluate_Info()
        {
	        //Par d?faut on essaye d'?valuer quelque chose
			//mais normalement cette m?thode doit ?tre overrider dans les diff?rents types de taches
			if(QXPFrk.Validation.IsSet(this.DestinationBlocName))
			{
				this.Properties.PageNum		= this.Run.Gabarit.XML.GetPageNum(this.DestinationBlocName);
				this.Properties.LayoutName	= this.Run.Gabarit.XML.GetLayoutName(this.DestinationBlocName);
			}
        }

		/// <summary>
		/// Permet de retourner la page du bloc evaluer par rapport au point de d?part de la tache et de la position relative du bloc
		/// </summary>
		/// <param name="condName">Bloc conditionnel de test</param>
		/// <param name="relative_Page">index relatif du spread</param>
		/// <returns>la valeur du spread ?valuer par rapport au spread de d?part de la tache la position relative du spread souhait?</returns>
		public int			Get_Page_ID_From_Relative(string condName, int relative_Page)
		{
			int __spreadNum;

			//s'il y ? un bloc conditionnel il faut se base sur lui pour ?valuer la page
			if (QXPFrk.Validation.IsSet(condName))
			{
				__spreadNum = this.Run.Gabarit.XML.GetPageNum(condName);
			}
			else
			{
				__spreadNum = this.Properties.PageNum;
			}
		
		    //on ajoute la notion de page relative par rapport au pageid d'origine
		    __spreadNum += relative_Page;

		    return __spreadNum;			
		}

		/// <summary>
		/// Permet de retourner le spread id du bloc evaluer par rapport sa page
		/// </summary>
		/// <param name="page_id">index relatif du spread</param>
		/// <param name="lag_spread">faut-il d?caler les spreads de une page</param>
		/// <returns>la valeur du spread ?valuer par rapport au spread de d?part de la tache la position relative du spread souhait?</returns>
		public int			Get_Spread_ID_From_Page_ID(int page_id, bool lag_spread)
		{
			int __value;

			//Si il y ? une page par spread alors ont renvoit l'identifiant de page comme celui du spread
			if (this.Run.Properties.Nb_Page_By_Spread == Run_Properties.PaginationSimple)
			{
				__value = page_id;
			}
			else
			{
				//Cas particulier pour la page 1 ou spread 1 est toujours 1
				if (page_id == 1)
				{
					__value = 1;
				}
				else
				{
					decimal __val;

					if (lag_spread)
					{
						__val = decimal.Divide(page_id, this.Run.Properties.Nb_Page_By_Spread) + 1;
					}
					else
					{
					    __val = decimal.Divide(page_id + 1 , this.Run.Properties.Nb_Page_By_Spread);
					}

					//Retourne la valeur enti?re arrondi sup?rieur de la division entre page_id et nombre de page par spread
					__value = (int)Math.Ceiling(__val);
				}
			}

			return __value;
		}

		/// <summary>
		/// Permet d'obtenir certaines informations (position nom etc.) sur une boite dans le document gabarit courant du run 
		/// </summary>
		/// <remarks>afin de v?rifier si le bloc existe il suffit de v?rifier que DBlocInfo.UID est d?fini</remarks>
		/// <param name="boxName">nom de la boite</param>
		/// <returns>les informations de la boite</returns>
		public DBloc_Info	Get_Bloc_Info(string boxName)
		{
			DBloc_Info	__dbloc_Info	= this.Run.Gabarit.XML.GetBlocInfo(boxName);
			return __dbloc_Info;
		}

		/// <summary>
		/// Permet de r?initialiser les param?tres ?valuer lors d'un pr?c?dent Processing de la tache
		/// Chaque type de tache doit faire son job de reset (il faudra affiner les param?tres ? r?initialiser). 
		/// Pensez ? appeler la base lorsque vous overrider
		/// </summary>
		public virtual void Reset_Process()
		{
			//tous les blocs cr??s
			this.Blocs_Update.Clear();
			this.Blocs_Modify.Clear();

			//toutes les donn?es cr?es
			this.DataNamesValues.Clear();
		}
		#endregion M?thodes

		#region Propri?t?s
		
		/// <summary>
		/// Identifiant de la tache
		/// </summary>
		public int ID
		{
			get{return _id;}
		}

		/// <summary>
		/// Commentaire de la tache
		/// </summary>
		public string Commentaire
		{
			get{return _commentaire;}
			set{_commentaire = value;}
		}
		
		/// <summary>
		/// Cette tache est-elle ? ex?cuter
		/// </summary>
		public bool Todo
		{
			get{return _todo;}
			set{_todo = value;}
		}

		/// <summary>
		/// Cette tache est-elle ? ex?cuter ? chaque re-processing de certaine tache.
		/// Apr?s Le check des overflows certaines tache sont ? re-?x?cuter, hors certaine tache (exemple DID) doivent se r?x?cuter ?galement m?me si il n'y ? pas d'overflow ? l'int?rieure
		/// </summary>
		public bool AllwaysReprocess
		{
			get{return _allwaysReprocess;}
			set{_allwaysReprocess = value;}
		}

		/// <summary>
		/// Cette tache doit-elle ?tre pr?par?e
		///<remarks>
		/// Certaine tache (ex insertion de pdf) m?me si elles ne doivent pas ?tre ex?cut?es doivent tout de m?me ?tre pr?par?es
		/// c'est ? dire que les fichiers pdf doivent ?tre envoy?e au serveur quark quand m?me.
		///</remarks>
		/// </summary>
		public bool ToLoad
		{
			get{return _toload;}
			set{_toload = value;}
		}

        /// <summary>
		/// D?finit les informations fonctionnelle de la tache ( ex: [23 - Inventaire] );
        /// </summary>
		public string Debug_Info
        {
            get
			{	
				if(QXPFrk.Validation.IsNotSet(_debugInfo))
				{
					_debugInfo = string.Format(DebugInfoPattern, this.ID, this.Commentaire);
				}
				return _debugInfo; 
			}
        }

		/// <summary>
		/// Repr?sente le nom du bloc qui contient les donn?es sources
		/// </summary>
		public string SourceBlocName
		{
			get{return _sourceBlocName;}
			set{_sourceBlocName = value;}
		}

		/// <summary>
		/// Repr?sente le nom du bloc qui devra recevoir les donn?es
		/// </summary>
		public string DestinationBlocName
		{
			get{return _destinationBlocName;}
			set{_destinationBlocName = value;}
		}

		/// <summary>
		/// Chaine utilis? par certaine lorsque la valeur du bloc est null ou vide
		/// </summary>
        public string NullString
        {
            get { return _nullString; }
            set { _nullString = value; }
        }

        /// <summary>
        /// Sous Type de tache
        /// </summary>
		public Sub_Task_Type Sub_Task_Type
        {
            get { return _subTaskType; }
            set { _subTaskType = value; }
        }

		/// <summary>
		/// Run associ? ? la tache
		/// </summary>
		public Run_Base			Run
		{
			get { return _run; }
		}

		/// <summary>
		/// contient les propri?t?s d'une taches, g?n?ralement des valeurs ?valu?es pendant la pr?paration/l'?x?cution de la tache
		/// </summary>
		public Task_Properties	Properties
		{
			get{return _properties;}
		}

		/// <summary>
		/// Repr?sente les blocs de modification de valeur cr??s ? partir de la tache
		/// Ces blocs de modification sont pris en charge par la commande NameValue de QuarkXpress Server
		/// </summary>
		public Blocs			Blocs_Update{
			get{return _blocs_Update;}
		}

		/// <summary>
		/// Repr?sente les blocs de modification de structure/valeur cr??s ? partir de la tache
		/// Ces blocs de modification sont pris en charge par la commande Modify de QuarkXpress Server
		/// </summary>
		public Blocs			Blocs_Modify{
			get{return _blocs_Modify;}
		}

		/// <summary>
		/// repr?sente les taches exceptions associ?es ? la tache
		/// </summary>
		/// <remarks>
		/// Cette propri?t? ? ?t? mise dans la classe de base car nous pourrions conditionner de nouveau type de tache plus tard 
		/// </remarks>
		public Task_Exceptions	Exceptions 
		{
			get { return _exceptions; }
		}

		/// <summary>
		/// Repr?sente le master page associ? ? la tache contient le/les identifiant des master page ? utiliser lors de la creation de page par cette tache
		/// </summary>
		public DMaster_Page		Master_Page{
			get{return _master_Page;}
			set{_master_Page = value;}
		}

		/// <summary>
		/// d?fini si les appels li?es ? cette tache sont des appels direct ? QuarkXPress Server (true) ou ? travers QuarkXpress manager (false) (Def = false)
		/// </summary>
		public virtual bool		Direct_Call
		{
			get{return false;}
		}

		/// <summary>
		/// Permet de savoir si la tache est tomb?e en erreur ? une des ?tapes de g?n?ration (exemple prepare / process etc..)
		/// </summary>
		public bool				InError
		{
			get{return _InError;}
			set{_InError = value;}
		}

		/// <summary>
		/// La tache est-elle en mode d?grad?e
		/// Lorsque la tache se base sur un document QXP trop volumineux les op?rations ? r?alis?es ne sont pas effectu?es
		/// Cette propri?t? doit ?tre overrider par certain type de tache exemple Task_Document, Task_QXP_Previous
		/// </summary>
		public virtual bool		Mode_Degrade
		{
			get
			{
				return false;
			}
		}

		/// <summary>
		/// Contient les donn?es g?n?r?es par la tache
		/// </summary>
		public DataNamesValues	DataNamesValues
		{
			get
			{
				return _dataNamesValues;
			}
		}
		#endregion Propri?t?s
	}
}
