using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une collection de tache d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 16:32:25</date>    
	public class Tasks: Dictionary<int, Task_Base>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Tasks
		/// </summary>
		public Tasks()
		{
		}

		#endregion Constructeur

		#region M�thodes
		
		/// <summary>
		/// Permet d'obtenir que les taches d'un certain type. 
		/// Cela facilitera les boucles par la suite
		/// </summary>
		/// <typeparam name="T">Le type de tache souhait�e. </typeparam>
		/// <param name="todo">Ne r�cup�re que les taches en todo si true, sinon r�cup�re toutes les taches.</param>
		/// <returns>la liste des taches du type demand�e</returns>
		public IEnumerable<T>	GetEnumerable<T>(bool todo) where T:Task_Base
		{
			foreach(Task_Base __task_Base in this.Values)
			{
				T __task = __task_Base as T;
				if (QXPFrk.Validation.IsNotNull(__task) && (!todo || __task.Todo))
				{
					yield return __task;
				}
			}
		}

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
