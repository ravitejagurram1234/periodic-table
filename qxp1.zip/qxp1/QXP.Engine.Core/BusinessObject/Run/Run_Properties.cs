using System;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPCore = QXP.Core;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les param?tres globaux d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:18:09</date>    
	public class Run_Properties
	{
		#region Membres
		string _datePattern			= string.Empty;
		string _dateTimePattern		= string.Empty;
		string _decimalSeparator	= string.Empty;
		string _groupSeparator		= string.Empty;

        string						_id_Fnd_Code;
        string						_id_Unit_Code;
        int							_id_Suivi;
		int							_id_Run;
        int							_id_Type_Rapport;
		Type_Rapport				_type_Rapport			= Type_Rapport.Unknown;
        string						_societe;
        DateTime					_date_Echeance;
        int							_id_Langue;
        string						_code_Langue;
        QXPCore.Gabarit_Source		_gabarit_Source			= QXPCore.Gabarit_Source.DocumentCourant;
		string						_run_type;
		bool						_integrer_N1			= true;	
		bool						_generate_To_Word		= false;
		int							_id_gabarit				= int.MinValue;
		int							_id_gabarit_template	= int.MinValue; 
		Task_Compartiment_Mode		_compartiment_mode		= Task_Compartiment_Mode.Unknown;
		Store_Data_Type				_store_Data_Type		= Store_Data_Type.NONE;
		int							_id_Suivi_Gabarit_Source = int.MinValue;

		int							_id_last_pdf			= int.MinValue;
		int							_id_last_qxp			= int.MinValue;
		int							_id_last_doc			= int.MinValue;
		
		//D?fini le nombre de page par spread
		int							_nb_Page_By_Spread		= PaginationSimple;

		#endregion Membres

		#region Constantes
		/// <summary>
		/// D?fini une pagination simple (1 page / spread) du document en cours de modification par le run
		/// </summary>
		public const int PaginationSimple = 1;
		/// <summary>
		/// D?fini une pagination double (2 pages / spread) du document en cours de modification par le run
		/// </summary>
		public const int PaginationDouble = 2;
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur
		/// <summary>
		/// Cr?e une instance de Run_Properties
		/// </summary>
		public Run_Properties()
		{
			try
			{
				_datePattern		= EngineCoreSetting.Current.Run_DatePattern;
				_dateTimePattern	= EngineCoreSetting.Current.Run_DateTimePattern;
				_decimalSeparator	= EngineCoreSetting.Current.Run_DecimalChar;
				_groupSeparator		= EngineCoreSetting.Current.Run_GroupSeparator;
			}
			catch(Exception ex)
			{
				QXPDiagnostic.Log.LogError("Invalid or missing EngineCoreSetting", ex);
			}
		}
		#endregion Constructeur

		#region M?thodes

		#endregion M?thodes

		#region Propri?t?s
		
		/// <summary>
		/// Repr?sente le pattern du format de date
		/// </summary>
		public string	DatePattern
		{
			get{return _datePattern;}
			set{_datePattern = value;}
		}

		/// <summary>
		/// Repr?sente le pattern du format de date et heure
		/// </summary>
		public string	DateTimePattern
		{
			get{return _dateTimePattern;}
			set{_dateTimePattern = value;}
		}

        /// <summary>
        /// repr?sente le s?parateur des d?cimals
        /// </summary>
		public string	DecimalSeparator
        {
            get { return _decimalSeparator; }
			set { _decimalSeparator = value; }
        }

		/// <summary>
		/// repr?sente le s?parateur des milliers
		/// </summary>
        public string	GroupSeparator
        {
            get { return _groupSeparator; }
			set { _groupSeparator = value; }
        }

        /// <summary>
        /// Identifiant du run
        /// </summary>
		public int		ID_Run
        {
            get { return _id_Run; }
			set { _id_Run = value; }
        }
        
        /// <summary>
        /// Identifiant du suivi du run
        /// </summary>
		public int		ID_Suivi
        {
            get { return _id_Suivi; }
            set { _id_Suivi = value; }
        }
        
        /// <summary>
        /// Identifiant du type de rapport
        /// </summary>
		public int		ID_Type_Rapport
        {
            get 
			{ 
				return _id_Type_Rapport; 
			}
            set
			{ 
				_id_Type_Rapport	= value; 
				_type_Rapport		= QXPFrk.Conversion.ToEnum<Type_Rapport>(value);
			}
        }

		/// <summary>
		/// type de rapport
		/// </summary>
		public Type_Rapport Type_Rapport
		{
			get
			{
				return _type_Rapport;
			}
		}
        /// <summary>
        /// Identifiant du fond ou de la structure associ? au run
        /// </summary>
		public string	ID_Fnd_Code
        {
            get { return _id_Fnd_Code; }
            set { _id_Fnd_Code = value; }
        }
        /// <summary>
        /// Identifiant de la part du fond associ? au run
        /// </summary>
		public string	ID_Unit_Code
        {
            get { return _id_Unit_Code; }
            set { _id_Unit_Code = value; }
        }
		/// <summary>
		/// Identifiant du gabarit du run
		/// </summary>
		public int		ID_Gabarit
		{
			get{return _id_gabarit;}
			set{_id_gabarit = value;}
		}
        
		/// <summary>
		/// Si d?fini alors le run est bas? sur un gabarit qui poss?de un gabarit template (c'est ? dire que des taches dynamiques pourrons ?tre ex?cut?es).
		/// </summary>
		public int		ID_Gabarit_Template
		{
			get{return _id_gabarit_template;}
			set{_id_gabarit_template = value;}
		}

        /// <summary>
        /// Soci?t? associ? au run
        /// </summary>
		public string	Societe
        {
            get { return _societe; }
            set { _societe = value; }
        }
        
        /// <summary>
        /// Date d'?ch?ance du run
        /// </summary>
		public DateTime Date_Echeance
        {
            get { return _date_Echeance; }
            set { _date_Echeance = value; }
        }
        
        /// <summary>
        /// identifiant de la langue du run
        /// </summary>
		public int		ID_Langue
        {
            get { return _id_Langue; }
            set { _id_Langue = value; }
        }
        
		/// <summary>
		/// Code de la langue associ? au run
		/// </summary>
        public string	Code_Langue
        {
            get { return _code_Langue; }
            set { _code_Langue = value; }
        }

		/// <summary>
		/// Type de run (manuel / planifier / upload)
		/// </summary>
		public string	RunType
        {
            get { return _run_type; }
            set { _run_type = value; }
        }

		/// <summary>
		/// Le document qxp source est-il un gabarit
		/// sinon (false) c'est un document pr?c?demment g?n?r? par un autre run
		/// </summary>
		public QXPCore.Gabarit_Source	Gabarit_Source
        {
            get { return _gabarit_Source; }
            set { _gabarit_Source = value; }
        }

		/// <summary>
		/// Identifiant du suivi ? utilis? pour r?cup?rer le gabarit du run en cours
		/// <remarks>Cette propri?t? n'est utilis? que si Gabarit_Source = Document_Suivi</remarks>
		/// </summary>
		public int				ID_Suivi_Gabarit_Source
		{
			get{return _id_Suivi_Gabarit_Source;}
			set{_id_Suivi_Gabarit_Source = value;}
		}
		/// <summary>
		/// Faut-il int?grer les donn?es N-1 dans le nouveau document
		/// </summary>
		public bool		Integrer_N1
        {
            get { return _integrer_N1; }
            set { _integrer_N1 = value; }
        }

		/// <summary>
		/// Faut-il effectuer un rendu Word du document QXP final
		/// </summary>
		public bool		Generate_To_Word
        {
            get { return _generate_To_Word; }
            set { _generate_To_Word = value; }
        }


		/// <summary>
		/// D?finit le mode d'?x?cution des taches de type compartiment
		/// </summary>
		public Task_Compartiment_Mode Compartiment_Mode
		{
			get
			{
				return _compartiment_mode;
			}
			set
			{
				_compartiment_mode = value;
			}
		}

		/// <summary>
		/// repr?sente l'identifiant du dernier fichier PDF g?n?r? pour ce run
		/// </summary>
		public int		ID_Last_PDF
		{
			get
			{
				return _id_last_pdf;
			}
			set
			{
				_id_last_pdf = value;
			}
		}

		/// <summary>
		/// repr?sente l'identifiant du dernier fichier QXP g?n?r? pour ce run
		/// </summary>
		public int		ID_Last_QXP
		{
			get
			{
				return _id_last_qxp;
			}
			set
			{
				_id_last_qxp = value;
			}
		}

		/// <summary>
		/// repr?sente l'identifiant du dernier fichier DOC g?n?r? pour ce run
		/// </summary>
		public int		ID_Last_DOC
		{
			get
			{
				return _id_last_doc;
			}
			set
			{
				_id_last_doc = value;
			}
		}

		/// <summary>
		/// D?fini le nombre de pages par spread du gabarit (par defaut 1)
		/// </summary>
		public int Nb_Page_By_Spread
		{
			get
			{
				return _nb_Page_By_Spread;
			}
			set
			{
				_nb_Page_By_Spread = value;
			}
		}

		/// <summary>
		/// D?fini le type de stockage des donn?es du run
		/// </summary>
		public Store_Data_Type Store_Type
		{
			get
			{
				return _store_Data_Type;
			}
			set
			{
				_store_Data_Type = value;
			}
		}

		#endregion Propri?t?s
	}
}
