using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini une collection d'�tapes de modification d'un document quark 
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:28:17</date>    
	public class Run_Task_Steps: QXPFrk.BaseList<Run_Task_Step>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Run_Task_Steps
		/// </summary>
		public Run_Task_Steps()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
