using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

using QXPFrk	= QXP.Framework;
using QXPIO		= QXP.Framework.IO;
using QXPAudit	= QXP.Audit;

using QXPInterop			= QXP.Interop;
using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un run de test quark SQL, Il regroupe toutes les param�tres n�cessaires � la g�n�ration/modification de document quark 
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/03/2010 11:18:09</date>    
	public class Run_Test_SQL: Run_Base
	{
		#region Membres
		

		#endregion Membres

		#region Constantes
		//const string Gabarit_Tete			= "Gabarit_Double_Tmp.qxp"; //2 page simple
	    const string Gabarit_Tete           = "Gabarit_Double_V7.qxp";
	    const string Document_Exemple = "Exemple_V7.qxp";
	    const string Document_Exemple2 = "Exemple2_V7.qxp";
        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur
        public Run_Test_SQL(): base(0)
		{

		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="id_run">identifiant du run</param>
		public Run_Test_SQL(int id_run): base(id_run)
		{

		}
		#endregion Constructeur

		#region M�thodes

		#region overrides
		/// <summary>
		/// D�but du run
		/// </summary>
		protected override void Start()
		{
			//Rien � faire ici pour l'instant
		}

		/// <summary>
		/// Chargement des propri�t�s du run
		/// </summary>
		protected override void LoadProperties()
		{
			//Seulement si ce n'est pas d�fini par l'ext�rieur
			if(QXPFrk.Validation.IsNotSet(this.Properties.ID_Fnd_Code)) this.Properties.ID_Fnd_Code			= "UCOMPA";
			
			//Seulement si ce n'est pas d�fini par l'ext�rieur
			if(QXPFrk.Validation.IsNotSet(this.Properties.ID_Suivi))	this.Properties.ID_Suivi			= 1;
			
			//� activer lorsque l'ont travail sur le gabarit Gabarit_Tete est "Gabarit_Double_Tmp"
			this.Properties.Nb_Page_By_Spread = Run_Properties.PaginationDouble;

			//this.Properties.Store_Type	= Store_Data_Type.SQL;
			//this.Properties.Store_Type	= Store_Data_Type.DOCUMENT;
			//this.Properties.Store_Type	= Store_Data_Type.ALL;

		}

		/// <summary>
		/// Chargment des templates
		/// </summary>
		protected override void LoadTemplates()
		{
			//rien � faire ici
		}

		/// <summary>
		/// Chargment et pr�paration du gabarit
		/// </summary>
		protected override void PrepareGabarit()
		{
            //on inform que le gabarit est d�j� dans le pool de quark
            string __gabarit_Tete = QXPS_File_Manager.GetPoolPath(Gabarit_Tete);
            QXPS_File_Manager.Addfile_Inform(__gabarit_Tete);
			//on le r�cup�re
            Document __doc_gabarit = QXPS_File_Manager.Get_FilePool(Gabarit_Tete);

			this.Gabarit = __doc_gabarit;
			
			//Test overflow
			//QXPFrk.BaseList<string> __overflow = this.Gabarit.XML.GetOverflowBoxes();
			//bool __isover1		= this.Gabarit.XML.CheckBoxOverflow("Cell2");
			//bool __isover2		= this.Gabarit.XML.CheckBoxOverflow("Cell1");

			//DataNamesValues __namesValues =  this.Gabarit.XML.GetNamesValuesBoxes();
			//string __resultat = QXPFrk.StringHelper.HookString(QXPFrk.StringHelper.Left(string.Format("{0:N}", Guid.NewGuid()), 28));
                
			//string  __pg;

			//__pg = this.Gabarit.XML.GetPageID("Ancre_1_START");
			//__pg = this.Gabarit.XML.GetPageID("Table1");
			//__pg = this.Gabarit.XML.GetPageID("Cellule2_2");
			
		}

		/// <summary>
		/// Chargement des InParams du run, les Inparams sont pass�s � certaines taches (exemple les taches SQL)
		/// </summary>
		protected override void LoadInParams()
		{
			

		}

		/// <summary>
		/// Chargement des taches associ�es � un run
		/// </summary>
		protected override void LoadTasks()
		{
			//Document_Identity __identity = Document_Identity_Helper.Get_Identity("LYX.qxp");
			
			////Tache GIF
			//Task_Document  __task_GIF = new Task_Document(1, this);
			//__task_GIF.Format_Document		= "GIF";
			//__task_GIF.DestinationBlocName	= "D_GIF";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_GIF.Document				= new Document("D_3", null, "GIF");
			//__task_GIF.Todo					= true;
			//this.Tasks.Add(__task_GIF.ID, __task_GIF);
			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//QXPS_File_Manager.Addfile_Inform(__task_GIF.Document.FilePoolPath);


			////Tache XTG (fragment quark)
			//Task_Document  __task_XTG = new Task_Document(2, this);
			//__task_XTG.Format_Document		= "XTG";
			//__task_XTG.DestinationBlocName	= "D_XTG";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_XTG.Document				= new Document("D_4", null, "XTG");
			//__task_XTG.Conserver_Style		= true;
			//__task_XTG.Todo					= true;
			//this.Tasks.Add(__task_XTG.ID, __task_XTG);
			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//QXPS_File_Manager.Addfile_Inform(__task_XTG.Document.FilePoolPath);

			
			////Tache RTF
			//Task_Document  __task_RTF = new Task_Document(3, this);
			//__task_RTF.Format_Document		= "RTF";
			//__task_RTF.DestinationBlocName	= "D_RTF";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_RTF.Document				= new Document("D_5", null, "RTF");
			//__task_RTF.Todo					= true;
			//this.Tasks.Add(__task_RTF.ID, __task_RTF);
			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//QXPS_File_Manager.Addfile_Inform(__task_RTF.Document.FilePoolPath);

			////Tache DOC
			//Task_Document  __task_DOC = new Task_Document(4, this);
			//__task_DOC.Format_Document		= "RTF";
			//__task_DOC.DestinationBlocName	= "D_DOC";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_DOC.Document				= new Document("D_6", null, "DOC");
			//__task_DOC.Todo					= true;
			//this.Tasks.Add(__task_DOC.ID, __task_DOC);
			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//QXPS_File_Manager.Addfile_Inform(__task_DOC.Document.FilePoolPath);


			////Tache PDF
			//Task_Document  __task_PDF = new Task_Document(5, this);
			//__task_PDF.Format_Document		= "PDF";
			//__task_PDF.DestinationBlocName	= "D_PDF";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_PDF.Document				= new Document("D_PDF", null, "PDF");
			
			////Dans le cas pdf conserver le style n'est pas significatif
			//__task_PDF.Conserver_Style		= true;
			//__task_PDF.Todo					= true;
			//__task_PDF.Offset_Values		= "-180|-130";
			//__task_PDF.Rotation_Image		= true;
			//this.Tasks.Add(__task_PDF.ID, __task_PDF);

			//QXPFrk.BaseList<QXPIO.PDF_File>	__pdfs = new QXPFrk.BaseList<QXPIO.PDF_File>();
			//__pdfs.Add(new QXPIO.PDF_File("D_1.pdf"));
			//__pdfs.Add(new QXPIO.PDF_File("D_2.pdf"));
			//__pdfs.Add(new QXPIO.PDF_File("D_3.pdf"));
			//__pdfs.Add(new QXPIO.PDF_File("D_4.pdf"));
			//__task_PDF.Document.PDFFiles = __pdfs;

			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//foreach(QXPIO.PDF_File __file in __pdfs)
			//{
			//    QXPS_File_Manager.Addfile_Inform(QXPS_File_Manager.GetPoolPath(__file.FileName));
			//}

			//Une tache sql 1
			Task_SQL __task_SQL1 = new Task_SQL(10, this);
			__task_SQL1.SQL					= SQLData1;
			__task_SQL1.Todo				= true;
			
			Task_Exception __exception = new Task_Exception("Table1", "Cellule3_1", new int[]{1,3}, Task_Exception_Type.LINE);
			__task_SQL1.Exceptions.Add(__exception.Name, __exception);
			
			this.Tasks.Add(__task_SQL1.ID, __task_SQL1);

			Task_DID	__did_Task = new Task_DID(0, this);
			this.Tasks.Add(__did_Task.ID, __did_Task);

		}

		/// <summary>
		/// Fin du run
		/// </summary>
		protected override void End()
		{
			//Rien � faire ici			
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="bloc_name">nom du bloc</param>
		/// <param name="bloc_value">valeur du bloc</param>
		/// <returns></returns>
		private string Get_Select(string bloc_name, string bloc_value)
		{
			return string.Format("Select '{0}' NOM_BLOC, '{1}' VALEUR_BLOC from dual ", bloc_name, bloc_value);
		}
		#endregion overrides

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Repr�sente le r�pertoire de travail dans le pool exemple "R_1687\"
		/// </summary>
		protected override	string	PoolPath
		{
			get{return "TU\\"; }
		}
        
        /// <summary>
        /// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 1
        /// </summary>
        private string	SQLData1
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();

				//Test aucune source de donn�e
				//__selects.Add("select 1 from dual where 1=0");

				__selects.Add(Get_Select("Table1_Cellule2_2", "toto"));
                __selects.Add(Get_Select("Table1_Cellule1_3", string.Empty));
			    __selects.Add(Get_Select("Table2_Cellule1_2", "titi"));

                return string.Join(" UNION ", __selects.ToArray());
			}
		}

        #endregion Propri�t�s
    }
}
