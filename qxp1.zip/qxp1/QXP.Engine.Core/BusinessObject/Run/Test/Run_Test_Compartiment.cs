using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un run de test quark sur les compartiments, Il regroupe toutes les param�tres n�cessaires � la g�n�ration/modification de document quark 
    /// * Pour faire fonctionner ces tests il faut decompresser TU.zip est le mettre dans le document pool du serveur Quark.
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/05/2010 14:57:14</date>    
	public class Run_Test_Compartiment: Run_Base
	{
		#region Membres

		#endregion Membres

		#region Constantes
		//const string Gabarit_Tete		= "Gabarit_Tete_Simple_V7.qxp";
		const string Gabarit_Tete		= "Gabarit_Tete_Double_V7.qxp";
		const string Gabarit_Fils1		= "Gabarit_Fils_1_V7.qxp";
		//const string Gabarit_Fils2		= "Gabarit_Fils_2_V7.qxp";
		const string Gabarit_Fils2		= "Gabarit_Fils_Vide.qxp";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Run_Test_Compartiment
		/// </summary>
		public Run_Test_Compartiment(): base(0)
		{
		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// D�but du run
		/// </summary>
		protected override void Start()
		{
			//Rien � faire ici pour l'instant
		}

		/// <summary>
		/// Fin du run
		/// </summary>
		protected override void End()
		{
			//Rien � faire ici pour l'instant
		}

		/// <summary>
		/// Chargement des propri�t�s du run
		/// </summary>
		protected override void LoadProperties()
		{
			//Permet de d�finir le mode de fonctionnement des taches compartiment
			this.Properties.Compartiment_Mode	= Task_Compartiment_Mode.Incorporate;
			this.Properties.ID_Fnd_Code			= "TCOMPA";

			//� activer lorsque l'ont travail sur le gabarit Gabarit_Tete est "Gabarit_Tete_Double"
			this.Properties.Nb_Page_By_Spread = Run_Properties.PaginationDouble;

		}

		/// <summary>
		/// Pr�paration du gabarit
		/// </summary>
		protected override void PrepareGabarit()
		{
			//on inform que le gabarit est d�j� dans le pool de quark
            string __gabarit_Tete = QXPS_File_Manager.GetPoolPath(Gabarit_Tete);
			QXPS_File_Manager.Addfile_Inform(__gabarit_Tete);
			//on le r�cup�re
            Document __doc_gabarit = QXPS_File_Manager.Get_FilePool(Gabarit_Tete);

			this.Gabarit = __doc_gabarit;				
		}

		/// <summary>
		/// Chargement des taches
		/// </summary>
		protected override void LoadTasks()
		{
			//Tache Compart
			Task_Compartiment  __task_Compartiment = new Task_Compartiment(1, this);
			__task_Compartiment.Todo				= true;
			__task_Compartiment.DestinationBlocName	= "Compart_T1";
			__task_Compartiment.ID_Gabarit_Fils		= 100;
			//Les runs sont �valuer ici donc ont met cette propri�t� � false (la tache n'essayera pas de les �valuer !!)
			__task_Compartiment.Evaluate_Runs		= false;
			
			this.Tasks.Add(__task_Compartiment.ID, __task_Compartiment);
			
            Run_Test_Dynamique __child_Run1 = new Run_Test_Dynamique(1);
            __child_Run1.Properties.ID_Fnd_Code = "FND1";
            __child_Run1.Properties.ID_Suivi	= 1; //pour les tests
            __task_Compartiment.Child_Runs.Add(__child_Run1);

            Run_Test_Dynamique __child_Run2 = new Run_Test_Dynamique(2);
            __child_Run2.Properties.ID_Fnd_Code = "FND2";
            __child_Run2.Properties.ID_Suivi	= 2; //pour les tests
            __task_Compartiment.Child_Runs.Add(__child_Run2);

            Run_Test_Unitaire_V7 __child_Run3 = new Run_Test_Unitaire_V7(3);
            __child_Run3.Properties.ID_Fnd_Code = "FND3";
            __child_Run3.Properties.ID_Suivi	= 3; //pour les tests
            __task_Compartiment.Child_Runs.Add(__child_Run3);
			
			//Run_Test_Previous __child_Run2 = new Run_Test_Previous();
			//__child_Run2.Previous_QXP			= Gabarit_Fils2;
			//__child_Run2.Properties.ID_Fnd_Code = "FND2";
			//__child_Run2.Properties.ID_Suivi	= 2; //pour les tests
			//__task_Compartiment.Child_Runs.Add(__child_Run2);

		}
		#endregion M�thodes

		#region Propri�t�s
        /// <summary>
        /// r�pertoire de travail dans le pool quark
        /// </summary>
        protected override string PoolPath
        {
            get
            {
                return "TU\\";
            }
        }

		#endregion Propri�t�s
	}
}
