using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPIO = QXP.Framework.IO;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/* 
     Les tests unitaires ont pour objectifs de tester la plus part des fonctions unitaires qui peuvent �tre effectu�es sur QXP.Engine.Core � l'aide d'un run et de tache.
     * (PrepareGabarit) Les fonctions de copie /r�cup�ration/suppression de fichier/analyse de fichier
     * (LoadTask) Test des taches sql avec exception
     * 
     * Pour faire fonctionner ces tests il faut decompresser TU.zip est le mettre dans le document pool du serveur Quark.
     */

    /// <summary>
	/// Il s'agit d'un version sp�ciale qui permet de tester des fonctions unitaires du g�n�rateur quark sur des documents V7 et non pas la g�n�ration d'un run 
	/// </summary>
	/// <author>doufarm</author>
	/// <date>31/08/2011 17:32:22</date>    
	public class Run_Test_Unitaire_V7 : Run_Base
	{
		#region Membres
		private string _previous_QXP = null;
		#endregion Membres

		#region Constantes
		const string Gabarit_Tete			= "Gabarit_Double_V7.qxp";
        //const string Gabarit_Tete           = "Gabarit_Simple_V7.qxp";
        
        const string Gabarit_Template_Name	= "Gabarit_Template_V7.qxp";


        const string Document_Exemple       = "Exemple_V7.qxp";
        const string Document_Exemple2      = "Exemple2_V7.qxp";
        #endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
        /// Cr�e une instance de Run_Test_Unitaire_V7 avec un id specifique
		/// </summary>
        public Run_Test_Unitaire_V7(int id): base(id)
		{

		}
		/// <summary>
        /// Cr�e une instance de Run_Test_Unitaire_V7
		/// </summary>
        public Run_Test_Unitaire_V7()
            : base(1)
		{

		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// D�but du run
		/// </summary>
		protected override void Start()
		{
			//Rien � faire ici pour l'instant
		}

		/// <summary>
		/// Chargement des propri�t�s du run
		/// </summary>
		protected override void LoadProperties()
		{
			//Seulement si ce n'est pas d�fini par l'ext�rieur
			if(QXPFrk.Validation.IsNotSet(this.Properties.ID_Fnd_Code)) this.Properties.ID_Fnd_Code			= "VCOMPA";
			
			//Seulement si ce n'est pas d�fini par l'ext�rieur
			if(QXPFrk.Validation.IsNotSet(this.Properties.ID_Suivi))	this.Properties.ID_Suivi			= 1;
			
			//� activer lorsque l'ont travail sur le gabarit Gabarit_Tete est "Gabarit_Double_Tmp"
			//this.Properties.Nb_Page_By_Spread = Run_Properties.PaginationSimple;
            this.Properties.Nb_Page_By_Spread = Run_Properties.PaginationDouble;

		}

        /// <summary>
		/// Chargement des templates
		/// </summary>
		protected override void LoadTemplates()
		{
			this.Gabarit_Template = QXPS_File_Manager.Get_FilePool(Gabarit_Template_Name);

			//j'informe que le gabarit_template est d�j� dans le pool la tache_dynamique n'essayera pas de le renvoyer
			QXPS_File_Manager.Addfile_Inform(this.Gabarit_Template.FilePoolPath);
			
			Template __tmp;
			//Ent�te
			__tmp = this.QuickAddTemplate("Head_1", "Titre tableau", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Left = 10;

			__tmp = this.QuickAddTemplate("HeadA_1", "Titre tableau", true, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Left = 10;

			__tmp = this.QuickAddTemplate("Head_Break_1", "Titre tableau", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Left = 10;
			//Ent�te � recopier sur les nouvelles colonne
			__tmp.Page_Break = true;
			//__tmp.Column_Break = true;

			__tmp = this.QuickAddTemplate("HeadA_Break_1", "Titre tableau", true, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Left = 10;
			//Ent�te � recopier sur les nouvelles colonne
			__tmp.Page_Break = true;
			__tmp.Column_Break = true;

			//Activation d'un overflow sur ces blocs
			//__tmp.Src_Name_Overflow = "Titre tableau large";

			__tmp = this.QuickAddTemplate("Head_Break_2", "Titre tableau", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Left = 10;
			//Ent�te � recopier sur les nouvelles pages
			//__tmp.Page_Break = true;
			//Ent�te � recopier sur les nouvelles colonne
			__tmp.Column_Break = true;
			//Activation d'un overflow sur ces blocs
			//__tmp.Src_Name_Overflow = "Titre tableau large";

			__tmp = this.QuickAddTemplate("Head_Break_3", "Titre tableau", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Left = 10;
			//Ent�te � recopier sur les nouvelles pages
			__tmp.Page_Break = true;
			//Ent�te � recopier sur les nouvelles colonne
			__tmp.Column_Break = true;
			//Activation d'un overflow sur ces blocs
			//__tmp.Src_Name_Overflow = "Titre tableau large";

			//__tmp = this.QuickAddTemplate("Head_Break_Composite", "T1", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			////__tmp.Left = 10;
			////Ent�te � recopier sur les nouvelles pages
			//__tmp.Page_Break = true;
			////Ent�te � recopier sur les nouvelles colonne
			//__tmp.Column_Break = true;
			////Activation d'un overflow sur ces blocs
			////__tmp.Src_Name_Overflow = "Titre tableau large";

			//ajout d'un template C_GHC_1_1 bas� sur l'�l�ment C_GHC_1

			//ajout d'un template Box Fond_1 bas� sur l'�l�ment Fond (on conserve les attributs original (largeur hauteur etc..)
			this.QuickAddTemplate("Fond_1", "Fond", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			//ajout d'un template Box Value_1 bas� sur l'�l�ment Fond (on conserve les attributs original (largeur hauteur etc..) mais on ajoute un padding top de 10
			this.QuickAddTemplate("Value_1", "Fond", false, 0, 10, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);

			//ajout d'un template Group Value_1 bas� sur l'�l�ment GH1 (on conserve les attributs original (largeur hauteur etc..)
			__tmp = this.QuickAddTemplate("Group_1", "GH1", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			//template � utiliser en cas d'overflow
			__tmp.Src_Name_Overflow = "Total1 L1-C1";

			//ajout d'un template Group G_1 bas� sur l'�l�ment GH1 (on conserve les attributs original (largeur hauteur etc..)
			__tmp = this.QuickAddTemplate("G_1", "G1", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Src_Name_Overflow = "G1W";

			this.QuickAddTemplate("G_2", "G2", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			this.QuickAddTemplate("G_3", "G3", true, 250, 250, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			this.QuickAddTemplate("G_4", "G4", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);

			//Box  simple italique relative
			__tmp = this.QuickAddTemplate("R_B_1", "B1", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			//__tmp.Src_Name_Overflow = "B1H";
			//__tmp.Src_Name_Overflow = "B1HW";
			//__tmp.Src_Name_Overflow = "B1W";
			//Box  simple italique relative

			//Box  simple italique absolute / repeat
			this.QuickAddTemplate("A_B_1", "B1", true, 50.20m, 10m, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.All);
			//Box  simple italique absolute / repeat other
			this.QuickAddTemplate("A_B_2", "B1", true, 250, 10, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Other_Page);
			//Box  simple italique absolute / sans repeat
			this.QuickAddTemplate("A_B_3", "B1", true, 250, 10, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.First_Page);

			//Box Simple relative Gras
			this.QuickAddTemplate("B6", "B6", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);

			//Group absolute / sans repeat
			__tmp = this.QuickAddTemplate("A_G_1", "G1", true, 40m, 40m, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.All);
			__tmp.Src_Name_Overflow = "G1W";
		
		}
        
        /// <summary>
		/// Chargment et pr�paration du gabarit
		/// </summary>
		protected override void PrepareGabarit()
		{
			

            Document __doc_gabarit = null;

            #region Ajout / analyse / suppression fichier
            ////test ajout de fichier
            string __exemple2 = QXPS_File_Manager.GetPoolPath(Document_Exemple2);
            QXPS_File_Manager.Addfile(__exemple2, System.IO.File.ReadAllBytes(QXPS_File_Manager.GetPoolPathAbsolute(Document_Exemple)));
                //string.Format("C:\\QuarkXPress Server Documents\\TU\\Exemple.qxp"));
            
            __doc_gabarit = QXPS_File_Manager.Get_FilePool(Document_Exemple2);
            //analyse du document qxp
            QXP_Project __project = __doc_gabarit.QXPProject;

            QXPS_File_Manager.Deletefile(__exemple2);

            #endregion #region Ajout / analyse / suppression fichier

            //on inform que le gabarit est d�j� dans le pool de quark
            string __gabarit_Tete = QXPS_File_Manager.GetPoolPath(Gabarit_Tete);
			QXPS_File_Manager.Addfile_Inform(__gabarit_Tete);
			
			//on le r�cup�re
            __doc_gabarit = QXPS_File_Manager.Get_FilePool(Gabarit_Tete);

			this.Gabarit = __doc_gabarit;

		}

		/// <summary>
		/// Chargement des InParams du run, les Inparams sont pass�s � certaines taches (exemple les taches SQL)
		/// </summary>
		protected override void LoadInParams()
		{
			

		}

		/// <summary>
		/// Chargement des taches associ�es � un run
		/// </summary>
		protected override void LoadTasks()
		{
            int __idTask = 0;

            Task_DID __did_Task = new Task_DID(__idTask++, this);
			this.Tasks.Add(__did_Task.ID, __did_Task);

            #region Mise � jour de valeur par Tache SQL avec des task_exceptions

            Task_SQL __sql_Task = new Task_SQL(__idTask++, this);

            __sql_Task.SQL				= SQLData;
            __sql_Task.Todo				= true;
			
            Task_Exception __exception = new Task_Exception("Table1", "Table1_Cellule1_3", new int[]{1,3}, Task_Exception_Type.LINE);
            __sql_Task.Exceptions.Add(__exception.Name, __exception);

            __exception = new Task_Exception("Table2", "Table2_Cellule1_2", new int[0], Task_Exception_Type.TABLE);
            __sql_Task.Exceptions.Add(__exception.Name, __exception);

            __exception = new Task_Exception("Table3", "Table3_Cellule3_1", new int[0], Task_Exception_Type.TABLE);
            __sql_Task.Exceptions.Add(__exception.Name, __exception);

            this.Tasks.Add(__sql_Task.ID, __sql_Task);

            #endregion

            #region Mise � jour document

            //Tache GIF
            Task_Document __task_GIF = new Task_Document(__idTask++, this);
            __task_GIF.Format_Document = "GIF";
            __task_GIF.DestinationBlocName = "D_GIF";
            //on se fiche du contenu le fichier est d�j� sur le serveur
            __task_GIF.Document = new Document("D_3", null, "GIF");
            __task_GIF.Todo = true;
            this.Tasks.Add(__task_GIF.ID, __task_GIF);
            //Permet d'informer que le document est d�j� pr�sent dans le pool
            QXPS_File_Manager.Addfile_Inform(__task_GIF.Document.FilePoolPath);


            //Tache XTG (fragment quark)
            Task_Document __task_XTG = new Task_Document(__idTask++, this);
            __task_XTG.Format_Document = "XTG";
            __task_XTG.DestinationBlocName = "D_XTG";
            //on se fiche du contenu le fichier est d�j� sur le serveur
            __task_XTG.Document = new Document("D_4", null, "XTG");
            __task_XTG.Conserver_Style = true;
            __task_XTG.Todo = true;
            this.Tasks.Add(__task_XTG.ID, __task_XTG);
            //Permet d'informer que le document est d�j� pr�sent dans le pool
            QXPS_File_Manager.Addfile_Inform(__task_XTG.Document.FilePoolPath);


            //Tache RTF
            Task_Document __task_RTF = new Task_Document(__idTask++, this);
            __task_RTF.Format_Document = "RTF";
            __task_RTF.DestinationBlocName = "D_RTF";
            //on se fiche du contenu le fichier est d�j� sur le serveur
            __task_RTF.Document = new Document("D_5", null, "RTF");
            __task_RTF.Todo = true;
            this.Tasks.Add(__task_RTF.ID, __task_RTF);
            //Permet d'informer que le document est d�j� pr�sent dans le pool
            QXPS_File_Manager.Addfile_Inform(__task_RTF.Document.FilePoolPath);

            //Tache DOC
            Task_Document __task_DOC = new Task_Document(__idTask++, this);
            __task_DOC.Format_Document = "RTF";
            __task_DOC.DestinationBlocName = "D_DOC";
            //on se fiche du contenu le fichier est d�j� sur le serveur
            __task_DOC.Document = new Document("D_6", null, "DOC");
            __task_DOC.Todo = true;
            this.Tasks.Add(__task_DOC.ID, __task_DOC);
            //Permet d'informer que le document est d�j� pr�sent dans le pool
            QXPS_File_Manager.Addfile_Inform(__task_DOC.Document.FilePoolPath);

            //Tache PDF D_PDF
            Task_Document __task_PDF_D = new Task_Document(__idTask++, this);
            __task_PDF_D.Position_Values = "57,3;49,5;777;522,8";
            __task_PDF_D.Format_Document = "PDF";
            __task_PDF_D.DestinationBlocName = "D_PDF";
            //on se fiche du contenu le fichier est d�j� sur le serveur
            __task_PDF_D.Document = new Document("D_1", null, "PDF");

            ////Dans le cas pdf conserver le style n'a pas d'effet
            //__task_PDF_D.Conserver_Style		= true;
            __task_PDF_D.Todo					= true;
            //__task_PDF_D.Offset_Values			= "-180|-130";
            __task_PDF_D.Offset_Values      = "-105|-19";
            //__task_PDF_D.Rotation_Image			= true; //Ca fonctionne
            this.Tasks.Add(__task_PDF_D.ID, __task_PDF_D);
            
            QXPFrk.BaseList<QXPIO.PDF_File>  __pdfs = new QXPFrk.BaseList<QXPIO.PDF_File>();
            __pdfs.Add(new QXPIO.PDF_File("D_1.pdf"));
            __pdfs.Add(new QXPIO.PDF_File("D_2.pdf"));
            __task_PDF_D.Document.PDFFiles = __pdfs;

            //Permet d'informer que le document est d�j� pr�sent dans le pool
            foreach (QXPIO.PDF_File __file in __pdfs)
            {
                QXPS_File_Manager.Addfile_Inform(QXPS_File_Manager.GetPoolPath(__file.FileName));
            }

            #endregion

            #region Mise � jour QXP previous
            //Optimisation Je charge le doc une fois pour toutes les tache_qxp_previous
            Document __doc_previous = QXPS_File_Manager.Get_FilePool(Document_Exemple);
            /* 1 ere qxp previous */
            Task_QXP_Previous __qxp_Previous_Task = new Task_QXP_Previous(__idTask++, this);
            __qxp_Previous_Task.Document = __doc_previous;
            __qxp_Previous_Task.Todo = true;

            __qxp_Previous_Task.SourceBlocName = "NOM_SGP";
            __qxp_Previous_Task.DestinationBlocName = "NOM_SGP";
            __qxp_Previous_Task.Conserver_Style = true;

            this.Tasks.Add(__qxp_Previous_Task.ID, __qxp_Previous_Task);

            /* 2 em qxp previous */
            __qxp_Previous_Task = new Task_QXP_Previous(__idTask++, this);
            __qxp_Previous_Task.Document = __doc_previous;
            __qxp_Previous_Task.Todo = true;

            __qxp_Previous_Task.SourceBlocName = "Mot du gerant";
            __qxp_Previous_Task.DestinationBlocName = "Mot du gerant";
            __qxp_Previous_Task.Conserver_Style = true;

            this.Tasks.Add(__qxp_Previous_Task.ID, __qxp_Previous_Task);

            /* 3 em qxp previous valeur n-1 */
            __qxp_Previous_Task = new Task_QXP_Previous(__idTask++, this);
            __qxp_Previous_Task.Document = __doc_previous;
            __qxp_Previous_Task.Todo = true;

            __qxp_Previous_Task.Conserver_Style = true;

            this.Tasks.Add(__qxp_Previous_Task.ID, __qxp_Previous_Task);

            #endregion

            #region Mise � jour tache dynamique
            Task_Dynamique __task_Dynamique1 = new Task_Dynamique(__idTask++, this);
			
            __task_Dynamique1.SQL					= SQLDataPerformance;
            __task_Dynamique1.Todo					= true;
            __task_Dynamique1.Nb_Column             = 1;
            __task_Dynamique1.DestinationBlocName	= "Ancre_1";

            __task_Dynamique1.Page_Break_Rules		= new D_Break_Rules("2:L1,1-0");
            //__task_Dynamique1.Column_Break_Rules	= new D_Break_Rules("10:10");//("36-38:35,36,37"); //("36-38:35-37");//new D_Break_Rules("30-40:10-40");

            this.Tasks.Add(__task_Dynamique1.ID, __task_Dynamique1);

            Task_Dynamique __task_Dynamique2 = new Task_Dynamique(__idTask++, this);
			
            __task_Dynamique2.Nb_Column				= 4;
            __task_Dynamique2.SQL					= SQLDataBreaks;
            __task_Dynamique2.Todo					= true;
            __task_Dynamique2.DestinationBlocName	= "Ancre_2";
            //__task_Dynamique2.Control_Overflow		= true;
            //__task_Dynamique2.Column_Space			= 50m;
            //__task_Dynamique2.New_Page_Table		    = false;

            __task_Dynamique2.Page_Break_Rules		= new D_Break_Rules("2:L1,0,1");
            //__task_Dynamique2.Column_Break_Rules	= new D_Break_Rules("1-4:0-3");

            this.Tasks.Add(__task_Dynamique2.ID, __task_Dynamique2);

            #endregion

            #region Mise � jour Tache compartiment
            //Utiliser Run_Test_Compartiment
            #endregion

        }

		/// <summary>
		/// Fin du run
		/// </summary>
		protected override void End()
		{
		
		}
		
        /// <summary>
		/// Ajout rapide d'un template dans la liste des templates
		/// </summary>
		/// <param name="name"></param>
		/// <param name="src_Name"></param>
		/// <param name="absolute"></param>
		/// <param name="left"></param>
		/// <param name="top"></param>
		/// <param name="width"></param>
		/// <param name="height"></param>
		/// <param name="repeatType"></param>
		/// <returns></returns>
		Template QuickAddTemplate(string name, string src_Name, bool absolute, decimal left, decimal top, decimal width, decimal height, Absolute_Repeat_Type repeatType)
		{
			Template __new_template = new Template();
			__new_template.Name				= name;
			__new_template.Src_Name			= src_Name;
			__new_template.Absolute			= absolute;
			__new_template.Left				= left;
			__new_template.Top				= top;
			__new_template.Width			= width;
			__new_template.Height			= height;
			__new_template.Absolute_Repeat		= repeatType;

			this.Templates.Add(__new_template.Name, __new_template);
			return __new_template;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="bloc_name">nom du bloc</param>
		/// <param name="bloc_value">valeur du bloc</param>
		/// <returns></returns>
		private string Get_Select(string bloc_name, string bloc_value)
		{
			return string.Format("Select '{0}' NOM_BLOC, '{1}' VALEUR_BLOC from dual ", bloc_name, bloc_value);
		}

		/// <summary>
		/// R�cup�ration d'un select
		/// </summary>
		/// <param name="id_section">identifiant de la section</param>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_Section(int id_section, int id_group, int id_ligne, string new_name, string data, string template)
		{
			string __select = string.Format("Select {0} id_section, {1} id_groupe, {2} id_ligne, {2} row_level, '{3}' NOM_BLOC, 'LVL:{2} {4}' VALEUR_BLOC, '{5}' Template from dual ", id_section, id_group, id_ligne, new_name, data, template);
			return __select;
		}

        /// <summary>
		/// R�cup�ration d'un select
		/// </summary>
		/// <param name="id_section">identifiant de la section</param>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="row_level">le row level</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_Section_RowLevel(int id_section, int id_group, int id_ligne, string new_name, string data, string template, int row_level)
		{
			string __select = string.Format("Select {0} id_section, {1} id_groupe, {2} id_ligne, {6} row_level, '{3}' NOM_BLOC, '{4}' VALEUR_BLOC, '{5}' Template from dual ", id_section, id_group, id_ligne, new_name, data, template, row_level);
			return __select;
		}

		/// <summary>
		/// R�cup�ration d'un select g�n�rant N lignes
		/// </summary>
		/// <param name="id_section">identifiant de la section</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="nb_Ligne">nombre de lignes souhait�es</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_Section_N(int id_section, int off_setGroup, string new_name, string data, string template, int nb_Ligne)
		{
			string __select = string.Format("Select {0} id_section, level + {5} id_groupe, level + {5} id_ligne, mod(level,5) row_level, '{1}_' || level NOM_BLOC, 'S{0}.G' || TO_CHAR(level + {5}) || '.L' || TO_CHAR(level + {5}) || '.LVL' || mod(level,5) || ' {2}' VALEUR_BLOC, '{3}' Template from dual connect by level <= {4}", id_section, new_name, data, template, nb_Ligne, off_setGroup);
			return __select;
		}

		/// <summary>
		/// R�cup�ration d'un select avec level
		/// </summary>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="row_level">le row level</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_RowLevel(int id_group, int id_ligne, string new_name, string data, string template, int row_level)
		{
			string __select = string.Format("Select {0} id_groupe, {1} id_ligne, '{2}' NOM_BLOC, '{5}L {3}' VALEUR_BLOC, '{4}' Template , {5} row_level from dual ", id_group, id_ligne, new_name, data, template, row_level);
			return __select;
		}

		#endregion M�thodes

		#region Propri�t�s
        protected override string PoolPath
        {
            get
            {
                return "TU\\";
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private string SQLData {
            get {
				
                QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();

				//Test aucune source de donn�e
				//__selects.Add("select 1 from dual where 1=0");

				__selects.Add(Get_Select("Table1_Cellule2_2", "new val cel2_2"));
				__selects.Add(Get_Select("Table1_Cellule1_3", string.Empty));

				__selects.Add(Get_Select("Table2_Cellule1_2", "new val cel1_2"));

				return string.Join(" UNION ALL ", __selects.ToArray());

            }
        }

        /// <summary>
		/// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 1
		/// </summary>
		private string SQLDataPerformance
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();
				int							__section			= 1;
				int							__group			    = 1;
				int							__nbpage			= 1;
				//int							__elementByPage		= 155; //pour les test V9
				//int							__elementByPage		= 100;
                int							__elementByPage		= 118;
                //int							__elements		    = 15000; // pas de notion de page
                int							__elements		    = 28; // pas de notion de page
				int							__loop				= __nbpage * __elementByPage;
				int                         __row_Level         = 10;//5;


				string						__template_Group	    = "R_B_1";
				string						__template_header		= "Head_1";
				string						__template_header_break	= "Head_Break_1";

				int							__L1				= 1;
				int							__L2				= 2;


                
                __selects.Add(Get_Select_Section_RowLevel(__section, __group, __group, "1_1Header_" + __group, string.Format("S{0}.G{1}.H{2}.LVL{3}", __section, __group, __L1, __row_Level), __template_header, __row_Level));
                __group++;
                __selects.Add(Get_Select_Section_RowLevel(__section, __group, __group, "1_2Header_" + __group, string.Format("S{0}.G{1}.H{2}.LVL{3} repeat", __section, __group, __L1, __row_Level), __template_header_break, __row_Level));
                __group++;
                
                //nouveau row level
                __row_Level++;

                __selects.Add(Get_Select_Section_RowLevel(__section, __group, __group, "2_1Header_" + __group, string.Format("S{0}.G{1}.H{2}.LVL{3}", __section, __group, __L2, __row_Level), __template_header, __row_Level));
                __group++;
                __selects.Add(Get_Select_Section_RowLevel(__section, __group, __group, "2_2Header_" + __group, string.Format("S{0}.G{1}.H{2}.LVL{3} repeat", __section, __group, __L2, __row_Level), __template_header_break, __row_Level));
                

                __selects.Add(Get_Select_Section_N(__section, __group, string.Format("3_1Group_{0}_", __section), "Val", __template_Group, __elements));

                ////nouvelle ent�te H2 
                ////nouveau row level
                ////__row_Level++;
                //__group += __elements+1;

                //__selects.Add(Get_Select_Section_RowLevel(__section, __group, __group, "4_1Header_" + __group, string.Format("S{0}.G{1}.H{2}.LVL{3}", __section, __group, __L2, __row_Level), __template_header, __row_Level));
                //__group++;
                //__selects.Add(Get_Select_Section_RowLevel(__section, __group, __group, "4_2Header_" + __group, string.Format("S{0}.G{1}.H{2}.LVL{3} repeat", __section, __group, __L2, __row_Level), __template_header_break, __row_Level));
                
                //__selects.Add(Get_Select_Section_N(__section, __group, string.Format("5_1Group_{0}_", __section), "Val", __template_Group, __elements));
                
                //__group += __elements+1;
                
				return string.Join(" UNION ALL ", __selects.ToArray());
			}
		}

        /// <summary>
		/// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 1
		/// </summary>
		private string SQLDataBreaks
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();
				int							__nbpage			= 1;
                int							__elementByPage		= 250;
				int							__loop				= __nbpage * __elementByPage;


				string						__template_Group	    = "R_B_1";
				string						__template_header		= "Head_1";
				string						__template_header_break	= "Head_Break_1";
				string						__template_G1_Abs_1		= "A_G_1";

                int							__L1				= 0;
				int							__L2				= 1;
				int							__L3				= 10;

				int                         __row_Level_Header = 10;
				int                         __row_Level_Abs = 20;
                int                         __row_Level;
                int                         __index = 1;
                int                         __j;


				int __section = 0;
				for(int __i = 0; __i < __loop; __i++)
				{
				    __j = (__i % __elementByPage);
                    __row_Level = (__j % 5);
				    switch(__j)
				    {
				        case 0:
				            __section++;
				            __selects.Add(Get_Select_Section_RowLevel(__section, __index, __index, "2_1Header_" + __index++, string.Format("H{0} L0", __L1), __template_header, __row_Level_Header));
				            __selects.Add(Get_Select_Section_RowLevel(__section, __index, __index, "2_2Header_" + __index++, string.Format("H{0} L0 Suite", __L1++), __template_header_break, __row_Level_Header));
				            
                            __selects.Add(Get_Select_Section_RowLevel(__section, __index, __index, "1_1G_1_Abs_1", "Value In Group G1 B1", __template_G1_Abs_1, __row_Level_Abs));
				            break;
				        case 1:
				        default:
				            __selects.Add(Get_Select_Section_RowLevel(__section, __index, __index, "2_1Group_" + __index++, string.Format("Val S:{0} G:{1} LVL:{2}" , __section, __index, __row_Level), __template_Group, __row_Level));
				            break;
				    }
				}

				return string.Join(" UNION ALL ", __selects.ToArray());
			}
		}

        /// <summary>
        /// Source de donn�es qui ne renvoit aucune ligne.
        /// </summary>
        private string SQLDataEmpty {
            get {
				
                QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();

				//Test aucune source de donn�e
				__selects.Add("select 1 from dual where 1=0");

				return string.Join(" UNION ALL ", __selects.ToArray());

            }
        }

		#endregion Propri�t�s
	}
}
