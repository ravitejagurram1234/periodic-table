using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

using QXPFrk	= QXP.Framework;
using QXPIO		= QXP.Framework.IO;
using QXPAudit	= QXP.Audit;

using QXPInterop			= QXP.Interop;
using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un run de test quark dynamique, Il regroupe toutes les param�tres n�cessaires � la g�n�ration/modification de document quark 
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/03/2010 11:18:09</date>    
	public class Run_Test_Dynamique: Run_Base
	{
		#region Membres
		

		#endregion Membres

		#region Constantes
		const string Gabarit_Template_Name	= "Gabarit_Template_V7.qxp"; //V7 sans titre tableau composite
		//const string Gabarit_Template_Name	= "Gabarit_Template_2.qxp"; // V9 avec titre tableau composite
		const string Gabarit_Tete			= "Gabarit_Simple_V7.qxp";
		//const string Gabarit_Tete			= "Gabarit_Double_Simple_Tmp.qxp";
		//const string Gabarit_Tete			= "Gabarit_Double_Tmp.qxp"; //2 page simple
		//double ancre_1 page 1 d�j� du contenu
		//const string Gabarit_Tete			= "Gabarit_Double_Simple_Tmp_1.qxp";
		//const string Gabarit_Tete			= "Gabarit_Double_Tmp_2.qxp"; //2 page simple - 1 ancre ANCRE_1 c'est tout
		//const string Gabarit_Tete			= "Gabarit_Double_Tmp_3.qxp"; //2 page simple - 2 zone de pdf rempli pdf et data
		//const string Gabarit_Tete			= "Gabarit_Double_Tmp_4.qxp"; //2 page simple - 1 ancre ANCRE_1 c'est tout document original gros
		//const string Gabarit_Tete			= "Gabarit_Double_Tmp_1.qxp"; //2 page simple - 2 zone de pdf vide
		//const string Gabarit_Tete			= "Gabarit_Tableau_Tmp.qxp"; //N pages simple / Ancre_1
		//const string Gabarit_Tete			= "Gabarit_Tableau_V9.qxp"; //N pages simple / Ancre_1
		//const string Gabarit_Tete			= "Gabarit_Tableau_Test.qxp"; //V7 - 1 pages simple / Ancre_1
		//const string Gabarit_Tete			= "Gabarit_Double_Simple_Tmp_5.qxp";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur
		public Run_Test_Dynamique(): base(0)
		{

		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="id_run">identifiant du run</param>
		public Run_Test_Dynamique(int id_run): base(id_run)
		{

		}
		#endregion Constructeur

		#region M�thodes

		#region overrides
		/// <summary>
		/// D�but du run
		/// </summary>
		protected override void Start()
		{
			//Rien � faire ici pour l'instant
		}

		/// <summary>
		/// Chargement des propri�t�s du run
		/// </summary>
		protected override void LoadProperties()
		{
			//Seulement si ce n'est pas d�fini par l'ext�rieur
			if(QXPFrk.Validation.IsNotSet(this.Properties.ID_Fnd_Code)) this.Properties.ID_Fnd_Code			= "UCOMPA";
			
			//Seulement si ce n'est pas d�fini par l'ext�rieur
			if(QXPFrk.Validation.IsNotSet(this.Properties.ID_Suivi))	this.Properties.ID_Suivi			= 1;
			
			//� activer lorsque l'ont travail sur le gabarit Gabarit_Tete est "Gabarit_Double_Tmp"
			//this.Properties.Nb_Page_By_Spread = Run_Properties.PaginationDouble;

			//this.Properties.Store_Type	= Store_Data_Type.SQL;
			//this.Properties.Store_Type	= Store_Data_Type.DOCUMENT;
			//this.Properties.Store_Type	= Store_Data_Type.ALL;

		}

		/// <summary>
		/// Chargment des templates
		/// </summary>
		protected override void LoadTemplates()
		{
			this.Gabarit_Template = QXPS_File_Manager.Get_FilePool(Gabarit_Template_Name);

			//j'informe que le gabarit_template est d�j� dans le pool la tache_dynamique n'essayera pas de le renvoyer
			QXPS_File_Manager.Addfile_Inform(this.Gabarit_Template.FilePoolPath);
			
			Template __tmp;
			//Ent�te
			__tmp = this.QuickAddTemplate("Head_1", "Titre tableau", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Left = 10;

			__tmp = this.QuickAddTemplate("Head_Break_1", "Titre tableau", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			//__tmp.Left = -10;
			//Ent�te � recopier sur les nouvelles pages
			//__tmp.Page_Break = true;
			//Ent�te � recopier sur les nouvelles colonne
			__tmp.Page_Break = true;
			__tmp.Column_Break = true;
			//Activation d'un overflow sur ces blocs
			//__tmp.Src_Name_Overflow = "Titre tableau large";

			__tmp = this.QuickAddTemplate("Head_Break_2", "Titre tableau", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Left = 10;
			//Ent�te � recopier sur les nouvelles pages
			//__tmp.Page_Break = true;
			//Ent�te � recopier sur les nouvelles colonne
			__tmp.Column_Break = true;
			//Activation d'un overflow sur ces blocs
			//__tmp.Src_Name_Overflow = "Titre tableau large";

			__tmp = this.QuickAddTemplate("Head_Break_3", "Titre tableau", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Left = 10;
			//Ent�te � recopier sur les nouvelles pages
			__tmp.Page_Break = true;
			//Ent�te � recopier sur les nouvelles colonne
			__tmp.Column_Break = true;
			//Activation d'un overflow sur ces blocs
			//__tmp.Src_Name_Overflow = "Titre tableau large";

			//__tmp = this.QuickAddTemplate("Head_Break_Composite", "T1", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			////__tmp.Left = 10;
			////Ent�te � recopier sur les nouvelles pages
			//__tmp.Page_Break = true;
			////Ent�te � recopier sur les nouvelles colonne
			//__tmp.Column_Break = true;
			////Activation d'un overflow sur ces blocs
			////__tmp.Src_Name_Overflow = "Titre tableau large";

			//ajout d'un template C_GHC_1_1 bas� sur l'�l�ment C_GHC_1

			//ajout d'un template Box Fond_1 bas� sur l'�l�ment Fond (on conserve les attributs original (largeur hauteur etc..)
			this.QuickAddTemplate("Fond_1", "Fond", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			//ajout d'un template Box Value_1 bas� sur l'�l�ment Fond (on conserve les attributs original (largeur hauteur etc..) mais on ajoute un padding top de 10
			this.QuickAddTemplate("Value_1", "Fond", false, 0, 10, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);

			//ajout d'un template Group Value_1 bas� sur l'�l�ment GH1 (on conserve les attributs original (largeur hauteur etc..)
			__tmp = this.QuickAddTemplate("Group_1", "GH1", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			//template � utiliser en cas d'overflow
			__tmp.Src_Name_Overflow = "Total1 L1-C1";

			//ajout d'un template Group G_1 bas� sur l'�l�ment GH1 (on conserve les attributs original (largeur hauteur etc..)
			__tmp = this.QuickAddTemplate("G_1", "G1", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			__tmp.Src_Name_Overflow = "G1W";

			this.QuickAddTemplate("G_2", "G2", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			this.QuickAddTemplate("G_3", "G3", true, 250, 250, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			this.QuickAddTemplate("G_4", "G4", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);

			//Box  simple italique relative
			__tmp = this.QuickAddTemplate("R_B_1", "B1", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);
			//__tmp.Src_Name_Overflow = "B1H";
			//__tmp.Src_Name_Overflow = "B1HW";
			//__tmp.Src_Name_Overflow = "B1W";
			//Box  simple italique relative

			//Box  simple italique absolute / repeat
			this.QuickAddTemplate("A_B_1", "B1", true, 50.20m, 10m, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.All);
			//Box  simple italique absolute / repeat other
			this.QuickAddTemplate("A_B_2", "B1", true, 250, 10, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Other_Page);
			//Box  simple italique absolute / sans repeat
			this.QuickAddTemplate("A_B_3", "B1", true, 250, 10, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.First_Page);

			//Box Simple relative Gras
			this.QuickAddTemplate("B6", "B6", false, 0, 0, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.Default);

			//Group absolute / sans repeat
			__tmp = this.QuickAddTemplate("A_G_1", "G1", true, 250.20m, 10.84m, decimal.MinValue, decimal.MinValue, Absolute_Repeat_Type.All);
			__tmp.Src_Name_Overflow = "G1W";
		
		}
		/// <summary>
		/// Chargment et pr�paration du gabarit
		/// </summary>
		protected override void PrepareGabarit()
		{
			
			//on inform que le gabarit est d�j� dans le pool de quark
            string __gabarit_Tete = QXPS_File_Manager.GetPoolPath(Gabarit_Tete);
			QXPS_File_Manager.Addfile_Inform(__gabarit_Tete);
			//on le r�cup�re
            Document __doc_gabarit = QXPS_File_Manager.Get_FilePool(Gabarit_Tete);

			this.Gabarit = __doc_gabarit;

			//QXP_Project __project = __doc_gabarit.QXPProject;
			
			//Task_DID	__did_Task = new Task_DID(0, this);
			//this.Tasks.Add(__did_Task.ID, __did_Task);

			//__project.Analyse(__did_Task, false);
			
			//Test overflow
			//QXPFrk.BaseList<string> __overflow = this.Gabarit.XML.GetOverflowBoxes();
			//bool __isover1		= this.Gabarit.XML.CheckBoxOverflow("Cell2");
			//bool __isover2		= this.Gabarit.XML.CheckBoxOverflow("Cell1");

			//DataNamesValues __namesValues =  this.Gabarit.XML.GetNamesValuesBoxes();
			//string __resultat = QXPFrk.StringHelper.HookString(QXPFrk.StringHelper.Left(string.Format("{0:N}", Guid.NewGuid()), 28));
                
			string  __pg;

			//__pg = this.Gabarit.XML.GetPageID("Ancre_1_START");
			//__pg = this.Gabarit.XML.GetPageID("Table1");
			//__pg = this.Gabarit.XML.GetPageID("Cellule2_2");
			
		}

		/// <summary>
		/// Chargement des InParams du run, les Inparams sont pass�s � certaines taches (exemple les taches SQL)
		/// </summary>
		protected override void LoadInParams()
		{
			

		}

		/// <summary>
		/// Chargement des taches associ�es � un run
		/// </summary>
		protected override void LoadTasks()
		{
			//Document_Identity __identity = Document_Identity_Helper.Get_Identity("LYX.qxp");

			QXPFrk.BaseList<QXPIO.PDF_File>	__pdfs = null;
			
			////Tache GIF
			//Task_Document  __task_GIF = new Task_Document(1, this);
			//__task_GIF.Format_Document		= "GIF";
			//__task_GIF.DestinationBlocName	= "D_GIF";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_GIF.Document				= new Document("D_3", null, "GIF");
			//__task_GIF.Todo					= true;
			//this.Tasks.Add(__task_GIF.ID, __task_GIF);
			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//QXPS_File_Manager.Addfile_Inform(__task_GIF.Document.FilePoolPath);


			////Tache XTG (fragment quark)
			//Task_Document  __task_XTG = new Task_Document(2, this);
			//__task_XTG.Format_Document		= "XTG";
			//__task_XTG.DestinationBlocName	= "D_XTG";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_XTG.Document				= new Document("D_4", null, "XTG");
			//__task_XTG.Conserver_Style		= true;
			//__task_XTG.Todo					= true;
			//this.Tasks.Add(__task_XTG.ID, __task_XTG);
			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//QXPS_File_Manager.Addfile_Inform(__task_XTG.Document.FilePoolPath);

			
			////Tache RTF
			//Task_Document  __task_RTF = new Task_Document(3, this);
			//__task_RTF.Format_Document		= "RTF";
			//__task_RTF.DestinationBlocName	= "D_RTF";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_RTF.Document				= new Document("D_5", null, "RTF");
			//__task_RTF.Todo					= true;
			//this.Tasks.Add(__task_RTF.ID, __task_RTF);
			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//QXPS_File_Manager.Addfile_Inform(__task_RTF.Document.FilePoolPath);

			////Tache DOC
			//Task_Document  __task_DOC = new Task_Document(4, this);
			//__task_DOC.Format_Document		= "RTF";
			//__task_DOC.DestinationBlocName	= "D_DOC";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_DOC.Document				= new Document("D_6", null, "DOC");
			//__task_DOC.Todo					= true;
			//this.Tasks.Add(__task_DOC.ID, __task_DOC);
			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//QXPS_File_Manager.Addfile_Inform(__task_DOC.Document.FilePoolPath);

			////Tache PDF E_PDF_1
			//Task_Document  __task_PDF_E = new Task_Document(5, this);
			//__task_PDF_E.Position_Values		= "57,3;49,5;777;522,8";
			//__task_PDF_E.Format_Document		= "PDF";
			//__task_PDF_E.DestinationBlocName	= "E_PDF";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_PDF_E.Document				= new Document("E_PDF", null, "PDF");
			
			////Dans le cas pdf conserver le style n'est pas significatif
			//__task_PDF_E.Conserver_Style		= true;
			//__task_PDF_E.Todo					= true;
			//__task_PDF_E.Offset_Values		= "-180|-130";
			//__task_PDF_E.Rotation_Image		= true;
			//this.Tasks.Add(__task_PDF_E.ID, __task_PDF_E);

			//__pdfs = new QXPFrk.BaseList<QXPIO.PDF_File>();
			//__pdfs.Add(new QXPIO.PDF_File("D_1.pdf"));
			//__pdfs.Add(new QXPIO.PDF_File("D_2.pdf"));
			////__pdfs.Add(new QXPIO.PDF_File("D_3.pdf"));
			////__pdfs.Add(new QXPIO.PDF_File("D_4.pdf"));
			//__task_PDF_E.Document.PDFFiles = __pdfs;

			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//foreach(QXPIO.PDF_File __file in __pdfs)
			//{
			//    QXPS_File_Manager.Addfile_Inform(QXPS_File_Manager.GetPoolPath(__file.FileName));
			//}

			////Tache PDF D_PDF
			//Task_Document  __task_PDF_D = new Task_Document(6, this);
			//__task_PDF_D.Position_Values		= "57,3;49,5;777;522,8";
			//__task_PDF_D.Format_Document		= "PDF";
			//__task_PDF_D.DestinationBlocName	= "D_PDF";
			////on se fiche du contenu le fichier est d�j� sur le serveur
			//__task_PDF_D.Document				= new Document("D_PDF", null, "PDF");
			
			////Dans le cas pdf conserver le style n'est pas significatif
			//__task_PDF_D.Conserver_Style		= true;
			//__task_PDF_D.Todo					= true;
			//__task_PDF_D.Offset_Values			= "-180|-130";
			//__task_PDF_D.Rotation_Image			= true;
			//this.Tasks.Add(__task_PDF_D.ID, __task_PDF_D);

			//__pdfs = new QXPFrk.BaseList<QXPIO.PDF_File>();
			//__pdfs.Add(new QXPIO.PDF_File("D_1.pdf"));
			//__pdfs.Add(new QXPIO.PDF_File("D_2.pdf"));
			////__pdfs.Add(new QXPIO.PDF_File("D_3.pdf"));
			////__pdfs.Add(new QXPIO.PDF_File("D_4.pdf"));
			//__task_PDF_D.Document.PDFFiles = __pdfs;

			////Permet d'informer que le document est d�j� pr�sent dans le pool
			//foreach(QXPIO.PDF_File __file in __pdfs)
			//{
			//    QXPS_File_Manager.Addfile_Inform(QXPS_File_Manager.GetPoolPath(__file.FileName));
			//}


			//Une tache dynamique 1
			Task_Dynamique __task_Dynamique1 = new Task_Dynamique(10, this);
			__task_Dynamique1.SQL					= SQLData1;
			__task_Dynamique1.Todo					= true;
			__task_Dynamique1.DestinationBlocName	= "Ancre_3";
			__task_Dynamique1.Control_Overflow		= true;
			//__task_Dynamique1.Store_Data			= true;
			//__task_Dynamique1.Page_Break_Rules		= new D_Break_Rules("10:10");//new D_Break_Rules("1-2:0-1|10:0-2|13:L1|14:L2|15:L3");
			
			this.Tasks.Add(__task_Dynamique1.ID, __task_Dynamique1);

            ////Une tache dynamique 2
            //Task_Dynamique __task_Dynamique2 = new Task_Dynamique(11, this);
            ////__task_Dynamique2.SQL					= SQLData6;//SQLData2;
            ////__task_Dynamique2.SQL					= SQLData2; //OK
            ////__task_Dynamique2.SQL					= SQLData3; //Select_N
			
			
            //__task_Dynamique2.Nb_Column				= 4;
            //__task_Dynamique2.SQL					= SQLDataPerformance; //Select_N
            //__task_Dynamique2.Todo					= true;
            //__task_Dynamique2.DestinationBlocName	= "Ancre_2";
            ////__task_Dynamique2.DestinationBlocName	= "Ancre_1";
            ////__task_Dynamique2.Control_Overflow		= true;
            ////__task_Dynamique2.Nb_Column				= 2;
            ////__task_Dynamique2.Column_Space			= 50m;
            ////__task_Dynamique2.New_Page_Table		= false;

            ////__task_Dynamique2.Page_Break_Rules		= new D_Break_Rules("1:0|10:0-1");//("36-38:35,36,37"); //("36-38:35-37");//new D_Break_Rules("30-40:10-40");
            ////__task_Dynamique2.Page_Break_Rules		= new D_Break_Rules("10:2,10");//("36-38:35,36,37"); //("36-38:35-37");//new D_Break_Rules("30-40:10-40");
			
            ////__task_Dynamique2.Page_Break_Rules		= new D_Break_Rules("10:10");//("36-38:35,36,37"); //("36-38:35-37");//new D_Break_Rules("30-40:10-40");
            //__task_Dynamique2.Column_Break_Rules	= new D_Break_Rules("10:10");//("36-38:35,36,37"); //("36-38:35-37");//new D_Break_Rules("30-40:10-40");

            //this.Tasks.Add(__task_Dynamique2.ID, __task_Dynamique2);
			
			//Une tache dynamique 3
			Task_Dynamique __task_Dynamique3 = new Task_Dynamique(12, this);
			__task_Dynamique3.SQL					= SQLData3;
			__task_Dynamique3.Todo					= true;
			__task_Dynamique3.DestinationBlocName	= "Ancre_1";
			//__task_Dynamique3.Control_Overflow		= true;

			this.Tasks.Add(__task_Dynamique3.ID, __task_Dynamique3);

			Task_DID	__did_Task = new Task_DID(0, this);
			this.Tasks.Add(__did_Task.ID, __did_Task);

			//Task_System	__did_Task = new Task_System(0, this);
			//__did_Task.Todo							= true;
			//__did_Task.DestinationBlocName			= Document_Identity.DID;
			//__did_Task.TBox_Action					= Bloc_Action.MOVE;
			//__did_Task.TBox_Pagination				= true;

			////Get DID info
			//DBloc_Info	__did_Info	=	__did_Task.Get_Bloc_Info(Document_Identity.DID);

			//if (QXPFrk.Validation.IsSet(__did_Info.UID))
			//{
			//    //__did_Task.TBox_Destination_SpreadID	= __did_Info.Page;
				
			//    TBox					__tBox	= TElement_Helper.Get_TElement(Static_TElement_Name.MOVE_BLOC_VALUE, __did_Task.DestinationBlocName) as TBox;
				
			//    QXPInterop.QXPSMSDK.Box	__box	= __tBox.SrcBox;
				
			//    //Pour d�placer un bloc il faut au minimum les informations suivantes + __box.geometry.page (qui est d�finit plus tard dans le QXPS_Modifier)
			//    __box.geometry.position.left	= __did_Info.Left.ToString();//"900";//
			//    __box.geometry.position.top		= __did_Info.Top.ToString();
			//    __box.geometry.position.right	= __did_Info.Right.ToString();//"1300";//
			//    __box.geometry.position.bottom	= __did_Info.Bottom.ToString();
			//    //__box.geometry.page				= __did_Info.Page.ToString();
			//    __box.UID						= __did_Info.UID;

			//    __box.content.value				= "tutu";

			//    __did_Task.TBox					= __tBox;

			//    this.Tasks.Add(0, __did_Task);

			//}

			//else
			//{
			//    //la boite DID n'existe pas dans le gabarit
			//}

			////Test structure document 
			//string __file = "R_59754\\D_2997.qxp";
			////on inform que le gabarit est d�j� dans le pool de quark
			//QXPS_File_Manager.Addfile_Inform(__file);
			////on le r�cup�re
			//Document __doc= QXPS_File_Manager.Get_File(__file);

			//__doc.QXPProject.Analyse(__did_Task);			


		}

		/// <summary>
		/// R�cup�ration d'un select (avec un row_level � 99).
		/// </summary>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select(int id_group, int id_ligne, string new_name, string data, string template)
		{
			return Get_Select(id_group, id_ligne, new_name, data, template, 99);
		}
		
		/// <summary>
		/// R�cup�ration d'un select (avec un row_level � 99).
		/// </summary>
		/// <param name="id_table">id de la table</param>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_Table(int id_table, int id_group, int id_ligne, string new_name, string data, string template)
		{
			return Get_Select_Table(id_table, id_group, id_ligne, new_name, data, template, 99);
		}		
		
		/// <summary>
		/// R�cup�ration d'un select
		/// </summary>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="row_level">le row level de la ligne</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select(int id_group, int id_ligne, string new_name, string data, string template, int row_level)
		{
			string __select = string.Format("Select {0} id_groupe, {1} id_ligne, '{2}' NOM_BLOC, '{3}' VALEUR_BLOC, '{4}' Template, {5} row_level from dual ", id_group, id_ligne, new_name, data, template, row_level);
			return __select;
		}

		/// <summary>
		/// R�cup�ration d'un select
		/// </summary>
		/// <param name="id_table">id de la table</param>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="row_level">le row level de la ligne</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_Table(int id_table, int id_group, int id_ligne, string new_name, string data, string template, int row_level)
		{
			string __select = string.Format("Select {0} id_table, {1} id_groupe, {2} id_ligne, '{3}' NOM_BLOC, '{4}' VALEUR_BLOC, '{5}' Template, {6} row_level from dual ", id_table, id_group, id_ligne, new_name, data, template, row_level);
			return __select;
		}

		/// <summary>
		/// R�cup�ration d'un select avec level
		/// </summary>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="row_level">le row level</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_RowLevel(int id_group, int id_ligne, string new_name, string data, string template, int row_level)
		{
			string __select = string.Format("Select {0} id_groupe, {1} id_ligne, '{2}' NOM_BLOC, '{3}' VALEUR_BLOC, '{4}' Template , {5} row_level from dual ", id_group, id_ligne, new_name, data, template, row_level);
			return __select;
		}

		/// <summary>
		/// R�cup�ration d'un select avec level et id_table
		/// </summary>
		/// <param name="id_table">identifiant de la table</param>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="row_level">le row level</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_RowLevel_Table(int id_table, int id_group, int id_ligne, string new_name, string data, string template, int row_level)
		{
			string __select = string.Format("Select {0} id_table, {1} id_groupe, {2} id_ligne, '{3}' NOM_BLOC, '{4}' VALEUR_BLOC, '{5}' Template , {6} row_level from dual ", id_table, id_group, id_ligne, new_name, data, template, row_level);
			return __select;
		}
		/// <summary>
		/// R�cup�ration d'un select
		/// </summary>
		/// <param name="id_section">identifiant de la section</param>
		/// <param name="id_group">id_group changement de template tant que id_row est identique les donn�es sont appliqu� � la m�me instance de template</param>
		/// <param name="id_ligne">id_ligne num�ro de la ligne ou le template doit �tre mis, si pas de changement de ligne les templates sont mis sur la m�me ligne</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_Section(int id_section, int id_group, int id_ligne, string new_name, string data, string template)
		{
			string __select = string.Format("Select {0} id_section, {1} id_groupe, {2} id_ligne, {2} row_level, '{3}' NOM_BLOC, '{4}' VALEUR_BLOC, '{5}' Template from dual ", id_section, id_group, id_ligne, new_name, data, template);
			return __select;
		}

		/// <summary>
		/// R�cup�ration d'un select g�n�rant N lignes
		/// </summary>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="nb_Ligne">nombre de lignes souhait�es</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_N(string new_name, string data, string template, int nb_Ligne)
		{
			string __select = string.Format("Select level id_groupe, level id_ligne, '{0}_' || level NOM_BLOC, '{1}_' || level VALEUR_BLOC, '{2}' Template from dual connect by level <= {3}", new_name, data, template, nb_Ligne);
			return __select;
		}

		/// <summary>
		/// R�cup�ration d'un select g�n�rant N lignes
		/// </summary>
		/// <param name="id_section">identifiant de la section</param>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="nb_Ligne">nombre de lignes souhait�es</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_Section_N(int id_section, string new_name, string data, string template, int nb_Ligne)
		{
			string __select = string.Format("Select {0} id_section, level id_groupe, level id_ligne, mod(level,5) row_level, '{1}_' || level NOM_BLOC, '{2}_' || level VALEUR_BLOC, '{3}' Template from dual connect by level <= {4}", id_section, new_name, data, template, nb_Ligne);
			return __select;
		}

		/// <summary>
		/// R�cup�ration d'un select g�n�rant N lignes de Groupe d'�l�ment
		/// </summary>
		/// <param name="new_name">nouveau nom des bloc receptionnant les donn�es</param>
		/// <param name="data">data donn�e � mettre dans chaque bloc du templates</param>
		/// <param name="template">template � utiliser</param>
		/// <param name="nb_Ligne">nombre de lignes souhait�es</param>
		/// <param name="nb_Element">nombre d'element dans le groupe de chaques lignes</param>
		/// <returns>un fragment de la chaine SQL � ex�cuter sur Oracle </returns>
		private String Get_Select_Group_N(string new_name, string data, string template, int nb_Ligne, int nb_Element)
		{
			StringBuilder __sb = new StringBuilder();
			
			__sb.Append("SELECT ")
				.Append("grp.id id_groupe ")
				.Append(", grp.id id_ligne ")
				.Append(", mod(grp.id,5) row_level ")
				.AppendFormat(", '{0}_' || grp.id || '_' || ele.id NOM_BLOC ", new_name)
				.AppendFormat(", '{0}_' || grp.id || '_' || ele.id VALEUR_BLOC ", data)
				.AppendFormat(", '{0}' Template ", template)
				.Append("FROM ")
				.AppendFormat("(select level id from dual connect by level <={0}) grp ", nb_Ligne)
				.AppendFormat(", (select level id from dual connect by level <={0}) ele ", nb_Element);
						
			string __select = __sb.ToString();
			return __select;
		}

		/// <summary>
		/// Fin du run
		/// </summary>
		protected override void End()
		{
			////Inscription des donn�es de stockage
			//Proxy_Store __proxy_Store = new Proxy_Store();
			//__proxy_Store.Insert_Data_Storage(this);
		}
		#endregion overrides

		/// <summary>
		/// Ajout rapide d'un template dans la liste des templates
		/// </summary>
		/// <param name="name"></param>
		/// <param name="src_Name"></param>
		/// <param name="absolute"></param>
		/// <param name="left"></param>
		/// <param name="top"></param>
		/// <param name="width"></param>
		/// <param name="height"></param>
		/// <param name="repeatType"></param>
		/// <returns></returns>
		Template QuickAddTemplate(string name, string src_Name, bool absolute, decimal left, decimal top, decimal width, decimal height, Absolute_Repeat_Type repeatType)
		{
			Template __new_template = new Template();
			__new_template.Name				= name;
			__new_template.Src_Name			= src_Name;
			__new_template.Absolute			= absolute;
			__new_template.Left				= left;
			__new_template.Top				= top;
			__new_template.Width			= width;
			__new_template.Height			= height;
			__new_template.Absolute_Repeat		= repeatType;

			this.Templates.Add(__new_template.Name, __new_template);
			return __new_template;
		}
		#endregion M�thodes

		#region Propri�t�s
        ///// <summary>
        ///// r�pertoire de travail dans le pool quark
        ///// exemple "R_1687\"
        ///// </summary>
        ///// </summary>
        //protected override string PoolPath
        //{
        //    get
        //    {
        //        return "TU\\";
        //    }
        //}


		/// <summary>
		/// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 1
		/// </summary>
		private string SQLDataPerformance
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();
				int							__index				= 1;
				string						__template_Group	= "R_B_1";
				string						__template_header	= "Head_1";
				int							__nbpage			= 1;
				//int							__elementByPage		= 155; //pour les test V9
				int							__elementByPage		= 130;
				int							__loop				= __nbpage * __elementByPage;

				int __L1 = 1;
				int __L2 = 1;
				int __j;
				//int __section = 0;
				//for(int __i = 0; __i < __loop; __i++)
				//{
				//    __j = (__i % __elementByPage);
				//    switch(__j)
				//    {
				//        case 0:
				//            __section++;
				//            //__selects.Add(Get_Select_Section(__section, __index, __index, "2_1Header_" + __index++, string.Format("H{0} L0", __L1), __template_header));
				//            //__L1++;
				//            break;
				//        case 1:
				//        default:
				//            //__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Group_" + __index, string.Format("Value In Index {0}, pos {1}" , __index++, __j), __template_Group, 10));
				//            __selects.Add(Get_Select_Section(__section, __index, __index, "2_1Group_" + __index++, string.Format("Value In G:{0}" , __j), __template_Group));
				//            break;
				//    }
				//}

				int __section = 0;
				for(int __i = 0; __i < __nbpage; __i++)
				{
					__section++;
					__selects.Add(Get_Select_Section_N(__section, string.Format("2_1Group_{0}_", __section), string.Format("Value In S:{0}" , __section), __template_Group, __elementByPage));
				}

				return string.Join(" UNION ", __selects.ToArray());
			}
		}

		/// <summary>
		/// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 1
		/// </summary>
		private string SQLData1
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();
				int							__index				= 1;
				int							__index_Value		= 1;
				string						__template_header		= "Head_1";
				string						__template_header_break	= "Head_Break_1";
				string						__template_Group		= "Group_1";
				string						__template_G1_Abs_1		= "A_G_1";

				int							__loop				= 120;//400;

				int							__L1				= 0;
				int							__L2				= 1;
				int							__L3				= 1;

				int __row_Level = 10;//5;

				//Pour tester si pas de donnn�e
				//return "select 1 from dual where 1=0";

				__selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1}.{2}", __L1, __L2, __L3), __template_header, 1));
				__selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1}.{2} suite suite suite L2", __L1, __L2, __L3), __template_header_break, 1));

				for(int __i = 0; __i < __loop; __i++)
				{
					//if(__i == 1) __row_Level = 10;
					__selects.Add(Get_Select_RowLevel(__index, __index, "1_1Group_" + __index++, "Value In Group " + __index_Value++ + "L " + __row_Level, __template_Group, __row_Level));
				}

				//for(int __i = 0; __i < __loop; __i++)
				//{

				//    switch (__i % 60)
				//    {
				//        //case 0:
				//        //    __L1++; __L2 = 1; __L3 = 1;
				//        //    //Ajout level1
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0} L0", __L1), __template_header, 0));
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0} suite L0", __L1), __template_header_break, 0));
							
				//        //    //Ajout level2
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1} L1", __L1, __L2), __template_header, 1));
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1} suite L1", __L1, __L2), __template_header_break, 1));
							
				//        //    //Ajout level3
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1}.{2} L2", __L1, __L2, __L3), __template_header, 2));
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1}.{2} suite L2", __L1, __L2, __L3), __template_header_break, 2));

				//        //    break;
				//        //case 17:
				//        //case 37:
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Group_" + __index++, "Total In Group " + __index_Value++ + " L13", __template_Group, 13));
				//        //    break;
				//        case 18:
				//        case 38:
				//            __L3++;
				//            //Ajout level3
				//            __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1}.{2} L2", __L1, __L2, __L3), __template_header, 2));
				//            __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1}.{2} suite L2", __L1, __L2, __L3), __template_header_break, 2));

				//            break;
				//        //case 27:
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Group_" + __index++, "Total In Group " + __index_Value++ + " L13", __template_Group, 13));
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Group_" + __index++, "Total In Group " + __index_Value++ + " L14", __template_Group, 14));
				//        //    break;
				//        //case 28:
				//        //    __L2++; __L3 = 1;
				//        //    //Ajout level2
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1} L1", __L1, __L2), __template_header, 1));
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1} suite L1", __L1, __L2), __template_header_break, 1));
							
				//        //    //Ajout level3
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1}.{2} L2", __L1, __L2, __L3), __template_header, 2));
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, string.Format("H{0}.{1}.{2} suite L2", __L1, __L2, __L3), __template_header_break, 2));

				//        //    break;
				//        //case 59: //derni�re ligne c'est un total
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Group_" + __index++, "Total In Group " + __index_Value++ + " L13", __template_Group, 13));
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Group_" + __index++, "Total In Group " + __index_Value++ + " L14", __template_Group, 14));
				//        //    __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Group_" + __index++, "Total In Group " + __index_Value++ + " L15", __template_Group, 15));
				//        //    break;
				//        default: //dans les autres cas une ligne simple
				//            //switch (__i % 3)
				//            //{
				//            //    case 0:
				//            //        __row_Level = 10;
				//            //        break;
				//            //    case 1:
				//            //        __row_Level = 11;
				//            //        break;
				//            //    case 2:
				//            //        __row_Level = 12;
				//            //        break;
				//            //}

				//            //switch (__i % 15)
				//            //{
				//            //    case 0: //toute les 15 ligne g�n�ration d'un rowlevel special qui casse la r�cup�ration des lignes
				//            //        __row_Level = 14;
				//            //        break;
				//            //    default:
				//            //        __row_Level = 10;
				//            //        break;
				//            //}

				//            __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Group_" + __index++, "Value In Group " + __index_Value++ + "L " + __row_Level, __template_Group, __row_Level));
				//            break;
				//    }


					
					////Changement de template page break
					//switch (__i)
					//{
					//    case 50:
					//        //Ajout d'un small 1.2
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "H1.2", __template_header, 2));
					//        //Ajout du template page break associ�
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "H1.2 suite", __template_header_break, 2));
					//        break;
					//    case 59:
					//        //Ajout d'un big 2
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "Big H2 ", __template_header, 1));
					//        //Ajout du template page break associ�
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "Big H2 suite", __template_header_break, 1));

					//        //ajout d'un small 2.1
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "H2.1", __template_header, 2));
					//        //Ajout du template page break associ�
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "H2.1 suite", __template_header_break, 2));
					//        break;
						
					//    case 100:
					//        //ajout d'un small 2.2
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "H2.2", __template_header, 2));
					//        //Ajout du template page break associ�
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "H2.2 suite", __template_header_break, 2));
					//        break;

					//    case 110:
					//        //ajout d'un small 2.3
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "H2.3", __template_header, 2));
					//        //Ajout du template page break associ�
					//        __selects.Add(Get_Select_RowLevel(__index, __index, "1_1Header_" + __index++, "H2.3 suite", __template_header_break, 2));
					//        break;
					
					//}
				//}

				////Groupe
				__selects.Add(Get_Select_RowLevel(__index, __index, "1_1G_1_Abs_1", "Value In Group G1 B1", __template_G1_Abs_1, 0));
				__selects.Add(Get_Select_RowLevel(__index, __index, "1_1G_1_Abs_2", "Value In Group G1 B2", __template_G1_Abs_1, 0));

				return string.Join(" UNION ", __selects.ToArray());
			}
		}

		/// <summary>
		/// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 2
		/// </summary>
		private string SQLData2
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();
				int							__index				= 1;
				//string						__template_Fond		= "Fond_1";
				//string						__template_Value	= "Value_1";
				//string						__template_Group	= "Group_1";
				string						__template_Group	= "R_B_1";
				//string						__template_G1		= "G_1";
				//string						__template_G2		= "G_2";
				//string						__template_G3		= "G_3";
				//string						__template_G4		= "G_4";
				//string						__template_B1_Rel	= "R_B_1";
				string						__template_B1_Abs_1	= "A_B_1";
				string						__template_B1_Abs_2	= "A_B_2";
				//string						__template_G1_Abs_1	= "A_G_1";
				string						__template_header			= "Head_1";
				string						__template_header_break		= "Head_Break_1";
				string						__template_header_break_2	= "Head_Break_2";
				string						__template_header_break_3	= "Head_Break_3";
				//string						__template_header_composite	= "Head_Break_Composite";

				//int							__loop				= 40;
				//int							__loop				= 80;
				//int							__loop				= 120;
				//int							__loop				= 200;
				//int							__loop				= 20000;
				int							__loop				= 10;

				//Pour tester si pas de donnn�e
				//return "select 1 from dual where 1=0";

				//G�n�ration de 1 ligne
				//__selects.Add(Get_Select(__index, 1, "2Fund_" + __index++, "Unit A", __template_Fond));
				//__selects.Add(Get_Select(__index, 1, "2Fund_" + __index++, "Unit B", __template_Fond));
				//__selects.Add(Get_Select(__index, 2, "2Value_" + __index++, "Value A", __template_Value));
				//__selects.Add(Get_Select(__index, 3, "2Value_" + __index++, "Value B", __template_Value));
				
				////fonctionne jusqu'a 2000 � travers le manager
				int __L1 = 1;
				int __L2 = 1;
				int __j;
				for(int __i = 0; __i < __loop; __i++)
				{
				    __j = (__i % 24);
					switch(__j)
					{
						//case 0:
						////case 26:
						////case 15:
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_1Header_" + __index++, string.Format("H{0} L0", __L1), __template_header, 1));
						//    //Page repeat
						//    //__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Header_" + __index++, string.Format("H{0} L0 suite", __L1), __template_header_break, 1));
						//    //__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Header_Composite_" + __index++, string.Format("HC{0} L0 suite", __L1), __template_header_composite, 1));
							
						//    ////Ajout level2
						//    //__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Header_" + __index++, string.Format("H{0}.{1} L1", __L1, __L2), __template_header, 1));
						//    //__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Header_" + __index++, string.Format("H{0}.{1} suite L1", __L1, __L2), __template_header_break, 1));

						//    __L1++;

						//    break;
						////case 1:
						//case 1:
						////case 27:
						////case 16:
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_1Middle_" + __index++, string.Format("M{0} L2", __L1), __template_header, 2));
						//    //Page repeat
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_1Middle_" + __index++, string.Format("M{0} L2 suite", __L1), __template_header_break_2, 2));
						//    __L1++;
						//    break;

						//case 2:
						////case 27:
						////case 16:
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_1Footer_" + __index++, string.Format("F{0} L2", __L1), __template_header, 3));
						//    //Page repeat
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_1Footer_" + __index++, string.Format("F{0} L2 suite", __L1), __template_header_break_3, 3));
						//    __L1++;
						//    break;

						/* Tr�s Long text pour les overflow*/
						//case 8:
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_1Group_" + __index, "Tr�s tr�s tr�s longue longue value In Group " + __index++, __template_Group, 10));
						//    break;
						/* Assez long text pour les overflow*/
						//case 12:
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_2Group_" + __index, "assez longue longue value In Group " + __index++, __template_Group, 10));
						//    break;
						default:
							//__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Group_" + __index, string.Format("Value In Index {0}, pos {1}" , __index++, __j), __template_Group, 10));
							__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Group_" + __index++, string.Format("Value In Group {0}" , __j), __template_Group, 10));
							break;
					}
				//    //__selects.Add(Get_Select(__index, __index, "2B_" + __index, "Value In Box " + __index++, __template_B1_Rel));
				}

				//Box
				__selects.Add(Get_Select(__index, __index, "2B_Abs1", "Value In Box " + __index++, __template_B1_Abs_1));
				__selects.Add(Get_Select(__index, __index, "2B_Abs2", "Value In Box " + __index++, __template_B1_Abs_2));

				
				////Groupe
				//__selects.Add(Get_Select(__index, 8, "2G3_B1", "G3_B1", __template_G3));
				//__selects.Add(Get_Select(__index++, 8, "2G3_B2", "G3_B2", __template_G3));

				//__selects.Add(Get_Select(__index, 8, "2G3_B3", "G3_B3", __template_G4));
				//__selects.Add(Get_Select(__index++, 8, "2G3_B4", "G3_B4", __template_G4));
				
				return string.Join(" UNION ", __selects.ToArray());
			}
		}

		/// <summary>
		/// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 3
		/// </summary>
		private string SQLData3
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();
				//int							__index				= 1;
				//string						__template_Fond		= "Fond_1";
				//string						__template_Value	= "Value_1";
				//string						__template_Group	= "Group_1";
				//string						__template_G1		= "G_1";
				//string						__template_G2		= "G_2";
				//string						__template_G3		= "G_3";
				//string						__template_G4		= "G_4";
				//string						__template_B1_Rel	= "R_B_1";
				//string						__template_B1_Abs_1	= "A_B_1";
				//string						__template_B1_Abs_2	= "A_B_2";
				//string						__template_B1_Abs_3	= "A_B_3";
				//string						__template_G1_Abs_1	= "A_G_1";
				string						__template_R_B_1	= "R_B_1";
				//string						__template_G4		= "G4";

				//int							__nbElement			= 5;
				int							__loop				= 120;//15000;//1 page =30// 2 pages =60// 3 pages =100// 4 pages =140; Max 98 pages = 3500
				//int							__loop_Section1				= 10;
				//int							__loop_Section2				= 10;

				//Pour tester si pas de donnn�e
				//return "select 1 from dual where 1=0";
				
				////Box Section 1
				//__selects.Add(Get_Select_Section(1, __loop_Section1 + __index, __loop_Section1 + __index, "3_1B_Abs1", "Value In Box " + __index++, __template_B1_Abs_1));
				//__selects.Add(Get_Select_Section(1, __loop_Section1 +__index, __loop_Section1 + __index, "3_1B_Abs2", "Value In Box " + __index++, __template_B1_Abs_2));

				////Section 1
				//__selects.Add(Get_Select_Section_N(1, "3_1Group_" + __index, "Value In Group " + __index++, __template_B5, __loop_Section1));
				
				////Box Section 2
				//__selects.Add(Get_Select_Section(2, __loop_Section2 + __index, __loop_Section2 + __index, "3_2B_Abs1", "Value In Box " + __index++, __template_B1_Abs_1));
				//__selects.Add(Get_Select_Section(2, __loop_Section2 + __index, __loop_Section2 + __index, "3_2B_Abs2", "Value In Box " + __index++, __template_B1_Abs_3));

				////Section 2
				//__selects.Add(Get_Select_Section_N(2, "3_2Group_" + __index, "Value In Group " + __index++, __template_Group, __loop_Section2));

				//G�n�ration de ligne de groupes d'�l�ments
				//__selects.Add(Get_Select_Group_N("3_G4", "Une autre value In Group ", __template_Group, __loop, __nbElement));
				__selects.Add(Get_Select_N("3_G4", "Value dans nouveau ___Group", __template_R_B_1, __loop));

				
				return string.Join(" UNION ", __selects.ToArray());
			}
		}

		/// <summary>
		/// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 4 (variante de SQL2)
		/// </summary>
		private string SQLData4
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();
				int							__index				= 1;
				//string						__template_Fond		= "Fond_1";
				//string						__template_Value	= "Value_1";
				//string						__template_Group	= "Group_1";
				string						__template_Group	= "R_B_1";
				string						__template_G1		= "G_1";
				//string						__template_G2		= "G_2";
				//string						__template_G3		= "G_3";
				//string						__template_G4		= "G_4";
				//string						__template_B1_Rel	= "R_B_1";
				//string						__template_B1_Abs_1	= "A_B_1";
				//string						__template_B1_Abs_2	= "A_B_2";
				//string						__template_G1_Abs_1	= "A_G_1";
				string						__template_header		= "Head_1";
				string						__template_header_break	= "Head_Break_1";

				int							__loop				= 100;

				//return "select 1 from dual where 1=0";

				//G�n�ration de 1 ligne
				//__selects.Add(Get_Select(__index, 1, "2Fund_" + __index++, "Unit A", __template_Fond));
				//__selects.Add(Get_Select(__index, 1, "2Fund_" + __index++, "Unit B", __template_Fond));
				//__selects.Add(Get_Select(__index, 2, "2Value_" + __index++, "Value A", __template_Value));
				//__selects.Add(Get_Select(__index, 3, "2Value_" + __index++, "Value B", __template_Value));
				
				////fonctionne jusqu'a 2000 � travers le manager
				int __L1 = 1;
				int __L2 = 1;
				for(int __i = 0; __i < __loop; __i++)
				{
				    switch(__i % 22)
					{
						case 0:
				            __selects.Add(Get_Select_RowLevel(__index, __index, "4_1Header_" + __index++, string.Format("H{0} L0", __L1), __template_header, 0));
				            __selects.Add(Get_Select_RowLevel(__index, __index, "4_1Header_" + __index++, string.Format("H{0} suite L0", __L1), __template_header_break, 0));
							
				            //Ajout level2
				            __selects.Add(Get_Select_RowLevel(__index, __index, "4_1Header_" + __index++, string.Format("H{0}.{1} L1", __L1, __L2), __template_header, 1));
				            __selects.Add(Get_Select_RowLevel(__index, __index, "4_1Header_" + __index++, string.Format("H{0}.{1} suite L1", __L1, __L2), __template_header_break, 1));

							__L1++;

							break;
						case 8:
							__selects.Add(Get_Select_RowLevel(__index, __index, "4_1Group_" + __index, "Tr�s tr�s tr�s longue longue value In Group " + __index++, __template_Group, 10));
							break;

						case 12:
							//Groupe
							__selects.Add(Get_Select_RowLevel(__index, __index, "4G3_B1_" + __index, "___G3_B1_" + __index, __template_G1, 7));
							__selects.Add(Get_Select_RowLevel(__index, __index, "4G3_B2_" + __index, "G3_B2_" + __index++, __template_G1, 7));
							break;
						default:
							__selects.Add(Get_Select_RowLevel(__index, __index, "4_1Group_" + __index, "Value In Group " + __index++, __template_Group, 10));
							break;
					}
				//    //__selects.Add(Get_Select(__index, __index, "4B_" + __index, "Value In Box " + __index++, __template_B1_Rel));
				}

				////Box
				//__selects.Add(Get_Select(__index, __index, "4B_Abs1", "Value In Box " + __index++, __template_B1_Abs_1));
				//__selects.Add(Get_Select(__index, __index, "4B_Abs2", "Value In Box " + __index++, __template_B1_Abs_2));

				
				
				return string.Join(" UNION ", __selects.ToArray());
			}
		}


		/// <summary>
		/// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 5
		/// </summary>
		private string SQLData5
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();
				int							__index				= 1;
				//string						__template_Fond		= "Fond_1";
				//string						__template_Value	= "Value_1";
				string						__template_Group	= "Group_1";
				//string						__template_G1		= "G_1";
				//string						__template_G2		= "G_2";
				//string						__template_G3		= "G_3";
				//string						__template_G4		= "G_4";
				string						__template_B1_Rel	= "R_B_1";
				string						__template_B1_Abs_1	= "A_B_1";
				string						__template_B1_Abs_2	= "A_B_2";
				string						__template_B1_Abs_3	= "A_B_3";
				//string						__template_G1_Abs_1	= "A_G_1";
				//string						__template_R_B_1	= "R_B_1";
				//string						__template_G4		= "G4";

				//int							__nbElement			= 5;
				//int							__loop				= 15;//1 page =30// 2 pages =60// 3 pages =100// 4 pages =140; Max 98 pages = 3500
				int							__loop_Section1				= 100;
				int							__loop_Section2				= 100;

				//Box Section 1
				__selects.Add(Get_Select_Section(1, __loop_Section1 + __index, __loop_Section1 + __index, "3_1B_Abs1", "Value In Box " + __index++, __template_B1_Abs_1));
				__selects.Add(Get_Select_Section(1, __loop_Section1 +__index, __loop_Section1 + __index, "3_1B_Abs2", "Value In Box " + __index++, __template_B1_Abs_2));

				//Section 1
				__selects.Add(Get_Select_Section_N(1, "5_1Group_" + __index, "___________Value In Group " + __index++, __template_B1_Rel, __loop_Section1));
				
				//Box Section 2
				__selects.Add(Get_Select_Section(2, __loop_Section2 + __index, __loop_Section2 + __index, "3_2B_Abs1", "Value In Box " + __index++, __template_B1_Abs_1));
				__selects.Add(Get_Select_Section(2, __loop_Section2 + __index, __loop_Section2 + __index, "3_2B_Abs2", "Value In Box " + __index++, __template_B1_Abs_3));

				//Section 2
				__selects.Add(Get_Select_Section_N(2, "3_2Group_" + __index, "____________Value In Group " + __index++, __template_Group, __loop_Section2));

				
				return string.Join(" UNION ", __selects.ToArray());
			}
		}

		/// <summary>
		/// G�n�ration du tache SQL de test des Taches dynamiques - Num�ro 6
		/// Avec TABLE
		/// </summary>
		private string SQLData6
		{
			get
			{	
				QXPFrk.BaseList<string>		__selects			= new QXPFrk.BaseList<string>();
				int							__index				= 1;
				//string						__template_Fond		= "Fond_1";
				//string						__template_Value	= "Value_1";
				//string						__template_Group	= "Group_1";
				string						__template_Group	= "R_B_1";
				//string						__template_G1		= "G_1";
				//string						__template_G2		= "G_2";
				//string						__template_G3		= "G_3";
				//string						__template_G4		= "G_4";
				//string						__template_B1_Rel	= "R_B_1";
				string						__template_B1_Abs_1	= "A_B_1";
				string						__template_B1_Abs_2	= "A_B_2";
				//string						__template_G1_Abs_1	= "A_G_1";
				string						__template_header			= "Head_1";
				string						__template_header_break		= "Head_Break_1";
				string						__template_header_break_2	= "Head_Break_2";
				string						__template_header_break_3	= "Head_Break_3";
				int							__id_table = 0;

				//int							__loop				= 40;
				//int							__loop				= 80;
				int							__loop				= 60;
				//int							__loop				= 200;

				//Pour tester si pas de donnn�e
				//return "select 1 from dual where 1=0";

				//G�n�ration de 1 ligne
				//__selects.Add(Get_Select(__index, 1, "2Fund_" + __index++, "Unit A", __template_Fond));
				//__selects.Add(Get_Select(__index, 1, "2Fund_" + __index++, "Unit B", __template_Fond));
				//__selects.Add(Get_Select(__index, 2, "2Value_" + __index++, "Value A", __template_Value));
				//__selects.Add(Get_Select(__index, 3, "2Value_" + __index++, "Value B", __template_Value));
				
				////fonctionne jusqu'a 2000 � travers le manager
				int __L1 = 1;
				int __L2 = 1;
				int __j;
				for(int __i = 0; __i < __loop; __i++)
				{
				    __j = (__i % 24);
					switch(__j)
					{
						case 0:
						//case 26:
						//case 15:
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Header_" + __index++, string.Format("H{0} L0", __L1), __template_header, 1));
				            //Page repeat
							__selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Header_" + __index++, string.Format("H{0} L0 suite", __L1), __template_header_break, 1));
							
							////Ajout level2
							//__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Header_" + __index++, string.Format("H{0}.{1} L1", __L1, __L2), __template_header, 1));
							//__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Header_" + __index++, string.Format("H{0}.{1} suite L1", __L1, __L2), __template_header_break, 1));

							__L1++;

							break;
						//case 1:
						case 1:
						//case 27:
						//case 16:
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Middle_" + __index++, string.Format("M{0} L1", __L1), __template_header, 2));
						    //Page repeat
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Middle_" + __index++, string.Format("M{0} L1 suite", __L1), __template_header_break_2, 2));
						    __L1++;
						    break;

						case 2:
						//case 27:
						//case 16:
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Footer_" + __index++, string.Format("F{0} L2", __L1), __template_header, 3));
						    //Page repeat
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Footer_" + __index++, string.Format("F{0} L2 suite", __L1), __template_header_break_3, 3));
						    __L1++;
						    break;

						/* Tr�s Long text pour les overflow*/
						//case 8:
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_1Group_" + __index, "Tr�s tr�s tr�s longue longue value In Group " + __index++, __template_Group, 10));
						//    break;
						/* Assez long text pour les overflow*/
						//case 12:
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_2Group_" + __index, "assez longue longue value In Group " + __index++, __template_Group, 10));
						//    break;
						default:
							__selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Group_" + __index, string.Format("Value In Index {0}, pos {1}" , __index++, __j), __template_Group, 10));
							break;
					}
				//    //__selects.Add(Get_Select(__index, __index, "2B_" + __index, "Value In Box " + __index++, __template_B1_Rel));
				}

				__id_table++;

				for(int __i = 0; __i < __loop; __i++)
				{
				    __j = (__i % 24);
					switch(__j)
					{
						case 0:
						//case 26:
						//case 15:
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Header_" + __index++, string.Format("H{0} L0", __L1), __template_header, 1));
				            //Page repeat
							__selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Header_" + __index++, string.Format("H{0} L0 suite", __L1), __template_header_break, 1));
							
							////Ajout level2
							//__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Header_" + __index++, string.Format("H{0}.{1} L1", __L1, __L2), __template_header, 1));
							//__selects.Add(Get_Select_RowLevel(__index, __index, "2_1Header_" + __index++, string.Format("H{0}.{1} suite L1", __L1, __L2), __template_header_break, 1));

							__L1++;

							break;
						//case 1:
						case 1:
						//case 27:
						//case 16:
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Middle_" + __index++, string.Format("M{0} L1", __L1), __template_header, 2));
						    //Page repeat
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Middle_" + __index++, string.Format("M{0} L1 suite", __L1), __template_header_break_2, 2));
						    __L1++;
						    break;

						case 2:
						//case 27:
						//case 16:
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Footer_" + __index++, string.Format("F{0} L2", __L1), __template_header, 3));
						    //Page repeat
						    __selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Footer_" + __index++, string.Format("F{0} L2 suite", __L1), __template_header_break_3, 3));
						    __L1++;
						    break;

						/* Tr�s Long text pour les overflow*/
						//case 8:
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_1Group_" + __index, "Tr�s tr�s tr�s longue longue value In Group " + __index++, __template_Group, 10));
						//    break;
						/* Assez long text pour les overflow*/
						//case 12:
						//    __selects.Add(Get_Select_RowLevel(__index, __index, "2_2Group_" + __index, "assez longue longue value In Group " + __index++, __template_Group, 10));
						//    break;
						default:
							__selects.Add(Get_Select_RowLevel_Table(__id_table, __index, __index, "2_1Group_" + __index, string.Format("Value In Index {0}, pos {1}" , __index++, __j), __template_Group, 10));
							break;
					}
				//    //__selects.Add(Get_Select(__index, __index, "2B_" + __index, "Value In Box " + __index++, __template_B1_Rel));
				}

				//Box
				__selects.Add(Get_Select_Table(99, __index, __index, "2B_Abs1", "Value In Box " + __index++, __template_B1_Abs_1));
				__selects.Add(Get_Select_Table(99, __index, __index, "2B_Abs2", "Value In Box " + __index++, __template_B1_Abs_2));

				
				////Groupe
				//__selects.Add(Get_Select(__index, 8, "2G3_B1", "G3_B1", __template_G3));
				//__selects.Add(Get_Select(__index++, 8, "2G3_B2", "G3_B2", __template_G3));

				//__selects.Add(Get_Select(__index, 8, "2G3_B3", "G3_B3", __template_G4));
				//__selects.Add(Get_Select(__index++, 8, "2G3_B4", "G3_B4", __template_G4));
				
				return string.Join(" UNION ", __selects.ToArray());
			}
		}

        protected override string PoolPath
        {
            get
            {
                return "TU\\";
            }
        }

		#endregion Propri�t�s
	}
}
