
using QXPFrk	= QXP.Framework;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un run de test quark permettant de rafraichir un fichier quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>17/08/2010 10:45:10</date>    
	public class Run_Test_Refresh: Run_Base
	{
		#region Membres
		

		#endregion Membres

		#region Constantes
		//const string Gabarit_Tete			= "DG.qxp";
		//const string Gabarit_Tete			= "LYX.qxp";
		//const string Gabarit_Tete			= "hyperbig.qxp";
		//const string Gabarit_Tete			= "Gabarit_Double_Simple_Tmp.qxp";
		//const string Gabarit_Tete			= "Gabarit_Double_Tmp.qxp";
		//const string Gabarit_Tete			= "Gabarit_Tableau_2.qxp";
		//const string Gabarit_Tete			= "D_0.qxp";
		//const string Gabarit_Tete			= "Gabarit_Double_Simple_Tmp_2.qxp";
		//const string Gabarit_Tete			= "Gabarit_Double_Simple_Tmp_2.qxp";
		//const string Gabarit_Tete			= "toobig.qxp";
		//const string Gabarit_Tete			= "R_12025/G_31.qxp";
		const string Gabarit_Tete			= "R_12027/DG_25765_3.QXP";
		//const string Gabarit_Tete			= "RA.qxp";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur
		public Run_Test_Refresh(): base(0)
		{

		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="id_run">identifiant du run</param>
		public Run_Test_Refresh(int id_run): base(id_run)
		{

		}
		#endregion Constructeur

		#region M�thodes

		#region overrides
		/// <summary>
		/// D�but du run
		/// </summary>
		protected override void Start()
		{
			//Rien � faire ici pour l'instant
		}

		/// <summary>
		/// Chargement des propri�t�s du run
		/// </summary>
		protected override void LoadProperties()
		{
			//Seulement si ce n'est pas d�fini par l'ext�rieur
			if(QXPFrk.Validation.IsNotSet(this.Properties.ID_Fnd_Code)) 
				this.Properties.ID_Fnd_Code			= "UCOMPA";
			
			//Seulement si ce n'est pas d�fini par l'ext�rieur
			if(QXPFrk.Validation.IsNotSet(this.Properties.ID_Suivi))	
				this.Properties.ID_Suivi			= 1;
			
			//� activer lorsque l'ont travail sur le gabarit Gabarit_Tete est "Gabarit_Double_Tmp"
			this.Properties.Nb_Page_By_Spread = Run_Properties.PaginationSimple;
		}

		/// <summary>
		/// Chargment des templates
		/// </summary>
		protected override void LoadTemplates()
		{
		
		}
		/// <summary>
		/// Chargment et pr�paration du gabarit
		/// </summary>
		protected override void PrepareGabarit()
		{
			

			//on inform que le gabarit est d�j� dans le pool de quark
			QXPS_File_Manager.Addfile_Inform(Gabarit_Tete);

			//on le r�cup�re
			string __fileName	= QXPS_File_Manager.GetFileNameExt(Gabarit_Tete);
            Document __doc_gabarit = QXPS_File_Manager.Get_FilePool(__fileName);

			this.Gabarit = __doc_gabarit;			

			//string				__strDID	= Document_Identity_Helper.Get_Current_Identity(Gabarit_Tete);
			//Document_Identity	__DID		=  new Document_Identity(__strDID);

			__doc_gabarit.Evaluate_Document_Identity();

			Document_Identity __DID = __doc_gabarit.Identity;

			if (__DID.Is_Defined)
			{
				this.Properties.ID_Fnd_Code		= __DID.Id_Fnd_Code;
				this.Properties.ID_Langue		= __DID.Id_Langue;
				this.Properties.ID_Suivi		= __DID.Id_Suivi;
				this.Properties.ID_Unit_Code	= __DID.Id_Unit_Code;
			}

			if (!this.Mode_Degrade)
			{
				DProject_Info __projectInfo = this.Gabarit.XML.Project_Info;

				decimal __box_complexity = this.Gabarit.Box_Complexity;
				int __box_size_ratio = this.Gabarit.Ratio_Size_Box;
				int __doc_size = this.Gabarit.Data.Length;
				int __nbBox = this.Gabarit.XML.Project_Info.NbBox;
				int __nbPage = this.Gabarit.XML.Project_Info.NbPage;
			}
			
			//int		__nbBoxMax			= (int)((decimal)17500 / __box_complexity);
			//QXPFrk.BaseList<string> __ancres	= this.Gabarit.XML.GetListBoxNameStartWith("Ancre");
			//QXPFrk.BaseList<string> __start		= this.Gabarit.XML.GetListBoxNameEndWith("_START");
                
		}

		/// <summary>
		/// Chargement des InParams du run, les Inparams sont pass�s � certaines taches (exemple les taches SQL)
		/// </summary>
		protected override void LoadInParams()
		{
			

		}

		/// <summary>
		/// Chargement des taches associ�es � un run
		/// </summary>
		protected override void LoadTasks()
		{

			Task_DID	__did_Task = new Task_DID(0, this);
			this.Tasks.Add(__did_Task.ID, __did_Task);

		}

		/// <summary>
		/// Fin du run
		/// </summary>
		protected override void End()
		{
			//Rien � faire ici			
		}
		#endregion overrides

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Repr�sente le r�pertoire de travail dans le pool exemple "R_1687\"
		/// </summary>
		protected override	string	PoolPath
		{
			get{
				string __root	= QXPS_File_Manager.GetFilePath(Gabarit_Tete);

				if (QXPFrk.Validation.IsSet(__root))
				{
					return string.Format("{0}\\", __root);
				}
				else
				{
					return string.Empty;
				}
			}
		}

		#endregion Propri�t�s
	}
}
