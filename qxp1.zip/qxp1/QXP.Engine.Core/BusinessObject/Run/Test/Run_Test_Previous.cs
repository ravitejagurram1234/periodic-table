using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Il s'agit d'un version sp�ciale du Run_Previous qui est utilis�e par EOS.Quality pour effectuer des chargement sp�cifique d'ancien gabarit fils
	/// </summary>
	/// <author>doufarm</author>
	/// <date>02/06/2010 09:48:44</date>    
	public class Run_Test_Previous : Run_Previous
	{
		#region Membres
		private string _previous_QXP = null;
		#endregion Membres

		#region Constantes
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Run_Previous_Debug
		/// </summary>
		public Run_Test_Previous(): base (1)
		{

		}

		#endregion Constructeur

		#region M�thodes

		protected override void LoadProperties()
		{
			
		}

		/// <summary>
		/// 
		/// </summary>
		protected override void Render()
		{
			if (QXPFrk.Validation.IsSet(_previous_QXP))
			{
				//Permet d'avertir que le fichier est d�j� pr�sent dans le pool path de quark
				QXPS_File_Manager.Addfile_Inform(_previous_QXP);

				//R�cup�ration du fichier
				this.Result.Final_QXP = QXPS_File_Manager.Get_FilePool(_previous_QXP);
			}
		}
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Nom du fichier QXP � charger
		/// </summary>
		public string Previous_QXP
		{
			get
			{
				return _previous_QXP;
			}
			set
			{
				_previous_QXP = value;
			}
		}
		#endregion Propri�t�s
	}
}
