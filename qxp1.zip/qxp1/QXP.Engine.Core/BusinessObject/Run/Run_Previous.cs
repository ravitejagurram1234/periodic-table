using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un run d�j� �x�cut�, permet de recharger les propri�t�s et les r�sultats de ce run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>27/05/2010 16:44:08</date>    
	public class Run_Previous : Run
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Repr�sente un run d�j� �x�cuter
		/// </summary>
		/// <param name="id_run"></param>
		public Run_Previous(int id_run): base(id_run)
		{

		}


		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Dans ce type de run aucun template n'est n�cessaire
		/// </summary>
		protected override void LoadTemplates()
		{
			//Rien � faire
		}

		/// <summary>
		/// Dans ce type de run aucune tache ne sera �x�cut� nous n'avons donc pas besoin des InParams
		/// </summary>
		protected override void LoadInParams()
		{
			//Rien � faire
		}
		
		/// <summary>
		/// Dans ce type de run aucun status de run n'est mis � jour en base de donn�e
		/// </summary>
		protected override void Start()
		{
			//Rien � faire
		}

		/// <summary>
		/// 
		/// </summary>
		protected override void Process_Steps()
		{
			//Aucune �tape � effectuer ici
		}

		/// <summary>
		/// En faite cela n'effectue pas un nouveau rendu du run mais cela r�cup�re les fichiers g�n�r�s � l'�poque.
		/// </summary>
		protected override void Render()
		{
			//s'il y a bien un document qxp qui � �t� g�n�r� pour ce run alors on le charge
			if (QXPFrk.Validation.IsSet(this.Properties.ID_Last_QXP))
			{
				Document	__doc = QXPS_File_Manager.Get_Document(this.Properties.ID_Last_QXP);
				this.Result.Final_QXP = __doc;
				//ajout du document dans le document pool
				QXPS_File_Manager.Addfile(__doc.FilePoolPath, __doc.Data);
			}
			else
			{
				this.Errors.Add(Constantes.Error_Messages.EmptyRunChildQXP, this.ID);
			}
		}

		/// <summary>
		/// Dans ce type de run aucun status de run n'est mis � jour en base de donn�e
		/// </summary>
		protected override void End()
		{
			//Rien � faire
		}

		/// <summary>
		/// Dans ce type de run aucune tache ne doit �tre proc�ss�
		/// </summary>
		protected override void Process()
		{
			//Rien � faire
		}
		
		/// <summary>
		/// Dans ce type de run aucune tache ne sera �x�cuter pas besoin de gabarit
		/// </summary>
		protected override void PrepareGabarit()
		{
			//Rien � faire
		}

		/// <summary>
		/// Dans ce type de run nous ne changeons pas les param�tres du document pool de quark server
		/// </summary>
		protected override void InitThreadFileManager()
		{
			//rien � faire
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
