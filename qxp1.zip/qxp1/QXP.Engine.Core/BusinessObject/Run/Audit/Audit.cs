using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet d'auditer l'�x�cution d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:43:14</date>    
	public class Audit
	{
		#region Membres
		Run_Base	_run;
        
		DateTime    _startDate;       
        DateTime    _endDate;       
		Run_Status	_endStatus;
        string      _message;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Audit
		/// </summary>
		/// <param name="run">le run � auditer</param>
		public Audit(Run_Base run)
		{
			_run		= run;
			_startDate  = DateTime.Now;
		}

		#endregion Constructeur

		#region M�thodes
		
		/// <summary>
		/// Fin de l'audit
		/// </summary>
        public void End()
		{
            _endDate    = DateTime.Now;
			_endStatus	= _run.Status;
            buildAuditMessage();
        }

        /// <summary>
        /// contruction du message final de l'audit
        /// </summary>
		private void buildAuditMessage()
        {
            StringBuilder __message = new StringBuilder();

            int __nbtask = 0;
            foreach (Task_Base __t in _run.Tasks.Values)
            {
                if(__t.Todo)
                    __nbtask++;
            }

            __message.AppendFormat("Nb Tasks: {0}\nNb Errors: {1}", __nbtask, _run.Errors.Count);
            __message.Append(_run.Errors.ToString());
            _message = __message.ToString();
        }
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Repr�sente le run associ� � l'audit
		/// </summary>
		public Run_Base Run
		{
			get{return _run;}
		}

		/// <summary>
		/// dur�e d'�x�cution totale du run (en millisecond)
		/// </summary>
        public int Duration
        {
            get { return ((TimeSpan)(_endDate-_startDate)).Milliseconds;}
        }

		/// <summary>
		/// Date de d�but de l'audit
		/// </summary>
		public DateTime StartDate
		{
			get{return _startDate;}
		}

		/// <summary>
		/// Date de fin de l'audit
		/// </summary>
		public DateTime		EndDate
		{
			get{return _endDate;}
		}

		/// <summary>
		/// Status du run � la fin de l'audit
		/// </summary>
		public Run_Status	EndStatus
		{
			get{return _endStatus;}
		}

		/// <summary>
		/// Message final de l'audit du run
		/// </summary>
        public string		Message
        {
            get { return _message; }
        }
		#endregion Propri�t�s
	}
}
