using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les versions (qxp, pdf et word) du document quark final obtenu apr�s l'�x�cution du run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:48:23</date>    
	public class Run_Result
	{
		#region Membres
        Document	_final_jpg		= null;
        Document	_final_pdf		= null;
        Document	_final_qxp		= null;
        Document	_final_word		= null;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Run_Result
		/// </summary>
		public Run_Result()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Document finale JPG du run
		/// </summary>
        public Document Final_JPG
        {
            get 
			{ 
				return _final_jpg; 
			}
            set 
			{ 
				_final_jpg = value; 
			}
        }

		/// <summary>
		/// Document finale PDF du run
		/// </summary>
        public Document Final_PDF
        {
            get 
			{ 
				return _final_pdf; 
			}
            set 
			{ 
				_final_pdf = value; 
			}
        }

		/// <summary>
		/// Document finale QXP du run
		/// </summary>
        public Document Final_QXP
        {
            get 
			{ 
				return _final_qxp; 
			}
            set 
			{ 
				_final_qxp = value; 
			}
        }
        
		/// <summary>
		/// Document finale DOC du run
		/// </summary>
        public Document Final_Word
        {
            get 
			{ 
				return _final_word; 
			}
            set 
			{ 
				_final_word = value; 
			}
        }

		#endregion Propri�t�s
	}
}
