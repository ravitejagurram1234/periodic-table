using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// repr�sente une Exception .net qui survient lorsqu'une erreur impr�vue se produit lors de la g�n�ration d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 15:25:45</date>    
	public class Run_Exception: Exception
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		//TODO: ajouter les informations du run en cours d'�x�cution
		/// <summary>
		/// Cr�e une instance de Run_Exception
		/// </summary>
		/// <param name="message"></param>
		/// <param name="ex"></param>
		public Run_Exception(string message, Exception ex): base(message, ex)
		{
            
        }

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
