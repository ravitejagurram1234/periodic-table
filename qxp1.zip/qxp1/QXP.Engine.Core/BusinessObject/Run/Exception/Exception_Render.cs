using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Exception lev� en cas d'erreur dans l'obtention/evaluation d'un DID (document identity)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>05/05/2010 11:47:40</date>    
	public class Exception_Render: Exception_Base
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Exception_DID
		/// </summary>
		/// <param name="ex"></param>
		/// <param name="message"></param>
		/// <param name="args"></param>
		public Exception_Render(QXPInteropQuarkServer.QXPS_Exception ex, string message, params object[] args): base(ex, Get_Message(ex, message, args))
		{
			this.Type = Error_Type.Bloquante;
		}
		#endregion Constructeur

		#region M�thodes
			
		/// <summary>
		/// 
		/// </summary>
		/// <param name="ex"></param>
		/// <param name="message"></param>
		/// <param name="args"></param>
		/// <returns></returns>
		static string Get_Message(QXPInteropQuarkServer.QXPS_Exception ex, string message, params object[] args)
		{
			StringBuilder __sb = new StringBuilder();
			if (QXPFrk.Validation.IsSet(message))
			{
				__sb.AppendLine(string.Format(message, args));
			}
			__sb.AppendLine(ex.Message);
			return __sb.ToString();
		}
		#endregion M�thodes

		#region Propri�t�s
		
		#endregion Propri�t�s
	}
}
