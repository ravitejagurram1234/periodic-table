using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Exception lev� en cas d'erreur lors de la manipulation des TElements (template �l�ment)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>05/05/2010 11:47:40</date>    
	public class Exception_TElement: Exception_Base
	{
		#region Membres

		#endregion Membres

		#region Constantes
		/// <summary>
		/// "La boite mod�le n'existe pas pour le nouveau nom {0}"
		/// </summary>
		public const string MSG_SrcBox_NULL						= "La boite mod�le n'existe pas pour le nouveau nom {0}";
		/// <summary>
		/// "La structure {0} du group ne peut pas accueillir de valeur"
		/// </summary>
		public const string MSG_Invalid_Box_Structure			= "La structure {0} du group ne peut pas accueillir de valeur";
		/// <summary>
		/// "Impossible d'analyser le nom de la boite {0} cible"
		/// </summary>
		public const string MSG_Invalid_Box						= "Impossible d'analyser le nom de la boite {0} cible";
		/// <summary>
		/// "Boite ou g�om�trie invalide pour le groupe {0} cible"
		/// </summary>
		public const string MSG_Invalid_Box_Group_Or_Geometry	= "Boite ou g�om�trie invalide pour le groupe {0} cible";
		/// <summary>
		/// "L'�l�ment {0} ne peut acceuillir qu'un nouveau nom"
		/// </summary>
		public const string MSG_TElement_Need_One_Name			= "L'�l�ment {0} ne peut acceuillir qu'un nouveau nom";
		/// <summary>
		/// "L'�l�ment {0} doit avoir au moins un nom"
		/// </summary>
		public const string MSG_TElement_Need_Name				= "L'�l�ment {0} doit avoir au moins un nom";
		/// <summary>
		/// "Un probl�me sur l'�l�ment {0} emp�che de mettre � jour le/les nom(s) et valeur(s)"
		/// </summary>
		public const string MSG_TElement_UpdateNamesValues		= "Un probl�me sur l'�l�ment {0} emp�che de mettre � jour le/les nom(s) et valeur(s)";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Exception_TElement
		/// </summary>
		/// <param name="message">message de l'exception</param>
		/// <param name="args">arguments du message</param>
		public Exception_TElement(string message, params object[] args): base(message, args)
		{
			
		}

		/// <summary>
		/// Cr�e une instance de Exception_TElement
		/// </summary>
		/// <param name="ex">exception � l'origine de cette nouvelle exception</param>
		/// <param name="message">message de l'exception</param>
		/// <param name="args">arguments du message</param>
		public Exception_TElement(Exception ex, string message, params object[] args): base(message, args)
		{
			
		}

		/// <summary>
		/// Cr�e une instance de Exception_TElement
		/// </summary>
		/// <param name="ex">exception � l'origine de cette nouvelle exception</param>
		public Exception_TElement(Exception ex): base(ex)
		{
			
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		
		#endregion Propri�t�s
	}
}
