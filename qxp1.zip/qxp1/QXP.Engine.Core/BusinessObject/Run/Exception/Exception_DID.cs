using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Exception lev� en cas d'erreur dans l'obtention/evaluation d'un DID (document identity)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>05/05/2010 11:47:40</date>    
	public class Exception_DID: Exception_Base
	{
		#region Membres

		#endregion Membres

		#region Constantes
		/// <summary>
		/// Le document n'est pas valide pour une analyse DID
		/// </summary>
		public const string MSG_Invalid_Document = "Le document n'est pas valide pour une analyse DID";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Exception_DID
		/// </summary>
		public Exception_DID(): base(MSG_Invalid_Document)
		{
			this.Type = Error_Type.Bloquante;
		}

		/// <summary>
		/// Cr�e une instance de Exception_DID
		/// </summary>
		/// <param name="ex">L'exception qui � provoquer l'erreur de did</param>
		public Exception_DID(Exception ex): base(ex, MSG_Invalid_Document)
		{
			this.Type = Error_Type.Bloquante;
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		
		#endregion Propri�t�s
	}
}
