using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Exception lev�e en cas d'erreur dans une Task (tache)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>05/05/2010 11:47:40</date>    
	public class Exception_Task: Exception_Base
	{
		#region Membres

		#endregion Membres

		#region Constantes
		/// <summary>
		/// "Le Gabarit template est absent"
		/// </summary>
		public const string MSG_Gabarit_Template_NULL	= "Le Gabarit template est absent";
		/// <summary>
		/// "Erreur lors de l'ex�cution du sql generic de la tache {0}"
		/// </summary>
		public const string MSG_Execute_SQL				= "Erreur lors de l'ex�cution du sql generic de la tache {0}";
		/// <summary>
		/// "L'ancre {0} est introuvable"
		/// </summary>
		public const string MSG_Ancre_Introuvable		= "L'ancre {0} est introuvable";
		/// <summary>
		/// "La position des ancres est incoh�rente l'ancre {0} et plus basse que l'ancre {1}"
		/// </summary>
		public const string MSG_Ancre_Incoherente		= "La position des ancres est incoh�rente l'ancre {0} et plus basse que l'ancre {1}";
		/// <summary>
		/// "Erreur lors de la preparation de la tache {0}"
		/// </summary>
		public const string MSG_Prepare_Task			= "Erreur lors de la preparation de la tache {0} de {1}";
		/// <summary>
		/// "Erreur lors reset du processing de la tache {0} du run {1}"
		/// </summary>
		public const string MSG_Reset_Process_Task		= "Erreur lors du reset du processing de la tache {0} de {1}";
		/// <summary>
		/// "Erreur lors du processing de la tache {0} du run {1}"
		/// </summary>
		public const string MSG_Process_Task			= "Erreur lors du processing de la tache {0} de {1}";
		/// <summary>
		/// "Erreur lors du post processing de la tache {0} du run {1}"
		/// </summary>
		public const string MSG_PostProcess_Task		= "Erreur lors du post processing de la tache {0} de {1}";
		/// <summary>
		/// "Erreur sur la tache {0} - manque le mode de la tache compartiment sur le run"
		/// </summary>
		public const string MSG_Load_Task_Compartiment	= "Erreur sur la tache {0} - manque le mode de la tache compartiment sur le run";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Exception_Task
		/// </summary>
		/// <param name="message">message de l'exception</param>
		/// <param name="args">arguments du message</param>
		public Exception_Task(string message, params object[] args): base(message, args)
		{
			
		}

		/// <summary>
		/// Cr�e une instance de Exception_Task
		/// </summary>
		/// <param name="ex">L'exception qui � provoquer l'erreur de did</param>
		/// <param name="message">message de l'exception</param>
		/// <param name="args">arguments du message</param>
		public Exception_Task(Exception ex, string message, params object[] args): base(ex, message, args)
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		
		#endregion Propri�t�s
	}
}
