using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Exception de base de toutes les exceptions li� � l'�x�cution d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>05/05/2010 11:47:40</date>    
	public class Exception_Base: Exception
	{
		#region Membres
		string		_info		= string.Empty;
		Error_Type	_type		= Error_Type.Unspecified;
		#endregion Membres

		#region Constantes
		const	string MSG_UnhandledException	= "Erreur inattendue";
		//Ne peut pas �tre �valuer comme une constante � cause du +
		static	string ChainMessagePattern		= "==> {0}" + Environment.NewLine;
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Exception_Base
		/// </summary>
		public Exception_Base(): base(MSG_UnhandledException)
		{
		}
		
		/// <summary>
		/// Cr�e une instance de Exception_Base
		/// </summary>
		/// <param name="message">Message d'information sur l'exception.</param>
		/// <param name="args">liste des arguments associ�s au message</param>
		public Exception_Base(string message, params object[] args): base(string.Format(message, args))
		{
		}

		/// <summary>
		/// Cr�e une instance de Exception_Base
		/// </summary>
		/// <param name="ex">L'exception qui � g�n�r�e cette exception.</param>
		public Exception_Base(Exception ex): base(MSG_UnhandledException, ex)
		{
		}
	
		/// <summary>
		/// Cr�e une instance de Exception_Base
		/// </summary>
		/// <param name="ex">L'exception qui � g�n�r�e cette exception.</param>
		/// <param name="message">Message d'information sur l'exception.</param>
		/// <param name="args">liste des arguments associ�s au message</param>
		public Exception_Base(Exception ex, string message, params object[] args): base(string.Format(message, args), ex)
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		
		/// <summary>
		/// Informations compl�mentaire sur l'erreur
		/// </summary>
		public string Info
		{
			get{return _info;}
			set{_info = value;}
		}

		/// <summary>
		/// Repr�sente le niveau de gravit� de cette Exception
		/// </summary>
		public Error_Type		Type
		{
			get{return _type;}
			set{_type = value;}
		}

		/// <summary>
		/// Permet d'obtenir la liste des messages maison contenu dans l'exception maison
		/// </summary>
		public string			ChainMessage
		{
			get
			{
				StringBuilder	__sb	= new StringBuilder();
				//Permet de sauter une ligne au d�but
				__sb.AppendLine();
				__sb.AppendFormat(ChainMessagePattern, this.Message);
				Exception_Base __ex = this;
				while (__ex.InnerException is Exception_Base)
				{
					__ex = (Exception_Base)__ex.InnerException;;
					__sb.AppendFormat(ChainMessagePattern, __ex.Message);
				}

				return __sb.ToString();
			}
		}
		#endregion Propri�t�s
	}
}
