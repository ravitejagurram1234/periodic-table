using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// repr�sente une Exception .net qui survient lorsqu'une erreur impr�vue se produit lors de la g�n�ration d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 15:25:45</date>    
	public class Exception_Run: Exception_Base
	{
		#region Membres

		#endregion Membres

		#region Constantes
		/// <summary>
		/// "Manque l'identifiant du gabarit template pour le gabarit {0}"
		/// </summary>
		public const string MSG_Missing_ID_Gabarit_Template = "Manque l'identifiant du gabarit template pour le gabarit {0}";
		/// <summary>
		/// "Impossible de sauvegarder le(s) fichier(s) {0}" 
		/// </summary>
		public const string MSG_Unable_To_Save_File			= "Impossible de sauvegarder le(s) fichier(s) {0}";
		/// <summary>
		/// "Erreur lors du d�marrage du run {0}"
		/// </summary>
		public const string MSG_Start_Run					= "Erreur lors du d�marrage du run {0}";
		/// <summary>
		/// "Erreur lors du chargement des propri�t�s du run {0}"
		/// </summary>
		public const string MSG_Load_Run_Properties			= "Erreur lors du chargement des propri�t�s du run {0}";
		/// <summary>
		/// "Les propri�t�s du run sont introuvables"
		/// </summary>
		public const string MSG_Null_Run_Properties			= "Les propri�t�s du run sont introuvables";
		/// <summary>
		/// "Erreur lors du chargement des InParams du run {0}"
		/// </summary>
		public const string MSG_Load_Run_InParams			= "Erreur lors du chargement des InParams du run {0}";
		/// <summary>
		/// "Erreur lors du chargement des Taches du run {0}"
		/// </summary>
		public const string MSG_Load_Run_Tasks				= "Erreur lors du chargement des Taches du run {0}";
		/// <summary>
		/// "Erreur lors du chargement des Templates du run {0}"
		/// </summary>
		public const string MSG_Load_Run_Template			= "Erreur lors du chargement des Templates du run {0}";
		/// <summary>
		/// "Erreur lors du rendu du run {0}"
		/// </summary>
		public const string MSG_Render_Run					= "Erreur lors du rendu du run {0}";
		/// <summary>
		/// "Erreur lors de la v�rification du run {0}"
		/// </summary>
		public const string MSG_Check_Run					= "Erreur lors de la v�rification du run {0}";
		/// <summary>
		/// "Erreur lors du chargement des taches exceptions"
		/// </summary>
		public const string MSG_Load_Run_Tasks_Exceptions	= "Erreur lors du chargement des taches exceptions";
		/// <summary>
		/// "Erreur lors de la preparation du gabarit du run {0}"
		/// </summary>
		public const string MSG_PrepareGabarit				= "Erreur lors de la preparation du gabarit du run {0}";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Exception_Run
		/// </summary>
		/// <param name="message">message de l'exception</param>
		/// <param name="args">arguments du message</param>
		public Exception_Run(string message, params object[] args): base(message, args)
		{
            this.Type = Error_Type.Bloquante;
        }

		/// <summary>
		/// Cr�e une instance de Exception_Run
		/// </summary>
		/// <param name="ex">exception � l'origine de cette nouvelle exception</param>
		/// <param name="message">message de l'exception</param>
		/// <param name="args">arguments du message</param>
		public Exception_Run(Exception ex, string message, params object[] args): base(ex, message, args)
		{
            this.Type = Error_Type.Bloquante;
        }

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
