using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Cette classe permet d'effectuer une consolidation des taches � executer 
	/// et permet de fournir une liste d'�tape � r�aliser sur le document quark 
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 18:05:33</date>    
	public class Run_Task
	{
		#region Membres
        Tasks				_tasks_Modifier = new Tasks();
        Tasks				_tasks_Update	= new Tasks();
		
		/// <summary>
		/// D�fini le nombre de bloc maximum � creer/modifier par Etape (sinon risque de plantage de quark !!) les tests on d�montr� que la valeur pouvaient �tre 6000 mais par s�curit� on abaisse cette valeur
		/// Si cette valeur est d�pass� alors une autre �tape est cr��e.
		/// Si la valeur est �gale � int.MinValue toutes les modifications sont effectu�es dans la m�me �tape
		/// </summary>
		int								_split_Step_Box_Number = EngineCoreSetting.Current.Step_Limit;

		/// <summary>
		/// repr�sente les �tapes temporaires pendant
		/// </summary>
		QXPFrk.BaseList<Run_Task_Step>	_steps_temp = null;
        /// <summary>
        /// repr�sente les �tapes finales  (l'ordre des �tapes est important)
        /// </summary>
		QXPFrk.BaseList<Run_Task_Step>	_steps		= null;
		Run_Base						_run;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Run_Task
		/// </summary>
		public Run_Task(Run_Base run)
		{
			_run = run;
		}

		#endregion Constructeur

		#region M�thodes

        /// <summary>
        /// Ajoute une t�che au conteneur de t�ches qui est le Run_Tasks
        /// L'ajout d'une tache va distinguer le type de celle ci, deux types possibles :
        ///     - Update : Aucune MAj de la structure du doc, pas d'ajout de spread etc
        ///     - Action : (task.Modifier = true) Modifie la structure du doc (op�ration CREATE/REMOVE etc)
        /// </summary>
        /// <param name="task">tache � ajouter</param>
        public void Add(Task_Base task)
        {
			if (task.Blocs_Modify.Count>0)
            {
                _tasks_Modifier.Add(task.ID, task);
            }
            
			if (task.Blocs_Update.Count>0)
            {
                _tasks_Update.Add(task.ID, task);
            }
        }

		/// <summary>
        /// A partir des taches (Objet Task) contenues dans la liste des taches Actions ou des taches Update,
        /// on va g�n�rer la liste des Run_Task_Step qui correspond � l'ensemble des �tapes � effectuer
        /// pour la modification, rempliassage du document.
        /// On aura une unique Run_Task_Step d'Update et (0 ou n) Run_Task_Step d'Actions
        /// La Run_Task_Step Update sera toujours en premi�re position dans la liste des steps (et contiendra toujours au moins un UPDATE sur le DID)
        /// </summary>
        /// <returns>Une liste d'�tape � �x�cuter sur quark server</returns>
        public QXPFrk.BaseList<Run_Task_Step> Get_Steps()
        {
            int __index		= 0;
			int __nb_Bloc	= 0;
			int __nb_Modify	= 0;
			
			//�tapes temporaire
			_steps_temp = new QXPFrk.BaseList<Run_Task_Step>();

			if (QXPFrk.Validation.IsNull(_steps))
            {
                //� cr��r puis � remplir
                _steps = new QXPFrk.BaseList<Run_Task_Step>();
            }
            else
            {
                //Elle est donc d�j� remplie
                return _steps;
            }

            // 1 - La premi�re �tape contient toutes les updates de box qui n�cessite pas de modification de structure du doc 
            //(pas d'ajout de spread, de pages...)            
            Run_Task_Step __run_Task_Step_Update	= new Run_Task_Step(_run);
			//par s�curit� on laisse les update � travers le web service, m�me si cela fonctionne en appel direct il faudrait faire plus de test en particulier sur les limites du nombre d'�l�ment qui peuvent �tre mise � jour en m�me temps
			__run_Task_Step_Update.Direct_Call = false; //Les mises � jours de champs ne sont pas effectu� en appel direct

            if (_tasks_Update.Count > 0)
            {
                foreach(Task_Base __task in _tasks_Update.Values)
				{
					__run_Task_Step_Update.Blocs_Update.AddRange(__task.Blocs_Update.Values);
				}
				                
            }
            
			//On execute les taches update en premiers
			if (__run_Task_Step_Update.Blocs_Update.Count > 0)
            {
                _steps.Add(__run_Task_Step_Update);
            }
			
			// 2 - On ajoutes les taches modifiant la pagination du document
			Run_Task_Step __run_Task_Step_Modify_Page	= new Run_Task_Step(_run);
			
			// 3 - On ajoutes les taches modifiant la structure des blocs
			Run_Task_Step __run_Task_Step_Modify		= new Run_Task_Step(_run);

            foreach (Task_Base __task_Modify in _tasks_Modifier.Values)
            {
                if (__task_Modify.Blocs_Modify.Count == 0)
                {
                    continue; //rien � faire ont continu
                }
				bool __haveModifyPagination = false;
				bool __haveModify			= false;

                foreach(Bloc_Base __bloc in __task_Modify.Blocs_Modify.Values)
				{
					if(__bloc.Pagination)
					{
						__haveModifyPagination = true;
						__run_Task_Step_Modify_Page.Blocs_Modify.Add(__bloc);
					}
					else
					{
						__nb_Modify		+= __bloc.Nb_Box;
						__haveModify	= true;
						__run_Task_Step_Modify.Blocs_Modify.Add(__bloc);
					}
					__nb_Bloc++;

					//On v�rifie le nombre de bloc d�j� ajouter � la tache de modification 
					//si ce nombre est sup�rieur � Max_Bloc_By_Step alors il faut creer une autre �tape 
					if(QXPFrk.Validation.IsSet(_split_Step_Box_Number) && __nb_Modify > _split_Step_Box_Number)
					{
						//on enl�ve l'ancien d�l�gate s'il existe
						__run_Task_Step_Modify.Evaluate_Info		-= __task_Modify.Evaluate_Info;
						//on d�fini le delegu�
						__run_Task_Step_Modify.Evaluate_Info		+= __task_Modify.Evaluate_Info;
						//on ajoute l'ancienne �tape aux �tapes temporaires
						_steps_temp.Add(__run_Task_Step_Modify);
						//on en recr�� une autre
						__run_Task_Step_Modify		= new Run_Task_Step(_run);
						//Il n'y � plus de modify car c'est une nouvelle collection
						__haveModify				= false;
						//r�initialisation � 0 du nombre de modify
						__nb_Modify					= 0;
					}
				}
				
				//liaison avec les evenements de mise � jour d'information entre �tape et taches
				if(__haveModifyPagination)
				{
					__run_Task_Step_Modify_Page.Evaluate_Info	+= __task_Modify.Evaluate_Info;
					__run_Task_Step_Modify_Page.Pagination		= true;
				}

				if(__haveModify)
				{
					//on enl�ve l'ancien d�l�gate s'il existe
					__run_Task_Step_Modify.Evaluate_Info		-= __task_Modify.Evaluate_Info;
					//on d�fini le delegu�
					__run_Task_Step_Modify.Evaluate_Info		+= __task_Modify.Evaluate_Info;
				}
				
            }

			//en premier l'�tape de pagination
			if(__run_Task_Step_Modify_Page.Blocs_Modify.Count > 0)	_steps.Add(__run_Task_Step_Modify_Page);
			
			//ensuite les �tapes temporaires
			if(_steps_temp.Count > 0)								_steps.AddRange(_steps_temp);	
			
			//enfin la derni�re �tape
			if(__run_Task_Step_Modify.Blocs_Modify.Count > 0)		_steps.Add(__run_Task_Step_Modify);	

			//num�rotation des etapes
			_steps.ForEach(delegate(Run_Task_Step step){step.Index = __index++;});

            return _steps;
        }
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Lors de l'�valuation des blocs � ex�cuter dans les taches peut-�tre que certaine ont �t� exclues
		/// Renvoit le nombre de Boxes impacter par cette exclusion toutes �tapes confondues
		/// </summary>
		public int NbExcludeBoxes
		{
			get
			{
				int __excludes = 0;
				{
					foreach (Run_Task_Step __step in _steps)
					{
						__excludes += __step.NbBoxExcluded;
					}
				}
				return __excludes;
			}
		}

		/// <summary>
		/// Retourne le nombre de boite maximum que pouvait contenir le document lors de la derni�re �tape
		/// </summary>
		public int LastNbMaxDocBoxes
		{
			get
			{
				if(_steps.Count > 0)
				{
					return _steps[_steps.Count - 1].NbMaxBoxes;
				}
				else
				{
					return 0;
				}
			}
		}
		#endregion Propri�t�s
	}
}
