using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Represente un erreur lors de l'�x�cution d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 16:24:45</date>    
	public class Error
	{
		#region Membres
        string      _message;
        Error_Type  _type       = Error_Type.Unspecified;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Error
		/// </summary>
		/// <param name="type">type d'erreur</param>
		/// <param name="message">message de l'erreur</param>
		/// <param name="args">argument du message de l'erreur</param>
        public Error(Error_Type type, string message, params object[] args)
		{
            _type = type;
            if(args.Length > 0)
			{
                _message = string.Format(message, args);
            }
			else
			{
                _message = message;
            }
        }

		/// <summary>
		/// Cr�e une instance de Error
		/// </summary>
		/// <param name="message">message de l'erreur</param>
		/// <param name="args">argument du message de l'erreur</param>
        public Error(string message, params object[] args): this(Error_Type.Unspecified, message, args){}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
        /// <summary>
        /// Message de l'erreur
        /// </summary>
		public string       Message{
            get{return _message;}
        }
        
		/// <summary>
		/// Le type de l'erreur
		/// </summary>
		public Error_Type   Type{
            get{return _type;}
        }

		#endregion Propri�t�s
	}
}
