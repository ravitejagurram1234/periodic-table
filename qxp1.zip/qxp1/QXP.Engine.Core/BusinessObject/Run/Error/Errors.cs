using System;
using System.Collections.Generic;
using System.Text;

using QXPAudit		= QXP.Audit;
using QXPFrk		= QXP.Framework;
using QXPDiagnostic = QXP.Framework.Diagnostic;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Represente une liste d'erreur qui c'est produites lors de l'�x�cution d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 16:24:45</date>    
	public class Errors: QXPFrk.BaseList<Error>
	{
		#region Membres

		#endregion Membres

		#region Constantes
		const string Log_Error_Pattern = "\n=>Error Type:{0} \nMsg:{1}";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Errors
		/// </summary>
		public Errors()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Ajout d'un log d'erreur
		/// </summary>
		/// <param name="type">type d'erreur</param>
		/// <param name="message">message de l'erreur</param>
		/// <param name="args">argument du message de l'erreur</param>
		public void Add(Error_Type type, string message, params object[] args)
		{
			try
			{
				Error __error = new Error(type, message, args);
				this.Add(__error);
			}
			//Maintenant le log d'erreur ne bloquera plus le fonctionnement de l'application
			catch(Exception ex)
			{
				QXPDiagnostic.Log.LogError(string.Format(Constantes.Error_Messages.Log_Error, message, args.Length), ex);
			}
		}

		/// <summary>
		/// Ajout d'un log d'erreur
		/// </summary>
		/// <param name="type">type d'erreur</param>
		/// <param name="exb">Exception maison � l'origine de l'erreur</param>
		public void Add(Error_Type type, Exception_Base exb)
		{
			try
			{
				Error __error = new Error(type, exb.ChainMessage);
				this.Add(__error);
			}
			//Maintenant le log d'erreur ne bloquera plus le fonctionnement de l'application
			catch(Exception ex)
			{
				QXPDiagnostic.Log.LogError(Constantes.Error_Messages.Log_Exception, ex);
			}			
			
		}

		/// <summary>
		/// Ajout d'un log d'erreur
		/// </summary>
		/// <param name="error">l'objet error � ajouter</param>
		public new void Add(Error error)
		{
			//on trace toutes les erreurs
			Trace_Helper.Log_Message(Log_Error_Pattern, error.Type, error.Message);
			
			base.Add(error);
		}
		/// <summary>
		/// Ajout d'un log d'erreur
		/// </summary>
		/// <param name="message">message de l'erreur</param>
		/// <param name="args">argument du message de l'erreur</param>
		public void Add(string message, params object[] args)
		{
			try
			{
				Error __error = new Error(message, args);
				this.Add(__error);
			}
			//Maintenant le log d'erreur ne bloquera plus le fonctionnement de l'application
			catch(Exception ex)
			{
				QXPDiagnostic.Log.LogError(string.Format(Constantes.Error_Messages.Log_Error, message, args.Length), ex);
			}
		}

		/// <summary>
		/// Evaluer la liste des messages contenus dans les erreurs
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			StringBuilder __message = new StringBuilder();
			foreach (Error err in this)
            {
                if(err.Type.Equals(Error_Type.Bloquante))
                {                    
                    __message.Append("\nErreur Bloquante: ");
                    __message.Append(err.Message);
                }
                else if (err.Type.Equals(Error_Type.Critique))
                {
                    __message.Append("\nErreur Critique: ");
                    __message.Append(err.Message);
                }
				else
                {
                    __message.Append("\nErreur : ");
                    __message.Append(err.Message);
                }
            }
			return __message.ToString();
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
