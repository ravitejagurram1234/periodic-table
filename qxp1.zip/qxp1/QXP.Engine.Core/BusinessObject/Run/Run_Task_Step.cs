using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini une �tape de modification d'un document quark qui contient une ou plusieurs tache � effectuer
	/// </summary>
	/// <remarks>
	/// en fonction du type de tache (apr�s avoir �t� prepar�e et process�e) les taches sont regroup�es en �tape
	/// par exemple toutes les taches de types update sont regroup� dans la m�me �tape d'�x�cution
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:28:17</date>    
	public class Run_Task_Step
	{
		#region Membres
		int								_index			= 0;
		bool							_direct_Call	= true;
		bool							_pagination		= false;
		QXPFrk.BaseList<Bloc_Base>		_blocs_Update	= new QXPFrk.BaseList<Bloc_Base>();
		QXPFrk.BaseList<Bloc_Base>		_blocs_Modify	= new QXPFrk.BaseList<Bloc_Base>();

		QXPS_Modifier									_modifier			= new QXPS_Modifier();
		Run_Task_Step									_prepare_Step		= null;
        QXPFrk.BaseList<QXPSMSDK.NameValueParam>	_nameValues			= new QXPFrk.BaseList<QXPSMSDK.NameValueParam>();
		
		public event		QXPFrk.BasicHandler			Evaluate_Info = null;

		int								_nbBoxAdded		= 0;
		int								_nbBoxUpdate	= 0;
		int								_nbBoxExcluded	= 0;
		int								_nbBoxDoc		= 0;

		int								_nbMaxBoxes		= int.MinValue;
		Run_Base						_run			= null;

		#endregion Membres

		#region Constantes
		const int PagePaire					= 0;
		const int PageImpaire				= 1;
		//valeur du d�calage de pages simple
		const int OffSetPage				= 1;
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Run_Task_Step
		/// </summary>
		/// <param name="run">Le run associ� � l'�tape.</param>
		public Run_Task_Step(Run_Base run)
		{
			_run = run;
		}

		#endregion Constructeur

		#region M�thodes

        /// <summary>
        /// Demande l'�valuation des informations n�cessaire (spreadID/Layout) correspondant � la derni�re version du gabarit.
		/// Et du "Modifier" ainsi que des "nameValues"
		/// en cas d'exclusion de l'�tape il faut quand m�me calculer le nombre de boite exclues
        /// </summary>
		/// <param name="ignoreStep">Force l'exclusion de cette �tape (true)</param>
		public void Prepare(bool ignoreStep)
        {

			if (QXPFrk.Validation.IsNotNull(Evaluate_Info))
			{
			    Evaluate_Info();
			}
			this.Evaluate_Modifier_And_Values();
			this.Evaluate_Limitation(ignoreStep);
			
			//Maintenant que tout � �t� �valu� on peut ajouter les blocs dans le modifier
			_modifier.AddRange(_blocs_Modify);

        }

		/// <summary>
		/// Evaluation des �l�ments du Modifier et des nameValues
		/// </summary>
		private void Evaluate_Modifier_And_Values()
		{
			QXPSMSDK.NameValueParam __nameValue;

			//Evaluation des pages dans les bloc en modify
			foreach(Bloc_Base __bloc in  _blocs_Modify)
			{
				__bloc.Evaluate_Page();
			}
			
			//Traitement particulier dans le cas de step de pagination
			if(_blocs_Modify.Count> 0 && this.Pagination) Update_Bloc_Pagination(_blocs_Modify);

			foreach(Bloc_Base __bloc in  _blocs_Update)
			{
		        //si c'est n'est pas un modifier cela correspond � des bloc name/value qui sera ex�cuter en 1 �re �tape
		        Bloc_Box __bloc_box = __bloc as Bloc_Box;
		        //Si ce n'est pas un bloc_box ce n'est pas normal
		        if(QXPFrk.Validation.IsNotNull(__bloc_box))
		        {
		            __nameValue				= new QXPSMSDK.NameValueParam();
		            __nameValue.paramName	= __bloc.Name;
		            __nameValue.textValue	= __bloc_box.Value;
		            _nameValues.Add(__nameValue);					
		        }
			}
			//Mise � jour du nombre de boite qui doivent �tre modifi�es 
			_nbBoxUpdate += _nameValues.Count;
		}

		/// <summary>
		/// Permet d'�valuer les op�rations effectuer sur les boites est donc de connaitre si nous d�passons la taille maximale autoris�e
		/// Si tel est le cas les boites plus aucun box n'est ajout�e
		/// </summary>
		/// <param name="ignoreStep">Force l'exclusion de cette �tape (true)</param>
		private void Evaluate_Limitation(bool ignoreStep)

		{
			Bloc_Base				__bloc			= null;
			int						__nbBoxBloc		= 0;

			_nbBoxDoc			= _run.Gabarit.XML.Project_Info.NbBox;

			Trace_Helper.Log_Message("Evaluation des limitations par rapport au document actuel ({0} boxe(s), {1} complexity) sur {2} boxes autoris�es", _run.Gabarit.XML.Project_Info.NbBox, _run.Gabarit.Box_Complexity, this.NbMaxBoxes);

			#region bloc_modify
			for (int __i = 0; __i < _blocs_Modify.Count; __i++)
			{
				__bloc		= _blocs_Modify[__i];
				__nbBoxBloc = __bloc.Nb_Box;
				//Dans le cas d'une �tape de pagination on ne controle pas la limitation du nombre de boite maximum
				//Car justement il peut y en avoir � supprimer hors dans le cas Pagination les nouvelle pages sont ajouter avant d'enlever les anciennes ^^ 
				if (!this.Pagination && (_nbBoxDoc > this.NbMaxBoxes || ignoreStep))
				{
					__bloc.Exclude = true;
					_nbBoxExcluded += __nbBoxBloc;
				}
				else
				{
					switch (__bloc.Action)
					{
						case Bloc_Action.CREATE:
							_nbBoxAdded		+= __nbBoxBloc;
							_nbBoxDoc		+= __nbBoxBloc;
							break;
						//Les autres autres cas
						default:
							_nbBoxUpdate	+= __nbBoxBloc;
							break;
					}
				}
			}			
			
			#endregion

			#region bloc_update
			//Il y � d�j� trop de boxes dans le document nous ne pouvons pas risquer d'autres modifications
			if (_nbBoxDoc > this.NbMaxBoxes)
			{
				_blocs_Update.Clear();
			}
			else
			{
				//pas de recontrole de la limite des boites en update
				foreach(Bloc_Box __bloc_Box in _blocs_Update)
				{
					 if(QXPFrk.Validation.IsNotNull(__bloc_Box))
					 {
						_nbBoxUpdate += __nbBoxBloc;
					 }
		        }
			}

			#endregion


		}

		/// <summary>
		/// Permet de mettre � jour les num�ros de page des taches en fonction des cr�ations de pages des autres taches. (voir la remarque ci-dessous pour plus d'informations)
		/// </summary>
		/// <param name="blocs">liste des blocs � mettre dont il faut mettre � jours la pagination </param>
		/// <remarks>
		/// La mise � jour de la pagination � 2 mode de fonctionnement (D�fini par la propri�t� Run.Properties.Nb_Page_By_Spread):
		/// 
		/// 1 => lorsque le document finale poss�de 1 page par spread la mise � jour de la pagination d�duit pour chaque tache le nombre de page cr��es est met � jour les num�ros de pages des autres taches dont les pages sont plus grandes
		/// quelque soit le type de tache les blocs sont toujours organis� de la mani�re suivante:
		/// - s'il y � des cr�ations de page elles sont toujours d�fini avant les suppressions de page
		/// - les pages en creation et en suppression sont toujours contigues dans une m�me tache
		/// 
		/// 2 => lorsque le document finale poss�de 2 pages par spread en vis � vis (aussi appel� page en regard) le traitement du mode 1 page/Spread reste appliqu�, mais des contraintes suppl�mentaires doivent �tre v�rifi�es.
		/// La difficult� de ce mode est que quelque soit la position de l'ajout ou de la suppression des pages dans le document, toutes les pages doivent se suivre est �tre 2 par spread , hors l'ajout de page dans un spread existant n'est pas correctement pris en compte par quark server car il ne d�cale pas les pages suivantes sur le spread suivant (alors que la suppression le fait)
		/// en fonction de la position de la page dans le spread il faut d�finir une propri�t� suppl�mentaire "POSITION" (� gauche "LEFTOFSPINE" ou RIGHTOFSPINE � droite) quark server refuse de cr�er dans un spread existant une page LEFTOFSPINE, il faut donc toujours cr�er un nouveau spread pour ce type de page, ce qui � compliquer l'algorithme.
		/// Il faut �galement g�rer le cas du spread 1 qui ne poss�de qu'une page contrairement � tous les autres spreads qui en poss�de 2.
		/// 
		/// Il faut �valuer si la premi�re page cr��e est paire ou impaire:
		/// - si elle est paire toutes les cr�ations de pages sont toujours effectu�e en premier puis ensuite les suppressions
		/// - si elle est impaire la premiere suppression doit toujours �tre situ�e avant les cr�ations (contrainte de quark server) puis viennent ensuite les autres suppressions
		/// 
		/// Il faut �galement �valuer si la derni�re page cr��e est paire ou impaire:
		/// - si elle est impaire, il n'y � pas d'op�ration suppl�mentaire � r�aliser
		/// - si elle est paire, il faut cr�� une page fictive suppl�mentaire (propri�t� Create_Next_Dummy_Page du dernier bloc page qui est pair) est l'effacer imm�diatement afin de d�clencher un d�calage � gauche suppl�mentaire de l'organisation des pages du document (ce d�calage est effectu� implicitement par quark server lors de la suppression de page ram�ne la premi�re page du spread suivant dans la derni�re page du spread courant)
		/// </remarks>
		private void Update_Bloc_Pagination(QXPFrk.BaseList<Bloc_Base> blocs)
		{

			//�tape 1 regrouper les blocs par taches
			// � l'int�rieur d'une m�me tache il n'y � pas de d�calage de page puisqu'il y a d�j� la notion de page relative !!
			Dictionary<Task_Base, QXPFrk.BaseList<Bloc_Base>>	__task_Blocs			= new Dictionary<Task_Base, QXPFrk.BaseList<Bloc_Base>>();
			QXPFrk.BaseList<Bloc_Base>							__blocs					= null;
			QXPFrk.BaseList<Task_Base>							__tasks					= new QXPFrk.BaseList<Task_Base>();
			bool												__lag_Spread			= false;
			int													__preprare_offsetTotal	= 0;

			//Cette �tape aura peut-�tre besoin d'une �tape de pr�paration
			Run_Task_Step __prepare_Step = new Run_Task_Step(_run);

			foreach(Bloc_Base __bloc in blocs)
			{
				if(__task_Blocs.ContainsKey(__bloc.Task))
				{
					__blocs = __task_Blocs[__bloc.Task];
				}
				else
				{
					__blocs = new QXPFrk.BaseList<Bloc_Base>();
					__task_Blocs.Add(__bloc.Task, __blocs);
				}
				__blocs.Add(__bloc);
			}

			//ajout de la clefs des taches dans une collection qui pourra �tre tri�e
			__tasks.AddRange(__task_Blocs.Keys);
			
			//Trie des taches par rapport � la page de d�part
			__tasks.Sort(delegate(Task_Base task1, Task_Base task2) { return task1.Properties.PageNum.CompareTo(task2.Properties.PageNum); });

			//�tape 2 - Nous pouvons analyser les bloc_pages contenu et mettre � jour les pages des autres bloc_page
			foreach(Task_Base __task in __tasks)
			{
				//R�pr�sente le nombre de pages cr��s par la tache
				int __nbPage_Creer							= 0;
				//R�pr�sente le nombre de pages supprim�es par la tache
				int __nbPage_Supprimer						= 0;
				//Repr�sente l'identifiant minimum des pages de la tache 
				int __min_Page_ID							= int.MaxValue;
				//Repr�sente l'identifiant minimum des pages cr��es par la tache 
				int __min_Creation_Page_ID					= int.MaxValue;
				//Repr�sente l'identifiant original minimum des pages cr��es par la tache 
				int __min_Creation_Page_ID_Originale		= int.MaxValue;
				//Permet de m�moris� le num�ro de la derni�re par cr�� (permettra �ventuellement par la suite d'ajouter une page suppl�mentaire dans le cas des pages en vis � vis si la derni�re page est � gauche cad est paire)
				int __max_Creation_Page_ID					= int.MinValue;
				//Nouvelle identifiant de la page maximum
				int __new_Max_Creation_Page_ID				= int.MinValue;
				//R�f�rence de la page maximum cr��e
				Bloc_Page	__max_Creation_Page				= null;


				//on parcours tous les blocs de type Page de la tache pour d�duire le d�calage de page
				foreach(Bloc_Base __bloc in __task_Blocs[__task])
				{
					//c'est un bloc_page il y a donc creation ou suppression de page
					if(__bloc is Bloc_Page)
					{
						switch(__bloc.Action)
						{
							case Bloc_Action.CREATE:
								//Incr�mentation du compteur de page cr�es
								__nbPage_Creer++;
								//Evaluation de la nouvelle page maximum
								__new_Max_Creation_Page_ID = Math.Max(__max_Creation_Page_ID, __bloc.Page_ID);
								//nous gardons une r�f�rence vers la derni�re page ajout�e afin de pouvoir appliquer plus tard une propri�t� dans le cas des doubles pages
								if (__new_Max_Creation_Page_ID > __max_Creation_Page_ID)
								{
									__max_Creation_Page_ID	= __new_Max_Creation_Page_ID;
									__max_Creation_Page		= __bloc as Bloc_Page;
								}
								//Evaluation de la nouvelle page minimum
								__min_Creation_Page_ID				= Math.Min(__min_Creation_Page_ID, __bloc.Page_ID);
								//Evaluation de la nouvelle page minimum
								__min_Creation_Page_ID_Originale	= Math.Min(__min_Creation_Page_ID_Originale, __bloc.Page_ID_Originale);
								break;
							
							case Bloc_Action.REMOVE:
								//Incr�mentation du compteur de page supprim�es
								__nbPage_Supprimer++;
							    break;
						}
						__min_Page_ID = Math.Min(__min_Page_ID, __bloc.Page_ID);
					}
				}

				//nous savons maintenant le nombre de page cr��es
				//Si le d�calage est 0 alors il n'y a aucun bloc � mettre � jour dans les autres taches
				//S'il y � des pages � supprimer cela ne d�calera pas les autres taches
				if(__nbPage_Creer > 0)
				{

					#region R�organisation des pages en vis � vis
					//si nous sommes avec des pages en vis � vis il faut augmenter le d�calage de page dans le cas ou la derni�re page ajouter est paire
					//est d�caler les pages de cette tache
					if (_run.Properties.Nb_Page_By_Spread == Run_Properties.PaginationDouble)
					{
						int __position_premiere_creation			= __min_Creation_Page_ID;
						int __position_premiere_creation_originale	= __min_Creation_Page_ID_Originale;
						int __position_derniere_creation			= __max_Creation_Page_ID;
						//th�orique
						int __position_premiere_suppression			= __max_Creation_Page_ID + 1;

						//Permet de d�terminer la position de la premi�re cr�ation
						int __checkPremiereCreation					= __lag_Spread?PagePaire:PageImpaire;

						//Recherche si la premi�re page � cr�� est impaire (doit tenir compte du lag) dans ce cas il faut r�organiser les num�ro de pages
						//afin d'effectuer la premi�re suppression avant les ajouts 
						if ((__position_premiere_creation % 2) == __checkPremiereCreation)
						{
							//Cas ou la premi�re page cr��e est sup�rieur � 1
							if (__min_Creation_Page_ID > 1)
							{
								if (__nbPage_Supprimer > 0)
								{
									foreach (Bloc_Base __bloc in __task_Blocs[__task])
									{
										//la premi�re page supprim�e devient la premi�re page ajout�e
										if (__bloc.Page_ID == __position_premiere_suppression)
										{
											__bloc.Page_ID = __position_premiere_creation;
										}
										//Les autres pages en cr�ation doivent donc se d�caler
										else if ((__bloc.Page_ID < __position_premiere_suppression) && (__bloc.Page_ID >= __position_premiere_creation))
										{
											__bloc.Page_ID += OffSetPage;
										}
									}
									__position_derniere_creation += OffSetPage;
								}
								else
								{
									//l� �a ce corse !!
									//Dans le cas ou une tache ne supprime aucune tache il faut effectuer un traitement de pr�paration du document qui doit tenir compte des positions de ou devrons �tre effectu�s l'ajout des premi�re pages
									
									//premi�re id de la page originale (avant la pr�paration)
									int __offsetDummyPageIDOriginale;
									//premi�re id de la page (apr�s la pr�paration)
									int __offsetDummyPageID;
									//d�calage des pages avant la pr�paration
									int __offsetDummyPageOriginale	= 0;
									//d�calage des pages apr�s la pr�paration
									int __offsetDummyPage			= 0;
									
									//Dans le cas ou la premi�re page � ajouter est impaire (en tenant compte du lag_spread) il faut encore d�caler de 1
									if ((__position_premiere_creation % 2) == __checkPremiereCreation)
									{
										__offsetDummyPage			= - 1;

										//Dans le cas ou la premi�re page � ajouter est impaire 
										if ((__position_premiere_creation_originale % 2) == PagePaire)
										{
											__offsetDummyPageOriginale	= - 2;
										}
										else
										{
											__offsetDummyPageOriginale	= - 1;
										}

										__offsetDummyPageID				= __position_premiere_creation + __offsetDummyPage; 
										__offsetDummyPageIDOriginale	= __position_premiere_creation_originale + __offsetDummyPageOriginale + __preprare_offsetTotal;

										__preprare_offsetTotal		+= 2;

										//c'est le cas qui � besoin d'une �tape de pr�paration car nous devons cr�er une premi�re page � droite sans en supprimer aucune
										//il faut ajouter � l'�tape de pr�paration 2 pages et en supprimer 1 afin de produire le d�calage n�cessaire � l'ajout des nouvelles pages
										//PA Page Add
										Bloc_Page __page = new Bloc_Page(__task, "PA_Offset_"+__offsetDummyPageIDOriginale);
										__page.Action					= Bloc_Action.CREATE;
										__page.Create_Next_Dummy_Page	= true;
										__page.Page_ID					= __offsetDummyPageIDOriginale;
										
										//ajout de cette page particuli�re directement dans le modifier de l'�tape de pr�paration
										//Cette manipulation ne doit �tre fait que dans le cas d'utilisation conjoint avec _prepare_Step
										__prepare_Step.Modifier.Add(__page);

										//L'�tape en cours � maintenant une �tape de pr�paration
										_prepare_Step = __prepare_Step;

										//traitement particulier l'�tape en cours doit supprimer la page restant cr��e dans l'�tape pr�paratoire
										//attention l'ajout se fait directement dans le modifier de notre �tape
										//PR Page Remove
										__page = new Bloc_Page(__task, "PR_Offset_"+__offsetDummyPageID);
										__page.Action					= Bloc_Action.REMOVE;
										__page.Lag_Spread				= __lag_Spread;
										//Il faut penser � tenir compte du d�calage suppl�mentaire
										__page.Page_ID					= __offsetDummyPageID ;
										
										//ajout de cette page particuli�re directement dans le modifier de l'�tape de pr�paration
										//Cette manipulation ne doit �tre fait que dans le cas d'utilisation conjoint avec _prepare_Step
										this.Modifier.Add(__page);
										foreach (Bloc_Base __bloc in __task_Blocs[__task])
										{
											if ((__bloc.Page_ID < __position_premiere_suppression) && (__bloc.Page_ID >= __position_premiere_creation))
											{
												__bloc.Page_ID += OffSetPage;
											}
										}

										__position_derniere_creation += OffSetPage;
										//Mise � jour du nombre de page cr�es (+2 ajout -1 suppression) = 1
										__nbPage_Creer++;
									}
								}
							}
							else
							{
								// s'il n'y � qu'une page de cr��e
								if (__min_Creation_Page_ID == 1 && __max_Creation_Page_ID == 1)
								{
									__lag_Spread = true;

									foreach (Bloc_Base __bloc in __task_Blocs[__task])
									{
										if (__bloc.Page_ID > 1)
										{
											__bloc.Lag_Spread = true;
										}
									}
								}
							}
						}

						//Recherche si la derni�re page � cr�� est paire (doit tenir compte du lag_spread)
						if ((__position_derniere_creation % 2) != __checkPremiereCreation)
						{
							//afin de na pas laisser de spread avec une seule page il faut demander la cr�ation d'une page en plus et la supprimer de suite 
							//cette action permet de r�ordonner les pages suivantes dans les spreads suivant
							__max_Creation_Page.Create_Next_Dummy_Page = true;
							foreach (Bloc_Base __bloc in __task_Blocs[__task])
							{
								if (__bloc.Page_ID > __position_derniere_creation)
								{
									__bloc.Page_ID		+= OffSetPage;
								}
							}
							//�tant donn�e que la page q'une fausse page va �tre cr�� nous devons rajouter 1 au nombre de page cr��e par cette tache pour la vue des autres taches
							__nbPage_Creer++;
						}

					}
					#endregion R�organisation des pages en vis � vis

					//Parcours de tous les bloc des autres taches afin de mettre � jour leurs nouvelles positions
					foreach (Task_Base __task_Sub in __task_Blocs.Keys)
					{
						//la tache en cours ne doit pas �tre d�cal�e elle � d�j� �t� �ventuellement r�organis�e au dessus
						if (__task_Sub != __task)
						{
							foreach (Bloc_Base __bloc in __task_Blocs[__task_Sub])
							{
							    if (__bloc.Page_ID >= __min_Page_ID && __bloc.Page_ID > 1)
							    {
							        __bloc.Page_ID += __nbPage_Creer;
							    }

								//Ne met � jour cette information que si le bloc n'est pas en page 1
								if (__bloc.Page_ID > 1)
								{
									__bloc.Lag_Spread = __lag_Spread;
								}
							}
						}
					}
				}

			}
			
		}
		#endregion M�thodes

		#region Propri�t�s
        
		/// <summary>
        /// Liste des blocs de type Action (alt�ration du document final) contenu dans l'�tape de g�n�ration
        /// </summary>
		public List<Bloc_Base> Blocs_Modify
        {
            get { return _blocs_Modify; }
        }

        /// <summary>
        /// Liste des blocs de type update (mise � jour de valeur) contenu dans l'�tape de g�n�ration
        /// </summary>
		public List<Bloc_Base> Blocs_Update
        {
            get { return _blocs_Update; }
        }

		/// <summary>
		/// Permet d'obtenir le Modifier qui contient les modifications de structure qui doivent �tre r�alis�es par cette �tape
		/// </summary>
		/// <returns></returns>
		public QXPS_Modifier Modifier 
		{ 
			get{return _modifier;}
		}

		/// <summary>
		/// Permet d'obtenir les noms et les valeurs de bloc � modifier (sans changement de structure)
		/// </summary>
		public QXPFrk.BaseList<QXPSMSDK.NameValueParam> NameValues
		{
			get { return _nameValues; }
		}

		/// <summary>
		/// Cette etape doit-elle effectuer ses appels directement � quarkXpress server (true) ou � travers QuarkXpress manager (false).
		/// </summary>
		public bool				Direct_Call
		{
			get{return _direct_Call;}
			set{_direct_Call = value;}
		}

		/// <summary>
		/// Cette �tape contient-t-elle des bloc de pagination (def false). 
		/// si oui un traitement sera effectu� ult�rieurement pour r�num�roter les pages !!!!
		/// </summary>
		public bool				Pagination
		{
			get{return _pagination;}
			set{_pagination = value;}
		}

		/// <summary>
		/// Repr�sente l'index de l'�tape
		/// </summary>
		public int				Index
		{
			get{return _index;}
			set{_index = value;}
		}

		/// <summary>
		/// D�fini l'�tape � �x�cuter avant de pouvoir �x�cuter l'�tape en cours
		/// Cette valeur est null sauf pour certaine �tape de pagination dans le cas des doubles pages
		/// Cette �tape est tr�s particuli�re puisqu'elle ne suis pas les r�gle de pr�paration des autres �tapes
		/// Elle ne peut �tre d�fini que par la fonction Update_Bloc_Pagination
		/// </summary>
		public Run_Task_Step	Prepare_Step
		{
			get
			{
				return _prepare_Step;
			}
		}

		/// <summary>
		/// D�fini le nombre de box ajouter par l'�tape
		/// </summary>
		public int				NbBoxAdded
		{
			get
			{
				return _nbBoxAdded;
			}
			private set
			{
				_nbBoxAdded = value;
			}
		}

		/// <summary>
		/// D�fini le nombre de boite mise � jour par l'�tape
		/// </summary>
		public int				NbBoxUpdate
		{
			get
			{
				return _nbBoxUpdate;
			}
			private set
			{
				_nbBoxUpdate = value;
			}
		}

		/// <summary>
		/// d�fini le nombre de boite ignore par l'�tape a cause d'un d�passement du nombre maximal de bloc dans le document
		/// </summary>
		public int				NbBoxExcluded
		{
			get
			{
				return _nbBoxExcluded;
			}
			private set
			{
				_nbBoxExcluded = value;
			}
		}

		/// <summary>
		/// Nombre de boite actuellement dans le document 
		/// Cette valeur est disponible apr�s avoir �valuer les limitations
		/// </summary>
		public int				NbBoxDoc
		{
			get
			{
				return _nbBoxDoc;
			}
		}

		/// <summary>
		/// Evalue le nombre de boite maximum que peut contenir ce document qxp
		/// </summary>
		public int				NbMaxBoxes
		{
			get
			{
				if (QXPFrk.Validation.IsNotSet(_nbMaxBoxes))
				{
					decimal __box_Complexity = _run.Gabarit.Box_Complexity;
					//controle de la coh�rence elle ne doit pas �tre en dehors de certaines valeurs
					if (__box_Complexity < 0.8m )
					{
						Trace_Helper.Log_Message(Constantes.Error_Messages.BoxComplexityOutOfRange, _run.Gabarit.Box_Complexity);						
						_nbMaxBoxes = (int)(EngineCoreSetting.Current.Nb_Box_Max / 0.8m);
					}
					else if(__box_Complexity > 1.3m)
					{
						Trace_Helper.Log_Message(Constantes.Error_Messages.BoxComplexityOutOfRange, _run.Gabarit.Box_Complexity);						
						_nbMaxBoxes = (int)(EngineCoreSetting.Current.Nb_Box_Max / 1.3m);
					}
					else
					{
						_nbMaxBoxes = (int)(EngineCoreSetting.Current.Nb_Box_Max / __box_Complexity);
						
					}
				}

				return _nbMaxBoxes;

			}
		}

		/// <summary>
		/// Si aucune modifications de blocs contenus dans l'�tape n'est effectu�e alors l'�tape est exclue de l'ex�cution
		/// </summary>
		public bool				Full_Exclude
		{
			get
			{
				return (_nbBoxAdded == 0 && _nbBoxUpdate == 0);
			}
		}

		/// <summary>
		/// D�fini si au moins une Box � �t� exclue (dans ce cas les �tapes suivante doivent �tre exclues �galements
		/// Si une des �tapes atteind la limite de modification il ne faut pas continuer les modifications m�me le recalcule du nombre de boite maximum (NbMaxBoxes) �volue entre les �tapes
		/// </summary>
		public bool				Partial_Exclude
		{

			get
			{
				return (_nbBoxExcluded > 0);
			}
		}
		#endregion Propri�t�s
	}
}
