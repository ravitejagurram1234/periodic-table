using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un param�tre d'un run ce param�tre est ensuite pass� � toutes les taches SQL du run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:05:45</date>    
	public class InParam
	{
		#region Membres
        string          _name;
        Data_Type       _type;
        string          _string_value;
        object          _value;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

        /// <summary>
        /// Cr�ation d'un nouveau InParam � partir de son nom, son type et ca valeur
        /// </summary>
		/// <param name="name">nom du param�tre</param>
		/// <param name="type">type du param�tre</param>
		/// <param name="value">valeur textuelle du param�tre</param>
		public InParam(string name, int type, string value): this(name, (Data_Type)type, value){}
        
		/// <summary>
		/// 
		/// </summary>
		/// <param name="name">nom du param�tre</param>
		/// <param name="type">type du param�tre</param>
		/// <param name="value">valeur textuelle du param�tre</param>
		public InParam(string name, Data_Type type, string value)
		{
            _name           = name;
            _type           = type;
            _string_value   = value;
            _value          = Data_Type_Helper.InputToTypedValue(_string_value, _type);
        }

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
        
		/// <summary>
		/// Nom du InParam
		/// </summary>
		public string               Name{
            get{return _name;}
        }
        
		/// <summary>
		/// type de donn�e du InParam (permet de convertir la valeur chaine en type de donn�e natif qui pourra �tre envoy�e � oracle)
		/// </summary>
		public Data_Type            Type{
            get{return _type;}
        }
        
		/// <summary>
		/// Valeur chaine du InParam
		/// </summary>
		public string               String_Value{
            get{return _string_value;}
        }
        
		/// <summary>
		/// Valeur du InParam
		/// </summary>
		public object               Value{
            get{return _value;}
        }
		#endregion Propri�t�s
	}
}
