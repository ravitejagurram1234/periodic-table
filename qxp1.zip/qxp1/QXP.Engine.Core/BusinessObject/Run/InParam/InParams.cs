using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk		= QXP.Framework;
using QXPAudit		= QXP.Audit;
using QXPDataOracle = QXP.Framework.Data.Oracle;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une collection de <see cref="InParam"/>
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:33:08</date>    
	public class InParams : Dictionary<string, InParam>
	{
		#region Membres
        QXPFrk.BaseList<QXPDataOracle.OraParameter> _oraParameters;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de InParams
		/// </summary>
		public InParams()
		{
            _oraParameters = new QXPFrk.BaseList<QXPDataOracle.OraParameter>();
		}

		#endregion Constructeur

		#region M�thodes
		
		/// <summary>
		/// Initialisation des OraParameters li�s au InParams. 
		/// Chaque InParam g�n�re un OraParameter qui pourra �tre clon� � la demande
		/// </summary>
        public void InitOraParameters()
        {
            QXPDataOracle.OraParameter __param;

            foreach (KeyValuePair<string, InParam> __entry in this)
            {
                __param = InitOraParam(__entry);
                _oraParameters.Add(__param);
            }
        }

        /// <summary>
        /// Permet d'obtenir un OraParameter � partir d'un InParam
        /// </summary>
        /// <param name="entry">object contenant le InParam</param>
        /// <returns>l'OraParameter </returns>
		private QXPDataOracle.OraParameter InitOraParam(KeyValuePair<string, InParam> entry)
        {
            string   __paramName = entry.Key;
            InParam  __inParam   = entry.Value;
            
            return  new QXPDataOracle.OraParameter(__paramName, __inParam.Value);
        }

        /// <summary>
        /// Duplication de la collection de OraParameter �valuer � partir de la collection des InParams
        /// </summary>
        /// <returns>liste des OraParameter</returns>
		public QXPDataOracle.OraParameter[] CloneParameters()
        {
            QXPFrk.BaseList<QXPDataOracle.OraParameter> __tempParams = new QXPFrk.BaseList<QXPDataOracle.OraParameter>();
            foreach (QXPDataOracle.OraParameter __param in _oraParameters)
            {
                __tempParams.Add(__param.Clone());
            }
            return __tempParams.ToArray();
        }
		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// Nouvelle liste de param�tres oracles �valu�e � partir des InParams
		/// </summary>
        public QXPDataOracle.OraParameter[] OraParameters
        {
            get { return this.CloneParameters(); }
        }        
		#endregion Propri�t�s
	}
}
