using System;

using QXPFrk	= QXP.Framework;


using QXPCore				= QXP.Core;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr?sente un run quark, Il regroupe toutes les param?tres n?cessaires ? la g?n?ration/modification de document quark 
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:18:09</date>    
	public class Run: Run_Base
	{
		#region Membres
		

		#endregion Membres

		#region Constantes
		const string PoolPattern = "R_{0}\\";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur
		/// <summary>
		/// Repr?sente un run standard avec ex?cution et rendu
		/// </summary>
		/// <param name="id_run"></param>
		public Run(int id_run): base(id_run)
		{

		}
		#endregion Constructeur

		#region M?thodes

		#region overrides
		
		/// <summary>
		/// D?but du Run
		/// </summary>
		protected override void Start()
		{
			Proxy_Run	__proxy = new Proxy_Run();            
			__proxy.Start_Run(this);
		}

		/// <summary>
		/// Chargement des propri?t?s du run
		/// </summary>
		protected override void LoadProperties()
		{
			Proxy_Run	__proxy = new Proxy_Run();
			__proxy.Load_Run_Properties(this);
		}

		/// <summary>
		/// Chargment et pr?paration du gabarit
		/// </summary>
		protected override void PrepareGabarit()
		{
			
			//Chargement du gabarit ou du pr?c?dent document g?n?r?
			Proxy_Gabarit	__proxy_Gabarit = new Proxy_Gabarit();
			Document		__doc_gabarit = null;

			switch(this.Properties.Gabarit_Source)
			{
				case QXPCore.Gabarit_Source.Gabarit:
					__doc_gabarit = __proxy_Gabarit.Get_Gabarit(this.Properties.ID_Gabarit);
					break;
				case QXPCore.Gabarit_Source.DocumentCourant:
					__doc_gabarit = __proxy_Gabarit.Get_Gabarit_Document(this.Properties.ID_Suivi);
					break;
				case QXPCore.Gabarit_Source.DocumentPrecedentCertifie:
					__doc_gabarit = __proxy_Gabarit.Get_Gabarit_Document_Certifie(this.Properties.ID_Suivi);
					break;
				case QXPCore.Gabarit_Source.DocumentSuivi:
					__doc_gabarit = __proxy_Gabarit.Get_Gabarit_Document(this.Properties.ID_Suivi_Gabarit_Source);
					break;
			}

			this.Gabarit = __doc_gabarit;			

			//Envoi du gabarit dans le document pool du server quark
            QXPS_File_Manager.Addfile(this.Gabarit.FilePoolPath, this.Gabarit.Data);
            
			this.Gabarit.Evaluate_Document_Identity();

			//si nous ne sommes pas en mode d?grad? nous loggons un petit message d'information
			if (!this.Mode_Degrade)
			{
				Trace_Helper.Log_Message("Le gabarit contient d?j? {0} boxe(s) sur {1} page(s)", this.Gabarit.XML.Project_Info.NbBox, this.Gabarit.XML.Project_Info.NbPage);
			}
		}

		/// <summary>
		/// Chargement des InParams du run, les Inparams sont pass?s ? certaines taches (exemple les taches SQL)
		/// </summary>
		protected override void LoadInParams()
		{
			
			Proxy_Param __proxy =  new Proxy_Param();
			__proxy.Load_In_Params(this);

		}

		/// <summary>
		/// Chargement des taches associ? ? un run
		/// </summary>
		protected override void LoadTasks()
		{
			
			Proxy_Task	__proxy = new Proxy_Task();
			__proxy.Load_Task(this);
			
			//// ATTENTION ! nous allons ajouter une tache sp?cifique pour la mise ? jour du DID (Document IDentity)
			Task_DID __did_Task = new Task_DID(0, this);
			this.Tasks.Add(__did_Task.ID, __did_Task);

		}

		/// <summary>
		/// Chargements des templates associ?s au run
		/// </summary>
		protected override void LoadTemplates()
		{
			bool __load_templates = false;
			//Cela peut sembl? un peu compliqu? mais j'utilise des fonctions d?j? pr?sentes et cela ne nui pas au performance
			//D'abord on test s'il y ? au moins une tache dynamique en TODO dans le run
			foreach(Task_Dynamique __task in this.Tasks.GetEnumerable<Task_Dynamique>(true))
			{
				__load_templates = true;
				break;					
			}

			//on doit charger les templates et le gabarit template
			if(__load_templates)
			{
				//l'identifiant du gabarit template est d?fini dans les propri?t?s du run
				if(QXPFrk.Validation.IsSet(Properties.ID_Gabarit_Template))
				{
					Proxy_Template __proxy	= new Proxy_Template();
					
					//Chargement du gabarit template
					this.Gabarit_Template = __proxy.Get_Gabarit_Template(this);

					Trace_Helper.Log_Message("- Gabarit template {0} charg? ! ", Properties.ID_Gabarit_Template);

					//Chargement des templates
					__proxy.Load_Templates(this);

					Trace_Helper.Log_Message("- {0} Templates associ?s pour le gabarit_template {1}", this.Templates.Count, Properties.ID_Gabarit_Template);
				}
				else
				{
					Exception_Helper.Raise_Exception(new Exception_Run(Exception_Run.MSG_Missing_ID_Gabarit_Template, this.Gabarit.ID), Error_Type.Bloquante);
				}
			}
		}
		/// <summary>
		/// fin du run
		/// </summary>
		protected override void End()
		{
			Proxy_Run __proxy = new Proxy_Run();
			try
			{
				__proxy.End_Run(this);
			}
			catch(Exception)
			{
				//si l'on plante lors de End_Run, le statut du run doit ?tre Error
				//peut ?tre un pb d'insertion des documents g?n?r? ou autre
				this.Status = Run_Status.Error;
				//on ressaye un autre End_Run pour mettre ? jour le statut du run a Error
				__proxy.End_Run(this);
			}
		}
		#endregion overrides

		#endregion M?thodes

		#region Propri?t?s
		/// <summary>
		/// Repr?sente le r?pertoire de travail dans le pool exemple "R_1687\"
		/// </summary>
		protected override	string	PoolPath
		{
			get{return string.Format(PoolPattern, this.ID);}
		}

		#endregion Propri?t?s
	}
}
