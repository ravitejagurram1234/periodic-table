using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// R�pr�sente les param�tres d'un Template de tache dynamique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/03/2010 10:42:41</date>    
	public class Template
	{
		#region Membres
		
		#region common Normal/Overflow
		string					_name					= "Default";
		bool					_absolute				= false;
		Absolute_Repeat_Type	_absolute_repetition	= Absolute_Repeat_Type.Default;
		bool					_page_break				= false;
		bool					_column_break			= false;
		#endregion

		#region normal
		string					_src_Name				= null;
		#endregion
		
		#region overflow
		string					_src_Name_Overflow		= null;
		#endregion

		
		// Pour le positionnement
		decimal	_left			= 0;
		decimal	_top			= 0;
		decimal	_width			= 0; 
		decimal	_height			= 0;
		decimal	_height_Percent = 100;

		public static	Template Default = new Template();
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Template
		/// </summary>
		public Template()
		{
		
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		
		/// <summary>
		/// Nom du style
		/// </summary>
		public string	Name
		{
			get
			{
				return _name;
			}
			set
			{
				_name = value;
			}
		}

		/// <summary>
		/// nom de l'�l�ment (Box ou groupe de box) associ� � ce template dans le gabarit template
		/// </summary>
		public string	Src_Name
		{
			get
			{
				return _src_Name;
			}
			set
			{
				_src_Name = value;
			}
		}

		/// <summary>
		/// nom de l'�l�ment (Box ou groupe de box) associ� � ce template dans le gabarit template en cas d'overflow
		/// si null retourne tout de m�me le nom de l'element standard Src_Name
		/// </summary>
		public string	Src_Name_Overflow
		{
			get
			{
				if(QXPFrk.Validation.IsNotSet(_src_Name_Overflow)) return _src_Name;
				return _src_Name_Overflow;
			}
			set
			{
				_src_Name_Overflow = value;
			}
		}

		/// <summary>
		/// Largeur finale du template pour ce style
		/// </summary>
		public decimal	Width
		{
			get
			{
				return _width;
			}
			set
			{
				_width = value;
			}
		}

		/// <summary>
		/// Hauteur finale du template pour ce style
		/// </summary>
		public decimal	Height
		{
			get
			{
				return _height;
			}
			set
			{
				_height = value;
			}
		}
		
		/// <summary>
		/// hauteur finale en % du template pour ce style
		/// </summary>
		public decimal	Height_Percent
		{
			get
			{
				return _height_Percent;
			}
			set
			{
				_height_Percent = value;
			}
		}

		/// <summary>
		/// Position Haute finale du template dans le document final
		/// </summary>
		public decimal	Top
		{
			get
			{
				return _top;
			}
			set
			{
				_top = value;
			}
		}
		
		/// <summary>
		/// Position Gauche finale du template dans le document final
		/// </summary>
		public decimal	Left{
			get
			{
				return _left;
			}
			set
			{
				_left = value;
			}
		}

		/// <summary>
		/// Comment faut-il r�p�ter ce bloc absolu sur les pages
		/// </summary>
		public Absolute_Repeat_Type			Absolute_Repeat{
			get
			{
				return _absolute_repetition;
			}
			set
			{
				_absolute_repetition = value;
			}
		}

		/// <summary>
		/// Si ce n'est pas absolu (true) c'est relatif (false = valeur par defaut)
		/// </summary>
		public bool							Absolute
		{
			get
			{
				return _absolute;
			}
			set
			{
				_absolute = value;
			}
		}

		/// <summary>
		/// Permet de d�finir si ce template s'affiche uniquement sur les ruptures de pages
		/// </summary>
		public bool							Page_Break
		{
			get
			{
				return _page_break;
			}
			set
			{
				_page_break = value;
			}
		}

		/// <summary>
		/// Permet de d�finir si ce template s'affiche uniquement sur les ruptures de colonnes
		/// </summary>
		public bool							Column_Break
		{
			get
			{
				return _column_break;
			}
			set
			{
				_column_break = value;
			}
		}
		#endregion Propri�t�s
	}
}
