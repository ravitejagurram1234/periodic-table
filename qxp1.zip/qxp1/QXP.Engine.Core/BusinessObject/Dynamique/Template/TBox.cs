using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un Template Box disponible pour une tache dynamique
	/// Ne jamais travailler sur un TBox sans avoir obtenu un clone du TBox
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/03/2010 10:31:36</date>    
	public class TBox: TElement
	{
		#region Membres
		QXPSMSDK.Box	_srcBox			= null;
		QXPSMSDK.Box	_srcExtraBox	= null;
		TBox_Type			_type			= TBox_Type.CT_UNKNOWN;
		string				_page			= UnknownPage;
		#endregion Membres

		#region Constantes
		const string UnknownPage = "?";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de TBox. 
		/// Ne doit �tre utilis� que par la Serialisation
		/// </summary>
		public TBox()
		{
		
		}
		/// <summary>
		/// Cr�e une instance de TBox
		/// </summary>
		/// <param name="box">Boite Quark (Box)</param>
		public TBox(QXPSMSDK.Box box): base(box.name)
		{
			_srcBox	= box;
			if(QXPFrk.Validation.IsSet(box.boxType))
			{
				_type	= QXPFrk.Conversion.ToEnum<TBox_Type>(box.boxType);
			}
			if(QXPFrk.Validation.IsNotNull(box.geometry))
			{
				_page = box.geometry.page;
			}
		}

		/// <summary>
		/// Cr�e une instance de TBox
		/// </summary>
		/// <param name="box">Boite Quark (Box)</param>
		/// <param name="srcExtrabox">Boite suppl�mentaire associ� � la boite principale permettant certaine op�ration suppl�mentaire</param>
		public TBox(QXPSMSDK.Box box, QXPSMSDK.Box srcExtrabox): this(box)
		{
			_srcExtraBox	= srcExtrabox;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Lance l'�valuation des dimension de la boite
		/// </summary>
		/// <param name="qxp_Project">Le project qxp � partir duquel l'�l�ment est �valu�</param>
		public override void Evaluate(QXP_Project qxp_Project)
		{
			if(base.Evaluated) return;

			QXPSMSDK.Position __position = _srcBox.geometry.position;

            this.Left       = QXPFrk.ConversionInvariante.ToDecimal(__position.left);
            this.Top        = QXPFrk.ConversionInvariante.ToDecimal(__position.top);
            this.Right      = QXPFrk.ConversionInvariante.ToDecimal(__position.right);
            this.Bottom     = QXPFrk.ConversionInvariante.ToDecimal(__position.bottom);

			this.Width		= this.Right - this.Left;
			this.Height		= this.Bottom - this.Top;

			base.Evaluated = true;
		}

		

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Repr�sente la source du mod�le de Box
		/// </summary>
		public QXPSMSDK.Box	SrcBox
		{
			get{return _srcBox;}
			set{_srcBox = value;}
		}

		/// <summary>
		/// Repr�sente une source special du mod�le de Box. dans certaine tache (exemple pdf) il faut d'abord cr�� la boite avant de pouvoir effectuer un d�calage offset (avec l'extra)
		/// </summary>
		public QXPSMSDK.Box	SrcExtraBox
		{
			get{return _srcExtraBox;}
			set{_srcExtraBox = value;}
		}

		/// <summary>
		/// Type du TBox (CT_TEXT, CT_PICTURE etc..)
		/// </summary>
		public TBox_Type			Type
		{
			get{return _type;}
			set{_type = value;}
		}

		/// <summary>
		/// La page contenant cet �l�ment 
		/// Si la valeur est ? la page n'a pas pu �tre �valu�e
		/// </summary>
		public string						Page
		{
			get
			{
				return _page;
			}
		}
		#endregion Propri�t�s
	}
}
