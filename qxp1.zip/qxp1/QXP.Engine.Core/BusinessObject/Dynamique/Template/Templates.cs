using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une liste de Templates
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/03/2010 10:43:44</date>    
	public class Templates : Dictionary<string, Template>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Templates
		/// </summary>
		public Templates()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
