using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un Template de groupe de Box disponible dans les taches dynamiques
	/// Ne jamais travailler sur un TGroup sans avoir obtenu un clone du TGroup
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/03/2010 10:33:14</date>    
	public class TGroup: TElement
	{
		#region Membres
		QXPSMSDK.Group		_srcGroup;
		QXPSMSDK.Box[]		_srcBoxes;
		QXPFrk.BaseList<TBox>	_tBoxes = new QXPFrk.BaseList<TBox>(); //repr�sente les boites contenues dans le groupe
		string					_page	= UnknownPage;
		#endregion Membres

		#region Constantes
		const string UnknownPage = "?";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de TGroup
		/// </summary>
		public TGroup()
		{
		}

		/// <summary>
		/// Cr�e une instance de TGroup
		/// </summary>
		/// <param name="group">groupe de boite quark</param>
		public TGroup(QXPSMSDK.Group group): base(group.name)
		{
			_srcGroup = group;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Lance l'�valuation des prori�t�s du group
		/// </summary>
		/// <param name="qxp_Project">Le project qxp � partir duquel l'�l�ment est �valu�</param>
		public override void Evaluate(QXP_Project qxp_Project)
		{
			if(base.Evaluated) return;

			this.EvaluateBoxes(qxp_Project);

			decimal __left_Min		= decimal.MaxValue;
			decimal __top_Min		= decimal.MaxValue;
			decimal __right_Max		= decimal.MinValue;
			decimal __bottom_Max	= decimal.MinValue;

			decimal __width;
			decimal __height;

			//Si pas de boite !!
			if(this._tBoxes.Count == 0)
			{
				__left_Min	= 0;
				__top_Min	= 0;
				__width		= 0;
				__height	= 0;				
			}
			else
			{

				//Evaluation des dimensions Min/Max
				_tBoxes.ForEach(delegate(TBox __tBox)
				{
					__left_Min		= Math.Min(__left_Min, __tBox.Left);
					__top_Min		= Math.Min(__top_Min, __tBox.Top);
					__right_Max		= Math.Max(__right_Max, __tBox.Right);
					__bottom_Max	= Math.Max(__bottom_Max, __tBox.Bottom);

				});

				__width			= __right_Max - __left_Min;
				__height		= __bottom_Max - __top_Min;
			
			}			

			//M�morisation des param�tres du groupe
			this.Left			= __left_Min;
			this.Top			= __top_Min;
			this.Width			= __width;
			this.Height			= __height;

			base.Evaluated = true;
		}

		/// <summary>
		/// Permet d'�valuer les boites contenue dans le groupe
		/// </summary>
		/// <param name="qxp_Project">Le project qxp � partir duquel l'�l�ment est �valu�</param>
		private void				EvaluateBoxes(QXP_Project qxp_Project)
		{
			bool								__subGroup = false;
			QXPFrk.BaseList<QXPSMSDK.Box>	__srcBoxes = new QXPFrk.BaseList<QXPSMSDK.Box>();

			//Parfois il existe des groupes sans boite ^^
			if (QXPFrk.Validation.IsSet(_srcGroup.boxRefs))
			{
				foreach (QXPSMSDK.BoxRef __boxRef in _srcGroup.boxRefs)
				{
					if (qxp_Project.Elements.ContainsKey(__boxRef.name))
					{
						TBox __tBox = qxp_Project.Elements[__boxRef.name] as TBox;
						if (QXPFrk.Validation.IsNotNull(__tBox))
						{
							_tBoxes.Add(__tBox);
							__tBox.Evaluate(qxp_Project);
							__srcBoxes.Add(__tBox.SrcBox);
							if (_page == UnknownPage && __tBox.Page != UnknownPage)
							{
								_page = __tBox.Page;
							}
						}
						else
						{
							//nous effectuons une recherche simplifi� puisque nous traitons avec ce code que le cas suivant:
							//* un group DE 0-N boite(s) ET 1-N groupe(s) DE 1-N boite(s) 

							//La boxRef est peut �tre un groupe
							TGroup __tGroup = qxp_Project.Elements[__boxRef.name] as TGroup;
							if (QXPFrk.Validation.IsNotNull(__tGroup))
							{
								__subGroup = true;
								__tGroup.Evaluate(qxp_Project);
								if (_page == UnknownPage && __tGroup.Page != UnknownPage)
								{
									_page = __tGroup.Page;
								}
							}
						}
					}
					else
					{
						throw new Exception_TElement(Constantes.Error_Messages.TGroupUnKnownSubGroup, __boxRef.name, _srcGroup.name);						
					}
				}
			}

			_srcBoxes = __srcBoxes.ToArray();
			
			//Attention les template �l�ment de type groupe de doivent pas contenir d'autres groupes, j'ajoute un message d'information
			if(__subGroup)
			{
				throw new Exception_TElement(Constantes.Error_Messages.TGroupSubGroupProblem, _srcGroup.name, this.Page);
			}
		}

		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// Repr�sente la source du mod�le de Box contenu dans le TGroup
		/// </summary>
		public QXPSMSDK.Box[]			SrcBoxes
		{
			get{return _srcBoxes;}
			set{_srcBoxes = value;}
		}

		/// <summary>
		/// La page contenant cet �l�ment 
		/// Si la valeur est ? la page n'a pas pu �tre �valu�e
		/// </summary>
		public string						Page
		{
			get
			{
				return _page;
			}
		}
		#endregion Propri�t�s
	}
}
