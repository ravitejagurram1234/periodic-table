using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

using QXPFrk			= QXP.Framework;
using QXPSerialization	= QXP.Framework.Serialization;
using QXPAudit			= QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente la classe commune � tous les Templates �lements utilis�s dans les taches dynamiques
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/03/2010 10:30:41</date>    
	public abstract class TElement
	{
		#region Membres
		string				_name;
		decimal				_left;
		decimal				_top;
		decimal				_right;
		decimal				_bottom;
		decimal				_width;
		decimal				_height;
		bool				_evaluated = false;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de TElement. 
		/// Ne doit �tre utilis� que par la Serialisation
		/// </summary>
		protected TElement(){}

		/// <summary>
		/// Cr�e une instance de TElement
		/// </summary>
		public TElement(string name)
		{
			_name = name;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Demande l'�valuation des propri�t�s des �l�ments contenus
		/// </summary>
		/// <param name="qxp_Project">Le project qxp � partir duquel l'�l�ment est �valu�</param>
		public abstract void Evaluate(QXP_Project qxp_Project);

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Nom de l'�l�ment
		/// </summary>
		public string Name
		{
			get{return _name;}	
			set {_name = value;}
		}

		/// <summary>
		/// Position gauche de l'�l�ment
		/// </summary>
		public decimal Left
		{
			get{return _left;}
			set{_left = value;}
		}

		/// <summary>
		/// Position Haute de l'�l�ment
		/// </summary>
		public decimal Top
		{
			get{return _top;}
			set{_top = value;}
		}

		/// <summary>
		/// Position Droite de l'�l�ment
		/// </summary>
		public decimal Right
		{
			get{return _right;}
			set{_right = value;}
		}

		/// <summary>
		/// Position Basse de l'�l�ment
		/// </summary>
		public decimal Bottom
		{
			get{return _bottom;}
			set{_bottom = value;}
		}

		/// <summary>
		/// Largeur de l'�l�ment
		/// </summary>
		public decimal Width
		{
			get{return _width;}
			set{_width = value;}
		}

		/// <summary>
		/// Hauteur de l'�l�ment
		/// </summary>
		public decimal Height
		{
			get{return _height;}
			set{_height = value;}
		}

		/// <summary>
		/// Cette element a-t-il d�j� �t� �valu�
		/// </summary>
		public bool Evaluated
		{
			get
			{
				return _evaluated;
			}
			set
			{
				_evaluated = value;
			}
		}
		#endregion Propri�t�s
	}
}
