using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un template de Table disponible dans les taches dynamiques (mais pas encore utilis�)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/03/2010 10:31:36</date>    
	public class TTable: TElement
	{
		#region Membres
		QXPSMSDK.Table	_table;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur
		/// <summary>
		/// Cr�e une instance de TTable
		/// </summary>
		public TTable()
		{
		}

		/// <summary>
		/// Cr�e une instance de TTable
		/// </summary>
		/// <param name="table">table quark</param>
		public TTable(QXPSMSDK.Table table): base(table.name)
		{
			_table	= table;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Demande l'�valuation des propri�t�s des �l�ments contenus
		/// </summary>
		/// <param name="qxp_Project">Le project qxp � partir duquel l'�l�ment est �valu�</param>
		public override void Evaluate(QXP_Project qxp_Project)
		{
			//Non trait� pour le moment il n'est pas possible de d�finir des template de type Table			
			//Mais ce sera � faire lorsqu'il sera possible d'importer des Table depuis un gabarit Template
		}
		#endregion M�thodes

		#region Propri�t�s
		
		/// <summary>
		/// Repr�sente la source du mod�le de Box
		/// </summary>
		public QXPSMSDK.Table	SrcTable
		{
			get
			{
				return _table;
			}
			set
			{
				_table = value;
			}
		}

		#endregion Propri�t�s
	}
}
