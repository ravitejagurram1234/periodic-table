using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les informations de g�om�trie d'une DCell
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:47:37</date>    
	public class DCell_Info
	{
		#region Membres
		int			_page;
		int			_column;
		DZone		_zone;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DCell_Info
		/// </summary>
		public DCell_Info()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Clonage des informations de la cellule
		/// </summary>
		/// <returns></returns>
		public DCell_Info	Clone()
		{
			DCell_Info __new_Cell_Info = new DCell_Info();
			__new_Cell_Info.Zone		= this.Zone.Clone();
			__new_Cell_Info.Page		= this.Page;
			return __new_Cell_Info;
		}
		
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Page de la cellule
		/// </summary>
		public int			Page{
			get{return _page;}
			set{_page = value;}
		}

		/// <summary>
		/// Num�ro de la colonne de la ligne
		/// </summary>
		public int		Column{
			get{return _column;}
			set{_column = value;}
		}

		/// <summary>
		/// Zone g�om�trique de la cellule apr�s modification par le traitement
		/// </summary>
		public DZone		Zone{
			get{return _zone;}
			set{_zone = value;}
		}
		#endregion Propri�t�s
	}
}
