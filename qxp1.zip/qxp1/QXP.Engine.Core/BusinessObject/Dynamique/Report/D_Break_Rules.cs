using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code generated with template: QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Contains all page break rules for DReport when there is no more space on the page to add a row
	/// </summary>
	/// <remarks>
	/// Defines the line break rules within table(s) of a task.
	/// When the available height on a page to add a row is no longer sufficient, the row is added to the next page. 
	/// It is possible to define rules so that this row does not appear alone at the top of the new page, but instead brings rows above it along with it.
	/// These rules are only taken into account if the Row_Level column (optional column) is present in the SQL code of the Dynamic task.
	/// 
	/// It is possible to define multiple rules for a task. Example: A|B|C (where A, B, and C are rules separated by |)
	/// Each rule must match the following pattern X:Y where X represents the Row_Level(s) of rows to check in case of a page break, and Y the rows above to bring along with X.
	/// X and Y represent a list of Row_Level values (e.g., 2,3,4) separated by commas, or a range of Row_Level values (e.g., 1-3) separated by a hyphen, or a combination of both (e.g., 1-3,5)
	/// Concrete example:
	/// If Page_Break_Rules equals "2-4:1-3", it means that if a page break occurs on a Row_Level equal to 2, 3, or 4, then the rows above are brought along as long as the Row_Level is equal to 1, 2, or 3. 
	/// This rule can also be written differently (e.g., 2,3,4:1,2,3) which gives the same result.
	/// It is possible to write complex rules. Example:
	/// 2-4:1-3|5:3-4|6:5,3
	/// 
	/// It is also possible to write in Y the code LZ where Z is a digit from 1 to N that defines the number of rows to bring regardless of their row_level
	/// Example:
	/// 1-2:L2
	/// Tests if breaks occur on lines with row_level 1 or 2. If so, the line that changes pages will also bring the 2 rows directly above it
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>01/04/2010 11:04:13</date>    
	public class D_Break_Rules
	{
		#region Members
		string								_values	= string.Empty;

		Dictionary<int, D_Break_Rule>	_rules	= new Dictionary<int,D_Break_Rule>();

		public static D_Break_Rules		Default = new D_Break_Rules();
		#endregion Members

		#region Constants

		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructor

		/// <summary>
		/// Creates an instance of D_Break_Rules
		/// </summary>
		public D_Break_Rules()
		{
		}

		/// <summary>
		/// Creates an instance of D_Break_Rules
		/// </summary>
		/// <param name="values">String representing the page break rules</param>
		public D_Break_Rules(string values)
		{
			_values = values;
			this.Analyse_Rules(values);
		}

		#endregion Constructor

		#region Methods

		/// <summary>
		/// Evaluates the line break rules contained in the rules string
		/// </summary>
		/// <remarks>
		/// Defines the line break rules per page based on the row_level of the line (e.g., 1-3:4-8|5:6,7). 
		/// Each rule is separated by |. A rule is defined in the form X:Y where X represents the level (row_level) to test at break, 
		/// and Y the level(s) to bring if X changes page. Y can represent 1 or N values separated by commas (e.g., 1,3) or a range of values (e.g., 1-3)
		/// </remarks>
		/// <param name="values"></param>
		private void Analyse_Rules(string values)
		{
			if(QXPFrk.Validation.IsSet(values))
			{
				//list of rules to analyze
				string[] __rules = values.Split('|');				
				foreach(string __rule in __rules)
				{
					if(QXPFrk.Validation.IsSet(__rule))
					{
						D_Break_Rule __page_Break_Rule = new D_Break_Rule(__rule);
						this.Add_Rule(__page_Break_Rule);
					}				
				}
			}
		}

		/// <summary>
		/// Adds a break rule
		/// </summary>
		/// <param name="rule"></param>
		private void Add_Rule(D_Break_Rule rule)
		{
			foreach(int __level in rule.Levels)
			{
				if(!_rules.ContainsKey(__level))
				{
					_rules.Add(__level, rule);
				}
			}
		}


		/// <summary>
		/// Gets a break rule if it exists, otherwise returns the default rule
		/// </summary>
		/// <param name="level"></param>
		/// <returns></returns>
		public D_Break_Rule	Get_Rules(int level)
		{
			if(_rules.ContainsKey(level))
			{
				return _rules[level];
			}
			else
			{
				if(_rules.ContainsKey(int.MinValue))	return _rules[int.MinValue];
				else									return D_Break_Rule.Default;
			}
		}

		#endregion Methods

		#region Properties
		/// <summary>
		/// String containing the original rules
		/// </summary>
		public string Values
		{
			get
			{
				return _values;
			}
		}

		#endregion Properties
	}
}
