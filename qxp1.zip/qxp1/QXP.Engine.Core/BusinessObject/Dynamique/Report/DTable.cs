using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une structure type table dans un rapport dynamique, c'est � dire que les �l�ments sont positionn�s en relatifs les uns par rapports aux autres
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:40:52</date>    
	public class DTable
	{
		#region Membres
		DRows			_rows		= new DRows();
		DTable_Info		_info		= new DTable_Info();

		bool	_newPage	= false;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DTable
		/// </summary>
		public DTable()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Liste de DRow contenus dans le tableau
		/// </summary>
		public DRows		Rows{
			get{return _rows;}
		}

		/// <summary>
		/// Retourne les informations spatiales d'un tableau
		/// </summary>
		public DTable_Info	Info
		{
			get{return _info;}
		}

		/// <summary>
		/// D�finit si ce tableau commence sur une nouvelle page
		/// (cette propri�t� n'est pas utilis� pour le moment)
		/// </summary>
		public bool			NewPage{
			get{return _newPage;}
			set{_newPage = value;}
		}
		#endregion Propri�t�s
	}
}
