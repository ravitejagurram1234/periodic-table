using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une ligne dans une DTable d'un rapport dynamique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:43:27</date>    
	public class DRow
	{
		#region Membres
		DCells					_cells				= new DCells();
		DRow_Info				_info				= new DRow_Info();
		int						_level				= 0;
		QXPFrk.BaseList<DRow>	_page_Break_Rows	= new QXPFrk.BaseList<DRow>();
		QXPFrk.BaseList<DRow>	_column_Break_Rows	= new QXPFrk.BaseList<DRow>();
		int						_generation			= 1;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DRow
		/// </summary>
		public DRow()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet de Cloner un DRow
		/// </summary>
		/// <returns></returns>
		public DRow						Clone()
		{
			DRow	__newRow = new DRow();
			this.Generation++; //incr�mentation de la g�n�ration en cours
			__newRow.Generation			= this.Generation; //Affectation de la nouvelle generation � la nouvelle row
			__newRow.Info				= this.Info.Clone();
			__newRow.Level				= this.Level;
			__newRow.Page_Break_Rows	= this.Page_Break_Rows;

			foreach (DCell __cell in this.Cells)
			{
				__newRow.Cells.Add(__cell.Clone());
			}
			return __newRow;
		}
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Liste des DCell contenus dans la DRow
		/// </summary>
		public DCells					Cells{
			get{return _cells;}
		}
		
		/// <summary>
		/// Informations spatiales de la DRow
		/// </summary>
		public DRow_Info				Info{
			get{return _info;}
			set{_info = value;}
		}
		
		/// <summary>
		/// Niveau de la ligne (aussi appel� Row_Level)
		/// </summary>
		public int						Level{
			get{return _level;}
			set{_level = value;}
		}

		/// <summary>
		/// Cette DRow contient-t-il au moins une DCell sur un Template avec Page_Break = true
		/// Une ligne avec cette propri�t� � true, n'est pas trait�e comme une ligne relative comme les autres
		/// Elle est conserv�e et ajout�e en d�but de chaque nouvelles pages
		/// </summary>
		public bool						Page_Break
		{
			get
			{
				foreach(DCell __cell in _cells)
				{
					if (__cell.Template.Page_Break)
					{
						return true;
					}
				};
				return false;
			}
		}

		/// <summary>
		/// Cette DRow contient-t-il au moins une DCell sur un Template avec Column_Break = true
		/// Une ligne avec cette propri�t� � true, n'est pas trait�e comme une ligne relative comme les autres
		/// Elle est conserv�e et ajout�e en d�but de chaque nouvelles colonnes
		/// </summary>
		public bool						Column_Break
		{
			get
			{
				foreach(DCell __cell in _cells)
				{
					if (__cell.Template.Column_Break)
					{
						return true;
					}
				};
				return false;
			}
		}


		/// <summary>
		/// Contient la liste des Rows � r�p�ter lors d'un changement de page sur cette row
		/// </summary>
		public QXPFrk.BaseList<DRow>	Page_Break_Rows
		{
			get
			{
				return _page_Break_Rows;
			}
			set
			{
				_page_Break_Rows = value;
			}
		}

		/// <summary>
		/// Contient la liste des Rows � r�p�ter lors d'un changement de colonne sur cette row
		/// </summary>
		public QXPFrk.BaseList<DRow>	Column_Break_Rows
		{
			get
			{
				return _column_Break_Rows;
			}
			set
			{
				_column_Break_Rows = value;
			}
		}

		/// <summary>
		/// D�fini la g�n�ration de clonage de la DRow.
		/// A chaque clonage cette valeur s'incr�mente de 1 sur la classe d'origine et prend la m�me valeur sur la classe clon�e
		/// L'information de g�n�ration est utilis� uniquement pendant la phase de clonage.
		/// </summary>
		public int								Generation
		{
			get
			{
				return _generation;
			}
			private set
			{
				_generation = value;
			}
		}

		#endregion Propri�t�s
	}
}
