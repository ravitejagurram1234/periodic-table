using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini certaines propri�t�s d'un Project qxp (deduite � partir de la structure xml)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>13/04/2010 17:09:55</date>    
	public class DProject_Info
	{
		#region Membres
		string					_name;
		string					_xmlVersion;
		
		Dictionary<int, int>	_pageBoxes		= new Dictionary<int,int>();
		int						_nbSpread;
		int						_nbBox;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DProject_Info
		/// </summary>
		public DProject_Info()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet d'obtenir le nombre de boite sur la page
		/// </summary>
		/// <param name="page">num�ro de la page</param>
		/// <returns>le nombre de boite sur la page ou 1 s'il n'y � aucune boite</returns>
		public int GetNbBoxOnPage(int page)
		{
			if (_pageBoxes.ContainsKey(page))
			{
				return _pageBoxes[page];
			}
			else
			{
				return 0;
			}
		}
		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// Nom du projet
		/// </summary>
		public string				Name
		{
			get{return _name;}
			set{_name = value;}
		}

		/// <summary>
		/// Version XML de la structure xml
		/// </summary>
		public string				XMLVersion
		{
			get{return _xmlVersion;}
			set{_xmlVersion = value;}
		}

		/// <summary>
		/// Nombre de pages
		/// </summary>
		public int					NbPage
		{
			get{return _pageBoxes.Count;}
		}

		/// <summary>
		/// Nombre de spread
		/// </summary>
		public int					NbSpread
		{
			get{return _nbSpread;}
			set{_nbSpread = value;}
		}

		/// <summary>
		/// Nombre de box totale
		/// </summary>
		public int					NbBox
		{
			get{return _nbBox;}
			set{_nbBox = value;}
		}

		/// <summary>
		/// Nombre de box par page
		/// </summary>
		public Dictionary<int, int> PageBoxes
		{
			get{return _pageBoxes;}
			set{_pageBoxes = value;}
		}
		

		#endregion Propri�t�s
	}
}
