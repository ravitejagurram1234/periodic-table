using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une position (left,top) dans le document dynamique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:58:53</date>    
	public class DPoint
	{
		#region Membres
		decimal _left		= 0;
		decimal _top		= 0;

		/// <summary>
		/// Point d'origine 0,0
		/// </summary>
		public static DPoint Default = new DPoint();
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DPoint
		/// </summary>
		public DPoint(){}

		/// <summary>
		/// Cr�e une instance de DPoint
		/// </summary>
		/// <param name="start">Point de d�part</param>
		public DPoint(DPoint start)
		{
			_left	= start.Left;
			_top	= start.Top;
		}

		/// <summary>
		/// Cr�e une instance de DPoint
		/// </summary>
		/// <param name="left">position gauche</param>
		/// <param name="top">position haute</param>
		public DPoint(decimal left, decimal top)
		{
			_left	= left;
			_top	= top;
		}
		
		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// R�initialise � 0 les positions du point
		/// </summary>
		/// <param name="left">position gauche</param>
		/// <param name="top">position haute</param>
		public void Reset(decimal left, decimal top)
		{
			_left	= left;
			_top	= top;
		}
	
		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// Position Gauche du point
		/// </summary>
		public decimal Left{
			get{return _left;}
			set{_left = value;}
		}

		/// <summary>
		/// Position Haute du point
		/// </summary>
		public decimal Top{
			get{return _top;}
			set{_top = value;}
		}
		#endregion Propri�t�s
	}
}
