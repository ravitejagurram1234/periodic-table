using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// D�finit certaine propri�t� d'un bloc bloc dans un document QXP (left, top, right, bottom, page, nom, uid)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>13/04/2010 17:09:55</date>    
	public class DBloc_Info
	{
		#region Membres
		decimal				_left	= 0;
		decimal				_top	= 0;
		decimal				_right	= 0;
		decimal				_bottom	= 0;
		int					_page	= 0;
		string				_name	= string.Empty;
		string				_uid	= string.Empty;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DBloc_Info
		/// </summary>
		public DBloc_Info()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		
		/// <summary>
		/// Unique Identifier
		/// </summary>
		public string UID
		{
			get{return _uid;}
			set{_uid = value;}
		}


		/// <summary>
		/// Nom du bloc
		/// </summary>
		public string Name
		{
			get{return _name;}
			set{_name = value;}
		}
		
		/// <summary>
		/// Num�ro de la page
		/// </summary>
		public int		Page
		{
			get{return _page;}
			set{_page = value;}
		}

		/// <summary>
		/// Position Gauche
		/// </summary>
		public decimal Left
		{
			get{return _left;}
			set{_left = value;}
		}
		
		/// <summary>
		/// Position Haute
		/// </summary>
		public decimal Top
		{
			get{return _top;}
			set{_top = value;}
		}
		
		/// <summary>
		/// Position Droite
		/// </summary>
		public decimal Right
		{
			get{return _right;}
			set{_right = value;}
		}
		
		/// <summary>
		/// Position basse
		/// </summary>
		public decimal Bottom
		{
			get{return _bottom;}
			set{_bottom = value;}
		}
		

		#endregion Propri�t�s
	}
}
