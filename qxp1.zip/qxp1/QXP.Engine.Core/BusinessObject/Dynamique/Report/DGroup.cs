using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une section de groupe de box dans un rapport dynamique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:38:33</date>    
	public class DSection
	{
		#region Membres
		int			_id_MasterPage;
		DTables		_tables			= new DTables(); //Cellules en position relatives
		DCells		_cells			= new DCells(); //Cellules en position absolutes
		DSection_Info	_info			= new DSection_Info();

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DSection
		/// </summary>
		public DSection()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Liste des cellules en positions relatives
		/// </summary>
		public DTables Tables
		{
			get{return _tables;}
		}

		/// <summary>
		/// Liste des cellules en positions absolutes
		/// </summary>
		public DCells Cells
		{
			get{return _cells;}
		}

		/// <summary>
		/// Informations spatiales du group
		/// </summary>
		public DSection_Info Info
		{
			get{return _info;}
		}

		/// <summary>
		/// Indentifiant du master page � utiliser
		/// </summary>
		public int			ID_MasterPage{
			get{return _id_MasterPage;}
			set{_id_MasterPage = value;}
		}
		#endregion Propri�t�s
	}
}
