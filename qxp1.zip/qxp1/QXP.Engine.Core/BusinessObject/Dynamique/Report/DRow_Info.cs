using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les informations de g�om�trie d'une DRow
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:54:22</date>    
	public class DRow_Info
	{
		#region Membres
		decimal	_height;
		decimal _width;
		int		_page;
		int		_column;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DRow_Info
		/// </summary>
		public DRow_Info()
		{
		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// Clonage des informations de la ligne
		/// </summary>
		/// <returns></returns>
		public DRow_Info	Clone()
		{
			DRow_Info __new_Row_Info = new DRow_Info();
			__new_Row_Info.Height	= this.Height;
			__new_Row_Info.Page		= this.Page;
			return __new_Row_Info;
		}

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Hauteur actuelle de la ligne en point
		/// </summary>
		public decimal	Height{
			get{return _height;}
			set{ _height = value;}
		}

		/// <summary>
		/// Largeur actuelle de la ligne en point
		/// </summary>
		public decimal	Width{
			get{return _width;}
			set{ _width = value;}
		}
		
		/// <summary>
		/// Num�ro de page de la ligne
		/// </summary>
		public int		Page{
			get{return _page;}
			set{_page = value;}
		}

		/// <summary>
		/// Num�ro de la colonne de la ligne
		/// </summary>
		public int		Column{
			get{return _column;}
			set{_column = value;}
		}
		#endregion Propri�t�s
	}
}
