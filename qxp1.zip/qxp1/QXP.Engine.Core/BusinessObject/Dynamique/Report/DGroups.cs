using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une liste de DSection dans un rapport dynamique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:38:08</date>    
	public class DSections : QXPFrk.BaseList<DSection>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DSections
		/// </summary>
		public DSections()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
