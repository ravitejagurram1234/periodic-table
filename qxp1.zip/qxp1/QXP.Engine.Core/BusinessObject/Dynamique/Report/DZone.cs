using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une zone visuelle dans un document dynamique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:50:15</date>    
	public class DZone
	{
		#region Membres
		decimal _left		= 10;
		decimal _top		= 10;
		decimal _width		= 50;
		decimal _height		= 50;
		
		/// <summary>
		/// D�finit une zone par d�faut left:10 top:10 width:50 height:50
		/// </summary>
		public static DZone Default = new DZone();

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Permet la creation d'une DZone par Default
		/// </summary>
		private DZone(){}

		/// <summary>
		/// Cr�e une instance de DZone
		/// </summary>
		/// <param name="left">position gauche</param>
		/// <param name="top">position haute</param>
		/// <param name="width">largeur</param>
		/// <param name="height">hauteur</param>
		public DZone(decimal left, decimal top, decimal width, decimal height)
		{
			_left	= left;
			_top	= top;
			_width	= width;
			_height = height;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet de dupliquer une zone afin de cr�� une nouvelle zone sans modifier les param�tres de la zone originale
		/// </summary>
		/// <returns>la nouvelle zone identique � la zone originale</returns>
		public DZone		Clone()
		{
			return new DZone(this.Left, this.Top, this.Width, this.Height);
		}
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Position gauche de la Zone
		/// </summary>
		public decimal	Left{
			get{return _left;}
			set{_left = value;}
		}
		/// <summary>
		/// Position haute de la Zone
		/// </summary>
		public decimal	Top{
			get{return _top;}
			set{_top = value;}
		}

		/// <summary>
		/// Largeur de la Zone
		/// </summary>
		public decimal	Width{
			get{return _width;}
			set{_width = value;}
		}
		
		/// <summary>
		/// Hauteur de la Zone
		/// </summary>
		public decimal	Height{
			get{return _height;}
			set{_height  =value ;}
		}
		#endregion Propri�t�s
	}
}
