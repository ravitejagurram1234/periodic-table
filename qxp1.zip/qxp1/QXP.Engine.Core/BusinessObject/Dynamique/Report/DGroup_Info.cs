using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les informations propre � un DSection
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:49:19</date>    
	public class DSection_Info
	{
		#region Membres
		DMaster_Page _master_Page = null;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DSection_Info
		/// </summary>
		public DSection_Info()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Repr�sente la master page du groupe
		/// </summary>
		public DMaster_Page Master_Page
		{
			get{return _master_Page;}
			set{_master_Page = value;}
		}
		#endregion Propri�t�s
	}
}
