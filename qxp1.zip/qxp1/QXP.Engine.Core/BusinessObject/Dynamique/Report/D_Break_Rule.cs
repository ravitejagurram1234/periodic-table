using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code generated with template: QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Contains a rule for breaking DReport into pages when there is no more space on the page to add rows
	/// </summary>
	/// <remarks>
	/// See explanations in the D_Break_Rules class.
	/// This class represents a single rule in the list of rules contained in D_Break_Rules
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>01/04/2010 11:03:13</date>    
	public class D_Break_Rule
	{
		#region Members
		QXPFrk.BaseList<int>	_levels			= new QXPFrk.BaseList<int>();
		QXPFrk.BaseList<int>	_bring_Levels	= new QXPFrk.BaseList<int>();

		public static D_Break_Rule Default = new D_Break_Rule(int.MinValue);
		#endregion Members

		#region Constants

		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructor

		/// <summary>
		/// Creates an instance of D_Break_Rule
		/// </summary>
		/// <param name="levels"></param>
		public D_Break_Rule(params int[] levels)
		{
			_levels.AddRange(levels);
		}

		/// <summary>
		/// Creates an instance of D_Break_Rule
		/// </summary>
		/// <param name="rule">string defining the rules</param>
		public D_Break_Rule(string rule)
		{
			this.Analyse_Rule(rule);
		}

		/// <summary>
		/// Creates an instance of D_Break_Rule
		/// </summary>
		/// <param name="level">break level</param>
		/// <param name="bring_Levels">list of levels to bring</param>
		public D_Break_Rule(int level, QXPFrk.BaseList<int> bring_Levels) : this(level)
		{
			_bring_Levels	= bring_Levels;
		}

		#endregion Constructor

		#region Methods
		
		/// <summary>
		/// Analyzes the rule
		/// </summary>
		/// <param name="rule">the string containing the rule</param>
		private void Analyse_Rule(string rule)
		{
			string[]	__rule_infos = rule.Split(':');
			
			if(__rule_infos.Length == 2)
			{
				// Before ':' this represents the level(s)
				_levels.AddRange(Get_Rule_Values(__rule_infos[0]));
				

				// After ':' this represents the levels to bring
				_bring_Levels.AddRange(Get_Rule_Values(__rule_infos[1]));

			}
		}

		/// <summary>
		/// Evaluates the list of values contained in the string
		/// </summary>
		/// <param name="chaine">the string to evaluate</param>
		/// <returns>a list of integers (Level or Sub_Level)</returns>
		private int[] Get_Rule_Values(string chaine)
		{
			string[]				__infos		= chaine.Split(',');
			int						__start;
			int						__end;
			int						__value;
			QXPFrk.BaseList<int>	__values	= new QXP.Framework.BaseList<int>();

			foreach(string __info in __infos)
			{
				string[]	__levels			= __info.Split('-');
					
				// This is a range
				if(__levels.Length == 2)
				{
					__start = QXPFrk.Conversion.ToInt(__levels[0]);
					__end	= QXPFrk.Conversion.ToInt(__levels[1]);
					for(int __i = __start; __i <= __end; __i++)
					{
						__values.Add(__i);
					}
				}
				// Otherwise it's a single value
				else
				{
					// Test for presence of 'L' at the beginning of the string which defines bringing a specific number of lines (without testing row_level)
					string __level = __levels[0];
					if(__level.StartsWith("L"))
					{
						// In the case of an 'L', negative values are added to the values. -1 means bring the line above
						string __nb_Ligne = __level.Substring(1);
						__value = -QXPFrk.Conversion.ToInt(__nb_Ligne);
					}
					// Otherwise it's a row level to process (positive value)
					else
					{
						__value = QXPFrk.Conversion.ToInt(__levels[0]);
					}
					__values.Add(__value);
				}				
			}
			return __values.ToArray();
		}
		#endregion Methods

		#region Properties
		
		/// <summary>
		/// List of levels triggering a conditional break
		/// </summary>
		public QXPFrk.BaseList<int>		Levels{
			get{return _levels;}
		}

			
		/// <summary>
		/// List of levels brought in case of break
		/// </summary>
		public QXPFrk.BaseList<int>		Bring_Levels{
			get{return _bring_Levels;}
		} 

		#endregion Properties
	}
}
