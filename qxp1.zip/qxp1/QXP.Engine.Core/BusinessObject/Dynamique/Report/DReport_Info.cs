using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les informations de g�om�trie d'un DReport
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:57:04</date>    
	public class DReport_Info
	{
		#region Membres
		/// <summary>
		/// Nombre de pages totales g�n�r�es par le rapport
		/// </summary>
		public int Nb_Page = 0;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DReport_Info
		/// </summary>
		public DReport_Info()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
