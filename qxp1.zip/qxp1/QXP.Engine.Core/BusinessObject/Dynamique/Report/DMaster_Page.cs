using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un mod�le de master page utilis� lors de la cr�ation de page dans Quark. 
	/// </summary>
	/// <remarks>
	/// Le codage de la master page permet de d�finir plusieurs id de master en fonction d'une position 
	/// les id de master page sont s�par�s par  | (exemple 3|4) puis sont rechercher par le code en fonction de leur position
	/// pour l'instant seul la position 0 est utilis� mais nous auron besoin de cette m�canique lorsque nous devrons trait� les page en vis � vis (2 pages dans le m�me spread)
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>01/04/2010 11:30:57</date>    
	public class DMaster_Page
	{
		#region Membres
		string		_name		= "Default";
		string		_code		= null;
		string[]	_list_ids	= null;
		
		public static DMaster_Page Default = new DMaster_Page(Def_Code);
		#endregion Membres

		#region Constantes
		const string	Def_Code = "4";
		const char		Split_Char = '|';
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DMaster_Page
		/// </summary>
		/// <param name="code">codage de la master page</param>
		public DMaster_Page(string code)
		{
			_code		= code;
			_list_ids	= code.Split(Split_Char);
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet de retourner l'identifiant du master page situ� � l'index sp�cifi� dans le code
		/// </summary>
		/// <param name="position">position de la master page recherch�e</param>
		/// <returns>l'idenfiant de la master page si elle existe � la position demand�e sinon 4 afin de garder une compatibilit� ascendante</returns>
		public string Get_Master_Page_ID(int position)
		{
			if(position < _list_ids.Length)
			{
				return _list_ids[position];
			}
			else
			{
				return Def_Code;
			}
		}
		#endregion M�thodes

		#region Propri�t�s
		
		/// <summary>
		/// Code orginale du master page (exemple 3|4 )
		/// </summary>
		public string			Code
		{
			get{return _code;}
		}

		/// <summary>
		/// Nom de la master page dans le document quark
		/// </summary>
		public string			Name{
			get{return _name;}
			set{_name = value;}
		}
		
		#endregion Propri�t�s
	}
}
