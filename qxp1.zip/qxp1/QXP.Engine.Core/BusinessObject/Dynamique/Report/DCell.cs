using System;
using QXPFrk = QXP.Framework;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une cellule dans un rapport dynamique. Cette structure peut �tre position dans un tableau (relatif) ou directement dans un rapport (absolu)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:44:57</date>    
	public class DCell : IEquatable<DCell>
	{
		#region Membres

        int _logicaId = 0; // id used to differenciate the cellule ( used only in Absolute mode )
		QXPFrk.BaseList<string>		_newNames	= new QXPFrk.BaseList<string>(); // Liste des nouveaux nom de bloc � donn�e aux bloc du template
		QXPFrk.BaseList<string>		_values		= new QXPFrk.BaseList<string>(); // Liste des valeurs � mettre dans le/les blocs contenu dans le template
		Template					_template;
		bool						_overflow	= false;
		TElement					_tElement	= null;
		DCell_Info					_info		= new DCell_Info();
		int							_generation = 1; //La g�n�ration commence � 1 mais peut descendrer � 0 si l'on appel la methode downgrade_generation. ce qui aura pour cons�quence de conserver les noms originaux au premier clonage.

		#endregion Membres

		#region Constantes
		const string				New_Cell_Index_Pattern			= "[{0}_{1}]";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DCell
		/// </summary>
		public DCell(Template template)
		{
			_template	= template;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet de cloner la DCell en cours, chaque clonage renomme les newNames en fonction de la generatin de clonage
		/// </summary>
		/// <returns></returns>
		public DCell							Clone()
		{
			DCell __new_Cell = new DCell(this.Template);
			this.Generation++; //incr�mentation de la g�n�ration en cours
			__new_Cell.Generation	= this.Generation; //Affectation de la nouvelle generation � la nouvelle cell
			__new_Cell.TElement		= this.TElement;
			__new_Cell.Info			= this.Info.Clone();
			__new_Cell.NewNames.AddRange(Get_New_Names(__new_Cell.Generation));
			__new_Cell.Values.AddRange(this.Values); //Permet de casser les r�f�rences sur BaseList
            __new_Cell.LogicalId = this.LogicalId;
			return __new_Cell;
		}

		/// <summary>
		/// Permet d'obtenir une nouvelle liste de noms � partir de la liste de noms en cours et de la nouvelle generation.
		/// </summary>
		/// <param name="new_generation">indice de la nouvelle generation</param>
		/// <returns>une liste de nouveau noms</returns>
		public QXPFrk.BaseList<string> Get_New_Names(int new_generation)
		{
			QXPFrk.BaseList<string> __new_Names = new QXPFrk.BaseList<string>();
			foreach(string __old_name in this.NewNames)
			{
				//Cas particulier ou nous sommes en train de cloner une g�n�ration 1
				//les noms doivent rester les m�mes
				//seules les Cells absolues sur repeat other ou les r�p�titions d'ent�te de page (Page_Break) doivent �tre dans ce cas !! Voir la methode Downgrade_Generation
				if (new_generation == 1)
				{
					__new_Names.Add(__old_name);
				}
				else
				{
					__new_Names.Add(string.Format(New_Cell_Index_Pattern, __old_name, new_generation));
				}
			}
			return __new_Names;
		}

		/// <summary>
		/// Permet de d�finir la g�n�ration � 0, ce qui permettra au premier clonage de ne pas renommer les NewNames.
		/// Ne pas appeler cette propri�t�s normalement utiliser uniquement par les bloc absolus sur repeat other uniquement.
		/// </summary>
		public void				Downgrade_Generation()
		{
			_generation = 0;
		}

        /// <summary>
        /// Verify if two cells are equal, is available only for absolute Cells
        /// </summary>
        /// <param name="cell"></param>
        /// <returns></returns>
        public bool Equals(DCell cell)
        {
            if (QXPFrk.Validation.IsNull(cell))
                return false;
            return this.LogicalId == cell.LogicalId;
        }

        #endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Information de la cellule
		/// </summary>
		public DCell_Info						Info
		{
			get{return _info;}
			set{_info = value;}
		}

		/// <summary>
		/// Template associ�e � la cellule
		/// </summary>
		public Template							Template
		{
			get{return _template;}
		}

		/// <summary>
		/// Template Element de la cellule �valuer par la methode TElement_Helper.Evaluate_TElement.
		/// </summary>
		public TElement							TElement{
			get{return _tElement;}
			set{_tElement = value;}
		}

		/// <summary>
		/// 
		/// </summary>
		public bool								Overflow
		{
			get
			{
				return _overflow;
			}
			set
			{
				_overflow = value;
			}
		}
		/// <summary>
		/// Liste du/des nouveaux nom de bloc � donn�e aux blocs du template
		/// </summary>
		public QXPFrk.BaseList<string>			NewNames
		{
			get{return _newNames;}
		}
		
		/// <summary>
		/// Liste des valeurs � mettre dans le/les blocs contenu dans le template
		/// </summary>
		public QXPFrk.BaseList<string>			Values
		{
			get{return _values;}
		}

		/// <summary>
		/// D�fini la g�n�ration de clonage de la DCell.
		/// A chaque clonage cette valeur s'incr�mente de 1 sur la classe d'origine et prend la m�me valeur sur la classe clon�e
		/// </summary>
		public int								Generation
		{
			get
			{
				return _generation;
			}
			private set
			{
				_generation = value;
			}
		}

        /// <summary>
        /// Logical Id of cell - used in absolute call.
        /// it always equals 0 in case of relative cell.
        /// </summary>
        public int LogicalId 
        {
            get { return _logicaId; }
            set { _logicaId = value; } 
        }

		#endregion Propri�t�s
	}
}
