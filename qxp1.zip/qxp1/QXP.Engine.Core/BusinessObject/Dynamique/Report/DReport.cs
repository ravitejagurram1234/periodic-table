using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un rapport dynamique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:36:33</date>    
	public class DReport
	{
		#region Membres
		DReport_Info			_info				= new DReport_Info();
		DSections				_sections			= new DSections();
		D_Break_Rules			_page_Break_Rules	= new D_Break_Rules();
		D_Break_Rules			_column_Break_Rules	= new D_Break_Rules();
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DReport
		/// </summary>
		public DReport()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Liste des sections contenues dans le rapport
		/// </summary>
		public DSections	Sections
		{
			get{return _sections;}
		}

		/// <summary>
		/// Retourne les informations spatiales d'un DReport
		/// </summary>
		public DReport_Info Info
		{
			get{return _info;}
		}

		/// <summary>
		/// Contient les r�gles de rupture des lignes dans les tableaux
		/// </summary>
		public D_Break_Rules Page_Break_Rules
		{
			get{return _page_Break_Rules;}
			set{_page_Break_Rules = value;}
		}

		/// <summary>
		/// Contient les r�gles de rupture des colonnes dans les tableaux
		/// </summary>
		public D_Break_Rules Column_Break_Rules
		{
			get{return _column_Break_Rules;}
			set{_column_Break_Rules = value;}
		}

		#endregion Propri�t�s
	}
}
