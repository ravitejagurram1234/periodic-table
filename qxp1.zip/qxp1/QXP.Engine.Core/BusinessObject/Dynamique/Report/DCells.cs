using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une liste de DCell
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:46:14</date>    
	public class DCells : QXPFrk.BaseList<DCell>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DCells
		/// </summary>
		public DCells()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
