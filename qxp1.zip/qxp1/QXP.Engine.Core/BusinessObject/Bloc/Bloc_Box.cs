using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk		= QXP.Framework;
using QXPAudit		= QXP.Audit;

using QXPSMSDK	= com.quark.qxpsm;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un bloc de type box (1 seul bloc) dans un document quark
	/// Attention ce bloc peut avoir n'importe qu'elle type CT_TEXT, CT_PICTURE etc...
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 10:06:25</date>    
	public class Bloc_Box : Bloc_Base
	{
		#region Membres
        string					_value;
        QXPSMSDK.Box		_srcBox				= null;
        QXPSMSDK.Box		_srcExtraBox		= null;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

        /// <summary>
        /// Il est possible de cr�er une boite � partir d'une valeur
        /// </summary>
		/// <param name="task">Tache qui � cr�� ce Bloc_Box</param>
        /// <param name="name">Nom du bloc</param>
        /// <param name="value">valeur du bloc</param>
		public Bloc_Box(Task_Base task, string name, string value) : base(task, name)
		{
            _value      = value;
		}

		/// <summary>
		/// Il est possible de cr�er un bloc box � partir d'une Box Quark
		/// </summary>
		/// <param name="task">Tache qui � cr�� ce Bloc_Box</param>
        /// <param name="name">Nom du bloc</param>
        /// <param name="tBox">le TBox original</param>
        public Bloc_Box(Task_Base task, string name, TBox tBox) : base(task, name)
		{
            _srcBox			= tBox.SrcBox;
			_srcExtraBox	= tBox.SrcExtraBox;
        }

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
        /// <summary>
        /// Valeur � mettre dans la boite (cette propri�t� n'est pas utilis� dans les tache dynamiques) 
        /// </summary>
		public string					Value{
            get{return _value;}
        }
        
		/// <summary>
        /// Box quark de modification principale
        /// </summary>
		public QXPSMSDK.Box		SrcBox{
            get{return _srcBox;}
        }

		/// <summary>
        /// Box quark de modification suppl�mentaire (permet certaine op�ration sur les boites exemple en pdf avec le d�calage des images, ou l'image doit �tre ajouter avec SrcBox puis d�caler avec SrcExtraBox)
        /// </summary>
		public QXPSMSDK.Box		SrcExtraBox{
            get{return _srcExtraBox;}
        }
		
		#endregion Propri�t�s
	}
}
