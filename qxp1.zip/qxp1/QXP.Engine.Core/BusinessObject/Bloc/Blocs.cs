using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// repr?sente une collection de bloc
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 11:16:07</date>    
	public class Blocs: Dictionary<string, Bloc_Base>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr?e une instance de Blocs
		/// </summary>
		public Blocs()
		{
		}

		#endregion Constructeur

		#region M?thodes

		#endregion M?thodes

		#region Propri?t?s

		#endregion Propri?t?s
	}
}
