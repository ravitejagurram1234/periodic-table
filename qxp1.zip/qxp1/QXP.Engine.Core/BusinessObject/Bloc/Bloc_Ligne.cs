using System;
using System.Collections.Generic;
using System.Text;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un type de bloc ligne qui permettra �ventuellement la suppression de 1 ligne dans un document quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 15:32:58</date>    
	public class Bloc_Ligne : Bloc_Base
	{
		#region Membres
        int     _index      = int.MinValue;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur


		/// <summary>
		/// Cr�e une instance de Bloc_Ligne
		/// </summary>
        /// <param name="task">Tache qui � cr�� ce Bloc_Ligne</param>
		/// <param name="name">nom du bloc</param>
        /// <param name="parentName">nom de la table contenant la ligne � supprimer</param>
        /// <param name="index">index de la ligne � supprimer</param>
		public Bloc_Ligne(Task_Base task, string name, string parentName, int index) : base(task, name)
        {
            base.ParentName		= parentName;
            _index				= index;
        }

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Index de la ligne � supprimer
		/// </summary>
		public int      Index {
			get { return _index; }
			set { _index = value; }
		}
		#endregion Propri�t�s
	}
}
