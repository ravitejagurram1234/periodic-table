using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un type de bloc page qui permettra �ventuellement la suppression de 1 page ou la creation d'une page.
	/// La valeur Pagination est donc a true par def dans ce type de bloc
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 15:32:58</date>    
	public class Bloc_Page : Bloc_Base
	{
		#region Membres
		bool _create_Next_Dummy_Page = false;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur


		/// <summary>
		/// Cr�e une instance de Bloc_Page
		/// </summary>
        /// <param name="task">Tache qui � cr�� ce Bloc_Page</param>
		/// <param name="name">nom de bloc</param>
        public Bloc_Page(Task_Base task, string name) : base(task, name)
        {
			//Bien entendu dans le cas d'un bloc_page la pagination est modifi� :)
			this.Pagination = true;
        }

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		
		/// <summary>
		/// D�fini la position de la page par rapport � la reliure
		/// A Droite ou string.empty (par d�faut) ou � gauche
		/// <remarks>
		/// Cette valeur est d�finie par rapport � la page et au spread
		/// </remarks>
		/// </summary>
		public string Position
		{
			get
			{
				string __position = string.Empty;
				//Pour pouvoir �tre positionn� en LEFTOFSPINE il faut :
				// - etre en mode multipage 
				// - ne pas �tre sur la page 1
				// - avoir un index de position de la page sur le spread de 0
				if (this.Task.Run.Properties.Nb_Page_By_Spread != Run_Properties.PaginationSimple 
					&& this.Page_ID != 1
					&& this.Index_Position == 0)
				{
					__position = Page_Position.LEFTOFSPINE;
				}
				else
				{
					//Il aurait �t� �galement possible de d�finir =>
					//__position = Page_Position.RIGHTOFSPINE;
				}
				return __position;
			}
		}

		/// <summary>
		/// Permet d'obtenir l'index de la position de la page dans le spread si une page par spread alors cette valeur est toujours �gale � 0
		/// </summary>
		public int	Index_Position
		{
			get
			{
				//Cas tr�s particulier de la page 1 il faudra cr�� un spread
				if (this.Page_ID == 1)
				{
					return 0;
				}
				//dans les autres cas cette formule s'applique parfaitement !!
				else
				{
					//tenir compte du lag_spread caus� par la cr�ation de la premi�re page dans un document en double page
					if (this.Lag_Spread)
					{
					    return ((this.Page_ID+1) % this.Task.Run.Properties.Nb_Page_By_Spread);
					}
					else
					{
					    return (this.Page_ID % this.Task.Run.Properties.Nb_Page_By_Spread);
					}					
				}
			}
		}

		/// <summary>
		/// Permet de d�finir si cette page doit cr�er une nouvelle page bidon derri�re elle
		/// cette propri�t� est utilis�e dans le cas des page en vis � vis lorsque la derni�re page en cr�ation d'une tache � un num�ro pair
		/// dans le cas des page en vis � vis chaque nouveau spread doit toujours avoir 2 pages hors si la derni�re page � cr�er est paire cela sous entend que le dernier spread n'aura qu'une page
		/// il faut donc cr��r une page suppl�mentaire et la supprimer imm�diatement afin d'induire un d�calage des pages sur les spreads suivants
		/// </summary>
		public bool Create_Next_Dummy_Page
		{
			get
			{
				return _create_Next_Dummy_Page;
			}
			set
			{
				_create_Next_Dummy_Page = value;
			}
		}

		/// <summary>
		/// Permet de connaitre le nombre de box contenu dans la page qui va �tre supprim�e. si c'est un ajout il n'y aura aucun bloc dessus par d�faut
		/// </summary>
		public override int Nb_Box
		{
			get
			{
				if (this.Action == Bloc_Action.REMOVE)
				{
					return this.Task.Run.Gabarit.XML.Project_Info.GetNbBoxOnPage(this.Page_ID);
				}
				else
				{
					return base.Nb_Box;
				}
				
			}
		}
		#endregion Propri�t�s
	}
}
