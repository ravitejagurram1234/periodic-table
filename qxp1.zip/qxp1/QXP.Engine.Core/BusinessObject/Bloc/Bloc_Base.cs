using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente la classe de base de tout les types de bloc qui pourrons modifier la structure d'un document Quark
	/// </summary>
	/// <remarks>
	/// Les taches g�n�rent diff�rents type de bloc (qui d�rive de cette classe)
	/// tous ces blocs sont ensuite envoy�e � un manager qui r�partira toutes ces taches en �tape d'�x�cution
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>23/03/2010 10:03:12</date>    
	public class Bloc_Base
	{
		#region Membres
        string          _name;
        string          _parentName					= string.Empty;
        Bloc_Action     _action						= Bloc_Action.NONE;
        string			_condName					= string.Empty;
        Task_Base       _task;
		int				_relative_Page				= 0;
		int				_page_id					= int.MinValue;
		int				_page_id_originale			= int.MinValue;
		bool			_pagination					= false;
        int             _index_Maquette				= 4; //D�fini l'index de la maquette pour la cr�ation de page
		bool			_lag_Spread					= false;
		bool			_exclude					= false;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur


		/// <summary>
		/// Cr�e une instance de Bloc_Base avec un nom de bloc et une tache
		/// </summary>
		/// <param name="name">nom du bloc</param>
		/// <param name="task">Tache qui � cr�� ce bloc action</param>
		public Bloc_Base(Task_Base task, string name)
		{
            _task   = task;
            _name   = name;
        }


		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Lance l'�valuation de la page du bloc en fonction du relative page
		/// </summary>
		public void Evaluate_Page()
		{
			_page_id_originale = _page_id = Task.Get_Page_ID_From_Relative(this.CondName, this.Relative_Page);
		}

		#endregion M�thodes

		#region Propri�t�s
        /// <summary>
        /// Ce nom d�pend du type de bloc, exemple si c'est un bloc_box c'est le nom du bloc, si c'est un Bloc_Table c'est le nom de la table
        /// </summary>
		public string       Name{
            get{return _name;}
        }
        
		/// <summary>
		/// Identifiant de la page associ�e au bloc de modification. 
		/// Cette valeur est d�duite initialement � partir Task_Properties.PageID et du Relative_Page du bloc
		/// </summary>
		public int			Page_ID
		{
		    get{return _page_id;}
		    set{_page_id = value;}
		}
		
		/// <summary>
		/// Identifiant de la page associ�e au bloc de modification. 
		/// Cette valeur est d�duite initialement � partir Task_Properties.PageID et du Relative_Page du bloc
		/// Mais contrairement � Page_ID cette valeur n'�value pas durant les �tapes de Repagination
		/// Cette propri�t� sera utilis� dans la pr�paration du document des �tapes Run_Task_Step.Prepare_Step
		/// </summary>
		public int			Page_ID_Originale
		{
		    get{return _page_id_originale;}
		}
	
		/// <summary>
		/// Repr�sente la position relative de la page du bloc par rapport � la page du bloc destination dans le document en cours de modification.
		/// (ex si la page du bloc destination et 10 et que Relative_Page = 1 alors la page du bloc en cours est 11
		/// </summary>
		public int			Relative_Page
		{
		    get{return _relative_Page;}
		    set{_relative_Page = value;}
		}

		/// <summary>
		/// Identifiant du spread associ� au bloc de modification
		/// Cette valeur est �valu�e � chaque appel afin de tenir compte de la derni�re version de la page_id
		/// </summary>
		public int			Spread_ID
		{
		    get
		    {
		        return this.Task.Get_Spread_ID_From_Page_ID(_page_id, _lag_Spread);
		    }
		}

		/// <summary>
		/// Nom du bloc conditionnel.
		/// </summary>
		public string       CondName
		{
		    get { return _condName; }
		    set { _condName = value; }
		}
        
		/// <summary>
		/// Nom de l'�l�ment Parent du bloc (peut-�tre par exemple une table ou un group)
		/// </summary>
		public string		ParentName
		{
		    get{return _parentName;}
		    set{_parentName = value;}
		}
        
		/// <summary>
		/// L'action effectu�e sur ce bloc
		/// </summary>
		public Bloc_Action  Action{
            get{return _action;}
            set{_action = value;}
        }

		//Pour l'instant cette propri�t� reste l�, mais il faudrait peut �tre envisager de mettre cette propri�t� dans les taches
		/// <summary>
		/// Index de la maquette � utiliser si ce bloc doit cr�er une nouvelle spread/page
		/// </summary>
        public int          Index_Maquette{
            get{return _index_Maquette;}
            set{_index_Maquette = value;}
        }

		/// <summary>
		/// La tache associ� au bloc
		/// </summary>
        public Task_Base    Task
        {
            get { return _task; }
        }

		/// <summary>
		/// Ce bloc change t-il ou est-il li� � un changment de la pagination du document finale (def false)
		/// </summary>
		public bool			Pagination
		{
			get{return _pagination;}
			set{_pagination = value;}
		}

		/// <summary>
		/// Permet de pr�ciser lors de l'�valuation du spread s'il y � eu suppression du spread 1 uniquement
		/// utiliser lors des doubles pages
		/// si oui alors page 3-4 sur spread 3 , 5-6 sur spread 4 etc...
		/// sinon page 2-3 sur spread 2, 4-5 sur spread 3 etc ...
		/// </summary>
		public bool			Lag_Spread
		{
			get
			{
				return _lag_Spread;
			}
			set
			{
				_lag_Spread = value;
			}
		}

		/// <summary>
		/// Nombre de box r�ellement contenu dans le type de bloc d�riv�e
		/// Permet de controler le nombre total de Box qui seront modifi�e par le run
		/// </summary>
		public virtual	int	Nb_Box
		{
			get
			{
				return 1;
			}
		}

		/// <summary>
		/// D�fini si le bloc est n'est pas ajouter dans la hierarchie du Modifier pour cause de d�passement de capacit� (Def:false)
		/// </summary>
		public bool			Exclude
		{
			get
			{
				return _exclude;
			}
			set
			{
				_exclude = value;
			}
		}

		#endregion Propri�t�s
	}
}
