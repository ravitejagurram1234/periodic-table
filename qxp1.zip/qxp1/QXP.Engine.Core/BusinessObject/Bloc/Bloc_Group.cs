using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk		= QXP.Framework;
using QXPAudit		= QXP.Audit;

using QXPSMSDK	= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un bloc de type Group (plusieurs blocs) dans un document quark
	/// Attention ces blocs peuvent avoir n'importe qu'elle type CT_TEXT, CT_PICTURE etc...
	/// </summary>
	/// <author>doufarm</author>
	/// <date>31/03/2010 14:43:25</date>    
	public class Bloc_Group: Bloc_Base
	{
		#region Membres
        QXPSMSDK.Box[]		_srcBoxes		= null;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Il est possible de cr�er un group � partir d'un autre group et de valeurs
		/// </summary>
		/// <param name="task">Tache qui � cr�� ce Bloc_Group</param>
        /// <param name="name">Nom du group</param>
        /// <param name="srcBoxes">Liste de Box Quark du groupe</param>
        public Bloc_Group(Task_Base task, string name, QXPSMSDK.Box[] srcBoxes) : base(task, name)
		{
            _srcBoxes		= srcBoxes;
        }

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
        
		/// <summary>
        /// structure quark de d�finition des boites du groupe
        /// </summary>
		public QXPSMSDK.Box[]		SrcBoxes{
            get{return _srcBoxes;}
        }

		/// <summary>
		/// Nombre de Box dans le group
		/// </summary>
		public override int Nb_Box
		{
			get
			{
				if (QXPFrk.Validation.IsSet(_srcBoxes))
				{
					return _srcBoxes.Length;
				}
				else
				{
					return 0;
				}
			}
		}
		#endregion Propri�t�s
	}
}
