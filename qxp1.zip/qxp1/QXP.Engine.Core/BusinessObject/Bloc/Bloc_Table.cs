using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK		= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente un type de bloc table qui permettra �ventuellement la suppression d'une table dans un document quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 15:32:58</date>    
	public class Bloc_Table : Bloc_Base
	{
		#region Membres
        QXPSMSDK.Table _srcTable = null;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur


		/// <summary>
		/// Cr�e une instance de Bloc_Table
		/// </summary>
        /// <param name="task">Tache qui � cr�� ce Bloc_Table</param>
		/// <param name="name">nom du bloc</param>
		public Bloc_Table(Task_Base task, string name) : base(task, name)
        {
        }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="task">Tache qui � cr�� ce Bloc_Table</param>
		/// <param name="name">nom du bloc</param>
        /// <param name="tTable">le TTable originale</param>
        public Bloc_Table(Task_Base task, string name, TTable tTable): base(task, name)
        {
            _srcTable = tTable.SrcTable;
        }

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
        
		/// <summary>
        /// Table QXP Source utilis� pour la reprise
        /// </summary>
        public QXPSMSDK.Table SrcTable
        {
            get { return _srcTable; }
        }
		#endregion Propri�t�s
	}
}
