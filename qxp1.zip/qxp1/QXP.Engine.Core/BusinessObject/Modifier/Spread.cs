using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sentant un spread dans un projet de modifications
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/03/2010 10:02:20</date>    
	public class Spread
	{
		#region Membres
        
		/// <summary>
		/// Unique Identifier du spread
		/// </summary>
		public string						UID;
		/// <summary>
		/// Liste des boites du spread
		/// </summary>
        public Dictionary<string, Box>		Boxes		= new Dictionary<string, Box>();
        /// <summary>
        /// Liste des boites suppl�mentaires du spread
        /// </summary>
		public Dictionary<string, Box>		Boxes_Extra	= new Dictionary<string, Box>();
        /// <summary>
        /// Liste des groupes du spread
        /// </summary>
		public Dictionary<string, Group>	Groups		= new Dictionary<string, Group>();
        /// <summary>
        /// Liste des tables du spread
        /// </summary>
		public Dictionary<string, Table>	Tables		= new Dictionary<string, Table>();
        /// <summary>
        /// Liste des pages du spread
        /// </summary>
		public Dictionary<string, Page>		Pages		= new Dictionary<string, Page>();
		/// <summary>
		/// M�morise si le spread doit �tre cr��
		/// </summary>
		public bool							Create		= false;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Spread
		/// </summary>
		public Spread()
		{
		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// Retourne la liste des boites quark �valuer � partir du spread
		/// </summary>
		/// <returns>une liste de boites quark</returns>
		public QXPSMSDK.Box[]		GetSDKBoxes()
        {
            QXPFrk.BaseList<QXPSMSDK.Box>	__dest_Boxes	= new QXPFrk.BaseList<QXPSMSDK.Box>();

			#region Zone des Boxes
			//ajout des box (normal)
			__dest_Boxes.AddRange(EvaluateSDKBoxes(Boxes, false));
            
			#endregion
			#region Zone Groups

			foreach(Group __grp in this.Groups.Values)
			{
				foreach(QXPSMSDK.Box __new_Box in __grp.SrcBoxes)
				{
					__new_Box.operation	= Bloc_Operation.CREATE;
					__new_Box.UID		= string.Empty;
					__dest_Boxes.Add(__new_Box);
					if(QXPFrk.Validation.IsNull(__new_Box.geometry))
					{
						__new_Box.geometry = new QXPSMSDK.Geometry();
					}
					//Nous partons du principe que les spreadID sont �gaux au PageID ( c'est � dire une page par spread)
					__new_Box.geometry.page = __grp.Page_ID.ToString();

				}
			}

			#endregion
            return __dest_Boxes.ToArray();
        }

		/// <summary>
		/// Retourne la liste des boites Extra quark �valuer � partir du spread
		/// </summary>
		/// <returns>une liste de boites quark</returns>
		public QXPSMSDK.Box[]		GetSDKBoxesExtra()
        {
            QXPFrk.BaseList<QXPSMSDK.Box>	__dest_Boxes	= new QXPFrk.BaseList<QXPSMSDK.Box>();

			#region Zone des Boxes
			//ajout des box (extra)
			__dest_Boxes.AddRange(EvaluateSDKBoxes(Boxes_Extra, true));
            
			#endregion

            return __dest_Boxes.ToArray();
        }
 
		/// <summary>
		/// Permet de mettre � jour les op�rations et les pages de la liste des boites pass� en argument
		/// </summary>
		/// <param name="boxes">la liste des boites � mettre � jour</param>
		/// <param name="IgnoreOperation">si true l'op�ration (d�duite de l'action) n'est pas ajouter � la box</param>
		/// <returns>Les boites mises � jours</returns>
		private  QXPSMSDK.Box[]	EvaluateSDKBoxes(Dictionary<string, Box> boxes, bool IgnoreOperation)
		{
            QXPFrk.BaseList<QXPSMSDK.Box>	__dest_Boxes	= new QXPFrk.BaseList<QXPSMSDK.Box>();
			QXPSMSDK.Box					__box;
			foreach (Box __bx in boxes.Values)
            {
				__box = __bx.SrcBox;
				switch(__bx.Action)
				{
					case Bloc_Action.CREATE:
						if(!IgnoreOperation)
						{
							__box.operation = Bloc_Operation.CREATE;
						}
						__box.UID		= string.Empty;
						if(QXPFrk.Validation.IsNull(__box.geometry))
						{
							__box.geometry		= new QXPSMSDK.Geometry();
						}
						__box.geometry.page = __bx.Page_ID.ToString();						
						break;
					case Bloc_Action.MOVE:
						__box.geometry.page = __bx.Page_ID.ToString();						
						break;
				}
				__dest_Boxes.Add(__box);
            }
			return __dest_Boxes.ToArray();
		}

		/// <summary>
		/// Retourne la liste des table quark �valuer � partir du spread
		/// </summary>
		/// <returns>liste de table quark</returns>
        public QXPSMSDK.Table[]	GetSDKTables()
        {
            QXPSMSDK.Table __table;
            QXPFrk.BaseList<QXPSMSDK.Table> __tables = new QXPFrk.BaseList<QXPSMSDK.Table>();

            foreach (Table __tab in Tables.Values)
            {
                //ont regarde si le tableau est � supprimer
                if (__tab.Action == Bloc_Action.REMOVE)
                {
                    __table					= new QXPSMSDK.Table();
                    __table.name			= __tab.Name;
                    __table.operation		= Bloc_Operation.DELETE;
                    __tables.Add(__table);
                }
                // si il sagit d'une tache de donn�e QXP et que la table possede une source
                else if (__tab.Task.Sub_Task_Type == Sub_Task_Type.File_QXP_Previous && QXPFrk.Validation.IsNotNull(__tab.SrcTable))
                {
                    __table			= __tab.SrcTable;
					__table.name	= __tab.Name;
                    __tables.Add(__table);
                }
                else //sinon il faut supprimer des lignes
                {
                    __table				= new QXPSMSDK.Table();
                    __table.name		= __tab.Name;

                    QXPFrk.BaseList<Ligne> __lignes = new QXPFrk.BaseList<Ligne>(__tab.Lignes.Values);
                    //tri decroissant des indexes de ligne pour une suppression sans d�calage 
                    //utilisation d'un delegate anonymous pour effectuer le trie d�croissant
                    __lignes.Sort(delegate(Ligne ligne1, Ligne ligne2) { return ligne2.Index.CompareTo(ligne1.Index); });
                    QXPFrk.BaseList<QXPSMSDK.DeleteCells> __deleteCells = new QXPFrk.BaseList<QXPSMSDK.DeleteCells>();
                    QXPSMSDK.DeleteCells __deleteCell = null;
                    //Creation de la liste des lignes � supprimer dans le tableau
                    foreach (Ligne __ligne in __lignes)
                    {
                        __deleteCell = new QXPSMSDK.DeleteCells();
                        __deleteCell.type = "ROW";
                        __deleteCell.baseIndex = QXPFrk.Conversion.ToString(__ligne.Index);
                        __deleteCell.deleteCount = "1";
                        __deleteCells.Add(__deleteCell);
                    }
                    if (__deleteCells.Count > 0)
                    {
                        __table.deleteCells = __deleteCells.ToArray();
                        __tables.Add(__table);
                    }
                }
            }

            return __tables.ToArray();
        }

        /// <summary>
		/// Retourne la liste des pages quark �valuer � partir du spread
        /// </summary>
        /// <returns>liste de page quark</returns>
		public QXPSMSDK.Page[]		GetSDKPages()
        {
            QXPSMSDK.Page					__page;
            QXPFrk.BaseList<QXPSMSDK.Page> __pages				= new QXPFrk.BaseList<QXPSMSDK.Page>();
            
			foreach (Page __pg in Pages.Values)
            {
                __page				= new QXPSMSDK.Page();
                __page.UID			= __pg.UID;

				//Tr�s important si la tache n'a pas d'action il faut rechercher le bloc qui � cr�� cette page est regarder son action !!
                switch (__pg.Task.Properties.Task_Action)
                {
                    case Task_Action_Type.NONE:
                        Bloc_Action __action = __pg.Action;
                        switch (__action)
                        {
                            case Bloc_Action.REMOVE:
                                __page.operation = Bloc_Operation.DELETE;
                                break;
                            case Bloc_Action.CREATE:
                                __page.operation = Bloc_Operation.CREATE;
                                break;
                        }
                        break;
                    case Task_Action_Type.REMOVE:
                        __page.operation = Bloc_Operation.DELETE;
                        break;
                    default:	// Par d�faut, c'est une cr�ation de page 
                        __page.operation	= Bloc_Operation.CREATE;
                        break;
                }
                // Page simple, 2�me maquette utilisateur appliqu�e
                if (__page.operation == Bloc_Operation.CREATE)
                {
                    //plus tard lorsque que nous g�rerons plusieurs pages par spread il faudra �valuer l'argument pass� (actuellement 0) en fonction de la position de la nouvelle page (LEFTOFSPIN / RIGHTOFSPIN)
					__page.master		= __pg.Task.Master_Page.Get_Master_Page_ID(0);
					
					//Affectation de la position de la page par rapport � la reliure
					__page.position		= __pg.Position;
					
					//Si l'index de la position de la page est 0 alors la page doit se trouver sur un nouveau spread
					if (__pg.Index_Position == 0)
					{
					    this.Create = true;
					}
                }
                __pages.Add(__page);
				
				if (__pg.Create_Dummy_Next_Page)
				{
					string __nextPageID = (QXPFrk.Conversion.ToInt(__pg.UID) + 1).ToString();
					//ajout de la page bidon
					__page				= new QXPSMSDK.Page();
					__page.UID			= __nextPageID;
                    __page.operation	= Bloc_Operation.CREATE;
					__pages.Add(__page);

					//suppression de la page bidon est donc d�calage des pages sur les spreads suivants
					__page				= new QXPSMSDK.Page();
					__page.UID			= __nextPageID;
                    __page.operation	= Bloc_Operation.DELETE;
					__pages.Add(__page);
					
				}
            }

            return __pages.ToArray();
        }


		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
