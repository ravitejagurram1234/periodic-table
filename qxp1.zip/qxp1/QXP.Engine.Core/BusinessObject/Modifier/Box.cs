using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sentant une boite(Box) dans un projet de modifications
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/03/2010 10:02:20</date>    
	public class Box
	{
		#region Membres
        public string				UID;

        public string				Name;

        public string				Value;

        public QXPSMSDK.Box	SrcBox;

		public int					Page_ID;

		/// <summary>
		/// Qu'elle est l'op�ration r�alis�e sur le bloc
		/// </summary>
		public Bloc_Action			Action			= Bloc_Action.NONE;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Box
		/// </summary>
		public Box()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
