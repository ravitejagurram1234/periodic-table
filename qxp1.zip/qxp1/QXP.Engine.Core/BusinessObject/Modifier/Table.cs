using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sentant une Table dans un projet de modifications
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/03/2010 10:02:20</date>    
	public class Table
	{
		#region Membres
        
		/// <summary>
		/// Unique identifier de la Table
		/// </summary>
		public string					UID;
		/// <summary>
		/// Nom de la Table
		/// </summary>
        public string					Name;
        /// <summary>
        /// Nombre de colonne de la Table
        /// </summary>
		public int						Column;
        /// <summary>
        /// Table quark source de la table en cours
        /// </summary>
		public QXPSMSDK.Table		SrcTable;
        /// <summary>
        /// Action � effectuer sur cette table
        /// </summary>
		public Bloc_Action				Action = Bloc_Action.UPDATE;
        /// <summary>
        /// Tache qui � cr�� cette table
        /// </summary>
		public Task_Base				Task;
        /// <summary>
        /// Liste des lignes de cette table
        /// </summary>
		public Dictionary<int, Ligne>	Lignes = new Dictionary<int, Ligne>();

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Table
		/// </summary>
		public Table()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
