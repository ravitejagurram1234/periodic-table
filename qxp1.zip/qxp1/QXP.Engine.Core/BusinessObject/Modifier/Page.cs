using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sentant une Page dans un projet de modification
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/03/2010 10:02:20</date>    
	public class Page
	{
		#region Membres
		/// <summary>
		/// Unique identifier de la page
		/// </summary>
        public string		UID;
		/// <summary>
		/// Nom de la page
		/// </summary>
		public string		Name;
		/// <summary>
		/// Position de la page par rapport � la reliure
		/// </summary>
		public string		Position;
		/// <summary>
		/// Index de la Position de la page dans le spread
		/// </summary>
		public int			Index_Position;
        /// <summary>
        /// Tache qui � cr��e cette Page
        /// </summary>
		public Task_Base	Task;

		/// <summary>
		/// D�fini si cette page doit cr�er une fausse page derri�re elle.
		/// � pour valeur true sous certaine condition dans le cas de page en vis � vis (sinon toujours false)
		/// voir le commentaire 
		/// </summary>
		/// <seealso cref="QXP.Engine.Core.Bloc_Page.Create_Next_Dummy_Page"/>
		public bool			Create_Dummy_Next_Page;

		/// <summary>
		/// Qu'elle est l'op�ration r�alis�e sur la page
		/// </summary>
		public Bloc_Action	Action			= Bloc_Action.NONE;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Page
		/// </summary>
		public Page()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
