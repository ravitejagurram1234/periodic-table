using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sentant un layout dans un projet de modifications quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/03/2010 10:02:20</date>    
	public class Layout
	{
		#region Membres
        
		/// <summary>
		/// nom du layout
		/// </summary>
		public string						Name;
        /// <summary>
        /// Liste des spreads du layout
        /// </summary>
		public Dictionary<string, Spread>	Spreads = new Dictionary<string, Spread>();
		
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Layout
		/// </summary>
		public Layout()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet d'obtenir les Spreads de modification quark
		/// </summary>
		/// <returns>une liste de spread quark contenant toutes les op�ration � effectuer sur le document final</returns>
		public QXPSMSDK.Spread[] GetSDKSpreads()
        {
            QXPFrk.BaseList<QXPSMSDK.Spread>		__spreads = new QXPFrk.BaseList<QXPSMSDK.Spread>();
            __spreads.AddRange(GetSDKSpreads(Spreads));
			return __spreads.ToArray();
        }

		/// <summary>
		/// Permet d'obtenir les spreads de modification quark
		/// </summary>
		/// <param name="spreads">liste des spreads � utiliser pour g�n�rer les spreads de modification quark</param>
		/// <returns>une liste de spread quark contenant toutes les op�ration � effectuer sur le document final</returns>
		private QXPSMSDK.Spread[] GetSDKSpreads(Dictionary<string, Spread> spreads)
		{
			QXPSMSDK.Spread						__spread;
            QXPFrk.BaseList<QXPSMSDK.Spread>		__spreads		= new QXPFrk.BaseList<QXPSMSDK.Spread>();

            //Ce tri est r�alis� car certaines op�rations ajoutent des blocs directement dans le Modifier
            //hors ces blocs ne respectent pas l'ordre croissant des id des spreads obligatoires
            /* Il est plus simple de trier le dictionaire que la future liste des spreads. */
            foreach (var __keyValue in spreads.OrderBy(kvp => QXPFrk.Conversion.ToInt(kvp.Key)))
            {
                Spread  __sp = __keyValue.Value;
                __spread		= new QXPSMSDK.Spread();
                __spread.UID	= __sp.UID;
                __spread.boxes	= __sp.GetSDKBoxes();
				__spread.tables = __sp.GetSDKTables();
                __spread.pages	= __sp.GetSDKPages();

				//V�rification si c'est une cr�ation de spread
				if (__sp.Create)
				{
					__spread.operation = Bloc_Operation.CREATE;
				}

				//INFO dans cette version de quarkXpress server (7.24) il est impossible de cr�er des groupes de boites
				//en revanche en 8.x c'est possible cette fonction sera � r�activer / mettre � jour au changement de version !!
				//pour l'instant c'est fait dans GetSDKBoxes()
				//__spread.groups	= __sp.GetSDKGroups(__sp.UID);
                
                __spreads.Add(__spread);
				//s'il y � des box extra il faut recr�er un nouveau spread portant le m�me identifiant que celui en cours mais avec les box extra
				if (__sp.Boxes_Extra.Count > 0)
				{
					__spread		= new QXPSMSDK.Spread();
					__spread.UID	= __sp.UID;
					__spread.boxes	= __sp.GetSDKBoxesExtra();
					__spreads.Add(__spread);
									
				}
            }

			return __spreads.ToArray();
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
