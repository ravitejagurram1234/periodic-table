using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Classe repr�sentant un projet de modifications
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/03/2010 10:02:20</date>    
	public class Projet
	{
		#region Membres
		/// <summary>
		/// Liste des layouts contenu dans le projet
		/// </summary>
		public Dictionary<string, Layout> Layouts = new Dictionary<string, Layout>();
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Projet
		/// </summary>
		public Projet()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// R�cup�ration du projet initial
		/// </summary>
		/// <returns></returns>
        public QXPSMSDK.Project GetSDKProject()
        {
            QXPSMSDK.Project						__project = new QXPSMSDK.Project();
            QXPFrk.BaseList<QXPSMSDK.Layout>		__layouts = new QXPFrk.BaseList<QXPSMSDK.Layout>();
            __layouts.AddRange(this.GetSDKLayouts(Layouts));
			__project.layouts = __layouts.ToArray();
            return __project;
        }

        /// <summary>
        /// Permet d'obtenir la liste des Layout quark de modification contenu dans le projet en cours
        /// </summary>
        /// <returns>liste des layouts quark qui contient les modification � effectuer sur le document final quark</returns>
		private QXPSMSDK.Layout[] GetSDKLayouts(Dictionary<string, Layout> layouts)
        {
            QXPSMSDK.Layout						__layout;
            QXPFrk.BaseList<QXPSMSDK.Layout>		__layouts = new QXPFrk.BaseList<QXPSMSDK.Layout>();
            foreach (Layout __la in layouts.Values)
            {
                __layout = new QXPSMSDK.Layout();
                __layout.name = __la.Name;
                __layout.spreads = __la.GetSDKSpreads();
                __layouts.Add(__layout);
            }
			return __layouts.ToArray();
        }


		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
