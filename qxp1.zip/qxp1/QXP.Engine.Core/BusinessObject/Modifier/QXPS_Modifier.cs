using System;
using System.Collections.Generic;
using System.Text;
//TEMP
using System.IO;
using System.Xml.Serialization;
using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;

using QXPFrk	= QXP.Framework;
using QXPIO		= QXP.Framework.IO;
using QXPAudit	= QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les fonctions d'aggr�gation de tous les types de bloc dans une arboresence qui servira
	/// enfin � g�n�rer une structure "QXPSMSDK.Project" qui sera envoy�e � QuarkXpress server � travers la command "Modify"
	/// </summary>
	/// <remarks>
	/// Cette structure "QXPSMSDK.Project" fournit par le web service contient des r�f�rences et des actions � r�alis�e sur le document quark finale.
	/// (exemple suppression page 1)
	/// Cette couche est importante car elle est evalu�e entre chaque �tape de la g�n�ration du rapport finale, les spread Id sont donc � jour !!
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>23/03/2010 16:55:22</date>    
	public class QXPS_Modifier
	{
		#region Membres
		Projet						_projet			= new Projet();
        bool						_empty			= true;
		bool						_empty_Extra	= true;
		QXPFrk.BaseList<Bloc_Base>	_blocs			= new QXPFrk.BaseList<Bloc_Base>();
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�ation de l'aborescence locale qui permettra de cr�� un projet de modifications quark 
		/// </summary>
		public QXPS_Modifier()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet d'ajouter un ensemble de bloc_base dans le modifier
		/// </summary>
		/// <param name="blocs">liste des blocs � ajouter</param>
		public void AddRange(IEnumerable<Bloc_Base> blocs)
		{
			foreach(Bloc_Base __bloc in blocs)
			{
				this.Add(__bloc);
			}
		}
		
		/// <summary>
		/// ajout d'un bloc a l'arborescence locale
		/// </summary>
		/// <remarks>
		/// ce bloc peut avoir diff�rents types ex: Box Spread etc..
		/// </remarks>
		/// <param name="bloc">bloc � ajouter dans le projet</param>
		public void Add(Bloc_Base bloc)
        {
			//si le bloc est � ignorer on ne l'ajoute pas
			if (bloc.Exclude) return;

			if(QXPFrk.Validation.IsNotNull(bloc)) _blocs.Add(bloc);


            Bloc_Box __blocBox = bloc as Bloc_Box;

            if (QXPFrk.Validation.IsNotNull(__blocBox))
            {
                this.Add(__blocBox);
                return;
            }
            
			Bloc_Group __blocGroup = bloc as Bloc_Group;
            
            if (QXPFrk.Validation.IsNotNull(__blocGroup))
            {
                this.Add(__blocGroup);
                return;
            }

            Bloc_Table __blocTable = bloc as Bloc_Table;
            
            if (QXPFrk.Validation.IsNotNull(__blocTable))
            {
                this.Add(__blocTable);
                return;
            }

            Bloc_Ligne __blocLigne = bloc as Bloc_Ligne;
            
            if (QXPFrk.Validation.IsNotNull(__blocLigne))
            {
                this.Add(__blocLigne);
                return;
            }

            Bloc_Page __blocPage = bloc as Bloc_Page;
            
            if (QXPFrk.Validation.IsNotNull(__blocPage))
            {
                this.Add(__blocPage);
                return;
            }
        }

		/// <summary>
		/// ajout d'un bloc de type box � l'arborescence locale
		/// </summary>
		/// <param name="bloc">la boite � ajouter dans le projet</param>
		private void Add(Bloc_Box bloc)
        {
            Box		__box;
            Spread	__spread = this.AddGetSpread(bloc);

            if (QXPFrk.Validation.IsSet(__spread))
            {
                __box				= new Box();
                __box.Name			= bloc.Name;
				__box.Action		= bloc.Action;
				__box.Page_ID		= bloc.Page_ID;
                __box.Value			= bloc.Value;
                __box.SrcBox		= Get_Box(bloc, false);

                __spread.Boxes.Add(__box.Name, __box);

				//ajout des Box Extra dans la liste des SrcExtra 
				if(QXPFrk.Validation.IsNotNull(bloc.SrcExtraBox))
				{
					__box				= new Box();
					__box.Name			= bloc.Name;
					__box.Action		= bloc.Action;
					__box.Page_ID		= bloc.Page_ID;
					__box.Value			= bloc.Value;
					__box.SrcBox		= Get_Box(bloc, true);
					__spread.Boxes_Extra.Add(__box.Name, __box);
				}
            }
        }

        /// <summary>
        /// ajout d'un bloc de type table � l'arborescence locale
        /// </summary>
        /// <param name="bloc">la table � ajouter dans le projet</param>
		private void Add(Bloc_Table bloc)
        {
            Spread __spread = this.AddGetSpread(bloc);

            if (QXPFrk.Validation.IsSet(__spread))
            {
                Table __table = new Table();
                __table.Name		= bloc.Name;
                __table.Action		= bloc.Action;
                __table.Task		= bloc.Task;
                __table.SrcTable	= bloc.SrcTable;

                if (!__spread.Tables.ContainsKey(__table.Name))
                {
                    __spread.Tables.Add(__table.Name, __table);
                }
                else
                {
                    // si le tableau existe dej� et que le nouveau bloc � action Remove 
                    // alors la suppression des Lignes ne servent plus � rien donc ont supprime les �ventuelles lignes
                    __table = __spread.Tables[__table.Name];
                    if (bloc.Action == Bloc_Action.REMOVE)
                    {
                        __table.Action = bloc.Action;
                        __table.Lignes.Clear();
                    }
                }
            }
        }

		/// <summary>
		/// ajout d'un bloc de type ligne � l'arborescence locale
		/// </summary>
		/// <param name="bloc">la ligne � ajouter dans le projet</param>
        private void Add(Bloc_Ligne bloc)
        {
            Table __table = this.AddGetTable(bloc);
            
			if (QXPFrk.Validation.IsSet(__table))
            {
                Ligne __ligne = new Ligne();
                __ligne.Index = bloc.Index;

                //On n'ajoute pas de ligne en suppression si le tableau va �tre supprim�
                if (!__table.Lignes.ContainsKey(bloc.Index) && __table.Action != Bloc_Action.REMOVE)
                {
					__table.Lignes.Add(__ligne.Index, __ligne);
                }
            }
        }

        /// <summary>
        /// ajout d'un bloc de type page � l'arborescence locale
        /// </summary>
        /// <param name="bloc">la page � ajouter dans le projet</param>
		private void Add(Bloc_Page bloc)
        {
            Spread __spread = this.AddGetSpread(bloc);

            if (QXPFrk.Validation.IsSet(__spread))
            {
                Page __page = new Page();
				__page.Action					= bloc.Action;
                __page.UID						= bloc.Page_ID.ToString();
				__page.Position					= bloc.Position;
				__page.Index_Position			= bloc.Index_Position;
				__page.Name						= bloc.Name;
                __page.Task						= bloc.Task;
				__page.Create_Dummy_Next_Page	= bloc.Create_Next_Dummy_Page;

                if (!__spread.Pages.ContainsKey(__page.UID)) __spread.Pages.Add(__page.UID, __page);
            }

        }

		/// <summary>
        /// ajout d'un bloc de type group � l'arborescence locale
		/// </summary>
		/// <param name="bloc">le groupe � ajouter dans la structure du projet</param>
		private void Add(Bloc_Group bloc)
		{
            Group		__group;
            Spread		__spread = this.AddGetSpread(bloc);

            if (QXPFrk.Validation.IsSet(__spread))
            {
                __group					= new Group();
                __group.Name			= bloc.Name;
				__group.Page_ID			= bloc.Page_ID;
				__group.Action			= bloc.Action;
                __group.SrcBoxes		= Get_Group(bloc);

                __spread.Groups.Add(__group.Name, __group);
            }			
		}


		/// <summary>
		/// Permet une v�rification des styles de paragraphes et de charact�res contenu dans la boite source.
		/// Les style doivent exister dans le gabarit sinon il sont effacer du bloc source. 
		/// retourne la box pr�te � �tre inject�e dans un document quark
		/// </summary>
		/// <param name="bloc_box">le Bloc_Box � analyser</param>		
		/// <param name="FromExtraSrc">Defini si l'ont recherche la Box dans la propri�t� ExtraBox(true) ou SrcBox (false) <see cref="Bloc_Box"/></param>
		/// <returns>la boite quark</returns>
		private QXPSMSDK.Box	Get_Box(Bloc_Box bloc_box, bool FromExtraSrc) 
		{ 
			QXPSMSDK.Box __box ;
			
			if(FromExtraSrc)
			{
				__box = bloc_box.SrcExtraBox;
			}
			else
			{
				__box = bloc_box.SrcBox;
			}
            
			/* ATTENTION CE CODE A ETE DESACTIVER PROVISOIREMENT */
			/* � la base il devait supprimer les styles qui n'�taient pas disponible dans le document final mais il semble enlever des styles pourtant disponible */
			/*
			QXP_XML __xml = bloc_box.Task.Run.Properties.Gabarit.XML;

			CheckBoxStyle(__box, __xml);
			*/
			return __box;
		}

		/// <summary>
		/// Permet une v�rification des styles de paragraphes et de charact�res contenu dans la boite source.
		/// Les style doivent exister dans le gabarit sinon il sont effacer du bloc source. 
		/// retourne la box pr�te � �tre inject�e dans un document quark
		/// </summary>
		/// <param name="bloc_group">le groupe � utiliser pour r�cup�rer le groupe quark</param>		
		/// <returns>le groupe quark</returns>
		private QXPSMSDK.Box[]	Get_Group(Bloc_Group bloc_group) 
		{ 
			/* ATTENTION CE CODE A ETE DESACTIVER PROVISOIREMENT */
			/* � la base il devait supprimer les styles qui n'�taient pas disponible dans le document final mais il semble enlever des styles pourtant disponible */
			/*
			QXP_XML				__xml	= bloc_group.Task.Run.Properties.Gabarit.XML;

			if(QXPFrk.Validation.IsSet(__group.boxes))
			{
				foreach(QXPSMSDK.Box __box in __group.boxes)
				{
					CheckBoxStyle(__box, __xml);
				}
			}
			*/

			return bloc_group.SrcBoxes;

		}

		//D�sactiv� pour le moment
		///// <summary>
		///// Permet de v�rifier et �ventuellement de mettre � jour (effacer) les styles s'il ne sont pas pr�sent dans le document destination
		///// </summary>
		///// <param name="box">la boite (Box) � v�rifier)</param>
		///// <param name="xml">le v�rificateur de style � utiliser </param>
		//private void				CheckBoxStyle(QXPSMSDK.Box box, QXP_XML xml)
		//{
		//    // Verification des styles utilis�es dans le bloc de texte
		//    if (QXPFrk.Validation.IsNotNull(box))
		//    {
		//        //check couleur de la boite
		//        box.color = xml.CheckColor(box.color);
		//        if(QXPFrk.Validation.IsNotNull(box.text) 
		//        && QXPFrk.Validation.IsNotNull(box.text.story) 
		//        && QXPFrk.Validation.IsSet(box.text.story.paragraphs))
		//        {

		//            foreach (QXPSMSDK.Paragraph paragraph in box.text.story.paragraphs)
		//            {
		//                //check style paragraphe du paragraph
		//                paragraph.paraStyle = xml.CheckParagraphStyle(paragraph.paraStyle);
		//                if (QXPFrk.Validation.IsSet(paragraph.richText))
		//                {
		//                    foreach (QXPSMSDK.RichText text in paragraph.richText)
		//                    {
		//                        //check couleur du text
		//                        text.color		= xml.CheckColor(text.color);
		//                        //check style charat�re du text
		//                        text.charStyle	= xml.CheckCharacterStyle(text.charStyle);
		//                    }
		//                }
		//            }
		//        }			
		//    }
		//}
		
		/// <summary>
		/// Permet de r�cup�rer le layout sur lequel va travailler le bloc
		/// </summary>
		/// <param name="bloc">le bloc contenant les informations permettant de d�terminer le layout sur lequel il va �tre pos�</param>
        /// <returns>le nouveau layout qui doit contenir le bloc si le layout existe d�j� il est retourn�</returns>
		private Layout					AddGetLayout(Bloc_Base bloc)
		{
            Layout __layout;
			string __layout_Name = string.Empty;
            
			//Si un bloc conditionnel est d�fini il est sur le m�me layout que le bloc (� cr�er/modifier/supprimer)
			if(QXPFrk.Validation.IsSet(bloc.CondName))
            {
                __layout_Name = bloc.Task.Run.Gabarit.XML.GetLayoutName(bloc.CondName);
            }
            else
            {
                __layout_Name = bloc.Task.Properties.LayoutName;
            }

			//Si pas de nom de layout alors on renvoi null !! et le Bloc_base sera ignor� dans la hierarchie au dessus
			if(QXPFrk.Validation.IsNotSet(__layout_Name)) return null;

            if (_projet.Layouts.ContainsKey(__layout_Name))
            {
                __layout = _projet.Layouts[__layout_Name];
            }
            else
            {
				__layout		= new Layout();
                __layout.Name	= __layout_Name;
                _projet.Layouts.Add(__layout.Name, __layout);
            }
			
			return __layout;
		}

        /// <summary>
        /// Permet de renvoy� le spread qui devra contenir le bloc
        /// </summary>
        /// <param name="bloc">bloc � utiliser pour d�termin� le spread</param>
        /// <returns>le nouveau spread qui doit contenir le bloc si le spread existe d�j� il est retourn�</returns>
		private Spread					AddGetSpread(Bloc_Base bloc)
        {
            Layout		__layout;
            Spread		__spread;
			string		__spreadUID;
            
			__layout = AddGetLayout(bloc);
			
			//Si pas de layout alors on renvoi null !! et le Bloc_base sera ignor� dans la hierarchie au dessus
			if(QXPFrk.Validation.IsNull(__layout))
			{
				bloc.Task.Run.Errors.Add(Constantes.Error_Messages.Empty_Layout_Or_Spread_For_Bloc, bloc.Name);
				return null;
			}
			
			//on considere pour l'instant que si un Bloc_base � un layout et un spread il g�n�rera/modifira quelque chose. on pourra affiner plus tard cette propri�t� en fonction des cas !!
			_empty = false;
			
			__spreadUID = bloc.Spread_ID.ToString();

			////Gestion du param�tre Extra, si extra est true alors on travail sur une autre collection de spread qui seront int�gr�s dans un deuxieme temps dans le m�me Projet
			Dictionary<string, Spread> __spreads = __layout.Spreads;

			if (__spreads.ContainsKey(__spreadUID))
		    {
		        __spread = __spreads[__spreadUID];
		    }
		    else
		    {
	            __spread		= new Spread();
	            __spread.UID	= __spreadUID;
		        __spreads.Add(__spreadUID, __spread);
		    }

            return __spread;
        }

        /// <summary>
        /// permet de retourner la table qui doit contenir le bloc
        /// </summary>
        /// <param name="bloc">le bloc contenant les informmations permettant de d�terminer le Table qui doit le contenir</param>
        /// <returns>la table </returns>
		private Table					AddGetTable(Bloc_Base bloc)
        {
            Table	__table		= null;
            Spread	__spread	= this.AddGetSpread(bloc);
            if (QXPFrk.Validation.IsSet(__spread))
            {
                if (__spread.Tables.ContainsKey(bloc.ParentName))
                {
                    __table = __spread.Tables[bloc.ParentName];
                }
                else
                {
                    __table				= new Table();
                    __table.Name		= bloc.ParentName;
                    __table.Action		= Bloc_Action.NONE;
                    __table.Task		= bloc.Task;
                    __spread.Tables.Add(__table.Name, __table);
                }
            }
            return __table;
        }

        /// <summary>
        /// R�cup�ration du projet final de modification Quark
        /// </summary>
        /// <returns>Un projet de modification quark</returns>
		public QXPSMSDK.Project	GetProject()
        {
            QXPSMSDK.Project	__project	= _projet.GetSDKProject();
            return __project;
        }

        /// <summary>
        /// R�cup�ration du flux binaire du projet final de modification Quark. 
		/// Cette methode est appell�e par les appel directe � quark
        /// </summary>
        /// <returns>Flux binaire d�duit � partir de la serialisation du projet</returns>
		public QXPIO.IOValue	GetIOValue()
        {
            QXPSMSDK.Project	__project	= this.GetProject();
			return QXP_Project_Serializer.Get_IOValue(__project);
        }

		/// <summary>
		/// Debug only permet de retourver une/des boites par le nom dans une hierarchie (Project)
		/// </summary>
		/// <param name="project">structure d'un projet quark</param>
		/// <param name="box_Name">nom � rechercher</param>
		/// <returns>liste des boites contenant le nom recherch�</returns>
		private QXPSMSDK.Box[] Find_Boxes(QXPSMSDK.Project project, string box_Name)
		{
			List<QXPSMSDK.Box> __boxes = new List<QXPSMSDK.Box>();
			foreach(QXPSMSDK.Layout __layout in project.layouts)
			{
				foreach(QXPSMSDK.Spread __spread in __layout.spreads)
				{
					if(QXPFrk.Validation.IsSet(__spread.boxes))
					{
						foreach(QXPSMSDK.Box __box in __spread.boxes)
						{
							if(string.Compare(__box.name, box_Name, true) == 0) //Equals
							{
								__boxes.Add(__box);
							}
						}
					}
				}
			}
			return __boxes.ToArray();
		}
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Les taches primaires de ce "Modifier" sont-elles vides (sans aucun bloc)
		/// </summary>
        public bool Empty
        {
            get { return _empty; }
        }

		/// <summary>
		/// Les taches secondaires de ce "Modifier" sont-elles vides (sans aucun bloc)
		/// </summary>
        public bool				Empty_Extra
        {
            get { return _empty_Extra; }
        }

		/// <summary>
		/// Repr�sente la liste des blocs en vracs contenus dans ce modifier. (utile par exemple pour effectuer des mise � jour en lot)
		/// </summary>
		public QXPFrk.BaseList<Bloc_Base> Blocs
		{
			get{return _blocs;}
		}
		#endregion Propri�t�s
	}
}
