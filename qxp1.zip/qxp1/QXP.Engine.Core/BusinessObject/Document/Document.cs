using System;

using QXPFrk	= QXP.Framework;
using QXPIO = QXP.Framework.IO;

using QXPInterop			= QXP.Interop;
using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;

using QXPSMSDK         = com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les informations d'un document manipul�s par l'engine
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:53:05</date>    
	public class Document
	{
		#region Membres
        int						_id             = 0;
        byte[]					_data           = new byte[0];
        Document_Type			_type           = Document_Type.Unknown;
        int						_id_langue      = 1;
        string					_format         = null;
        string					_name;
        string					_fileName       = string.Empty;
        string					_filePoolPath   = string.Empty;
        string					_fileFullPath   = string.Empty;
        string					_prefix         = string.Empty;

		QXPFrk.BaseList<QXPIO.PDF_File>	_pdfs;

        private QXP_Project		_project		= null;
        private bool			_is_Gabarit		= true;
        QXP_XML					_xml            = null;
        Document_Identity		_identity       = new Document_Identity();
		bool?					_mode_degrade	= null;

		int						SizeLimitBeforeFailSoft = EngineCoreSetting.Current.Size_Limit_Before_Fail_Soft;

		#endregion Membres

		#region Constantes
		
		const string        FileNamePrefixePattern		= "{0}_{1}.{2}";
		const string        FileNamePattern				= "{0}.{1}";
        
		/// <summary>
		/// Prefix des documents classique
		/// </summary>
		public const string         FileDocumentPrefix			= "D";

		/// <summary>
		/// Prefix des gabarits
		/// </summary>
		public const string			FileGabaritPrefix			= "G";
		
		/// <summary>
        /// Prefix des documents gabarit
        /// </summary>
		public const string			FileDocumentGabaritPrefix	= "DG";

		/// <summary>
        /// Prefix des documents certifi�s gabarit
        /// </summary>
		public const string			FileDocumentCertifieGabaritPrefix	= "DCG";

		/// <summary>
        /// Prefix des document gabarit
        /// </summary>
		public const string			FileDocumentFinalPrefix		= "DF";

		/// <summary>
        /// Prefix des gabarit template	
        /// </summary>
		public const string			FileGabaritTemplatePrefix	= "GT";

		int							Def_Box_Size				= EngineCoreSetting.Current.Average_Box_Size;
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Document
		/// </summary>
		/// <param name="id">identifiant du document</param>
		/// <param name="name">nom du document</param>
		/// <param name="format">format du document</param>
		/// <param name="data">donn�es binaires du document</param>
		public Document(int id, string name, string format, byte[] data): this(id, name, format, FileDocumentPrefix, data)
		{
		
		}
		/// <summary>
		/// Cr�e une instance de Document
		/// </summary>
		/// <param name="id">identifiant du document</param>
		/// <param name="name">nom du document</param>
		/// <param name="format">format du document</param>
		/// <param name="prefix">Pr�fixe du document</param>
		/// <param name="data">donn�es binaires du document</param>
		public Document(int id, string name, string format, string prefix, byte[] data)
		{
            _id             = id;
            _data           = data;
            _name           = name;
            _format         = format;
            _prefix         = prefix;
            _type           = GetDocumentType(format);
            _fileName       = string.Format(FileNamePrefixePattern, _prefix, this.ID, format);
            // Builds the relative file path by concatenating the current pool path with the file name
            // Returns a relative path to the document within the Quark pool (e.g., "R_102\D_1.pdf")
            _filePoolPath   = QXPS_File_Manager.GetPoolPath(_fileName);
            // Builds the absolute file path by concatenating the current absolute pool path with the file name
            // Returns a complete absolute path to the document (e.g., "C:\QuarkPool\R_102\D_1.pdf")
            _fileFullPath   = QXPS_File_Manager.GetPoolPathAbsolute(_fileName);
		}

		/// <summary>
		/// Cr�e une instance de Document
		/// </summary>
		/// <param name="name">nom du document</param>
		/// <param name="data">donn�es binaires du document</param>
		/// <param name="format">format du document</param>
		public Document(string name, byte[] data, string format)
		{
            _name           = name;
            _format         = format;
            _data           = data;
            _type           = GetDocumentType(format);
            _fileName       = string.Format(FileNamePattern, name, format);
            _filePoolPath   = QXPS_File_Manager.GetPoolPath(_fileName);
            _fileFullPath   = QXPS_File_Manager.GetPoolPathAbsolute(_fileName);
		}
		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet de d�terminer le type de document en fonction du format
		/// </summary>
		/// <param name="format">format du document exemple (PDF, JPEG)</param>
		/// <returns></returns>
        static Document_Type	GetDocumentType(string format)
		{
            if(QXPFrk.Validation.IsNotSet(format)) return Document_Type.Unknown;
            Document_Type __type = Document_Type.Unknown;
            switch(format.ToUpper())
			{
                case "PDF":     __type = Document_Type.PDF; break;
                case "JPG":
                case "JPEG":
                case "EPS":
                case "GIF":
                case "PNG":     __type = Document_Type.IMG; break;
                case "XTG":     __type = Document_Type.XTG; break;
                case "DOC":     __type = Document_Type.DOC; break;
                case "RTF":     __type = Document_Type.RTF; break;
                case "QXP":     __type = Document_Type.QXP; break;
            }
            return __type;
        }

		/// <summary>
		/// Changement de gabarit (mais le fichier est d�j� sur le server quark
		/// </summary>
		/// <param name="newName">Nouveau nom du document</param>
        public void				Change_Document(string newName)
		{
            _fileName       = newName;
            _filePoolPath   = QXPS_File_Manager.GetPoolPath(_fileName);
            _fileFullPath   = QXPS_File_Manager.GetPoolPathAbsolute(_fileName);

			//purge du xml et du projet il est erron� maintenant
			_xml			= null;
			_project		= null;

            _data           = QXPInteropQuarkServer.QXPS_Helper.GetFileData(_filePoolPath);

			//Il faut purger tout �a en force maintenant
			GC.Collect();
			GC.WaitForPendingFinalizers();

        }

		/// <summary>
		/// Permet d'�valuer l'identit�e d'un document quark
		/// ne fonctionne que sur les fichiers qxp g�n�r�s par un run pr�c�dent
		/// </summary>
		public void				Evaluate_Document_Identity()
		{
            
			try
			{
				//uniquement si le document n'est pas en mode d�grad�
				if (!this.Mode_Degrade)
				{
					//Si c'est un document qxp et que l'objet this.XML contient quelque chose
					if (this.Type == Document_Type.QXP && QXPFrk.Validation.IsNotNull(this.XML))
					{
						string __str_identity = this.XML.GetValue(Document_Identity.DID);
						_identity = new Document_Identity(__str_identity);
					}
					else
					{
						throw new Exception_DID();
					}
				}
			}
			catch(Exception_DID)
			{
				throw;
			}
			catch(Exception ex)
			{
				throw new Exception_DID(ex);
			}

		}

		/// <summary>
		/// Si la taille du document gabarit atteint une certaine taille il passe en mode d�grad�
		/// </summary>
		private bool			Evaluate_Mode_Degrade()
		{
			//Que pour les fichier QXP
			if (this.Type == Document_Type.QXP && QXPFrk.Validation.IsSet(this.Data))
			{
				return (_data.Length > SizeLimitBeforeFailSoft);
			}
			else
			{
				return false;
			}
		}

		#endregion M�thodes

		#region Propri�t�s
		#region Commun a tous les type de document
		/// <summary>
		/// 
		/// </summary>
        public int                  ID{
            get{return _id;}
        }

		/// <summary>
		/// donn�es binaires du document
		/// </summary>
        public byte[]               Data{
            get{return _data;}
        }
        
		/// <summary>
		/// Type de document
		/// </summary>
		public Document_Type        Type{
            get{return _type;}
            set{_type = value;}
        }
        
		/// <summary>
		/// format du document
		/// </summary>
		public string               Format{
            get{return _format;}
        }
        
		/// <summary>
		/// Nom du document
		/// </summary>
		public string               Name{
            get{return _name;}
        }
        
		/// <summary>
		/// Identifiant de la langue du document
		/// </summary>
		public int                  ID_Langue{
            get{return _id_langue;}
            set{_id_langue = value;}
        }
        
		/// <summary>
		/// Nom du fichier  (ce nom est d�termin� par le prefix, nom et format)
		/// </summary>
		public string               FileName{
            get{return _fileName;}
        }
        
		/// <summary>
		/// Nom complet du fichier dans le pool path de quark
		/// </summary>
		public string               FilePoolPath{
            get{return _filePoolPath;}
        }
        
		/// <summary>
		/// Nom complet absolu du fichier dans le pool path de quark
		/// </summary>
		public string               FileFullPath{
            get{return _fileFullPath;}
        }
        
		/// <summary>
		/// Prefix du fichier
		/// </summary>
		public string               FilePrefix{
            get{return _prefix;}
		}

		/// <summary>
		/// D�fini si le document fonctionne en mode degrad�. 
		/// Lorsque le document atteint une certaine taille le run s'�x�cute en mode d�grad� et n'execute aucune tache y compris les taches DID
		/// dans ce cas il tente d'effectue uniquement un rendu pdf du document et r�cup�re le qxp correspondant sans modification
		/// </summary>
		public bool					Mode_Degrade
		{
			get
			{
				//Evaluation du mode d�grad� si �a n'a jamais �t� fait !
				if (!_mode_degrade.HasValue)
				{
					_mode_degrade = this.Evaluate_Mode_Degrade();
				}

				return _mode_degrade.Value;
			}
		}
		#endregion Commun a tous les type de document

		#region sp�cifique au document de ref�rence
		
		/// <summary>
		/// Liste des fichiers pdf contenue dans ce document
		/// </summary>
		public QXPFrk.BaseList<QXPIO.PDF_File>  PDFFiles {
			get { return _pdfs; }
            set { _pdfs = value; }
		}
        
		/// <summary>
		/// Premet d'obtenir un nom complet de fichier dans le poolpath pour un pdf particulier contenu dans le document
		/// </summary>
		/// <param name="file"></param>
		/// <returns></returns>
		public string GetPDFFilePoolPath(QXPIO.PDF_File file)
		{
            return QXPS_File_Manager.GetPoolPath(file.FileName);
        }
        
		/// <summary>
		/// Premet d'obtenir un nom complet absolu de fichier dans le poolpath pour un pdf particulier contenu dans le document
		/// </summary>
		/// <param name="file"></param>
		/// <returns></returns>
		public string GetPDFFileAbsolutePath(QXPIO.PDF_File file)
		{
            return QXPS_File_Manager.GetPoolPathAbsolute(file.FileName);
        }

		#endregion sp�cifique au document de ref�rence

		#region sp�cifique au document de qxp
		
		/// <summary>
		/// Ce document est-il un vrai gabarit quark (ou un document gabarit ou autre chose)
		/// </summary>
		public bool							Is_Gabarit
        {
            get { return _is_Gabarit; }
            set { _is_Gabarit = value; }
        }

        /// <summary>
        /// Obtient le Projet QXP relatif au gabarit.
        /// Attention cet action implique un temps de traitement assez long.
        /// Neanmoins il n'est effectu� qu'une fois car le resultat est plac� en cache
        /// </summary>
        public QXP_Project					QXPProject
        {
            get
            {
				if (this.Type == Document_Type.QXP && QXP.Framework.Validation.IsNull(_project))
                {
					if (!this.Mode_Degrade)
					{
						try
						{
                            QXPSMSDK.Project __qxp_Project = QXPS_File_Manager.Get_Project(this);
							_project = new QXP_Project(__qxp_Project);
						}
						//S'il est impossible d'obtenir le DOM du document qxp le document passe en mode d�grad�
						catch
						{
							_project		= QXP_Project.Empty;
							_mode_degrade	= true;
						}
						
					}
					else
					{
						_project = QXP_Project.Empty;
					}
					
                }
                return _project;
            }
        }

		/// <summary>
		/// Structure d'analyse XML du document quark
        /// Attention cet action implique un temps de traitement assez long.
        /// Neanmoins il n'est effectu� qu'une fois car le resultat est plac� en cache
		/// </summary>
		public QXP_XML						XML{
            get{
				if(this.Type == Document_Type.QXP && QXP.Framework.Validation.IsNull(_xml))
				{
					//uniquement en mode non d�grad�
					if (!this.Mode_Degrade)
					{
						try
						{
							_xml = QXPS_File_Manager.Get_XML(this);
						}
						//S'il est impossible d'obtenir la structure xml du document qxp le document passe en mode d�grad�
						catch
						{
							_xml			= QXP_XML.Empty;
							_mode_degrade	= true;
						}
					}
					else
					{
						_xml = QXP_XML.Empty;
					}
				}
				return _xml;
			}
        }
        
		/// <summary>
		/// Identit� (obtenu dans le bloc DID) d'un document Quark (si c'est un document g�n�r� par le g�n�rateur)
		/// </summary>
		public Document_Identity			Identity{
            get{return _identity;}
        }

		/// <summary>
		/// Permet d'�valuer la complexit� d'un document qxp en comparant la taille du qxp avec le nombre de box contenu
		/// plus cette valeur est grande plus les boites sont complexes
		/// Cette valeur sera plus tard utiliser pour �valuer si le nombre de boite pr�sent dans le document est trop grand pour ajouter d'autre boite
		/// Sur les petits documents ce ratio peut �tre tr�s grand mais le calcul final du coefficient poss�de des limites qu'il ne peut pas d�pass�e
		/// le ratio renvoy� est celui par d�faut s'il n'y � pas assez de Box dans le document (>100)
		/// </summary>
		public int							Ratio_Size_Box
		{
			get
			{
				if (this.Type == Document_Type.QXP && QXPFrk.Validation.IsSet(this.Data) && QXPFrk.Validation.IsNotNull(this.XML) && this.XML.Project_Info.NbBox > 100)
				{
					return (this.Data.Length  / this.XML.Project_Info.NbBox);				
				}
				else
				{
					return Def_Box_Size;
				}
			}
		}

		/// <summary>
		/// D�fini un coefficient de complexit� des boite dans le document qxp
		/// si la valeur est �gale � 1 les boites sont 'normales' si la valeur est plus grand elle sont plus complexe 
		/// ce coefficient sera utilis� pour connaitre le nombre de boites maximum que peu contenir un document modifi�
		/// Attention ce coefficient peut �tre fort surtout sur les petits documents avec des images , mais cette valeurs est r�guli�rement r��valuer en fonction de la derni�re version du document
		/// et il existe des syst�mes de limitations de variation
		/// </summary>
		public decimal Box_Complexity
		{
			get
			{
				return ((decimal)this.Ratio_Size_Box / (decimal)Def_Box_Size);
			}
		}
		#endregion sp�cifique au document de qxp

		#endregion Propri�t�s
	}
}
