using System;

using QXPFrk = QXP.Framework;

namespace QXP.Engine.Core
{
	/// <summary>
	/// R�pr�sente l'identit� d'un document Quark, � chaque modification d'un document cette identit� est mise � jour
	/// </summary>
	/// <remarks>
	/// Cette identit� contient les informations suivantes:
	/// - code fond
	/// - id run
	/// - id suivi
	/// - id langue
	/// - date echeance
	/// - date de mise � jour
	/// - code de la part
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>23/03/2010 09:55:57</date>    
	public class Document_Identity
	{
		#region Membres
		string		_value;
        string		_id_Fnd_Code;
        string		_id_Unit_Code = string.Empty;
        int			_id_Run;
        int			_id_Suivi;
        int			_id_Langue;
        DateTime	_date_Echeance;
        DateTime	_date_Last_Execution;

		#endregion Membres

		#region Constantes
		/// <summary>
		/// Repr�sente le nom "DID" du bloc dans contenant les informations de g�n�ration d'un rapport par le g�n�rateur
		/// </summary>
		public const string DID = "DID";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Document_Identity
		/// </summary>
		public Document_Identity()
		{
		}

		/// <summary>
		/// Creation d'une identit� � partir de la valeur contenu dans le champs DID d'un document quark
		/// </summary>
		/// <param name="valeur_champs"></param>
		public Document_Identity(string valeur_champs)
        {
			_value = valeur_champs;

            string[] __values = QXPFrk.Conversion.ToString(valeur_champs).Split('|');
            if (__values.Length >= 6)
            {
                //Ces valeurs doivent toujours �tre pr�sentes

				//Id_Fnd_Code
                _id_Fnd_Code			= __values[0];
                //IdSuivi
                _id_Suivi				= QXPFrk.ConversionInvariante.ToInt(__values[1]);
                //IdRun
                _id_Run					= QXPFrk.ConversionInvariante.ToInt(__values[2]);
                //IdLangue
                _id_Langue				= QXPFrk.ConversionInvariante.ToInt(__values[3]);
                //Date Echeance
                _date_Echeance			= QXPFrk.ConversionInvariante.ToDateTime(__values[4]);
                //Derni�re G�n�ration Automatique
                _date_Last_Execution	= QXPFrk.ConversionInvariante.ToDateTime(__values[5]);
                
				//la notion de part n'est pr�sente ou null que sur les document g�n�r�s r�cemment, les anciens document ne poss�dent pas cette informations, il sont pourtant valide !
				if(__values.Length >= 7)
				{
					//Identifiant de la part s'il est d�fini
					_id_Unit_Code			= __values[6];
				}
            }
        }
		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// identifiant du fond ou de la structure (les structures sont pr�fix�es par _ )
		/// </summary>
		public string Id_Fnd_Code
        {
            get { return _id_Fnd_Code; }
        }

		/// <summary>
		/// identifiant de la part du fond 
		/// </summary>
		public string Id_Unit_Code
        {
            get { return _id_Unit_Code; }
        }
        
		/// <summary>
		/// id du run
		/// </summary>
        public int Id_Run
        {
            get { return _id_Run; }
        }
        
		/// <summary>
		/// id du suivi
		/// </summary>
        public int Id_Suivi
        {
            get { return _id_Suivi; }
        }
        
        /// <summary>
        /// Langue du document
        /// </summary>
		public int Id_Langue
        {
            get { return _id_Langue; }
        }
        
		/// <summary>
		/// Date d'�cheance du suivi
		/// </summary>
        public DateTime Date_Echeance
        {
            get { return _date_Echeance; }
        }
        
        /// <summary>
        /// Date de derni�re �x�cution du document par un run
        /// </summary>
		public DateTime Date_Last_Execution
        {
            get { return _date_Last_Execution; }
        }

        /// <summary>
        /// Permet de savoir si l'identit� d'un document QXP est compl�te.
        /// </summary>
		public bool Is_Defined
        {
            get
            {
                return (
                        QXPFrk.Validation.IsSet(_id_Fnd_Code)
                        && QXPFrk.Validation.IsSet(_id_Run)
                        && QXPFrk.Validation.IsSet(_id_Suivi)
                        && QXPFrk.Validation.IsSet(_id_Langue)
                        && QXPFrk.Validation.IsSet(_date_Echeance)
                        && QXPFrk.Validation.IsSet(_date_Last_Execution)
                       );
            }
        }

		/// <summary>
		/// Chaine originale contenant les informations d'indentit� 
		/// </summary>
		public string Value
		{
			get
			{
				return _value;
			}
		}
		#endregion Propri�t�s
	}
}
