using System.Collections.Generic;

using QXPFrk = QXP.Framework;

using QXPInterop			= QXP.Interop;
using QXPSMSDK			= com.quark.qxpsm;

namespace QXP.Engine.Core
{
	
	/// <summary>
	/// Repr�sente une structure �voluer d'un Projet quark, elle permet de retrouver des �l�ment dans le mod�le objet
	/// </summary>
	/// <author>doufarm</author>
	/// <date>25/03/2010 15:30:39</date>    
	public class QXP_Project
	{
		#region Membres
		QXPSMSDK.Project		    _project;
		Dictionary<string, TElement>	_elements	= null;
		bool							_analysed	= false; //La structure projet � d�j� �t� analys�e

        Dictionary<string, QXPSMSDK.Box> _boxes = new Dictionary<string, QXPSMSDK.Box>();
        Dictionary<string, QXPSMSDK.Table> _tables = new Dictionary<string, QXPSMSDK.Table>();
        Dictionary<string, QXPSMSDK.Group> _groups = new Dictionary<string, QXPSMSDK.Group>();

		/// <summary>
		/// QXP_Project totalement vide mais non null
		/// </summary>
		public static QXP_Project Empty = new QXP_Project(new QXPSMSDK.Project());
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de QXP_Project
		/// </summary>
		public QXP_Project(QXPSMSDK.Project project)
		{
			_project = project;
		}

		#endregion Constructeur

		#region M�thodes
		
		/// <summary>
		/// Analyse la structure du projet afin de creer des collections de type d'�l�ments nomm�s.
		/// </summary>
		/// <param name="task">Une r�f�rence � la tache permettra d'ajouter �ventuellement des log dans le run</param>
		/// <param name="logError">Permet de d�finir si les erreurs de structure sont logg�s dans les erreurs du run (true), sinon false aucune trace.</param>
		public void Analyse(Task_Base task, bool logError) 
		{ 
			//Si la structure � d�j� �t� analys� on ne recommence pas
			if(_analysed) return;

			_elements = new Dictionary<string, TElement>();
			
			QXPFrk.BaseList<TGroup> __tGroups  = new QXPFrk.BaseList<TGroup>();

			if (QXPFrk.Validation.IsSet(_project.layouts))
			{
				foreach (QXPSMSDK.Layout __layout in _project.layouts)
				{
					foreach (QXPSMSDK.Spread __spread in __layout.spreads)
					{
						TBox	__tBox		= null;
						TGroup	__tGroup	= null;
						TTable	__tTable	= null;

						if (QXPFrk.Validation.IsSet(__spread.boxes))
						{
							foreach (QXPSMSDK.Box __box in __spread.boxes)
							{
								__tBox = new TBox(__box);
								//Certains probl�mes dans la structure du document peuvent entrainer des doublons dans les documents
								//Ce probl�me semble se produire sur d'ancien document peut-�tre g�n�r�s avec QuarkXpress Server 7
								if (!_elements.ContainsKey(__tBox.Name))
								{
									_elements.Add(__tBox.Name, __tBox);
									__tBox.Evaluate(this);
								}
							}
						}

						if (QXPFrk.Validation.IsSet(__spread.tables))
						{
							foreach (QXPSMSDK.Table __table in __spread.tables)
							{
								//correction bug V9 (il y a toujours une table null) m�me s'il n'y en a pas dans le document ????
                                if (QXPFrk.Validation.IsNotNull(__table))
                                {
                                    __tTable = new TTable(__table);
                                    //Certains probl�mes dans la structure du document peuvent entrainer des doublons dans les documents
                                    //Ce probl�me semble se produire sur d'ancien document peut-�tre g�n�r�s avec QuarkXpress Server 7
                                    if (!_elements.ContainsKey(__tTable.Name))
                                    {
                                        _elements.Add(__tTable.Name, __tTable);
                                        __tTable.Evaluate(this);
                                    }
                                }
							}
						}

						//Dans le cas des group il faut d'abord �valuer tous les groupes avant d'�valuer les elements contenus qui peuvent �tre eux m�me d'autres groupe
						if (QXPFrk.Validation.IsSet(__spread.groups))
						{
							//Les groupes ne peuvent constitu�s que d'�l�ment sur le m�me spread
							__tGroups.Clear();
							foreach (QXPSMSDK.Group __group in __spread.groups)
							{
								//correction bug V9 (il y a toujours un group null) m�me s'il n'y en a pas dans le document ????
                                if (QXPFrk.Validation.IsNotNull(__group))
                                {
                                    __tGroup = new TGroup(__group);
                                    //Certains probl�mes dans la structure du document peuvent entrainer des doublons dans les documents
                                    //Ce probl�me semble se produire sur d'ancien document peut-�tre g�n�r�s avec QuarkXpress Server 7
                                    if (!_elements.ContainsKey(__tGroup.Name))
                                    {
                                        _elements.Add(__tGroup.Name, __tGroup);
                                        __tGroups.Add(__tGroup);
                                    }
                                }
							}						
						
							foreach(TGroup __tGrp in __tGroups)
							{
								try
								{
									__tGrp.Evaluate(this);
								}
								catch (Exception_TElement tex)
								{
									
									if (logError)
									{
										task.Run.Errors.Add(tex.ToString());
									}
								}
							}
						}					
					}
				}
			}
			_analysed = true;

		}
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Structure du projet
		/// </summary>
		public QXPSMSDK.Project		Project 
		{
			get { return _project; }
		}

		/// <summary>
		/// Dans le cas de document Qxp elle repr�sente la liste des �l�ments contenu dans le documents.
		/// Cette propri�t� est utilis�e pour certaines taches (exemple les taches dynamiques).
		/// Pensez � lancer la methode Analyse avant d'acc�der � cette propri�t�
		/// </summary>
		public Dictionary<string, TElement> Elements
		{
			get{return _elements;}
		}
		#endregion Propri�t�s
	}

}
