using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet de stocker et d'analyser une structure XML d'un document Quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 14:51:43</date>    
	public class QXP_XML
	{
		#region Membres
        XPathNavigator			_nav_xml			= null;
		DProject_Info			_project_Info		= null;

		//Classe QXP_XML totalement vide mais non null
		public static QXP_XML	Empty = QXP_XML.Create_From_XML(EmptyProjectXML);
		#endregion Membres

		#region Constantes
		const string BlocValuePattern			= "//ID[@NAME='{0}']/..//PARAGRAPH/RICHTEXT/text()";
		const string CTTextBoxNamesPattern		= "(//CELL | //BOX)[@BOXTYPE='CT_TEXT']/ID/@NAME";
		
		//Remonte au parent du parent c'est � dire la CELL ou la BOX puis r�cup�re la valeur dans RICHTEXT
		const string CTBoxValueRelativeBoxID	= "../..//PARAGRAPH/RICHTEXT/text()";

		//Recherche tous les ID dont le nom est {0}
		const string UIDBlocPattern				= "//ID[@NAME='{0}']/@UID";
		//Expression compliqu�e: je recherche la g�om�trie contenue dans un boite ou une table dont name = {0} OU la g�om�trie contenu dans une table qui contient une CELL dont name = '{0}'
		const string PageIDBlocPattern			= "(//BOX[ID[@NAME='{0}']] | //TABLE[ID[@NAME='{0}']] | //TABLE[ROW/CELL/ID[@NAME='{0}']]) /GEOMETRY/@PAGE"; //| ../ROW/CELL/ID[@NAME='{0}']
		const string PositionBlocPattern		= "/PROJECT/LAYOUT/SPREAD/BOX[ID[@NAME='{0}']]/GEOMETRY/POSITION";
		const string LayoutNameBlocPattern  	= "/PROJECT/LAYOUT[//ID[@NAME='{0}']]/ID/@NAME";
		
		const string ProjectPattern					= "/PROJECT";
		const string SpreadIDPattern				= "//SPREAD/ID";
		const string BoxGeometryPattern				= "//BOX/GEOMETRY";
		
		#region Table Pattern
		const string BoxTableGeometryPagePattern				= "//TABLE/GEOMETRY/@PAGE";
		const string BoxTableRelativeTableGeometryPagePattern	= "../../ROW/CELL/ID";
		const string NbLignesInTablePattern						= "//TABLE[ID[@NAME='{0}']]//ROW";
		#endregion

		const string LeftKey					= "LEFT";
		const string TopKey						= "TOP";
		const string RightKey					= "RIGHT";
		const string BottomKey					= "BOTTOM";
		
		const string BoxNameStartWithPattern	= "//ID[starts-with(@NAME,'{0}')]/@NAME";
		const string BoxNameContainsPattern		= "//ID[contains(@NAME,'{0}')]/@NAME";
		const string BoxNameOverflowPattern		= "//OVERMATTER/../../../ID/@NAME";
		const string IsBoxOverflowPattern		= "//OVERMATTER/../../../ID[@NAME='{0}']";

		const string MasterProcessIDPattern		= "/PROCESSID/MASTER/ID/text()";


		const int	BOMCharNum					= 65279;

		const string EmptyProjectXML			= "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"no\"?><PROJECT></PROJECT>";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de QXP_XML
		/// </summary>
		private QXP_XML()
        {
        }

		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// 
		/// </summary>
		/// <param name="documentName"></param>
		/// <returns></returns>
		public static QXP_XML					Create_From_File(string documentName)
		{
			QXP_XML __qxpXML = new QXP_XML();
			
			__qxpXML.Nav_XML = Create_Navigator_From_File(documentName);

			return __qxpXML;
		}	
		
		/// <summary>
		/// 
		/// </summary>
		/// <param name="xml"></param>
		/// <returns></returns>
		public static QXP_XML					Create_From_XML(string xml)
		{
			QXP_XML __qxpXML = new QXP_XML();
			
			__qxpXML.Nav_XML = Create_Navigator_From_XML(xml);

			return __qxpXML;
		}	

		/// <summary>
		/// Permet d'obtenir le xpath navigator d'un fichier qxp permetttant de rechercher des �l�m�ent dans la structure xml
		/// </summary>
		/// <param name="filePoolPath">nom du document qxp dans le document pool de QuarkXPress server</param>
		/// <returns>le XPath navigator</returns>
		static XPathNavigator					Create_Navigator_From_File(string filePoolPath)
		{
			string	__xml	= QXPInteropQuarkServer.QXPS_Helper.Get_Xml(filePoolPath);
			
			return Create_Navigator_From_XML(__xml);
            
		}

		/// <summary>
		/// Permet d'obtenir le xpath navigator d'une structure XML de rechercher des �l�ments dans la structure xml
		/// </summary>
		/// <param name="xml">structure xml</param>
		/// <returns>le XPath navigator</returns>
		static XPathNavigator					Create_Navigator_From_XML(string xml)
		{
			XPathDocument   __doc;
			
			__doc    = new XPathDocument(new StringReader(FixedXML(xml)));
            
			return __doc.CreateNavigator();
		}
		
		/// <summary>
		/// Lors d'une commande deconstruction la structure xml renvoy�e contient toujours un caract�re sp�cial 
		/// qu'il faut supprimer afin de pouvoir l'utiliser avec XPathDocument
		/// </summary>
		/// <param name="xml">La structure xml � r�parer</param>
		/// <returns>la structure xml r�par�e</returns>
        static string							FixedXML(string xml)
		{
            string __fixed;
			
			//Test de la pr�sence du B.O.M. (Byte of mark)
			//dans le cas du d�construction � travers le manager ce charact�re est ajout� !! (pourquoi ?)
			if(xml.Length > 0 && xml[0] == BOMCharNum)
			{
			    __fixed = xml.Substring(1);
			}
			else
			{
			    __fixed = xml;
			}
				
            return __fixed;
        }

		#region Commandes disponibles lorsque le xml est issu de la commande "xml"

		/// <summary>
		/// Permet d'obtenir la valeur contenu dans un bloc
		/// </summary>
		/// <param name="blocName">nom de la boite (Box)</param>
		/// <returns>la valeur si elle existe sinon string.empty</returns>
		public string							GetValue(string blocName)
        {
            XPathNodeIterator __iterator;

            __iterator = this.Nav_XML.Select(string.Format(BlocValuePattern, blocName));
            if (__iterator.MoveNext())
            {
                return __iterator.Current.Value;
            }
            return string.Empty;
        }

		/// <summary>
		/// Obtenir la liste de bloc dont le nom commence par 
		/// </summary>
		/// <param name="name">nom de la boite (Box)</param>
		/// <returns>la liste des noms de bloc contenant la valeur BoxName dans leurs noms</returns>
		public QXPFrk.BaseList<String>			GetListBoxNameStartWith(string name) {
            XPathNodeIterator __iterator;
			QXPFrk.BaseList<string> __list = new QXPFrk.BaseList<string>();

            __iterator = this.Nav_XML.Select(string.Format(BoxNameStartWithPattern, name));
            while (__iterator.MoveNext())
            { 				
                __list.Add(__iterator.Current.Value);
			}

			return(__list);
		}

        /// <summary>
        /// Retourne la liste des boxes dont le nom termine par la chaine donn�e
        /// </summary>
        /// <param name="suffixe">chaine � trouver</param>
        /// <returns>liste des nom de box correspondant</returns>
        public QXPFrk.BaseList<string>			GetListBoxNameEndWith(string suffixe)
        {
            XPathNodeIterator __iterator;
            QXPFrk.BaseList<string> __list = new QXPFrk.BaseList<string>();

            __iterator = this.Nav_XML.Select(string.Format(BoxNameContainsPattern, suffixe));
            while(__iterator.MoveNext())
            {                
               if(__iterator.Current.Value.EndsWith(suffixe))
                __list.Add(__iterator.Current.Value);
            }

            return (__list);
        }

		/// <summary>
        /// Retourne la liste des boxes dont le nom contient par la chaine donn�e
        /// </summary>
        /// <param name="name">chaine � trouver</param>
        /// <returns>liste des nom de box correspondant</returns>
        public QXPFrk.BaseList<string>			GetListBoxNameContains(string name)
        {
            XPathNodeIterator		__iterator;
            QXPFrk.BaseList<string> __list = new QXPFrk.BaseList<string>();

            __iterator = this.Nav_XML.Select(string.Format(BoxNameContainsPattern, name));
            while(__iterator.MoveNext())
            {                
                __list.Add(__iterator.Current.Value);
            }

            return (__list);
        }

		/// <summary>
        /// Obtenir l'UID (unique identifier) d'un bloc
        /// </summary>
        /// <param name="blocName">nom du bloc (box)</param>
        /// <returns>Permet d'obtenir l'UID (unique identifier) d'un bloc nomm� blocName</returns>
        public string							GetUID(string blocName)
		{
            XPathNodeIterator __iterator;

            __iterator = this.Nav_XML.Select(string.Format(UIDBlocPattern, blocName));
            if (__iterator.MoveNext())
            {
                return __iterator.Current.Value;
            }
            return string.Empty;
        }

        /// <summary>
        /// Obtenir le nom du layout d'un bloc
        /// </summary>
		/// <param name="blocName">nom du bloc (box)</param>
        /// <returns>le nom du layout contenant le bloc nomm� blocName sinon retourne string.empty</returns>
        public string							GetLayoutName(string blocName)
		{
            XPathNodeIterator __iterator;

            __iterator = this.Nav_XML.Select(string.Format(LayoutNameBlocPattern, blocName));
            if (__iterator.MoveNext())
            {
                return __iterator.Current.Value;
            }
            return string.Empty;
        }

		/// <summary>
		/// Retourne la vrai page tel que pr�sente dans le qxp
		/// </summary>
		/// <param name="blocName"></param>
		/// <returns></returns>
		public int								GetPageNum(string blocName)
		{
			string __pageID = this.GetPageID(blocName);

			 //Permet de supprimer les �ventuels * exemple 10* (gauche de la page 10) ou 24** (droite de la page 24)
            return QXPFrk.ConversionInvariante.ToInt(__pageID.TrimEnd('*'));
		}        
		
		/// <summary>
        /// Obtenir la page �valuer d'un bloc (soit la page soit �valuer par rapport au spread)
        /// </summary>
		/// <remarks>
		/// Attention cette fonction doit �tre modifi� lorsque nous utiliserons le namespace "xml" plutot que le namespace "deconstruct"
		/// actuellement si page > 2000 alors nous sommes dans le pastboard (en dehors d'une page) et nous devons utiliser la valeur de spreadid
		/// plus tard une page � 20* voudra dire que nous sommes � gauche de la page 20 alors que 24** que nous sommes � droite de la page 24
		/// </remarks>
		/// <param name="blocName">nom du bloc (box)</param>
        /// <returns>le num�ro de la page contenant le bloc nomm� blocName sinon retourne string.empty</returns>
        public string							GetPageID(string blocName)
		{

            XPathNodeIterator	__iterator;
			string				__value		= string.Empty;

            __iterator = this.Nav_XML.Select(string.Format(PageIDBlocPattern, blocName));
            if (__iterator.MoveNext())
            {
                __value = __iterator.Current.Value;
            }

			return __value;
			
        }

		/// <summary>
		/// Permet d'obtenir certaines informations d'un bloc (exemple position left,top, right, bottom et la page d'un bloc)
		/// </summary>
		/// <param name="blocName">nom du bloc (box)</param>
		/// <returns>les informations de position du bloc nomm�e blocName</returns>
		public DBloc_Info						GetBlocInfo(string blocName)
		{
			DBloc_Info			__dBloc_Info		= new DBloc_Info();
			XPathNodeIterator	__iterator;

			//1 - Nom du bloc
			__dBloc_Info.Name = blocName;

			//2 - Puis la page
			__dBloc_Info.Page	= GetPageNum(blocName);

			//3 - L'UID du bloc
			__dBloc_Info.UID	= GetUID(blocName);

            //4 - puis les coordonn�es
			__iterator = this.Nav_XML.Select(string.Format(PositionBlocPattern, blocName));
            if (__iterator.MoveNext())
            {
                XPathNodeIterator	__iterator_childs	= __iterator.Current.SelectDescendants(XPathNodeType.Element, false);
				while(__iterator_childs.MoveNext())
				{
					switch(__iterator_childs.Current.Name)
					{
						case LeftKey:
                            __dBloc_Info.Left = QXPFrk.ConversionInvariante.ToDecimal(__iterator_childs.Current.Value);
							break;
						case TopKey:
                            __dBloc_Info.Top = QXPFrk.ConversionInvariante.ToDecimal(__iterator_childs.Current.Value);
							break;
						case RightKey:
                            __dBloc_Info.Right = QXPFrk.ConversionInvariante.ToDecimal(__iterator_childs.Current.Value);
							break;
						case BottomKey:
                            __dBloc_Info.Bottom = QXPFrk.ConversionInvariante.ToDecimal(__iterator_childs.Current.Value);
							break;
					}
				}
            }

			return __dBloc_Info;
		}

		/// <summary>
		/// Permet d'obtenir certaines informations concernant la structure xml du project
		/// </summary>
		/// <returns>les informations sur le project</returns>
		private DProject_Info					GetProjectInfo()
		{
			DProject_Info		__dProjet_Info		= new DProject_Info();
			XPathNodeIterator	__iterator;
			XPathNodeIterator	__subIterator;
			int					__currentPage	= 0;


			//1 - Information sur le projet
			__iterator = this.Nav_XML.Select(ProjectPattern);
			if (__iterator.MoveNext())
			{
				__dProjet_Info.Name			= __iterator.Current.GetAttribute("PROJECTNAME", string.Empty);
				__dProjet_Info.XMLVersion	= __iterator.Current.GetAttribute("XMLVERSION", string.Empty);
			}


			
			//2 - Informations sur les elements contenue
			__iterator = this.Nav_XML.Select(SpreadIDPattern);


			//traitement Les spreads
			while (__iterator.MoveNext())
			{
				__dProjet_Info.NbSpread++;
			}

			//traitement des boites directement dans les spreads
			__iterator = this.Nav_XML.Select(BoxGeometryPattern);
				
			//il y a des boites dans le spread!!
			while (__iterator.MoveNext())
			{
                __currentPage = QXPFrk.ConversionInvariante.ToInt(__iterator.Current.GetAttribute("PAGE", string.Empty));
				if (QXPFrk.Validation.IsSet(__currentPage))
				{
					if(!__dProjet_Info.PageBoxes.ContainsKey(__currentPage))
					{
						__dProjet_Info.PageBoxes.Add(__currentPage, 1); //et voici la premi�re boite dans la page
					}
					else
					{
						__dProjet_Info.PageBoxes[__currentPage]++; //et on ajoute une box
					}
				}
				__dProjet_Info.NbBox++;
			}

			//traitement des boites dans les tableaux
			//IMPORTANT !!
			//Nous pourrions factoriser le bloc ci-dessous avec le bloc ci-dessus (m�me code)
			//Mais cela permettra peut �tre par la suite de traiter les box/table diff�remment des box/spread
			
			__iterator = this.Nav_XML.Select(BoxTableGeometryPagePattern);
			
			//il y a des tables et des boites dans le spread!!
			while (__iterator.MoveNext())
			{
                __currentPage = QXPFrk.ConversionInvariante.ToInt(__iterator.Current.Value);
			    if (QXPFrk.Validation.IsSet(__currentPage))
			    {
			        __subIterator = __iterator.Current.Select(BoxTableRelativeTableGeometryPagePattern);
					
					while(__subIterator.MoveNext())
					{
						if(!__dProjet_Info.PageBoxes.ContainsKey(__currentPage))
						{
							__dProjet_Info.PageBoxes.Add(__currentPage, 1); //et voici la premi�re boite dans la page
						}
						else
						{
							__dProjet_Info.PageBoxes[__currentPage]++; //et on ajoute une box
						}
						__dProjet_Info.NbBox++;
					}
			    }
			    
			}

			return __dProjet_Info;
		}

		/// <summary>
		/// Permet de r�cup�rer la liste des noms de boites en overflow
		/// </summary>
		/// <returns></returns>
		public QXPFrk.BaseList<string>			GetOverflowBoxes()
		{
			XPathNodeIterator		__iterator;
            QXPFrk.BaseList<string> __list = new QXPFrk.BaseList<string>();

            __iterator = this.Nav_XML.Select(BoxNameOverflowPattern);
            while(__iterator.MoveNext())
            {                
                __list.Add(__iterator.Current.Value);
            }

            return (__list);		
		}

		/// <summary>
		/// Permet de savoir si une boite est en overflow
		/// </summary>
		/// <param name="name">le nom de la boite � tester.</param>
		/// <returns>true la boite est en overflow sinon false</returns>
		public bool								CheckBoxOverflow(string name)
		{
			XPathNodeIterator		__iterator;
            QXPFrk.BaseList<string> __list = new QXPFrk.BaseList<string>();

            __iterator = this.Nav_XML.Select(string.Format(IsBoxOverflowPattern, name));
            //S'il trouve un element c'est qu'il est en overflow
			return __iterator.MoveNext();
		}

		/// <summary>
		/// Permet de v�rifier l'existance d'un nom dans le document
		/// </summary>
		/// <param name="name">le nom de l'�l�ment � v�rifier</param>
		/// <returns>true l'�l�ment existe, sinon false.</returns>
		public bool								Exist_Name(string name)
		{
			return QXPFrk.Validation.IsSet(GetUID(name));
		}

		/// <summary>
		/// Permet de d�terminer le nombre de ligne (Row) contenu dans un tableau existant
		/// </summary>
		/// <param name="tableName">nom du tableau dans lequel il faut compter les lignes</param>
		/// <returns></returns>
		public int								GetNbLignes(string tableName)
		{
			XPathNodeIterator	__iterator;

			__iterator = this.Nav_XML.Select(string.Format(NbLignesInTablePattern, tableName));
            
			return __iterator.Count;
		}

		/// <summary>
		/// Permet de r�cup�rer la liste des noms et valeurs des boites du document
		/// </summary>
		/// <returns></returns>
		public DataNamesValues					GetNamesValuesBoxes()
		{
			XPathNodeIterator	__iterator;
			XPathNodeIterator	__subIterator;
            DataNamesValues		__list		= new DataNamesValues();
			string				__name;
			string				__value;

            __iterator = this.Nav_XML.Select(CTTextBoxNamesPattern);
			//tant qui y � des ids
            while(__iterator.MoveNext())
            {                
				//�valuation du nom
				__name			= __iterator.Current.Value;

				//c'est un xpath relatif au contex en cours il est tr�s rapide
				__subIterator	= __iterator.Current.Select(CTBoxValueRelativeBoxID);

				//Il y � au moins un noeud on prend le premier
				if (__subIterator.MoveNext())
				{
					__value = __subIterator.Current.Value;
				}
				else
				{
					__value = string.Empty;
				}

				//Seulement si le nom est d�fini
				if(QXPFrk.Validation.IsSet(__name))
				{
					__list.Add(__name, __value);
				}
            }

            return (__list);
		}
		
		#endregion Commandes disponibles lorsque le xml est issu de la commande "xml"


		#region Commandes disponibles lorsque le xml est issu de la commande "getprocessid"
		/// <summary>
		/// Permet d'obtenir le process ID du master sub renderer
		/// ne doit �tre utilis� que lorsque le xml est issu de la commande getprocessid
		/// </summary>
		/// <returns></returns>
		public string							GetMasterProcessID()
		{
            XPathNodeIterator	__iterator;
			string				__value		= string.Empty;

            __iterator = this.Nav_XML.Select(MasterProcessIDPattern);
            if (__iterator.MoveNext())
            {
                __value = __iterator.Current.Value;
            }

			return __value;
		}

		#endregion Commandes disponibles lorsque le xml est issu de la commande "getprocessid"

		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// XPathNavigator de la commande XML
		/// </summary>
		public XPathNavigator					Nav_XML
		{
			get
			{
				return _nav_xml;
			}
			set
			{
				_nav_xml = value;
			}
		}

		/// <summary>
		/// Retrourne divers informations sur la structure du project comme le nombre de spread nombre de box/page etc
		/// </summary>
		public DProject_Info					Project_Info
		{
			get
			{
				if (QXPFrk.Validation.IsNull(_project_Info))
				{
					_project_Info = this.GetProjectInfo();
				}
				return _project_Info;
			}
		}
		#endregion Propri�t�s
	}
}
