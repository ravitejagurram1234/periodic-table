using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP
{
	/// <summary>
	/// Interface d'un logger de trace
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/05/2010 11:33:30</date>    
	public interface ITrace_Logger{
		/// <summary>
		/// Informe un logger qu'il y a un nouveau message
		/// </summary>
		/// <param name="trace_Message"></param>
		void Log(Trace_Message trace_Message);
	}
}
