using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP
{
	/// <summary>
	/// Repr�sente une interface d'affichage des logs � l'�cran
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/05/2010 11:34:58</date>    
	public class Console_Trace_Logger: ITrace_Logger
	{
		#region Membres
		object	_syncRoot = new object();
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Console_Trace_Logger
		/// </summary>
		public Console_Trace_Logger()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Affichage d'un Trace_Message dans la console (�cran)
		/// </summary>
		/// <param name="trace_Message">le Trace_Message � afficher</param>
		public void Log(Trace_Message trace_Message)
		{
			lock(_syncRoot)
			{
				Console.WriteLine(trace_Message.ToString());
			}
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
