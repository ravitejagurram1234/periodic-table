using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP
{
	/// <summary>
	/// Repr�sente une interface de conservation des logs en m�moire
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/08/2010 14:52:00</date>    
	public class Memory_Trace_Logger: ITrace_Logger
	{
		#region Membres
		object					_syncRoot	= new object();
		StringBuilder			_logs		= new StringBuilder();
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Memory_Trace_Logger
		/// </summary>
		public Memory_Trace_Logger()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// ajout d'un Trace_Message dans la m�moire
		/// </summary>
		/// <param name="trace_Message">le Trace_Message � afficher</param>
		public void Log(Trace_Message trace_Message)
		{
			lock(_syncRoot)
			{
				_logs.AppendLine(trace_Message.ToString());
			}
		}
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Renvoi la totalit� des traces contenue dans le logger
		/// </summary>
		public string	Logs
		{
			get
			{
				return _logs.ToString();
			}
		}
		#endregion Propri�t�s
	}
}
