using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP
{
	/// <summary>
	/// contient les informations d'une trace 
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/05/2010 11:27:44</date>    
	public class Trace_Message
	{
		#region Membres
		DateTime		_date					= DateTime.Now;
		Trace_Context	_context				= null;
		string			_message				= null;
		string			_source					= null;
		Exception		_ex						= null;
		#endregion Membres

		#region Constantes
		const string Trace_Message_Pattern		= "- {0:HH:mm:ss.ffff}\t[{1}] \tSrc:{2}\tMsg: {3}";
		const string Trace_Message_Pattern_Ex	= "- {0:HH:mm:ss.ffff}\t[{1}] \tSrc: {2}\tMsg: {3}\n Ex: {4}";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Trace_Message
		/// </summary>
		/// <param name="context">Le contexte de la trace</param>
		/// <param name="message">le message de la trace</param>
		/// <param name="source">la source de la trace</param>
		/// <param name="ex">l'exception associ� � la trace</param>
		public Trace_Message(Trace_Context	context, string message, string source, Exception ex) : this(context, message, source)
		{
			_ex = ex;		
		}

		/// <summary>
		/// Cr�e une instance de Trace_Message
		/// </summary>
		/// <param name="context">Le contexte de la trace</param>
		/// <param name="message">le message de la trace</param>
		/// <param name="source">la source de la trace</param>
		public Trace_Message(Trace_Context	context, string message, string source): this(context, message)
		{
			_source = source;
		}

		/// <summary>
		/// Cr�e une instance de Trace_Message
		/// </summary>
		/// <param name="context">Le contexte de la trace</param>
		/// <param name="message">le message de la trace</param>
		public Trace_Message(Trace_Context	context, string message)
		{
			_context = context;
			_message = message;
		}
		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Evaluation du message textuel des information de la trace
		/// </summary>
		/// <returns></returns>
		public override string	ToString()
		{
			string __source = _source;
			if(Framework.Validation.IsNotSet(__source))
			{
				__source = _context.Source;
			}

			if(Framework.Validation.IsNull(_ex))
			{
				return string.Format(Trace_Message_Pattern
									, _date, Thread.CurrentThread.ManagedThreadId, __source, _message);
			}
			else
			{
				return string.Format(Trace_Message_Pattern_Ex
									, _date, Thread.CurrentThread.ManagedThreadId, __source, _message, _ex);
			}
		}
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Contexte de la trace
		/// </summary>
		public Trace_Context	Context{
			get{return _context;}
		}
		/// <summary>
		/// Date et heure de la trace
		/// </summary>
		public DateTime			DateTime{
			get{return _date;}
		}
		/// <summary>
		/// Message de la trace
		/// </summary>
		public string			Message{
			get{return _message;}
		}
		/// <summary>
		/// Source de la trace
		/// </summary>
		public string			Source{
			get{return _source;}
		}
		/// <summary>
		/// Eventuellement l'exception associ�e � la trace
		/// </summary>
		public Exception		Exception{
			get{return _ex;}
		}
		#endregion Propri�t�s
	}
}
