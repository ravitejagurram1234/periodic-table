using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP
{
	/// <summary>
	/// Repr�sente le contexte actuelle du syst�me de trace
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/05/2010 11:31:11</date>    
	public class Trace_Context
	{
		#region Membres
		const string Login_Sys				= "SYSTEM";
		const string Trace_Context_Pattern	= "App: {0} Lgn: {1} Src {2}";
		string	_app;
		string	_login						= Login_Sys;
		string	_source						= "Unknown";
		bool	_horodatage					= true;

		List<ITrace_Logger>	_loggers		= new List<ITrace_Logger>();
		Memory_Trace_Logger	_memory_Logger	= new Memory_Trace_Logger();

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Trace_Context
		/// </summary>
		public Trace_Context()
		{
			_app = AppName;
			
			this.Init_Loggers();

		}

		/// <summary>
		/// Cr�e une instance de Trace_Context
		/// </summary>
		/// <param name="source">source du context</param>
		public Trace_Context(string source): this()
		{
			_source	= source;
		}

		/// <summary>
		/// Cr�e une instance de Trace_Context
		/// </summary>
		/// <param name="source">source du contexte</param>
		/// <param name="login">login de l'utilisateur qui d�fini le contexte</param>
		public Trace_Context(string source, string login) : this(source)
		{
			if(QXP.Framework.Validation.IsSet(login)) _login	= login;
		}

		/// <summary>
		/// Cr�e une instance de Trace_Context
		/// </summary>
		/// <param name="source">source du contexte</param>
		/// <param name="login">login de l'utilisateur qui d�fini le contexte</param>
		/// <param name="app">application qui d�fini le contexte</param>
		public Trace_Context(string source, string login, string app) : this(source, login)
		{
			if(QXP.Framework.Validation.IsSet(app)) _app	= app;
		}

		/// <summary>
		/// Cr�e une instance de Trace_Context
		/// </summary>
		/// <param name="source">source du contexte</param>
		/// <param name="login">login de l'utilisateur qui d�fini le contexte</param>
		/// <param name="app">application qui d�fini le contexte</param>
		/// <param name="horodatage">faut-il horodater les traces</param>
		public Trace_Context(string source, string login, string app, bool horodatage) : this(source, login, app)
		{
			_horodatage	= horodatage;
		}
		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// Initialisation des Loggers du contexte
		/// </summary>
		private void Init_Loggers()
		{
			_loggers.Add(new Console_Trace_Logger());
			if(TraceSetting.Current.TRACE_ENABLED)
			{
				_loggers.Add(new File_Trace_Logger());
			}
			_loggers.Add(_memory_Logger);
		
		}

		/// <summary>
		/// Evaluation de la chaine repr�sentant le context actuel
		/// </summary>
		/// <returns></returns>
		public override string		ToString()
		{
			return string.Format(Trace_Context_Pattern, _app, _login, _source);
		}

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Quel est le processus qui � d�clench� la trace
		/// </summary>
		public static string		AppName{
			get{return AppDomain.CurrentDomain.SetupInformation.ApplicationName;}
		}

		/// <summary>
		/// quelle est l'application qui � d�clench� la trace
		/// </summary>
		public string				App{
			get{return _app;}
		}

		/// <summary>
		/// quel est le login de la personne qui � d�clencher la trace
		/// </summary>
		public string				Login{
			get{return _login;}
		}

		/// <summary>
		/// Quelle est la source de la trace
		/// </summary>
		public string				Source{
			get{return _source;}
		}

		/// <summary>
		/// Faut-il horodater le log (def true)
		/// </summary>
		public bool					Horodatage{
			get{return _horodatage;}
		}

		/// <summary>
		/// Liste des Loggers du context
		/// </summary>
		public List<ITrace_Logger>	Loggers
		{
			get
			{
				return _loggers;
			}
		}

		/// <summary>
		/// retourne l'ensemble des traces actuellement g�n�r�es lors du run
		/// </summary>
		public string				All_Logs
		{
			get
			{
				return _memory_Logger.Logs;
			}
		}
		#endregion Propri�t�s
	}
}
