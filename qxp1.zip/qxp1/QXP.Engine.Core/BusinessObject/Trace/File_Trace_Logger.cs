using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP
{
	/// <summary>
	/// Repr�sente une interface d'insertion des logs dans un fichier
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/05/2010 11:34:46</date>    
	public class File_Trace_Logger: ITrace_Logger
	{
		#region Membres
		object	_syncRoot = new object();
		static  string Log_Root;
		#endregion Membres

		#region Constantes
		const string TraceFilePatternHorodatage = @"{0}{1}_{2:yyyyMMdd}.log";
		const string TraceFilePattern			= @"{0}{1}.log";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// constructeur static de File_Trace_Logger
		/// </summary>
		static File_Trace_Logger()
		{
			if(QXP.Framework.Validation.IsSet(TraceSetting.Current.TRACE_LOG_PATH))
			{
				Log_Root = TraceSetting.Current.TRACE_LOG_PATH;
			}
			else
			{
				Log_Root = @"c:\";
			}
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Ajout d'un Trace_Message dans un fichier
		/// </summary>
		/// <param name="trace_Message">le Trace_Message � ajouter dans le fichier</param>
		public void Log(Trace_Message trace_Message)
		{
			lock(_syncRoot)
			{
				string __file;
				if(trace_Message.Context.Horodatage)
				{
					__file = string.Format(TraceFilePatternHorodatage, Log_Root, trace_Message.Context.App, trace_Message.DateTime);
				}
				else
				{
					__file = string.Format(TraceFilePattern, Log_Root, trace_Message.Context.App);
				}
				try
				{
					using (StreamWriter __writer = File.AppendText(__file))
					{
						__writer.WriteLine(trace_Message.ToString());
					}
				}
				catch
				{
					//permet de ne pas bloquer l'�x�cution de l'application m�me si le logger � des pbs !!
				}
			}
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
