using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;


/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Repr�sente une donn�e g�n�r�e par un tache ou contenue dans un document quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>20/09/2010 10:49:46</date>    
	public struct DataNameValue
	{
		#region Membres
		public string _name;
		public string _value;
		public string _descriptif;
		public string _info;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DataNameValue
		/// </summary>
		/// <param name="name">le nom de la donn�e.</param>
		/// <param name="value">la valeur de la donn�e.</param>
		public DataNameValue(string name, string value)
		{
			_name		= name;
			_value		= value;
			_descriptif = string.Empty;
			_info		= string.Empty;
		}
		
		/// <summary>
		/// Cr�e une instance de DataNameValue
		/// </summary>
		/// <param name="name">le nom de la donn�e.</param>
		/// <param name="value">la valeur de la donn�e.</param>
		/// <param name="descriptif">descriptif du nom/valeur</param>
		public DataNameValue(string name, string value, string descriptif, string info): this(name, value)
		{
			_descriptif	= descriptif;
			_info		= info;
		}
		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Repr�sente le nom de la donn�e
		/// </summary>
		public string Name
		{
			get
			{
				return _name;
			}
		}

		/// <summary>
		/// Repr�ente la valeur de la donn�e
		/// </summary>
		public string Value
		{
			get
			{
				return _value;
			}
		}

		/// <summary>
		/// Descriptif du nom/valeur
		/// </summary>
		public string Descriptif
		{
			get
			{
				return _descriptif;
			}
		}

		/// <summary>
		/// Information m�tier du nom/valeur
		/// </summary>
		public string Info
		{
			get
			{
				return _info;
			}
		}
		#endregion Propri�t�s
	}
}
