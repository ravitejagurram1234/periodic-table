using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;


/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// D�fini une collection des donn�es g�n�r�es par une tache ou contenu dans un document quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>20/09/2010 10:43:35</date>    
	public class DataNamesValues : QXPFrk.BaseList<DataNameValue>
	{
		#region Membres

		#endregion Membres

		#region Constantes
		const int Max_Name_Size			= 30;
		const int Max_Value_Size		= 500;
		const int Max_Descriptif_Size	= 250;
		const int Max_Info_Size			= 4000;
		#endregion Constantes

		#region Enums
		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de DataNamesValues
		/// </summary>
		public DataNamesValues()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Ajoute une donn�e
		/// </summary>
		/// <param name="name">nom de la donn�e</param>
		/// <param name="value">valeur de la donn�e</param>
		public void Add(string name, string value)
		{
			this.Add(new DataNameValue(name, value));
		}
		/// <summary>
		/// Ajoute une donn�e
		/// </summary>
		/// <param name="name">nom de la donn�e</param>
		/// <param name="value">valeur de la donn�e</param>
		/// <param name="descriptif">descriptif du nom/valeur</param>
		/// <param name="info">information m�tier du nom/valeur</param>
		public void Add(string name, string value, string descriptif, string info)
		{
			this.Add(new DataNameValue(name, value, descriptif, info));
		}

		/// <summary>
		/// Permet de renvoyer une liste de collection de string
		/// chaque collection de string repr�sente un element( name, value, descriptif et info)
		/// Index 0: Names / Index 1: Values / Index 2: Descriptifs / Index 3: Infos
		/// </summary>
		/// <returns></returns>
		public QXPFrk.BaseList<string[]> ToArrays()
		{
			QXPFrk.BaseList<string[]>	__elements		= new QXPFrk.BaseList<string[]>();
			QXPFrk.BaseList<string>		__names			= new QXPFrk.BaseList<string>();
			QXPFrk.BaseList<string>		__values		= new QXPFrk.BaseList<string>();
			QXPFrk.BaseList<string>		__descriptifs	= new QXPFrk.BaseList<string>();
			QXPFrk.BaseList<string>		__infos			= new QXPFrk.BaseList<string>();

			this.ForEach(
				delegate(DataNameValue dataNameValue)
				{
					__names.Add(QXPFrk.StringHelper.StartString(dataNameValue.Name, Max_Name_Size, string.Empty));
					__values.Add(QXPFrk.StringHelper.StartString(dataNameValue.Value, Max_Value_Size));
					__descriptifs.Add(QXPFrk.StringHelper.StartString(dataNameValue.Descriptif, Max_Descriptif_Size));
					__infos.Add(QXPFrk.StringHelper.StartString(dataNameValue.Info, Max_Info_Size));
				});

			__elements.Add(__names.ToArray());
			__elements.Add(__values.ToArray());
			__elements.Add(__descriptifs.ToArray());
			__elements.Add(__infos.ToArray());

			return __elements;
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
