using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;
using QXPIO	= QXP.Framework.IO;

using QXPSMSDK			= com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPBusinessClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet de transformer un DOM (Project) de modification quark en une chaine XML.
	/// </summary>
	/// <remarks>
	/// Ce mode de construction custom est hautement sp�cifique, c'est � dire qu'a chaque modification du serveur quark il devrait y avoir des adaptations � effectuer dans la construction. 
	/// En revanche les performances sont impressionnantes compar�es � la m�thode getXMLFromXPressDOM du manager quark qui plante d'ailleur � 60-70 pages simple dans un modifier
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>28/04/2010 15:59:57</date>    
	public class QXP_Project_Serializer
	{
		#region Membres

		#endregion Membres

		#region Constantes
		const string def_false_value = "false";

		#region KEY_

		private const string KEY_ADDCELLS = "ADDCELLS";
		private const string KEY_ALIGNMENT = "ALIGNMENT";
		private const string KEY_ALIGNON = "ALIGNON";
		private const string KEY_ALLCAPS = "ALLCAPS";
		private const string KEY_ALLEDGES = "ALLEDGES";
		private const string KEY_ALLLINESINPARA = "ALLLINESINPARA";
		private const string KEY_ALLOWBOXOFFPAGE = "ALLOWBOXOFFPAGE";
		private const string KEY_ALLOWBOXONTOPASTEBOARD = "ALLOWBOXONTOPASTEBOARD";
		private const string KEY_ANCHOREDIN = "ANCHOREDIN";
		private const string KEY_ANGLE = "ANGLE";
		private const string KEY_ARROWHEADS = "ARROWHEADS";
		private const string KEY_AUTOFIT = "AUTOFIT";
		private const string KEY_AUTOFITMAXLIMIT = "AUTOFITMAXLIMIT";
		private const string KEY_BASEINDEX = "BASEINDEX";
		private const string KEY_BASELINESHIFT = "BASELINESHIFT";
		private const string KEY_BLUR = "BLUR";
		private const string KEY_BOLD = "BOLD";
		private const string KEY_BOTTOM = "BOTTOM";
		private const string KEY_BOX = "BOX";
		private const string KEY_BOXTYPE = "BOXTYPE";
		private const string KEY_CELL = "CELL";
		private const string KEY_CHARCOUNT = "CHARCOUNT";
		private const string KEY_CHARSTYLE = "CHARSTYLE";
		private const string KEY_CLEAROLDTEXT = "CLEAROLDTEXT";
		private const string KEY_CLOSEDSHAPE = "CLOSEDSHAPE";
		private const string KEY_COLOR = "COLOR";
		private const string KEY_COLSPEC = "COLSPEC";
		private const string KEY_COLUMN = "COLUMN";
		private const string KEY_COLUMNCOUNT = "COLUMNCOUNT";
		private const string KEY_COLUMNS = "COLUMNS";
		private const string KEY_COLUMNWIDTH = "COLUMNWIDTH";
		private const string KEY_CONTENT = "CONTENT";
		private const string KEY_CONTOUR = "CONTOUR";
		private const string KEY_CONTOURS = "CONTOURS";
		private const string KEY_CONVERTQUOTES = "CONVERTQUOTES";
		private const string KEY_CURVEDEDGES = "CURVEDEDGES";
		private const string KEY_CUSPVERTEX = "CUSPVERTEX";
		private const string KEY_DELETECELLS = "DELETECELLS";
		private const string KEY_DELETECOUNT = "DELETECOUNT";
		private const string KEY_DISTANCE = "DISTANCE";
		private const string KEY_DROPCAP = "DROPCAP";
		private const string KEY_ENABLED = "ENABLED";
		private const string KEY_ENDLINE = "ENDLINE";
		private const string KEY_FILE = "FILE";
		private const string KEY_FILL = "FILL";
		private const string KEY_FIRSTBASELINEMIN = "FIRSTBASELINEMIN";
		private const string KEY_FIRSTLINE = "FIRSTLINE";
		private const string KEY_FIT = "FIT";
		private const string KEY_FITTEXTTOBOX = "FITTEXTTOBOX";
		private const string KEY_FLIPHORIZONTAL = "FLIPHORIZONTAL";
		private const string KEY_FLIPTEXT = "FLIPTEXT";
		private const string KEY_FLIPVERTICAL = "FLIPVERTICAL";
		private const string KEY_FONT = "FONT";
		private const string KEY_FONTNAME = "FONTNAME";
		private const string KEY_FORMAT = "FORMAT";
		private const string KEY_FRAME = "FRAME";
		private const string KEY_FULLRES = "FULLRES";
		private const string KEY_GAPCOLOR = "GAPCOLOR";
		private const string KEY_GAPOPACITY = "GAPOPACITY";
		private const string KEY_GAPSHADE = "GAPSHADE";
		private const string KEY_GEOMETRY = "GEOMETRY";
		private const string KEY_GROUP = "GROUP";
		private const string KEY_GROWACROSS = "GROWACROSS";
		private const string KEY_GROWDOWN = "GROWDOWN";
		private const string KEY_GUTTERWIDTH = "GUTTERWIDTH";
		private const string KEY_HANDJ = "HANDJ";
		private const string KEY_HASHOLES = "HASHOLES";
		private const string KEY_HASSPLINES = "HASSPLINES";
		private const string KEY_HORIZONTALSCALE = "HORIZONTALSCALE";
		private const string KEY_ID = "ID";
		private const string KEY_INCLUDESTYLESHEETS = "INCLUDESTYLESHEETS";
		private const string KEY_INCOMPLETE = "INCOMPLETE";
		private const string KEY_INHERITOPACITY = "INHERITOPACITY";
		private const string KEY_INSERTCOUNT = "INSERTCOUNT";
		private const string KEY_INSERTPOSITION = "INSERTPOSITION";
		private const string KEY_INSET = "INSET";
		private const string KEY_INTERPARAGRAPHMAX = "INTERPARAGRAPHMAX";
		private const string KEY_INVERT = "INVERT";
		private const string KEY_INVERTEDCONTOUR = "INVERTEDCONTOUR";
		private const string KEY_INVERTEDSHAPE = "INVERTEDSHAPE";
		private const string KEY_ITALIC = "ITALIC";
		private const string KEY_KEEPATTRIBUTE = "KEEPATTRIBUTE";
		private const string KEY_KEEPLINESTOGETHER = "KEEPLINESTOGETHER";
		private const string KEY_KEEPWITHNEXT = "KEEPWITHNEXT";
		private const string KEY_KERNAMOUNT = "KERNAMOUNT";
		private const string KEY_KNOCKOUTSHADOW = "KNOCKOUTSHADOW";
		private const string KEY_LANGUAGE = "LANGUAGE";
		private const string KEY_LAYER = "LAYER";
		private const string KEY_LAYOUT = "LAYOUT";
		private const string KEY_LEADING = "LEADING";
		private const string KEY_LEFT = "LEFT";
		private const string KEY_LEFTCONTROLPOINT = "LEFTCONTROLPOINT";
		private const string KEY_LEFTINDENT = "LEFTINDENT";
		private const string KEY_LENGTH = "LENGTH";
		private const string KEY_LIGATURES = "LIGATURES";
		private const string KEY_LINE = "LINE";
		private const string KEY_GRIDLINE = "GRIDLINE";
		private const string KEY_LINECOUNT = "LINECOUNT";
		private const string KEY_LINESTYLE = "LINESTYLE";
		private const string KEY_LIST = "LIST";
		private const string KEY_LISTSTYLE = "LISTSTYLE";
		private const string KEY_MAINTAINGEOMETRY = "MAINTAINGEOMETRY";
		private const string KEY_MASK = "MASK";
		private const string KEY_MASTER = "MASTER";
		private const string KEY_MERGE = "MERGE";
		private const string KEY_MERGECOLSPAN = "MERGECOLSPAN";
		private const string KEY_MERGEROWSPAN = "MERGEROWSPAN";
		private const string KEY_MORETHANONETOPLEVELCONTOUR = "MORETHANONETOPLEVELCONTOUR";
		private const string KEY_MOVEDOWN = "MOVEDOWN";
		private const string KEY_MOVELEFT = "MOVELEFT";
		private const string KEY_MOVERIGHT = "MOVERIGHT";
		private const string KEY_MOVEUP = "MOVEUP";
		private const string KEY_MULTIPLEINSETS = "MULTIPLEINSETS";
		private const string KEY_MULTIPLYSHADOW = "MULTIPLYSHADOW";
		private const string KEY_NAME = "NAME";
		private const string KEY_NEWFORMAT = "NEWFORMAT";
		private const string KEY_NOISE = "NOISE";
		private const string KEY_NONBREAKING = "NONBREAKING";
		private const string KEY_OFFSET = "OFFSET";
		private const string KEY_OFFSETACROSS = "OFFSETACROSS";
		private const string KEY_OFFSETDOWN = "OFFSETDOWN";
		private const string KEY_OPACITY = "OPACITY";
		private const string KEY_OPERATION = "OPERATION";
		private const string KEY_OT_ALL_SMALL_CAPS = "OT_ALL_SMALL_CAPS";
		private const string KEY_OT_CONTEXTUAL_ALTERNATIVES = "OT_CONTEXTUAL_ALTERNATIVES";
		private const string KEY_OT_DENOMINATOR = "OT_DENOMINATOR";
		private const string KEY_OT_DISCRETIONARY_LIGATURES = "OT_DISCRETIONARY_LIGATURES";
		private const string KEY_OT_FRACTIONS = "OT_FRACTIONS";
		private const string KEY_OT_LINING_FIGURES = "OT_LINING_FIGURES";
		private const string KEY_OT_NONE = "OT_NONE";
		private const string KEY_OT_NUMERATOR = "OT_NUMERATOR";
		private const string KEY_OT_OLDSTYLE_FIGURES = "OT_OLDSTYLE_FIGURES";
		private const string KEY_OT_ORDINALS = "OT_ORDINALS";
		private const string KEY_OT_PROPORTIONAL_FIGURES = "OT_PROPORTIONAL_FIGURES";
		private const string KEY_OT_SMALL_CAPS = "OT_SMALL_CAPS";
		private const string KEY_OT_STANDARD_LIGATURES = "OT_STANDARD_LIGATURES";
		private const string KEY_OT_SUBSCRIPT = "OT_SUBSCRIPT";
		private const string KEY_OT_SUPERSCRIPT = "OT_SUPERSCRIPT";
		private const string KEY_OT_SWASHES = "OT_SWASHES";
		private const string KEY_OT_TABULAR_FIGURES = "OT_TABULAR_FIGURES";
		private const string KEY_OT_TITLING_ALTERNATES = "OT_TITLING_ALTERNATES";
		private const string KEY_OUTLINE = "OUTLINE";
		private const string KEY_OUTSET = "OUTSET";
		private const string KEY_OUTSIDEONLY = "OUTSIDEONLY";
		private const string KEY_PAGE = "PAGE";
		private const string KEY_PARACHAR = "PARACHAR";
		private const string KEY_PARAGRAPH = "PARAGRAPH";
		private const string KEY_PARASTYLE = "PARASTYLE";
		private const string KEY_PATHNAME = "PATHNAME";
		private const string KEY_PICCOLOR = "PICCOLOR";
		private const string KEY_PICTURE = "PICTURE";
		private const string KEY_PLAIN = "PLAIN";
		private const string KEY_POLYCONTOUR = "POLYCONTOUR";
		private const string KEY_POSITION = "POSITION";
		private const string KEY_PROJECT = "PROJECT";
		private const string KEY_RECTCONTOUR = "RECTCONTOUR";
		private const string KEY_RECTSHAPE = "RECTSHAPE";
		private const string KEY_RESTRICTTOBOX = "RESTRICTTOBOX";
		private const string KEY_RICHTEXT = "RICHTEXT";
		private const string KEY_RIGHT = "RIGHT";
		private const string KEY_RIGHTCONTROLPOINT = "RIGHTCONTROLPOINT";
		private const string KEY_RIGHTINDENT = "RIGHTINDENT";
		private const string KEY_ROW = "ROW";
		private const string KEY_ROWCOUNT = "ROWCOUNT";
		private const string KEY_ROWHEIGHT = "ROWHEIGHT";
		private const string KEY_RULE = "RULE";
		private const string KEY_RUNAROUND = "RUNAROUND";
		private const string KEY_RUNAROUNDSHADOW = "RUNAROUNDSHADOW";
		private const string KEY_RUNTEXTAROUNDALLSIDES = "RUNTEXTAROUNDALLSIDES";
		private const string KEY_SCALE = "SCALE";
		private const string KEY_SCALEACROSS = "SCALEACROSS";
		private const string KEY_SCALEDOWN = "SCALEDOWN";
		private const string KEY_SELFINTERSECTED = "SELFINTERSECTED";
		private const string KEY_SHADE = "SHADE";
		private const string KEY_SHADOW = "SHADOW";
		private const string KEY_SHAPE = "SHAPE";
		private const string KEY_SHRINKACROSS = "SHRINKACROSS";
		private const string KEY_SHRINKDOWN = "SHRINKDOWN";
		private const string KEY_SIZE = "SIZE";
		private const string KEY_SKEW = "SKEW";
		private const string KEY_SMALLCAPS = "SMALLCAPS";
		private const string KEY_SMOOTHNESS = "SMOOTHNESS";
		private const string KEY_SMOOTHVERTEX = "SMOOTHVERTEX";
		private const string KEY_SPACEAFTER = "SPACEAFTER";
		private const string KEY_SPACEBEFORE = "SPACEBEFORE";
		private const string KEY_SPLINESHAPE = "SPLINESHAPE";
		private const string KEY_SPLIT = "SPLIT";
		private const string KEY_SPREAD = "SPREAD";
		private const string KEY_STACKINGORDER = "STACKINGORDER";
		private const string KEY_STARTLINE = "STARTLINE";
		private const string KEY_STORY = "STORY";
		private const string KEY_STRAIGHTEDGE = "STRAIGHTEDGE";
		private const string KEY_STRIKETHRU = "STRIKETHRU";
		private const string KEY_STYLE = "STYLE";
		private const string KEY_SUBSCRIPT = "SUBSCRIPT";
		private const string KEY_SUPERIOR = "SUPERIOR";
		private const string KEY_SUPERSCRIPT = "SUPERSCRIPT";
		private const string KEY_SUPPRESSOUTPUT = "SUPPRESSOUTPUT";
		private const string KEY_SUPRESSPICT = "SUPRESSPICT";
		private const string KEY_SYMMVERTEX = "SYMMVERTEX";
		private const string KEY_SYNCHRONIZEANGLE = "SYNCHRONIZEANGLE";
		private const string KEY_TAB = "TAB";
		private const string KEY_TABLE = "TABLE";
		private const string KEY_TABLEBREAK = "TABLEBREAK";
		private const string KEY_TABSPEC = "TABSPEC";
		private const string KEY_TAG = "TAG";
		private const string KEY_TAGSALLOCATED = "TAGSALLOCATED";
		private const string KEY_TEXT = "TEXT";
		private const string KEY_TEXTALIGN = "TEXTALIGN";
		private const string KEY_TEXTALIGNWITHLINE = "TEXTALIGNWITHLINE";
		private const string KEY_TEXTORIENTATION = "TEXTORIENTATION";
		private const string KEY_THRESHOLD = "THRESHOLD";
		private const string KEY_TOP = "TOP";
		private const string KEY_TOPLEVEL = "TOPLEVEL";
		private const string KEY_TRACKAMOUNT = "TRACKAMOUNT";
		private const string KEY_TWISTED = "TWISTED";
		private const string KEY_TYPE = "TYPE";
		private const string KEY_UID = "UID";
		private const string KEY_UNDERLINE = "UNDERLINE";
		private const string KEY_VERTEX = "VERTEX";
		private const string KEY_VERTEXPOINT = "VERTEXPOINT";
		private const string KEY_VERTEXSELECTED = "VERTEXSELECTED";
		private const string KEY_VERTEXTAGEXISTS = "VERTEXTAGEXISTS";
		private const string KEY_VERTICALALIGNMENT = "VERTICALALIGNMENT";
		private const string KEY_VERTICALSCALE = "VERTICALSCALE";
		private const string KEY_VERTICES = "VERTICES";
		private const string KEY_VERTSELECTED = "VERTSELECTED";
		private const string KEY_WELLFORMED = "WELLFORMED";
		private const string KEY_WIDTH = "WIDTH";
		private const string KEY_WORDUNDERLINE = "WORDUNDERLINE";
		private const string KEY_X = "X";
		private const string KEY_Y = "Y";

		#endregion KEY_

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de QXP_Project_Serializer
		/// </summary>
		public QXP_Project_Serializer()
		{
		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// Permet d'obtenir une containaire binaire IOValue de la chaine xml du projet qui pourra ensuite �tre envoy� par Http
		/// </summary>
		/// <param name="project">la structure du projet de modification</param>
		/// <returns>le containaire du flux binaire qui contient le xml s�rialis�</returns>
		public static QXPIO.IOValue Get_IOValue(QXPSMSDK.Project project)
		{
			QXPIO.IOValue __value = new QXPIO.IOValue(Get_XML(project));
			
			return __value;
		}

		/// <summary>
		/// Permet d'obtenir la chaine XML serialis�e d'un Project de modification quark
		/// </summary>
		/// <param name="project">le projet de modification quark</param>
		/// <returns>la chaine xml r�sultant de la s�rialisation</returns>
		public static string		Get_XML(QXPSMSDK.Project project)
		{
			string __xml = Transform(project);

			return __xml;
		}

		/// <summary>
		/// Serialise le projet de modification quark
		/// </summary>
		/// <param name="project">le projet de modification quark</param>
		/// <returns>la chaine xml r�sultant de la s�rialisation</returns>
		public static string		Transform(QXPSMSDK.Project project)
		{
			XmlWriterSettings __setting = new XmlWriterSettings();
			//false Permet de supprimer le BOM ( Byte Order Mark )
			__setting.Encoding	= new UTF8Encoding(false); 
			__setting.Indent	= true;

			using(MemoryStream	__stream	= new MemoryStream())
			{
				XmlWriter		__writer	= XmlWriter.Create(__stream, __setting);
				__writer.WriteStartDocument(false);
				Add_Project(__writer, project);
				__writer.WriteEndDocument();
				__writer.Close();
				return Encoding.UTF8.GetString(__stream.ToArray());
			}
		}
		#region Add

		/// <summary>
		/// Serialise un projet de modification
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="project">le projet � serialiser</param>
		public static void Add_Project(XmlWriter writer, QXPSMSDK.Project project)
		{
			if(QXPFrk.Validation.IsNull(project)) return;

			writer.WriteStartElement(null, KEY_PROJECT, null);
				if(QXPFrk.Validation.IsSet(project.layouts))
				{
					foreach(QXPSMSDK.Layout __layout in project.layouts)
					{
						Add_Layout(writer, __layout);
					}
				}
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise un layout
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="layout">l'objet layout � serialiser</param>
		public static void Add_Layout(XmlWriter writer, QXPSMSDK.Layout layout)
		{
			if(QXPFrk.Validation.IsNull(layout)) return;

			writer.WriteStartElement(null, KEY_LAYOUT, null);
				Add_ID(writer, layout.UID, layout.name);

				if(QXPFrk.Validation.IsSet(layout.spreads))
				{
					foreach(QXPSMSDK.Spread __spread in layout.spreads)
					{
						Add_Spread(writer, __spread);
					}
				}
				if(QXPFrk.Validation.IsSet(layout.boxes))
				{
					foreach(QXPSMSDK.Box __box in layout.boxes)
					{
						Add_Box(writer, __box);
					}
				}
				if(QXPFrk.Validation.IsSet(layout.tables))
				{
					foreach(QXPSMSDK.Table __table in layout.tables)
					{
						Add_Table(writer, __table);
					}
				}
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise un spread (il s'agit d'un espace d'affichage qui peut contenir plusieurs pages)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="spread">l'objet spread � serialiser</param>
		public static void Add_Spread(XmlWriter writer, QXPSMSDK.Spread spread)
		{
			if(QXPFrk.Validation.IsNull(spread)) return;

			writer.WriteStartElement(null, KEY_SPREAD, null);
				Add_AttributeValue(writer, KEY_OPERATION, spread.operation);

				Add_ID(writer, spread.UID, spread.name);
				if(QXPFrk.Validation.IsSet(spread.pages))
				{
					foreach(QXPSMSDK.Page __page in spread.pages)
					{
						Add_Page(writer, __page);
					}
				}
				if(QXPFrk.Validation.IsSet(spread.boxes))
				{
					foreach(QXPSMSDK.Box __box in spread.boxes)
					{
						Add_Box(writer, __box);
					}
				}

				if(QXPFrk.Validation.IsSet(spread.tables))
				{
					foreach(QXPSMSDK.Table __table in spread.tables)
					{
						Add_Table(writer, __table);
					}
				}

			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise une page
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="page">l'objet page � serialiser</param>
		public static void Add_Page(XmlWriter writer, QXPSMSDK.Page page)
		{
			if(QXPFrk.Validation.IsNull(page)) return;

			writer.WriteStartElement(null, KEY_PAGE, null);
				Add_AttributeValue(writer, KEY_OPERATION, page.operation);
				Add_AttributeValue(writer, KEY_MASTER, page.master);
				Add_AttributeValue(writer, KEY_POSITION, page.position);
				
				Add_ID(writer, page.UID, page.name);
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise une boite
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="box">l'objet boite � serialiser</param>
		public static void Add_Box(XmlWriter writer, QXPSMSDK.Box box)
		{
			if(QXPFrk.Validation.IsNull(box)) return;

			writer.WriteStartElement(null, KEY_BOX, null);
				Add_AttributeValue(writer, KEY_OPERATION, box.operation);
				Add_AttributeValue(writer, KEY_BOXTYPE, box.boxType);
				Add_AttributeValue(writer, KEY_COLOR, box.color);
				Add_AttributeValue(writer, KEY_SHADE, box.shade);
				Add_AttributeValue(writer, KEY_OPACITY, box.opacity);
				Add_AttributeValue(writer, KEY_ANCHOREDIN, box.anchoredIn);

				Add_ID(writer, box.UID, box.name);
				Add_Text(writer, box.text);
				Add_Picture(writer, box.picture);
				Add_Geometry(writer, box.geometry);
				Add_Content(writer, box.content);
				Add_Shadow(writer, box.shadow);
				Add_Frame(writer, box.frame);
				
				//box.placeholders Not Applicable
				writer.WriteEndElement();
		}

		/// <summary>
		/// Ajoute un �l�ment ID � la serialisation en cours
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="UID">l'identifiant UID de l'�l�ment</param>
		/// <param name="name">le nom de l'�l�ment</param>
		/// </summary>
		public static void Add_ID(XmlWriter writer, string UID, string name)
		{
			if(QXPFrk.Validation.IsNotSet(UID) && QXPFrk.Validation.IsNotSet(name)) return;

			writer.WriteStartElement(null, KEY_ID, null);
				if(QXPFrk.Validation.IsSet(name)) Add_AttributeValue(writer, KEY_NAME, name);
				if(QXPFrk.Validation.IsSet(UID)) Add_AttributeValue(writer, KEY_UID, UID);
			writer.WriteEndElement();		
		}
		#region Table
		
		/// <summary>
		/// Serialise une table
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="table">l'objet tableau � serialiser</param>
		public static void Add_Table(XmlWriter writer, QXPSMSDK.Table table)
		{
			if(QXPFrk.Validation.IsNull(table)) return;

			writer.WriteStartElement(null, KEY_TABLE, null);
				Add_AttributeValue(writer, KEY_OPERATION, table.operation);
				Add_AttributeValue(writer, KEY_COLUMNCOUNT, table.columnCount);
				Add_AttributeValue(writer, KEY_ROWCOUNT, table.rowCount);
				Add_AttributeValue(writer, KEY_MAINTAINGEOMETRY, table.maintainGeometry);
				Add_AttributeValue(writer, KEY_COLOR, table.color);
				Add_AttributeValue(writer, KEY_SHADE, table.shade);
				Add_AttributeValue(writer, KEY_OPACITY, table.opacity);
				Add_AttributeValue(writer, KEY_ANCHOREDIN, table.anchoredIn);
				Add_AttributeValue(writer, KEY_AUTOFIT, table.autofit);
				Add_AttributeValue(writer, KEY_AUTOFITMAXLIMIT, table.autofitMaxLimit);
				
				Add_ID(writer, table.UID, table.name);
				if(QXPFrk.Validation.IsSet(table.addCells))
				{
					foreach(QXPSMSDK.AddCells __addCells in table.addCells)
					{
						Add_AddCells(writer, __addCells);
					}
				}	
				
				if(QXPFrk.Validation.IsSet(table.deleteCells))
				{
					foreach(QXPSMSDK.DeleteCells __deleteCells in table.deleteCells)
					{
						Add_DeleteCells(writer, __deleteCells);
					}
				}	
				
				//table.deleteCells
				
				Add_ColSpec(writer, table.colSpec);
				
				if(QXPFrk.Validation.IsSet(table.rows))
				{
					foreach(QXPSMSDK.Row __row in table.rows)
					{
						Add_Row(writer, __row);
					}
				}
				Add_TableBreak(writer, table.tableBreak);
				Add_Frame(writer, table.frame);
				Add_Geometry(writer, table.geometry);
				Add_Shadow(writer, table.shadow);
			writer.WriteEndElement();
		}
		
		/// <summary>
		/// Serialise l'ajout de cellules
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="addCells">l'objet contenant les information sur les cellules � ajouter</param>
		public static void Add_AddCells(XmlWriter writer, QXPSMSDK.AddCells addCells)
		{
			if(QXPFrk.Validation.IsNull(addCells)) return;

			writer.WriteStartElement(null, KEY_ADDCELLS, null);
				Add_AttributeValue(writer, KEY_TYPE, addCells.type);
				Add_AttributeValue(writer, KEY_BASEINDEX, addCells.baseIndex);
				Add_AttributeValue(writer, KEY_INSERTCOUNT, addCells.insertCount);
				Add_AttributeValue(writer, KEY_INSERTPOSITION, addCells.insertPosition);
				Add_AttributeValue(writer, KEY_KEEPATTRIBUTE, addCells.keepAttribute);
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise la suppression de cellules
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="deleteCells">l'objet contenant les informations sur les cellules � supprimer</param>
		public static void Add_DeleteCells(XmlWriter writer, QXPSMSDK.DeleteCells deleteCells)
		{
			if(QXPFrk.Validation.IsNull(deleteCells)) return;

			writer.WriteStartElement(null, KEY_DELETECELLS, null);
				Add_AttributeValue(writer, KEY_TYPE, deleteCells.type);
				Add_AttributeValue(writer, KEY_BASEINDEX, deleteCells.baseIndex);
				Add_AttributeValue(writer, KEY_DELETECOUNT, deleteCells.deleteCount);
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise les sp�cifications des colonnes d'un tableau
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="colSpec">l'objet sp�cification des colonnes d'un tableau � serialiser</param>
		public static void Add_ColSpec(XmlWriter writer, QXPSMSDK.ColSpec colSpec)
		{
			if(QXPFrk.Validation.IsNull(colSpec)) return;

			writer.WriteStartElement(null, KEY_COLSPEC, null);
				if(QXPFrk.Validation.IsSet(colSpec.columns))
				{
					foreach(QXPSMSDK.Column __column in colSpec.columns)
					{
						Add_Column(writer, __column);
					}
				}
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise une colonne
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="column">l'objet colonne de tableau � serialiser</param>
		public static void Add_Column(XmlWriter writer, QXPSMSDK.Column column)
		{
			if(QXPFrk.Validation.IsNull(column)) return;

			writer.WriteStartElement(null, KEY_COLUMN, null);
				Add_AttributeValue(writer, KEY_COLUMNCOUNT, column.columnCount);
				Add_AttributeValue(writer, KEY_COLUMNWIDTH, column.columnWidth);
				Add_AttributeValue(writer, KEY_COLOR, column.color);
				Add_AttributeValue(writer, KEY_SHADE, column.shade);
				Add_AttributeValue(writer, KEY_OPACITY, column.opacity);
				Add_AttributeValue(writer, KEY_MERGECOLSPAN, column.mergeColSpan);
				Add_AttributeValue(writer, KEY_SPLIT, column.split);
				Add_AttributeValue(writer, KEY_AUTOFIT, column.autofit);
				Add_AttributeValue(writer, KEY_AUTOFITMAXLIMIT, column.autofitMaxLimit);

				if (QXPFrk.Validation.IsSet(column.gridLines))
				{
					foreach (QXPSMSDK.GridLine __gridLine in column.gridLines)
						Add_GridLine(writer, __gridLine);
				}

			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise une ligne
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="row">l'objet ligne de tableau � serialiser</param>
		public static void Add_Row(XmlWriter writer, QXPSMSDK.Row row)
		{
			if(QXPFrk.Validation.IsNull(row)) return;

			writer.WriteStartElement(null, KEY_ROW, null);
				Add_AttributeValue(writer, KEY_AUTOFIT, row.autofit);
				Add_AttributeValue(writer, KEY_AUTOFITMAXLIMIT, row.autofitMaxLimit);
				Add_AttributeValue(writer, KEY_COLOR, row.color);
				Add_AttributeValue(writer, KEY_MERGEROWSPAN, row.mergeRowSpan);
				Add_AttributeValue(writer, KEY_OPACITY, row.opacity);
				Add_AttributeValue(writer, KEY_ROWCOUNT, row.rowCount);
				Add_AttributeValue(writer, KEY_ROWHEIGHT, row.rowHeight);
				Add_AttributeValue(writer, KEY_SHADE, row.shade);
				Add_AttributeValue(writer, KEY_SPLIT, row.split);

				if(QXPFrk.Validation.IsSet(row.cells))
				{
					foreach(QXPSMSDK.Cell __cell in row.cells)
					{
						Add_Cell(writer, __cell);
					}
				}
				
				if (QXPFrk.Validation.IsSet(row.gridLines))
				{
					foreach (QXPSMSDK.GridLine __gridLine in row.gridLines)
						Add_GridLine(writer, __gridLine);
				}


			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise une cellule
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="cell">l'objet cellule de tableau � serialiser</param>
		public static void Add_Cell(XmlWriter writer, QXPSMSDK.Cell cell)
		{
			if(QXPFrk.Validation.IsNull(cell)) return;

			writer.WriteStartElement(null, KEY_CELL, null);
				Add_AttributeValue(writer, KEY_BOXTYPE, cell.boxType);
				Add_AttributeValue(writer, KEY_COLOR, cell.color);
				Add_AttributeValue(writer, KEY_COLUMNCOUNT, cell.columnCount);
				Add_AttributeValue(writer, KEY_MERGECOLSPAN, cell.mergeColSpan);
				Add_AttributeValue(writer, KEY_MERGEROWSPAN, cell.mergeRowSpan);
				Add_AttributeValue(writer, KEY_OPACITY, cell.opacity);
				Add_AttributeValue(writer, KEY_SHADE, cell.shade);
				Add_AttributeValue(writer, KEY_SPLIT, cell.split);
				
				Add_Content(writer, cell.content);
				Add_Text(writer, cell.text);
				Add_Picture(writer, cell.picture);
			writer.WriteEndElement();		
		}		

		/// <summary>
		/// Serialise une ligne (filet)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="gridline">l'objet filet � serialiser</param>
		public static void Add_GridLine(XmlWriter writer, QXPSMSDK.GridLine gridline)
		{
		    if(QXPFrk.Validation.IsNull(gridline)) return;

		    writer.WriteStartElement(null, KEY_GRIDLINE, null);
				Add_AttributeValue(writer, KEY_STYLE,	gridline.style);
		        Add_AttributeValue(writer, KEY_WIDTH,	gridline.width);
		        Add_AttributeValue(writer, KEY_COLOR, gridline.color);
		        Add_AttributeValue(writer, KEY_SHADE,	gridline.shade);
		        Add_AttributeValue(writer, KEY_OPACITY, gridline.opacity);
		        Add_AttributeValue(writer, KEY_GAPCOLOR, gridline.gapColor);
		        Add_AttributeValue(writer, KEY_GAPSHADE, gridline.gapShade);
		        Add_AttributeValue(writer, KEY_GAPOPACITY, gridline.gapOpacity);
		    writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise une rupture de tableau
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="tableBreak">l'objet rupture de tableau � serialiser</param>
		public static void Add_TableBreak(XmlWriter writer, QXPSMSDK.TableBreak tableBreak)
		{
			if(QXPFrk.Validation.IsNull(tableBreak)) return;

			writer.WriteStartElement(null, KEY_TABLEBREAK, null);
			
			writer.WriteEndElement();
		}
		#endregion Table
		#region Text

		/// <summary>
		/// Serialise un text (object) contenu dans une boite ou une cellule de tableau
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="text">l'objet Text � serialiser</param>
		public static void Add_Text(XmlWriter writer, QXPSMSDK.Text text)
		{
			if(QXPFrk.Validation.IsNull(text)) return;

			writer.WriteStartElement(null, KEY_TEXT, null);
				Add_AttributeValue(writer, KEY_ANGLE, text.angle);
				Add_AttributeValue(writer, KEY_SKEW, text.skew);
				Add_AttributeValue(writer, KEY_COLUMNS, text.columns);
				Add_AttributeValue(writer, KEY_GUTTERWIDTH, text.gutterWidth);
				Add_AttributeValue(writer, KEY_FLIPVERTICAL, text.flipVertical);
				Add_AttributeValue(writer, KEY_FLIPHORIZONTAL, text.flipHorizontal);
				Add_AttributeValue(writer, KEY_VERTICALALIGNMENT, text.verticalAlignment);
				Add_AttributeValue(writer, KEY_INTERPARAGRAPHMAX, text.interParagraphMax);
				Add_AttributeValue(writer, KEY_FIRSTBASELINEMIN, text.firstBaseLineMin);
				Add_AttributeValue(writer, KEY_OFFSET, text.offset);
				Add_AttributeValue(writer, KEY_RUNTEXTAROUNDALLSIDES, text.runTextAroundAllSides);
				Add_AttributeValue(writer, KEY_TEXTORIENTATION, text.textOrientation);
				Add_AttributeValue(writer, KEY_TEXTALIGN, text.textAlign);
				Add_AttributeValue(writer, KEY_TEXTALIGNWITHLINE, text.textAlignWithLine);
				Add_AttributeValue(writer, KEY_FLIPTEXT, text.flipText);

				Add_Inset(writer, text.inset);
				Add_Story(writer, text.story);
			writer.WriteEndElement();
		}

		/// <summary>
		/// serialise un encart
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="inset">l'objet encart � serialiser</param>
		public static void Add_Inset(XmlWriter writer, QXPSMSDK.Inset inset)
		{
			if(QXPFrk.Validation.IsNull(inset)) return;

			writer.WriteStartElement(null, KEY_INSET, null);
				Add_AttributeValue(writer, KEY_MULTIPLEINSETS, inset.multipleInsets);
				Add_AttributeValue(writer, KEY_TOP, inset.top);
				Add_AttributeValue(writer, KEY_BOTTOM, inset.bottom);
				Add_AttributeValue(writer, KEY_RIGHT, inset.right);
				Add_AttributeValue(writer, KEY_LEFT, inset.left);
				Add_AttributeValue(writer, KEY_ALLEDGES, inset.allEdges);
			writer.WriteEndElement();
		}
		
		/// <summary>
		/// Serialise une Story (groupe de paragraphs/text etc.)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="story">l'objet Story � serialiser</param>
		public static void Add_Story(XmlWriter writer, QXPSMSDK.Story story)
		{
			if(QXPFrk.Validation.IsNull(story)) return;

			writer.WriteStartElement(null, KEY_STORY, null);
				Add_AttributeValue(writer, KEY_CLEAROLDTEXT, story.clearOldText);
				Add_AttributeValue(writer, KEY_FITTEXTTOBOX, story.fitTextToBox);
				Add_AttributeValue(writer, KEY_FILE, story.file);
				Add_AttributeValue(writer, KEY_CONVERTQUOTES, story.convertQuotes);
				Add_AttributeValue(writer, KEY_INCLUDESTYLESHEETS, story.includeStylesheets);

				// story.copyFit //Not applicable
				// story.anchoredBoxReferences //Not applicable
				//story.linkedBoxes //Not applicable

				if(QXPFrk.Validation.IsSet(story.paragraphs))
				{
					foreach(QXPSMSDK.Paragraph __paragraph in story.paragraphs)
					{
						Add_Paragraph(writer, __paragraph);
					}
				}
				if(QXPFrk.Validation.IsSet(story.richText))
				{
					foreach(QXPSMSDK.RichText __richText in story.richText)
					{
						Add_RichText(writer, __richText);
					}
				}
				if(QXPFrk.Validation.IsSet(story.lists))
				{
					foreach(QXPSMSDK.List __list in story.lists)
					{
						Add_List(writer, __list);
					}
				}
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise une liste
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="list">l'objet list � serialiser</param>
		public static void Add_List(XmlWriter writer, QXPSMSDK.List list)
		{
			if(QXPFrk.Validation.IsNull(list)) return;

			writer.WriteStartElement(null, KEY_LIST, null);
				Add_AttributeValue(writer, KEY_OPERATION, list.operation);
				Add_AttributeValue(writer, KEY_LISTSTYLE, list.listStyle);

				if(QXPFrk.Validation.IsSet(list.paragraphs))
				{
					foreach(QXPSMSDK.Paragraph __paragraph in list.paragraphs)
					{
						Add_Paragraph(writer, __paragraph);
					}
				}
				if(QXPFrk.Validation.IsSet(list.richText))
				{
					foreach(QXPSMSDK.RichText __richText in list.richText)
					{
						Add_RichText(writer, __richText);
					}
				}
			writer.WriteEndElement();		
		}
		
		/// <summary>
		/// Serialise un paragraphe
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="paragraph">l'objet paragraphe � serialiser </param>
		public static void Add_Paragraph(XmlWriter writer, QXPSMSDK.Paragraph paragraph)
		{
			if(QXPFrk.Validation.IsNull(paragraph)) return;

			writer.WriteStartElement(null, KEY_PARAGRAPH, null);
				Add_AttributeValue(writer, KEY_PARASTYLE, paragraph.paraStyle);
				Add_AttributeValue(writer, KEY_PARACHAR, paragraph.parachar);
				Add_AttributeValue(writer, KEY_MERGE, paragraph.merge);
				
				if(QXPFrk.Validation.IsSet(paragraph.tabspecs))
				{
					foreach(QXPSMSDK.TabSpec __tabSpec in paragraph.tabspecs)
					{
						Add_TabSpec(writer, __tabSpec);
					}
				}
				
				if(QXPFrk.Validation.IsSet(paragraph.rules))
				{
					foreach(QXPSMSDK.Rule __rule in paragraph.rules)
					{
						Add_Rule(writer, __rule);
					}
				}

				Add_Format(writer, paragraph.format);

				if(QXPFrk.Validation.IsSet(paragraph.richText))
				{
					foreach(QXPSMSDK.RichText __richText in paragraph.richText)
					{
						Add_RichText(writer, __richText);
					}
				}
				
			writer.WriteEndElement();
		
		}
		
		/// <summary>
		/// Serialise les tabulations
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="tabSpec">l'objet des tabultations � serialiser</param>
		public static void Add_TabSpec(XmlWriter writer, QXPSMSDK.TabSpec tabSpec)
		{
			if(QXPFrk.Validation.IsNull(tabSpec)) return;

			writer.WriteStartElement(null, KEY_TABSPEC, null);
				if(QXPFrk.Validation.IsSet(tabSpec.tabs))
				{
					foreach(QXPSMSDK.Tab __tab in tabSpec.tabs)
					{
						Add_Tab(writer, __tab);
					}
				}
			writer.WriteEndElement();
		
		}

		
		/// <summary>
		/// Serialise une tabulation
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="tab">l'objet tabulation � serialiser</param>
		public static void Add_Tab(XmlWriter writer, QXPSMSDK.Tab tab)
		{
			if(QXPFrk.Validation.IsNull(tab)) return;

			writer.WriteStartElement(null, KEY_TAB, null);
				Add_AttributeValue(writer, KEY_POSITION, tab.position);
				Add_AttributeValue(writer, KEY_FILL, tab.fill);
				Add_AttributeValue(writer, KEY_ALIGNMENT, tab.alignment);
				Add_AttributeValue(writer, KEY_ALIGNON, tab.alignOn);
				Add_AttributeValue(writer, KEY_ENABLED, tab.enabled);
			writer.WriteEndElement();		
		}
		
		/// <summary>
		/// Serialise une r�gle
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="rule">l'objet r�gle � serialiser</param>
		public static void Add_Rule(XmlWriter writer, QXPSMSDK.Rule rule)
		{
			if(QXPFrk.Validation.IsNull(rule)) return;

			writer.WriteStartElement(null, KEY_RULE, null);
				Add_AttributeValue(writer, KEY_ENABLED, rule.enabled);
				Add_AttributeValue(writer, KEY_POSITION, rule.position);
				Add_AttributeValue(writer, KEY_LENGTH, rule.length);
				Add_AttributeValue(writer, KEY_LEFT, rule.left);
				Add_AttributeValue(writer, KEY_RIGHT, rule.right);
				Add_AttributeValue(writer, KEY_OFFSET, rule.offset);
				Add_AttributeValue(writer, KEY_WIDTH, rule.width);
				Add_AttributeValue(writer, KEY_COLOR, rule.color);
				Add_AttributeValue(writer, KEY_SHADE, rule.shade);
				Add_AttributeValue(writer, KEY_OPACITY, rule.opacity);
				Add_AttributeValue(writer, KEY_STYLE, rule.style);
			writer.WriteEndElement();
		
		}
		
		/// <summary>
		/// Serialise un format d'affichage
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="format">l'objet format d'affichage � serialiser</param>
		public static void Add_Format(XmlWriter writer, QXPSMSDK.Format format)
		{
			if(QXPFrk.Validation.IsNull(format)) return;

			writer.WriteStartElement(null, KEY_FORMAT, null);
				Add_AttributeValue(writer, KEY_SPACEBEFORE, format.spaceBefore);
				Add_AttributeValue(writer, KEY_SPACEAFTER, format.spaceAfter);
				Add_AttributeValue(writer, KEY_LEFTINDENT, format.leftIndent);
				Add_AttributeValue(writer, KEY_RIGHTINDENT, format.rightIndent);
				Add_AttributeValue(writer, KEY_FIRSTLINE, format.firstLine);
				Add_AttributeValue(writer, KEY_LEADING, format.leading);
				Add_AttributeValue(writer, KEY_ALIGNMENT, format.alignment);
				Add_AttributeValue(writer, KEY_HANDJ, format.HAndJ);
				Add_AttributeValue(writer, KEY_KEEPWITHNEXT, format.keepWithNext);

				Add_KeepLinesTogether(writer, format.keepLinesTogether);
				Add_DropCap(writer, format.dropCap);
			writer.WriteEndElement();
		
		}

		/// <summary>
		/// Serialise l'objet KeepLinesTogether (qui permet de controler le flux des lignes dans un paragraphes en fin de colonne)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="keepLinesTogether">l'objet KeepLinesTogether � serialiser</param>
		public static void Add_KeepLinesTogether(XmlWriter writer, QXPSMSDK.KeepLinesTogether keepLinesTogether)
		{
			if(QXPFrk.Validation.IsNull(keepLinesTogether)) return;

			writer.WriteStartElement(null, KEY_KEEPLINESTOGETHER, null);
				Add_AttributeValue(writer, KEY_ENABLED, keepLinesTogether.enabled);
				Add_AttributeValue(writer, KEY_ALLLINESINPARA, keepLinesTogether.allLinesInPara);
				Add_AttributeValue(writer, KEY_STARTLINE, keepLinesTogether.startLine);
				Add_AttributeValue(writer, KEY_ENDLINE, keepLinesTogether.endLine);
			writer.WriteEndElement();		
		}

		/// <summary>
		/// Serialise l'objet DropCap (qui permet de d�finir les propri�t�s du premier charact�re d'un paragraph)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="dropCap">l'objet DropCap � serialiser</param>
		public static void Add_DropCap(XmlWriter writer, QXPSMSDK.DropCap dropCap)
		{
			if(QXPFrk.Validation.IsNull(dropCap)) return;

			writer.WriteStartElement(null, KEY_DROPCAP, null);
				Add_AttributeValue(writer, KEY_CHARCOUNT, dropCap.charCount);
				Add_AttributeValue(writer, KEY_LINECOUNT, dropCap.lineCount);
			writer.WriteEndElement();		
		}
		/// <summary>
		/// Serialise un objet richText (qui d�crit les formats d'un paragraphe)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="richText">l'objet RichText � serialiser</param>
		public static void Add_RichText(XmlWriter writer, QXPSMSDK.RichText richText)
		{
			if(QXPFrk.Validation.IsNull(richText)) return;

			writer.WriteStartElement(null, KEY_RICHTEXT, null);
				Add_AttributeValue(writer, KEY_CHARSTYLE, richText.charStyle);
				Add_AttributeValue(writer, KEY_PLAIN, richText.plain);
				Add_AttributeValue(writer, KEY_MERGE, richText.merge);
				Add_AttributeValue(writer, KEY_BOLD, richText.bold);
				Add_AttributeValue(writer, KEY_ITALIC, richText.italic);
				Add_AttributeValue(writer, KEY_FONT, richText.font);
				Add_AttributeValue(writer, KEY_SIZE, richText.size);
				Add_AttributeValue(writer, KEY_COLOR, richText.color);
				Add_AttributeValue(writer, KEY_SHADE, richText.shade);
				Add_AttributeValue(writer, KEY_OPACITY, richText.opacity);
				Add_AttributeValue(writer, KEY_NONBREAKING, richText.nonBreaking);
				Add_AttributeValue(writer, KEY_UNDERLINE, richText.underline);
				Add_AttributeValue(writer, KEY_WORDUNDERLINE, richText.wordUnderline);
				Add_AttributeValue(writer, KEY_SMALLCAPS, richText.smallCaps);
				Add_AttributeValue(writer, KEY_ALLCAPS, richText.allCaps);
				Add_AttributeValue(writer, KEY_SUPERSCRIPT, richText.superScript);
				Add_AttributeValue(writer, KEY_SUBSCRIPT, richText.subScript);
				Add_AttributeValue(writer, KEY_SUPERIOR, richText.superior);
				Add_AttributeValue(writer, KEY_OUTLINE, richText.outline);
				Add_AttributeValue(writer, KEY_SHADOW, richText.shadow);
				Add_AttributeValue(writer, KEY_STRIKETHRU, richText.strikeThru);
				Add_AttributeValue(writer, KEY_BASELINESHIFT, richText.baselineShift);
				Add_AttributeValue(writer, KEY_HORIZONTALSCALE, richText.horizontalScale);
				Add_AttributeValue(writer, KEY_VERTICALSCALE, richText.verticalScale);
				Add_AttributeValue(writer, KEY_TRACKAMOUNT, richText.trackAmount);
				Add_AttributeValue(writer, KEY_KERNAMOUNT, richText.kernAmount);
				Add_AttributeValue(writer, KEY_LIGATURES, richText.ligatures);
				Add_AttributeValue(writer, KEY_OT_STANDARD_LIGATURES, richText.OTStandardLigatures);
				Add_AttributeValue(writer, KEY_OT_DISCRETIONARY_LIGATURES, richText.OTDiscretionaryLigatures);
				Add_AttributeValue(writer, KEY_OT_ORDINALS, richText.OTOrdinals);
				Add_AttributeValue(writer, KEY_OT_TITLING_ALTERNATES, richText.OTTitlingAlternates);
				Add_AttributeValue(writer, KEY_OT_ALL_SMALL_CAPS, richText.OTAllSmallCaps);
				Add_AttributeValue(writer, KEY_OT_FRACTIONS, richText.OTFractions);
				Add_AttributeValue(writer, KEY_OT_SWASHES, richText.OTSwashes);
				Add_AttributeValue(writer, KEY_OT_SMALL_CAPS, richText.OTSmallCaps);
				Add_AttributeValue(writer, KEY_OT_CONTEXTUAL_ALTERNATIVES, richText.OTContextualAlternatives);
				Add_AttributeValue(writer, KEY_OT_TABULAR_FIGURES, richText.OTTabularFigures);
				Add_AttributeValue(writer, KEY_OT_PROPORTIONAL_FIGURES, richText.OTProportionalFigures);
				Add_AttributeValue(writer, KEY_OT_LINING_FIGURES, richText.OTLiningFigures);
				//Add_AttributeValue(writer, KEY_OT_NONE, richText.OTNone);
				Add_AttributeValue(writer, KEY_OT_SUPERSCRIPT, richText.OTSuperscript);
				Add_AttributeValue(writer, KEY_OT_SUBSCRIPT, richText.OTSubscript);
				Add_AttributeValue(writer, KEY_OT_NUMERATOR, richText.OTNumerator);
				Add_AttributeValue(writer, KEY_OT_DENOMINATOR, richText.OTDenominator);
				Add_AttributeValue(writer, KEY_OT_OLDSTYLE_FIGURES, richText.OTOldStyleFigures);
				Add_AttributeValue(writer, KEY_LANGUAGE, richText.language);
				Add_Value(writer, richText.value);
			writer.WriteEndElement();

		}
		#endregion Text
		#region Picture

		/// <summary>
		/// Serialise les param�tres d'une image
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="picture">l'objet Image � serialiser</param>
		public static void Add_Picture(XmlWriter writer, QXPSMSDK.Picture picture)
		{
			if(QXPFrk.Validation.IsNull(picture)) return;

			writer.WriteStartElement(null, KEY_PICTURE, null);
				Add_AttributeValue(writer, KEY_FIT, picture.fit);
				Add_AttributeValue(writer, KEY_SCALEACROSS, picture.scaleAcross);
				Add_AttributeValue(writer, KEY_SCALEDOWN, picture.scaleDown);
				Add_AttributeValue(writer, KEY_OFFSETACROSS, picture.offsetAcross);
				Add_AttributeValue(writer, KEY_OFFSETDOWN, picture.offsetDown);
				Add_AttributeValue(writer, KEY_ANGLE, picture.angle);
				Add_AttributeValue(writer, KEY_SKEW, picture.skew);
				Add_AttributeValue(writer, KEY_PICCOLOR, picture.pictureColor);
				Add_AttributeValue(writer, KEY_SHADE, picture.shade);
				Add_AttributeValue(writer, KEY_OPACITY, picture.opacity);
				Add_AttributeValue(writer, KEY_FLIPVERTICAL, picture.flipVertical);
				Add_AttributeValue(writer, KEY_FLIPHORIZONTAL, picture.flipHorizontal);
				Add_AttributeValue(writer, KEY_SUPRESSPICT, picture.supressPicture);
				Add_AttributeValue(writer, KEY_FULLRES, picture.fullResolution);
				Add_AttributeValue(writer, KEY_MASK, picture.mask);
			writer.WriteEndElement();
		}

		#endregion Picture
		#region Geometry
		/// <summary>
		/// Serialise la g�ometrie d'un objet
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="geometry">l'objet g�om�trie � serialiser</param>
		public static void Add_Geometry(XmlWriter writer, QXPSMSDK.Geometry geometry)
		{
			if(QXPFrk.Validation.IsNull(geometry)) return;

			writer.WriteStartElement(null, KEY_GEOMETRY, null);
				Add_AttributeValue(writer, KEY_SHAPE, geometry.shape);
				Add_AttributeValue(writer, KEY_PAGE, geometry.page);
				Add_AttributeValue(writer, KEY_ANGLE, geometry.angle);
				Add_AttributeValue(writer, KEY_LAYER, geometry.layer);
				
				Add_Position(writer, geometry.position);
				
				Add_ElementValue(writer, KEY_MOVEUP, geometry.moveUp);
				Add_ElementValue(writer, KEY_MOVEDOWN, geometry.moveDown);
				Add_ElementValue(writer, KEY_MOVELEFT, geometry.moveLeft);
				Add_ElementValue(writer, KEY_MOVERIGHT, geometry.moveRight);
				Add_ElementValue(writer, KEY_GROWACROSS, geometry.growAcross);
				Add_ElementValue(writer, KEY_GROWDOWN, geometry.growDown);
				Add_ElementValue(writer, KEY_SHRINKACROSS, geometry.shrinkAcross);
				Add_ElementValue(writer, KEY_SHRINKDOWN, geometry.shrinkDown);
				Add_ElementValue(writer, KEY_ALLOWBOXONTOPASTEBOARD, geometry.allowBoxOnToPasteboard);
				Add_ElementValue(writer, KEY_ALLOWBOXOFFPAGE, geometry.allowBoxOffPage);
				Add_ElementValue(writer, KEY_STACKINGORDER, geometry.stackingOrder);
				Add_ElementValue(writer, KEY_SUPPRESSOUTPUT, geometry.suppressOutput, def_false_value);

				Add_RunAround(writer, geometry.runaround);
				Add_LineStyle(writer, geometry.linestyle);
				Add_SplineShape(writer, geometry.splineShape);
				
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise l'habillage d'un object
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="runAround">l'objet habillage � serialiser</param>
		public static void Add_RunAround(XmlWriter writer, QXPSMSDK.Runaround runAround)
		{
			if(QXPFrk.Validation.IsNull(runAround)) return;

			writer.WriteStartElement(null, KEY_RUNAROUND, null);
				Add_AttributeValue(writer, KEY_TYPE, runAround.type);
				Add_AttributeValue(writer, KEY_TOP, runAround.top);
				Add_AttributeValue(writer, KEY_RIGHT, runAround.right);
				Add_AttributeValue(writer, KEY_LEFT, runAround.left);
				Add_AttributeValue(writer, KEY_BOTTOM, runAround.bottom);
				Add_AttributeValue(writer, KEY_PATHNAME, runAround.pathName);
				Add_AttributeValue(writer, KEY_OUTSET, runAround.outset);
				Add_AttributeValue(writer, KEY_NOISE, runAround.noise);
				Add_AttributeValue(writer, KEY_THRESHOLD, runAround.threshold);
				Add_AttributeValue(writer, KEY_SMOOTHNESS, runAround.smoothness);
				Add_AttributeValue(writer, KEY_OUTSIDEONLY, runAround.outsideOnly);
				Add_AttributeValue(writer, KEY_RESTRICTTOBOX, runAround.restrictToBox);
				Add_AttributeValue(writer, KEY_INVERT, runAround.invert);
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise le style d'un filet
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="lineStyle">l'objet style de filet � serialiser</param>
		public static void Add_LineStyle(XmlWriter writer, QXPSMSDK.LineStyle lineStyle)
		{
			if(QXPFrk.Validation.IsNull(lineStyle)) return;

			writer.WriteStartElement(null, KEY_LINESTYLE, null);
				Add_AttributeValue(writer, KEY_ARROWHEADS, lineStyle.arrowHeads);
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise un objet SplineShape (qui r�pr�sente les param�tres d'une courbe ex courbe de b�zier)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="splineShape">l'objet SplineShape � serialiser</param>
		public static void Add_SplineShape(XmlWriter writer, QXPSMSDK.SplineShape splineShape)
		{
			if(QXPFrk.Validation.IsNull(splineShape)) return;

			writer.WriteStartElement(null, KEY_SPLINESHAPE, null);
				Add_AttributeValue(writer, KEY_RECTSHAPE, splineShape.rectShape);
				Add_AttributeValue(writer, KEY_INVERTEDSHAPE, splineShape.invertedShape);
				Add_AttributeValue(writer, KEY_HASSPLINES, splineShape.hasSplines);
				Add_AttributeValue(writer, KEY_HASHOLES, splineShape.hasHoles);
				Add_AttributeValue(writer, KEY_NEWFORMAT, splineShape.newFormat);
				Add_AttributeValue(writer, KEY_MORETHANONETOPLEVELCONTOUR, splineShape.moreThanOneTopLevelContour);
				Add_AttributeValue(writer, KEY_CLOSEDSHAPE, splineShape.closedShape);
				Add_AttributeValue(writer, KEY_WELLFORMED, splineShape.wellformed);
				Add_AttributeValue(writer, KEY_TAGSALLOCATED, splineShape.tagsAllocated);
				Add_AttributeValue(writer, KEY_INCOMPLETE, splineShape.incomplete);
				Add_AttributeValue(writer, KEY_VERTSELECTED, splineShape.vertSelected);

				Add_Contours(writer, splineShape.contours);
			writer.WriteEndElement();
		}

		/// <summary>
		/// Serialise les contours d'un objet
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="contours">l'objet Contours � serialiser</param>
		public static void Add_Contours(XmlWriter writer, QXPSMSDK.Contours contours)
		{
			if(QXPFrk.Validation.IsNull(contours)) return;

			writer.WriteStartElement(null, KEY_CONTOURS, null);
				if(QXPFrk.Validation.IsSet(contours.contours))
				{
					foreach(QXPSMSDK.Contour __contour in contours.contours)
					{
						Add_Contour(writer, __contour);
					}
					
				}
			writer.WriteEndElement();		
		}

		/// <summary>
		/// Serialise un contour
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="contour">l'objet contour � serialiser</param>
		public static void Add_Contour(XmlWriter writer, QXPSMSDK.Contour contour)
		{
			if(QXPFrk.Validation.IsNull(contour)) return;

			writer.WriteStartElement(null, KEY_CONTOUR, null);
				Add_AttributeValue(writer, KEY_CURVEDEDGES, contour.curvedEdges);
				Add_AttributeValue(writer, KEY_RECTCONTOUR, contour.rectContour);
				Add_AttributeValue(writer, KEY_INVERTEDCONTOUR, contour.invertedContour);
				Add_AttributeValue(writer, KEY_TOPLEVEL, contour.topLevel);
				Add_AttributeValue(writer, KEY_SELFINTERSECTED, contour.selfIntersected);
				Add_AttributeValue(writer, KEY_POLYCONTOUR, contour.polyContour);
				Add_AttributeValue(writer, KEY_VERTEXTAGEXISTS, contour.vertexTagExists);
				
				Add_Vertices(writer, contour.vertices);
			writer.WriteEndElement();		
		}

		/// <summary>
		/// Serialise l'objet Vertices (ensemble de sommet)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="vertices">l'objet Vertices � serialiser</param>
		public static void Add_Vertices(XmlWriter writer, QXPSMSDK.Vertices vertices)
		{
			if(QXPFrk.Validation.IsNull(vertices)) return;

			writer.WriteStartElement(null, KEY_VERTICES, null);
				if(QXPFrk.Validation.IsSet(vertices.vertices))
				{
					foreach(QXPSMSDK.Vertex __vertex in vertices.vertices)
					{
						Add_Vertex(writer, __vertex);		
					}
				}
			writer.WriteEndElement();		
		
		}

		/// <summary>
		/// Serialise un vertex (sommet ou direction d'un point)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="vertex">l'objet Vertex � serialiser</param>
		public static void Add_Vertex(XmlWriter writer, QXPSMSDK.Vertex vertex)
		{
			if(QXPFrk.Validation.IsNull(vertex)) return;

			writer.WriteStartElement(null, KEY_VERTEX, null);
				Add_AttributeValue(writer, KEY_SMOOTHVERTEX, vertex.smoothVertex);
				Add_AttributeValue(writer, KEY_STRAIGHTEDGE, vertex.straightEdge);
				Add_AttributeValue(writer, KEY_SYMMVERTEX, vertex.symmVertex);
				Add_AttributeValue(writer, KEY_SYMMVERTEX, vertex.symmVertex);
				Add_AttributeValue(writer, KEY_CUSPVERTEX, vertex.cuspVertex);
				Add_AttributeValue(writer, KEY_TWISTED, vertex.twisted);
				Add_AttributeValue(writer, KEY_VERTEXSELECTED, vertex.vertexSelected);

				Add_LeftControlPoint(writer, vertex.leftControlPoint);
				Add_VertexPoint(writer, vertex.vertexPoint);
				Add_RightControlPoint(writer, vertex.rightControlPoint);
			writer.WriteEndElement();			
		}

		/// <summary>
		/// Serialise un objet LeftControlPoint (qui d�fini les coordonn�es d'un point dans une courbe par x, y)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="leftControlPoint">l'objet LeftControlPoint � serialiser</param>
		public static void Add_LeftControlPoint(XmlWriter writer, QXPSMSDK.LeftControlPoint leftControlPoint)
		{
			if(QXPFrk.Validation.IsNull(leftControlPoint)) return;

			writer.WriteStartElement(null, KEY_LEFTCONTROLPOINT, null);
				Add_AttributeValue(writer, KEY_X, leftControlPoint.x);
				Add_AttributeValue(writer, KEY_Y, leftControlPoint.y);
			writer.WriteEndElement();			
		}

		/// <summary>
		/// Serialise un objet RightControlPoint (qui d�fini les coordonn�es d'un point dans une courbe par x, y)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="rightControlPoint">l'objet RightControlPoint � serialiser</param>
		public static void Add_RightControlPoint(XmlWriter writer, QXPSMSDK.RightControlPoint rightControlPoint)
		{
			if(QXPFrk.Validation.IsNull(rightControlPoint)) return;

			writer.WriteStartElement(null, KEY_RIGHTCONTROLPOINT, null);
				Add_AttributeValue(writer, KEY_X, rightControlPoint.x);
				Add_AttributeValue(writer, KEY_Y, rightControlPoint.y);
			writer.WriteEndElement();			
		}

		/// <summary>
		/// Serialise un objet VertexPoint (qui d�fini les coordonn�es d'un point dans une courbe par x, y et d'un vertex)
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="vertexPoint">l'objet VertexPoint � serialiser</param>
		public static void Add_VertexPoint(XmlWriter writer, QXPSMSDK.VertexPoint vertexPoint)
		{
			if(QXPFrk.Validation.IsNull(vertexPoint)) return;

			writer.WriteStartElement(null, KEY_VERTEXPOINT, null);
				Add_AttributeValue(writer, KEY_X, vertexPoint.x);
				Add_AttributeValue(writer, KEY_Y, vertexPoint.y);
				Add_AttributeValue(writer, KEY_TAG, vertexPoint.tag);
			writer.WriteEndElement();			
		}
		
		/// <summary>
		/// Serialise une position d'un objet
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="position">l'objet position � serialiser</param>
		public static void Add_Position(XmlWriter writer, QXPSMSDK.Position position)
		{
			if(QXPFrk.Validation.IsNull(position)) return;

			writer.WriteStartElement(null, KEY_POSITION, null);
				Add_ElementValue(writer, KEY_TOP, position.top);
				Add_ElementValue(writer, KEY_LEFT, position.left);
				Add_ElementValue(writer, KEY_BOTTOM, position.bottom);
				Add_ElementValue(writer, KEY_RIGHT, position.right);
			writer.WriteEndElement();
		
		}

		#endregion Geometry
		#region Content
		/// <summary>
		/// Serialise un contenue d'une boite ou d'une cellule
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="content">l'objet contenu � serialiser</param>
		public static void Add_Content(XmlWriter writer, QXPSMSDK.Content content)
		{
			if(QXPFrk.Validation.IsNull(content)) return;

			writer.WriteStartElement(null, KEY_CONTENT, null);
				Add_AttributeValue(writer, KEY_CONVERTQUOTES, content.convertQuotes);
				Add_AttributeValue(writer, KEY_INCLUDESTYLESHEETS, content.includeStyleSheets);
				Add_AttributeValue(writer, KEY_FONTNAME, content.fontName);
				Add_Value(writer, content.value);
			writer.WriteEndElement();
		}
		#endregion Content
		#region Shadow
		/// <summary>
		/// Serialise une ombre d'une boite ou d'une table
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="shadow">l'objet ombre � serialiser</param>
		public static void Add_Shadow(XmlWriter writer, QXPSMSDK.Shadow shadow)
		{
			if(QXPFrk.Validation.IsNull(shadow)) return;

			writer.WriteStartElement(null, KEY_SHADOW, null);
				Add_AttributeValue(writer, KEY_COLOR, shadow.color);
				Add_AttributeValue(writer, KEY_SHADE, shadow.shade);
				Add_AttributeValue(writer, KEY_OPACITY, shadow.opacity);
				Add_AttributeValue(writer, KEY_ANGLE, shadow.angle);
				Add_AttributeValue(writer, KEY_DISTANCE, shadow.distance);
				Add_AttributeValue(writer, KEY_SKEW, shadow.skew);
				Add_AttributeValue(writer, KEY_SCALE, shadow.scale);
				Add_AttributeValue(writer, KEY_BLUR, shadow.blur);
				Add_AttributeValue(writer, KEY_KNOCKOUTSHADOW, shadow.knockoutShadow);
				Add_AttributeValue(writer, KEY_SYNCHRONIZEANGLE, shadow.synchronizeAngle);
				Add_AttributeValue(writer, KEY_RUNAROUNDSHADOW, shadow.runaroundShadow);
				Add_AttributeValue(writer, KEY_MULTIPLYSHADOW, shadow.multiplyShadow);
				Add_AttributeValue(writer, KEY_INHERITOPACITY, shadow.inheritOpacity);
			writer.WriteEndElement();
		}
		#endregion Shadow
		#region Frame
		/// <summary>
		/// Serialise un encadrement d'une boite ou d'un tableau 
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="frame">l'objet encadrement � serialiser</param>
		public static void Add_Frame(XmlWriter writer, QXPSMSDK.Frame frame)
		{
			if(QXPFrk.Validation.IsNull(frame)) return;

			writer.WriteStartElement(null, KEY_FRAME, null);
				Add_AttributeValue(writer, KEY_STYLE, frame.style);
				Add_AttributeValue(writer, KEY_WIDTH, frame.width);
				Add_AttributeValue(writer, KEY_COLOR, frame.color);
				Add_AttributeValue(writer, KEY_SHADE, frame.shade);
				Add_AttributeValue(writer, KEY_OPACITY, frame.opacity);
				Add_AttributeValue(writer, KEY_GAPCOLOR, frame.gapColor);
				Add_AttributeValue(writer, KEY_GAPSHADE, frame.gapShade);
				Add_AttributeValue(writer, KEY_GAPOPACITY, frame.gapOpacity);
			writer.WriteEndElement();
		}
		#endregion Frame

		#region Add Element/Attribute/Values

		/// <summary>
		/// Ajoute un attribut avec sa valeur � l'�l�m�ent actif dans le writer
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="name">le nom de l'attribut</param>
		/// <param name="value">la valeur de l'attribut</param>
		public static void Add_AttributeValue(XmlWriter writer, string name, string value)
		{
			if(QXPFrk.Validation.IsSet(value))
			{
				writer.WriteAttributeString(name, value);
			}
		}
		
		/// <summary>
		/// Ajoute un element et sa valeur � l'�l�ment actif dans le writer
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="name">le nom de l'�l�ment</param>
		/// <param name="value">la valeur de l'�l�ment</param>
		public static void Add_ElementValue(XmlWriter writer, string name, string value)
		{
			if(QXPFrk.Validation.IsSet(value))
			{
				writer.WriteElementString(name, value);
			}
		}
		
		/// <summary>
		/// Ajoute un element et sa valeur � l'�l�ment actif dans le writer
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="name">le nom de l'�l�ment</param>
		/// <param name="value">la valeur de l'�l�ment</param>
		/// <param name="def_value">D�fini la valeur par d�faut du param�tre si value = def_value l'�l�ment n'est pas ajout� !!</param>
		public static void Add_ElementValue(XmlWriter writer, string name, string value, string def_value)
		{
			if(QXPFrk.Validation.IsSet(value) && value != def_false_value)
			{
				writer.WriteElementString(name, value);
			}
		}

		/// <summary>
		/// Ajoute une valeur � l'�l�ment actif dans le writer
		/// </summary>
		/// <param name="writer">le container xml dans lequel nous allons �crire la chaine</param>
		/// <param name="value">la valeur</param>
		public static void Add_Value(XmlWriter writer, string value)
		{
			if(QXPFrk.Validation.IsSet(value))
			{
				writer.WriteValue(value);
			}
		}
		#endregion Add Element/Attribute/Values


		#endregion Add
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
