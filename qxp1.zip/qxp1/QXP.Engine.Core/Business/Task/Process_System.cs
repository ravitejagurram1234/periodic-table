using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core.Business
{
	/// <summary>
	/// Contient la partie business du processing d'une tache de type "Task_System"
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 17:50:15</date>    
	public class Process_System
	{
		#region Membres

		#endregion Membres

		#region Constantes
        
		
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		#endregion Constructeur

		#region M�thodes
        /// <summary>
        /// Cr�ation des blocs
        /// </summary>
        /// <param name="task">la tache</param>
		public static void Process(Task_System task)
		{
            Bloc_Box			__bloc;

            //Checks Task
            if (QXPFrk.Validation.IsNotSet(task.DestinationBlocName))
            {
                task.Run.Errors.Add(Constantes.Error_Messages.MissingBlocNameInTask, task.Debug_Info);
                return;
            }

			
			//C'est une tache system Box (mise � jour d'une Box (contenu/position etc) 
			if(QXPFrk.Validation.IsSet(task.TBox))
			{
				task.Sub_Task_Type	= Sub_Task_Type.Box;

				__bloc = new Bloc_Box(task, task.TBox.SrcBox.name, task.TBox);
			
				//Indique un deplacement de bloc
				__bloc.Action				= task.TBox_Action;
				__bloc.Pagination			= task.TBox_Pagination;
				task.Blocs_Modify.Add(__bloc.Name, __bloc);
				
			}
			//C'est une tache system valeur (mise � jour de la valeur d'un bloc
			else
			{
				//C'est une tache valeur
				task.Sub_Task_Type	= Sub_Task_Type.Value;
			
				Data_Type_Helper	__data_Type_Helper = new Data_Type_Helper(task.Run.Properties);
				
				__bloc = new Bloc_Box(task, task.DestinationBlocName, __data_Type_Helper.OutputToString(task.Value, task.Data_Type, task.NbDecimal, task.ShowZero, task.NullString, task.Decimal_Significative));
				task.Blocs_Update.Add(__bloc.Name, __bloc);
			
			}
        }
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
