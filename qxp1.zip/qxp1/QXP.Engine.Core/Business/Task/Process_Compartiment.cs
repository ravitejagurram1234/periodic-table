using System;
using System.Collections.Generic;

using QXPFrk = QXP.Framework;

using QXPSMSDK	= com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPBusinessClass
*/
namespace QXP.Engine.Core.Business
{
	/// <summary>
	/// Contient la partie business d'une tache de type "Task_Compartiment"
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/05/2010 14:46:36</date>    
	public class Process_Compartiment
	{
		#region Membres

		#endregion Membres

		#region Constantes
		/// <summary>
		/// Repr�sente le type de rapport des runs fils � retrouver associ�s � la tache compartiment
		/// </summary>
		public	const int		Type_Rapport_Compartiment	= 4;
		public	const int		Max_OldName_Size			= 24;
		const string			Suffixe_Pattern				= "_{0}";
		const string			New_Page_Pattern			= "T{0}_P{1}"; //0 - tache 1 - indexpage
		const string			DefBoxNamePattern			= "Box{0}"; //Pattern des nom de bloc g�n�r� par quark xpress server lorsqu'une boite na pas de nom donn�e par l'utilisateur
		private const string	Out_OfPage_Char				= "*"; //D�fini le caract�re qui exprime dans le num�ro de page qu'un bloc est situ� sur le pastboard

		//private const string	QXPSDKtrue					= "true";
		private const string	QXPSDKfalse					= "false";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Process_Compartiment
		/// </summary>
		public Process_Compartiment()
		{
		}

		#endregion Constructeur

		#region M�thodes
        /// <summary>
        /// Ex�cution de la tache
        /// </summary>
        /// <param name="task">la tache</param>
		public static void		Process(Task_Compartiment task)
		{

			if (task.Run.Properties.Compartiment_Mode == Task_Compartiment_Mode.Unknown)
			{
				Exception_Helper.Raise_Exception(new Exception_Task(Exception_Task.MSG_Load_Task_Compartiment, task.ID));
			}

			//Pr�paration des runs fils � �x�cuter
			//g�n�ralement cette propri�t� est vrai sauf dans des cas tr�s particulier de TEST
			if (task.Evaluate_Runs)
			{
				Prepare_Runs(task);
			}

			//Ex�cution des runs fils
			Execute_Runs(task);

			//Ajout des blocs contenues dans les document finaux des runs fils dans la tache en cours
			Render_Runs(task);

			//Afin de soulager la m�moire est maintenant que les informations ont �t� r�cup�r� des runs nous vidons la liste des childRun
			//Car en prod le process Engine peut atteindre 1 Go.
			task.Child_Runs.Clear();
			
			//Il faut purger tout �a en force maintenant
			GC.Collect();
			GC.WaitForPendingFinalizers();
		}

		/// <summary>
		/// Preparation des runs inclus dans la tache
		/// </summary>
		/// <param name="task">la tache compartiment</param>
		static void Prepare_Runs(Task_Compartiment task)
		{
			// 1 - G�n�ration ou r�cup�ration des child_runs

			// 1.1 - chargement de la liste des compartiment run
			List_Compartiment_Run		__list_compartiment_run;
			Run_Base					__run				= null;
			Run_Properties				__run_Properties	= task.Run.Properties;
			Proxy_Run					__proxy				= new Proxy_Run();
			bool						__to_Generate		= (task.Run.Properties.Compartiment_Mode & Task_Compartiment_Mode.Generate) == Task_Compartiment_Mode.Generate;
	
			__list_compartiment_run = __proxy.Get_Compartiment_Runs(__run_Properties.ID_Gabarit, __run_Properties.ID_Fnd_Code, task.ID_Gabarit_Fils, Type_Rapport_Compartiment,  __run_Properties.ID_Langue, __run_Properties.Date_Echeance, __to_Generate);

			if (__list_compartiment_run.Count > 0)
			{
				// 1.2 - V�rification des compartiment runs et cr�ation de la liste des runs en fonction du type
				foreach (KeyValuePair<string, int> __keyValue in __list_compartiment_run)
				{
					//Il y � bien un run
					if (QXPFrk.Validation.IsSet(__keyValue.Value))
					{
						if (__to_Generate)
						{
							__run = new Run(__keyValue.Value);
						}
						else
						{
							__run = new Run_Previous(__keyValue.Value);
						}

						task.Child_Runs.Add(__run);

					}
					// Il n'y a aucun run pour le compartiment 
					else
					{
						task.Run.Errors.Add(Constantes.Error_Messages.EmptyRunCompartiment, __keyValue.Key, task.ID, task.Run.ID);
					}
				}
			}
			else
			{
				task.Run.Errors.Add(Constantes.Error_Messages.NoneRunCompartiment, task.ID, task.Run.ID);
			}
		}

		/// <summary>
		/// Ex�cution/R�cup�ration des runs contenus dans tache
		/// </summary>
		/// <param name="task">la tache compartiment</param>
		static void Execute_Runs(Task_Compartiment task)
		{
			// Ex�cution des run fils 
			//attention les �tapes �x�cuter change en fonction du type de run (standard=run previous=run_previous)
			foreach (Run_Base __r in task.Child_Runs)
			{
				__r.Launch();

				//R�cup�ration des traces m�moires du run fils dans le run p�re
				string __childTrace = __r.Trace_Context.All_Logs;

				//R�initialisation du context au run en cours ^^ et non plus � un child run
				task.Run.SetTraceContext();

				//Ajout de la trace du fils dans la trace du p�re
				Trace_Helper.Log_Message("Child Trace:\n{0}", __childTrace);
			}
		}

		/// <summary>
		/// Rendu du contenu des runs contenus dans la tache compartiment
		/// </summary>
		/// <param name="task">la tache compartiment</param>
		static void Render_Runs(Task_Compartiment task)
		{
			Bloc_Page	__bloc_Page;
			int			__last_Page				= 0;

			//Si la tache est � incorporer il faut ajouter les blocs contenu dans les documents qxp des childs run (g�n�r�s ou r�cup�r�s)
			if ((task.Run.Properties.Compartiment_Mode & Task_Compartiment_Mode.Incorporate) == Task_Compartiment_Mode.Incorporate)
			{
				foreach (Run_Base __r in task.Child_Runs)
				{
					//G�n�ration des blocs
					__last_Page = Add_Run_Blocs(task, __r, __last_Page);
				}

				//1 - Test des compartiments vide
				//Si la tache ne poss�de aucun bloc, cela sous entend que les compartiments �taient vide
				//Nous v�rifions s'il n'y � aucun bloc de g�n�r� par les compartiment nous cr�ons une page vide

				if(task.Blocs_Modify.Count == 0)
				{
					__bloc_Page					= new Bloc_Page(task, string.Format(New_Page_Pattern, task.ID, 0));
					__bloc_Page.Action			= Bloc_Action.CREATE;
					__bloc_Page.Relative_Page	= 0;
					task.Blocs_Modify.Add(__bloc_Page.Name, __bloc_Page);
					__last_Page++; //la derni�re page est 1 maintenant
				}

				//Evaluation des ancres D�but et Fin
				DBloc_Info __start_Info = task.Get_Anchor_Info(true);

				DBloc_Info __end_Info	= task.Get_Anchor_Info(false);

				//Cr�ation des taches pour supprimer les pages et d�placer les ancres
				//Info: les page � ajouter on �t� cr��s dans Add_Run_Blocs

				//2 - Suppression des pages en trop
				int __nb_Ancien_Page = __end_Info.Page - __start_Info.Page;
				int __relative_remove_page;

				for (int __i = 0; __i <= __nb_Ancien_Page; __i++)
				{
				    __relative_remove_page					= __last_Page + __i;
				    __bloc_Page								= new Bloc_Page(task, string.Format(New_Page_Pattern, task.ID, __relative_remove_page));
				    __bloc_Page.Action						= Bloc_Action.REMOVE;
				    __bloc_Page.Relative_Page				= __relative_remove_page;
				    task.Blocs_Modify.Add(__bloc_Page.Name, __bloc_Page);
				}

				//3 - deplacement de l'ancre en premi�re page cr��e

				Bloc_Box __bloc_start = TElement_Helper.Get_Move_Anchor(task, __start_Info, 0);

				//Cette modification doit �tre effectu�e en m�me temps que la nouvelle pagination
				__bloc_start.Pagination = true;
				task.Blocs_Modify.Add(__bloc_start.Name, __bloc_start);

				//4 - deplacement de l'ancre en derni�re page cr��e

				Bloc_Box __bloc_end = TElement_Helper.Get_Move_Anchor(task, __end_Info, __last_Page - 1);

				//Cette modification doit �tre effectu�e en m�me temps que la nouvelle pagination
				__bloc_end.Pagination = true;
				task.Blocs_Modify.Add(__bloc_end.Name, __bloc_end);

			}
			//S'il n'y a rien � incorporer il n'y � donc plus rien � faire pour cette tache
			else
			{
				//cette modification permet d'ignorer le test sur le nombre de bloc g�n�r� par la tache qui est dans notre cas �gale � 0
				task.Todo = false;
			}
		}


		/// <summary>
		/// Permet d'ajouter les bloc contenu dans le document final qxp du run child dans la tache compartiment en cours
		/// </summary>
		/// <param name="task">la tache compartiment en cours</param>
		/// <param name="child_Run">le run sur le gabarit fils</param>
		/// <param name="lastPage">Index de la derni�re page</param>
		/// <returns>le nombre de page cr��e par les bloc du run fils</returns>
		static int Add_Run_Blocs(Task_Compartiment task, Run_Base child_Run, int lastPage)
		{
			QXP_Project __qxp_Project;
			
			if(QXPFrk.Validation.IsNull(child_Run.Result) || QXPFrk.Validation.IsNull(child_Run.Result.Final_QXP))
			{
				task.Run.Errors.Add(Constantes.Error_Messages.EmptyRunChildQXP, child_Run.ID);
				return lastPage;
			}

			if(QXPFrk.Validation.IsNull(child_Run.Result.Final_QXP.QXPProject))
			{
				task.Run.Errors.Add(Constantes.Error_Messages.EmptyRunChildProject, child_Run.ID);
				return lastPage;
			}

			__qxp_Project = child_Run.Result.Final_QXP.QXPProject;

			//Ajout des blocs �valuer � partir du Projet du document fils dans la tache compartiment en cours
			//Retourne le nombre de page cr��s !
			int __new_LastPage = Add_Blocs(task, __qxp_Project, child_Run, lastPage);

			return __new_LastPage;
		}

		/// <summary>
		/// Mise � jour du projet comptage du nombre de page du projet
		/// la mise � jour change le nom des blocs en ajoutant un suffixe et met les operations � CREATE sur tous les �l�ments sur lesquels c'est possibles
		/// </summary>
		/// <param name="task">la tache dans laquelle il faut ajouter les blocs</param>
		/// <param name="qxp_Project">Le project � mettre � jour.</param>
		/// <param name="run_Child">Le run compartiment en cours.</param>
		/// <param name="lastPage">Index de la derni�re page en cours</param>
		/// <returns>le nombre de page dans le projet</returns>
		static int Add_Blocs(Task_Compartiment task, QXP_Project qxp_Project, Run_Base run_Child, int lastPage)
		{
			//Structure du project dans laquelle il faut r�cup�rer les blocs
			QXPSMSDK.Project	__project			= qxp_Project.Project;
			
			//identifiant du compartiment
			string					__standard_Suffixe	= run_Child.Properties.ID_Fnd_Code;
			
			Bloc_Page				__bloc_Page			= null;
			Bloc_Box				__bloc_Box			= null;
			//Nombre de Box r�cup�r� dans le QXP_Project du run child
			int						__nbBox				= 0;
			string					__last_Page			= string.Empty;
			string					__current_Page		= string.Empty;
			int						__current_Page_ID;
			bool					__new_Page			= false;

			//Le trie s'effectuant sur la clef il faut qu'elle soit de type int
			SortedDictionary<int, QXPFrk.BaseList<Bloc_Box>>	__boxes_By_Page				= new SortedDictionary<int,QXP.Framework.BaseList<Bloc_Box>>();
			QXPFrk.BaseList<Bloc_Box>							__current_Boxes				= null;

			Trace_Helper.Log_Message("D�but de l'analyse du run child {0}", run_Child.ID);

			if (QXPFrk.Validation.IsSet(__project.layouts))
			{
				//Analyse de l'arborescence du projet
				foreach (QXPSMSDK.Layout __layout in __project.layouts)
				{
					if (QXPFrk.Validation.IsSet(__layout.spreads))
					{
						foreach (QXPSMSDK.Spread __spread in __layout.spreads)
						{
							if (QXPFrk.Validation.IsSet(__spread.boxes))
							{
								//r�cup�ration des boites
								foreach (QXPSMSDK.Box __box in __spread.boxes)
								{

									//Les blocs qui sont situ�s en dehors de la page du spread ne sont pas r�cup�r�s
									//Pour savoir si un bloc se trouve en dehors de la page (sur le "pastboard") ont regarde si le num�ro de la page se termine par *
									//en faite * si le bloc est � gauche de la page et ** s'il est situ� � droite

									if (!__box.geometry.page.EndsWith(Out_OfPage_Char))
									{
										__current_Page = __box.geometry.page;

										//y a-t-il eu un changement de page
										__new_Page = (__last_Page != __current_Page);

										//petite optimisation afin de ne pas avoir � rechercher __current_Boxes � chaque fois
										if (__new_Page)
										{
                                            __current_Page_ID = QXPFrk.ConversionInvariante.ToInt(__current_Page);
											if (__boxes_By_Page.ContainsKey(__current_Page_ID))
											{
												__current_Boxes = __boxes_By_Page[__current_Page_ID];
											}
											else
											{
												__current_Boxes = new QXPFrk.BaseList<Bloc_Box>();
												__boxes_By_Page.Add(__current_Page_ID, __current_Boxes);
											}
											__last_Page = __current_Page;
										}


										__box.name = Rename_Bloc(__box, __standard_Suffixe);

										//Important ! cette ligne doit �tre apr�s la fonction Rename_Bloc au dessus
										__box.UID = null;

										__bloc_Box = new Bloc_Box(task, __box.name, new TBox(__box));
										__bloc_Box.Action = Bloc_Action.CREATE;

										__current_Boxes.Add(__bloc_Box);

									}
								}
							}
						}
					}
				}
			}

			foreach(QXPFrk.BaseList<Bloc_Box> __bloc_List in __boxes_By_Page.Values)
			{
				//Si la page contient au moins une boite � imprim�
				//s'il n'y � pas de bloc ou que des bloc ne pas imprim� (exemple les ancres) cette page est exclue (les blocs ne sont pas ajout�s � la tache
				if(__bloc_List.Exists(delegate(Bloc_Box bloc_Box){return bloc_Box.SrcBox.geometry.suppressOutput == QXPSDKfalse;}))
				{
	                //ajout de la page
	                __bloc_Page					= new Bloc_Page(task, string.Format(New_Page_Pattern, task.ID, lastPage));
	                __bloc_Page.Action			= Bloc_Action.CREATE;
	                __bloc_Page.Relative_Page	= lastPage;

	                task.Blocs_Modify.Add(__bloc_Page.Name, __bloc_Page);
					
					//ajout des blocs
					foreach(Bloc_Box __bloc in __bloc_List)
					{
						//Mise � jour des num�ros de pages relative et ajout dans la tache
						__bloc.Relative_Page = lastPage;
						task.Blocs_Modify.Add(__bloc.Name, __bloc);
					}
					lastPage++;
				}

			}

			Trace_Helper.Log_Message("{0} Boxes r�cup�r�s du run child {1}", __nbBox, run_Child.ID);
			return lastPage;
		}

		/// <summary>
		/// Permet de renommer un ancien nom de bloc en ajoutant le suffixe et en s'assurant que la taille du nouveau nom est bien inf�rieur ou �gale � 31
		/// le nouveau nom est �gale � "OLDNAME_SUFFIXE" ou OLDNAME est limit� � 24 caract�res et PREFIX � 6
		/// </summary>
		/// <param name="box">la boite � renommer</param>
		/// <param name="suffixe">le suffixe � ajouter (6 caract�res max)</param>
		/// <returns>le nouveau nom</returns>
		static string Rename_Bloc(QXPSMSDK.Box box, string suffixe)
		{
			string __old_Name	= box.name;
			string __new_Name	= QXPFrk.StringHelper.Left(__old_Name, Max_OldName_Size);
			string __def_Name	= string.Format(DefBoxNamePattern, box.UID);
			string __suffixe	= string.Format(Suffixe_Pattern, suffixe);

			//nous v�rifions l'ancien nom ne correspond pas au nom par d�faut des bloc quark qui � le pattern "BoxY" ou Y et l'UID de la boite;
			//l'ancien nom doit �tre d�fini et il ne doit pas �tre �gale au nom par d�faut des boites quark exemple "Box365"
			if (QXPFrk.Validation.IsSet(__new_Name) && (__old_Name != __def_Name))
			{
				//Si le __new_name se termine d�j� par le suffixe on ne fait rien le nom est d�j� unique
				if (!__new_Name.EndsWith(__suffixe))
				{
					__new_Name = string.Concat(__new_Name, __suffixe);
				}
			}
			//l'ancien nom n'�tait pas d�fini
			else
			{
				__new_Name = TElement_Helper.NewBlocName();
			}
			
			return __new_Name;
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
