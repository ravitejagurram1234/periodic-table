using System;

using QXPFrk	= QXP.Framework;
using QXPIO		= QXP.Framework.IO;

using QXPSMSDK	= com.quark.qxpsm;

namespace QXP.Engine.Core.Business
{
	/// <summary>
	/// Contient la partie business du processing d'une tache de type "Task_Document"
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 17:50:15</date>    
	public class Process_Document
	{
		#region Membres

		#endregion Membres

		#region Constantes
		const string PictureRotation90			= "90";

        const string SourceFileAbsoluPattern	= "{0}";
        const string SourceFileDocPoolPattern	= "file:{0}";

        const string PDFBlocNamePattern			= "{0}_{1}"; // 0= prefixe du bloc / 1= num�ro du bloc
        const string PDFPageNamePattern			= "P{0}_{1}"; // 0 = page / 1= nom du bloc

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		#endregion Constructeur

		#region M�thodes
        /// <summary>
        /// Cr�ation des blocs
        /// </summary>
        /// <param name="task">la tache de type document</param>
		public static void Process(Task_Document task)
		{
			Bloc_Box	__blocBox	= null;
			TBox		__tBox;
            //Checks Task
            if (QXPFrk.Validation.IsNotSet(task.DestinationBlocName))
            {
                task.Run.Errors.Add(Constantes.Error_Messages.MissingBlocNameInTask, task.Debug_Info);
                return;
            }
            switch (task.Sub_Task_Type)
            {
                case Sub_Task_Type.File_IMG:
					//obtenir une copie du Template element
					__tBox = TElement_Helper.Get_TElement(Static_TElement_Name.IMG, task.DestinationBlocName) as TBox;
					__tBox.SrcBox.content.value	= string.Format(SourceFileAbsoluPattern, task.Document.FileFullPath);
					if (task.Rotation_Image) __tBox.SrcBox.picture.angle = "90";
					__blocBox			= new Bloc_Box(task, task.DestinationBlocName, __tBox);
					break;
                case Sub_Task_Type.File_PDF:
					//Ajout de 1 a N bloc_box !!
					Process_File_PDF(task);
                    break;
                case Sub_Task_Type.File_DOC:
                case Sub_Task_Type.File_RTF:
                case Sub_Task_Type.File_XTG:
					//obtenir une copie du Template element
					__tBox = TElement_Helper.Get_TElement(Static_TElement_Name.RTF_DOC_XTG, task.DestinationBlocName) as TBox;
					__tBox.SrcBox.content.value	= string.Format(SourceFileDocPoolPattern, task.Document.FileFullPath);
					//if (task.Rotation_Image) __src_Element.SrcBox.picture.angle = "90";
					__blocBox			= new Bloc_Box(task, task.DestinationBlocName, __tBox);
                    break;
				case Sub_Task_Type.File_QXP_Data:
					Process_File_QXP_Data(task);
					break;
            }

			if(QXPFrk.Validation.IsNotNull(__blocBox))
			{
				task.Blocs_Modify.Add(__blocBox.Name, __blocBox);
			}
		}

		/// <summary>
		/// Traitement particulier li� � la r�cup�ration d'information d'ancien fichier qxp
		/// </summary>
		static void Process_File_QXP_Data(Task_Document task) 
		{ 
			//Il faut que l'information Source et Destination soit d�fini afin de pouvoir analyser les informations � transf�rer
			if(QXPFrk.Validation.IsSet(task.SourceBlocName) && QXPFrk.Validation.IsSet(task.DestinationBlocName))
			{ 
				Document __doc = task.Document;

				//V�rification s'il faut conserver les styles
				//Si c'est le cas il faut travailler sur le DOM (Project QXP) dans ce cas il faut lancer une analyse exhaustive du projet
				if(task.Conserver_Style) { 
					task.Document.QXPProject.Analyse(task, false);
				}
				
				string[] __listSourceBoxName		= null;
				string[] __listDestinationBoxName	= null;
			
				// Cr�er autant de blocs qu'il y a de noms dans la t�che.
				// Les noms de blocs �tant s�par� par '|'
				__listSourceBoxName			= task.SourceBlocName.Split(new char[] { '|' });
				__listDestinationBoxName	= task.DestinationBlocName.Split(new char[] { '|' });
				
				// TODO Gestion des erreurs, v�rifier si il y a autant de nom blocs dans la source et la destination
				for(int i = 0 ; i < __listSourceBoxName.Length ; i ++) 
				{
					string		__sourceName			= __listSourceBoxName[i];
					string		__destinationName		= __listDestinationBoxName[i];
					Bloc_Base	__bloc					= null;
					
					//2 cas on conserve les styles ou non
					// 1 - On conserve le style 
					if(task.Conserver_Style)
					{
						//Pour chacun des �l�ments rechercher on regarde dans les boites puis les tables puis les groupes
						if(__doc.QXPProject.Elements.ContainsKey(__sourceName))
						{
							TElement __tElement = __doc.QXPProject.Elements[__sourceName];
							if(__tElement is TBox)
							{
								TBox		__tBox		= __tElement as TBox;
								Bloc_Box	__blocBox	= new Bloc_Box(task, __destinationName, __tBox);
								__blocBox.Action		= Bloc_Action.UPDATE;
								task.Blocs_Modify.Add(__blocBox.Name, __blocBox);
								__bloc = __blocBox;
							
							}
							else if(__tElement is TTable)
							{
								TTable		__tTable = __tElement as TTable;
								Bloc_Table	__blocTable = new Bloc_Table(task, __destinationName, __tTable);
								__blocTable.Action = Bloc_Action.UPDATE;
								__bloc = __blocTable;
							
							}
							else if(__tElement is TGroup)
							{
								//Pas trait� pour le moment							
							}						
						}
						

						if(QXPFrk.Validation.IsNotNull(__bloc)) 
						{ 
							if (task.Blocs_Modify.ContainsKey(__bloc.Name))
							{
								task.Run.Errors.Add(Constantes.Error_Messages.BlocDupliquerDansTache, __bloc.Name, task.Debug_Info);
							}
							else
							{
								//il y aura alt�ration du document !!
								//m�me si ce n'est que des actions de type Update il faudra passer par un "QXPS_Modifier"
								task.Blocs_Modify.Add(__bloc.Name, __bloc);
							}
						}
					}
					// 1 - On ne prend que la valeur
					else
					{ 
						string		__bloc_Value	= __doc.XML.GetValue(__sourceName);
						Bloc_Box	__blocBox		= new Bloc_Box(task, __destinationName, __bloc_Value);
						__blocBox.Action = Bloc_Action.UPDATE;
						task.Blocs_Update.Add(__blocBox.Name, __blocBox);
					}
				}

			}
		
		}

		/// <summary>
		/// Traitement particulier li� au fichiers PDF
		/// </summary>
		static void Process_File_PDF(Task_Document task)
		{
			if(task.Document.PDFFiles.Count == 0) return;
			
			Bloc_Box				__blocBox;
            Bloc_Page				__blocPage;
			QXPFrk.BaseList<string>	__lstBoxName	= task.Run.Gabarit.XML.GetListBoxNameStartWith(task.DestinationBlocName);
			Document				__doc			= task.Document;
			string					__blocName;
			QXPIO.PDF_File			__file		= null;
			QXPSMSDK.Box		__box		= null;
			QXPSMSDK.Box		__extrabox	= null;

			//il ne peut pas y avoir 0 anciennes boites dans le documents.
			if (__lstBoxName.Count == 0)
			{
				task.Run.Errors.Add(Constantes.Error_Messages.MissingDestinationBlocNameInTask, task.DestinationBlocName, task.ID);
				return;
			}

			//Si ce nombre est n�gatif il a trop de boites, Si ce nombre est positif il manque des boites
			//Si ce nombre est �gal � 0 le nombre de boite d�j� pr�sent est correcte.
			int __nbPageManquante = (task.Document.PDFFiles.Count - __lstBoxName.Count);

			//permet d'�valuer les d�calage d'images � appliquer !!
			task.Image_Offset	= new Task_Image_Offset(task.Offset_Values);

			//permet d'�valuer la positin des nouveaux bloc image
			task.Image_Position =  new Task_Image_Position(task.Position_Values);
			
			int __nbPageMaxRequis = Math.Max(task.Document.PDFFiles.Count, __lstBoxName.Count);

			for(int __i = 0 ; __i < __nbPageMaxRequis; __i++)
			{
				//Si il y a plus de boites dans le document que dans la liste des pdfs il faut supprimer des boites
				if(__i < __lstBoxName.Count && __i >= task.Document.PDFFiles.Count)
				{
					//on doit supprimer des pages
					__blocName					= string.Format(PDFBlocNamePattern, task.DestinationBlocName, __i + 1);
					__blocPage					= new Bloc_Page(task, __blocName);
					__blocPage.Relative_Page	= __i;
					__blocPage.Action			= Bloc_Action.REMOVE; //Suppression d'une page
					task.Blocs_Modify.Add(__blocPage.Name, __blocPage);
				}
				else
				{
					__file						= __doc.PDFFiles[__i];
					__blocName					= string.Format("{0}_{1}", task.DestinationBlocName, __i + 1);

					TBox					__tBox;
					Static_TElement_Name	__tElementName;
					//Si c'est le premier bloc on prend un template sp�cifique
					if(__i == 0)
					{
						__tElementName = Static_TElement_Name.PDF_1;
					}
					else
					{
						__tElementName = Static_TElement_Name.PDF_N;
					}
					__tBox						= TElement_Helper.Get_TElement(__tElementName, __blocName) as TBox;
					__tBox.SrcBox.content.value = __doc.GetPDFFileAbsolutePath(__file);
					__blocBox					= new Bloc_Box(task, __blocName, __tBox);
					__blocBox.Relative_Page		= __i;

					__box						= __blocBox.SrcBox;
					__extrabox					= __blocBox.SrcExtraBox;

					if (__i > 0)
					{
						__box.geometry.position.left	= task.Image_Position.Left;
						__box.geometry.position.top		= task.Image_Position.Top;
						__box.geometry.position.right	= task.Image_Position.Right;
						__box.geometry.position.bottom	= task.Image_Position.Bottom;					
					}

					//Mise en place de la rotation de l'image pdf
					if(task.Rotation_Image)
					{
						//traitement de la rotation
						if(QXPFrk.Validation.IsNotNull(__tBox.SrcBox) && QXPFrk.Validation.IsNotNull(__tBox.SrcBox.picture))
						{
							__tBox.SrcBox.picture.angle				= PictureRotation90;
						}
						//traitement du d�calage
						if(QXPFrk.Validation.IsNotNull(__tBox.SrcExtraBox) && QXPFrk.Validation.IsNotNull(__tBox.SrcExtraBox.picture))
						{
                            __tBox.SrcExtraBox.picture.offsetAcross = task.Image_Offset.GetOffset(__i);
						}
					}
					else
					{
						//traitement du d�calage
						if(QXPFrk.Validation.IsNotNull(__tBox.SrcExtraBox) && QXPFrk.Validation.IsNotNull(__tBox.SrcExtraBox.picture))
						{
							//traitement du d�calage
                            __tBox.SrcExtraBox.picture.offsetDown = task.Image_Offset.GetOffset(__i);
						}
					}

					//Tant qu'il y a des boites sur l'ancien document on les mets � jour
					if(__i < __lstBoxName.Count)
					{
						__blocBox.Action			= Bloc_Action.UPDATE; 
					}
					//Sinon il faut les cr��s
					else
					{
						string __pageName = string.Format(PDFPageNamePattern, __i, __blocName);
						//Ajout de la page
						__blocPage					= new Bloc_Page(task, __pageName);
						__blocPage.Action			= Bloc_Action.CREATE;
						__blocPage.Relative_Page	= __i;
						task.Blocs_Modify.Add(__blocPage.Name, __blocPage);

						//ajout du bloc
						__blocBox.Action			= Bloc_Action.CREATE;	// Cr�ation d'un nouveau bloc
					}
					task.Blocs_Modify.Add(__blocBox.Name, __blocBox);

				}
			}
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
