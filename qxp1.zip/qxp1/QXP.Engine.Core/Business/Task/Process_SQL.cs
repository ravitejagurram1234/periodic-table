using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk		= QXP.Framework;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPAudit		= QXP.Audit;

namespace QXP.Engine.Core.Business
{
	/// <summary>
	/// Contient la partie business du processing d'une tache de type "Task_SQL"
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 17:50:15</date>    
	public class Process_SQL
	{
		#region Membres

		#endregion Membres

		#region Constantes
        private const string NAME_BLOC_COL			= "NOM_BLOC";
        private const string VALUE_BLOC_COL			= "VALEUR_BLOC";
        private const string N1_End_Bloc			= "N1";
        private const string DESCRIPTION_BLOC_COL	= "DESCRIPTION_BLOC"; //optionnelle
        private const string INFO_BLOC_COL			= "INFO_BLOC"; //optionnelle

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		#endregion Constructeur

		#region M?thodes
        /// <summary>
        /// Cr?ation des blocs
        /// </summary>
        /// <param name="task">la tache</param>
		public static void Process(Task_SQL task)
		{

			// Chargement des param?tres            
			QXPDataOracle.OraParameter[] __parameters = task.Run.InParams.CloneParameters();

			// Appel ? la couche proxy : r?cup?ration d'un reader
			try
			{

				Proxy_Generic __proxy = new Proxy_Generic();
				using(QXPDataOracle.OraDataReader __reader = __proxy.GetReader(task.SQL, __parameters))
				{
					// Ajout des blocs
					if(__reader.HasRows)
					{
						AddBlocs(task, __reader);
					}
					//pas de donn?e
					else
					{
						Trace_Helper.Log_Message(Constantes.Error_Messages.NoSQLDataForTask, task.ID);						
					}

				}
				Check_Task_Exception(task);
			}
			catch(Exception ex)
			{
				Exception_Helper.Raise_Exception(new Exception_Task(ex, Exception_Task.MSG_Execute_SQL, task.Debug_Info), Error_Type.Critique);
			}
		}
		/// <summary>
		/// Ajout d'une liste de bloc ? mettre ? jour
		/// </summary>
		/// <param name="task">la tache dans laquelle il faut ajouter les nouveaux blocs</param>
		/// <param name="reader">la source de donn?es permettant d'?valuer les nouveaux blocs</param>
        private static void AddBlocs(Task_SQL task, QXPDataOracle.OraDataReader reader)
        {
            Bloc_Box			__bloc;
            string				__bloc_Name;
			string				__bloc_Value;
			string				__bloc_Description	= string.Empty;
			string				__bloc_Info			= string.Empty;
            bool				__integrer_N1		= task.Run.Properties.Integrer_N1;
			Data_Type_Helper	__data_Type_Helper	= new Data_Type_Helper(task.Run.Properties);

			//Nous devons stocker les donn?es si le run et en mode store SQL et que la tache est en store_data
			bool				__store_Data				= task.Store_Data && ((task.Run.Properties.Store_Type & Store_Data_Type.SQL) == Store_Data_Type.SQL);
			bool				__include_Description_Bloc	= reader.Exist_Column(DESCRIPTION_BLOC_COL);
			bool				__include_Info_Bloc			= reader.Exist_Column(INFO_BLOC_COL);

            while (reader.Read())
            {
                __bloc_Name = string.Empty; //re-initialise le nom du bloc au cas ou il y ait une erreur sur le nom 
                try
                {
                    __bloc_Name = QXPFrk.Conversion.ToString(reader[NAME_BLOC_COL]);
                    // on ajoute tout les blocs si integrer N1 est true sinon ont test que le bloc ne se termine pas par le texte N1 
                    if(__integrer_N1 || !__bloc_Name.EndsWith(N1_End_Bloc))
					{
                        __bloc_Value	= __data_Type_Helper.OutputToString(reader[VALUE_BLOC_COL], task.Data_Type, task.NbDecimal, task.ShowZero, task.NullString, task.Decimal_Significative);
						__bloc          = new Bloc_Box(task, __bloc_Name, __bloc_Value);
                        __bloc.Action   = Bloc_Action.UPDATE;

						if (__include_Description_Bloc)
						{
							__bloc_Description = reader[DESCRIPTION_BLOC_COL];
						}

						if (__include_Info_Bloc)
						{
							__bloc_Info = reader[INFO_BLOC_COL];
						}

                        if(task.Blocs_Update.ContainsKey(__bloc_Name))
						{
                            task.Run.Errors.Add(Constantes.Error_Messages.ErrorDuplicateBlocInTask, task.Debug_Info, __bloc_Name);
                        }
						else
						{
                            task.Blocs_Update.Add(__bloc.Name, __bloc);
							
							if (__store_Data)
							{
								task.DataNamesValues.Add(__bloc_Name, __bloc_Value, __bloc_Description, __bloc_Info);
							}
                        }
                    }
                }
                catch
                {
                    task.Run.Errors.Add(Constantes.Error_Messages.ErrorAddingBlocSQLInTask, task.Debug_Info, __bloc_Name);
                }
            }
        }

		/// <summary>
		/// Permet de v?rifier si des exceptions s'appliquent sur cette tache
		/// </summary>
		/// <param name="task"></param>
		private static void Check_Task_Exception(Task_SQL task)
		{
			if (task.Exceptions.Count == 0) return;
            
			Bloc_Table	__blocTable			= null;
            Bloc_Ligne	__blocLigne			= null;
            bool		__processRemove		= false;
			string		__last_destination	= string.Empty;
            
			//On v?rifie les Exceptions si une est v?rifi?e alors on supprime la/les ligne(s) ou tableau correspondant !
            foreach (Task_Exception __exception in task.Exceptions.Values)
            {
                if (task.Blocs_Update.ContainsKey(__exception.Name))
                {
                    // ? l'int?rieur d'une tache SQL il ne peux y avoir que des blocs Box
                    // ont recherche le bloc ? tester
                    Bloc_Box __bloc = task.Blocs_Update[__exception.Name] as Bloc_Box;
                    __processRemove = QXPFrk.Validation.IsNotSet(__bloc.Value) || (__bloc.Value == task.NullString);
                }
                else
                {
                    __processRemove = true;
                }
                
				//Si aucune valeur dans le bloc ou bloc non trouv? alors il doit y avoir suppression de lignes ou de bloc
                if (__processRemove)
                {
					//On v?rifie que le bloc ? supprimer existe
					if (!task.Run.Gabarit.XML.Exist_Name(__exception.Name))
                    {
                        task.Run.Errors.Add(new Error(Constantes.Error_Messages.InvalidCondBloc, __exception.Name, task.ID));
                        continue;
                    }

					//on v?rifie que la table que l'ont va supprimer ou dans laquel il y ? des lignes ? supprimer existe
					if (task.Run.Gabarit.XML.Exist_Name(__exception.TableName))
					{
						if (__exception.Type == Task_Exception_Type.LINE)
						{
							//Il faut d?terminer le plus grand num?ro de ligne dans la tache exception
							int __maxLigne = 0;
							foreach (int __ligne in __exception.IndexLignes)
							{
								__maxLigne = Math.Max(__maxLigne, __ligne);
							}

							//on v?rifie que le tableau correspond poss?de au moins la ligne max ? supprimer
							if (task.Run.Gabarit.XML.GetNbLignes(__exception.TableName) >= __maxLigne)
							{
								foreach (int __idx in __exception.IndexLignes)
								{
									string __ligne_id = string.Concat(__exception.TableName, "_", __idx);
									if (!task.Blocs_Modify.ContainsKey(__ligne_id))
									{
										__blocLigne = new Bloc_Ligne(task, __ligne_id, __exception.TableName, __idx);
										__blocLigne.CondName = __exception.TableName;
										__blocLigne.Action = Bloc_Action.REMOVE;
										task.Blocs_Modify.Add(__ligne_id, __blocLigne);
										//Permet de conserver la derni?re destination des exception permettra d'?valuer la page plus tard
										__last_destination = __exception.TableName;
									}
								}
							}
							else
							{
								task.Run.Errors.Add(new Error(Constantes.Error_Messages.MissingTableRows, __exception.TableName, __exception.Name));
							}
						}
						else
						{
							if (!task.Blocs_Modify.ContainsKey(__exception.TableName))
							{
								__blocTable				= new Bloc_Table(task, __exception.TableName);
								__blocTable.CondName	= __exception.TableName;
								__blocTable.Action		= Bloc_Action.REMOVE;
								task.Blocs_Modify.Add(__blocTable.Name, __blocTable);
								//Permet de conserver la derni?re destination des exception permettra d'?valuer la page plus tard
								__last_destination = __exception.TableName;
							}
						}
					}
					else
					{
                        task.Run.Errors.Add(new Error(Constantes.Error_Messages.TableNotExist, __exception.TableName));
					}
                }
            }
			if (QXPFrk.Validation.IsSet(__last_destination))
			{
				//Voir si ont peut virer ?a !!
				task.DestinationBlocName = __last_destination;
			}
		}

		#endregion M?thodes

		#region Propri?t?s

		#endregion Propri?t?s
	}
}
