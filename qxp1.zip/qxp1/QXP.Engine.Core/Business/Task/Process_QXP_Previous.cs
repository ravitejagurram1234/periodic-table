using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk		= QXP.Framework;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPAudit		= QXP.Audit;

using QXPSMSDK	= com.quark.qxpsm;

namespace QXP.Engine.Core.Business
{
	/// <summary>
	/// Contient la partie business du processing d'une tache de type "Task_QXP_Previous"
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 17:50:15</date>    
	public class Process_QXP_Previous
	{
		#region Membres

		#endregion Membres

		#region Constantes
        private const string BlocNSuffix                = ".N";       
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		#endregion Constructeur

		#region M�thodes
        /// <summary>
        /// Cr�ation des blocs
        /// </summary>
        /// <param name="task">la tache</param>
		public static void Process(Task_QXP_Previous task)
		{

            if (QXPFrk.Validation.IsNotNull(task.Document))
            {
                if (QXPFrk.Validation.IsSet(task.SourceBlocName) && QXPFrk.Validation.IsSet(task.DestinationBlocName))
                {
					// Mettre � jour autant de blocs qu'il y a de noms dans la t�che.
					// Les noms de blocs �tant s�par� par '|'
					string[] __listSourceBoxName		= task.SourceBlocName.Split('|');

					//on en profite pour r�cup�rer une �ventuelle position_blocName sp�cifique (utile pour les Telement de Type Table
					//il est possible d'encoder dans la destination une destination autre que le DestinationBlocName en ajoutant dans le champs destination X�Y
					//ou X repr�sente l'�l�ment destination et Y l'�l�ment permettant de d�finir le spreadID et le layout
					//Tout ces complications car la m�thode deconstruct ne permet pas d'obtenir le spreadid et le layout d'un table nomm�e :((
					string[] __listPositionBoxName		= task.DestinationBlocName.Split('�');
					
					string[] __listDestinationBoxName;

					//il y � bien une position
					if (__listPositionBoxName.Length == 2)
					{
						__listDestinationBoxName	= __listPositionBoxName[0].Split('|');
						task.Position_BlocName		= __listPositionBoxName[1];
					}
					//il n'y � pas de position d�finie
					else
					{
						__listDestinationBoxName	= task.DestinationBlocName.Split('|');
					}
					
					if(__listSourceBoxName.Length != __listDestinationBoxName.Length){
						task.Run.Errors.Add(Constantes.Error_Messages.Invalid_List_Count, __listSourceBoxName.Length, __listDestinationBoxName.Length);
					}


					//S'il faut conserver les styles on analyse le document QXP
					if(task.Conserver_Style)
					{
						task.Document.QXPProject.Analyse(task, false);
					}

					//ajout des bloc
					AddBlocs(task, __listSourceBoxName, __listDestinationBoxName);
					
                    
                }
                // sinon on prend les noms finissant par le suffixe BlocNSuffix (exemple N1)
                else
                {
                    SortedDictionary<int, QXPFrk.BaseList<string>>	__boxesSourcesNamesByLevels = new SortedDictionary<int, QXPFrk.BaseList<string>>();
                    QXPFrk.BaseList<string>							__boxesSourcesNames			= new QXPFrk.BaseList<string>();
                    bool											__endProcess				= false;
                    int i = 0;
                    while (!__endProcess)
                    {
                        // get the blocs for the level i
                        __boxesSourcesNames = task.Document.XML.GetListBoxNameEndWith(BlocNSuffix + i.ToString());
                        if (QXPFrk.Validation.IsNotNull(__boxesSourcesNames) && __boxesSourcesNames.Count > 0)
                        {
                            __boxesSourcesNamesByLevels.Add(i, __boxesSourcesNames);
                        }
                        else
                        {
                            // End the process when no source bloc is found for the level i >> no use to check greater level
                            __endProcess = true;
                        }

                        // loop on the next level
                        i++;
                    }

                    // calcul les blocs � partir de la hierarchie des blocs sources et ajout � la tache
                    if (QXPFrk.Validation.IsNotNull(__boxesSourcesNamesByLevels) && __boxesSourcesNamesByLevels.Count > 0)
                    {
                        AddBlocs(task, __boxesSourcesNamesByLevels);
                    }
                }
            }            
		}

        /// <summary>
        /// Ajoute � la tache donn�e les blocs calcul� � partir de la hierarchie de bloc sources pass� en param�tre
        /// </summary>
        /// <param name="task">tache � renseigner</param>
        /// <param name="boxesSourcesNamesByLevels">hierarchie de bloc source tri� par level croissant</param>
        private static void AddBlocs(Task_QXP_Previous task, SortedDictionary<int, QXPFrk.BaseList<string>> boxesSourcesNamesByLevels)
        {
            Bloc_Box	__bloc;
            string		__destBoxName; // nom du bloc de destination
            QXP_XML		__xmlPreviousQxp = task.Document.XML;       

            // pour chaque niveau de bloc 
            foreach(KeyValuePair<int,QXPFrk.BaseList<string>> __levelSourceBoxName in boxesSourcesNamesByLevels)
            {
                // pour chaque bloc source du niveau 
                foreach (string __sourceBoxName in __levelSourceBoxName.Value)
                {
                    // on calcule le nom du bloc de destination
                    __destBoxName = string.Concat(__sourceBoxName.Substring(0, __sourceBoxName.Length - 3), BlocNSuffix, (__levelSourceBoxName.Key+ 1).ToString());

                    try
                    {                        
                        if (task.Blocs_Update.ContainsKey(__destBoxName))
                        {
                            // si le bloc de destination est deja pr�sent dans la tache >> erreur 
                            task.Run.Errors.Add(Constantes.Error_Messages.ErrorDuplicateBlocInTask, task.Debug_Info, __destBoxName);
                        }
                        else
                        {
                            string __value = __xmlPreviousQxp.GetValue(__sourceBoxName);
                            // Quark ne g�re pas les chaines vides, cela provoque une erreur
                            // au moment de la sauvegarde du fichier final. On doit les remplacer par
                            // le NullString d�fini --> par d�faut : " "
                            if (QXPFrk.Validation.IsNotSet(__value))
                            {
                                __value = task.NullString;
                            }
                            // on cr�e le bloc de destination � partir de la valeur de la boite source 
                            __bloc = new Bloc_Box(task, __destBoxName, __value);
                            __bloc.Action	= Bloc_Action.UPDATE;
                            task.Blocs_Update.Add(__destBoxName, __bloc);
                        }
                    }
                    catch
                    {
                        task.Run.Errors.Add(Constantes.Error_Messages.ErrorAddingBlocInTask, task.Debug_Info, __sourceBoxName, __destBoxName);
                    }
                }
            }            
        }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="task"></param>
		/// <param name="listSourceBoxName"></param>
		/// <param name="listDestinationBoxName"></param>
		private static void AddBlocs(Task_QXP_Previous task, string[] listSourceBoxName, string[] listDestinationBoxName)
		{
			string		__sourceBoxName;
			string		__destBoxName;
			Bloc_Box	__bloc		= null;

			for(int __i=0; __i < listSourceBoxName.Length;__i++)
			{
                __sourceBoxName	=  listSourceBoxName[__i];
				__destBoxName	=  listDestinationBoxName[__i];
				
                if (task.Blocs_Update.ContainsKey(__destBoxName) || task.Blocs_Modify.ContainsKey(__destBoxName))
                {
                    // si le bloc de destination est deja pr�sent dans la tache >> erreur 
                    task.Run.Errors.Add(Constantes.Error_Messages.ErrorDuplicateBlocInTask, task.Debug_Info, __destBoxName);
                }
                else
                {
					//on r�cup�re la valeur et le style
					if(task.Conserver_Style)
					{
						//L'�l�ment source existe bien
						if (task.Document.QXPProject.Elements.ContainsKey(__sourceBoxName))
						{
							TElement __tElement = task.Document.QXPProject.Elements[__sourceBoxName];

							if (__tElement is TBox)
							{
								AddBloc(task, (TBox)__tElement, __destBoxName);
							}
							else if (__tElement is TTable)
							{
								AddBloc(task, (TTable)__tElement, __destBoxName);
							}
							else
							{
								task.Run.Errors.Add(Constantes.Error_Messages.Invalid_TElement_Type, __sourceBoxName, task.Debug_Info);
							}
						}
						else
						{
							task.Run.Errors.Add(Constantes.Error_Messages.Missing_TElement, __sourceBoxName, task.Debug_Info);
						}
					}
					//on r�cup�re la valeur
					else
					{
						// on cr�e le bloc de destination � partir de la valeur de la boite source 
						__bloc			= new Bloc_Box(task, __destBoxName, task.Document.XML.GetValue(__sourceBoxName));
						__bloc.Action	= Bloc_Action.UPDATE;
						task.Blocs_Update.Add(__destBoxName, __bloc);
					}
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="task"></param>
		/// <param name="tBox"></param>
		/// <param name="newName"></param>
		static void AddBloc(Task_QXP_Previous task, TBox tBox, string newName)
		{
		    //Pr�paration de la boite destination � partir de la boite source
		    Bloc_Box	__bloc		= new Bloc_Box(task, newName, TElement_Helper.Get_New_TBox_StyleValue_From_TBox(tBox, newName));
		    __bloc.Action	= Bloc_Action.UPDATE;
		    task.Blocs_Modify.Add(newName, __bloc);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="task"></param>
		/// <param name="tTable"></param>
		/// <param name="newName"></param>
		static void AddBloc(Task_QXP_Previous task, TTable tTable, string newName)
		{
		    //Pr�paration de la boite destination � partir de la boite source
		    Bloc_Table __bloc	= new Bloc_Table(task, newName, TElement_Helper.Get_New_TTable_StyleValue_From_TTable(tTable, newName));
		    __bloc.Action	= Bloc_Action.UPDATE;
		    task.Blocs_Modify.Add(newName, __bloc);
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
