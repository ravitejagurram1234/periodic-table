using System;
using System.Data;
using System.Text;
using System.Collections.Generic;

using Oracle.DataAccess.Client;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPProxy = QXP.Framework.Proxy;
using QXPAPPlication = QXP.Framework.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Proxy permettant le chargement des InParams utilis?s dans les runs
	/// </summary>
	/// <author>doufarm</author>
	/// <date>24/03/2010 15:32:19</date>    
	public class Proxy_Param : QXPProxy.BaseProxy
	{
		#region Membres

		#endregion Membres

		#region Constantes

		private const string PACKAGE = "QXP_PK_RUN.";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr?e une instance de Proxy_Param
		/// </summary>
		public Proxy_Param()
		{
		}

		/// <summary>
		/// Cr?e une instance de Proxy_Param
		/// </summary>
		/// <param name="oraClient">Connexion Oracle</param>
		public Proxy_Param(QXPDataOracle.OraClient oraClient)
			: base(oraClient)
		{
		}

		/// <summary>
		/// Cr?e une instance de Proxy_Param
		/// </summary>
		/// <param name="dataBase">Nom de la cl? DataBase situ? dans le fichier .config de l'application (associ?e ? une chaine de connexion)</param>
		public Proxy_Param(string dataBase)
			: base(dataBase)
		{
		}

		#endregion Constructeur

		#region M?thodes

		#region Acc?s Base

		#region SELECT

		
		/// <summary>
		/// Chargement des InParams associ? au run par le suivi
		/// </summary>
		/// <param name="run">le run sur lequel il faut charger les InParams</param>
		public void Load_In_Params(Run run)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			InParam							__inParam;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_suivi", run.Properties.ID_Suivi);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_In_Params");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
				run.InParams.Clear(); // au cas ou !
            	while (__odr.Read())
            	{
            		__inParam = new InParam(__odr["nom_parametre"]
											, (int) __odr["input_data_type"]
											, __odr["valeur"]);

            		run.InParams.Add(__inParam.Name, __inParam);

            	}				
			}
		}
			

		#endregion SELECT

		#region INSERT / UPDATE / DELETE

		/*
         * Utiliser ici les QXPSnippet Proxy pour g?n?rer automatiquement un squelette de code pour les acc?s INSERT / UPDATE / DELETE ? la base de donn?es
         */

		#endregion INSERT / UPDATE / DELETE

		#endregion Acc?s Base

		#endregion M?thodes

		#region Propri?t?s

		#endregion Propri?t?s
	}
}
