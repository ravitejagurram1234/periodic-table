using System;
using System.Data;
using System.Text;
using System.Collections.Generic;

using Oracle.DataAccess.Client;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPProxy = QXP.Framework.Proxy;
using QXPAPPlication = QXP.Framework.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Proxy de l'audit d'un run
	/// </summary>
	/// <author>doufarm</author>
	/// <date>24/03/2010 10:47:10</date>    
	public class Proxy_Audit : QXPProxy.BaseProxy
	{
		#region Membres

		#endregion Membres

		#region Constantes

		private const string PACKAGE = "QXP_PK_AUDIT.";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Proxy_Audit
		/// </summary>
		public Proxy_Audit()
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Audit
		/// </summary>
		/// <param name="oraClient">Connexion Oracle</param>
		public Proxy_Audit(QXPDataOracle.OraClient oraClient)
			: base(oraClient)
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Audit
		/// </summary>
		/// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
		public Proxy_Audit(string dataBase)
			: base(dataBase)
		{
		}

		#endregion Constructeur

		#region M�thodes

		#region Acc�s Base

		#region SELECT

		#endregion SELECT

		#region INSERT / UPDATE / DELETE

		
		/// <summary>
		/// Insert un audit d'un run en base de donn�es
		/// </summary>
		/// <param name="audit">Objet de type object</param>
		public void InsertAuditRun(Audit audit)
		{

			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("p_id_run", audit.Run.ID)
							.AddParameterToSqlParamList("p_id_suivi", audit.Run.Properties.ID_Suivi)
							.AddParameterToSqlParamList("p_run_type", audit.Run.Properties.RunType)
							.AddParameterToSqlParamList("p_start_date", audit.StartDate)
							.AddParameterToSqlParamList("p_end_date", audit.EndDate)
							.AddParameterToSqlParamList("p_duration", audit.Duration)
							.AddParameterToSqlParamList("p_end_status", audit.EndStatus.ToString())
							.AddParameterToSqlParamList("p_message", audit.Message);


			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "InsertAuditRun");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			try
			{
				
				this.Execute(__sqlRequest);

			}
			catch (Exception ex)
			{
				QXPDiagnostic.Log.LogError("Erreur lors de l'insertion de l'audit : ", ex);
				throw;
			}
		}		
			

		#endregion INSERT / UPDATE / DELETE

		#endregion Acc�s Base

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
