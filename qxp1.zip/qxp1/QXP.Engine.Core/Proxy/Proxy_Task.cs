using System;
using System.Data;
using System.Text;
using System.Collections.Generic;

using Oracle.DataAccess.Client;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPProxy = QXP.Framework.Proxy;
using QXPAPPlication = QXP.Framework.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Proxy permettant le chargement des InParams utilis?s dans les runs
	/// </summary>
	/// <author>doufarm</author>
	/// <date>24/03/2010 15:32:19</date>    
	public class Proxy_Task : QXPProxy.BaseProxy
	{
		#region Membres

		#endregion Membres

		#region Constantes

		private const string PACKAGE		= "QXP_PK_RUN.";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr?e une instance de Proxy_Task
		/// </summary>
		public Proxy_Task()
		{
		}

		/// <summary>
		/// Cr?e une instance de Proxy_Task
		/// </summary>
		/// <param name="oraClient">Connexion Oracle</param>
		public Proxy_Task(QXPDataOracle.OraClient oraClient)
			: base(oraClient)
		{
		}

		/// <summary>
		/// Cr?e une instance de Proxy_Task
		/// </summary>
		/// <param name="dataBase">Nom de la cl? DataBase situ? dans le fichier .config de l'application (associ?e ? une chaine de connexion)</param>
		public Proxy_Task(string dataBase)
			: base(dataBase)
		{
		}

		#endregion Constructeur

		#region M?thodes

		#region Acc?s Base

		#region SELECT

		
		/// <summary>
		/// Chargement des taches associ? au run par le suivi
		/// </summary>
		/// <param name="run">le run sur lequel il faut charger les taches</param>
		public void Load_Task(Run run)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			Task_Base						__task			= null;
			int								__id_run		= run.ID;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_run", __id_run);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Taches");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
				run.Tasks.Clear(); // au cas ou !
            	while (__odr.Read())
            	{
            		__task = Get_Task(__odr, run);

					if(QXPFrk.Validation.IsNotNull(__task))
					{
						run.Tasks.Add(__task.ID, __task);
					}
            	}				
			}
			
			try
			{
				this.LoadTaskExceptions(run);
			}
			catch(Exception ex)
			{
				Exception_Run __exception = new Exception_Run(ex, Exception_Run.MSG_Load_Run_Tasks_Exceptions);
				Exception_Helper.Raise_Exception(__exception, Error_Type.Bloquante);
			}
		}

		/// <summary>
		/// Chargement des ?ventuelles taches exceptions associ?s ? la tache
		/// </summary>
		/// <param name="run">le run sur lequel il faut charger les taches</param>
		public void LoadTaskExceptions(Run run)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			
			Task_Base						__task					= null;
            int								__id_Tache				= int.MinValue;
            string							__nom_Bloc				= string.Empty;
            string							__nom_Table				= string.Empty;
            int[]							__index_Lignes			= new int[0];
            Task_Exception_Type				__task_Exception_Type   = Task_Exception_Type.NONE;
            Task_Exception					__task_Exception		= null;
			int								__id_run				= run.ID;


			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_run", __id_run);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Run_Taches_Exceptions");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
            	while (__odr.Read())
            	{
            		__id_Tache = __odr["ID_TACHE"];
            		__nom_Bloc = __odr["NOM_BLOC"];

            		//Petit mise en cache local de la derni?re tache utilis?e
					if (QXPFrk.Validation.IsNull(__task) || __task.ID != __id_Tache)
            		{
            			//Il est possible que des taches exception soit associ?s ? une tache qui n'a pu ?tre charg?e dans le run donc on consigne l'erreur !
            			if (run.Tasks.ContainsKey(__id_Tache))
            			{
            				__task = run.Tasks[__id_Tache];
            			}
            			else
            			{
            				__task = null;
            				run.Errors.Add(Constantes.Error_Messages.TaskNullInBlocException, __id_Tache, __id_run, __nom_Bloc);
            				continue;
            			}
            		}
            		string __str_index_lignes = __odr["INDEX_LIGNES"];
            		__index_Lignes = new int[0];
            		if (QXPFrk.Validation.IsSet(__str_index_lignes))
            		{
            			__index_Lignes = QXPFrk.Conversion.ToIntArray(__str_index_lignes.Split('|'));
            		}
            		__nom_Table = __odr["NOM_TABLEAU"];
            		if (QXPFrk.Validation.IsSet(__index_Lignes))
            		{
            			__task_Exception_Type = Task_Exception_Type.LINE;
            		}
            		else
            		{
            			__task_Exception_Type = Task_Exception_Type.TABLE;
            		}
            		__task_Exception = new Task_Exception(__nom_Table, __nom_Bloc, __index_Lignes, __task_Exception_Type);
            		if (__task.Exceptions.ContainsKey(__nom_Bloc))
            		{
            			run.Errors.Add(Constantes.Error_Messages.DuplicateBlocException, __nom_Bloc, __task.Debug_Info, __id_run);
            		}
            		else
            		{
            			__task.Exceptions.Add(__nom_Bloc, __task_Exception);
            		}
            	}				
			}
			
		}

		/// <summary>
		/// Chargement des taches en fonction du type de tache.
		/// </summary>
		/// <param name="reader">la source de donn?es contenant les information sur la nouvelle tache</param>
		/// <returns>La nouvelle tache</returns>
		private Task_Base Get_Task(QXPDataOracle.OraDataReader reader, Run run)
		{
			Task_Base			__task_Base = null;
			int __id_Tache		= reader["ID_TACHE"];
			int __id_Type_Tache = reader["ID_TYPE_TACHE"]; //(exemple 1=SQL / 2=Doc EOS / 3=Bloc QXP)

			Task_Type __task_Type = QXPFrk.Conversion.ToEnum<Task_Type>(__id_Type_Tache);
			//On cr?? le bon objet en fonction du type de tache
			switch(__task_Type) 
			{ 
				case Task_Type.SQL:
					Task_SQL				__task_SQL		= new Task_SQL(__id_Tache, run);
					this.Load_Task(reader, __task_SQL);
					__task_Base = __task_SQL;
					break;
				case Task_Type.DOC_EOS:
					Task_Document			__task_DOC_EOS	= new Task_Document(__id_Tache, run);
					this.Load_Task(reader, __task_DOC_EOS);
					__task_Base = __task_DOC_EOS;
					break;
				case Task_Type.DOC_QXP:
					Task_QXP_Previous		__task_DOC_QXP	= new Task_QXP_Previous(__id_Tache, run);
					this.Load_Task(reader, __task_DOC_QXP);
					__task_Base = __task_DOC_QXP;
					break;
				case Task_Type.SQL_DYNAMIQUE:
					Task_Dynamique			__task_Dynamique	= new Task_Dynamique(__id_Tache, run);
					this.Load_Task(reader, __task_Dynamique);
					__task_Base = __task_Dynamique;
					break;
				case Task_Type.COMPARTIMENTS:
					Task_Compartiment		__task_Compartiment	= new Task_Compartiment(__id_Tache, run);
					this.Load_Task(reader, __task_Compartiment);
					__task_Base = __task_Compartiment;
					break;
			}
			if(QXPFrk.Validation.IsNotNull(__task_Base))
			{
				//chargement des propri?t?s communes ? tous les types de taches
				Load_Task(reader, __task_Base);
			}

			return __task_Base;
				
		}

		/// <summary>
		/// Permet le chargement des informations communes ? tous les types de tache
		/// </summary>
		/// <param name="reader">la source de donn?es contenant les information sur la nouvelle tache</param>
		/// <param name="task">la tache sql</param>
		private void Load_Task(QXPDataOracle.OraDataReader reader, Task_Base task)
		{
			
			string __nullString = reader["CHAMPS_VIDE"];
			if(QXPFrk.Validation.IsSet(__nullString)) task.NullString = __nullString;
			task.Todo			= reader["TODO"];
			task.Commentaire	= reader["COMMENTAIRE"];
		}

		/// <summary>
		/// Permet le chargement des informations sp?cifiques au tache SQL
		/// </summary>
		/// <param name="reader">la source de donn?es contenant les information sur la nouvelle tache</param>
		/// <param name="task">la tache sql</param>
		private void Load_Task(QXPDataOracle.OraDataReader reader, Task_SQL task)
		{
			
			task.SQL					= reader["SQL"];
			task.ShowZero				= reader["AFFICHER_ZERO"];
			task.NbDecimal				= reader["NB_DECIMAL"];
			task.Decimal_Significative	= reader["DECIMAL_SIGNIFICATIVE"];
			int __id_data_type = reader["OUTPUT_DATA_TYPE"];
			try
			{
			    task.Data_Type = (Data_Type) __id_data_type;
			}
			catch (Exception)
			{
				task.Run.Errors.Add(Constantes.Error_Messages.Invalid_Data_Type, __id_data_type, task.Debug_Info);
			}
			task.Store_Data				= reader["STORE_DATA"];
		}

		/// <summary>
		/// Permet le chargement des informations sp?cifiques au tache SQL dynamique
		/// </summary>
		/// <param name="reader">la source de donn?es contenant les information sur la nouvelle tache</param>
		/// <param name="task">la tache sql</param>
		private void Load_Task(QXPDataOracle.OraDataReader reader, Task_Dynamique task)
		{
			
			task.SQL					= reader["SQL"];
			//Repr?sente l'identifiant des ancres (d?but et fin)
			//Les blocs dynamiques seront ajout? entre ces 2 ancres.
			task.DestinationBlocName	= reader["BLOC_DESTINATION"];
			task.Control_Overflow		= reader["CONTROL_OVERFLOW"];
			task.New_Page_Table			= reader["NEW_PAGE_TABLE"];
			task.Nb_Column				= reader["NB_COLUMN"];
			task.Column_Space			= reader["COLUMN_SPACE"];
			string __code_master_Page	= reader["CODE_MASTER_PAGE"];
			if(QXPFrk.Validation.IsSet(__code_master_Page))
			{
				task.Master_Page			= new DMaster_Page(__code_master_Page);
			}
			else
			{
				task.Master_Page			= DMaster_Page.Default;
			}
			string __page_Break_Rules	= reader["PAGE_BREAK_RULES"];
			if(QXPFrk.Validation.IsSet(__page_Break_Rules))
			{
				task.Page_Break_Rules			= new D_Break_Rules(__page_Break_Rules);
			}
			else
			{
				task.Page_Break_Rules			= D_Break_Rules.Default;
			}

			string __column_Break_Rules	= reader["COLUMN_BREAK_RULES"];
			if(QXPFrk.Validation.IsSet(__column_Break_Rules))
			{
			    task.Column_Break_Rules			= new D_Break_Rules(__column_Break_Rules);
			}
			else
			{
			    task.Column_Break_Rules			= D_Break_Rules.Default;
			}

			task.Store_Data						= reader["STORE_DATA"];
		}
		/// <summary>
		/// Permet le chargement des informations sp?cifiques au tache Document EOS
		/// </summary>
		/// <param name="reader">la source de donn?es contenant les information sur la nouvelle tache</param>
		/// <param name="task">la tache document</param>
		private void Load_Task(QXPDataOracle.OraDataReader reader, Task_Document task)
		{
			
			task.Format_Document		= reader["FORMAT"];
			task.Rotation_Image			= reader["ROTATION_IMAGE"];
			task.Id_Sous_Categorie		= reader["ID_SOUS_CATEGORIE"];
			task.Offset_Values			= reader["CROP_IMAGE_VALUES"];
			task.Conserver_Style		= reader["CONSERVER_STYLE"];
			task.SourceBlocName			= reader["BLOC_SOURCE"];
			task.DestinationBlocName	= reader["BLOC_DESTINATION"];
			task.Position_Values		= reader["POSITION_IMAGE"];

		}

		/// <summary>
		/// Permet le chargement des informations sp?cifiques au tache Document QXP
		/// </summary>
		/// <param name="reader">la source de donn?es contenant les information sur la nouvelle tache</param>
		/// <param name="task">la tache document</param>
		private void Load_Task(QXPDataOracle.OraDataReader reader, Task_QXP_Previous task)
		{
			task.Conserver_Style		= reader["CONSERVER_STYLE"];
			task.Previous_Type_Rapport	= reader["PREVIOUS_TYPE_RAPPORT"];
			
			task.SourceBlocName			= reader["BLOC_SOURCE"];
			task.DestinationBlocName	= reader["BLOC_DESTINATION"];
		}

		/// <summary>
		/// Permet le chargement des informations sp?cifiques aux taches Compartiments
		/// </summary>
		/// <param name="reader">la source de donn?es contenant les information sur la nouvelle tache</param>
		/// <param name="task">la tache compartiment</param>
		private void Load_Task(QXPDataOracle.OraDataReader reader, Task_Compartiment task)
		{
			//Repr?sente l'identifiant des ancres (d?but et fin)
			//Les blocs dynamiques seront ajout? entre ces 2 ancres.
			task.DestinationBlocName	= reader["BLOC_DESTINATION"];
			string __code_master_Page	= reader["CODE_MASTER_PAGE"];
			if(QXPFrk.Validation.IsSet(__code_master_Page))
			{
				task.Master_Page			= new DMaster_Page(__code_master_Page);
			}
			else
			{
				task.Master_Page			= DMaster_Page.Default;
			}
			
			//identifiant du gabarit fils li?e ? cette tache
			task.ID_Gabarit_Fils = reader["id_gabarit_fils"];
		}

		#endregion SELECT

		#region INSERT / UPDATE / DELETE

		/*
         * Utiliser ici les QXPSnippet Proxy pour g?n?rer automatiquement un squelette de code pour les acc?s INSERT / UPDATE / DELETE ? la base de donn?es
         */

		#endregion INSERT / UPDATE / DELETE

		#endregion Acc?s Base

		#endregion M?thodes

		#region Propri?t?s

		#endregion Propri?t?s
	}
}
