using System;
using System.Data;
using System.Text;
using System.Collections.Generic;

using Oracle.DataAccess.Client;

using QXPFrk			= QXP.Framework;
using QXPAudit			= QXP.Audit;
using QXPDataOracle		= QXP.Framework.Data.Oracle;
using QXPProxy			= QXP.Framework.Proxy;
using QXPAPPlication	= QXP.Framework.Application;
using QXPDiagnostic		= QXP.Framework.Diagnostic;

/* 
 * Code g�n�r� avec le template : QXPProxyClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Proxy Premettant le chargement des gabarits templates et des templates
	/// </summary>
	/// <author>doufarm</author>
	/// <date>27/04/2010 14:41:18</date>    
	public class Proxy_Template : QXPProxy.BaseProxy
	{
		#region Membres

		#endregion Membres

		#region Constantes

		private const string PACKAGE = "QXP_PK_TEMPLATE.";


		private const string COL_GABARIT_TEMPLATE_ID		= "ID_GABARIT_TEMPLATE";
		private const string COL_GABARIT_TEMPLATE_NOM		= "NOM";
		private const string COL_GABARIT_TEMPLATE_CONTENU	= "CONTENU";

		private const string COL_TEMPLATE_NOM				= "NOM";
		private const string COL_TEMPLATE_SRC_NOM			= "SRC_NOM";
		private const string COL_TEMPLATE_SRC_NOM_OVERFLOW	= "SRC_NOM_OVERFLOW";
		private const string COL_TEMPLATE_ABSOLUTE			= "ABSOLUTE";
		private const string COL_TEMPLATE_LEFT				= "LEFT";
		private const string COL_TEMPLATE_TOP				= "TOP";
		private const string COL_TEMPLATE_WIDTH				= "WIDTH";
		private const string COL_TEMPLATE_HEIGHT			= "HEIGHT";
		private const string COL_TEMPLATE_ABSOLUTE_REPEAT	= "ABSOLUTE_REPEAT";
		private const string COL_PAGE_BREAK					= "PAGE_BREAK";
		private const string COL_COLUMN_BREAK				= "COLUMN_BREAK";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Proxy_Template
		/// </summary>
		public Proxy_Template()
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Template
		/// </summary>
		/// <param name="oraClient">Connexion Oracle</param>
		public Proxy_Template(QXPDataOracle.OraClient oraClient)
			: base(oraClient)
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Template
		/// </summary>
		/// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
		public Proxy_Template(string dataBase)
			: base(dataBase)
		{
		}

		#endregion Constructeur

		#region M�thodes

		#region Acc�s Base

		#region SELECT

		/// <summary>
		/// Retourne un document de type gabarit template du run en cours
		/// </summary>
		/// <param name="run">le run en cours</param>
		/// <returns>un document de type gabarit template</returns>
		public Document Get_Gabarit_Template(Run run)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters		= new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest		= null;
			string							__sql				= string.Empty;
			Document						__gabarit_Template	= null;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_gabarit_template", run.Properties.ID_Gabarit_Template);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Gabarit_Template");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
				if (__odr.Read())
				{
					__gabarit_Template = new Document(__odr[COL_GABARIT_TEMPLATE_ID]
											, __odr[COL_GABARIT_TEMPLATE_NOM]
											, Constantes.Document_Format.QXP
											, Document.FileGabaritTemplatePrefix
											, __odr[COL_GABARIT_TEMPLATE_CONTENU]);
    				__gabarit_Template.ID_Langue = run.Properties.ID_Langue;
				}
			}

			return __gabarit_Template;
		}

		
		/// <summary>
		/// Permet de charger les templates associ�s au run en cours dans celui ci
		/// </summary>
		/// <param name="run">le run en cours</param>
		public void Load_Templates(Run run)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			decimal							__value			= decimal.MinValue;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_gabarit_template", run.Properties.ID_Gabarit_Template);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Templates");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			run.Templates.Clear();

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
				while (__odr.Read())
				{
					Template __template = new Template();
					
					__template.Name					= __odr[COL_TEMPLATE_NOM];
					__template.Src_Name				= __odr[COL_TEMPLATE_SRC_NOM];
					__template.Src_Name_Overflow	= __odr[COL_TEMPLATE_SRC_NOM_OVERFLOW];
					__template.Absolute				= __odr[COL_TEMPLATE_ABSOLUTE];
					
					__value = __odr[COL_TEMPLATE_LEFT];
					if(QXPFrk.Validation.IsSet(__value)) __template.Left	= __value;
					__value = __odr[COL_TEMPLATE_TOP];
					if(QXPFrk.Validation.IsSet(__value)) __template.Top		= __value;
					__value = __odr[COL_TEMPLATE_WIDTH];
					if(QXPFrk.Validation.IsSet(__value)) __template.Width	= __value;
					__value = __odr[COL_TEMPLATE_HEIGHT];
					if(QXPFrk.Validation.IsSet(__value)) __template.Height	= __value;

					int __absolute_Repeat_val	= __odr[COL_TEMPLATE_ABSOLUTE_REPEAT];
					if(QXPFrk.Validation.IsSet(__absolute_Repeat_val))
					{
						__template.Absolute_Repeat	= QXPFrk.Conversion.ToEnum<Absolute_Repeat_Type>(__absolute_Repeat_val);
					}

					__template.Page_Break	= __odr[COL_PAGE_BREAK];
					__template.Column_Break	= __odr[COL_COLUMN_BREAK];

					run.Templates.Add(__template.Name, __template);
				}
			}
		}
		
		#endregion SELECT

		#region INSERT / UPDATE / DELETE

		/*
         * Utiliser ici les QXPSnippet Proxy pour g�n�rer automatiquement un squelette de code pour les acc�s INSERT / UPDATE / DELETE � la base de donn�es
         */

		#endregion INSERT / UPDATE / DELETE

		#endregion Acc�s Base

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
