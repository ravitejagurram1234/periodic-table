using System;
using System.Data;
using Oracle.DataAccess.Client;
using QXPCore = QXP.Core;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPProxy = QXP.Framework.Proxy;


namespace QXP.Engine.Core
{
    /// <summary>
    /// Repr?sente la couche d'acc?s au donn?e du run
    /// </summary>
    /// <author>doufarm</author>
    /// <date>24/03/2010 09:48:19</date>    
    public class Proxy_Run : QXPProxy.BaseProxy
    {
        #region Membres

        #endregion Membres

        #region Constantes

        private const string PACKAGE = "QXP_PK_Run.";

        /// <summary>
        /// Sous cat?gorie d'un document QXP g?n?r? par l'engine (6)
        /// </summary>
		public const int IdSousCategorieQXPGenere = 6;
        /// <summary>
        /// Sous cat?gorie d'un document PDF g?n?r? par l'engine (7)
        /// </summary>
        public const int IdSousCategoriePDFGenere = 7;
        /// <summary>
        /// Sous cat?gorie d'un document DOC g?n?r? par l'engine (8)
        /// </summary>
        public const int IdSousCategorieDOCGenere = 8;

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr?e une instance de Proxy_Run
        /// </summary>
        public Proxy_Run()
        {
        }

        /// <summary>
        /// Cr?e une instance de Proxy_Run
        /// </summary>
        /// <param name="oraClient">Connexion Oracle</param>
        public Proxy_Run(QXPDataOracle.OraClient oraClient)
            : base(oraClient)
        {
        }

        /// <summary>
        /// Cr?e une instance de Proxy_Run
        /// </summary>
        /// <param name="dataBase">Nom de la cl? DataBase situ? dans le fichier .config de l'application (associ?e ? une chaine de connexion)</param>
        public Proxy_Run(string dataBase)
            : base(dataBase)
        {
        }

        #endregion Constructeur

        #region M?thodes

        #region Acc?s Base

        #region SELECT


        /// <summary>
        /// Charge les propri?t?s d'un run
        /// </summary>
        /// <param name="run">le run dont il faut charger les propri?t?s</param>
        public void Load_Run_Properties(Run run)
        {

            if (QXPFrk.Validation.IsNull(run)) return;

            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            Run_Properties __run_Properties = run.Properties;

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
                           .AddParameterToSqlParamList("p_id_run", run.ID);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "Get_Run_Properties");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                if (__odr.Read())
                {

                    __run_Properties.ID_Type_Rapport			= __odr["id_type_rapport"];
                    __run_Properties.ID_Fnd_Code				= __odr["id_fnd_code"];
                    __run_Properties.ID_Unit_Code				= __odr["id_unit_code"];
                    __run_Properties.Date_Echeance				= __odr["date_echeance"];
                    __run_Properties.ID_Suivi					= __odr["id_suivi"];
                    __run_Properties.Societe					= __odr["societe"];
                    __run_Properties.ID_Langue					= __odr["id_langue"];
                    __run_Properties.Code_Langue				= __odr["code_langue"];
                    __run_Properties.Gabarit_Source				= QXPFrk.Conversion.ToEnum<QXPCore.Gabarit_Source>(__odr["gabarit_source"]);
                    __run_Properties.ID_Suivi_Gabarit_Source	= __odr["id_suivi_gabarit_source"];
                    __run_Properties.Integrer_N1				= __odr["integrer_n1"];
                    __run_Properties.RunType					= __odr["runtype"];
                    __run_Properties.Generate_To_Word			= __odr["generate_to_word"];
                    __run_Properties.ID_Gabarit					= __odr["id_gabarit"];
                    __run_Properties.ID_Gabarit_Template		= __odr["id_gabarit_template"];

                    bool __pagination_Double = __odr["pagination_double"];
					//Par d?faut la pagination est simple (1 page / spread)
					if(__pagination_Double)
					{
						__run_Properties.Nb_Page_By_Spread		= Run_Properties.PaginationDouble;
					}
                    
					__run_Properties.ID_Last_PDF			= __odr["id_doc_pdf"];
					__run_Properties.ID_Last_QXP			= __odr["id_doc_qxp"];
					__run_Properties.ID_Last_DOC			= __odr["id_doc_doc"];

					//Mode d'?x?cution des taches de types compartiment
					int __mode	= __odr["mode_compart"];
					if (QXPFrk.Validation.IsSet(__mode))
					{
						__run_Properties.Compartiment_Mode = QXPFrk.Conversion.ToEnum<Task_Compartiment_Mode>(__mode);
					}

					int __id_Store_Type = __odr["Store_Data_Type"];

					__run_Properties.Store_Type = QXPFrk.Conversion.ToEnum<Store_Data_Type>(__id_Store_Type);

                }
				else
				{
					throw new Exception_Run(Exception_Run.MSG_Null_Run_Properties, run.ID);
				}
            }
        }


		
		/// <summary>
		/// Retourne Une liste d'identifiant de run en fonction des crit?res sp?cifi?s.
		/// Utiliser par les taches compartiments pour retrouver les Runs pr?c?demment ?x?cuter ou les runs ? ?x?cuter
		/// </summary>
		/// <param name="id_gabarit_tete">identifiant du gabarit de tete</param>
		/// <param name="id_structure">code de la structure</param>
		/// <param name="id_gabarit_fils">identifiant du gabarit fils</param>
		/// <param name="id_type_rapport">identifiant du type de rapport recherch?</param>
		/// <param name="id_langue">identifiant de la langue</param>
		/// <param name="date_echeance">date de l'?ch?ance</param>
		/// <param name="to_generate">true run ? g?n?rer sinon false les runs d?j? g?n?rer.</param>
		/// <returns>une liste de compartiment/run</returns>
		public List_Compartiment_Run Get_Compartiment_Runs(int id_gabarit_tete, string id_structure, int id_gabarit_fils, int id_type_rapport, int id_langue, DateTime date_echeance, bool to_generate)
		{
			#region Variables
			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			List_Compartiment_Run			__list			= new List_Compartiment_Run();

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_gabarit_tete", id_gabarit_tete)
						   .AddParameterToSqlParamList("p_id_structure", id_structure)
						   .AddParameterToSqlParamList("p_id_gabarit_fils", id_gabarit_fils)
						   .AddParameterToSqlParamList("p_id_type_rapport", id_type_rapport)
						   .AddParameterToSqlParamList("p_id_langue", id_langue)
						   .AddParameterToSqlParamList("p_date_echeance", date_echeance)
						   .AddParameterToSqlParamList("p_to_generate", to_generate);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Compartiment_Runs");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
				while (__odr.Read())
				{
					__list.Add(__odr["id_fnd_code"], __odr["id_run"]);
				}
			}

			return __list;
		}
			
        #endregion SELECT

        #region INSERT / UPDATE / DELETE

        /// <summary>
        /// D?but du run (Mise ? jour du statut du run en base de donn?es)
        /// </summary>
		/// <param name="run">le run qui d?bute</param>
        public void Start_Run(Run run)
        {

            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            //on r?cup?re le run en cours
            Run __run = run;

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("p_id_run", __run.ID)
                            .AddParameterToSqlParamList("p_run_status", (int)__run.Status)
                            .AddParameterToSqlParamList("p_date_debut", __run.Debut_Generation);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "Start_Run");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            try
            {
                this.Execute(__sqlRequest);
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de la mise ? jour du start_run : ", ex);
                throw;
            }
        }

        /// <summary>
        /// Fin du run (mise ? jour du statut et insertion des r?sultats)
        /// </summary>
        /// <param name="run">Le run ? finaliser</param>
        public void End_Run(Run run)
        {

            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            //on r?cup?re le run en cours
            Run __run = run;

            int __id_qxp = int.MinValue;
            int __id_pdf = int.MinValue;
            int __id_doc = int.MinValue;

            #endregion Variables


            __sql = string.Empty;


            try
            {
                this.OracleClient.BeginTransaction();

                #region Definition des OraParameters
                //on traite 2 cas possibles

                //Param?tre commun au 2 cas
                __oraParameters.AddParameterToSqlParamList("p_id_run", __run.ID)
                                .AddParameterToSqlParamList("p_run_status", (int)__run.Status)
                                .AddParameterToSqlParamList("p_suivi_status", (int)__run.Status)
                                .AddParameterToSqlParamList("p_date_fin", __run.Fin_Generation)
								.AddParameterToSqlParamList("p_log_trace", __run.Trace_Context.All_Logs, OracleDbType.Clob, ParameterDirection.Input);

                //1 - Le run est en erreur la g?n?ration n'a pas ?t? correctement finalis?e
                if (__run.Status == Run_Status.Error)
                {
                    __sql = string.Concat(PACKAGE, "Update_Status_Run");
                }
                //2 - Le run est termin?
                else
                {
                    __sql = string.Concat(PACKAGE, "End_Run");

                    //Insertion des documents g?n?r?s
                    Proxy_Document __proxy_Document = new Proxy_Document(this.OracleClient);
                    __id_qxp = __proxy_Document.Insert_Document(__run.Result.Final_QXP, IdSousCategorieQXPGenere, run.Properties.ID_Fnd_Code, run.Properties.ID_Unit_Code, run.Properties.Date_Echeance, run.ID);
                    __id_pdf = __proxy_Document.Insert_Document(__run.Result.Final_PDF, IdSousCategoriePDFGenere, run.Properties.ID_Fnd_Code, run.Properties.ID_Unit_Code, run.Properties.Date_Echeance, run.ID);
                    __id_doc = __proxy_Document.Insert_Document(__run.Result.Final_Word, IdSousCategorieDOCGenere, run.Properties.ID_Fnd_Code, run.Properties.ID_Unit_Code, run.Properties.Date_Echeance, run.ID);

                    //on ajoute les param?tres des documents g?n?r?s et l'identifiant du suivi
                    __oraParameters.AddParameterToSqlParamList("p_id_suivi", __run.Properties.ID_Suivi)
                                    .AddParameterToSqlParamList("p_id_doc_pdf", __id_pdf)
                                    .AddParameterToSqlParamList("p_id_doc_qxp", __id_qxp)
                                    .AddParameterToSqlParamList("p_id_doc_doc", __id_doc);
                }

                #endregion Definition des OraParameters

                __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

                this.Execute(__sqlRequest);

                //Inscription des erreurs
                Proxy_Error __proxy_Error = new Proxy_Error(this.OracleClient);
                __proxy_Error.Insert_Run_Errors(__run);

                //Inscription de l'audit
                Proxy_Audit __proxy_Audit = new Proxy_Audit(this.OracleClient);
                __proxy_Audit.InsertAuditRun(__run.Audit);

				//Seulement si le run n'est pas en erreur !!
				if (__run.Status != Run_Status.Error)
				{
					//Inscription des donn?es de stockage
					Proxy_Store __proxy_Store = new Proxy_Store(this.OracleClient);
					__proxy_Store.Insert_Data_Storage(__run);
				}

                this.OracleClient.CommitTransaction();
            }
            catch (Exception ex)
            {
                //FIN ANORMALE DU MODE TRANSACTIONNEL
                this.RoolBackTransaction();
                QXPDiagnostic.Log.LogError("EndRun", ex);
                throw;
            }
        }

        #endregion INSERT / UPDATE / DELETE

        #endregion Acc?s Base

        #endregion M?thodes

        #region Propri?t?s

        #endregion Propri?t?s
    }
}
