using System;
using System.Data;
using Oracle.DataAccess.Client;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPProxy = QXP.Framework.Proxy;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Proxy Proxy_Document
	/// </summary>
	/// <author>doufarm</author>
	/// <date>24/03/2010 10:46:25</date>    
	public class Proxy_Document : QXPProxy.BaseProxy
	{
		#region Membres

		#endregion Membres

		#region Constantes

		private const string PACKAGE = "QXP_PK_RUN.";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Proxy_Document
		/// </summary>
		public Proxy_Document()
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Document
		/// </summary>
		/// <param name="oraClient">Connexion Oracle</param>
		public Proxy_Document(QXPDataOracle.OraClient oraClient)
			: base(oraClient)
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Document
		/// </summary>
		/// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
		public Proxy_Document(string dataBase)
			: base(dataBase)
		{
		}

		#endregion Constructeur

		#region M�thodes

		#region Acc�s Base

		#region SELECT


		/// <summary>
		/// Retourne un Document de la base de donn�es
		/// </summary>
		/// <param name="id_sous_categorie">identifiant de la sous categorie</param>
		/// <param name="id_fnd_code">identifiant du fond ou de la structure</param>
		/// <param name="id_unit_code">identifiant de la part du fond</param>
		/// <param name="societe">nom de la soci�t�</param>
		/// <param name="id_langue">identifiant de la langue</param>
		/// <param name="date_echeance">date d'�ch�ance</param>
		/// <returns>Un Document</returns>
		public Document Get_Document(int id_sous_categorie, string id_fnd_code, string id_unit_code, string societe, int id_langue, DateTime date_echeance)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			Document						__document		= null;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_sous_categorie", id_sous_categorie)
						   .AddParameterToSqlParamList("p_id_fnd_code", id_fnd_code)
						   .AddParameterToSqlParamList("p_id_unit_code", id_unit_code)
						   .AddParameterToSqlParamList("p_societe", societe)
						   .AddParameterToSqlParamList("p_id_langue", id_langue)
						   .AddParameterToSqlParamList("p_date_echeance", date_echeance);


			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Document");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
				if (__odr.Read())
				{
					__document = new Document(__odr["id_document"]
												, __odr["nom"]
												, __odr["format"]
												, __odr["contenu"]);
                    __document.ID_Langue = id_langue;

				}
			}

			return __document;
		}

		/// <summary>
		/// Retourne un Document de la base de donn�es
		/// </summary>
		/// <param name="id_document">identifiant du document</param>
		/// <returns>Un Document</returns>
		public Document Get_Document(int id_document)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			Document						__document		= null;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_document", id_document);


			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Document_ByID");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
				if (__odr.Read())
				{
					__document = new Document(__odr["id_document"]
												, __odr["nom"]
												, __odr["format"]
												, __odr["contenu"]);
                    __document.ID_Langue = __odr["id_langue"];

				}
			}

			return __document;
		}


		/// <summary>
		/// Retourne le dernier Document quark certifi� pour ce suivi et ce type de rapport
		/// </summary>
		/// <param name="id_suivi">identifiant du suivi</param>
		/// <param name="id_type_rapport">type de rapport</param>
		/// <param name="id_langue">identifiant de la langue du document</param>
		/// <returns>Un document quark</returns>
		public Document Get_Last_Qxp_Certifie(int id_suivi
												, int id_type_rapport
												, int id_langue)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			Document						__document		= null;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_suivi", id_suivi)
						   .AddParameterToSqlParamList("p_id_type_rapport", id_type_rapport);

			#endregion Definition des OraParameters

			//TODO chang� cette proc�dure de package !! et la mettre dans QXP_PK_DOCUMENT
			// __sql = string.Concat(PACKAGE, "Get_Last_Qxp_Certifie");
			__sql = "QXP_PK_RUN.Get_Last_Qxp_Certifie";

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
				if (__odr.Read())
				{

                    __document			= new Document(__odr["id_document"]
														, __odr["nom"]
														, __odr["format"]
														, __odr["contenu"]);
                    __document.ID_Langue = id_langue;

				}
			}

			return __document;
		}
			
		#endregion SELECT

		#region INSERT / UPDATE / DELETE


		/// <summary>
		/// Insertion d'un document en base de donn�es
		/// </summary>
		/// <param name="doc">document � ins�rer</param>
		/// <param name="id_sous_cat">sous cat�gorie � associer � ce nouveau document</param>
		/// <param name="id_Fnd_Code">identifiant du fond ou de la structure</param>
		/// <param name="id_Unit_Code">identifiant de la part</param>
		/// <param name="date_echeance">date d'�ch�ance</param>
		/// <param name="id_run">identifiant du run</param>
		/// <returns>l'identifiant du nouveau document</returns>
		public int Insert_Document(Document doc
									, int id_sous_cat
									, string id_Fnd_Code
									, string id_Unit_Code
									, DateTime date_echeance
									, int id_run)
		{

			if (QXPFrk.Validation.IsNull(doc))
			{
				return int.MinValue;
			}

			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
            int								__id			= Int32.MinValue;

			#endregion Variables

			#region Definition des OraParameters

            QXPDataOracle.OraParameter __id_doc = new QXPDataOracle.OraParameter("p_id_doc", OracleDbType.Int32, ParameterDirection.ReturnValue);

			__oraParameters.Add(__id_doc);
			
			__oraParameters.AddParameterToSqlParamList("p_code_port", id_Fnd_Code)
							.AddParameterToSqlParamList("p_id_unit_code", id_Unit_Code)
							.AddParameterToSqlParamList("p_id_sous_categorie", id_sous_cat)
							.AddParameterToSqlParamList("p_format", doc.Format)
							.AddParameterToSqlParamList("p_id_langue", doc.ID_Langue)
							.AddParameterToSqlParamList("p_date_document", date_echeance)
							.AddParameterToSqlParamList("p_nom_document", doc.FileName)
							.AddParameterToSqlParamList("p_id_utilisateur", 0)
							.AddParameterToSqlParamList("p_contenu", doc.Data)
							.AddParameterToSqlParamList("p_taille_document", QXPFrk.Validation.IsSet(doc.Data) ? doc.Data.Length : 0)
							.AddParameterToSqlParamList("p_is_actif", true)
							.AddParameterToSqlParamList("p_id_run", id_run);



			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Insert_Document");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			try
			{
				
				this.Execute(__sqlRequest);
				__id = __id_doc.ReturnValue;
				return __id;
			}
			catch (Exception ex)
			{
				QXPDiagnostic.Log.LogError("Erreur lors de l'insertion du document : ", ex);
				throw;
			}
		}		
			

		#endregion INSERT / UPDATE / DELETE

		#endregion Acc�s Base

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
