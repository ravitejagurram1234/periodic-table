using System;
using System.Data;
using System.Text;
using System.Collections.Generic;

using Oracle.DataAccess.Client;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPProxy = QXP.Framework.Proxy;
using QXPAPPlication = QXP.Framework.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Proxy permettant le chargement des gabarits utilis�s dans les runs
	/// </summary>
	/// <author>doufarm</author>
	/// <date>24/03/2010 13:53:35</date>    
	public class Proxy_Gabarit : QXPProxy.BaseProxy
	{
		#region Membres

		#endregion Membres

		#region Constantes

		private const string PACKAGE = "QXP_PK_RUN.";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Proxy_Gabarit
		/// </summary>
		public Proxy_Gabarit()
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Gabarit
		/// </summary>
		/// <param name="oraClient">Connexion Oracle</param>
		public Proxy_Gabarit(QXPDataOracle.OraClient oraClient)
			: base(oraClient)
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Gabarit
		/// </summary>
		/// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
		public Proxy_Gabarit(string dataBase)
			: base(dataBase)
		{
		}

		#endregion Constructeur

		#region M�thodes

		#region Acc�s Base

		#region SELECT

		
		/// <summary>
		/// Retourne un document gabarit
		/// </summary>
		/// <param name="id_gabarit">identifiant du gabarit</param>
		/// <returns>Un document gabarit</returns>
		public Document Get_Gabarit(int id_gabarit)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			Document						__gabarit		= null;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_gabarit", id_gabarit);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Gabarit");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
    			if (__odr.Read())
    			{
    				__gabarit = new Document(__odr["id_gabarit"]
											, __odr["nom"]
											, Constantes.Document_Format.QXP
											, Document.FileGabaritPrefix
											, __odr["contenu"]);
    				__gabarit.ID_Langue = __odr["id_langue"];
    				__gabarit.Is_Gabarit = true;
    			}
    			else
    			{
    				throw new Exception_Run(Constantes.Error_Messages.Gabarit_Null);
    			}
			}

			return __gabarit;
		}
			
		/// <summary>
		/// Retourne un document gabarit issu de la derni�re g�n�ration d'un suivi
		/// </summary>
		/// <param name="id_suivi">identifiant du suivi pour retrouver la derni�re g�n�ration</param>
		/// <returns>Un document gabarit</returns>
		public Document Get_Gabarit_Document(int id_suivi)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			Document						__gabarit		= null;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_suivi", id_suivi);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Gabarit_Document");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
    			if (__odr.Read())
    			{
    				__gabarit = new Document(__odr["id_document"]
											, __odr["nom"]
											, Constantes.Document_Format.QXP
											, Document.FileDocumentGabaritPrefix
											, __odr["contenu"]);
    				__gabarit.ID_Langue = __odr["id_langue"];
    				__gabarit.Is_Gabarit = true;
    			}
    			else
    			{
    				throw new Exception_Run(Constantes.Error_Messages.Gabarit_Document_Null);
    			}
			}

			return __gabarit;
		}		


		/// <summary>
		/// Retourne un document gabarit issu de la derni�re derni�re certification qxp du suivi pr�c�dent ayant les m�mes caract�risques (fond/part/langue/date_echeance etc.) que le suivi en cours g�n�ration d'un suivi
		/// </summary>
		/// <param name="id_suivi">identifiant du suivi pour retrouver la derni�re g�n�ration</param>
		/// <returns>Un document gabarit</returns>
		public Document Get_Gabarit_Document_Certifie(int id_suivi)
		{
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
			Document						__gabarit		= null;

			#endregion Variables

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
						   .AddParameterToSqlParamList("p_id_suivi", id_suivi);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Get_Gabarit_Document_Certifie");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
			{
    			if (__odr.Read())
    			{
    				__gabarit = new Document(__odr["id_document"]
											, __odr["nom"]
											, Constantes.Document_Format.QXP
											, Document.FileDocumentCertifieGabaritPrefix
											, __odr["contenu"]);
    				__gabarit.ID_Langue = __odr["id_langue"];
    				__gabarit.Is_Gabarit = true;
    			}
    			else
    			{
    				throw new Exception_Run(Constantes.Error_Messages.Gabarit_Document_Null);
    			}
			}

			return __gabarit;
		}		

		#endregion SELECT

		#region INSERT / UPDATE / DELETE

		/*
         * Utiliser ici les QXPSnippet Proxy pour g�n�rer automatiquement un squelette de code pour les acc�s INSERT / UPDATE / DELETE � la base de donn�es
         */

		#endregion INSERT / UPDATE / DELETE

		#endregion Acc�s Base

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
