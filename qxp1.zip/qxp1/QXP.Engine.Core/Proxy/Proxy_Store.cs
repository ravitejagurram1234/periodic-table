using System;
using System.Data;
using System.Text;
using System.Collections.Generic;

using Oracle.DataAccess.Client;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPProxy = QXP.Framework.Proxy;
using QXPAPPlication = QXP.Framework.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;

/* 
 * Code g�n�r� avec le template : QXPProxyClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Proxy permettant de sauvegarder les donn�es g�n�r�es par le run ou contenu dans le document final.
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/09/2010 10:23:28</date>    
	public class Proxy_Store : QXPProxy.BaseProxy
	{
		#region Membres

		#endregion Membres

		#region Constantes

		private const string PACKAGE = "QXP_PK_DATA_STORAGE.";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Proxy_Store
		/// </summary>
		public Proxy_Store()
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Store
		/// </summary>
		/// <param name="oraClient">Connexion Oracle</param>
		public Proxy_Store(QXPDataOracle.OraClient oraClient)
			: base(oraClient)
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Store
		/// </summary>
		/// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
		public Proxy_Store(string dataBase)
			: base(dataBase)
		{
		}

		#endregion Constructeur

		#region M�thodes

		#region Acc�s Base

		#region SELECT

		/*
         * Utiliser ici les QXPSnippet Proxy pour g�n�rer automatiquement un squelette de code pour les acc�s SELECT � la base de donn�es
         */

		#endregion SELECT

		#region INSERT / UPDATE / DELETE

		/// <summary>
		/// Insertion des donn�es de stockage du run 
		/// </summary>
		/// <param name="run">un Run</param>
		public void Insert_Data_Storage(Run_Base run)
		{
			if ((run.Properties.Store_Type & Store_Data_Type.SQL) == Store_Data_Type.SQL)
			{
				QXPFrk.BaseList<string[]> __datas = run.SQLDataNamesValues.ToArrays();
	
				this.Insert_Data(run.Properties.ID_Suivi, run.ID, run.Fin_Generation, Store_Data_Type.SQL, __datas, false);
			}

			if ((run.Properties.Store_Type & Store_Data_Type.DOCUMENT) == Store_Data_Type.DOCUMENT)
			{
				QXPFrk.BaseList<string[]> __datas = run.DocDataNamesValues.ToArrays();
				
				this.Insert_Data(run.Properties.ID_Suivi, run.ID, run.Fin_Generation, Store_Data_Type.DOCUMENT, __datas, true);
			}
		}
		
		/// <summary>
		/// Stockage des donn�es 
		/// </summary>
		/// <param name="id_suivi">identifiant du suivi</param>
		/// <param name="id_run">identifiant du run</param>
		/// <param name="fin_generation">Date de stockage</param>
		/// <param name="store_Data_Type">type de stockage</param>
		/// <param name="data">donn�es de stockage</param>
		/// <param name="historisation_differentielle">si true chaque run g�n�re un stockage du diff�rentiel des blocs d�j� pr�sent pour le suivi (si le bloc n'existe pas il est ajout�, s'ul existe les informations sont mise � jour)), si false toutes les informations sont ins�r�e pour le suivi et pour le run (pas de diff�rentiel).</param>
		private void Insert_Data(int id_suivi, int id_run, DateTime fin_generation, Store_Data_Type store_Data_Type, QXPFrk.BaseList<string[]> data, bool historisation_differentielle)
		{
			
			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;

			#endregion Variables

			#region Definition des OraParameters
			

			__oraParameters.AddParameterToSqlParamList("p_id_suivi", id_suivi)
							.AddParameterToSqlParamList("p_id_run", id_run)
							.AddParameterToSqlParamList("p_date_generation", fin_generation)
							.AddParameterToSqlParamList("p_store_type", (int)store_Data_Type)
							.AddParameterToSqlParamList("p_names", data[0])
							.AddParameterToSqlParamList("p_values", data[1])
							.AddParameterToSqlParamList("p_descriptifs", data[2])
							.AddParameterToSqlParamList("p_infos", data[3])
							.AddParameterToSqlParamList("p_historisation_differentielle", historisation_differentielle);

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Insert_Data");
			
			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			try
			{

				this.Execute(__sqlRequest);

			}
			catch (Exception ex)
			{
				QXPDiagnostic.Log.LogError("Erreur lors des donn�es de stockage du Run : ", ex);
				throw;
			}
		}		

		#endregion INSERT / UPDATE / DELETE

		#endregion Acc�s Base

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
