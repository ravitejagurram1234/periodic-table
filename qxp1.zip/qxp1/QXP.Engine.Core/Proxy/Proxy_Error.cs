using System;
using System.Data;
using System.Text;
using System.Collections.Generic;

using Oracle.DataAccess.Client;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPProxy = QXP.Framework.Proxy;
using QXPAPPlication = QXP.Framework.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Proxy Proxy_Error
	/// </summary>
	/// <author>doufarm</author>
	/// <date>24/03/2010 10:46:55</date>    
	public class Proxy_Error : QXPProxy.BaseProxy
	{
		#region Membres

		#endregion Membres

		#region Constantes

		private const string PACKAGE = "QXP_PK_RUN.";

		const string MessageVide = "aucun";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de Proxy_Error
		/// </summary>
		public Proxy_Error()
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Error
		/// </summary>
		/// <param name="oraClient">Connexion Oracle</param>
		public Proxy_Error(QXPDataOracle.OraClient oraClient)
			: base(oraClient)
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Error
		/// </summary>
		/// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
		public Proxy_Error(string dataBase)
			: base(dataBase)
		{
		}

		#endregion Constructeur

		#region M�thodes

		#region Acc�s Base

		#region SELECT

		/*
         * Utiliser ici les QXPSnippet Proxy pour g�n�rer automatiquement un squelette de code pour les acc�s SELECT � la base de donn�es
         */

		#endregion SELECT

		#region INSERT / UPDATE / DELETE

		
		/// <summary>
		/// Insertion des erreurs control�s survenus pendant la g�n�ration d'un run
		/// </summary>
		/// <param name="run">le run contenant les erreurs</param>
		public void Insert_Run_Errors(Run run)
		{

            //Aucune erreur � inserer ! on sort
            if(run.Errors.Count == 0) return;

			#region Variables

			QXPDataOracle.OraParameterList	__oraParameters = new QXPDataOracle.OraParameterList();
			QXPDataOracle.SQLRequest		__sqlRequest	= null;
			string							__sql			= string.Empty;
            QXPFrk.BaseList<string>			__msgs          = new QXPFrk.BaseList<string>();
            QXPFrk.BaseList<int>			__cats          = new QXPFrk.BaseList<int>();
            string							__msg;

			#endregion Variables

			#region pr�paration des messages d'erreurs avant envoi
            
			foreach(Error __error in run.Errors)
			{
                //Par s�curit� il est d�j� arriv� je ne sais pas pourquoi que le message soit vide :(
                if(QXPFrk.Validation.IsSet(__error.Message))
				{
                    __msg = __error.Message;
                }
				else
				{
                    __msg = MessageVide;
                }
                __msgs.Add(__msg);
                __cats.Add((int)__error.Type);
            }

			#endregion

			#region Definition des OraParameters

			__oraParameters.AddParameterToSqlParamList("p_id_run", run.ID)
							.AddParameterToSqlParamList("p_messages", __msgs.ToArray())
							.AddParameterToSqlParamList("p_categories", __cats.ToArray());

			#endregion Definition des OraParameters

			__sql = string.Concat(PACKAGE, "Insert_Run_Errors");

			__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

			try
			{
				
				this.Execute(__sqlRequest);

			}
			catch (Exception ex)
			{
				QXPDiagnostic.Log.LogError(string.Format("Erreur lors de l'insertion des erreurs pour le run:{0}", run.ID), ex);
				throw;
			}
		}		
			

		#endregion INSERT / UPDATE / DELETE

		#endregion Acc�s Base

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
