using System;
using System.Data;
using System.Text;
using System.Collections.Generic;

using Oracle.DataAccess.Client;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPProxy = QXP.Framework.Proxy;
using QXPAPPlication = QXP.Framework.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPConfiguration	= QXP.Framework.Configuration;


namespace QXP.Engine.Core
{
	/// <summary>
	/// Proxy utiliser par les taches SQL et plus tard par les taches dynamiques
	/// </summary>
	/// <author>doufarm</author>
	/// <date>25/03/2010 11:50:26</date>    
	public class Proxy_Generic : QXPProxy.BaseProxy
	{
		#region Membres
        static  string  DBGenericConnectionName		= string.Empty;

		#endregion Membres

		#region Constantes
		
		const   string	DBGenericSettingKey   = "DBConnection_Generic";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

        /// <summary>
        /// Constructeur statique
        /// </summary>
		static Proxy_Generic()
		{
            string __connectionName = QXPConfiguration.Settings.Current.GetString(DBGenericSettingKey);
            if(QXPFrk.Validation.IsSet(__connectionName))
			{
                DBGenericConnectionName   = __connectionName;
            }
        }


		/// <summary>
		/// Cr�e une instance de Proxy_Generic
		/// </summary>
		public Proxy_Generic(): base(DBGenericConnectionName){}
		
		/// <summary>
		/// Cr�e une instance de Proxy_Generic
		/// </summary>
		/// <param name="oraClient">Connexion Oracle</param>
		public Proxy_Generic(QXPDataOracle.OraClient oraClient)
			: base(oraClient)
		{
		}

		/// <summary>
		/// Cr�e une instance de Proxy_Generic
		/// </summary>
		/// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
		public Proxy_Generic(string dataBase)
			: base(dataBase)
		{
		}

		#endregion Constructeur

		#region M�thodes

		#region Acc�s Base

		#region SELECT

        /// <summary>
        /// Utiliser par certaines taches (exemple SQL, Dynamique) pour obtenir un OraDataReader
        /// </summary>
        /// <param name="sql">le code sql � �x�cuter</param>
        /// <param name="parameters">les param�tres oracles � utiliser</param>
        /// <returns>Un DataReader oracle donnant acc�s � la source de donn�es g�n�r�e par le sql</returns>
		public QXPDataOracle.OraDataReader GetReader(string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            return this.GetReader(CommandType.Text, sql, parameters);
        }

		#endregion SELECT

		#region INSERT / UPDATE / DELETE

		/*
         * Utiliser ici les QXPSnippet Proxy pour g�n�rer automatiquement un squelette de code pour les acc�s INSERT / UPDATE / DELETE � la base de donn�es
         */

		#endregion INSERT / UPDATE / DELETE

		#endregion Acc�s Base

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
