using System;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Ensembles des Constantes communes au module QXP.Engine.Core
	/// </summary>
	/// <author>doufarm</author>
	/// <date>18/03/2010 16:17:41</date>    
	public class Constantes
	{
		/// <summary>
		/// Liste des messages d'erreurs control�s possibles
		/// </summary>
		public class Error_Messages
			{
				public const string	ApplicationError					= "Erreur de L'Engine";
				
				public const string Log_Error							= "Impossible de logger le message {0} avec {1} arguments";
				public const string Log_Exception						= "Impossible de logger l'exception";

				public const string Gabarit_Null            			= "Impossible de trouver le Gabarit";
				public const string Gabarit_Document_Null   			= "Impossible de trouver le Gabarit Document";

				public const string Document_Null           			= "Aucun document associ� � Fond/Part/Soci�t�:{0}/{1}/{2} pour la sous_cat:{3} et langue:{4} tache {5}";

				public const string Document_LastQxp_Null   			= "Aucun QXP pr�c�dent n'a �t� trouv� pour le suivi {0} et le type {1} pour la tache {2}";

				public const string BoxOverflow							= "Le bloc \"{0}\" est en d�bord";

				// RUN
				public const string RunSansTache            			= "Aucune Tache pour le Run {0}";
				public const string EmptyRunCompartiment				= "le compartiment {0} ne poss�de pas de run � ex�cuter ou � incorporer pour la tache {1} du run parent {2}";
				public const string NoneRunCompartiment					= "aucun compartiment pour la tache compartiment {0} du run parent {1}";
				public const string EmptyRunChildQXP					= "le run fils {0} ne poss�de pas de document qxp g�n�r�";
				public const string EmptyRunChildProject				= "le document qxp du run fils {0} n'est pas valide (impossible d'analyser le projet)";

				//QXPS_Modifier
				public const string BlocDupliquerDansTache				= "le nom Bloc {0} de la tache {1} est d�j� d�fini";
				public const string Empty_Layout_Or_Spread_For_Bloc 	= "Layout ou Spread NULL pour le bloc {0}";

				// TASK
				public const string MissingBlocNameInTask				= "Missing BlocName in Task:{0}";
				public const string TaskPreparing						= "Erreur lors de la preparation des taches du run {0}";
				public const string TaskProcessing						= "Impossible d'ex�cuter la tache {0}";
				public const string TaskSansBloc						= "Aucun Bloc dans la tache {0}";
				public const string Invalid_Data_Type					= "Invalid DataType {0} on task {1}";
				public const string TaskFailSoftMode					= "La tache {0} est en mode d�grad�e, aucun processing effectu� !";

				public const string ElementTemplateMissing				= "l'�lement associ� au template {0} est absent la cellule contenant le(s) nom(s) ({1}) ne sera donc pas ajout�e !!";
				public const string NullBlocs							= "le/les blocs sont nulls dans la DCell";

				public const string ErrorAddingBlocInTask				= "Error when adding bloc in task : {0} : source bloc : {1} : dest bloc : {2}";
				public const string ErrorDuplicateBlocInTask			= "Duplicate Name Bloc in task : {0} bloc : {1}";
				public const string ErrorAddingBlocSQLInTask			= "Error when adding bloc in task : {0} bloc : {1}";
				public const string ErrorGettingDataInTask  			= "Error when getting data in task : {0}";

				public const string	MissingBlocNameInDocument			= "Le bloc {0} est introuvable dans le document {1}";	
				public const string	MissingDestinationBlocNameInTask	= "Manque le bloc de destination {0} dans la tache {1}";

				public const string	MissingDID							= "Le bloc DID est absent du document";
				
				public const string	Invalid_List_Count					= "le nombre d'�l�ments dans la source ({0}) n'est pas le m�me que dans la destination ({1})";	
				public const string	Invalid_TElement_Type				= "Le type d'�l�ment de {0} n'est pas pris en charge pour la tache {1}";
				public const string	Missing_TElement					= "Le document qxp source ne contient pas l'�l�ment {0} pour la tache {1}";

				public const string NoSQLDataForTask					= "Aucune donn�e retourn�e par le SQL de la tache {0}";

				public const string BreakRuleIgnored					= "Les r�gles de saut de page/colonne ({0}) mode page ({1}) ont �t� ignor�es. manque de hauteur pour la page relative {2} / colonne {3} de la tache {4}"; 


				//TASK_Exception
				public const string DuplicateBlocException  = "Le bloc {0} est d�j� d�fini dans la tache {1} du run {2}";
				public const string TaskNullInBlocException = "impossible de d�finir l'exception [{2}] pour la tache {0} qui est introuvable dans le run {1}";
				public const string InvalidCondBloc         = "Le bloc {0} n'est pas pr�sent dans le gabarit de la tache {1}, l'exception associ�e n'est donc pas prise en compte";
				public const string TableNotExist			= "La table {0} n'existe pas/plus dans le document en cours";
				public const string MissingTableRows		= "La table {0} ne contient pas assez de ligne pour permettre l'�x�cution de la tache exception {1}, elle est donc ignor�e !";

				// Run_Task_Step
				public const string DuplicateBlocName       = "le nom Bloc {0} de la tache {1} est d�j� d�fini";

				//TElement
				public const string TGroupSubGroupProblem	= "Attention le group '{0}' de la page '{1}' poss�de des sous groupes qui ne seront pas �valu�s et qui peuvent perturber l'ex�cution de la tache";
				public const string TGroupUnKnownSubGroup	= "Attention l'�l�ment '{0}' est introuvable dans le group '{1}'";

				public const string TaskInSafeMode			= "Attention La tache � fonctionn�e en mode d�grad�e, il n'y � donc eu aucune modification de la structure du document par cette tache";
				public const string RunInSafeMode			= "Attention Le run � fonctionn� en mode d�grad�, il n'y � donc eu aucune modification de la structure du document";

				public const string BoxComplexityOutOfRange = "Le coefficient de complexit� ({0}) des boites du documents est en dehors des limites, nous utiliserons donc les bornes min (0.8) ou max (1.3).";
		}

		/// <summary>
		/// Format des documents manipuler par Quark
		/// </summary>
		public class Document_Format
		{
                public const string PDF = "PDF";
                public const string JPG = "JPG";
                public const string JPEG = "JPEG";
                public const string EPS = "EPS";
                public const string GIF = "GIF";
                public const string PNG = "PNG";
                public const string XTG = "XTG";
                public const string DOC	= "DOC";
                public const string RTF	= "RTF";
                public const string QXP	= "QXP";
				public const string TIF = "TIF";
                public const string TIFF = "TIFF";
		}
	}
}
