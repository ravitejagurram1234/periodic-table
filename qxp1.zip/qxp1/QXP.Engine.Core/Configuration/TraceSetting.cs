﻿using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;


namespace QXP
{
    /// <summary>
    /// TraceSetting définit la section de configuation des traces
    /// </summary>
    /// <author>mdoufar</author>
    /// <date>19/05/2010 11:39:41</date>    
    public class TraceSetting : QXPFrk.Configuration.BaseSetting<TraceSetting>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        private const string TRACE_SECTION			= "QXP.Trace";
		private const string TRACE_ENABLED_KEY		= "Trace_Enabled";        
		private const string TRACE_LOG_PATH_KEY		= "Trace_Log_Path";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Crée une instance de TraceSetting
        /// </summary>
        public TraceSetting() : base(TRACE_SECTION)
        {
        }

        #endregion Constructeur

        #region Méthodes

        #endregion Méthodes

        #region Propriétés

        /// <summary>
        /// Active les traces fichiers (def false)
        /// </summary>
        public bool	TRACE_ENABLED
        {
            get
            {
                return this.GetBool(TRACE_ENABLED_KEY, false);
            }
        }   

        /// <summary>
        /// Repertoire dans lequel sauvegarder les traces fichiers
        /// </summary>
        public string		TRACE_LOG_PATH
        {
            get
            {
                return this.GetString(TRACE_LOG_PATH_KEY);
            }
        }   

        #endregion Propriétés
    }
}
