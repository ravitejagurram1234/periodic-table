﻿using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;


namespace QXP.Engine.Core
{
    /// <summary>
    /// EngineCoreSetting définit la section de configuration de l'engine
    /// </summary>
    /// <author>mdoufar</author>
    /// <date>26/03/2010 16:19:41</date>    
    public class EngineCoreSetting : QXPFrk.Configuration.BaseSetting<EngineCoreSetting>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        private const string ENGINECORE_SECTION					= "QXP.Engine.Core";
		private const string DEFAULTPOOLPATHABSOLUTE_KEY		= "Default_PoolPath_Absolute";        
		private const string SAVE_USED_RESSOURCES_KEY			= "Save_Used_Ressources";
		private const string SAVE_USED_RESSOURCES_PATH_KEY		= "Save_Used_Ressources_Path";
		private const string SAVE_QXPS_RESPONSE_KEY				= "Save_QXPS_Response";
		private const string DELETE_QXPS_RESSOURCES_KEY			= "Delete_QXPS_Ressources";
		private const string RUN_DECIMALCHAR_KEY				= "Run_DecimalChar";
		private const string RUN_DATEPATTERN_KEY				= "Run_DatePattern";
		private const string RUN_DATETIMEPATTERN_KEY			= "Run_DateTimePattern";
		private const string RUN_GROUPSEPARATOR_KEY				= "Run_GroupSeparator";
		private const string APP_PREFIXE_KEY					= "App_Prefixe";
		
		private const string STEP_LIMIT_KEY						= "Step_Limit";
		private const string SIZE_LIMIT_BEFORE_FAIL_SOFT_KEY	= "Size_Limit_Before_Fail_Soft";
		private const string AVERAGE_BOX_SIZE_KEY				= "Average_Box_Size";

		private const string NB_BOX_MAX_KEY						= "Nb_Box_Max";


		private const int	 Def_Step_Limit						= 5000;
		private const int	 Def_Average_Box_Size				= 3400; //Valeur moyenne d'une Box très Simple
		private const int	 Def_SIZE_LIMIT_BEFORE_FAIL_SOFT	= 68000000;

		private const int	 Def_Nb_Box_Max						= 17500;
        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Crée une instance de EngineCoreSetting
        /// </summary>
        public EngineCoreSetting() : base(ENGINECORE_SECTION)
        {
        }

        #endregion Constructeur

        #region Méthodes

        #endregion Méthodes

        #region Propriétés

        /// <summary>
        /// Valeur du chemin absolu du poolPath sur le serveur quark dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public string	DefaultPoolPathAbsolute
        {
            get
            {
                return this.GetString(DEFAULTPOOLPATHABSOLUTE_KEY, "d:\\Documents\\");
            }
        }   

        /// <summary>
        /// Valeur du X dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public bool		Save_Used_Ressources
        {
            get
            {
                return this.GetBool(SAVE_USED_RESSOURCES_KEY, true);
            }
        }   

        /// <summary>
        /// Valeur du X dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public string	Save_Used_Ressources_Path
        {
            get
            {
                return this.GetString(SAVE_USED_RESSOURCES_PATH_KEY, "c:\\Documents\\");
            }
        }   

        /// <summary>
        /// Valeur du X dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public bool		Save_QXPS_Response
        {
            get
            {
                return this.GetBool(SAVE_QXPS_RESPONSE_KEY, true);
            }
        }   

        /// <summary>
        /// Valeur du X dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public bool		Delete_QXPS_Ressources
        {
            get
            {
                return this.GetBool(DELETE_QXPS_RESSOURCES_KEY, false);
            }
        }   

        /// <summary>
        /// Valeur du X dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public string	Run_DecimalChar
        {
            get
            {
                return this.GetString(RUN_DECIMALCHAR_KEY);
            }
        }   

        /// <summary>
        /// Valeur du X dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public string	Run_DatePattern
        {
            get
            {
                return this.GetString(RUN_DATEPATTERN_KEY, "dd/MM/yyyy");
            }
        }   

        /// <summary>
        /// Valeur du X dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public string	Run_DateTimePattern
        {
            get
            {
                return this.GetString(RUN_DATETIMEPATTERN_KEY, "dd/MM/yyyy HH:mm:ss");
            }
        }   

        /// <summary>
        /// Valeur du X dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public string	Run_GroupSeparator
        {
            get
            {
                return this.GetString(RUN_GROUPSEPARATOR_KEY);
            }
        }   

        /// <summary>
        /// Valeur du X dans la section QXP.Engine.Core du fichier de configuration
        /// </summary>
        public string	App_Prefixe
        {
            get
            {
                return this.GetString(APP_PREFIXE_KEY);
            }
        }

		/// <summary>
		/// définit le nombre de blocs maximum par étape de modification d'un document quark
		/// (def 5000) si int.minvalue pas de limite (ce qui n'est pas trop conseillé).
		/// défini par la clef Step_Limit dans la section QXP.Engine.Core de app.config
		/// </summary>
		public int		Step_Limit
		{
                get{
					return this.GetInt(STEP_LIMIT_KEY, Def_Step_Limit);
				}
		}

		/// <summary>
		/// défini la taille (en byte) à partir duquel le run fonctionne en mode dégradé
		/// Lorsque le gabarit atteint une certaine taille le run s'éxécute en mode dégradé et n'execute aucune tache y compris les taches DID
		/// dans ce cas il tente d'effectue uniquement un rendu pdf du document et récupère le qxp correspondant sans modification
		/// </summary>
		public int		Size_Limit_Before_Fail_Soft
		{
                get{
					return this.GetInt(SIZE_LIMIT_BEFORE_FAIL_SOFT_KEY, Def_SIZE_LIMIT_BEFORE_FAIL_SOFT);
				}
		}

		/// <summary>
		/// Définit le nombre maximal de boite qu'un document qui doit subir des ajouts peut contenir
		/// lorsque cette limite est dépassé les opérations d'ajout de box sont ignorés
		/// </summary>
		public int		Nb_Box_Max
		{
			get
			{
				return this.GetInt(NB_BOX_MAX_KEY, Def_Nb_Box_Max);
			}
		}

		/// <summary>
		/// Définit la taille moyenne d'une boite boite dans un document moyen
		/// Permet d'évaluer la compléxité d'un document en fonction de la taille de celui-ci et du nombre de boites
		/// </summary>
		public int		Average_Box_Size
		{
			get
			{
				return this.GetInt(AVERAGE_BOX_SIZE_KEY, Def_Average_Box_Size);
			}
		}

        #endregion Propriétés
    }
}
