﻿using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;


namespace QXP.Engine.Core
{
    /// <summary>
    /// SolidFrameworkSetting définit la section de configuation de SolidFrameworkSetting
    /// </summary>
    /// <author>cueffl</author>
    /// <date>23/09/2009 16:19:41</date>    
    public class SolidFrameworkSetting : QXPFrk.Configuration.BaseSetting<SolidFrameworkSetting>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        private const string SOLIDFRAMEWORK_SECTION = "QXP.Framework.SolidFramework";
        private const string LICENSE_NAME_KEY = "licenseName";        
        private const string LICENSE_EMAIL_KEY = "licenseEmail";
        private const string LICENSE_ORGANIZATION_KEY = "licenseOrganization";
        private const string LICENSE_CODE_KEY = "licenseCode";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Crée une instance de SolidFrameworkSetting
        /// </summary>
        public SolidFrameworkSetting() : base(SOLIDFRAMEWORK_SECTION)
        {
        }

        #endregion Constructeur

        #region Méthodes

        #endregion Méthodes

        #region Propriétés

        /// <summary>
        /// Valeur de la LicenseName dans la section QXP.Framework.SolidFramework du fichier de configuration
        /// </summary>
        public string LicenseName
        {
            get
            {
                return this.GetSetting(LICENSE_NAME_KEY);
            }
        }   

        /// <summary>
        /// Valeur de la LicenseEmail dans la section QXP.Framework.SolidFramework du fichier de configuration
        /// </summary>
        public string LicenseEmail
        {
            get
            {
                return this.GetSetting(LICENSE_EMAIL_KEY);
            }
        }  

        /// <summary>
        /// Valeur de la LicenceOrganisation dans la section QXP.Framework.SolidFramework du fichier de configuration
        /// </summary>
        public string LicenceOrganisation
        {
            get
            {
                return this.GetSetting(LICENSE_ORGANIZATION_KEY);
            }
        }  

        /// <summary>
        /// Valeur de la LicenceCode dans la section QXP.Framework.SolidFramework du fichier de configuration
        /// </summary>
        public string LicenceCode
        {
            get
            {
                return this.GetSetting(LICENSE_CODE_KEY);
            }
        }  

        #endregion Propriétés
    }
}
