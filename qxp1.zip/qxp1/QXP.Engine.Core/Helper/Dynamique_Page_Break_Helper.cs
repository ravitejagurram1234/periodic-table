using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Helper Permettant d'�valuer les ruptures de lignes dans les tableaux dynamiques
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 16:10:57</date>    
	public class Dynamique_Page_Break_Helper
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Dynamique_Page_Break_Helper
		/// </summary>
		static Dynamique_Page_Break_Helper()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet de mettre � jour les informations (page/colonne) des lignes pr�c�dentes/suivante la ligne qui � g�n�r� le saut de page/colonne
		/// </summary>
		/// <param name="report">le rapport � mettre en forme</param>
		/// <param name="table_Rows">les lignes de la table en cours de traitenent</param>
		/// <param name="current_Row">la ligne qui � d�clench�e le saut de page/colonne</param>
		/// <param name="prp">les param�tres instantan�s de g�n�ration</param>
		/// <param name="pageBreak">true c'est un saut de page, false c'est un saut de colonne</param>
		/// <param name="left">Position � gauche du saut (de page ou de colonne)</param>
		public static void Update_Rows(DReport report, DRows table_Rows, DRow current_Row, Prepare_Report_Parameters prp, bool pageBreak, decimal left)
		{
			//r�gles de r�cup�ration des lignes pr�c�dentes
			D_Break_Rule			__rules;
			//Num�ro de la page pr�c�dente
			int						__previous_PageColumn;
			//nombre de ligne d�j� r�cup�r�e 
			//on commence � -1 car la ligne qui � d�clencher le saut de page est dans la boucle et elle ne doit pas compt�
			int						__nbRowsRetrieves			= -1;
			//nombre minimum de lignes � r�cup�r�e si la valeur est 0 (seule les r�gles de page break rules sont utilis�e)
			int						__nbRowsMinRetrieves		= 0;
			//Hauteur totales des lignes en r�p�tition (Breaks)
			decimal					__break_Height				= 0;
			//Largeur totales des lignes en r�p�tition (Breaks)
			decimal					__break_Width				= 0;
			//Hauteur totales des lignes ramen�es (Rules)
			decimal					__retrieves_Rows_Height		= 0;
			//Largeur maximale des lignes ramen�es (Rules) (on initialise avec la largeur de la ligne qui � provoqu� le saut de colonne).
			decimal					__retrieves_Rows_Width		= current_Row.Info.Width;
			//Liste des lignes finalement r�cup�rer (par les r�gles de rules)
			DRows					__rows						= new DRows();
			//instance de la ligne en cours en clonage dans le traitement
			DRow					__duplicate_row				= null;
			//Premi�re ligne qui � d�clencher le saut de page
			DRow					__first_row					= current_Row;
			//Lignes � r�p�ter dans la nouvelle page
			QXPFrk.BaseList<DRow>	__break_Rows				= new QXPFrk.BaseList<DRow>();
			//Lignes des r�p�titions qui ne seront finalement pas r�cup�r�e (Car en doublons avec les lignes suivantes)
			QXPFrk.BaseList<int>	__rowlevel_Remove_Break		= new QXPFrk.BaseList<int>();
			
			QXPFrk.BaseList<DRow>	__current_Break_Rows		= null;
			int						__current_PageColumn		= 0;
			//d�fini si les r�gles de r�cup�ration sont encore active
			bool					__active_Rules				= true;

			//index d'une ligne � r�p�ter
			int						__indexBreak;

			if (pageBreak)
			{
				__rules					= report.Page_Break_Rules.Get_Rules(current_Row.Level);
				__previous_PageColumn	= prp.Page - 1;
			}
			else
			{
				__rules					= report.Column_Break_Rules.Get_Rules(current_Row.Level);
				__previous_PageColumn	= prp.Column - 1;
			}
			
			#region Traitement des Rules (r�cup�ration des lignes)

			//Test de la pr�sence d'une valeur n�gatives dans les r�gles
			//Si il y � au moins une valeurs n�gatives il faudra retrouver au moins "l'absolue de cette valeur" lignes au dessus de la ligne en cours
			__nbRowsMinRetrieves = -__rules.Bring_Levels.Find(delegate(int val){return (val < 0); });

					

			//Mise � jour de certaines lignes au dessus avec les nouvelles pages en fonction des r�gles
			//Attention !!! c'est un reverse donc les lignes sont mises � jour de bas en haut
			foreach(DRow __row in table_Rows.Get_Reverse_Enumerable(current_Row))
			{
				//si ce n'est pas une row en page break (rep�tition entete) 
				//on r�cup�re les lignes d�finis par les rules
				if (!IsRowBreak(__row))
				{

					if (pageBreak)
					{
						//D�fini la page de la ligne en cours
						__current_PageColumn	= current_Row.Info.Page;
					}
					else
					{
						//D�fini la colonne de la ligne en cours
						__current_PageColumn	= current_Row.Info.Column;
					}			
					
					// on met � jour la ligne si:
					// 1 - elle est la premi�re du traitement en cours
					// 2 - les r�gles sont actives && son level est d�fini comme �tant � mettre � jour (� r�cup�rer par les rules) (__row.Info.Page == __previous_Page) - Permet de mettre en place une s�curit�, on ne peut changer les pages que des lignes sur la page pr�c�dente.
					// 3 - elle est situ�e � une certaine position au dessus de la current_row (ont ignore le level dans ce cas)
					if((__row == current_Row)||(__active_Rules && __rules.Bring_Levels.Contains(__row.Level) && (__current_PageColumn == __previous_PageColumn))||(__nbRowsRetrieves < __nbRowsMinRetrieves))
					{
						
						if (pageBreak)
						{
							__current_Break_Rows	= __row.Page_Break_Rows;
						}
						else
						{
							__current_Break_Rows	= __row.Column_Break_Rows;
						}					
						
						//on conserve la derniere ligne r�cup�r� sur la nouvelle page
						__first_row = __row;

						//Ajout de la ligne dans la liste des lignes r�cup�r�e
						__rows.Add(__row);

						//on calcule la hauteur des lignes ramen�es
						__retrieves_Rows_Height += __row.Info.Height;

						//on calcule la largeur maximale des lignes ramen�es
						__retrieves_Rows_Width	= Math.Max(__retrieves_Rows_Width, __row.Info.Width);
						
						__nbRowsRetrieves++;

						__indexBreak = Index_Row_Type_Break(__current_Break_Rows, __row.Level);
						
						//Si cette ligne est du m�me level qu'un row break (ligne � r�p�ter) il faut la supprimer
						if( __indexBreak >=0)
						{
							if(!__rowlevel_Remove_Break.Contains(__row.Level)) __rowlevel_Remove_Break.Add(__row.Level);
						}
						
					}
					else
					{
						//V�rification si la ligne pr�c�dente n'est pas une ligne ayant le m�me level qu'une ligne � r�p�ter
						__indexBreak = Index_Row_Type_Break(__current_Break_Rows, __row.Level);
						
						//� partir du moment ou l'ont entre dans ce cas les r�gles Break_Rules ne sont plus actives
						__active_Rules = false;

						//Si cette ligne est du m�me level qu'un row break (ligne � r�p�ter) il faut la ligne � r�p�ter et ramener la ligne originale
						//et il faudra continuer la boucle
						if (__indexBreak >= 0)
						{
							//on conserve la derniere ligne r�cup�r� sur la nouvelle page
							__first_row = __row;

							//Ajout de la ligne dans la liste des lignes r�cup�r�e
							__rows.Add(__row);

							//on calcule la hauteur des lignes ramen�es
							__retrieves_Rows_Height += __row.Info.Height;

							//on calcule la largeur maximale des lignes ramen�es
							__retrieves_Rows_Width	= Math.Max(__retrieves_Rows_Width, __row.Info.Width);
							
							__nbRowsRetrieves++;
							
							if(!__rowlevel_Remove_Break.Contains(__row.Level)) 
								__rowlevel_Remove_Break.Add(__row.Level);

						}
						else
						{
							// aucune r�gle ne s'applique � la ligne en cours
							// donc on sort et ont met plus � jour de lignes.
							break;
						}
					}				
				}
			}

			#endregion

			#region Traitement des Breaks (R�p�tition des ent�te)
			//Pr�-traitement des lignes suivantes la ligne en cours

			//Dans le cas ou il y des rows break (r�p�tition) il faut v�rifier que les lignes suivantes ne sont pas en r�p�tition
			//si  c'est le cas il faut supprimer l'ajout des duplicate rows
			//table_rows.Get_Enumerable parcours les elements de table_rows en commencant � la ligne current_row
			foreach (DRow __row in table_Rows.Get_Enumerable(current_Row))
			{
			    //le saut peut se produire sur une row qui sera suivi d'une page break de m�me niveau qui doit �tre ignor�
			    //seulement si c'est une row qui n'est pas de type page break
			    if (!IsRowBreak(__row))
			    {
					if (pageBreak)
					{
						__current_Break_Rows = current_Row.Page_Break_Rows;
					}
					else
					{
						__current_Break_Rows = current_Row.Column_Break_Rows;
					}

					__indexBreak = Index_Row_Type_Break(__current_Break_Rows, __row.Level);
					
					//Si dans les lignes "juste en dessous de la ligne en cours" suivantes il y � une ligne avec le m�me row level qu'un ligne � r�p�t� ont supprimer la ligne � r�p�ter
					if( __indexBreak >=0)
					{
							if(!__rowlevel_Remove_Break.Contains(__row.Level))
								__rowlevel_Remove_Break.Add(__row.Level);
					}
					else
					{
						//on arr�t le test nous sommes sur une ligne normale (plus aucune row en r�p�tition n'est � supprimer)
						break;
					}			        
			    }
			}			

			//Creation d'une liste locale afin de ne pas pertuber les autres r�f�rences
			
			if (pageBreak)
			{
				__break_Rows = new QXPFrk.BaseList<DRow>(__first_row.Page_Break_Rows);
			}
			else
			{
				__break_Rows = new QXPFrk.BaseList<DRow>(__first_row.Column_Break_Rows);
			}					

			__break_Rows.RemoveAll(delegate(DRow row){return __rowlevel_Remove_Break.Contains(row.Level);});

			
			//Ajout des lignes � r�p�ter

			//S'il y � des DRow page break sur la premi�re ligne il faut les ajouter au debut de la nouvelle page/colonne
			if (__break_Rows.Count > 0)
			{
				//on r�cup�re l'index de la premi�re ligne r�cup�r�e sur la nouvelle page
				int __firstNewRowIndex = table_Rows.IndexOf(__first_row);
			    
				//Parcours des rows � r�p�ter 
				foreach (DRow __row in __break_Rows)
			    {
			        //creation d'une copie de la row page break
					__duplicate_row = Duplicate_Update_DRow(__row, prp.Page, prp.Column);

					//mise � jour des Cells 
					__duplicate_row.Cells.ForEach(delegate(DCell cell)
					{
					    //Mise � jour des positions (top) des cellules
					    cell.Info.Zone.Top = (__break_Height + prp.Task.StartAnchor.Bottom + cell.Template.Top);
					    //Mise � jour des positions (top) des cellules
					    cell.Info.Zone.Left = (left + prp.Task.StartAnchor.Right + cell.Template.Left);
					    //Mise � jour de la page sur les cellule de la ligne en cours
					    cell.Info.Page = prp.Page;
					    //Mise � jour de la page sur les cellules de la ligne en cours
					    cell.Info.Column = prp.Column;
					});
					
					//Ajoute de cette ligne dupliqu�e dans la bonne position des table_Rows
					table_Rows.Insert(__firstNewRowIndex, __duplicate_row);
					
					//Calcul de la hauteur totale des lignes de types Page Break
					__break_Height += __row.Info.Height;

					//Calcul de la largeur maximale des lignes de types Page Break
					__break_Width	= Math.Max(__break_Width, __row.Info.Width);

				}
			}

			decimal __top = __break_Height;

			//Tr�s important il faut savoir s'il y aura assez de place sur la nouvelle page pour acceuillir tout le monde 
			//et surtout il faut ajouter la hauteur de la ligne qui � cr��er la rupture
			if ((__retrieves_Rows_Height + __top + current_Row.Info.Height) < prp.Available_Height)
			{
				//Mise � jour des position top des lignes
				//Attention !!! c'est un reverse de reverse donc les lignes sont mise � jour de haut en bas
				foreach (DRow __row in __rows.Get_Reverse_Enumerable())
				{
					// Mise � jour de la page de la ligne
					__row.Info.Page = prp.Page;
					// Mise � jour de la colonne de la ligne
					__row.Info.Column = prp.Column;

					//mise � jour des Cells 
					__row.Cells.ForEach(delegate(DCell cell)
					{
						//Mise � jour des positions (top) des cellules
						cell.Info.Zone.Top = (__top + prp.Task.StartAnchor.Bottom + cell.Template.Top);
						//Mise � jour des positions (top) des cellules
						cell.Info.Zone.Left = (left + prp.Task.StartAnchor.Right + cell.Template.Left);
						//Mise � jour de la page sur les cellule de la ligne en cours
						cell.Info.Page = prp.Page;
						//Mise � jour de la page sur les cellules de la ligne en cours
						cell.Info.Column = prp.Column;
					});
					/* on ajoute la hauteur de la ligne en cours*/
					__top += __row.Info.Height;
				}
			}
			else
			{
				//On met � jour tout de m�me la ligne qui � d�clench�e le saut mais aucune autre lignes n'est mise � jour
				
				// Mise � jour de la page de la ligne
				current_Row.Info.Page = prp.Page;
				// Mise � jour de la colonne de la ligne
				current_Row.Info.Column = prp.Column;

				//mise � jour des Cells 
				current_Row.Cells.ForEach(delegate(DCell cell)
				{
					//Mise � jour des positions (top) des cellules
					cell.Info.Zone.Top = (__top + prp.Task.StartAnchor.Bottom + cell.Template.Top);
					//Mise � jour des positions (top) des cellules
					cell.Info.Zone.Left = (left + prp.Task.StartAnchor.Right + cell.Template.Left);
					//Mise � jour de la page sur les cellule de la ligne en cours
					cell.Info.Page = prp.Page;
					//Mise � jour de la page sur les cellules de la ligne en cours
					cell.Info.Column = prp.Column;
				});

				/* on ajoute la hauteur de la ligne en cours*/
				__top += current_Row.Info.Height;

				
				prp.Task.Run.Errors.Add(Constantes.Error_Messages.BreakRuleIgnored, (pageBreak?prp.Task.Page_Break_Rules.Values:prp.Task.Column_Break_Rules.Values), pageBreak, prp.Page, prp.Column, prp.Task.ID);
			}
			#endregion

			//Mise � jour des r�sultats
			prp.Current_Table_Height	= __top;
			prp.Current_Table_Width		= Math.Max(__break_Width, __retrieves_Rows_Width);
			prp.Nb_Rows_Added			= __break_Rows.Count;


		}
		
		/// <summary>
		/// Permet de v�rifier si la ligne en cours est du m�me level qu'une des lignes en r�p�ter
		/// </summary>
		/// <param name="page_Break_Rows">la liste des page break rows</param>
		/// <param name="row_level">le level � v�rifier</param>
		/// <returns>l'index du page break ou -1 si elle n'existe pas</returns>
		static int Index_Row_Type_Break(QXPFrk.BaseList<DRow> break_Rows, int row_level)
		{
			return break_Rows.FindIndex(delegate(DRow row)
													{
														return (row.Level == row_level);
													});
		}
		/// <summary>
		/// Permet de tester si la ligne est une ligne de r�p�tition (Saut de Page (si PageBreak = true) ou Saut de Colonne (si PageBreak = false))
		/// </summary>
		/// <param name="row">La ligne � tester</param>
		/// <returns></returns>
		static bool IsRowBreak(DRow row)
		{
			return row.Page_Break || row.Column_Break;
		}

		/// <summary>
		/// duplication d'une ligne de type page break
		/// </summary>
		/// <param name="row">la ligne � cloner</param>
		/// <param name="page">nouvelle ligne</param>
		/// <param name="column">nouvelle colonne</param>
		/// <returns>la nouvelle DRow</returns>
		static DRow Duplicate_Update_DRow(DRow row, int page, int column)
		{
			DRow __newRow = row.Clone();
			//Mise � jour de la page
			__newRow.Info.Page = page;
			//Mise � jour de la colonne
			__newRow.Info.Column = column;
			foreach (DCell __cell in __newRow.Cells)
			{
				//Mise � jour de la page
				__cell.Info.Page = page;
				//Mise � jour de la Colonne
				__cell.Info.Column = column;
			}
			return __newRow;
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
