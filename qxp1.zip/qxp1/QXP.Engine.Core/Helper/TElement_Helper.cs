using System;
using System.Collections.Generic;
using QXPDiagnostic		= QXP.Framework.Diagnostic;
using QXPFrk			= QXP.Framework;
using QXPSerialization	= QXP.Framework.Serialization;
using QXPSMSDK		    = com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet d'effectuer diverse op�rations sur les TElements lors de la g�n�ration des blocs
	/// </summary>
	/// <author>doufarm</author>
	/// <date>02/04/2010 16:28:07</date>    
	public class TElement_Helper
	{
		#region Membres
		static Dictionary<string, string>					__serialization_cache	= new Dictionary<string,string>();
		static Dictionary<Static_TElement_Name, TElement>	__elements				= new Dictionary<Static_TElement_Name, TElement>();
		#endregion Membres

		#region Constantes
		const string	NewBlocPattern		= "{0:N}";
		const string	DataBlocPattern		= "C_";
		const int		NewBlocNameSize		= 29;
		/// <summary>
		/// D�fini les types d'empilements autoris� pour les bloc
		/// </summary>
		public class StackingOrder
		{
			/// <summary>
			/// Envoi du bloc en arri�re
			/// </summary>
			public const string SENDBACKWARD	= "SENDBACKWARD";
			/// <summary>
			/// Envoi du bloc tout en bas
			/// </summary>
			public const string SENDTOBACK		= "SENDTOBACK";
			/// <summary>
			/// Avancer le bloc en avant
			/// </summary>
			public const string BRINGFORWARD	= "BRINGFORWARD";
			/// <summary>
			/// Avancer le bloc devant
			/// </summary>
			public const string BRINGTOFRONT	= "BRINGTOFRONT";
		}
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static TElement_Helper
		/// </summary>
		static TElement_Helper()
		{
			try
			{
				LoadStaticElements();
			}
			catch(Exception ex)
			{
				QXPDiagnostic.Log.LogError("Unable to load StaticElements", ex);
			}
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet d'obtenir des bloc_box � partir d'une DCell
		/// </summary>
		/// <param name="cell">la cellule dans laquelle il faut r�cup�rer les blocs</param>
		/// <param name="task">la tache associ�e</param>
		/// <returns>un bloc_box ou un bloc_group</returns>
		public static Bloc_Base Get_Bloc(DCell cell, Task_Dynamique task)
		{
			if(cell.TElement is TBox)
			{
				//Nouvelle TBox
				TBox	__tBox = null;
				
				__tBox = Clone<TBox>(cell.TElement);

				//Obtenir le bloc_Box � partir du bloc box en cours
				return Update_And_Get_Bloc_Box(__tBox, cell, task);
			}
			else if(cell.TElement is TGroup)
			{
				//Nouveau TGroup
				TGroup __tGroup = Clone<TGroup>(cell.TElement);
				
				return Update_And_Get_Bloc_Group(__tGroup, cell, task);
			}
			else
			{
				//g�n�rer une erreur
				return null;
			}
		}

		/// <summary>
		/// Permet d'�valuer le TElement associ� au template de la cellule. 
		/// Il faut toujours evaluer l'overflow sur la DCell avant d'appeller cette methode (afin de selection le bon src_name ou src_name_overflow)
		/// </summary>
		/// <param name="task">la tache contenant les TElements</param>
		/// <param name="cell">la cellule contenant les informations permettant de retrouver le TElement.</param>
		/// <returns></returns>
		public static TElement	Evaluate_TElement(Task_Dynamique task, DCell cell)
		{
			string		__src_Name	= null;
			TElement	__tElement	= null;
			
			QXP_Project __qxp_Project = task.Run.Gabarit_Template.QXPProject;
			
			if (cell.Overflow)
			{
				__src_Name = cell.Template.Src_Name_Overflow;
			}
			else
			{
				__src_Name = cell.Template.Src_Name;
			}


			//Le template element existe
			if(__qxp_Project.Elements.ContainsKey(__src_Name))
			{
				__tElement		= __qxp_Project.Elements[__src_Name];
			}
			//Le template element n'existe pas
			else
			{
				task.Run.Errors.Add(Constantes.Error_Messages.ElementTemplateMissing, __src_Name, string.Join("/", cell.NewNames.ToArray()));
			}

			return __tElement;
		
		}
		/// <summary>
		/// Permet de r�cup�rer une copie d'un TElement utilis� par certaines taches (exemple PDF)
		/// </summary>
		/// <param name="tElement_Name">nom de l'�l�ment souhait�</param>
		/// <param name="newName">nouveau nom � appliquer � l'�l�ment souhait�e</param>
		/// <returns>une copie de l'�l�ment souhait�</returns>
		public static TElement	Get_TElement(Static_TElement_Name tElement_Name, string newName)
		{
			TElement __tElement = Get_Default_TElement(tElement_Name);
			__tElement.Name = newName;
			if(__tElement is TBox)
			{
				TBox __tBox = Clone<TBox>(__tElement);
				__tBox.SrcBox.name = newName;
				//Traitement �ventuel de la boite Extra
				if(QXPFrk.Validation.IsNotNull(__tBox.SrcExtraBox))
				{
					__tBox.SrcExtraBox.name = newName;
				}
				return __tBox;
			}
			else if(__tElement is TGroup)
			{
				//Nouveau TGroup
				return Clone<TGroup>(__tElement);
			}
			else if(__tElement is TTable)
			{
				//Nouveau TTable
				return Clone<TTable>(__tElement);
			}
			else
			{
				//g�n�rer une erreur
				return null;
			}
		
		}

		/// <summary>
		/// Permet d'obtenir une structure de paragraph par d�faut visuellement agressive mettant en �vidence un probl�me dans le gabarit_template
		/// </summary>
		/// <returns>une liste de paragraph quark contenent un style par d�faut</returns>
		public static QXPSMSDK.Paragraph[] Get_Warning_Paragraph()
		{
			QXPSMSDK.Paragraph[] __paragraphs = new QXPSMSDK.Paragraph[]{new QXPSMSDK.Paragraph()};
			__paragraphs[0].richText = new QXPSMSDK.RichText[]{new QXPSMSDK.RichText()};
			QXPSMSDK.RichText  __richText = __paragraphs[0].richText[0];
			__richText.bold		= "true";
			__richText.color	= "Rouge";
			
			return __paragraphs;
		}

		#region Gestion des TBox
		
		/// <summary>
		/// Mise � jour des positions et des valeurs de la Box dans le TBox � partir des param�tres dans le DCell
		/// </summary>
		/// <param name="tBox">le template de la Box � mettre � jour</param>
		/// <param name="cell">la cellule associ� � ce template</param>
		static void Update_TElement(TBox tBox, DCell cell)
		{
			
			// 1 - Mise � jour de la valeur et du nom du bloc

			//OK
			if(cell.NewNames.Count == 1)
			{
				string __newName	= cell.NewNames[0];
				string __newValue	= cell.Values[0];

				TElement_Helper.Update_Name_Value(tBox, __newName, __newValue);
			}
			else
			{
				Exception_Helper.Raise_Exception(new Exception_TElement(Exception_TElement.MSG_TElement_Need_One_Name, cell.TElement.Name));
			}

			// 2 - Mise � jour de la position de la boite
			Update_Position(tBox, cell);

		}


		/// <summary>
		/// Mise � jour des position de la boite
		/// </summary>
		/// <param name="tBox">le template de la Box � mettre � jour</param>
		/// <param name="cell">la cellule associ� � ce template</param>
		static void Update_Position(TBox tBox, DCell cell)
		{
			QXPSMSDK.Box __srcBox = tBox.SrcBox;
			if(QXPFrk.Validation.IsNotNull(__srcBox)
				&& QXPFrk.Validation.IsNull(__srcBox.geometry))
			{

				__srcBox.geometry = new QXPSMSDK.Geometry();
			}

			//Mise � jour du z-order (stacking order) de la boite (si c'est une boite absolue elle doit �tre devant les relatives)
			if(cell.Template.Absolute)
			{
				__srcBox.geometry.stackingOrder	= StackingOrder.BRINGTOFRONT;
			}

			DZone __zone = cell.Info.Zone;
			
			__srcBox.geometry.position.left		= QXPFrk.ConversionInvariante.ToString(__zone.Left);
            __srcBox.geometry.position.top      = QXPFrk.ConversionInvariante.ToString(__zone.Top);

            __srcBox.geometry.position.right    = QXPFrk.ConversionInvariante.ToString(__zone.Left + __zone.Width);
            __srcBox.geometry.position.bottom   = QXPFrk.ConversionInvariante.ToString(__zone.Top + __zone.Height);
		
		}

		/// <summary>
		/// Mise � jour de la position et des valeurs des boites contenues dans le groupe
		/// </summary>
		/// <param name="tGroup">le template du groupe de boite � mettre � jour</param>
		/// <param name="cell">la cellule asoci�e au template de groupe</param>
		static void					Update_Position(TGroup tGroup, DCell cell)
		{
			//Calcul des d�placements relative
			decimal				__relative_top;
			decimal				__relative_left;
			DZone				__zone		= cell.Info.Zone;

			//Pour l'instant on traite les d�placement relatif mais pas le changement d'�chelle
			__relative_top	= __zone.Top - tGroup.Top;
			__relative_left	= __zone.Left - tGroup.Left;
			
			if(QXPFrk.Validation.IsNotNull(tGroup)
				&& QXPFrk.Validation.IsSet(tGroup.SrcBoxes))
			{
				foreach(QXPSMSDK.Box __box in tGroup.SrcBoxes)
				{
					if(QXPFrk.Validation.IsNotNull(__box)
						&& QXPFrk.Validation.IsNotNull(__box.geometry))
					{
						
						//Mise � jour du z-order (stacking order) de la boite (si c'est une boite absolue elle doit �tre devant les relatives)
						if(cell.Template.Absolute)
						{
							__box.geometry.stackingOrder	= StackingOrder.BRINGTOFRONT;
						}

						//On traite tous les types de boites

                        __box.geometry.position.left    = QXPFrk.ConversionInvariante.ToString(QXPFrk.ConversionInvariante.ToDecimal(__box.geometry.position.left) + __relative_left);
                        __box.geometry.position.top     = QXPFrk.ConversionInvariante.ToString(QXPFrk.ConversionInvariante.ToDecimal(__box.geometry.position.top) + __relative_top);

                        __box.geometry.position.right   = QXPFrk.ConversionInvariante.ToString(QXPFrk.ConversionInvariante.ToDecimal(__box.geometry.position.right) + __relative_left);
                        __box.geometry.position.bottom  = QXPFrk.ConversionInvariante.ToString(QXPFrk.ConversionInvariante.ToDecimal(__box.geometry.position.bottom) + __relative_top);
					}
					else
					{
						Exception_Helper.Raise_Exception(new Exception_TElement(Exception_TElement.MSG_Invalid_Box_Group_Or_Geometry, cell.TElement.Name));
					}
				}
			}
		}

		/// <summary>
		/// Mise � jour du nom du bloc et de la valeur du bloc
		/// </summary>
		/// <param name="tBox">Le TBox qui contient les �l�ments � mettre � jour</param>
		/// <param name="new_name">le nouveau nom</param>
		/// <param name="new_value">la nouvelle valeur</param>
		static void					Update_Name_Value(TBox tBox, string new_name, string new_value)
		{
			QXPSMSDK.Box __srcBox = tBox.SrcBox;

			if(QXPFrk.Validation.IsNotNull(__srcBox))
			{
				if(QXPFrk.Validation.IsNotNull(__srcBox.text)
				&& QXPFrk.Validation.IsNotNull(__srcBox.text.story))
				{
					if(QXPFrk.Validation.IsNotSet(__srcBox.text.story.paragraphs)
					|| QXPFrk.Validation.IsNotSet(__srcBox.text.story.paragraphs[0].richText))
					{
						__srcBox.text.story.paragraphs = Get_Warning_Paragraph();
					}
					__srcBox.text.story.paragraphs[0].richText[0].value = new_value;
				}
				__srcBox.name	= new_name;
				tBox.Name		= new_name;
			}
			else
			{
				Exception_Helper.Raise_Exception(new Exception_TElement(Exception_TElement.MSG_SrcBox_NULL, new_name));
			}
		}

		/// <summary>
		/// Mise � jour des noms de blocs et leurs valeurs du groupe
		/// </summary>
		/// <param name="tGroup">Le TGroup qui contient les �l�ments � mettre � jour</param>
		/// <param name="new_names">les nouveaux noms</param>
		/// <param name="new_values">les nouvelles valeurs</param>
		static void					Update_Name_Value(TGroup tGroup, string[] new_names, string[] new_values)
		{
			foreach(QXPSMSDK.Box __box in tGroup.SrcBoxes)
			{
				if(QXPFrk.Validation.IsNotNull(__box))
				{
					//on ne traite que les box en CT_TEXT ou CT_PICTURE !! pas les CT_NONE
					if(__box.boxType != TBox_Type.CT_NONE.ToString())
					{
						int		__index		= int.MinValue;
					    string	__boxName	= __box.name;

						//on test si le bloc peut contenir des donn�es et on recherche l'index des donn�es � utiliser
						if(QXPFrk.Validation.IsSet(__boxName) && __boxName.StartsWith(DataBlocPattern))
						{
							__index = GetIndexBox(__boxName);
							//L'index est pr�sent dans le nom
							if(QXPFrk.Validation.IsSet(__index))
							{
								//s�curit� on ne cherche pas � r�cup�rer un nom qui n'existe pas dans la liste des new_names
								if(__index < new_names.Length)
								{
									__box.name	= new_names[__index];
									if (QXPFrk.Validation.IsNotNull(__box.text)
									&& QXPFrk.Validation.IsNotNull(__box.text.story))
									{
										if (QXPFrk.Validation.IsNotSet(__box.text.story.paragraphs)
										|| QXPFrk.Validation.IsNotSet(__box.text.story.paragraphs[0].richText))
										{
											__box.text.story.paragraphs = Get_Warning_Paragraph();
										}
										__box.text.story.paragraphs[0].richText[0].value = new_values[__index];
									}
									else
									{
										Exception_Helper.Raise_Exception(new Exception_TElement(Exception_TElement.MSG_Invalid_Box_Structure, __boxName));
									}
								}
								else
								{
									Rename_Bloc(__box);								
								}
							}
							else
							{
								Exception_Helper.Raise_Exception(new Exception_TElement(Exception_TElement.MSG_Invalid_Box, __boxName));
							}
						}
						else
						{
							Rename_Bloc(__box);
						}
						
					}
					else
					{
						Rename_Bloc(__box);
					}
				}
			}
			//nous donnons au groupe le nom de la premiere boite du groupe
			if (new_names.Length > 0)
			{
				tGroup.Name = new_names[0];
			}
		}


		/// <summary>
		/// Permet de renommer s�quentiellement un bloc afin de ne pas avoir de doublons dans les blocs cr�� � partir des m�mes templates
		/// </summary>
		/// <param name="box">la boite � renommer</param>
		static void Rename_Bloc(QXPSMSDK.Box box)
		{
			box.UID  = string.Empty;
			box.name = NewBlocName();
		}

		/// <summary>
		/// Afin de g�n�rer des identifiants uniques pour tous les blocs nomm�s on utilisera cette methode qui garantie un nom unique
		/// la taille du nouveau nom est de 30 caract�res
		/// </summary>
		/// <returns>un nom de boite unique</returns>
		public static string				NewBlocName()
		{
			return QXPFrk.StringHelper.HookString(QXPFrk.StringHelper.Left(string.Format(NewBlocPattern, Guid.NewGuid()), NewBlocNameSize));
		}

		/// <summary>
		/// Permet de retrouver la valeur de l'index dans le nom du bloc qui doit avoir le pattern C_X_Y. 
		/// ou X est l'index (exemple C_0_Group1) ou l'index est �gal � 0.
		/// </summary>
		/// <param name="boxName">le nom de la boite � analyser</param>
		/// <returns>l'index de la boite</returns>
		static int GetIndexBox(string boxName)
		{
			//Les v�rifications avant !!
			if(boxName.Length < 5) return int.MinValue; // C_X_Y est la chaine minimum ou X est la valeur recherch�e

			//on exclu les 2 premiers caract�res puis on prend jusqu'au premier underscore
			string __sub_str	= boxName.Substring(2);
			string __index		= __sub_str.Substring(0, __sub_str.IndexOf('_'));
			
			return QXPFrk.Conversion.ToInt(__index);
			
			
		}
		/// <summary>
		/// Mise � jour d'un template de boite et retourne un bloc_box 
		/// </summary>
		/// <param name="tBox">le template de boite � utiliser</param>
		/// <param name="cell">la cellule associ�e au template de boite</param>
		/// <param name="task">la tache en cours</param>
		/// <returns>un bloc_box � jour</returns>
		static Bloc_Box	Update_And_Get_Bloc_Box(TBox tBox, DCell cell, Task_Dynamique task)
		{
			
			Bloc_Box	__bloc_Box	= null;
			//Mise � jour du TBox
			Update_TElement(tBox, cell);

			__bloc_Box					= new Bloc_Box(task, tBox.Name, tBox);
			__bloc_Box.Action			= Bloc_Action.CREATE;
			__bloc_Box.Relative_Page	= cell.Info.Page - 1; //Les page relative sont index 0

			return __bloc_Box;
		}


		#endregion

		#region Gestion des TGroup
		/// <summary>
		/// Mise � jour des positions des Box dans le TGroup � partir des param�tres dans le DCell
		/// </summary>
		/// <param name="tGroup">un template de groupe</param>
		/// <param name="cell">la cellule associ�e au groupe</param>
		static void			Update_TElement(TGroup tGroup, DCell cell)
		{
			// 1 - Mise � jour des valeurs et des noms de blocs

			//OK
			if(cell.NewNames.Count > 0)
			{
				try
				{
					TElement_Helper.Update_Name_Value(tGroup, cell.NewNames.ToArray(), cell.Values.ToArray());
				}
				catch(Exception ex)
				{
					Exception_Helper.Raise_Exception(new Exception_TElement(ex, Exception_TElement.MSG_TElement_UpdateNamesValues, cell.TElement.Name));					
				}
			}
			else
			{
				Exception_Helper.Raise_Exception(new Exception_TElement(Exception_TElement.MSG_TElement_Need_Name, cell.TElement.Name));
			}

			// 2 - Mise � jour de la position de la boite
			TElement_Helper.Update_Position(tGroup, cell);
			
		}
		
		/// <summary>
		/// Mise � jour du template de group et retourne ensuite un bloc_group
		/// </summary>
		/// <param name="tGroup">le template de groupe</param>
		/// <param name="cell">la cellule associ�e au template de groupe</param>
		/// <param name="task">la tache en cours</param>
		/// <returns>un bloc group � jour</returns>
		static Bloc_Group	Update_And_Get_Bloc_Group(TGroup tGroup, DCell cell, Task_Dynamique task)
		{
			Bloc_Group __bloc_Group = null;
			
			//Mise � jour des positions
			Update_TElement(tGroup, cell);

			__bloc_Group					= new Bloc_Group(task, tGroup.Name, tGroup.SrcBoxes);
			__bloc_Group.Action				= Bloc_Action.CREATE;
			__bloc_Group.Relative_Page		= cell.Info.Page - 1; //Les page relative sont index 0

			return __bloc_Group;
		}

		#endregion

		#region Bloc_Box
		
		/// <summary>
		/// Obtient le bloc box permettant le deplacement de l'ancienne ancre
		/// </summary>
		/// <param name="anchor">l'ancre � d�placer</param>
		/// <param name="new_relative_page">la nouvelle position relative de l'ancre</param>
		/// <returns>Le bloc permettant le d�placement de l'ancre</returns>
		public static Bloc_Box Get_Move_Anchor(Task_Anchor task, DBloc_Info anchor, int new_relative_page)
		{
			TBox		__tBox = TElement_Helper.Get_TElement(Static_TElement_Name.MOVE_BLOC, anchor.Name) as TBox;
            QXPSMSDK.Box __box = __tBox.SrcBox;
			
			//Pour d�placer un bloc il faut au minimum les informations suivantes + __box.geometry.page (qui est d�finit plus tard dans le QXPS_Modifier)
			__box.geometry.position.left	= anchor.Left.ToString();
			__box.geometry.position.top		= anchor.Top.ToString();
			__box.geometry.position.right	= anchor.Right.ToString();
			__box.geometry.position.bottom	= anchor.Bottom.ToString();
			__box.UID						= anchor.UID;

			Bloc_Box	__bloc = new Bloc_Box(task, __tBox.SrcBox.name, __tBox);
			
			//Indique un deplacement de bloc
			__bloc.Action				= Bloc_Action.MOVE;
			__bloc.Relative_Page		= new_relative_page;

			return __bloc;		
		}

		/// <summary>
		/// Obtient le bloc box permettant le deplacement d'un ancien element
		/// </summary>
		/// <param name="task">la tache qui � besoin de cette element</param>
		/// <param name="tElement_Name">le type de Telement n�cessaire</param>
		/// <param name="new_Name">le nom de l'�l�ment</param>
		/// <param name="new_relative_page">la nouvelle position relative de l'element</param>
		/// <returns>Le bloc permettant le d�placement de l'element</returns>
		public static Bloc_Box Get_Bloc_AndMove(Task_Base task, Static_TElement_Name tElement_Name, string name, int new_relative_page)
		{
			TBox		__tBox = TElement_Helper.Get_TElement(tElement_Name, name) as TBox;
			QXPSMSDK.Box	__box			= __tBox.SrcBox;
			QXPSMSDK.Box	__extra_box		= __tBox.SrcExtraBox;
			
			DBloc_Info	__info = task.Get_Bloc_Info(name);

			if (QXPFrk.Validation.IsSet(__info.UID))
			{
				//Pour d�placer un bloc il faut au minimum les informations suivantes + __box.geometry.page (qui est d�finit plus tard dans le QXPS_Modifier)
				__box.geometry.position.left = __info.Left.ToString();
				__box.geometry.position.top = __info.Top.ToString();
				__box.geometry.position.right = __info.Right.ToString();
				__box.geometry.position.bottom = __info.Bottom.ToString();
				__box.UID = __info.UID;
				if (QXPFrk.Validation.IsNotNull(__extra_box))
				{
					__extra_box.UID = __info.UID;
				}
			}

			Bloc_Box	__bloc = new Bloc_Box(task, __tBox.SrcBox.name, __tBox);
			
			//Indique un deplacement de bloc
			__bloc.Action				= Bloc_Action.MOVE;
			__bloc.Relative_Page		= new_relative_page;
			//C'est toujours � effectuer dans l'�tape de pagination du modify sinon le bloc serait supprimer dans la pagination et ne pourrait plus �tre d�plac�
			__bloc.Pagination			= true;

			return __bloc;		
		}

		/// <summary>
		/// Obtient le bloc box permettant la creation d'un element
		/// </summary>
		/// <param name="task">la tache qui � besoin de cette element</param>
		/// <param name="tElement_Name">le type de Telement n�cessaire</param>
		/// <param name="new_Name">le nom de l'�l�ment</param>
		/// <param name="new_relative_page">la nouvelle position relative de l'element</param>
		/// <returns>Le bloc box permettant la creation de l'element</returns>
		public static Bloc_Box Get_Bloc_AndCreate(Task_Base task, Static_TElement_Name tElement_Name, string name, int new_relative_page)
		{
			TBox		__tBox = TElement_Helper.Get_TElement(tElement_Name, name) as TBox;
            QXPSMSDK.Box __box = __tBox.SrcBox;
			
			Bloc_Box	__bloc = new Bloc_Box(task, __tBox.SrcBox.name, __tBox);
			
			//Indique un deplacement de bloc
			__bloc.Action				= Bloc_Action.CREATE;
			__bloc.Relative_Page		= new_relative_page;

			return __bloc;		
		}

		#endregion

		/// <summary>
		/// Permet de charger les Telement utilis�s par certaines taches (exemple PDF)
		/// </summary>
		static void LoadStaticElements()
		{
			QXPSMSDK.Box		__box; //boite
			QXPSMSDK.Box		__boxExtra; //boite n�cessaire � certaine op�ration
			QXPSMSDK.Picture	__picture;
			QXPSMSDK.Table		__table; //table

			//La plus simple des boites ^^
			#region Empty Box 
			__box			= new QXPSMSDK.Box();
			
			__elements.Add(Static_TElement_Name.EMPTY_BLOC, new TBox(__box));
			#endregion

			#region IMG
			__box			= new QXPSMSDK.Box();
			__picture		= new QXPSMSDK.Picture();
            __box.content	= new QXPSMSDK.Content();
            __picture.fit	= "FITPICTURETOBOXPRO";
            __box.picture	= __picture;

			//Le m�me template �l�ments est utilis� pour les taches File_IMG
			__elements.Add(Static_TElement_Name.IMG, new TBox(__box));

			#endregion

			#region PDF 

			__box							= new QXPSMSDK.Box();
			__picture						= new QXPSMSDK.Picture();
            __box.content					= new QXPSMSDK.Content();
            __picture.fit					= "FITPICTURETOBOXPRO";
            __box.picture					= __picture;
			__box.geometry					= new QXPSMSDK.Geometry();

			//Permet de d�placer la boite en dehors des limites de la page
			__box.geometry.allowBoxOffPage			= "true";
			__box.geometry.allowBoxOnToPasteboard	= "true";

			//permettra a la boite pdf d'effectuer un d�calage offset eventuellement
			__boxExtra			= new QXPSMSDK.Box();
            __boxExtra.picture	= new QXPSMSDK.Picture();

            //Le template est utilis� pour les taches File_PDF
			__elements.Add(Static_TElement_Name.PDF_1, new TBox(__box, __boxExtra));

			/* **** */
			//Nouvelle box pour les blocs de 2 � N
			/* **** */

			__box			= new QXPSMSDK.Box();
            __box.content	= new QXPSMSDK.Content();
            __picture		= new QXPSMSDK.Picture();
			__box.geometry	= new QXPSMSDK.Geometry();
            __picture.fit	= "FITPICTURETOBOXPRO";
            __box.picture	= __picture;
			
			//Pas d'habillage pour les boites pdf
		    __box.geometry.runaround = new QXPSMSDK.Runaround();
		    __box.geometry.runaround.type = "NONE";

			//boite image
			__box.boxType					= TBox_Type.CT_PICT.ToString();
		    __box.geometry.position			= new QXPSMSDK.Position();
			//__box.geometry.position.left	= "42,52";
			//__box.geometry.position.top		= "56,693";
			//__box.geometry.position.bottom	= "785,197";
			//__box.geometry.position.right	= "552,756";

			//permettra a la boite pdf d'effectuer un d�calage offset eventuellement
			__boxExtra			= new QXPSMSDK.Box();
            __boxExtra.picture	= new QXPSMSDK.Picture();

			__elements.Add(Static_TElement_Name.PDF_N, new TBox(__box, __boxExtra));

			#endregion PDF / IMG

			#region RTF/XTG/DOC
			
			__box			= new QXPSMSDK.Box();
            __box.content	= new QXPSMSDK.Content();
            __box.content.convertQuotes = "true";
            __box.content.includeStyleSheets = "true";
			
			__elements.Add(Static_TElement_Name.RTF_DOC_XTG, new TBox(__box));
			
			#endregion RTF/XTG/DOC

			#region Move Bloc
			
			//C'est vraiment une boite tr�s simple elle ne modifie que la geometry de la boite destination
			__box							= new QXPSMSDK.Box();
			__box.geometry					= new QXPSMSDK.Geometry();
			__box.geometry.position			= new QXPSMSDK.Position();
			//Permet de d�placer la boite en dehors des limites de la page
			__box.geometry.allowBoxOffPage			= "true";
			__box.geometry.allowBoxOnToPasteboard	= "true";
			
			__elements.Add(Static_TElement_Name.MOVE_BLOC, new TBox(__box));

			#endregion
			
			#region Move Bloc With Value
			
			//C'est vraiment une boite tr�s simple elle ne modifie que la valeur et la geometry de la boite destination 
			__box							= new QXPSMSDK.Box();
			__box.geometry					= new QXPSMSDK.Geometry();
			__box.geometry.position			= new QXPSMSDK.Position();
			//Permet de d�placer la boite en dehors des limites de la page
			__box.geometry.allowBoxOffPage			= "true";
			__box.geometry.allowBoxOnToPasteboard	= "true";
			//Zone de contenue de la valeur
			__box.content					= new QXPSMSDK.Content();
			
			__elements.Add(Static_TElement_Name.MOVE_BLOC_VALUE, new TBox(__box));

			#endregion

			#region Empty Table
			__table			= new QXPSMSDK.Table();
			
			__elements.Add(Static_TElement_Name.EMPTY_TABLE, new TTable(__table));
			#endregion
		}

		/// <summary>
		/// Permet de r�cup�rer une TBox ne contenant que les styles et les valeurs de la boite srcBox !!
		/// </summary>
		/// <param name="srcTBox">l'ancien TBox (source)</param>
		/// <param name="newName">le nouveau nom de la TBox</param>
		/// <returns>la nouvelle TBox</returns>
		public static TBox Get_New_TBox_StyleValue_From_TBox(TBox srcTBox, string newName)
		{
			//TBox de destination
			TBox				__destTBox	= Get_TElement(Static_TElement_Name.EMPTY_BLOC, newName) as TBox;

			if (QXPFrk.Validation.IsNull(__destTBox))
			{
				//invalid TBox type
				return null;
			}

			QXPSMSDK.Box	__srcBox	= srcTBox.SrcBox;
			QXPSMSDK.Box	__destBox	= __destTBox.SrcBox;

			//Transfert des informations de la TBoxSource � la TBoxDestination

			switch (srcTBox.Type)
            {
                case TBox_Type.CT_TEXT:
					__destBox.boxType	= TBox_Type.CT_TEXT.ToString();

                    if (QXPFrk.Validation.IsNotNull(__srcBox.text.story))
                    {
						__destBox.text						= __srcBox.text;
						__destBox.text.story.clearOldText	= "true";

                        // si le bloc de texte possede une reference de linkedBox, on le supprime car le document de destination possede deja cette information de liaison, 
                        // il n'est pas necessaire de la reprendre. De plus si la destination ne possede pas la meme liaison, la generation plantera
                        __destBox.text.story.linkedBoxes	= null;
                    }

                    break;
                case TBox_Type.CT_PICT:
					__destBox.boxType	= TBox_Type.CT_PICT.ToString();
					
					__destBox.picture	= __srcBox.picture;
					__destBox.content	= __srcBox.content;
                    
					break;
            }

			return __destTBox;
		}

		/// <summary>
		/// Permet de r�cup�rer une TTable ne contenant que les styles et les valeurs de la table srcTable !!
		/// </summary>
		/// <param name="srcTTable">l'ancienne TTable (source)</param>
		/// <param name="newName">le nouveau nom de la TTable</param>
		/// <returns>la nouvelle TTable</returns>
		public static TTable Get_New_TTable_StyleValue_From_TTable(TTable srcTTable, string newName)
		{
			//TTable de destination
			TTable				__destTTable	= Get_TElement(Static_TElement_Name.EMPTY_TABLE, newName) as TTable;

			if (QXPFrk.Validation.IsNull(__destTTable))
			{
				//invalid TTable type
				return null;
			}

			QXPSMSDK.Table	__srcTable	= srcTTable.SrcTable;
			QXPSMSDK.Table	__destTable	= __destTTable.SrcTable;

			//Transfert des informations de la TTableSource � la TTableDestination
			
			//On laisse quark adapter la g�om�trie du tableau
			__destTTable.SrcTable.maintainGeometry = "false";

            if(QXPFrk.Validation.IsSet(__srcTable.rows))
			{
				__destTTable.SrcTable.rows = __srcTable.rows;
				
				foreach (QXPSMSDK.Row row in __destTTable.SrcTable.rows)
				{
					//Permet de corriger un bug de QXP server 7.24 qui g�n�re parfois une ligne avec cells = NULL
					if(QXPFrk.Validation.IsSet(row.cells))
					{
						foreach (QXPSMSDK.Cell cell in row.cells)
						{
							//�tant en mode mise � jour il ne faut pas fusionner l'ancien contenu avec le nouveau contenu
							if (QXPFrk.Validation.IsNotNull(cell.text) && QXPFrk.Validation.IsNotNull(cell.text.story))
								cell.text.story.clearOldText = "true";
						}
					}
				}
			}

			return __destTTable;
		}


		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// Cette op�ration permet de cloner un TElement ce qui permettra de modifier ses propri�t�s sans modifier tous les Telement du m�me type
		/// </summary>
		/// <typeparam name="T">le Type de TElement � cloner</typeparam>
		/// <param name="tElement">l'�lement � cloner</param>
		/// <returns>le nouvelle �l�ment identique � tElement</returns>
		static T Clone<T>(TElement tElement) where T: TElement
		{
			string __serialized_TElement;
			if(__serialization_cache.ContainsKey(tElement.Name))
			{
				__serialized_TElement = __serialization_cache[tElement.Name];
			}
			else
			{
				__serialized_TElement = QXPSerialization.Serializer.Serialize(tElement);
				__serialization_cache.Add(tElement.Name, __serialized_TElement);
			}
			return QXPSerialization.Serializer.Deserialize(__serialized_TElement, typeof(T)) as T;
			
		}

		/// <summary>
		/// R�cup�ration d'un TElement static par sont nom.
		/// </summary>
		/// <param name="element_Name">nom de l'�l�ment.</param>
		/// <returns>un TElement repr�sentant la structure hierarchique � appliquer au QXPS_Modifier</returns>
		static TElement Get_Default_TElement(Static_TElement_Name element_Name)
		{
			if(__elements.ContainsKey(element_Name))
			{
				return __elements[element_Name];
			}
			else
			{
				return null;
			}
		}
		#endregion Propri�t�s
	}
}
