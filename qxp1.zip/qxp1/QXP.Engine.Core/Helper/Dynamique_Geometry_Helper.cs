using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet de repositionner des �lements d'un rapport dynamique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 11:39:30</date>    
	public class Dynamique_Geometry_Helper
	{
		#region Membres
        
		#endregion Membres

		#region Constantes
        
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Dynamique_Geometry_Helper
		/// </summary>
		static Dynamique_Geometry_Helper()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// calcul d'une DZone en fonction d'une position et des param�tres d'une DCell (avec mise � jour de la position). 
		/// </summary>
		/// <remarks>
		/// 
		/// </remarks>
		/// <param name="cursor">position actuelle du curseur</param>
		/// <param name="cell">la cellule qui permet de d�duire la nouvelle zone </param>
		/// <returns>une nouvelle DZone</returns>
		public static DZone Get_Zone_And_Update_Cursor(DPoint cursor, DCell cell)
		{
			DZone __zone = Get_Zone(cursor, cell);
			if(QXP.Framework.Validation.IsNotNull(cursor))
			{
				cursor.Left = cursor.Left + __zone.Width + cell.Template.Left;
			}
			return __zone;
		}
		
		/// <summary>
		/// Calcule d'une DZone en fonction d'une position et des param�tres d'une DCell (sans mise � jour de la position). 
		/// </summary>
		/// <param name="cursor">position actuelle du curseur</param>
		/// <param name="cell">la cellule qui permet de d�duire la nouvelle zone </param>
		/// <returns>une nouvelle DZone</returns>
		public static DZone Get_Zone(DPoint cursor, DCell cell)
		{
			DZone		__zone;
			Template	__style = cell.Template;
			decimal		__left, __top, __width, __height;
			__left		= cell.Template.Left;
			__top		= cell.Template.Top;
			__width		= Get_CellWidth_WithoutLeft(cell);
			__height	= Get_CellHeight_WithoutTop(cell);

			if(QXP.Framework.Validation.IsNull(cursor))
			{
				__zone = new DZone(
					__left
					, __top
					, __width
					, __height);
			}
			else
			{
				__zone = new DZone(
					__left + cursor.Left 
					, __top + cursor.Top
					, __width
					, __height);
			}
			return __zone;
		}

		/// <summary>
		/// Calcule de la hauteur absolue d'une DCell (en tenant compte du marging top)
		/// </summary>
		/// <param name="cell">la cellule qui permet de d�duire la hauteur </param>
		/// <returns>la hauteur de la cellule</returns>
		public static decimal			 Get_CellHeight_WithTop(DCell cell)
		{
			decimal __height = 0;
			if(QXPFrk.Validation.IsSet(cell.Template.Height, false))
			{
				__height = cell.Template.Height;
			}
			else
			{
				__height = cell.TElement.Height;
			}
			if(!cell.Template.Absolute) __height += cell.Template.Top;
			return  __height;
		}

		/// <summary>
		/// Calcul de la hauteur d'une DCell (sans tenir compte du marging top)
		/// </summary>
		/// <param name="cell">la cellule qui permet de d�duire la hauteur </param>
		/// <returns>la hauteur de la cellule</returns>
		public static decimal			 Get_CellHeight_WithoutTop(DCell cell)
		{
			decimal __height = 0;
			if(QXPFrk.Validation.IsSet(cell.Template.Height, false))
			{
				__height = cell.Template.Height;
			}
			else
			{
				__height = cell.TElement.Height;
			}
			return  __height;
		}

		/// <summary>
		/// Calcul de la largeur Absolue d'une DCell (en tenant compte du marging left)
		/// </summary>
		/// <param name="cell">la cellule qui permet de d�duire la largeur </param>
		/// <returns>la largeur de la cellule</returns>
		public static decimal			 Get_CellWidth_WithLeft(DCell cell)
		{
			decimal __width = 0;
			if(QXPFrk.Validation.IsSet(cell.Template.Width, false))
			{
				__width = cell.Template.Width ;
			}
			else
			{
				__width = cell.TElement.Width;
			}
			if(!cell.Template.Absolute) __width += cell.Template.Left;
			return __width;
		}
		
		/// <summary>
		/// Calcul de la largeur Absolue d'une DCell (sans tenir compte du marging left)
		/// </summary>
		/// <param name="cell">la cellule qui permet de d�duire la largeur </param>
		/// <returns>la largeur de la cellule</returns>
		public static decimal			 Get_CellWidth_WithoutLeft(DCell cell)
		{
			decimal __width = 0;
			if(QXPFrk.Validation.IsSet(cell.Template.Width, false))
			{
				__width = cell.Template.Width ;
			}
			else
			{
				__width = cell.TElement.Width;
			}
			return __width;
		}
		
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
