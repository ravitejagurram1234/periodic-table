using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP
{
	/// <summary>
	/// Fournit les methodes permettant de tracer les informations de l'application
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/05/2010 11:23:05</date>    
	public class Trace_Helper
	{
		#region Membres
		//Astuce consistant � d�finir cette variable comme �tant li� au thread qui la cr�� uniquement !
		[ThreadStatic]
   		static Trace_Context	_context;	

        static Trace_Context    Default_Context = new Trace_Context("Default", "Unknown");
		#endregion Membres

		#region Constantes
		const string Trace_Pattern				= "{0} :{1:yyyy/MM/dd HH:mm:ss.ffff} - {2}";
		const string Trace_Pattern_Performance	= "- {0:yyyy/MM/dd HH:mm:ss.ffff} - {1} - {2}";
		const string Trace_Pattern_None			= "- {0:yyyy/MM/dd HH:mm:ss.ffff} - {1}";
		const string Trace_Error_Pattern		= "{0} - {1}";

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Trace_Helper
		/// </summary>
		static Trace_Helper()
		{
		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// Permet de d�finir le context de trace en cours
		/// </summary>
		/// <param name="trace_Context">le nouveau context de trace</param>
		public static void			Set_Trace_Context(Trace_Context trace_Context)
		{
			_context = trace_Context;
		}

		/// <summary>
		/// Retourne le contexte de trace en cours
		/// </summary>
		/// <returns>le contexte de trace en cours</returns>
		public static Trace_Context Get_Trace_Context()
		{
            if (QXPFrk.Validation.IsNull(_context))
            {
                return Default_Context;
            }
            else 
            { 
                return _context;
            } 
		}

		#region Logs
		/// <summary>
		/// Ajoute une nouvelle trace
		/// </summary>
		/// <param name="message">le message de la trace</param>
		/// <param name="args">les arguments associ�s au message</param>
		public static void			Log_Message(string message, params object[] args)
		{
			Log(string.Empty, null, message, args);			
		}

		/// <summary>
		/// Ajoute une nouvelle trace avec une source
		/// </summary>
		/// <param name="source">la source de la trace</param>
		/// <param name="message">le message de la trace</param>
		/// <param name="args">les arguments associ�s au message</param>
		public static void			Log_Src_Message(string source, string message, params object[] args)
		{
			Log(source, null, message, args);
		}

		/// <summary>
		/// Ajoute une nouvelle trace avec une exception
		/// </summary>
		/// <param name="ex">l'exception associ�e � la trace</param>
		/// <param name="message">le message de la trace</param>
		/// <param name="args">les arguments associ�s au message</param>
		public static void			Log_Exception_Message(Exception ex, string message, params object[] args)
		{
			Log(string.Empty, ex, message, args);
		}

		/// <summary>
		/// Ajoute une nouvelle trace avec une source et une exception
		/// </summary>
		/// <param name="source">la source de la trace</param>
		/// <param name="ex">l'exception associ�e � la trace</param>
		/// <param name="message">le message de la trace</param>
		/// <param name="args">les arguments associ�s au message</param>
		public static void			Log_All(string source, Exception ex, string message, params object[] args)
		{
			Log(source, ex, message, args);
		}

        /// <summary>
        /// Permet d'�valuer la trace compl�te en fonction du context et des param�tres
        /// </summary>
		/// <param name="source">la source de la trace</param>
		/// <param name="ex">l'exception associ�e � la trace</param>
		/// <param name="message">le message de la trace</param>
		/// <param name="args">les arguments associ�s au message</param>
        /// <returns>Le trace message complet</returns>
        public static Trace_Message Get_Trace_Message(string source, Exception ex, string message, params object[] args) 
        { 
            string __message = message;
			try
			{
				if(args.Length > 0 ) __message = string.Format(__message, args);
			}
			catch
			{
				//Rien � faire chaine mal format�e :(
				//on garde quand m�me le pattern
			}
			return new Trace_Message(Get_Trace_Context(), __message, source, ex);        
        }     

		/// <summary>
		/// Ajoute une nouvelle trace avec une source et une exception
		/// </summary>
		/// <param name="source">la source de la trace</param>
		/// <param name="ex">l'exception associ�e � la trace</param>
		/// <param name="message">le message de la trace</param>
		/// <param name="args">les arguments associ�s au message</param>
		static void					Log(string source, Exception ex, string message, params object[] args)
		{
			Trace_Message __trace_Message = Get_Trace_Message(source, ex, message, args);
            Log(__trace_Message);
		}
		
		/// <summary>
		/// Ajoute du Trace_Message dans les loggers du context
		/// </summary>
		/// <param name="trace_Message">le Trace_Message contenant les informations de la trace</param>
		public static void		    Log(Trace_Message trace_Message)
		{
			foreach(ITrace_Logger __logger in trace_Message.Context.Loggers)
			{
				__logger.Log(trace_Message);
			}			
		}
		
		#endregion Logs
		
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
