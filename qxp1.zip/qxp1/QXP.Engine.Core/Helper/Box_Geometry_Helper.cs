using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet de repositionner des boites (Box) du SDK quark
	/// </summary>
	/// <author>doufarm</author>
	/// <date>26/03/2010 10:44:49</date>    
	public class Box_Geometry_Helper
	{
		#region Membres
        
		static CultureInfo FR_culture = new CultureInfo("fr-FR");

		#endregion Membres

		#region Constantes
        
		// Le bloc a pour taille : 180 mm x 257 mm mais exprim� en points
        const decimal def_left = 0;
        const decimal def_top = 55;
        const decimal def_bottom = 785;
        const decimal def_right = 510;

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Box_Geometry_Helper
		/// </summary>
		static Box_Geometry_Helper()
		{
		}

		#endregion Constructeur

		#region M�thodes
		
		/// <summary>
		/// Permet de red�finir les nouvelles position d'une Box du SDK quark
		/// </summary>
		/// <param name="sdk_box">boite quark � repositionner</param>
		/// <param name="image_OffSet">offset � appliquer � la boite</param>
        public static void SetNewBoxGeometryPosition(QXPSMSDK.Box sdk_box, string image_OffSet)
        {
            decimal __x_offset = 0;
            decimal __y_offset = 0;

            //pour l'instant il n'y a une d�calage que dans les X pour centrer le contenu horizontalement
            if (QXPFrk.Validation.IsSet(image_OffSet))
            {
                int __offset = QXPFrk.ConversionInvariante.ToInt(image_OffSet);
                __x_offset = __offset / 2;
            }

			if(QXPFrk.Validation.IsNull(sdk_box.geometry))
			{
				sdk_box.geometry = new QXPSMSDK.Geometry();
			}
			if(QXPFrk.Validation.IsNull(sdk_box.geometry.position))
			{
				sdk_box.geometry.position = new QXPSMSDK.Position();
			}
			

            sdk_box.geometry.position.left = GetLeft(sdk_box.geometry.position.left ,__x_offset);
            sdk_box.geometry.position.top = GetTop(sdk_box.geometry.position.top, __y_offset);
            sdk_box.geometry.position.bottom = GetBottom(sdk_box.geometry.position.bottom, __y_offset);
            sdk_box.geometry.position.right = GetRight(sdk_box.geometry.position.right, __x_offset);

        }

        /// <summary>
        /// Permet de calculer la nouvelle position gauche
        /// </summary>
		/// <param name="currentLeft">position gauche courante</param>
        /// <param name="x_offset">d�calage � horizontal � appliquer</param>
        /// <returns>la nouvelle valeur � gauche</returns>
		private static string GetLeft(string currentLeft, decimal x_offset)
        {
            decimal __left;
			if(QXPFrk.Validation.IsSet(currentLeft))
			{
                __left = QXPFrk.ConversionInvariante.ToDecimal(currentLeft);
			}
			else
			{
				__left = def_left;
			}
			__left -= x_offset;
            return __left.ToString(FR_culture);
        }

        /// <summary>
        /// Permet de calculer la nouvelle position haute
        /// </summary>
		/// <param name="currentTop">la position haute courante</param>
        /// <param name="y_offset">le d�calage verticale � appliquer</param>
        /// <returns>la nouvelle valeur en haut</returns>
		private static string GetTop(string currentTop, decimal y_offset)
        {
            decimal __top;
			if(QXPFrk.Validation.IsSet(currentTop))
			{
                __top = QXPFrk.ConversionInvariante.ToDecimal(currentTop);
			}
			else
			{
				__top = def_top;
			}
            
			__top -= y_offset;
            return __top.ToString(FR_culture);
        }

        /// <summary>
        /// Permet de calculer la nouvelle position haute
        /// </summary>
		/// <param name="currentBottom">la position basse courante</param>
        /// <param name="y_offset">le d�calage verticale � appliquer</param>
        /// <returns>la nouvelle valeur en basse</returns>
		private static string GetBottom(string currentBottom, decimal y_offset)
        {
			decimal __bottom;
			if(QXPFrk.Validation.IsSet(currentBottom))
			{
                __bottom = QXPFrk.ConversionInvariante.ToDecimal(currentBottom);
			}
			else
			{
				__bottom = def_bottom;
			}
            
			__bottom -= y_offset;            
            return __bottom.ToString(FR_culture);
        }

        /// <summary>
        /// Permet de calculer la nouvelle position droite
        /// </summary>
		/// <param name="currentRight">position droite courante</param>
        /// <param name="x_offset">d�calage � horizontal � appliquer</param>
        /// <returns>la nouvelle valeur � droite</returns>
		private static string GetRight(string currentRight, decimal x_offset)
        {
			decimal __right;
			if(QXPFrk.Validation.IsSet(currentRight))
			{
                __right = QXPFrk.ConversionInvariante.ToDecimal(currentRight);
			}
			else
			{
				__right = def_right;
			}
                        
			__right -= x_offset;
            return __right.ToString(FR_culture);
        }
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
