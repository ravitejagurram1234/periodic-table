using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet d'executer des methodes dans un contexte control�
	/// </summary>
	/// <author>doufarm</author>
	/// <date>06/05/2010 09:24:47</date>    
	public class Execution_Helper
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Execution_Helper
		/// </summary>
		static Execution_Helper()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet de demander l'�x�cution d'une methode dans un try/catch et l�ve une exception T_Exception 'maison' s'il y a une erreur !
		/// </summary>
		/// <typeparam name="T_Exception">Le type de l'exception 'Maison' � lever</typeparam>
		/// <param name="method">la m�thode � appel�e</param>
		/// <param name="ex_args">les arguments � envoyer � l'exception 'Maison'</param>
		public static void Universal_Executer<T_Exception>(QXP.Framework.BasicHandler method, params object[] ex_args)where T_Exception:Exception{
			try
			{
				method();
			}
			//on catch une exception standard
			catch(Exception ex)
			{
				List<object> __args = new List<object>();
				__args.Add(ex);
				__args.AddRange(ex_args);
				throw (Exception)Activator.CreateInstance(typeof(T_Exception), __args.ToArray());
			}
		}

		/// <summary>
		/// Permet de demander l'�x�cution d'une methode dans un try/catch et l�ve une exception T_Exception 'maison' s'il y a une erreur inconnue!
		/// si l'erreur lev�e est �gale � T_ExceptionCatch alors une nouvelle exception T_ExceptionThrown est lev�e avec comme param�tre l'exception T_ExceptionCatch
		/// </summary>
		/// <typeparam name="T_ExceptionThrownStandard">Le type de l'exception 'Maison' � lever en cas d'erreur standard</typeparam>
		/// <typeparam name="T_ExceptionCatch">Le type de l'exception sp�ciale � catcher</typeparam>
		/// <typeparam name="T_ExceptionThrownCatch">Le type de l'exception 'Maison � lever si l'exception sp�ciale est catcher</typeparam>
		/// <param name="method">la m�thode � appel�e</param>
		/// <param name="ex_args">les arguments � envoyer � l'exception 'Maison' standard</param>
		public static void Universal_Executer<T_ExceptionThrownStandard, T_ExceptionCatch, T_ExceptionThrownCatch>(QXP.Framework.BasicHandler method, params object[] ex_args)where T_ExceptionThrownStandard:Exception where T_ExceptionCatch:Exception where T_ExceptionThrownCatch:Exception {
			try
			{
				method();
			}
			//on catch une exception standard
			catch (Exception ex)
			{
				List<object> __args = new List<object>();
				__args.Add(ex);
				__args.AddRange(ex_args);

				Type		__new_TException;
				
				if (ex is T_ExceptionCatch)
				{
					//ce type d'exception est charg�e d'analyser l'exception custom
					__new_TException = typeof(T_ExceptionThrownCatch);
				}
				else
				{
					__new_TException = typeof(T_ExceptionThrownStandard);
				}

				//on l�ve une nouvelle exception charg�e d'analyser l'exception custom
				throw (Exception)Activator.CreateInstance(__new_TException, __args.ToArray());

			}
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
