using System;

using QXPFrk = QXP.Framework;

using QXPInteropQuarkServer	= QXP.Interop.QuarkServer;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet d'obtenir des informations li� au DID (Document identity) d'un fichier quark g�n�r� par l'engine
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/05/2010 10:48:30</date>    
	public class Document_Identity_Helper
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Document_Identity_Helper
		/// </summary>
		static Document_Identity_Helper()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// G�n�ration des param�tres de mise � jour d'un bloc DID dans un document Quark 
		/// </summary>
		/// <param name="run">Le run sur lequel il faut creer le bloc identity</param>
		/// <returns>new did identity information</returns>
        public static string Get_New_Identity(Run_Base run)
        {
            
			QXPFrk.BaseList<string> __values = new QXPFrk.BaseList<string>();
            __values.Add(run.Properties.ID_Fnd_Code);
            __values.Add(QXPFrk.ConversionInvariante.ToString(run.Properties.ID_Suivi));
            __values.Add(QXPFrk.ConversionInvariante.ToString(run.ID));
            __values.Add(QXPFrk.ConversionInvariante.ToString(run.Properties.ID_Langue));
            __values.Add(QXPFrk.ConversionInvariante.ToString(run.Properties.Date_Echeance));
            __values.Add(QXPFrk.ConversionInvariante.ToString(DateTime.Now));
            __values.Add(run.Properties.ID_Unit_Code);
            return string.Join("|", __values.ToArray());
        }

		/// <summary>
		/// Permet d'�valuer la chaine d'identit� d'un document QXP qui � d�j� �t� g�n�r� par l'Engine
		/// La valeur est r�cup�r� dans le champs DID
		/// </summary>
		/// <param name="documentName">nom du document qxp dans lequel il faut analyser le did</param>
		/// <returns>valeur du did</returns>
		public static string				Get_Identity_Value(string documentName)
		{
			string __xmlDID		= QXPInteropQuarkServer.QXPS_Helper.Get_Xml(documentName, Document_Identity.DID);
			string __didValue	= QXP_XML.Create_From_XML(__xmlDID).GetValue(Document_Identity.DID);
			return __didValue;
		}

		/// <summary>
		/// Permet d'�valuer l'identit� d'un document QXP qui � d�j� �t� g�n�r� par l'Engine
		/// La valeur est r�cup�r� dans le champs DID
		/// </summary>
		/// <param name="documentName">nom du document qxp dans lequel il faut analyser le did</param>
		/// <returns>object did contenant les param�tres du document</returns>
		public static Document_Identity		Get_Identity(string documentName)
		{
			return new Document_Identity(Get_Identity_Value(documentName));
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
