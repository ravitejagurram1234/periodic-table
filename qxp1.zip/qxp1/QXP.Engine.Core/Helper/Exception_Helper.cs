using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Gestionnaire d'exception de l'Engine permet de lever des exceptions standard � l'Engine
	/// </summary>
	/// <author>doufarm</author>
	/// <date>05/05/2010 17:20:48</date>    
	public class Exception_Helper
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Exception_Helper
		/// </summary>
		static Exception_Helper()
		{
		}

		#endregion Constructeur

		#region M�thodes
		
		/// <summary>
		/// Permet de lever une exception en mode fatal ou non
		/// </summary>
		/// <param name="ex">L'exception</param>
		public static void Raise_Exception(Exception_Base ex)
		{
			throw ex;
		}

		/// <summary>
		/// Permet de lever une exception en mode fatal ou non
		/// </summary>
		/// <param name="ex">L'exception</param>
		/// <param name="type">est-elle fatale ?</param>
		public static void Raise_Exception(Exception_Base ex, Error_Type type)
		{
			ex.Type = type;
			throw ex;
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
