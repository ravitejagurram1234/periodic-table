using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading;

using QXPFrk			= QXP.Framework;
using QXPAudit			= QXP.Audit;
using QXPDataOracle     = QXP.Framework.Data.Oracle;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet une conversion/pr�paration des InParam qui seront transmis aux taches SQL
	/// puis des valeurs de bloc envoy�es au document final
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 11:10:09</date>    
	public class Data_Type_Helper
	{
		#region Membres
		Run_Properties	_run_Properties;
        
		static string[] _decimalFixedPattern;
        static string[] _decimalNotFixedPattern; 
		#endregion Membres

		#region Constantes
        const string    DecimalPattern     = "#,##0.{0}";
        const string    CurrencyPattern    = "#,##0.{0} {1}";
        const string    PercentPattern     = "#,##0.{0} %";
        
        const int       NbDecimalPattern   = 10;
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Data_Type_Helper
		/// </summary>
		static Data_Type_Helper()
		{
            _decimalFixedPattern        = new string[NbDecimalPattern];
            _decimalNotFixedPattern     = new string[NbDecimalPattern];
            for(int __i = 0;__i < 10; __i++)
			{
                _decimalFixedPattern[__i]       = new string('0', __i);
                _decimalNotFixedPattern[__i]    = new string('#', __i);
            }
		}

		/// <summary>
		/// D�fini les param�tre d'un helper de conversion en fonction des param�tre d'un run
		/// </summary>
		/// <param name="run_Properties"></param>
		public Data_Type_Helper(Run_Properties run_Properties) 
		{ 
			_run_Properties = run_Properties;
		}
		#endregion Constructeur

		#region M�thodes
		
		/// <summary>
		/// Permet d'obtenir les pattern d'affichage des nombre d�cimaux
		/// </summary>
		/// <param name="nbDecimal">nombre de d�cimale souhait�es dans le pattern d'affichage</param>
		/// <param name="fixedPattern">si true le pattern poss�de un nombre de d�cimal fixe</param>
		/// <returns>le pattern d'affichage des nombres d�cimaux</returns>
        string GetDecimalPattern(int nbDecimal, bool fixedPattern)
		{
            if(QXPFrk.Validation.IsSet(nbDecimal) && nbDecimal >= 0 && nbDecimal <= 10)
			{
                if(fixedPattern)
				{
                    return string.Format(DecimalPattern, _decimalFixedPattern[nbDecimal]);
                }
				else
				{
                    return string.Format(DecimalPattern, _decimalNotFixedPattern[nbDecimal]);
                }
            }
			else
			{
                return "n"; // format num�rique standard
            }
        }

		/// <summary>
		/// Permet d'obtenir les pattern d'affichage des nombres mon�taires
		/// </summary>
		/// <param name="nbDecimal">nombre de d�cimale souhait�es dans le pattern d'affichage</param>
		/// <param name="fixedPattern">si true le pattern poss�de un nombre de d�cimal fixe</param>
		/// <returns>le pattern d'affichage des nombres mon�taires</returns>
        string GetCurrencyPattern(int nbDecimal, bool fixedPattern)
		{
            if(QXPFrk.Validation.IsSet(nbDecimal) && nbDecimal >= 0 && nbDecimal <= 10)
			{
                if(fixedPattern)
				{
                    return string.Format(CurrencyPattern, _decimalFixedPattern[nbDecimal], NumberFormatInfo.CurrentInfo.CurrencySymbol);
                }
				else
				{
                    return string.Format(CurrencyPattern, _decimalNotFixedPattern[nbDecimal], NumberFormatInfo.CurrentInfo.CurrencySymbol);
                }
            }
			else
			{
                return "c"; // format num�rique currency
            }
        }

		/// <summary>
		/// Permet d'obtenir les pattern d'affichage des nombres en pourcentage
		/// </summary>
		/// <param name="nbDecimal">nombre de d�cimale souhait�es dans le pattern d'affichage</param>
		/// <param name="fixedPattern">si true le pattern poss�de un nombre de d�cimal fixe</param>
		/// <returns>le pattern d'affichage des nombres en pourcentage</returns>
        string GetPercentPattern(int nbDecimal, bool fixedPattern)
		{
            if(QXPFrk.Validation.IsSet(nbDecimal) && nbDecimal >= 0 && nbDecimal <= 10)
			{
                if(fixedPattern)
				{
                    return string.Format(PercentPattern, _decimalFixedPattern[nbDecimal]);
                }
				else
				{
                    return string.Format(PercentPattern, _decimalNotFixedPattern[nbDecimal]);
                }
            }
			else
			{
                return "p"; // format num�rique pourcentage
            }
        }

        #region string to InputParam
		
		/// <summary>
		/// Permet une conversion d'une valeur text en valeur fortement typ�es
		/// </summary>
		/// <param name="value">la valeur texte</param>
		/// <param name="type">le type de donn�e souhait�es</param>
		/// <returns>la valeur �valuer en fonction de la chaine et du type souhait�</returns>
        public static object   InputToTypedValue(string value, Data_Type type)
		{
            switch (type)
			{
                case Data_Type.Int:
                    return QXPFrk.ConversionInvariante.ToInt(value);
                case Data_Type.Decimal:
                    return QXPFrk.ConversionInvariante.ToDecimal(value);
                case Data_Type.Date:
                    return QXPFrk.ConversionInvariante.ToDateTime(value);
                default:
                    return value;
            }
        }

		/// <summary>
		/// Permet une conversion d'une valeur text en valeur fortement typ�es
		/// </summary>
		/// <param name="value">la valeur texte</param>
		/// <param name="type">le type de donn�e souhait�es</param>
		/// <returns>la valeur �valuer en fonction de la chaine et du type souhait�</returns>
		public static object    InputToTypedValue(string value, int type)
		{
            return InputToTypedValue(value, (Data_Type)type);
        }

        #endregion

        #region OraValue to String Output

		/// <summary>
		/// Permet d'obtenir la valeur text d'un param�tre oracle en fonction du type de donn�e souhait�e
		/// </summary>
		/// <param name="value">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="type">type de donn�e souhait�</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        public string    OutputToString(QXPDataOracle.OraValue value, Data_Type type, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
        {
            switch (type)
			{
                case Data_Type.Int:
                    return GetStringInt(value, showZero, nullString);
                case Data_Type.Decimal:
                    return GetStringDecimal(value, nbDecimal, showZero, nullString, decimal_significative);
                case Data_Type.Currency:
                    return GetStringCurrency(value, nbDecimal, showZero, nullString, decimal_significative);
                case Data_Type.Date:
                    return GetStringDate(value, nullString);
                case Data_Type.DateTime:
                    return GetStringDateTime(value, nullString);
                case Data_Type.Pourcentage:
                    return GetStringPourcentage(value, nbDecimal, showZero, nullString, decimal_significative);
                case Data_Type.Text:
                default:
                    return GetStringString(value, nullString);
                    
            }
        }

		/// <summary>
		/// Permet d'obtenir la valeur text d'un param�tre oracle en fonction du type de donn�e souhait�e
		/// </summary>
		/// <param name="value">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="type">type de donn�e souhait�</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        public string OutputToString(QXPDataOracle.OraValue value, int type, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
        {
            return OutputToString(value, (Data_Type)(type), nbDecimal, showZero, nullString, decimal_significative);
        }

		/// <summary>
		/// Permet d'obtenir la valeur text d'un param�tre oracle en fonction du type de donn�e Chaine
		/// </summary>
		/// <param name="dbValue">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringString(QXPDataOracle.OraValue dbValue, string nullString)
		{
			string	__str	= dbValue;
            return GetStringString(__str, nullString);
		}

		/// <summary>
		/// Permet d'obtenir la valeur text d'un param�tre oracle en fonction du type de donn�e Entier
		/// </summary>
		/// <param name="dbValue">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringInt(QXPDataOracle.OraValue dbValue, bool showZero, string nullString)
		{
            string __value = dbValue;
            if (QXPFrk.Validation.IsSet(__value)) __value = __value.Replace(",", "");
            int __int = QXPFrk.ConversionInvariante.ToInt(__value);
            return GetStringInt(__int, showZero, nullString);
		}

		/// <summary>
		/// Permet d'obtenir la valeur text d'un param�tre oracle en fonction du type de donn�e d�cimale
		/// </summary>
		/// <param name="dbValue">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringDecimal(QXPDataOracle.OraValue dbValue, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
		{
            Decimal     __decimal;
            string      __value = dbValue;
            if(dbValue.Value is Oracle.DataAccess.Types.OracleDecimal)
			{
                __decimal = dbValue;
            }
			else
			{
                if (QXPFrk.Validation.IsSet(__value))
				{
                    __value = __value.Replace(",", "");
                }
                __decimal = QXPFrk.ConversionInvariante.ToDecimal(__value);
            }
			return GetStringDecimal(__decimal, nbDecimal, showZero, nullString, decimal_significative);
		}

		/// <summary>
		/// Permet d'obtenir la valeur text d'un param�tre oracle en fonction du type de donn�e mon�taire
		/// </summary>
		/// <param name="dbValue">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringCurrency(QXPDataOracle.OraValue dbValue, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
		{
			Decimal				__currency	= dbValue;
			return GetStringCurrency(__currency, nbDecimal, showZero, nullString, decimal_significative);
		}

		/// <summary>
		/// Permet d'obtenir la valeur text d'un param�tre oracle en fonction du type de donn�e pourcentage
		/// </summary>
		/// <param name="dbValue">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringPourcentage(QXPDataOracle.OraValue dbValue, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
		{
			Decimal				__pourcentage	= dbValue;
            return GetStringPourcentage(__pourcentage, nbDecimal, showZero, nullString, decimal_significative);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="dbValue"></param>
		/// <param name="nullString"></param>
		/// <returns></returns>
        string GetStringDate(QXPDataOracle.OraValue dbValue, string nullString)
        {
            DateTime __date = dbValue;
            return GetStringDate(__date, nullString);
        }

		/// <summary>
		/// Permet d'obtenir la valeur text d'un param�tre oracle en fonction du type de donn�e date
		/// </summary>
		/// <param name="dbValue">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringDateTime(QXPDataOracle.OraValue dbValue, string nullString)
        {
            DateTime __date = dbValue;
            return GetStringDateTime(__date, nullString);
        }

        #endregion

        #region Value to String Output

		/// <summary>
		/// Permet d'obtenir la valeur text d'une valeur en fonction du type de donn�e souhait�e
		/// </summary>
		/// <param name="value">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="type">type de donn�e souhait�</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        public string OutputToString(object value, Data_Type type, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
		{
            switch (type)
			{
                case Data_Type.Int:
                    return GetStringInt(QXPFrk.ConversionInvariante.ToInt(value), showZero, nullString);
                case Data_Type.Decimal:
                    return GetStringDecimal(QXPFrk.ConversionInvariante.ToDecimal(value), nbDecimal, showZero, nullString, decimal_significative);
                case Data_Type.Currency:
                    return GetStringCurrency(QXPFrk.ConversionInvariante.ToDecimal(value), nbDecimal, showZero, nullString, decimal_significative);
                case Data_Type.Date:
                    return GetStringDate(QXPFrk.ConversionInvariante.ToDateTime(value), nullString);
                case Data_Type.DateTime:
                    return GetStringDateTime(QXPFrk.ConversionInvariante.ToDateTime(value), nullString);
                case Data_Type.Pourcentage:
                    return GetStringPourcentage(QXPFrk.ConversionInvariante.ToDecimal(value), nbDecimal, showZero, nullString, decimal_significative);
                case Data_Type.Text:
                default:
                    return GetStringString(QXPFrk.ConversionInvariante.ToString(value), nullString);
            }
        }

		/// <summary>
		/// Permet d'obtenir la valeur text d'une valeur en fonction du type de donn�e souhait�e
		/// </summary>
		/// <param name="value">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="type">type de donn�e souhait�</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        public string OutputToString(object value, int type, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
        {
            return OutputToString(value, (Data_Type)(type), nbDecimal, showZero, nullString, decimal_significative);
        }

		/// <summary>
		/// obtient une chaine format�e de la chaine
		/// </summary>
		/// <param name="value">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringString(string value, string nullString)
		{
            if (QXPFrk.Validation.IsSet(value))
            {
                return value;
            }
            else 
            {
                return nullString;
            }
		}

		/// <summary>
		/// obtient une chaine format�e mon�taire du nombre entier
		/// </summary>
		/// <param name="value">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringInt(int value, bool showZero, string nullString)
		{
			int			__int		= value;
			if(QXPFrk.Validation.IsSet(__int, showZero))
			{
				NumberFormatInfo	__nf		= Thread.CurrentThread.CurrentUICulture.NumberFormat.Clone() as NumberFormatInfo;
				__nf.NumberDecimalDigits		= 0;	
				string				__str		= __int.ToString("n", __nf);
				return 	__str;
			}
			else
			{
				return nullString;
			}
		}

		/// <summary>
		/// obtient une chaine format� du nombre d�cimal
		/// </summary>
		/// <param name="value">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringDecimal(Decimal value, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
		{
			Decimal				__decimal	= value;
			if(QXPFrk.Validation.IsSet(__decimal, showZero))
			{
				string          __pattern   = GetDecimalPattern(nbDecimal, decimal_significative);
                string		    __str		= __decimal.ToString(__pattern);
				return 	__str;
			}
			else
			{
				return nullString;
			}
		}

		/// <summary>
		/// obtient une chaine format�e mon�taire du nombre d�cimal
		/// </summary>
		/// <param name="value">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringCurrency(Decimal value, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
		{
			Decimal				__currency	= value;
			if(QXPFrk.Validation.IsSet(__currency, showZero))
			{
				string          __pattern   = GetCurrencyPattern(nbDecimal, decimal_significative);
                string		    __str		= __currency.ToString(__pattern);
				return 	        __str;
			}
			else
			{
				return nullString;
			}
		}

		/// <summary>
		/// obtient une chaine format�e pourcentage du nombre d�cimal
		/// </summary>
		/// <param name="value">le param�tre oracle dans lequel il faut extraire la valeur</param>
		/// <param name="nbDecimal">nombre de d�cimales</param>
		/// <param name="showZero">faut-il afficher les 0</param>
		/// <param name="nullString">resultat si la valeur n'est pas d�fini</param>
		/// <param name="decimal_significative">faut-il afficher les d�cimales significatives</param>
		/// <returns>la chaine r�sultat</returns>
        string GetStringPourcentage(Decimal value, int nbDecimal, bool showZero, string nullString, bool decimal_significative)
		{
			Decimal				__pourcentage	= value;
			if(QXPFrk.Validation.IsSet(__pourcentage, showZero))
			{
				string          __pattern   = GetPercentPattern(nbDecimal, decimal_significative);
                // TODO � voir si c'est correct
                string		    __str		= __pourcentage.ToString(__pattern) + " %";
				return 	        __str;
			}
			else
			{
				return nullString;
			}

		}

		/// <summary>
		/// obtient une chaine format�e de la date
		/// </summary>
		/// <param name="value">valeur de la date a formatter</param>
		/// <param name="nullString">chaine � retourn� si la date n'est pas d�finie</param>
		/// <returns>la date format�e</returns>
        string GetStringDate(DateTime value, string nullString)
        {
            DateTime __date = value;
            if (!QXPFrk.Validation.IsSet(__date)) return nullString;
            string _str = __date.ToString(_run_Properties.DatePattern);
            return _str;
        }


		/// <summary>
		/// obtient une chaine format�e de la date et heure
		/// </summary>
		/// <param name="value">valeur de la date a formatter</param>
		/// <param name="nullString">chaine � retourn� si la date n'est pas d�finie</param>
		/// <returns>la date format�e</returns>
        string GetStringDateTime(DateTime value, string nullString)
        {
            DateTime __date = value;
            if (!QXPFrk.Validation.IsSet(__date)) return nullString;
            string _str = __date.ToString(_run_Properties.DateTimePattern);
            return _str;
        }

        #endregion

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
