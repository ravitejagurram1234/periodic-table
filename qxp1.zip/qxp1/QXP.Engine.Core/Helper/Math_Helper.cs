using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK			= com.quark.qxpsm;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Engine.Core
{
	/// <summary>
	/// Fournit des fonctions math�matique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 11:39:30</date>    
	public class Math_Helper
	{
		#region Membres
        
		#endregion Membres

		#region Constantes
        
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Math_Helper
		/// </summary>
		static Math_Helper()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet d'obtenir une valeur (resultat) par le pourcentage(percent) d'une valeur (value)
		/// </summary>
		/// <param name="value">La valeur source</param>
		/// <param name="percent">le pourcentage voulu de la valeur source</param>
		/// <returns>la nouvelle valeur</returns>
		public static decimal GetValPercent(decimal value, decimal percent)
		{
			return (value * (percent / 100));
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
