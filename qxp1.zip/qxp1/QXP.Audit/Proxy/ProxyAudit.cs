using System;
using System.Data;
using Oracle.DataAccess.Client;
using QXPApplication = QXP.Framework.Application;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPProxy = QXP.Framework.Proxy;

namespace QXP.Audit.Proxy
{

    /// <summary>
    /// Proxy ProxyAudit : ProxyAudit
    /// </summary>
    /// <author> </author>
    /// <date> </date>   
    public class ProxyAudit : QXPProxy.BaseProxy
    {
        #region Membres

        #endregion Membres

        #region Constantes

        private const string PACKAGE = "_PK_AUDIT.";
        const int MAX_LENGTH_32 = 32;
        const int MAX_LENGTH_60 = 60;
        const int MAX_LENGTH_64 = 64;
        const int MAX_LENGTH_100 = 100;
        const int MAX_LENGTH_128 = 128;
        const int MAX_LENGTH_255 = 255;
        const int MAX_LENGTH_500 = 500;
        const int MAX_LENGTH_4000 = 4000;

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ProxyAudit
        /// </summary>
        public ProxyAudit()
        {
        }

        /// <summary>
        /// Cr�e une instance de ProxyAudit
        /// </summary>
        /// <param name="oraClient">Connexion Oracle</param>
        public ProxyAudit(QXPDataOracle.OraClient oraClient)
            : base(oraClient)
        {
        }

        /// <summary>
        /// Cr�e une instance de ProxyAudit
        /// </summary>
        /// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
        public ProxyAudit(string dataBase)
            : base(dataBase)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #region Acc�s Base

        #region SELECT

        /*
         * Utiliser ici les QXPSnippet Proxy pour g�n�rer automatiquement un squelette de code pour les acc�s SELECT � la base de donn�es
         */

        #endregion SELECT

        #region INSERT / UPDATE / DELETE

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ip"></param>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <param name="page"></param>
        /// <param name="login"></param>
        /// <param name="module"></param>
        /// <param name="fonction"></param>
        /// <param name="message"></param>
        /// <param name="param1"></param>
        /// <param name="param2"></param>
        /// <param name="param3"></param>
        /// <param name="param4"></param>
        /// <param name="param5"></param>
        /// <param name="responseTime"></param>
        /// <param name="statusNumber"></param>
        public int InsertTrace(string ip, DateTime startTime, DateTime endTime, string page, string login, string module, string fonction, string message, string param1, string param2, string param3, string param4, string param5, decimal responseTime, int statusNumber)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();

            #endregion Variables

            // Les entr�es sont limit�s en nombre de caract�res.
            login = QXPFrk.StringHelper.StartString(login, MAX_LENGTH_32);
            fonction = QXPFrk.StringHelper.StartString(fonction, MAX_LENGTH_64);
            page = QXPFrk.StringHelper.StartString(page, MAX_LENGTH_255);
            module = QXPFrk.StringHelper.StartString(module, MAX_LENGTH_128);
            message = QXPFrk.StringHelper.StartString(message, MAX_LENGTH_500);
            param1 = QXPFrk.StringHelper.StartString(param1, MAX_LENGTH_4000);
            param2 = QXPFrk.StringHelper.StartString(param2, MAX_LENGTH_500);
            param3 = QXPFrk.StringHelper.StartString(param3, MAX_LENGTH_500);
            param4 = QXPFrk.StringHelper.StartString(param4, MAX_LENGTH_500);
            param5 = QXPFrk.StringHelper.StartString(param5, MAX_LENGTH_500);
            string __nom_Application = QXPFrk.StringHelper.StartString(QXPApplication.Application.Name, MAX_LENGTH_100);
            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("p_ip", ip)
            .AddParameterToSqlParamList("p_startTime", startTime)
            .AddParameterToSqlParamList("p_endTime", endTime)
            .AddParameterToSqlParamList("p_page", page)
            .AddParameterToSqlParamList("p_login", login)
            .AddParameterToSqlParamList("p_module", module)
            .AddParameterToSqlParamList("p_fonction", fonction)
            .AddParameterToSqlParamList("p_message", message)
            .AddParameterToSqlParamList("p_param1", param1)
            .AddParameterToSqlParamList("p_param2", param2)
            .AddParameterToSqlParamList("p_param3", param3)
            .AddParameterToSqlParamList("p_param4", param4)
            .AddParameterToSqlParamList("p_param5", param5)
            .AddParameterToSqlParamList("p_temps_reponse", responseTime)
            .AddParameterToSqlParamList("p_statut", statusNumber)
            .AddParameterToSqlParamList("p_id_application", QXPApplication.Application.ID)
            .AddParameterToSqlParamList("p_nom_application", __nom_Application)
            .AddParameterToSqlParamList("p_id_trace", OracleDbType.Int32, ParameterDirection.Output);

            #endregion Definition des OraParameters

            string __sql = string.Concat(SitePrefix, PACKAGE, "InsertTrace");

            QXPDataOracle.SQLRequest __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            try
            {

                this.Execute(__sqlRequest);

                int __idAudit = __oraParameters.GetParameter("p_id_trace").ReturnValue;
                return __idAudit;
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de l'insertion de l'audit : ", ex);
            }

            return int.MinValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ip"></param>
        /// <param name="page"></param>
        /// <param name="login"></param>
        /// <param name="module"></param>
        /// <param name="fonction"></param>
        /// <param name="param1"></param>
        /// <param name="param2"></param>
        /// <param name="param3"></param>
        /// <param name="param4"></param>
        /// <param name="param5"></param>
        /// <param name="message"></param>
        public void EcritTrace(string ip, string page, string login, string module, string fonction, string param1, string param2, string param3, string param4, string param5, string message)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();

            #endregion Variables

            // Les entr�es sont limit�s en nombre de caract�res.
            login = QXPFrk.StringHelper.StartString(login, MAX_LENGTH_32);
            fonction = QXPFrk.StringHelper.StartString(fonction, MAX_LENGTH_64);
            page = QXPFrk.StringHelper.StartString(page, MAX_LENGTH_255);
            module = QXPFrk.StringHelper.StartString(module, MAX_LENGTH_128);
            message = QXPFrk.StringHelper.StartString(message, MAX_LENGTH_500);
            param1 = QXPFrk.StringHelper.StartString(param1, MAX_LENGTH_4000);
            param2 = QXPFrk.StringHelper.StartString(param2, MAX_LENGTH_500);
            param3 = QXPFrk.StringHelper.StartString(param3, MAX_LENGTH_500);
            param4 = QXPFrk.StringHelper.StartString(param4, MAX_LENGTH_500);
            param5 = QXPFrk.StringHelper.StartString(param5, MAX_LENGTH_500);
            string __nom_Application = QXPFrk.StringHelper.StartString(QXPApplication.Application.Name, MAX_LENGTH_100);

            #region Definition des OraParameters
            __oraParameters.AddParameterToSqlParamList("p_ip", ip)
            .AddParameterToSqlParamList("p_page", page)
            .AddParameterToSqlParamList("p_Login", login)
            .AddParameterToSqlParamList("p_Module", module)
            .AddParameterToSqlParamList("p_Fonction", fonction)
            .AddParameterToSqlParamList("p_Param1", param1)
            .AddParameterToSqlParamList("p_Param2", param2)
            .AddParameterToSqlParamList("p_Param3", param3)
            .AddParameterToSqlParamList("p_Param4", param4)
            .AddParameterToSqlParamList("p_Param5", param5)
            .AddParameterToSqlParamList("p_Message", message)
            .AddParameterToSqlParamList("p_id_application", QXPApplication.Application.ID)
            .AddParameterToSqlParamList("p_nom_application", __nom_Application);

            #endregion Definition des OraParameters

            string __sql = string.Concat(SitePrefix, PACKAGE, "EcritTrace");

            QXPDataOracle.SQLRequest __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            try
            {
                this.Execute(__sqlRequest);

            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de l'ecriture de l'audit : ", ex);
            }

        }

        /// <summary>
        /// Ins�re une trace dans la table d'audit des authentifications QXP_AUTH_AUDIT
        /// </summary>
        /// <param name="audit">Audit associ�</param>
        /// <param name="authMessage">Message d'authentification</param>
        /// <param name="dateLastConnexion">Date de derni�re connexion de l'utilisateur</param>
        public void EcritTraceAuth(Audit audit, string authMessage, DateTime dateLastConnexion)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            string __login = QXPFrk.StringHelper.StartString(audit.Login, MAX_LENGTH_60);
            string __authMessage = QXPFrk.StringHelper.StartString(authMessage, MAX_LENGTH_4000);
            string __nom_Application = QXPFrk.StringHelper.StartString(QXPApplication.Application.Name, MAX_LENGTH_100);

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("p_ip", audit.IP)
                           .AddParameterToSqlParamList("p_ip_access_type", audit.IPAccessType.ToString())
                           .AddParameterToSqlParamList("p_page", audit.Page)
                           .AddParameterToSqlParamList("p_Login", __login)
                           .AddParameterToSqlParamList("p_Habilitations", __authMessage)
                           .AddParameterToSqlParamList("p_id_application", QXPApplication.Application.ID)
                           .AddParameterToSqlParamList("p_nom_application", __nom_Application)
                           .AddParameterToSqlParamList("p_date_last_connexion", dateLastConnexion);

            #endregion Definition des OraParameters

            __sql = string.Concat(SitePrefix, PACKAGE, "EcritAuthTrace");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            try
            {
                this.Execute(__sqlRequest);
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de l'ecriture de l'audit authentification : ", ex);
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idTrace"></param>
        /// <param name="responseTime"></param>
        /// <param name="statusNumber"></param>
        /// <param name="finishTime"></param>
        public void UpdateTrace(int idTrace, decimal responseTime, int statusNumber)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("p_id_trace", idTrace)
            .AddParameterToSqlParamList("p_temps_reponse", responseTime)
            .AddParameterToSqlParamList("p_statut", statusNumber);

            #endregion Definition des OraParameters

            string __sql = string.Concat(SitePrefix, PACKAGE, "UpdateTrace");

            QXPDataOracle.SQLRequest __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            try
            {
                this.Execute(__sqlRequest);

            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de l'update de l'audit : ", ex);
            }
        }

        #endregion INSERT / UPDATE / DELETE

        #endregion Acc�s Base

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
