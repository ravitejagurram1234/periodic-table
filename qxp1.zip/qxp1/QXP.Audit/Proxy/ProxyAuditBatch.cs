using System;
using System.Data;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPProxy = QXP.Framework.Proxy;


namespace QXP.Audit.Proxy
{
    /// <summary>
    /// ProxyAuditBatch : proxy permettant l'insertion de traces d'audit pour les applications Batch
    /// </summary>
    /// <author>cueffl</author>
    /// <date>20/07/2009 18:03:00</date>    
    public class ProxyAuditBatch : QXPProxy.BaseProxy
    {
        #region Membres

        private int _idRun;
        private static ProxyAuditBatch _current = null;
        private int _idApplicatif = QXPFrk.Configuration.Settings.Current.GetInt("applicationId");

        #endregion Membres

        #region Constantes

        // QXP-111 : Enlever pour prendre en compte le package associ� � l'application en cours (SitePrefix)
        //private const string PACKAGE = "QXP_PK_AUDIT.";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ProxyLog
        /// </summary>
        private ProxyAuditBatch()
        {
            _idRun = this.GetLaunchIdFromDatabase();
        }

        /// <summary>
        /// Cr�e une instance de ProxyLog
        /// </summary>
        /// <param name="oraClient">Connexion Oracle</param>
        private ProxyAuditBatch(QXPDataOracle.OraClient oraClient)
            : base(oraClient)
        {
            _idRun = this.GetLaunchIdFromDatabase();
        }

        /// <summary>
        /// Cr�e une instance de ProxyLog
        /// </summary>
        /// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
        private ProxyAuditBatch(string dataBase)
            : base(dataBase)
        {
            _idRun = this.GetLaunchIdFromDatabase();
        }

        #endregion Constructeur

        #region M�thodes

        #region Acc�s Base

        #region SELECT

        /// <summary>
        /// Retourne un identifiant d'execution (correspond � l'incr�mentation d'une sequence oracle)
        /// </summary>
        /// <returns>Identifiant de run</returns>
        private int GetLaunchIdFromDatabase()
        {
            #region Variables

            string __sql = string.Empty;
            int __idRun = int.MinValue;
            string __package = string.Concat(SitePrefix, "_PK_AUDIT.");

            #endregion Variables

            __sql = string.Concat(__package, "GetLaunchIdFromDatabase");

            __idRun = this.ExecuteScalar(CommandType.StoredProcedure, __sql);

            return __idRun;
        }

        #endregion SELECT

        #region INSERT / UPDATE / DELETE

        /// <summary>
        /// Insert une trace dans la table QXP_AUDIT_BATCH
        /// </summary>
        /// <param name="message">Message</param>
        public void InsertTraceBatch(string message)
        {
            this.InsertTraceBatch(message, null);
        }

        /// <summary>
        /// Insert une trace dans la table QXP_AUDIT_BATCH
        /// </summary>
        /// <param name="codeRetour">Code de retour</param>
        /// <param name="message">Message</param>
        public void InsertTraceBatch(int codeRetour, string message)
        {
            this.InsertTraceBatch(codeRetour, message, null);
        }

        /// <summary>
        /// Insert une trace dans la table QXP_AUDIT_BATCH
        /// </summary>
        /// <param name="message">Message</param>
        /// <param name="exc">Exception</param>
        public void InsertTraceBatch(string message, Exception exc)
        {
            InsertTraceBatch(-1, message, exc);         
        }

        /// <summary>
        /// Insert une trace dans la table QXP_AUDIT_BATCH
        /// </summary>
        /// <param name="codeRetour">Code de retour</param>
        /// <param name="message">Message</param>
        /// <param name="exc">Exception</param>
        public void InsertTraceBatch(int codeRetour, string message, Exception exc)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            string __message = string.Empty;
            string __package = string.Concat(SitePrefix, "_PK_AUDIT.");

            if (QXPFrk.Validation.IsNotNull(exc))
            {
                __message = string.Concat(message, " ", exc.ToString());
            }
            else
            {
                __message = message;
            }

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("p_codeRetour", codeRetour)
                           .AddParameterToSqlParamList("p_message", QXPFrk.StringHelper.Left(__message, 4000))
                           .AddParameterToSqlParamList("p_applicationId", this._idApplicatif)
                           .AddParameterToSqlParamList("p_launchId", this._idRun);


            #endregion Definition des OraParameters

            __sql = string.Concat(__package, "InsertTraceBatch");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            try
            {
                this.Execute(__sqlRequest);
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de l'insertion de la trace : ", ex);
                throw;
            }
        }

        #endregion INSERT / UPDATE / DELETE

        #endregion Acc�s Base

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Singleton assurant l'unicit� du Proxy
        /// </summary>
        public static ProxyAuditBatch Current
        {
            get
            {
                if (_current == null)
                {
                    _current = new ProxyAuditBatch();
                }

                return _current;
            }
        }

        /// <summary>
        /// Identifiant de lancement utilis� pour l'audit
        /// </summary>
        public int IdRun
        {
            get { return _idRun; }
            set { _idRun = value; }
        }

        /// <summary>
        /// Identifiant de lancement utilis� pour l'audit
        /// </summary>
        public int IdApplicatif
        {
            get { return _idApplicatif; }
            set { _idApplicatif = value; }
        }

        #endregion Propri�t�s
    }
}