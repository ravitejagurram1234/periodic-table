using System;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;

namespace QXP.Audit
{
    /// <summary>
    /// Class Audit : Classe permettant l'audit d'information dans la table QXP_AUDIT.
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class Audit
    {
        #region Membres

        /// <summary>
        /// Mesure des performances
        /// </summary>
        private QXPDiagnostic.Performance _perf;
        private int _idTrace;
        private DateTime _startTime;
        private DateTime _endTime;
        private string _login;
        private string _ip;
        private string _module;
        private string _page;
        private string _fonction;
        private string _message;
        private decimal _responseTime;
        private int _statusNumber = 0;
        private string _param1;
        private string _param2;
        private string _param3;
        private string _param4;
        private string _param5;
        private Enums.AccessType _accessTYPE = Enums.AccessType.Unknown;
        private Proxy.ProxyAudit _proxyAudit = new Proxy.ProxyAudit();

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr��e une instance d'Audit
        /// </summary>
        /// <param name="source">Source</param>
        /// <param name="login">Login</param>
        /// <param name="module">Module</param>
        public Audit(object source, string login, string module) : this(source, login, module, null, null)
        {
        }
        
        /// <summary>
        /// Cr��e une instance d'Audit
        /// </summary>
        /// <param name="source">Source</param>
        /// <param name="login">Login</param>
        /// <param name="module">Module</param>
        /// <param name="page">Page</param>
        /// <param name="ip">Adresse IP</param>
        public Audit(object source, string login, string module, string page, string ip)
        {
            this._perf = new QXPDiagnostic.Performance(source);
            this._startTime = DateTime.Now;

            if (QXPFrk.Validation.IsSet(page))
            {
                this._page = page;
            }
            else
            {
                this._page = QXPFrk.Application.Application.Current_Page;
            }

            if (QXPFrk.Validation.IsSet(ip))
            {
                this._ip = ip;
                this._accessTYPE = Enums.AccessType.Unknown;
            }
            else
            {
                QXPFrk.Application.HTTP_IP_Access __http_ip_access = QXPFrk.Application.Application.Current_HTTPIPAccess;
                
                //L'@IP peut etre null si l'audit est appel�e par une application console par exemple
                if (QXPFrk.Validation.IsNotNull(__http_ip_access))
                {
                    this._ip = __http_ip_access.IP;
                    switch (__http_ip_access.IPSrc)
                    {
                        case QXP.Framework.Application.HTTP_IP_Access.IPSource.HTTP_X_FORWARDED_FOR:
                            this._accessTYPE = Enums.AccessType.RWEB;
                            break;
                        case QXP.Framework.Application.HTTP_IP_Access.IPSource.REMOTE_ADDR:
                            this._accessTYPE = Enums.AccessType.Direct;
                            break;
                        default:
                            this._accessTYPE = Enums.AccessType.Unknown;
                            break;
                    }
                }

            }
            this._login = login;
            this._module = module;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fonction"></param>
        /// <param name="message"></param>
        /// <param name="param1"></param>
        /// <param name="param2"></param>
        /// <param name="param3"></param>
        /// <param name="param4"></param>
        /// <param name="param5"></param>
        public void SetAuditParameters(string fonction, string message, object param1, object param2, object param3, object param4, object param5)
        {
            this._fonction = fonction;
            this._message = message;
            this._param1 = QXPFrk.Conversion.ToString(param1);
            this._param2 = QXPFrk.Conversion.ToString(param2);
            this._param3 = QXPFrk.Conversion.ToString(param3);
            this._param4 = QXPFrk.Conversion.ToString(param4);
            this._param5 = QXPFrk.Conversion.ToString(param5);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="fonction"></param>
        /// <param name="message"></param>
        /// <param name="param1"></param>
        /// <param name="param2"></param>
        /// <param name="param3"></param>
        /// <param name="param4"></param>
        public void SetAuditParameters(string fonction, string message, string param1, string param2, string param3, string param4)
        {
            this.SetAuditParameters(fonction, message, param1, param2, param3, param4, string.Empty);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="fonction"></param>
        /// <param name="message"></param>
        /// <param name="param1"></param>
        /// <param name="param2"></param>
        /// <param name="param3"></param>
        public void SetAuditParameters(string fonction, string message, string param1, string param2, string param3)
        {
            this.SetAuditParameters(fonction, message, param1, param2, param3, string.Empty, string.Empty);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="fonction"></param>
        /// <param name="message"></param>
        /// <param name="param1"></param>
        /// <param name="param2"></param>
        public void SetAuditParameters(string fonction, string message, string param1, string param2)
        {
            this.SetAuditParameters(fonction, message, param1, param2, string.Empty, string.Empty, string.Empty);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="fonction"></param>
        /// <param name="message"></param>
        /// <param name="param1"></param>
        public void SetAuditParameters(string fonction, string message, string param1)
        {
            this.SetAuditParameters(fonction, message, param1, string.Empty, string.Empty, string.Empty, string.Empty);
        }


        /// <summary>
        /// Ecrit une trace dans la table QXP_AUDIT
        /// </summary>
        public void EcritTrace()
        {
            try
            {
                this._responseTime = this._perf.GetSecondesAndMillseconds(false);
                this._endTime = DateTime.Now;
                this._idTrace = _proxyAudit.InsertTrace(this._ip, this._startTime, this._endTime, this._page, this._login, this._module, this._fonction, this._message, this._param1, this._param2, this._param3, this._param4, this._param5, this._responseTime, this._statusNumber);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Ecrit une trace dans la table QXP_AUDIT 
        /// </summary>
        /// <param name="login"></param>
        /// <param name="module"></param>
        /// <param name="fonction"></param>
        /// <param name="param1"></param>
        /// <param name="param2"></param>
        /// <param name="param3"></param>
        /// <param name="param4"></param>
        /// <param name="param5"></param>
        /// <param name="message"></param>
        public void EcritTrace(string login, string module, string fonction, string param1, string param2, string param3, string param4, string param5, string message)
        {
            try
            {
                this._responseTime = this._perf.GetSecondesAndMillseconds(false);
                this._endTime = DateTime.Now;
                this._idTrace = _proxyAudit.InsertTrace(this._ip, this._startTime, this._endTime, this._page, login, module, fonction, message, param1, param2, param3, param4, param5, this._responseTime, this._statusNumber);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Ecrit une trace dans la table QXP_AUDIT 
        /// </summary>
        /// <param name="fonction"></param>
        /// <param name="param1"></param>
        /// <param name="param2"></param>
        /// <param name="param3"></param>
        /// <param name="param4"></param>
        /// <param name="param5"></param>
        /// <param name="message"></param>
        public void EcritTrace(string fonction, string param1, string param2, string param3, string param4, string param5, string message)
        {
            try
            {
                this._responseTime = this._perf.GetSecondesAndMillseconds(false);
                this._endTime = DateTime.Now;
                this._idTrace = _proxyAudit.InsertTrace(this._ip, this._startTime, this._endTime, this._page, this._login, this._module, fonction, message, param1, param2, param3, param4, param5, this._responseTime, this._statusNumber);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// Ecriture de la trace d'authentification dans la table QXP_AUTH_AUDIT
        /// </summary>
        /// <param name="authMessage">Message d'authentification</param>
        /// <param name="dateLastConnexion">Date de derni�re connexion de l'utilisateur</param>
        public void EcritTraceAuth(string authMessage, DateTime dateLastConnexion)
        {
            _proxyAudit.EcritTraceAuth(this, authMessage, dateLastConnexion);
        }

        /// <summary>
        /// 
        /// </summary>
        public void InsertTrace()
        {
            try
            {
                _proxyAudit.InsertTrace(this._ip, this._startTime, DateTime.MinValue, this._page, this._login, this._module, this._fonction, this._message, this._param1, this._param2, this._param3, this._param4, this._param5, this._responseTime, this._statusNumber);
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="reponseTime"></param>
        public void UpdateTrace(decimal reponseTime)
        {
            try
            {
                _proxyAudit.UpdateTrace(this._idTrace, reponseTime, this._statusNumber);
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        public void ResetPerformance()
        {
            this._perf.Reset();
        }

        #region static methods

        /// <summary>
        /// Ecrit une trace dans la table QXP_AUDIT 
        /// </summary>
        public static void Ecrit_Audit(string login, string module, string fonction, string param1, string param2, string param3, string param4, string param5, string message)
        {
            //ne dupliquons pas le code, r�utilisons les fonctions de Audit:
            Audit __audit = new Audit(null, login, module);

            __audit.EcritTrace(fonction, param1, param2, param3, param4, param5, message);

        }

        /// <summary>
        /// Ecriture de la trace d'authentification dans la table QXP_AUTH_AUDIT
        /// </summary>
        /// <param name="login">Login</param>
        /// <param name="authMessage">Message d'authentification</param>
        /// <param name="dateLastConnexion">Date de derni�re connexion de l'utilisateur</param>
        public static void Ecrit_AuditAuth(string login, string authMessage, DateTime dateLastConnexion)
        {
            //ne dupliquons pas le code, r�utilisons les fonctions de Audit:
            Audit __audit = new Audit(null, login, null);
            __audit.EcritTraceAuth(authMessage, dateLastConnexion);
        }

        #endregion static methods

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// 
        /// </summary>
        public int IdTrace
        {
            get { return this._idTrace; }
            set { this._idTrace = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Login
        {
            get { return this._login; }
            set { this._login = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Module
        {
            get { return this._module; }
            set { this._module = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Fonction
        {
            get { return this._fonction; }
            set { this._fonction = value; }
        }

        /// <summary>
        /// Page web associ�e
        /// </summary>
        public string Page
        { 
            get { return this._page;}
        }

        /// <summary>
        /// 
        /// </summary>
        public string Message
        {
            get { return this._message; }
            set { this._message = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public decimal ResponseTime
        {
            get { return this._responseTime; }
            set { this._responseTime = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public int StatusNumber
        {
            get { return this._statusNumber; }
            set { this._statusNumber = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Param1
        {
            get { return this._param1; }
            set { this._param1 = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Param2
        {
            get { return this._param2; }
            set { this._param2 = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Param3
        {
            get { return this._param3; }
            set { this._param3 = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Param4
        {
            get { return this._param4; }
            set { this._param4 = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Param5
        {
            get { return this._param5; }
            set { this._param5 = value; }
        }

        /// <summary>
        /// Adresse IP
        /// </summary>
        public string IP
        {
            get { return this._ip; }
        }

        /// <summary>
        /// Type d'acc�s IP
        /// </summary>
        public Enums.AccessType IPAccessType
        {
            get { return this._accessTYPE; }
        }
        #endregion Propri�t�s
    }
}
