using System;

/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/
namespace QXP.Audit
{
    /// <summary>
    /// Ensembles des �num�rations communes au module
    /// </summary>
    /// <author>cueffl</author>
    /// <date>29/04/2010 10:24:07</date>    
    public class Enums
    {
        public enum AccessType
        {
            /// <summary>
            /// Acc�s ind�termin� � l'application.
            /// </summary>
            Unknown,
            /// <summary>
            /// Acc�s � l'application via le r�seau interne
            /// </summary>
            Direct,
            /// <summary>
            /// Acc�s � l'application via internet (en passant par RWEB)
            /// </summary>
            RWEB
        }
    }
}
