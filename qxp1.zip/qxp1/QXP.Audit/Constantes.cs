using System;

/* 
 * Code g�n�r� avec le template project : QXP.ProjectTemplate
*/
namespace QXP.Audit
{
    /// <summary>
    /// Ensembles des Constantes communes au module QXP.Audit
    /// </summary>
    /// <author>touxb</author>
    /// <date>03/02/2012 09:27:47</date>    
    public class Constantes
    {

    }
}
