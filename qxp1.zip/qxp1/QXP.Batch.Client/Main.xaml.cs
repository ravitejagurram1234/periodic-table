﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using QXP.Batch.Interop;
using QXPBatchService = QXP.Batch.Client.QXPServiceReference;

namespace QXP.Batch.Client
{
    /// <summary>
    /// Class Main : Logique d'interaction pour Main.xaml
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public partial class Main : Window
    {
        #region Membres
        private ServiceCallback                     _serviceCallBack;
        QXPServiceReference.ServiceClient           _service;
        ClientInfo                  _clientInfo = new ClientInfo() { ComputerName = Environment.MachineName, UserName = Environment.UserName };
        bool                                        _serviceOK = false;
        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Crée une instance de Main
        /// </summary>
        public Main()
        {
            InitializeComponent();
        }

        #endregion Constructeur

        #region Méthodes

        /// <summary>
        /// envoi d'un message au server
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSend_Click(object sender, RoutedEventArgs e)
        {
             try
            {
                if (_serviceOK) _service.ReceiveMessage(textBox1.Text);
            }
            catch(Exception ex)
            { 
                MessageBox.Show(ex.Message, "Batch inaccessible ");
                //Try to reinit service
                this.InitService();
            }

        }

        /// <summary>
        /// Fermeture de l'application ont informe le serveur que l'on quitte la session
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // au cas ou le service n'a pas pu être activé 
            try
            {
                if(_serviceOK)  this.CloseService();
            }
            catch(Exception ex)
            { 
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Initialisation du service
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InitService();
        }

        /// <summary>
        /// Initialisation du service avec call back
        /// </summary>
        private void InitService() 
        { 
            try
            {
                if (_service != null) this.CloseService();
                _serviceCallBack = new ServiceCallback(this);
                InstanceContext __context = new InstanceContext(_serviceCallBack);
                _service = new QXPServiceReference.ServiceClient(__context);
                _service.Subscribe(_clientInfo);
                _serviceOK = true;
            }
            catch(Exception ex)
            { 
                _serviceOK = false;
                MessageBox.Show(ex.Message, "Connection à batch");
            }
        }

        /// <summary>
        /// Fermeture du service
        /// </summary>
        private void CloseService() 
        { 
            try
            {
                if (_service.State != CommunicationState.Closed)
                {
                    _service.UnSubscribe();
                    _service.Close();
                }
            }
            catch
            {
                _service.Abort();
            }
        }


        #endregion Méthodes

        /// <summary>
        /// Permet de se reconnecter au serveur batch
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemReconnect_Click(object sender, RoutedEventArgs e)
        {
            this.InitService();
        }

        /// <summary>
        /// Permet d'obtenir la liste des client connecté au server
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemGetSubscribers_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBox.Show(string.Join("\n\r", _service.GetListClients()));
            }
            catch(Exception ex)
            { 
                MessageBox.Show(ex.Message, "Connection à batch");
            }
        }

        /// <summary>
        /// Permet d'effacer les logs en cours
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemClearLogs_Click(object sender, RoutedEventArgs e)
        {
            listMessages.Items.Clear();
        }

        #region Propriétés

        #endregion Propriétés
    }

			
}
