using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

using System.Windows.Controls;
using QXP.Batch.Interop;
using QXPBatchService = QXP.Batch.Client.QXPServiceReference;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Batch.Client
{
    /// <summary>
    /// Class ServiceCallback : Description
    /// </summary>
    /// <author>doufarm</author>
    /// <date>29/10/2012 12:18:59</date>    
    [CallbackBehavior(ConcurrencyMode = ConcurrencyMode.Reentrant)]
    public class ServiceCallback : QXPServiceReference.IServiceCallback
    {
        #region Membres
        Main _mainForm = null;
        MenuItem _menuInfo = null;
        MenuItem _menuRun = null;
        MenuItem _menuUpload = null;
        #endregion Membres

        #region Constantes
        const int maxRows = 500;

        const string menuNameInfo = "menuInfo";
        const string menuNameRun = "menuRun";
        const string menuNameUpload = "menuUpload";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ServiceCallback
        /// </summary>
        /// <param name="listBox"></param>
        public ServiceCallback(Main mainForm)
        {
            _mainForm = mainForm;
            _menuInfo = mainForm.FindName(menuNameInfo) as MenuItem;
            _menuRun = mainForm.FindName(menuNameRun) as MenuItem;
            _menuUpload = mainForm.FindName(menuNameUpload) as MenuItem;
        }


        #endregion Constructeur

        #region M�thodes

        #region IEventMessageCallback Members

        /// <summary>
        /// Survient lorsque le serveur envoit un message au client
        /// </summary>
        /// <param name="message_Type">type de message</param>
        /// <param name="message"></param>
        //public void OnReceiveMessage(QXPBatchService.Message_Type message_Type, string message)
        //{
        //    switch (message_Type)
        //    {
        //        case QXPBatchService.Message_Type.Information:
        //            if (_menuInfo == null || !_menuInfo.IsChecked) return;
        //            break;
        //        case QXPBatchService.Message_Type.Run:
        //            if (_menuRun == null || !_menuRun.IsChecked) return;
        //            break;
        //        case QXPBatchService.Message_Type.Upload:
        //            if (_menuUpload == null || !_menuUpload.IsChecked) return;
        //            break;
        //        default:
        //            //Les autres type de message sont afffich�s sans condition
        //            break;

        //    }

        //    ListBoxItem __item = new ListBoxItem();
        //    __item.Content = message;


        //    if (_mainForm.listMessages.Items.Count > maxRows)
        //    {
        //        _mainForm.listMessages.Items.RemoveAt(maxRows);
        //    }
        //    _mainForm.listMessages.Items.Insert(0, __item);
        //}

        public void OnReceiveMessage(Message_Type message_type, string message)
        {
            switch (message_type)
            {
                case Message_Type.Information:
                    if (_menuInfo == null || !_menuInfo.IsChecked) return;
                    break;
                case Message_Type.Run:
                    if (_menuRun == null || !_menuRun.IsChecked) return;
                    break;
                case Message_Type.Upload:
                    if (_menuUpload == null || !_menuUpload.IsChecked) return;
                    break;
                default:
                    //Les autres type de message sont afffich�s sans condition
                    break;

            }

            ListBoxItem __item = new ListBoxItem();
            __item.Content = message;


            if (_mainForm.listMessages.Items.Count > maxRows)
            {
                _mainForm.listMessages.Items.RemoveAt(maxRows);
            }
            _mainForm.listMessages.Items.Insert(0, __item);
        }

        /// <summary>
        /// Survient lorsque le server nous pr�vient qu'il se d�connecte
        /// </summary>
        public void ServerClosed()
        {
            _mainForm.listMessages.Items.Insert(0, new ListBoxItem() { Content = "Server Closed" });
        }
        #endregion

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
