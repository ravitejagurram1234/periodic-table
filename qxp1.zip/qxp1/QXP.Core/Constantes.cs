using System;

/* 
 * Code g�n�r� avec le template project : QXP.ProjectTemplate
*/
namespace QXP.Core
{
	/// <summary>
	/// Ensembles des Constantes communes au module QXP.Core
	/// </summary>
	/// <author>doufarm</author>
	/// <date>14/11/2011 11:00:52</date>    
	public class Constantes
	{

	}
}
