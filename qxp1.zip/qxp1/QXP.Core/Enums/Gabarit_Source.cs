using System;

namespace QXP.Core
{
	/// <summary>
	/// D�fini la source d'un gabarit Quark (l'origine du document Qxp qui sera modifi� par le g�n�rateur Quark)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>09/11/2011 14:27:21</date>    
	public enum Gabarit_Source
	{
		/// <summary>
		/// Partir du gabarit 
		/// </summary>
		Gabarit = 1 ,
		/// <summary>
		/// Partir du document precedemment g�n�r� sur le suivi en cours
		/// </summary>
		DocumentCourant = 2,
		/// <summary>
		/// Partir du dernier document qxp certifi� sur le suivi pr�c�dent (m�me fond/part/langue/date_echeance etc..) au suivi en cours
		/// </summary>
		DocumentPrecedentCertifie = 3,
		/// <summary>
		/// Partir du dernier document qxp d'un suivi sp�cifique
		/// </summary>
		DocumentSuivi = 4,
	}
}
