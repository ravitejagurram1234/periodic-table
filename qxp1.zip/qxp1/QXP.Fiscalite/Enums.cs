using System;

/* 
 * Code g�n�r� avec le template project : QXP.ProjectTemplate
*/
namespace QXP.Fiscalite
{
    /// <summary>
    /// Ensembles des �num�rations communes au module QXP.Fiscalite
    /// </summary>
    /// <author>cueffl</author>
    /// <date>07/05/2010 10:43:37</date>    
    public class Enums
    {

    }
}
