using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using Oracle.DataAccess.Client;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPProxy = QXP.Framework.Proxy;

/* 
 * Code g�n�r� avec le template : QXPProxyClass
*/
namespace QXP.Fiscalite.Proxy
{
    /// <summary>
    /// Proxy ProxyFiscalite : Description
    /// </summary>
    /// <author>cueffl</author>
    /// <date>07/05/2010 10:45:46</date>    
    public class ProxyFiscalite : QXPProxy.BaseProxy
    {
        #region Membres

        #endregion Membres

        #region Constantes

        private const string PACKAGE = "QXP_PK_FISCALITE.";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ProxyFiscalite
        /// </summary>
        public ProxyFiscalite()
        {
        }

        /// <summary>
        /// Cr�e une instance de ProxyFiscalite
        /// </summary>
        /// <param name="oraClient">Connexion Oracle</param>
        public ProxyFiscalite(QXPDataOracle.OraClient oraClient)
            : base(oraClient)
        {
        }

        /// <summary>
        /// Cr�e une instance de ProxyFiscalite
        /// </summary>
        /// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
        public ProxyFiscalite(string dataBase)
            : base(dataBase)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #region Acc�s Base

        #region SELECT


        /// <summary>
        /// Retourne la liste des fonds pour la fiscalit�
        /// </summary>
        /// <returns>Liste des fonds</returns>        
        public NameValueCollection GetListFundFiscalite()
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            NameValueCollection __listeType_Fonds = new NameValueCollection();

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "GetListFundFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                while (__odr.Read())
                {
                    __listeType_Fonds.Add(__odr["id_fnd_code"], __odr["nom_fonds"]);
                }
            }

            return __listeType_Fonds;
        }

        /// <summary>
        /// Retourne la liste des types de fonds pour la fiscalit�
        /// </summary>
        /// <returns>Liste des types de fonds</returns>        
        public List<Type_Fonds> GetListeTypeFundFiscalite()
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            List<Type_Fonds> __listeType_Fonds = new List<Type_Fonds>();

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "GetListeTypeFundFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                while (__odr.Read())
                {
                    var __type_Fonds = new Type_Fonds() { Id_Fisc_Ref_Type_Fonds = __odr["id_fisc_ref_type_fonds"], Label = __odr["label"] };
                    __listeType_Fonds.Add(__type_Fonds);
                }
            }

            return __listeType_Fonds;
        }

        /// <summary>
        /// Retourne le type de fonds d'un fonds pour la fiscalit�
        /// </summary>
        /// <param name="id_fnd_code">Identifiant du fonds de type string</param>
        /// <returns>Type_Fonds</returns>
        public Type_Fonds GetTypeFundFiscalite(string id_fnd_code)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            Type_Fonds __type_Fonds = null;

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
                           .AddParameterToSqlParamList("p_id_fnd_code", id_fnd_code);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "GetTypeFundFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                if (__odr.Read())
                {
                    __type_Fonds = new Type_Fonds() { Id_Fisc_Ref_Type_Fonds = __odr["id_fisc_ref_type_fonds"], Label = __odr["label"] };
                }
            }

            return __type_Fonds;
        }    			

        /// <summary>
        /// Retourne la liste des parts d'un fonds pour la fiscalit�
        /// </summary>
        /// <param name="id_fnd_code">Identifiant du fonds de type string</param>
        /// <returns>Liste des parts d'un fonds</returns>        
        public NameValueCollection GetListPartFundFiscalite(string id_fnd_code)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            NameValueCollection __listeParts = new NameValueCollection();

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
                           .AddParameterToSqlParamList("p_id_fnd_code", id_fnd_code);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "GetListPartFundFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                while (__odr.Read())
                {
                    __listeParts.Add(__odr["id_unit_code"], __odr["libelle_part"]);
                }
            }

            return __listeParts;
        }

        /// <summary>
        /// Retourne toutes les devises du fonds de la derni�re valorisation d'un fonds pour la fiscalit�
        /// </summary>
        /// <param name="id_fnd_code">Identifiant du fonds de type string</param>
        /// <param name="id_unit_code">Identifiant d'une part du fonds de type string</param>
        /// <returns>Liste des devises</returns>        
        public NameValueCollection GetListDeviseFiscalite(string id_fnd_code, string id_unit_code)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            NameValueCollection __listeDevise = new NameValueCollection();

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
                           .AddParameterToSqlParamList("p_id_fnd_code", id_fnd_code)
                           .AddParameterToSqlParamList("p_id_unit_code", id_unit_code);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "GetListDeviseFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                while (__odr.Read())
                {
                    __listeDevise.Add(__odr["devise"], __odr["libelle"]);
                }
            }

            return __listeDevise;
        }

        /// <summary>
        /// Retourne la liste des types de taxe pour la fiscalit�
        /// </summary>
        /// <returns>Liste des types de taxe</returns>        
        public NameValueCollection GetListTypeTaxeFiscalite()
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            NameValueCollection __listeTypeTaxe = new NameValueCollection();

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "GetListTypeTaxeFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                while (__odr.Read())
                {
                    __listeTypeTaxe.Add(__odr["id_ntax_type"], __odr["id_ntax_type"]);
                }
            }

            return __listeTypeTaxe;
        }

        /// <summary>
        /// Retourne la liste des dates r�f�rences pour la fiscalit�
        /// </summary>
        /// <param name="id_fnd_code">Identifiant du fonds de type string</param>
        /// <param name="id_unit_code">Identifiant de la part fonds de type string</param>
        /// <param name="devise">Devise</param>
        /// <param name="type_tax">Type de taxe</param>
        /// <returns>Liste des dates r�f�rences</returns>        
        public NameValueCollection GetListDateReferenceFiscalite(string id_fnd_code, string id_unit_code, string devise, string type_tax)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            NameValueCollection __listeDevise = new NameValueCollection();

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
                           .AddParameterToSqlParamList("p_id_fnd_code", id_fnd_code)
                           .AddParameterToSqlParamList("p_id_unit_code", id_unit_code)
                           .AddParameterToSqlParamList("p_devise", devise)
                           .AddParameterToSqlParamList("p_type_tax", type_tax);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "GetListDateReferenceFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                while (__odr.Read())
                {
                    __listeDevise.Add(QXPFrk.ConversionInvariante.ToString(__odr["date_ref"]), QXPFrk.Conversion.ToString(__odr["date_ref"]));
                }
            }

            return __listeDevise;
        }


        /// <summary>
        /// Retourne l'ensemble des informations de fiscalit� d'une part d'un fonds
        /// </summary>
        /// <param name="id_fnd_code">Identifiant du fonds de type string</param>
        /// <param name="id_unit_code">Identifiant de la part fonds de type string</param>
        /// <param name="devise">Devise</param>
        /// <param name="type_tax">Type de taxe</param>
        /// <param name="date_ref">Date de r�f�rence</param>
        /// <returns>InfoFiscalite de type InfoFiscalite</returns>
        public InfoFiscalite GetInfoFiscalite(string id_fnd_code, string id_unit_code, string devise, string type_tax, DateTime date_ref)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            InfoFiscalite __infoFiscalite = null;

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
                           .AddParameterToSqlParamList("p_id_fnd_code", id_fnd_code)
                           .AddParameterToSqlParamList("p_id_unit_code", id_unit_code)
                           .AddParameterToSqlParamList("p_devise", devise)
                           .AddParameterToSqlParamList("p_type_tax", type_tax)
                           .AddParameterToSqlParamList("p_date_ref", date_ref);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "GetInfoFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                if (__odr.Read())
                {
                    __infoFiscalite = new InfoFiscalite();
                    __infoFiscalite.Code_fonds = __odr["code_fonds"];
                    __infoFiscalite.Nom_fonds = __odr["nom_fonds"];
                    __infoFiscalite.Isin = __odr["isin"];
                    __infoFiscalite.Type_fonds = new Type_Fonds() { Id_Fisc_Ref_Type_Fonds = __odr["id_fisc_ref_type_fonds"], Label = __odr["type_fonds"] };
                    __infoFiscalite.Dev_fonds = __odr["dev_fonds"];
                    __infoFiscalite.Code_part = __odr["code_part"];
                    __infoFiscalite.Type_part = __odr["type_part"];
                    __infoFiscalite.Type_tax = __odr["type_tax"];
                    __infoFiscalite.Actif = __odr["actif"];
                    __infoFiscalite.Yield_part = __odr["yield_part"];
                    __infoFiscalite.Date_deb_yield = __odr["date_deb_yield"];
                    __infoFiscalite.Date_fin_yield = __odr["date_fin_yield"];
					__infoFiscalite.Ter_part = __odr["ter_part"];
                    __infoFiscalite.Date_deb_ter = __odr["date_deb_ter"];
                    __infoFiscalite.Date_fin_ter = __odr["date_fin_ter"];
                    __infoFiscalite.Coeff_alloc = __odr["coeff_alloc"];
                    __infoFiscalite.Date_ref = __odr["date_ref"];
                    __infoFiscalite.Seuil_mat_tunnel = __odr["seuil_mat_tunnel"];
                    __infoFiscalite.Nb_jour_tunnel = __odr["nb_jour_tunnel"];
                    __infoFiscalite.Valeurs_extr = __odr["valeurs_extr"];
                    __infoFiscalite.Seuil_mat_yield = __odr["seuil_mat_yield"];
                    __infoFiscalite.Seuil_mat_classe = __odr["seuil_mat_classe"];
                    __infoFiscalite.Seuil_corr_vni = __odr["seuil_corr_vni"];
                    __infoFiscalite.Statut_diffusion = __odr["statut_diffusion"];
                    __infoFiscalite.Isin_part_dev = __odr["isin_part_dev"];
                }
            }

            return __infoFiscalite;
        }


        /// <summary>
        /// Retourne les informations vides de fiscalit� d'une part d'un fonds
        /// </summary>
        /// <param name="id_fnd_code">Identifiant du fonds de type string</param>
        /// <param name="id_unit_code">Identifiant de la part fonds de type string</param>
        /// <param name="devise">Devise</param>
        /// <returns>InfoFiscalite de type InfoFiscalite</returns>
        public InfoFiscalite GetEmptyInfoFiscalite(string id_fnd_code, string id_unit_code, string devise)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            InfoFiscalite __infoFiscalite = null;

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
                           .AddParameterToSqlParamList("p_id_fnd_code", id_fnd_code)
                           .AddParameterToSqlParamList("p_id_unit_code", id_unit_code)
                           .AddParameterToSqlParamList("p_devise", devise);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "GetEmptyInfoFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {
                if (__odr.Read())
                {
                    __infoFiscalite = new InfoFiscalite();
                    __infoFiscalite.Code_fonds = __odr["code_fonds"];
                    __infoFiscalite.Nom_fonds = __odr["nom_fonds"];
                    __infoFiscalite.Isin = __odr["isin"];
                    __infoFiscalite.Dev_fonds = __odr["dev_fonds"];
                    __infoFiscalite.Code_part = __odr["code_part"];
                    __infoFiscalite.Type_part = __odr["type_part"];
                }
            }

            return __infoFiscalite;
        }
        
        #endregion SELECT

        #region INSERT / UPDATE / DELETE

        /// <summary>
        /// Met � jour le type fonds d'un fonds fiscalit�
        /// </summary>
        /// <param name="id_fnd_code">Identifiant du fonds de type string</param>
        /// <param name="type_fonds">Type fonds</param>
        public void UpdateTypeFundFiscalite(string id_fnd_code, Type_Fonds type_fonds)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("p_id_fnd_code", id_fnd_code)
                           .AddParameterToSqlParamList("p_id_Fisc_Ref_Type_Fonds", type_fonds.Id_Fisc_Ref_Type_Fonds);
            //             .AddParameterToSqlParamList("p_nameOfYourParameter", valueOfparameter);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "UpdateTypeFundFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            try
            {
                //A d�commenter uniquement si plusieurs op�rations sont r�alis�es dans le try (plusieurs Execute / ExecuteScalar)
                //this.OracleClient.BeginTransaction();

                this.Execute(__sqlRequest);


                //A d�commenter uniquement si plusieurs op�rations sont r�alis�es dans le try (plusieurs Execute / ExecuteScalar)
                //this.OracleClient.CommitTransaction();                
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de la mise � jour de string : ", ex);
                //A d�commenter uniquement si plusieurs op�rations sont r�alis�es dans le try (plusieurs Execute / ExecuteScalar)
                //this.OracleClient.RollBackTransaction();
                throw;
            }
        }

        /// <summary>
        /// Sauvegarde une InfoFiscalite d'une part d'un fonds
        /// </summary>
        /// <param name="infoFiscalite">InfoFiscalite de type InfoFiscalite</param>
        public void SauvegardeInfoFiscalite(InfoFiscalite infoFiscalite)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("p_id_fnd_code", infoFiscalite.Code_fonds)
                           .AddParameterToSqlParamList("p_nom_fonds", infoFiscalite.Nom_fonds)
                           .AddParameterToSqlParamList("p_isin", infoFiscalite.Isin)
                           .AddParameterToSqlParamList("p_id_fisc_ref_type_fonds", infoFiscalite.Type_fonds.Id_Fisc_Ref_Type_Fonds)
                           .AddParameterToSqlParamList("p_devise", infoFiscalite.Dev_fonds)
                           .AddParameterToSqlParamList("p_id_unit_code", infoFiscalite.Code_part)
                           .AddParameterToSqlParamList("p_type_part", infoFiscalite.Type_part)
                           .AddParameterToSqlParamList("p_type_tax", infoFiscalite.Type_tax)
                           .AddParameterToSqlParamList("p_actif", infoFiscalite.Actif)
                           .AddParameterToSqlParamList("p_yield_part", infoFiscalite.Yield_part)
                           .AddParameterToSqlParamList("p_date_deb_yield", infoFiscalite.Date_deb_yield)
                           .AddParameterToSqlParamList("p_date_fin_yield", infoFiscalite.Date_fin_yield)
                           .AddParameterToSqlParamList("p_ter_part", infoFiscalite.Ter_part)
                           .AddParameterToSqlParamList("p_date_deb_ter", infoFiscalite.Date_deb_ter)
                           .AddParameterToSqlParamList("p_date_fin_ter", infoFiscalite.Date_fin_ter)
                           .AddParameterToSqlParamList("p_coeff_alloc", infoFiscalite.Coeff_alloc)
                           .AddParameterToSqlParamList("p_date_ref", infoFiscalite.Date_ref)
                           .AddParameterToSqlParamList("p_seuil_mat_tunnel", infoFiscalite.Seuil_mat_tunnel)
                           .AddParameterToSqlParamList("p_nb_jour_tunnel", infoFiscalite.Nb_jour_tunnel)
                           .AddParameterToSqlParamList("p_valeurs_extr", infoFiscalite.Valeurs_extr)
                           .AddParameterToSqlParamList("p_seuil_mat_yield", infoFiscalite.Seuil_mat_yield)
                           .AddParameterToSqlParamList("p_seuil_mat_classe", infoFiscalite.Seuil_mat_classe)
                           .AddParameterToSqlParamList("p_seuil_corr_vni", infoFiscalite.Seuil_corr_vni)
                           .AddParameterToSqlParamList("p_statut_diffusion", infoFiscalite.Statut_diffusion)
                           .AddParameterToSqlParamList("p_isin_part_dev", infoFiscalite.Isin_part_dev);

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "SauvegardeInfoFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            try
            {
                //A d�commenter uniquement si plusieurs op�rations sont r�alis�es dans le try (plusieurs Execute / ExecuteScalar)
                //this.OracleClient.BeginTransaction();

                this.Execute(__sqlRequest);


                //A d�commenter uniquement si plusieurs op�rations sont r�alis�es dans le try (plusieurs Execute / ExecuteScalar)
                //this.OracleClient.CommitTransaction();                 
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de l'insertion de InfoFiscalite : ", ex);
                //A d�commenter uniquement si plusieurs op�rations sont r�alis�es dans le try (plusieurs Execute / ExecuteScalar)
                //this.OracleClient.RollBackTransaction();
                throw;
            }
        }

        /// <summary>
        /// Met � jour la statut d'activation
        /// </summary>
        /// <param name="infoFiscalite">InfoFiscalite de type InfoFiscalite</param>
        public void UpdateStatutFiscalite(InfoFiscalite infoFiscalite)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("p_id_fnd_code", infoFiscalite.Code_fonds)
                           .AddParameterToSqlParamList("p_nom_fonds", infoFiscalite.Nom_fonds)
                           .AddParameterToSqlParamList("p_isin", infoFiscalite.Isin)
                           .AddParameterToSqlParamList("p_id_fisc_ref_type_fonds", infoFiscalite.Type_fonds.Id_Fisc_Ref_Type_Fonds)
                           .AddParameterToSqlParamList("p_devise", infoFiscalite.Dev_fonds)
                           .AddParameterToSqlParamList("p_id_unit_code", infoFiscalite.Code_part)
                           .AddParameterToSqlParamList("p_type_part", infoFiscalite.Type_part)
                           .AddParameterToSqlParamList("p_type_tax", infoFiscalite.Type_tax)
                           .AddParameterToSqlParamList("p_actif", infoFiscalite.Actif)
                           .AddParameterToSqlParamList("p_statut_diffusion", infoFiscalite.Statut_diffusion)
                           .AddParameterToSqlParamList("p_isin_part_dev", infoFiscalite.Isin_part_dev);
                          

            #endregion Definition des OraParameters

            __sql = string.Concat(PACKAGE, "UpdateStatutFiscalite");

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            try
            {
                //A d�commenter uniquement si plusieurs op�rations sont r�alis�es dans le try (plusieurs Execute / ExecuteScalar)
                //this.OracleClient.BeginTransaction();

                this.Execute(__sqlRequest);


                //A d�commenter uniquement si plusieurs op�rations sont r�alis�es dans le try (plusieurs Execute / ExecuteScalar)
                //this.OracleClient.CommitTransaction();                
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de la mise � jour de object : ", ex);
                //A d�commenter uniquement si plusieurs op�rations sont r�alis�es dans le try (plusieurs Execute / ExecuteScalar)
                //this.OracleClient.RollBackTransaction();
                throw;
            }
        }

        #endregion INSERT / UPDATE / DELETE

        #endregion Acc�s Base

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
