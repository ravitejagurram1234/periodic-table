using System;
/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Fiscalite
{
    /// <summary>
    /// Objet InfoFiscalite
    /// </summary>
    /// <author>cueffl</author>
    /// <date>07/05/2010 15:50:41</date>    
    public class InfoFiscalite
    {
        #region Membres

        string _code_fonds;
        string _nom_fonds;
        string _isin;
        Type_Fonds _type_fonds;
        string _dev_fonds;
        string _code_part;
        string _type_part;
        string _type_tax;
        bool _actif;
        decimal _yield_part;
        DateTime _date_deb_yield;
        DateTime _date_fin_yield;
        decimal _ter_part;
        DateTime _date_deb_ter;
        DateTime _date_fin_ter;
        decimal _coeff_alloc;
        DateTime _date_ref;
        decimal _seuil_mat_tunnel;
        int _nb_jour_tunnel;
        int _valeurs_extr;
        decimal _seuil_mat_yield;
        decimal _seuil_mat_classe;
        decimal _seuil_corr_vni;
        bool statut_diffusion;
        string isin_part_dev;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de InfoFiscalite
        /// </summary>
        public InfoFiscalite()
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        public string Code_fonds
        {
            get { return _code_fonds; }
            set { _code_fonds = value; }
        }

        public string Nom_fonds
        {
            get { return _nom_fonds; }
            set { _nom_fonds = value; }
        }

        public string Isin
        {
            get { return _isin; }
            set { _isin = value; }
        }

        public Type_Fonds Type_fonds
        {
            get { return _type_fonds; }
            set { _type_fonds = value; }
        }

        public string Dev_fonds
        {
            get { return _dev_fonds; }
            set { _dev_fonds = value; }
        }

        public string Code_part
        {
            get { return _code_part; }
            set { _code_part = value; }
        }

        public string Type_part
        {
            get { return _type_part; }
            set { _type_part = value; }
        }

        public string Type_tax
        {
            get { return _type_tax; }
            set { _type_tax = value; }
        }

        public bool Actif
        {
            get { return _actif; }
            set { _actif = value; }
        }

        public decimal Yield_part
        {
            get { return _yield_part; }
            set { _yield_part = value; }
        }

        public DateTime Date_deb_yield
        {
            get { return _date_deb_yield; }
            set { _date_deb_yield = value; }
        }

        public DateTime Date_fin_yield
        {
            get { return _date_fin_yield; }
            set { _date_fin_yield = value; }
        }

        public decimal Ter_part
        {
            get { return _ter_part; }
            set { _ter_part = value; }
        }

        public DateTime Date_deb_ter
        {
            get { return _date_deb_ter; }
            set { _date_deb_ter = value; }
        }

        public DateTime Date_fin_ter
        {
            get { return _date_fin_ter; }
            set { _date_fin_ter = value; }
        }

        public decimal Coeff_alloc
        {
            get { return _coeff_alloc; }
            set { _coeff_alloc = value; }
        }

        public DateTime Date_ref
        {
            get { return _date_ref; }
            set { _date_ref = value; }
        }

        public decimal Seuil_mat_tunnel
        {
            get { return _seuil_mat_tunnel; }
            set { _seuil_mat_tunnel = value; }
        }

        public int Nb_jour_tunnel
        {
            get { return _nb_jour_tunnel; }
            set { _nb_jour_tunnel = value; }
        }

        public int Valeurs_extr
        {
            get { return _valeurs_extr; }
            set { _valeurs_extr = value; }
        }

        public decimal Seuil_mat_yield
        {
            get { return _seuil_mat_yield; }
            set { _seuil_mat_yield = value; }
        }

        public decimal Seuil_mat_classe
        {
            get { return _seuil_mat_classe; }
            set { _seuil_mat_classe = value; }
        }

        public decimal Seuil_corr_vni
        {
            get { return _seuil_corr_vni; }
            set { _seuil_corr_vni = value; }
        }

        public bool Statut_diffusion
        {
            get { return statut_diffusion; }
            set { statut_diffusion = value; }
        }
        public string Isin_part_dev
        {
            get { return isin_part_dev; }
            set { isin_part_dev = value; }
        }

        #endregion Propri�t�s
    }
}
