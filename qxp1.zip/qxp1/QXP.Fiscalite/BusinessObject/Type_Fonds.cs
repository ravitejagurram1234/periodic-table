/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Fiscalite
{
    /// <summary>
    /// Type_Fonds : Type de fonds pour la fiscalit� (bonds...)
    /// </summary>
    /// <author>cueffl</author>
    /// <date>29/08/2011 15:28:25</date>    
    public class Type_Fonds
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Type_Fonds
        /// </summary>
        public Type_Fonds()
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Identifiants du type de fonds
        /// </summary>
        public int Id_Fisc_Ref_Type_Fonds
        {
            get;
            set;
        }

        /// <summary>
        /// Type de fonds
        /// </summary>
        public string Label
        {
            get;
            set;
        }

        #endregion Propri�t�s
    }
}
