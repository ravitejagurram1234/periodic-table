﻿using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;

/* 
 * Code généré avec le template : QXPObjectClass
*/

namespace QXP.Batch.Core
{
    /// <summary>
    /// BatchCoreSetting définit la section de configuration du batch
    /// </summary>
    /// <author>mdoufar</author>
    /// <date>12/10/2010 09:49:31</date>    
    public class BatchCoreSetting : QXPFrk.Configuration.BaseSetting<BatchCoreSetting>
    {
        #region Membres

        #endregion Membres

        #region Constantes
		private const string BATCHCORE_SECTION					= "QXP.Batch.Core";

		private const string Path_Run_Engine_KEY				= "Path_Run_Engine";
		private const string Display_Detail_KEY					= "Display_Detail";
		private const string Display_Info_KEY					= "Display_Info";
		private const string ShutDown_TimeOut_Seconds_KEY		= "ShutDown_TimeOut_Seconds";
		private const string Worker_Thread_Wait_Seconds_KEY		= "Worker_Thread_Wait_Seconds";
		private const string Run_Execution_TimeOut_Seconds_KEY	= "Run_Execution_TimeOut_Seconds";
		private const string Watcher_Wait_Seconds_KEY			= "Watcher_Wait_Seconds";
		private const string Show_Run_Windows_KEY				= "Show_Run_Windows";
		private const string Number_Of_Threads_KEY				= "Number_Of_Threads";
		private const string App_Prefixe_KEY					= "App_Prefixe";
		private const string RunUploadPoolPath_KEY				= "RunUploadPoolPath";
		private const string Checker_Join_TimeOut_Seconds_KEY	= "Checker_Join_TimeOut_Seconds";
		private const string Enabled_Watcher_Planning_KEY		= "Enabled_Watcher_Planning";
		private const string CommandTimeOut_KEY					= "Command_TimeOut";
		private const string QXPSERVERLAUNCHER_KEY				= "QXPServerLauncher";        
        
		#endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Crée une instance de EngineCoreSetting
        /// </summary>
        public BatchCoreSetting() : base(BATCHCORE_SECTION)
        {
        }

        #endregion Constructeur

        #region Méthodes

        #endregion Méthodes

        #region Propriétés

        /// <summary>
        /// Chemin absolu de QuarkXpress Server généralement 
        /// </summary>
        public string	QuarkXpressServerLauncher
        {
            get
            {
                return this.GetString(QXPSERVERLAUNCHER_KEY);
            }
        }   


        /// <summary>
        /// 
        /// </summary>
        public string	Path_Run_Engine
        {
            get
            {
                return this.GetString(Path_Run_Engine_KEY, "C:\\VS2005\\EOS\\DEV_V3.5\\SRC\\QXP\\QXP.Engine\\bin\\Debug\\QXP.Engine.exe");
            }
        }   

        /// <summary>
        /// 
        /// </summary>
        public bool		Display_Detail
        {
            get
            {
                return this.GetBool(Display_Detail_KEY, false);
            }
        }   

        /// <summary>
        /// 
        /// </summary>
        public bool		Display_Info
        {
            get
            {
                return this.GetBool(Display_Info_KEY, true);
            }
        }   

        /// <summary>
        /// 
        /// </summary>
        public int		ShutDown_TimeOut_Seconds
        {
            get
            {
                return this.GetInt(ShutDown_TimeOut_Seconds_KEY, 60);
            }
        }   

        /// <summary>
        /// 
        /// </summary>
        public int		Worker_Thread_Wait_Seconds
        {
            get
            {
                return this.GetInt(Worker_Thread_Wait_Seconds_KEY, 2);
            }
        }   

		/// <summary>
        /// 
        /// </summary>
        public int		Run_Execution_TimeOut_Seconds
        {
            get
            {
                return this.GetInt(Run_Execution_TimeOut_Seconds_KEY, 600);
            }
        }   

		/// <summary>
        /// 
        /// </summary>
        public int		Watcher_Wait_Seconds
        {
            get
            {
                return this.GetInt(Watcher_Wait_Seconds_KEY, 2);
            }
        }   

		/// <summary>
        /// 
        /// </summary>
        public bool		Show_Run_Windows
        {
            get
            {
                return this.GetBool(Show_Run_Windows_KEY, false);
            }
        }   

		/// <summary>
        /// 
        /// </summary>
        public int		Number_Of_Threads
        {
            get
            {
                return this.GetInt(Number_Of_Threads_KEY, 2);
            }
        }   

		/// <summary>
        /// 
        /// </summary>
        public string	App_Prefixe
        {
            get
            {
                return this.GetString(App_Prefixe_KEY, "QXPB:");
            }
        }   

		/// <summary>
        /// 
        /// </summary>
        public string	RunUploadPoolPath
        {
            get
            {
                return this.GetString(RunUploadPoolPath_KEY, "Upload\\");
            }
        }

		/// <summary>
		/// 
		/// </summary>
		public int		Command_TimeOut
		{
			get
			{
				return this.GetInt(CommandTimeOut_KEY, 30);
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public int		Checker_Join_TimeOut_Seconds
		{
			get
			{
				return this.GetInt(Checker_Join_TimeOut_Seconds_KEY, 30);
			}
		}
        
		/// <summary>
		/// 
		/// </summary>
		public bool		Enabled_Watcher_Planning
		{
			get
			{
				return this.GetBool(Enabled_Watcher_Planning_KEY, true);
			}
		} 	
        
		#endregion Propriétés
    }
}
