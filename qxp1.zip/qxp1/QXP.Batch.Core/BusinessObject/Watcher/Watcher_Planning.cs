using System;
using System.Collections.Generic;
using System.Runtime.Remoting;
using System.Text;
using System.Threading;
using QXPFrk = QXP.Framework;

namespace QXP.Batch.Core
{
    public class Watcher_Planning
	{
		#region internal variables
		static Dictionary<int ,Day_Planning> _week = new Dictionary<int, Day_Planning>();
		const string week_StartTime		= "06:00:00";
		const string week_EndTime		= "23:59:59"; // "24:00:00" ne fonctionne pas
		const string saturday_StartTime	= "06:00:00";
		const string saturday_EndTime	= "12:00:00";
		const string sunday_StartTime	= "18:00:00";
		const string sunday_EndTime		= "23:59:59"; // "24:00:00" ne fonctionne pas
		enum Day_Name{
			Monday = 0,
			Tuesday,
			Wednesday,
			Thursday,
			Friday,
			Saturday,
			Sunday,
		}
		#endregion
		static Watcher_Planning(){
			//Load planning
			Add_Day_Planning(Day_Name.Monday, week_StartTime, week_EndTime);
			Add_Day_Planning(Day_Name.Tuesday, week_StartTime, week_EndTime);
			Add_Day_Planning(Day_Name.Wednesday, week_StartTime, week_EndTime);
			Add_Day_Planning(Day_Name.Thursday, week_StartTime, week_EndTime);
			Add_Day_Planning(Day_Name.Friday, week_StartTime, week_EndTime);
			Add_Day_Planning(Day_Name.Saturday, saturday_StartTime, saturday_EndTime);
			Add_Day_Planning(Day_Name.Sunday, sunday_StartTime, sunday_EndTime);
        }
		static void			Add_Day_Planning(Day_Name dayofWeek, string start_time, string end_time){
			_week.Add((int)dayofWeek, new Day_Planning(start_time, end_time));	
		}
		public static bool	Is_InPlanning(){
			DateTime		__now			= DateTime.Now;
            int __day = QXPFrk.DateHelper.GetDayOfWeek(__now);
			Day_Planning	__day_planning	= _week[__day];
			return __day_planning.Inside(__now.TimeOfDay);
		}
    }
	public class Day_Planning{
		const string EndDayTime			= "23:59:59"; // "24:00:00" ne fonctionne pas	

		TimeSpan _start_Time	= TimeSpan.Zero; //0H
		TimeSpan _end_Time		= TimeSpan.Parse(EndDayTime);
		
		public Day_Planning(string start_Time, string end_Time):this(Evaluate(start_Time), Evaluate(end_Time)){}
		public Day_Planning(TimeSpan start_Time, TimeSpan end_Time){
			if(start_Time >= _start_Time)	_start_Time = start_Time;
			if(end_Time <= _end_Time)		_end_Time	= end_Time;
		}
		static TimeSpan	Evaluate(string time){
			TimeSpan __time;
			if(TimeSpan.TryParse(time, out __time))	return __time;
			else 									return TimeSpan.Zero;
		}
		public TimeSpan Start_Time{
			get{return _start_Time;}
		}
		public TimeSpan End_Time{
			get{return _end_Time;}
		}
		public bool		Inside(TimeSpan time){
			return (time >= _start_Time && time <= _end_Time);
		}
	}
}
