using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Threading;

namespace QXP.Batch.Core
{
    public class Run_Queue_Item : IEquatable<Run_Queue_Item>
    {
        
        private int _id_run;
        
        public Run_Queue_Item(int id_run)
        {
            _id_run = id_run;
        }
        
        public int ID_Run
        {
            get { return _id_run; }
            set { _id_run = value; }
        }

        bool IEquatable<Run_Queue_Item>.Equals(Run_Queue_Item item)
        {
            return (_id_run == item.ID_Run);
        }
    }
}
