using System;
using System.Collections.Generic;
using System.Runtime.Remoting;
using System.Text;
using System.Threading;

namespace QXP.Batch.Core
{
    public class Checker_Thread
	{
		#region internal variables
		#endregion
		public static void  Start(){
			Trace_Helper.Set_Trace_Context(new Trace_Context("Checker_Thread"));
			
			Trace_Helper.Log_InfoMessage("D�marrage du Checker");
			
			//upload des documents(gabarit) modifier par les Graphistes
			UploadDocuments();
			
			//Recherche des elements � g�n�rer et mise dans la queue !
			CheckRuns();
            
			Trace_Helper.Log_InfoMessage("Fin du Checker");
        }
        static void         UploadDocuments(){
           UploadManager.Check();
        }
        static void         CheckRuns(){
			Trace_Helper.Log_InfoMessage("D�but - Check Runs");
            Proxy.RunProxy  __proxy     = new Proxy.RunProxy();
            List<int>       __runs      = __proxy.GetRuns();
            if(__runs.Count > 0){
				Trace_Helper.Log_InfoMessage("{0} Run(s) planifi�(s))", __runs.Count > 0);
            }else{
				Trace_Helper.Log_InfoMessage("Fin - Check Runs (aucun run planifi�)");
                return;
            }
            foreach(int _id_run in __runs){
				Trace_Helper.Log_InfoMessage("Ajout run {0} dans la queue", _id_run);
                Run_Queue.Enqueue(new Run_Queue_Item(_id_run));
            }
            Worker_Thread.Set_Loop_Events();
			Trace_Helper.Log_InfoMessage("Fin - Check Runs");
        }
    }
}
