using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Threading;

namespace QXP.Batch.Core
{
   public class Run_Queue{
       static object                SyncRoot = new object();
       static Queue<Run_Queue_Item> _queue = new Queue<Run_Queue_Item>();
       public static void              Enqueue(Run_Queue_Item item){
           lock(SyncRoot){
               if (!_queue.Contains(item))
               {
                   _queue.Enqueue(item);
               }
           }
       }
       public static Run_Queue_Item    Dequeue(){
           Run_Queue_Item __item = null;
           lock(SyncRoot){
                if(_queue.Count > 0){
                    __item = _queue.Dequeue();
                }
           } 
           return __item;
       }
       public static int               Count{
            get{
                int __count;
                lock(SyncRoot){
                    __count = _queue.Count;
                }
                return __count;
            }
       }
   }
}
