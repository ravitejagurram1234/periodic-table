using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;

using QXPFrk    = QXP.Framework;

namespace QXP.Batch.Core
{
    public class Worker_Thread
    {
        static          TimeSpan         _timeout;
        //Permet d'avoir un acc�s aux AutoResetEvent de chaques "Starts" afin d'acc�ler la relance pour la sortie!
        public static   List<AutoResetEvent> Loops_Event = new List<AutoResetEvent>();
        static Worker_Thread(){
            _timeout = TimeSpan.FromSeconds(Watcher_Properties.Worker_Thread_Wait_Seconds);
        }
        public static void Start(){
			Trace_Helper.Set_Trace_Context(new Trace_Context("Worker_Thread"));
            AutoResetEvent      __loop  = new AutoResetEvent(true);
            Run_Queue_Item      __item  = null;

            try{
                Loops_Event.Add(__loop);

                Trace_Helper.Log_InfoMessage("D�but boucle");
                //boucle tant que __exit n'est pas reset par le watcher
                while(!Watcher.Exit_Threads){
                    //on attend quelques temps ou on passe directement au suivant si __loop is set.
                    //Si Exit_Threads est true et loop est set alors ont sort tout de suite !
                    if(__loop.WaitOne(_timeout, false) && Watcher.Exit_Threads){
						Trace_Helper.Log_InfoMessage("Demande de Sortie - Wait" );
                        break;
                    }
                    
                    //Si le service est en pause on ne fait rien !!
                    if(Watcher.Paused) continue;
    
                    __item = Run_Queue.Dequeue();

                    //il reste au moins un element dans la queue !
                    if(QXPFrk.Validation.IsNotNull(__item)){
						Trace_Helper.Log_RunMessage("Un element � �t� pris de la queue Run:{0}", __item.ID_Run);

                        //On execute le run
                        LaunchRun(__item);
                        __loop.Set(); // on peut continuer la g�n�ration tout de suite sans attendre timeout
                    }
                }
            }catch(Exception ex){
                Error_Helper.LogError("Worker_Thread", ex);
            }
        }
        public static void Set_Loop_Events(){
            foreach(AutoResetEvent __event in Loops_Event){
                __event.Set(); // on informe les autres threads en cours de s'activer (avec eventuellement une sortie si lanc� par le watcher);
            }
        }
        static void LaunchRun(Run_Queue_Item item){
            Process __process   = null;
            int     __timeOut   = int.MinValue;
            try{
                string  __run_Id = QXPFrk.Conversion.ToString(item.ID_Run);
                ProcessStartInfo __startInfo = new ProcessStartInfo();
                //Afin de corriger un probl�me en mode Service windows nous forcons le WorkingDirectory au r�pertoire dans lequel est install� l'application
                //sinon ce r�pertoire est %windir%/System32
                __startInfo.WorkingDirectory    = AppDomain.CurrentDomain.BaseDirectory;
                __startInfo.FileName            = Watcher_Properties.Path_Run_Engine;
                __startInfo.Arguments           = __run_Id;
                if(!Watcher_Properties.Show_Run_Windows){
                    __startInfo.WindowStyle     = ProcessWindowStyle.Hidden;
                }
                Trace_Helper.Log_RunMessage("Lancement du run {0} avec la ligne de commande {1} {2}", __run_Id, __startInfo.FileName, __startInfo.Arguments);
                __process   = System.Diagnostics.Process.Start(__startInfo);
                if(QXPFrk.Validation.IsSet(Watcher_Properties.Run_Execution_TimeOut_Seconds, false)){
                    __timeOut = QXPFrk.Conversion.ToInt(TimeSpan.FromSeconds(Watcher_Properties.Run_Execution_TimeOut_Seconds).TotalMilliseconds);
                }
                if(QXPFrk.Validation.IsSet(__timeOut)){
					Trace_Helper.Log_RunMessage("Attente de la fin d'�x�cution du run {0} avec timeout {1}", __run_Id, __timeOut);
                    __process.WaitForExit(__timeOut);
                }else{
					Trace_Helper.Log_RunMessage("Attente de la fin d'�x�cution du run {0} sans timeout", __run_Id);
                    __process.WaitForExit();
                }
                if(__process.HasExited){
                    //Cas Normal
					Trace_Helper.Log_RunMessage("Fin d'�x�cution normale du run {0} (code retour {1})", __run_Id, __process.ExitCode);
                }else{
					Trace_Helper.Log_RunMessage("Fin d'�x�cution anormale du run {0} (code retour {1})", __run_Id, __process.ExitCode);
                }
            }catch(Exception ex){
                Error_Helper.LogError(string.Format("LaunchRun:{0}", item.ID_Run), ex);
            }finally{
                if(__process != null){
                    if(!__process.HasExited) __process.Close();
                    __process.Dispose();
                    __process = null;
                }
            }
            
        }
    }
}
