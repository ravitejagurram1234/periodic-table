using System;
using System.Collections.Generic;
using System.Runtime.Remoting;
using System.Text;
using System.Threading;

using QXP.Engine.Core;

namespace QXP.Batch.Core
{
    public class Watcher
    {
        public static bool              Exit                = false;
        public static bool              Exit_Threads        = false;
        public static bool              Paused              = false;

        
        static AutoResetEvent           _watch_Event       = new AutoResetEvent(true);
        static TimeSpan                 _timeout;
        static TimeSpan                 _checker_Join_Timeout;
        static TimeSpan                 _shutDownTimeOut;
        static List<Thread>             _worker_Threads     = new List<Thread>();
		static ThreadStart				_ts_Checker			= null;
        static Thread					_t_Checker			= null;

        
        static Watcher(){
            _timeout				= TimeSpan.FromSeconds(Watcher_Properties.Watcher_Wait_Seconds);
            _shutDownTimeOut		= TimeSpan.FromSeconds(Watcher_Properties.ShutDown_TimeOut_Seconds);
			_checker_Join_Timeout	= TimeSpan.FromSeconds(Watcher_Properties.Checker_Join_TimeOut_Seconds);
        }

        public static void  Start(){
            try{
				//initialisation du context de trace pour ce thread !
				Trace_Helper.Set_Trace_Context(new Trace_Context("Watcher"));
				Trace_Helper.Log_InfoMessage("====> D�marrage du Batch <====");

				Trace_Helper.Log_InfoMessage("D�marrage du serveur Interop ...");
				
				//Demarrage du serveur d'interop
                InteropServer.Start();
				
				Trace_Helper.Log_InfoMessage("Serveur Interop d�marr�");

				Trace_Helper.Log_InfoMessage("D�but - Cr�ation des threads de travail");
                //Creation des threads !
                CreateWorkerThreads();
				Trace_Helper.Log_InfoMessage("Fin - Cr�ation des threads de travail");

				Trace_Helper.Log_InfoMessage("D�but - ResetRunsStatus");
                ResetRunsStatus();
				Trace_Helper.Log_InfoMessage("Fin - ResetRunsStatus");

                //Recherche des elements � g�n�rer (y compris ceux en imm�diat) et mise dans la queue !
				Trace_Helper.Log_InfoMessage("D�but - CheckRunsInitials");
                CheckRunsInitials();
				Trace_Helper.Log_InfoMessage("Fin - CheckRunsInitials");

                //boucle tant que _exit est pas �gal � true
                while(!Exit){
                    

                    // on attend un signal ou le timeout(_timeout) et on recherche les nouvelle donn�es.
                    // le signal peut �tre envoyer lorsque la Queue en cours est vide !!
					Trace_Helper.Log_InfoMessage("D�but - Wait");
                    if(_watch_Event.WaitOne(_timeout, false) && Exit){
						Trace_Helper.Log_InfoMessage("Demande de Sortie - Wait" );
                        break;
                    }
					Trace_Helper.Log_InfoMessage("Wait - Fin");

                    //Si le service est en pause ont ne fait rien !!
                    if(Paused) continue;

					if(Is_Allowed()){
						Start_Checker();
						Join_Checker();
					}
                }
            }catch(Exception ex){
                Error_Helper.LogError("Watcher Error", ex);
            }finally{
                
                Exit_Threads = true; //fin des threads !!
				Trace_Helper.Log_InfoMessage("Reveil des workthreads pour extinction");
                Worker_Thread.Set_Loop_Events();
				Trace_Helper.Log_InfoMessage("D�but Attente de jointure des workthreads");
                foreach(Thread __t in _worker_Threads){
                    Trace_Helper.Log_InfoMessage("Attente de jointure du thread [{0}]", __t.ManagedThreadId);
					if(__t.Join(_shutDownTimeOut)){ //on attend la fin des threads
						Trace_Helper.Log_InfoMessage("Thread [{0}] termin� correctement", __t.ManagedThreadId);
					}else{
						Trace_Helper.Log_InfoMessage("Thread [{0}] non termin� correctement", __t.ManagedThreadId);
					}
                }
            }
				
            //Fin du serveur d'interop
            InteropServer.End();

			Trace_Helper.Log_InfoMessage("====> Fin du Batch <====");
        }
        public static void  End(){
            // Temporaire : �criture dans le fichier de log de l'heure d'arr�t
            //Error_Helper.LogError("ARRET MANUEL BATCH", new Exception("arr�t BATCH"));

            Exit = true;
            _watch_Event.Set();
        }
        static void         ResetRunsStatus(){
            Proxy.RunProxy  __proxy     = new Proxy.RunProxy();
            __proxy.ResetRunsStatus();
        }
        static void         CheckRunsInitials(){
            Proxy.RunProxy  __proxy     = new Proxy.RunProxy();
            List<int>       __runs      = __proxy.GetRunsInitials();
            if(__runs.Count > 0){
                Trace_Helper.Log_InfoMessage("{0} Nouveau(x) Run(s) / {1} Ancien(s) Run(s)", __runs.Count, Run_Queue.Count);
            }else{
                return;
            }
            foreach(int _id_run in __runs){
                Trace_Helper.Log_InfoMessage("Ajout du Run {0} dans la queue d'�x�cution", _id_run);
                Run_Queue.Enqueue(new Run_Queue_Item(_id_run));
            }
            Trace_Helper.Log_InfoMessage("R�veil des threads d'�x�cution");
            Worker_Thread.Set_Loop_Events();
        }
        static void         CreateWorkerThreads(){
			Trace_Helper.Log_InfoMessage("Creation de {0} workerthreads", Watcher_Properties.Number_Of_Threads);
            for(int __i = 0; __i < Watcher_Properties.Number_Of_Threads; __i++){
                ThreadStart __ts    = new ThreadStart(Worker_Thread.Start);
                Thread      __t     = new Thread(__ts);
				__t.Name = string.Format("Worker_Thread_{0}", __i);
                _worker_Threads.Add(__t);
				Trace_Helper.Log_InfoMessage("D�marrage du workerthread [{0}]", __t.ManagedThreadId);
                __t.Start();
            }
		}
		#region Checker Thread stuff
		static void			Start_Checker(){
				//ThreadPool.QueueUserWorkItem(new WaitCallback(Checker_Thread.Start));
				//if(QXP.Framework.Validation.IsNull(_t_Checker)){
				_ts_Checker		= new ThreadStart(Checker_Thread.Start);
				_t_Checker		= new Thread(_ts_Checker);
				_t_Checker.Name = "Checker__Thread";
				//}
				Trace_Helper.Log_InfoMessage("D�marrage du checker_thread [{0}]", _t_Checker.ManagedThreadId);
				_t_Checker.Start();
			}
		static void			Join_Checker(){
			if(_t_Checker.Join(_checker_Join_Timeout)){
				//Le thread c'est termin� normalement
				Trace_Helper.Log_InfoMessage("Jointure avec Watcher OK");
			}else{
				//force la fin du thread checker
				_t_Checker.Abort();
                // reset le flag de l'upload manager pour ne pas bloque les prochain check
                UploadManager.Reset();
				//Le thread c'est termin� en timeout (peut �tre est-il bloqu� !).
				Trace_Helper.Log_InfoMessage("Jointure avec Watcher >> KO <<");
			}
			_ts_Checker = null;
			_t_Checker = null;
		}
		#endregion
		static bool			Is_Allowed(){
			return Watcher_Planning.Is_InPlanning();
		}
    }
}
