using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using QXPFrk = QXP.Framework;

namespace QXP.Batch.Core
{
    public class Watcher_Properties
    {
        public static readonly string   Path_Run_Engine;
        public static readonly int      Number_Of_Threads;
        public static readonly bool     Show_Run_Windows;
        public static readonly int      Run_Execution_TimeOut_Seconds; //si int.minValue pas de timeout !
        public static readonly int      Watcher_Wait_Seconds;
        public static readonly int      Worker_Thread_Wait_Seconds;
        public static readonly int      ShutDown_TimeOut_Seconds;
        public static readonly int      Checker_Join_TimeOut_Seconds;

        public static readonly bool     Display_Info;
        public static readonly bool     Display_Detail;

        static Watcher_Properties(){

            Path_Run_Engine                 = BatchCoreSetting.Current.Path_Run_Engine ;//@"C:\VS2005\EOS2\DEV\SRC\QXP\QXP.Batch.Client\bin\Debug\QXP.Batch.Client.exe";
            Show_Run_Windows                = BatchCoreSetting.Current.Show_Run_Windows;//false;
            Worker_Thread_Wait_Seconds      = BatchCoreSetting.Current.Worker_Thread_Wait_Seconds;//2;
            Watcher_Wait_Seconds            = BatchCoreSetting.Current.Watcher_Wait_Seconds;//2;
            if (QXPFrk.Validation.IsSet(BatchCoreSetting.Current.Run_Execution_TimeOut_Seconds, false))
            {
                Run_Execution_TimeOut_Seconds   = BatchCoreSetting.Current.Run_Execution_TimeOut_Seconds;//si int.minValue ou 0 pas de timeout !
            }
            Number_Of_Threads               = BatchCoreSetting.Current.Number_Of_Threads;//2;
            ShutDown_TimeOut_Seconds        = BatchCoreSetting.Current.ShutDown_TimeOut_Seconds;//60;
            
            Display_Info                    = BatchCoreSetting.Current.Display_Info;//true;
            Display_Detail                  = BatchCoreSetting.Current.Display_Detail;//false;
			
			Checker_Join_TimeOut_Seconds	= BatchCoreSetting.Current.Checker_Join_TimeOut_Seconds;
		}
    }
}
