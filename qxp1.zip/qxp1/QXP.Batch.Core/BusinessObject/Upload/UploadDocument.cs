using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

using QXPFrk	= QXP.Framework;
using QXPIO		= QXP.Framework.IO;

using QXP.Engine.Core;

namespace QXP.Batch.Core
{
    public class UploadDocument{
        Document        _doc_qxp;
        QXPIO.PDF_File	_doc_pdf;
        public UploadDocument(Document doc_qxp, QXPIO.PDF_File doc_pdf){
            _doc_qxp = doc_qxp;
            _doc_pdf = doc_pdf;
        }
        #region public properties
        public Document			Doc_QXP{
            get{return _doc_qxp;}
        }
        public QXPIO.PDF_File	Doc_PDF{
            get{return _doc_pdf;}
        }
        #endregion
    }
}
