using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using QXPBatchInterop = QXP.Batch.Interop;
using QXPFrk = QXP.Framework;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Batch.Core
{
    /// <summary>
    /// Class Service : Contient les traitements effectu�s par le serveur (Batch) lorsqu'un client lui donne des ordres.
    /// </summary>
    /// <author>doufarm</author>
    /// <date>26/10/2012 15:21:16</date>    
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class Service : QXPBatchInterop.IService
    {
        #region Membres
		Trace_Context	_trace_Context			= null;


        private object locker = new object();
        private Dictionary<QXPBatchInterop.IEventMessageCallback, QXPBatchInterop.ClientInfo> Subscribers = new Dictionary<QXPBatchInterop.IEventMessageCallback, QXPBatchInterop.ClientInfo>();

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Service
        /// </summary>
        public Service()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Cette methode ne fait pas partie de l'interface interop publier au client, c'est � usage interne et exclusivement appel� par batch
        /// </summary>
        /// <param name="message_Type">type de message</param>
        /// <param name="message">le texte du message</param>
        public void SendMessage(QXPBatchInterop.Message_Type message_Type, string message) 
        { 
            //get all the subscribers
            var subscriberKeys = (from c in Subscribers select c.Key).ToList();

            subscriberKeys.ForEach(delegate(QXPBatchInterop.IEventMessageCallback callback)
            {
                if (((ICommunicationObject)callback).State == CommunicationState.Opened)
                {

                    callback.OnReceiveMessage(message_Type,  message);

                }
                else
                {
                    //These subscribers are no longer active. Delete them from subscriber list
                    subscriberKeys.Remove(callback);
                    Subscribers.Remove(callback);
                }
            });        
        }

        /// <summary>
        /// Cette methode permet d'avertir tous les clients que le server se ferme et de fermer proprement les connections
        /// </summary>
        public void CloseServer() 
        { 
	        Trace_Helper.Set_Trace_Context(this.Trace_Context);
            Trace_Helper.Log_InfoMessage("arret du WCF Service de batch");

            //get all the subscribers
            var subscriberKeys = (from c in Subscribers select c.Key).ToList();

            subscriberKeys.ForEach(delegate(QXPBatchInterop.IEventMessageCallback callback)
            {
                if (((ICommunicationObject)callback).State == CommunicationState.Opened)
                {

                    callback.ServerClosed();

                }
                else
                {
                    //le subscripter n'existe plus ! on le supprime
                    subscriberKeys.Remove(callback);
                    Subscribers.Remove(callback);
                }
            });   
     
            this.CloseSubscribers();
        }


        /// <summary>
        /// Un message � �t� envoy� par un client pour les clients et doit �tre trait� par batch
        /// </summary>
        /// <param name="message">le message</param>
        public void ReceiveMessage(string message)
        {
            
            QXPBatchInterop.IEventMessageCallback  __caller         = this.Caller;
            QXPBatchInterop.ClientInfo             __callerInfos    = this.CallerInfo;
            string __message = string.Format("{0} dit:{1}", __callerInfos.UserName, message);

	        Trace_Helper.Set_Trace_Context(this.Trace_Context);
            Trace_Helper.Log_Message(__message);

            //get all the subscribers
            var subscriberKeys = (from c in Subscribers select c.Key).ToList();

            subscriberKeys.ForEach(delegate(QXPBatchInterop.IEventMessageCallback callback)
            {
                if (callback != __caller)
                {
                    if (((ICommunicationObject)callback).State == CommunicationState.Opened)
                    {

                        callback.OnReceiveMessage(QXP.Batch.Interop.Message_Type.Message, __message);

                    }
                    else
                    {
                        //Le subscriber n'est plus actif il faut l'enlev� des Subscribers
                        //on ne doit pas passer dans ce cas en fonctionnement car il � du se souscrire automatiquement en quittant sont l'application
                        subscriberKeys.Remove(callback);
                        Subscribers.Remove(callback);
                    }
                }
            });
        }

        /// <summary>
        /// Un client nous averti de sont arriv� et nous donne ses informations personnels
        /// </summary>
        /// <param name="clientInfo">Information sur le client qui effectue l'appel</param>
        public void Subscribe(QXPBatchInterop.ClientInfo clientInfo)
        {
            try
            {
                QXPBatchInterop.IEventMessageCallback callback = OperationContext.Current.GetCallbackChannel<QXPBatchInterop.IEventMessageCallback>();
                lock (locker)
                {
                    Subscribers.Add(callback, clientInfo);
			        Trace_Helper.Set_Trace_Context(this.Trace_Context);
                    Trace_Helper.Log_InfoMessage("new subscripter {0}", clientInfo.GetFullInfo());
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Un client nous informe qu'il se d�connecte
        /// </summary>
        public void UnSubscribe()
        {
            try
            {
                QXPBatchInterop.IEventMessageCallback __caler = this.Caller;
                lock (locker)
                {
                    QXPBatchInterop.ClientInfo __infos = this.CallerInfo;
                    Subscribers.Remove(this.Caller);
			        Trace_Helper.Set_Trace_Context(this.Trace_Context);
                    Trace_Helper.Log_InfoMessage("subscripter [{0}]-{1} leave", __infos.Guid, __infos.UserName);
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Permet de r�cup�rer la liste des clients actuellement connect�s sur le server Batch
        /// </summary>
        /// <returns></returns>
        public string[] GetListClients() 
        { 
            //get all the subscribers infos
            return Subscribers.Values.Select(sub => sub.GetFullInfo()).ToArray();
        }

        /// <summary>
        /// Permet de demander � batch de lancer une liste de run. Cette methode est appel� par QXP.WebSite pour le lancement manuel des run depuis le site
        /// </summary>
        /// <param name="ids">liste des identifiants de run � lancer</param>
        /// <returns>true s'il n'y � pas eu de pb sinon false</returns>
        public bool ExecuteRuns(int[] run_ids)
		{
			bool __result = true;
			Trace_Helper.Set_Trace_Context(this.Trace_Context);
            string __str_ids_runs = string.Join(",", QXPFrk.Conversion.ToStringArray(run_ids));
			Trace_Helper.Log_RunMessage("Demande Ex�cution direct de {0} run(s) ({1})", run_ids.Length, __str_ids_runs);
            try{
                //On marque les runs comme �tant prise en charge par BATCH
                Proxy.RunProxy __proxy  = new Proxy.RunProxy();
				Trace_Helper.Log_RunMessage("D�but Mise a jour status runs");
                __proxy.UpdateRunsStatus(run_ids);
				Trace_Helper.Log_RunMessage("Fin Mise a jour status runs");

                //Appel de verification des nouveau uploads !
				Trace_Helper.Log_RunMessage("D�but V�rification des Upload");
                UploadManager.Check();
				Trace_Helper.Log_RunMessage("D�but V�rification des Upload");
                foreach(int __id_run in run_ids){
                    Run_Queue.Enqueue(new Run_Queue_Item(__id_run));
                }
                //permet de r�veiller les Worker_Thread(s) !!
                Worker_Thread.Set_Loop_Events();
            }catch(Exception ex){
                Error_Helper.LogError("Erreur lors de l'inscription de run en ex�cution imm�diate", ex);
                __result = false;
            }
            return __result; //True run added sinon false (error);
		}

        /// <summary>
        /// Permet de mettre fin aux connections avec les clients (Batch.Client)
        /// </summary>
        void CloseSubscribers() 
        { 
            //get all the subscribers
            var subscriberKeys = (from c in Subscribers select c.Key).ToList();

            subscriberKeys.ForEach(delegate(QXPBatchInterop.IEventMessageCallback callback)
            {
                try
                {
                    ((ICommunicationObject)callback).Close();
                }
                catch { }
            });         
       
            Subscribers.Clear();
        }

        #endregion M�thodes

        #region Propri�t�s
        
        /// <summary>
        /// Retourve une r�f�rence du client qui appel le server
        /// </summary>
        public QXPBatchInterop.IEventMessageCallback Caller
        {
          get{return OperationContext.Current.GetCallbackChannel<QXPBatchInterop.IEventMessageCallback>();}  
        } 

        /// <summary>
        /// Retourne les informations concernant le client en cours
        /// </summary>
        public QXPBatchInterop.ClientInfo CallerInfo 
        {
            get 
            { 
                QXPBatchInterop.IEventMessageCallback   __caller = this.Caller;
                QXPBatchInterop.ClientInfo              __info;
                if(!Subscribers.TryGetValue(__caller, out __info))
                {
                    return null;
                }
                return __info;
            }
        }

        /// <summary>
		/// Context de trace du Service
		/// </summary>
		public Trace_Context		Trace_Context
		{
			get
			{
				if(QXPFrk.Validation.IsNull(_trace_Context))
				{
					_trace_Context = new Trace_Context("InteropService");				
				}
				return _trace_Context;
			}
		}
        #endregion Propri�t�s
    }

}
