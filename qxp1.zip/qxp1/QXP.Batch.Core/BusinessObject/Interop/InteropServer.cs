using System.ServiceModel;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Batch.Core
{
    /// <summary>
    /// Class InteropServer : Repr�sente l'instance qui d�marre la partie serveur WCF de l'interop de batch
    /// </summary>
    /// <author>doufarm</author>
    /// <date>26/10/2012 15:44:12</date>    
    public class InteropServer
    {
        #region Membres
	    static ServiceHost _serviceHost = null;
	    static ServiceHost _serviceCommandHost = null;

        public static Service           Current_Service = null;
        public static ServiceCommand    Current_ServiceCommand = null;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        #endregion Constructeur

        #region M�thodes
        /// <summary>
        /// D�marrage du serveur WCF
        /// </summary>
		internal static void Start()
		{

            //Console.WriteLine("Server starting...");
            
            Current_Service = new Service();
            _serviceHost = new ServiceHost(Current_Service);
            _serviceHost.Open();
            
            Current_ServiceCommand = new ServiceCommand();
            _serviceCommandHost = new ServiceHost(Current_ServiceCommand);
            _serviceCommandHost.Open();
            
            // Console.WriteLine("Server started.");
        }

        /// <summary>
        /// Fin des services du serveur WCF
        /// </summary>
        internal static void End() 
        {
            try
            {
                if (_serviceHost != null)
                {
                    Current_Service.CloseServer();
                    //Cette fonction peut prendre closetimeout(dans .config) seconds pour s'�x�cuter
                    _serviceHost.Close();
                }
                if (_serviceCommandHost != null)
                {
                    //Cette fonction peut prendre closetimeout seconds(dans .config) pour s'�x�cuter
                    _serviceCommandHost.Close();
                }
            }
            catch { }
        }
        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
