﻿using System;
using System.ServiceModel;
using QXPBatchInterop = QXP.Batch.Interop;
using QXPFrk = QXP.Framework;

/* 
 * Code généré avec le template : QXPObjectClass
*/
namespace QXP.Batch.Core
{
    /// <summary>
    /// Class Service : Contient les traitements effectués par le serveur (Batch) lorsqu'un client lui donne des ordres.
    /// </summary>
    /// <author>doufarm</author>
    /// <date>26/10/2012 15:21:16</date>    
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class ServiceCommand : QXPBatchInterop.IServiceCommand
    {
        #region Membres
		Trace_Context	_trace_Context			= null;
        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Crée une instance de ServiceCommand
        /// </summary>
        public ServiceCommand()
        {
        }

        #endregion Constructeur

        #region Méthodes

        /// <summary>
        /// Permet de demander à batch de lancer une liste de run. Cette methode est appelé par QXP.WebSite pour le lancement manuel des run depuis le site
        /// </summary>
        /// <param name="ids">liste des identifiants de run à lancer</param>
        /// <returns>true s'il n'y à pas eu de pb sinon false</returns>
        public bool ExecuteRuns(int[] run_ids)
		{
			bool __result = true;
            Trace_Helper.Set_Trace_Context(this.Trace_Context);
            string __str_ids_runs = string.Join(",", QXPFrk.Conversion.ToStringArray(run_ids));
            Trace_Helper.Log_RunMessage("Demande Exécution direct de {0} run(s) ({1})", run_ids.Length, __str_ids_runs);
            try{
                //On marque les runs comme étant prise en charge par BATCH
                Proxy.RunProxy __proxy  = new Proxy.RunProxy();
                Trace_Helper.Log_RunMessage("Début Mise a jour status runs");
                __proxy.UpdateRunsStatus(run_ids);
                Trace_Helper.Log_RunMessage("Fin Mise a jour status runs");

                //Appel de verification des nouveau uploads !
                Trace_Helper.Log_RunMessage("Début Vérification des Upload");
                UploadManager.Check();
                Trace_Helper.Log_RunMessage("Début Vérification des Upload");
                foreach(int __id_run in run_ids){
                    Run_Queue.Enqueue(new Run_Queue_Item(__id_run));
                }
                //permet de réveiller les Worker_Thread(s) !!
                Worker_Thread.Set_Loop_Events();
            }catch(Exception ex){
                Error_Helper.LogError("Erreur lors de l'inscription de run en exécution immédiate", ex);
                __result = false;
            }
            return __result; //True run added sinon false (error);
		}

        #endregion Méthodes

        #region Propriétés
        
        /// <summary>
		/// Context de trace du ServiceCommand
		/// </summary>
		public Trace_Context		Trace_Context
		{
			get
			{
				if(QXPFrk.Validation.IsNull(_trace_Context))
				{
					_trace_Context = new Trace_Context("InteropServiceCommand");				
				}
				return _trace_Context;
			}
		}
        #endregion Propriétés
    }
}
