using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

using Oracle.DataAccess.Client;

using QXPFrk = QXP.Framework;
using QXPFrkProxy = QXP.Framework.Proxy;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPOraClient = Oracle.DataAccess.Client;

namespace QXP.Batch.Core.Proxy
{
    public class RunProxy : QXPFrkProxy.BaseProxy
    {
        public List<int>    GetRuns()
        {
            QXPDataOracle.OraParameter      __cursor    = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            List<int>                       __runs      = new List<int>();

            string __spName = "QXP_PK_BATCH.Get_Runs";
			this.Command_Timeout = BatchCoreSetting.Current.Command_TimeOut;

            try
            {
                using (QXPDataOracle.OraDataReader  __odr = this.GetReader(CommandType.StoredProcedure, __spName, __cursor))
                {
                	while (__odr.Read())
                	{
                		__runs.Add(__odr["id_run"]);
                	}
                }
            }
            catch(Exception ex)
            {                
                Error_Helper.LogError("Erreur pendant GetRuns", ex);
            }

            return __runs;

        }
        //au lancement de l'application les run imm�diat sont �galement r�cup�r�s
        public List<int>    GetRunsInitials()
        {
            QXPDataOracle.OraParameter      __cursor    = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            List<int>                       __runs      = new List<int>();

            string __spName = "QXP_PK_BATCH.Get_Runs_Initials";
            try
            {
                
                using (QXPDataOracle.OraDataReader  __odr = this.GetReader(CommandType.StoredProcedure, __spName, __cursor))
                {
                	while (__odr.Read())
                	{
                		__runs.Add(__odr["id_run"]);
                	}
                }
            }
            catch(Exception ex)
            {
                Error_Helper.LogError("Erreur pendant GetRunsInitials", ex);
                throw;
            }

            return __runs;

        }
        public void         ResetRunsStatus(){
            string __spName = "QXP_PK_BATCH.Reset_Runs_Status";
			
            this.Execute(CommandType.StoredProcedure, __spName);

        }
        public void         UpdateRunsStatus(int[] run_ids){
            if(run_ids.Length == 0) return;

            //string[]    __str_run_ids = QXPFrk.Conversion.ToStringArray(run_ids);
            //string      __str_ids     = string.Join(",", __str_run_ids);
            //QXPDataOracle.OraParameter      __run_ids    = new QXPDataOracle.OraParameter("p_run_ids", __str_ids);
            QXPDataOracle.OraParameter      __run_ids    = new QXPDataOracle.OraParameter("p_run_ids", run_ids);

            string __spName = "QXP_PK_BATCH.Update_Runs_Status";

            try{
                this.Execute(CommandType.StoredProcedure, __spName, __run_ids);
            }catch(Exception ex){
                Error_Helper.LogError("Erreur pendant UpdateRunsStatus", ex);
                throw;
            }
        }

        public int CreateRunUpload(int idSuivi, int idQxpUpload)
        {
            QXPDataOracle.OraParameter __idSuivi        = new QXPDataOracle.OraParameter("p_id_suivi", idSuivi);
            QXPDataOracle.OraParameter __idQxpUpload    = new QXPDataOracle.OraParameter("p_id_qxp_upload", idQxpUpload);
            string __sql = "QXP_PK_BATCH.Create_Run_Upload";

            int __idRunCreated;
            try
            {
                __idRunCreated = this.ExecuteScalar(CommandType.StoredProcedure, __sql, __idSuivi, __idQxpUpload);
            }
            catch (Exception ex)
            {
                Error_Helper.LogError("Erreur pendant la cr�ation du run upload", ex);
                throw;
            }

            return __idRunCreated;
        }
    }
}