using System;
using System.Collections.Generic;
using System.Data;
using QXP.Engine.Core;
using Oracle.DataAccess.Client;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPFrk = QXP.Framework;
using QXPProxy = QXP.Framework.Proxy;

namespace QXP.Batch.Core.Proxy
{
    /// <summary>
    /// Proxy DocumentProxy : DocumentProxy
    /// </summary>
    /// <author></author>
    /// <date></date>   
    public class DocumentProxy : QXPProxy.BaseProxy
    {
        #region Membres

        #endregion Membres

        #region Constantes

        private const string PACKAGE = "QXP_PK_BATCH.";
        public const int IdSousCategorieQXPGenere = 6;
        public const int IdSousCategoriePDFGenere = 7;

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de DocumentProxy
        /// </summary>
        public DocumentProxy()
        {
        }

        /// <summary>
        /// Cr�e une instance de DocumentProxy
        /// </summary>
        /// <param name="oraClient">Connexion Oracle</param>
        public DocumentProxy(QXPDataOracle.OraClient oraClient)
            : base(oraClient)
        {
        }

        /// <summary>
        /// Cr�e une instance de DocumentProxy
        /// </summary>
        /// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
        public DocumentProxy(string dataBase)
            : base(dataBase)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #region Acc�s Base

        #region SELECT

        public List<int> GetNewUploadDocuments()
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);

            string __sp_Name = string.Concat(PACKAGE, "Get_New_Upload");
            List<int> __new_document_ids = new List<int>();
            int __id_Upload;

            this.Command_Timeout = BatchCoreSetting.Current.Command_TimeOut;

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sp_Name, __cursor))
            {
                while (__odr.Read())
                {
                    __id_Upload = __odr["ID_UPLOAD"];
                    __new_document_ids.Add(__id_Upload);
                }
            }

            return __new_document_ids;
        }

        public List<Document> LoadUploadDocuments(List<int> upload_document_ids)
        {
            List<Document> __upload_documents = new List<Document>();
            Document __doc = null;

            foreach (int __id_Upload in upload_document_ids)
            {
                __doc = GetUploadDocument(__id_Upload);
                if (QXPFrk.Validation.IsNotNull(__doc)) __upload_documents.Add(__doc);
            }

            return __upload_documents;
        }

        public Document GetUploadDocument(int id_Upload)
        {
            Document __doc = null;

            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_Upload = new QXPDataOracle.OraParameter("p_id_upload", id_Upload);

            string __sp_Name = string.Concat(PACKAGE, "Get_Upload_Document");
            try
            {
                using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sp_Name, __cursor, __id_Upload))
                {
                    if (__odr.Read())
                    {
                        __doc = new Document(id_Upload, "Upload", Constantes.Document_Format.QXP, "UP", __odr["contenu"]);
                    }
                }
            }
            catch (Exception ex)
            {
                Error_Helper.LogError(string.Format("Impossible de charger le fichier {0} de qxp_document_upload", id_Upload), ex);
            }

            return __doc;
        }

        #endregion SELECT

        #region INSERT / UPDATE / DELETE

        //Permet de transfer le fichier de l'upload et d'envoyer le pdf dans qxp_document
        public void UpdateUploadErrors(Dictionary<int, string> error_upload_ids)
        {
            //rien � faire !
            if (error_upload_ids.Count == 0) return;

            string __sp_Name = string.Concat(PACKAGE, "Update_Upload_With_Errors");

            int[] __error_upload_ids = new int[error_upload_ids.Count];
            string[] __error_upload_msg = new string[error_upload_ids.Count];

            int __i = 0;
            foreach (int __id in error_upload_ids.Keys)
            {
                __error_upload_ids[__i] = __id;
                __i++;
            }

            __i = 0;
            foreach (string __msg in error_upload_ids.Values)
            {
                __error_upload_msg[__i] = __msg;
                __i++;
            }

            QXPDataOracle.OraParameter __error_ids = new QXPDataOracle.OraParameter("p_error_ids", __error_upload_ids);
            QXPDataOracle.OraParameter __error_msgs = new QXPDataOracle.OraParameter("p_error_msgs", __error_upload_msg);

            int __affected = this.ExecuteScalar(CommandType.StoredProcedure, __sp_Name, __error_ids, __error_msgs);

            if (error_upload_ids.Count != __affected)
                Error_Helper.LogError(string.Format("Le nombre d'�l�ments en erreur ({0}) ne correspond pas au nombre d'�lements mis � jour dans qxp_document_upload ({1})", error_upload_ids.Count, __affected), new InvalidOperationException());
        }

        #endregion INSERT / UPDATE / DELETE

        #endregion Acc�s Base

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}