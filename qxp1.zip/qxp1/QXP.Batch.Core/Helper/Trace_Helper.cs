using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;
using QXPBatchInterop = QXP.Batch.Interop;


/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Batch.Core
{
    /// <summary>
    /// Cette classe permet d'intercepter les appels � Trace_Helper et les renvoyer sur InteropServer
    /// </summary>
    /// <author>doufarm</author>
    /// <date>26/10/2012 16:37:34</date>    
    public class Trace_Helper
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Constructeur static Trace_Helper
        /// </summary>
        static Trace_Helper()
        {
        }

        #endregion Constructeur

        #region M�thodes
        /// <summary>
		/// Permet de d�finir le context de trace en cours
		/// </summary>
		/// <param name="trace_Context">le nouveau context de trace</param>
		public static void			Set_Trace_Context(Trace_Context trace_Context)
		{
			QXP.Trace_Helper.Set_Trace_Context(trace_Context);
		}

        /// <summary>
        /// Log un message utilisateur dans les traces
        /// </summary>
        /// <param name="message">le message</param>
        /// <param name="args">les �ventuels arguments du message</param>
        public static void Log_Message(string message, params object[] args)
        {
            Internal_Log_Message(QXPBatchInterop.Message_Type.Message, message, args);
        }

        /// <summary>
        /// Log un message utilisateur dans les traces sans appel � InteropServer
        /// </summary>
        /// <param name="message">le message</param>
        /// <param name="args">les �ventuels arguments du message</param>
        public static void Log_Message_Private(string message, params object[] args)
        {
            Internal_Log_Message_Private(QXPBatchInterop.Message_Type.Message, message, args);
        }

        /// <summary>
        /// Log une information system dans les traces
        /// </summary>
        /// <param name="message">le message</param>
        /// <param name="args">les �ventuels arguments du message</param>
        public static void Log_InfoMessage(string message, params object[] args)
        {
            Internal_Log_Message(QXPBatchInterop.Message_Type.Information, message, args);
        }
        
        /// <summary>
        /// Log une information de run dans les traces
        /// </summary>
        /// <param name="message">le message</param>
        /// <param name="args">les �ventuels arguments du message</param>
        public static void Log_RunMessage(string message, params object[] args)
        {
            Internal_Log_Message(QXPBatchInterop.Message_Type.Run, message, args);
        }

        /// <summary>
        /// Log une information d'upload dans les traces
        /// </summary>
        /// <param name="message">le message</param>
        /// <param name="args">les �ventuels arguments du message</param>
        public static void Log_UploadMessage(string message, params object[] args)
        {
            Internal_Log_Message(QXPBatchInterop.Message_Type.Upload, message, args);
        }

        /// <summary>
        /// Log d'un message dans les traces
        /// </summary>
        /// <param name="message_Type"></param>
        /// <param name="message"></param>
        /// <param name="args"></param>
        static void Internal_Log_Message(QXPBatchInterop.Message_Type message_Type, string message, object[] args) 
        { 
            Trace_Message __trace_Message = QXP.Trace_Helper.Get_Trace_Message(null, null, message, args);
            
            //Envoi du message aux client eventuels
            //Et si l'interop est op�rationnelle
            if(QXPFrk.Validation.IsNotNull(InteropServer.Current_Service)) InteropServer.Current_Service.SendMessage(message_Type, __trace_Message.ToString());
            
            QXP.Trace_Helper.Log(__trace_Message);
        }

        /// <summary>
        /// Log d'un message dans les traces SANS appel � InteropServer
        /// </summary>
        /// <param name="message_Type">type de message</param>
        /// <param name="message">message</param>
        /// <param name="args">les arguments du message</param>
        static void Internal_Log_Message_Private(QXPBatchInterop.Message_Type message_Type, string message, object[] args) 
        { 
            Trace_Message __trace_Message = QXP.Trace_Helper.Get_Trace_Message(null, null, message, args);
            
            QXP.Trace_Helper.Log(__trace_Message);
        }

        /// <summary>
        /// Les erreurs ne sont pas remont� compl�tement (mais elle sont tout de m�me signal� et elle pourront �tre retrouv� dans les logs de la base de donn�e).
        /// </summary>
        /// <param name="ex">l'exception</param>
        /// <param name="message">le message associ� � l'exception</param>
        public static void Log_Exception_Message(Exception ex, string message) 
        { 
            InteropServer.Current_Service.SendMessage(QXPBatchInterop.Message_Type.Information, message);
            QXP.Trace_Helper.Log_Exception_Message(ex, message);
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
