using System;
using System.Collections.Generic;
using System.Text;

using QXPAudit		= QXP.Audit;
using QXPFrk		= QXP.Framework;
using QXPDiagnostic = QXP.Framework.Diagnostic;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Batch.Core
{
	/// <summary>
	/// Helper de gestion des erreur de Batch
	/// </summary>
	/// <author>doufarm</author>
	/// <date>10/05/2010 11:52:06</date>    
	public class Error_Helper
	{
		#region Membres
        static      string                  App_Prefixe;
        static      string                  Message_Pattern = null;
        static      Get_Message_Handler     Get_Message     = null;
        delegate    string                  Get_Message_Handler(string message);
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Error_Helper
		/// </summary>
        static Error_Helper(){
            //Ce petit code permet d'�viter d'�valuer � chaque fois s'il a un MessagePattern 
            App_Prefixe = BatchCoreSetting.Current.App_Prefixe;
            if(QXPFrk.Validation.IsSet(App_Prefixe)){
                Message_Pattern = App_Prefixe + "{0}";
                Get_Message += new Get_Message_Handler(Get_Message_Pattern);
            }else{
                Get_Message += new Get_Message_Handler(Get_Message_Sans_Pattern);
            }
        }

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// 
		/// </summary>
		/// <param name="message"></param>
		/// <param name="ex"></param>
		public static void LogError(string message, Exception ex){
            QXPDiagnostic.Log.LogError(Get_Message(message), ex);
			Trace_Helper.Log_Exception_Message(ex, message);
        }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="message"></param>
		/// <returns></returns>
        static string Get_Message_Sans_Pattern(string message){
            return message;
        }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="message"></param>
		/// <returns></returns>
        static string Get_Message_Pattern(string message){
            return string.Format(Message_Pattern, message);
        }
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
