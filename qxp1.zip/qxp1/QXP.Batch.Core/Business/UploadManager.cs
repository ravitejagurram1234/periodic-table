using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

using QXP.Engine.Core;

namespace QXP.Batch.Core
{
    public class UploadManager
    {
        static bool Running = false;
        static UploadManager(){
            //Attention les fonctions d'upload n�cessitent l'utilisation de fonctions contenues dans QXP.Batch.Engine
            //qui utilisent des param�tres du run en cours, et m�me si batch on ne travail pas sur des runs on d�fini les param�tres d'un run fictif
            QXPS_File_Manager.SetPoolPath(BatchCoreSetting.Current.RunUploadPoolPath);
        }

        /// <summary>
        /// Reset the running flag 
        /// </summary>
        public static void Reset()
        {
            Running = false;
        }
        
        public static void Check(){
            // L'op�ration de chargement des fichiers d'upload pouvant �tre longue on d�compose en plusieurs �tapes.
			
			Trace_Helper.Log_UploadMessage("D�but check upload");

            //Voici un moyen tr�s simple d'�viter que plusieurs threads appellent cette fonction en m�me temps !
            if(Running){
				Trace_Helper.Log_UploadMessage("Sortie du Check car running");
				return;
			}
            Running = true;
            try{
				Trace_Helper.Log_UploadMessage("D�but GetNewUploadDocuments");

                // 1 - Recherche des nouveaux documents (identifiants seulement pour l'instant)!
                Proxy.DocumentProxy     __proxy             = new Proxy.DocumentProxy();
                List<int>               __new_upload_ids    = __proxy.GetNewUploadDocuments();
				Trace_Helper.Log_UploadMessage("Fin GetNewUploadDocuments avec {0} new upload", __new_upload_ids.Count);
                Dictionary<int, string> __error_upload_ids  = new Dictionary<int, string>();

                
                if(__new_upload_ids.Count == 0) {
                    //aucun nouveau document � charger/analyser
					Trace_Helper.Log_UploadMessage("Sortie du Check car 0 upload");
                    Running = false;
                    return;
                }
                // 2 - Chargement des nouveaux documents () !
				Trace_Helper.Log_UploadMessage("D�but LoadUploadDocuments");
                List<Document>			__documents         = __proxy.LoadUploadDocuments(__new_upload_ids);
				Trace_Helper.Log_UploadMessage("Fin LoadUploadDocuments avec {0}", __documents.Count);
                List<UploadDocument>    __uploadDocuments   = new List<UploadDocument>();

                // Puis pour chaque document r�p�t� l'�tape 3,4 et 5
                // 3 - Upload sur serveur Quark (inclu dans la methode Get_XML)
                // 4 - Deconstruction et R�cup�ration du DID (Document IDentity) s'il existe !
                int __i = 0; 
                List<int> __idRunToLaunch = new List<int>(); // Id des run � lancer
				Trace_Helper.Log_UploadMessage("D�but Analyse Documents");
                foreach(Document __doc in __documents){
                    try{
                        //Ajout du document dans Quark server et desconstruction !
						QXPS_File_Manager.Addfile(__doc.FilePoolPath, __doc.Data);
                        //Version plus rapide permettant d'obtenir le DID sans analyser tout le XML du document
						Document_Identity       __identity  = Document_Identity_Helper.Get_Identity(__doc.FilePoolPath);
						Trace_Helper.Log_UploadMessage("Analyse Documents DID:{0}", __identity.Value);
                        if(__identity.Is_Defined){
                            try
                            {
                                
								Trace_Helper.Log_UploadMessage("D�but Creation Run pour suivi {0} avec upload {1}", __identity.Id_Suivi, __doc.ID);
								// Cr�ation d'un run sans t�che
                                int __idRunCreated = CreateRunUpload(__identity.Id_Suivi, __doc.ID);
								Trace_Helper.Log_UploadMessage("Fin Creation Run pour suivi {0} avec upload {1} avec Run: {2}", __identity.Id_Suivi, __doc.ID, __idRunCreated);

                                switch (__idRunCreated)
                                {
                                    case -2: // Suivi lock�
                                        __error_upload_ids.Add(__doc.ID, "Le suivi est lock�");
                                        break;
                                    
                                    case -1: // RUN d�j� pris en compte par batch
                                        __error_upload_ids.Add(__doc.ID, "Le run � MAJ est d�j� pris en compte par batch");
                                        break;

                                    case 0: // Erreur lors de la cr�ation du run
                                        __error_upload_ids.Add(__doc.ID, "Erreur lors de la cr�ation du RunUpload");
                                        break;
                                    
                                    default: // Pas de probl�me : cr�ation du run (on v�rifie si d�j� pr�sent dans la queue)
                                        if (!__idRunToLaunch.Contains(__idRunCreated))
                                            __idRunToLaunch.Add(__idRunCreated);
                                        else                                    
											Trace_Helper.Log_UploadMessage("Attention Run: {2} d�j� dans la queue", __idRunCreated);
                                        break;
                                }
                            }
                            catch (Exception ex)
                            {
                                Error_Helper.LogError(string.Format("Impossible de g�n�rer le PDF pour le fichier {0}", __doc.FilePoolPath), ex);
                                __error_upload_ids.Add(__doc.ID, string.Format("Erreur lors de la g�n�ration du PDF � partir du document {0}", __doc.FilePoolPath));
                            }
                        }else{                            
                            __error_upload_ids.Add(__doc.ID, string.Format("Erreur dans le champs DID du document {0}", __doc.FilePoolPath));
                        }

                        __i++;
                        
                    }catch(Exception ex){
                        // s'il y a une erreur on exclut le fichier !
                        // ce n'est peut-�tre pas un fichier QXP ou le DID est vide c'est � dire que le fichier est encore un gabarit !
                        Error_Helper.LogError(string.Format("Impossible d'analyser le document : {0}", __doc.ID), ex);
                        __error_upload_ids.Add(__doc.ID, string.Format("Erreur lors de la r�cup�ration du XML ou champs DID introuvable pour le document {0}", __doc.FilePoolPath));
                    }
                }
				Trace_Helper.Log_UploadMessage("Fin Analyse Documents");

                // Mise dans la queue des runs � g�n�rer
				Trace_Helper.Log_UploadMessage("D�but Ajout des {0} Run(s) cr��(s) ", __idRunToLaunch.Count);
                foreach(int __idRun in __idRunToLaunch){
					Trace_Helper.Log_UploadMessage("Ajout du {0} Run(s) dans la file d'�x�cution ", __idRun);
                    Run_Queue.Enqueue(new Run_Queue_Item(__idRun));
                }
				Trace_Helper.Log_UploadMessage("Fin Ajout des {0} Run(s) cr��(s) ", __idRunToLaunch.Count);
				Trace_Helper.Log_UploadMessage("Ordre de r�veil des WorkerThreads ");
                //permet de r�veiller les Worker_Thread(s) !!
                Worker_Thread.Set_Loop_Events();

                // Mise � jour du statut (en erreur) des documents non reconnus dans QXP_Document_Upload
				Trace_Helper.Log_UploadMessage("D�but Mise � jour des uploads {0} en erreur ", __error_upload_ids.Count);
                __proxy.UpdateUploadErrors(__error_upload_ids);
				Trace_Helper.Log_UploadMessage("Fin Mise � jour des uploads {0} en erreur ", __error_upload_ids.Count);

            }catch(Exception ex){
                Error_Helper.LogError("Erreur Impr�vue lors de l'upload des documents", ex);
            }finally{
                try{
                    // 9 - Suppression du document du serveur quark.
                    //on purge les fichiers du serveur quark sans suppression du repertoire upload temporaire
					Trace_Helper.Log_UploadMessage("Purge des fichiers ajout�s sur quark server");
                    QXPS_File_Manager.PurgeAddedFiles(false);
                }catch(Exception ex){
                    Error_Helper.LogError("impossible de purger les fichiers", ex);
                }
				Trace_Helper.Log_UploadMessage("Fin check upload");
                Running = false;
            }
        }

        private static int CreateRunUpload(int idSuivi, int idQxpUpload)
        {
            Proxy.RunProxy __runProxy = new Proxy.RunProxy();
            
            int __idRunCreated;
            try
            {
                __idRunCreated = __runProxy.CreateRunUpload(idSuivi, idQxpUpload);
            }
            catch
            {
                __idRunCreated = 0;
            }

            return __idRunCreated;
        }
    }
}
