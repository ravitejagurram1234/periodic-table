using System;
using System.Collections;
using System.Globalization;

namespace QXP.Framework
{
	/// <summary>Contains string format constant used by <see cref="Format"/> class helper and log string format. </summary>
	public class StringFormat
	{
		private StringFormat(){}
		/// <summary>Represents a braced string Format. </summary>
		public const string					BraceFormat											= "({0})";
		/// <summary>Represents a braced string Format. </summary>
		public const string					HookFormat											= "[{0}]";
		/// <summary>Represents a Pipe braced string Format. </summary>
		public const string					PipeBraceFormat										= "|({0})";
		/// <summary>Represents a two dashed string Format. </summary>
		public const string					Dash2Format											= "{0}-{1}";
		/// <summary>Represents a two dotted string Format. </summary>
		public const string					Dot2Format											= "{0}.{1}";
		/// <summary>Represents a two dotted with new line string Format. </summary>
		public const string					Dot2FormatLine										= "{0}.{1}\r\n";
		/// <summary>Represents a three dotted string Format. </summary>
		public const string					Dot3Format											= "{0}.{1}.{2}";
		/// <summary>Represents a three dotted with new line string Format. </summary>
		public const string					Dot3FormatLine										= "{0}.{1}.{2}\r\n";
		/// <summary>Represents a two slashed string Format. </summary>
		public const string					Slash2Format										= "{0}/{1}";
		/// <summary>Represents a two equal string Format. </summary>
		public const string					Equal2Format										= "{0}={1}";
		/// <summary>Represents a three slashed string Format. </summary>
		public const string					Slash3Format										= "{0}/{1}/{2}";
		/// <summary>Represents a four Dotted string Format. </summary>
		public const string					Slash4Format										= "{0}/{1}/{2}/{3}";
		/// <summary>Represents a five slashed string Format. </summary>
		public const string					Slash5Format										= "{0}/{1}/{2}/{3}/{4}";
		/// <summary>Represents a two backslashed string Format. </summary>
		public const string					BackSlash2Format									= @"{0}\{1}";
		/// <summary>Represents a three backslashed string Format. </summary>
		public const string					BackSlash3Format									= @"{0}\{1}\{2}";
		/// <summary>Represents a four backslashed string Format. </summary>
		public const string					BackSlash4Format									= @"{0}\{1}\{2}\{3}";
		/// <summary>Represents a five backslashed string Format. </summary>
		public const string					BackSlash5Format									= @"{0}\{1}\{2}\{3}\{4}";
		/// <summary>Represents a two tabbed string Format. </summary>
		public const string					TabDot2FormatLine									= "\t{0}.{1}\r\n";
		/// <summary>Represents a three backslashed string Format. </summary>
		public const string					TabDot3FormatLine									= "\t{0}.{1}.{2}\r\n";
		/// <summary>Represents an underscored string Format. </summary>
		public const string					UnderScoreFormat									= "_{0}";
		/// <summary>Represents a two line string Format. </summary>
		public const string					Format2Lines										= "{0}\r\n{1}\r\n";

		/// <summary>Represents a log call tree format. </summary>
		public const string					LogCallTreeItem										= "\t[{0}] {1}\r\n";
		/// <summary>Represents a log line format. </summary>
		public const string					LogLine														= "{0}: {1}\r\n";
		/// <summary>Represents a log info format. </summary>
		public const string					LogInfo														= "{0}: {1} ";
		/// <summary>Represents a log file format. </summary>
		public const string					LogFile														= "{0}{1}{2}{3}.{4}";
		/// <summary>Represents a log basic error format. </summary>
		public const string					ErrorBasic												= "{0}: {1}";
		/// <summary>Represents a log extended error format. </summary>
		public const string					ErrorExtended											= "{0}: {1}\r\n\tAdditional info: {2}\r\n";
		/// <summary>Represents a log exception error format. </summary>
		public const string					ErrorInnerException								= "{0}\r\nAdditional info: {1}\r\n";
		/// <summary>Represents a log extension error format. </summary>
		public const string					ErrorExtension										= "{0}\r\nAn other error occured processing this operation:\r\n{1}";

	}
}
