using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework
{
    /// <summary>
    /// Objet Validation
    /// </summary>
    /// <author>cueffl</author>
    /// <date>19/01/2011 13:50:09</date>    
    public class Validation
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Validation
        /// </summary>
        public Validation()
        {
        }

        #endregion Constructeur

        #region M�thodes

        public static bool IsNull(object obj)
        {
            return (obj == null || obj == DBNull.Value);
        }

        public static bool IsNull(Data.Oracle.OraValue oraValue)
        {
            return (oraValue == null || oraValue.IsNull);
        }

        public static bool IsNotNull(object obj)
        {
            return (obj != null && obj != DBNull.Value);
        }

        public static bool IsNotNull(Data.Oracle.OraValue oraValue)
        {
            return !IsNull(oraValue);
        }

        public static bool IsSet(int val)
        {
            return IsSet(val, true);
        }

        public static bool IsSet(int val, bool isZeroValid)
        {
            if (isZeroValid)
            {
                return val != int.MinValue;
            }
            else
            {
                return !(val == int.MinValue || val == 0);
            }
        }

        public static bool IsSet(short val)
        {
            return IsSet(val, true);
        }

        public static bool IsSet(short val, bool isZeroValid)
        {
            if (isZeroValid)
            {
                return val != short.MinValue;
            }
            else
            {
                return !(val == short.MinValue || val == 0);
            }
        }

        public static bool IsSet(long val)
        {
            return IsSet(val, true);
        }

        public static bool IsSet(long val, bool isZeroValid)
        {
            if (isZeroValid)
            {
                return val != long.MinValue;
            }
            else
            {
                return !(val == long.MinValue || val == 0);
            }
        }

        public static bool IsSet(decimal val)
        {
            return IsSet(val, true);
        }

        public static bool IsSet(decimal val, bool isZeroValid)
        {
            if (isZeroValid)
            {
                return val != decimal.MinValue;
            }
            else
            {
                return !(val == decimal.MinValue || val == 0);
            }
        }

        public static bool IsSet(float val)
        {
            return IsSet(val, true);
        }

        public static bool IsSet(float val, bool isZeroValid)
        {
            if (isZeroValid)
            {
                return val != float.MinValue;
            }
            else
            {
                return !(val == float.MinValue || val == 0);
            }
        }

        public static bool IsSet(double val)
        {
            return IsSet(val, true);
        }

        public static bool IsSet(double val, bool isZeroValid)
        {
            if (isZeroValid)
            {
                return val != double.MinValue;
            }
            else
            {
                return !(val == double.MinValue || val == 0);
            }
        }

        public static bool IsSet(string str)
        {
            return (IsNotNull(str) && str != string.Empty);
        }

        public static bool IsSet(DateTime date)
        {
            return (date != DateTime.MinValue);
        }

        public static bool IsSet(TimeSpan timeSpan)
        {
            return (timeSpan != TimeSpan.MinValue);
        }

        public static bool IsSet(object obj)
        {
            if (IsNull(obj)) return false;
            Type __type = obj.GetType();
            if (__type == ValueType.CLSint32) { return IsSet((Int32)obj); }
            else if (__type == ValueType.CLSint64) { return IsSet((Int64)obj); }
            else if (__type == ValueType.CLSdecimal) { return IsSet((Decimal)obj); }
            else if (__type == ValueType.CLSsingle) { return IsSet((Single)obj); }
            else if (__type == ValueType.CLSdouble) { return IsSet((Double)obj); }
            else if (__type == ValueType.CLSstring) { return IsSet((string)obj); }
            else if (__type == ValueType.DateTime) { return IsSet((DateTime)obj); }
            else if (obj is ICollection) { return IsSet((ICollection)obj); }
            else if (obj is IEnumerable) { return IsSet((IEnumerable)obj); };
            return true;
        }

        /// <summary>
        /// on v�rifie si la valeur est d�finie, si la valeur est un nombre le param�tre IsZeroValid est pris en compte
        /// Il s'agit d'une nouvelle forme de v�rification compatible avec les param�tres g�n�riques 
        /// </summary>
        /// <typeparam name="T">Type de la valeur</typeparam>
        /// <param name="obj">la valeur</param>
        /// <param name="isZeroValid">d�fini si 0 est valide (true) ou pas (non)</param>
        /// <returns>true si la valeur est valide sinon false</returns>
        public static bool IsSet<T>(T obj, bool isZeroValid)
        {
            object __obj = obj;
            if (IsNull(__obj)) return false;
            Type __type = typeof(T);
            if (__type == ValueType.CLSint32) { return IsSet((Int32)__obj, isZeroValid); }
            else if (__type == ValueType.CLSint64) { return IsSet((Int64)__obj, isZeroValid); }
            else if (__type == ValueType.CLSdecimal) { return IsSet((Decimal)__obj, isZeroValid); }
            else if (__type == ValueType.CLSsingle) { return IsSet((Single)__obj, isZeroValid); }
            else if (__type == ValueType.CLSdouble) { return IsSet((Double)__obj, isZeroValid); }
            else if (__type == ValueType.CLSstring) { return IsSet((string)__obj); }
            else if (__type == ValueType.DateTime) { return IsSet((DateTime)__obj); }
            else if (obj is ICollection) { return IsSet((ICollection)__obj); }
            else if (obj is IEnumerable) { return IsSet((IEnumerable)obj); };
            return true;
        }

        /// <summary>
        /// on v�rifie si la valeur n'est pas d�finie, si la valeur est un nombre le param�tre IsZeroValid est pris en compte
        /// Il s'agit d'une nouvelle forme de v�rification compatible avec les param�tres g�n�riques 
        /// </summary>
        /// <typeparam name="T">Type de la valeur</typeparam>
        /// <param name="obj">la valeur</param>
        /// <param name="isZeroValid">d�fini si 0 est valide (true) ou pas (non)</param>
        /// <returns>true si la valeur n'est pas valide sinon false</returns>
        public static bool IsNotSet<T>(T obj, bool isZeroValid)
        {
            return !IsSet<T>(obj, isZeroValid);
        }

        public static bool IsSet(ICollection collection)
        {
            return (IsNotNull(collection) && collection.Count != 0);
        }

        /// <summary>
        /// V�rifie si l'IEnumerable est non null et poss�de au moins un �l�ment
        /// </summary>
        /// <param name="obj">IEnumerable</param>
        /// <returns>bool</returns>
        public static bool IsSet(IEnumerable obj)
        {
            if (IsNotNull(obj))
            {
                IEnumerator __enumerator = obj.GetEnumerator();
                if (__enumerator.MoveNext())
                {
                    return true;
                }
            }
            return false;
        }

        public static bool IsNotSet(int val)
        {
            return !IsSet(val, true);
        }

        public static bool IsNotSet(int val, bool isZeroValid)
        {
            return !IsSet(val, isZeroValid);
        }

        public static bool IsNotSet(long val)
        {
            return !IsSet(val, true);
        }

        public static bool IsNotSet(long val, bool isZeroValid)
        {
            return !IsSet(val, isZeroValid);
        }

        public static bool IsNotSet(decimal val)
        {
            return !IsSet(val, true);
        }

        public static bool IsNotSet(decimal val, bool isZeroValid)
        {
            return !IsSet(val, isZeroValid);
        }

        public static bool IsNotSet(float val)
        {
            return !IsSet(val, true);
        }

        public static bool IsNotSet(float val, bool isZeroValid)
        {
            return !IsSet(val, isZeroValid);
        }

        public static bool IsNotSet(double val)
        {
            return !IsSet(val, true);
        }

        public static bool IsNotSet(double val, bool isZeroValid)
        {
            return !IsSet(val, isZeroValid);
        }

        public static bool IsNotSet(string str)
        {
            return !IsSet(str);
        }

        public static bool IsNotSet(DateTime date)
        {
            return !IsSet(date);
        }

        public static bool IsNotSet(TimeSpan timeSpan)
        {
            return !IsSet(timeSpan);
        }

        public static bool IsNotSet(object obj)
        {
            return !IsSet(obj);
        }

        public static bool IsNotSet(ICollection collection)
        {
            return !IsSet(collection);
        }

        /// <summary>
        /// V�rifie si le type est un ValueType
        /// </summary>
        /// <param name="type">Type</param>
        /// <returns>True si le type est un ValueType</returns>
        public static bool IsPrimitiveValueType(Type type)
        {
            return type == ValueType.CLSbyte
                || type == ValueType.CLSint16
                || type == ValueType.CLSint32
                || type == ValueType.CLSint64
                || type == ValueType.CLSsingle
                || type == ValueType.CLSdouble
                || type == ValueType.CLSdecimal
                || type == ValueType.CLSboolean
                || type == ValueType.CLSchar
                || type == ValueType.CLSstring
                || type == ValueType.DateTime
                || type.IsEnum
                ;
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
