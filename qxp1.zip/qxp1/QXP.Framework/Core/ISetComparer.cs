using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;

/* 
 * Code g�n�r� avec le template : QXPBusinessClass
*/
namespace QXP.Framework
{
	/// <summary>
	/// Ce comparer permet d'effectuer une comparaison mais d�place les �l�m�ent non d�fini en fin de liste alors qu'il devrait �tre en d�but de liste normalement
	/// </summary>
	/// <author>doufarm</author>
	/// <date>14/04/2011 09:50:01</date>    
	public class ISetComparer: IComparer<object>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		#endregion Constructeur

		#region M�thodes
		
		public int Compare(object x, object y)
		{
			if (QXPFrk.Validation.IsNotSet(x))
			{
				if (QXPFrk.Validation.IsNotSet(y))
				{
					return 0;
				}
				else
				{
					return 1; //Normalement il faut renvoyer -1 mais nous voulons les nulls last
				}
			}
			else
			{
				if (QXPFrk.Validation.IsNotSet(y))
				{
					return -1; //Normalement il faut renvoyer +1 mais nous voulons les nulls last
				}
				else
				{
					
					return ((IComparable)x).CompareTo(y);
				}
			}
 		}

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
