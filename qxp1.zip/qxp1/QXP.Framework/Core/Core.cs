namespace QXP.Framework
{
    public delegate void BasicHandler();
}
