using System;
using System.Collections.Generic;


/* 
 * Code g�n�r� avec le template : QXPBusinessClass
*/
namespace QXP.Framework
{
	/// <summary>
	/// Ce comparer permet la d�finition de fonction IEqualityComparer en fonction lambda
	/// </summary>
	/// <author>doufarm</author>
	/// <date>14/04/2011 09:50:01</date>    
	public class LambdaComparer<T>: IEqualityComparer<T>
	{
		#region Membres
		private readonly Func<T, T, bool> _lambdaComparer;
		private readonly Func<T, int> _lambdaHash;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur
		/// <summary>
		/// Creation d'un lambda comparer avec un labda hash standard
		/// </summary>
		/// <param name="lambdaComparer">Expression lambda du comparer</param>
		public LambdaComparer(Func<T, T, bool> lambdaComparer) :
			this(lambdaComparer, o => o.GetHashCode())
		{

		}
	    
		/// <summary>
		/// Creation d'un lambda comparer avec un lambda hash custom (pour le calcul du hash)
		/// </summary>
		/// <example>
		/// voici un exemple non test� mais qui doit fonctionner
		/// List<MyObject> x = myCollection.Except(otherCollection, new LambdaComparer<MyObject>((x, y) => x.Id == y.Id)).ToList();
		/// </example>
		/// <param name="lambdaComparer">Expression lambda du comparer</param>
		/// <param name="lambdaHash">Expression lambda du calcul du hash</param>
		public LambdaComparer(Func<T, T, bool> lambdaComparer, Func<T, int> lambdaHash)
		{
			if (lambdaComparer == null)
				throw new ArgumentNullException("lambdaComparer");
			if (lambdaHash == null)
				throw new ArgumentNullException("lambdaHash");

			_lambdaComparer = lambdaComparer;
			_lambdaHash = lambdaHash;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Evaluation de Equals (par rapport au lambda comparer)
		/// </summary>
		/// <param name="x">r�f�rence de l'object x</param>
		/// <param name="y">r�f�rence de l'object y</param>
		/// <returns></returns>
		public bool Equals(T x, T y)
		{
			return _lambdaComparer(x, y);
		}

		/// <summary>
		/// Evaluation du hashcode des objects (par rapport au lambda hash)
		/// </summary>
		/// <param name="obj">l'object sur lequel il faut calculer le HashCode � l'aide de l'expression lambda hash.</param>
		/// <returns></returns>
		public int GetHashCode(T obj)
		{
			return _lambdaHash(obj);
		}
		
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
