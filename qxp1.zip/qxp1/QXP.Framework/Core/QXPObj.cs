using System;
using System.Collections.Generic;

/* 
 * Code g�n�r� avec le template : qxpObjectClass
*/
namespace QXP.Framework
{
    /// <summary>
    /// class QXPObj
    /// </summary>
    /// <author></author>
    /// <date> </date>    
    public class QXPObj
    {
        #region Membres
        readonly object _obj;
        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de QXPObj
        /// </summary>
        public QXPObj(object obj)
        {
            _obj = obj;
        }

        #endregion Constructeur

        #region M�thodes

        public static implicit operator String(QXPObj qxpObj)
        {
            return Conversion.ToString(qxpObj._obj);
        }
        
        public static implicit operator Int32(QXPObj qxpObj)
        {
            return Conversion.ToInt(qxpObj._obj);
        }
        
        public static implicit operator Int16(QXPObj qxpObj)
        {
            return Conversion.ToShort(qxpObj._obj);
        }
        
        public static implicit operator Double(QXPObj qxpObj)
        {
            return Conversion.ToDouble(qxpObj._obj);
        }
        
        public static implicit operator DateTime(QXPObj qxpObj)
        {
            return Conversion.ToDateTime(qxpObj._obj);
        }
        
        public static implicit operator Boolean(QXPObj qxpObj)
        {
            return Conversion.ToBool(qxpObj._obj);
        }
        
        public static implicit operator Byte(QXPObj qxpObj)
        {
            return Conversion.ToByte(qxpObj._obj);
        }
        
        public static implicit operator string[](QXPObj qxpObj)
        {
            return (string[])qxpObj._obj;
        }
        
        public static implicit operator int[](QXPObj qxpObj)
        {
            return (int[])qxpObj._obj;
        }
        
        public static implicit operator DateTime[](QXPObj qxpObj)
        {
            return (DateTime[])qxpObj._obj;
        }

        #endregion M�thodes

        #region Propri�t�s
        public object Value
        {
            get { return _obj; }
        }
        #endregion Propri�t�s
    }


    /// <summary>
    /// Class List_QXPObj : Liste de QXPObj
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class List_QXPObj : BaseList<QXPObj>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de List_qxpObj
        /// </summary>
        public List_QXPObj(IEnumerable<QXPObj> objs)
            : base(objs)
        {
        }

        /// <summary>
        /// Cr�e une instance de List_qxpObj
        /// </summary>
        public List_QXPObj(params object[] objs)
            : base()
        {
            this.Add(objs);
        }

        /// <summary>
        /// Cr�e une instance de List_qxpObj
        /// </summary>
        public void Add(params object[] objs)
        {
            foreach (object obj in objs)
            {
                base.Add(new QXPObj(obj));
            }
        }
        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
