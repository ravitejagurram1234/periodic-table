using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Web.UI.WebControls;

using Oracle.DataAccess.Client;

namespace QXP.Framework
{
	public class MathHelper{
		public enum RoundType{
			RoundUp = -1,
			RoundDown = 1,
		}
		//pour l'instant non utilis� car non finalis� !!
		public static decimal Round(decimal value, int nb_Decimal, RoundType type ){
			int		__pow		= (int)Math.Round(Math.Log10((double)value));
			int		__factor	= 10 * nb_Decimal;
			decimal __result	= Math.Floor(value * __factor);
			__result = __result/__factor;
			return __result;
		}

        /// <summary>
        /// Retrouve la valeur minimum d�finit dans la liste des elements
        /// </summary>
        /// <typeparam name="T">Type des �l�ments contenus dans l'IEnumerable</typeparam>
        /// <param name="source">IEnumerable</param>
		/// <param name="isZeroValid">la valeur zero est-elle autoris�e</param>
		/// <param name="defaultValue">La valeur par defaut si aucun element valid</param>
        public static T MinSet<T>(bool isZeroValid, T defaultValue, params T[] source)
        {
			Comparer<T> __comparer	= Comparer<T>.Default;
			T			__min		= defaultValue;
			
			if (Validation.IsNotSet(__min, true))
			{
				foreach (T __val in source)
				{
					if(Validation.IsSet(__val, isZeroValid))
					{
						if ((Validation.IsNotSet(__min)) || (__comparer.Compare(__val, __min) < 0))
						{
							__min = __val;
						}
					}
				}
				return __min;
			}
			
			foreach (T __val in source)
			{
				if (Validation.IsSet(__val, isZeroValid))
				{
					if (__comparer.Compare(__val, __min) < 0)
					{
						__min = __val;
					}
				}
			}

			return __min;
        }
	}
}
