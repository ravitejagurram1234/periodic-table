using System;
using System.Collections;
using System.Linq;
using System.Globalization;

namespace QXP.Framework
{
	/// <summary>Provides methods to handle <see cref="String"/>. </summary>
	public class	StringHelper
	{
		#region members
		private const string Dot3Const	= "...";
		private const string BRConst	=  "<br/>";
		private const string RNConst	=  "\r\n";
		#endregion
		
		/// <summary>Specifies a type of character. </summary>
		public enum CharType
		{
			/// <summary>No character. </summary>
			None, 
			/// <summary>A ( character. </summary>
			Bracket, 
			/// <summary>A{character. </summary>
			CurledBracket, 
			/// <summary>A [ character. </summary>
			SquareBracket, 
			/// <summary>A ' character. </summary>
			Quote,
			/// <summary>A '( character. </summary>
			QuotedBracket,
			/// <summary>A '{character. </summary>
			QuotedCurledBracket, 
			/// <summary>A '[ character. </summary>
			QuotedSquareBracket, 		
		}
		private StringHelper(){}
		/// <summary>Determines if an occurrence of the specified <paramref name="value"/> is present in the provided <paramref name="source"/> in this instance. </summary>
		/// <param name="source">The <see cref="String"/> in which the value might be contained. </param>
		/// <param name="value">The <see cref="String"/> to seek</param>
		/// <returns><see langword="true"/> if <paramref name="source"/> contains <paramref name="value"/> otherwise <see langword="false"/>. </returns>
		public static bool		Contains(string source, string value)
		{
			return (source.IndexOf(value) != -1);
		}			
		/// <summary>Returns a <see cref="String"/> containing a specified number of characters from the left side of a string. </summary>
		/// <param name="source">A <see cref="String"/> expression from which the leftmost characters are returned. </param>
		/// <param name="length">A 32-bit signed integer indicating how many characters to return. </param>
		/// <returns>The <see cref="String"/> equivalent that represent the leftmost of <paramref name="source"/> with a <paramref name="length"/> number of chars.  </returns>
		public static string	Left(string source, int length)
		{
            if(Validation.IsNull(source))
                return null;
			if(length > 0 && (source.Length > length))	return source.Substring(0, length);
			else										return source;
		}
		/// <summary>Returns a <see cref="String"/> containing a specified number of characters from the right side of a string. </summary>
		/// <param name="source">The <see cref="String"/> expression from which the rightmost characters are returned. </param>
		/// <param name="length">The 32-bit signed integer indicating how many characters to return. </param>
		/// <returns>The <see cref="String"/> equivalent that represent the rightmost of <paramref name="source"/> with a <paramref name="length"/> number of chars.  </returns>
		public static string	Right(string source, int length)
		{
            if(Validation.IsNull(source))
                return null;
			if(length > 0 && (source.Length > length))	return source.Substring(source.Length - length, length);
			else										return source;
		}
		/// <summary>Returns a <see cref="String"/> containing a specified number of characters from the left side of a string combined with a "..." suffix. </summary>
		/// <param name="source">The <see cref="String"/> expression from which the leftmost characters are returned. </param>
		/// <param name="length">The <see cref="int"/> indicating how many characters to return. </param>
		/// <returns>The <see cref="String"/> equivalent that represent the leftmost of <paramref name="source"/> with a <paramref name="length"/> number of chars concatened with a "..." string.  </returns>
		public static string	StartString(string source, int length)
		{
			return StartString(source, length, Dot3Const);
		}
		/// <summary>Returns a <see cref="String"/> containing a specified number of characters from the left side of a string combined with a <paramref name="suffixe"/> string. </summary>
		/// <param name="source">The <see cref="String"/> expression from which the leftmost characters are returned. </param>
		/// <param name="length">The <see cref="int"/> indicating how many characters to return. </param>
		/// <param name="suffixEndString"> specifies the suffix to add at the end of the string. </param>
		/// <returns>The <see cref="String"/> equivalent that represent the leftmost of <paramref name="source"/> with a <paramref name="length"/> number of chars  concatened with a <paramref name="suffixEndString"/> string.  </returns>
		public static string	StartString(string source, int length, string suffixEndString)
		{
			//Prise en compte de la longueur du suffixe maintenant
			if(Validation.IsSet(source) && (source.Length > length ))	return string.Format("{0}{1}", Left(source, length - Conversion.ToString(suffixEndString).Length), suffixEndString);
			else														return source;
		}
		/// <summary>Returns a <see cref="String"/> containing a specified number of characters from the right side of a string prefixed by '...'. </summary>
		/// <param name="source">The <see cref="String"/> expression from which the rightmost characters are returned. </param>
		/// <param name="length">The 32-bit signed integer indicating how many characters to return. </param>
		/// <returns>The <see cref="String"/> equivalent that represent the rightmost of <paramref name="source"/> with a <paramref name="length"/> number of chars  concatened with a <paramref name="suffixEndString"/> string.  </returns>
		public static string	EndString(string source, int length)
		{
			return EndString(source, length, Dot3Const);
		}
		/// <summary>Returns a <see cref="String"/> containing a specified number of characters from the right side of a string beginning with <paramref name="suffixEndString"/>. </summary>
		/// <param name="source">The <see cref="String"/> expression from which the rightmost characters are returned. </param>
		/// <param name="length">The 32-bit signed integer indicating how many characters to return. </param>
		/// <param name="prefixStartString">The <see cref="String"/> expression. </param>
		/// <returns>The <see cref="String"/> equivalent that represent the rightmost of <paramref name="source"/> with a <paramref name="length"/> number of chars  concatened with a <paramref name="suffixEndString"/> string.  </returns>
		public static string	EndString(string source, int length, string prefixStartString)
		{
			//Prise en compte de la longueur du prefixe maintenant
			if(Validation.IsSet(source) && (source.Length > length))	return string.Format("{0}{1}", prefixStartString, Right(source, length - Conversion.ToString(prefixStartString).Length));
			else														return(source);
		}
		/// <summary>Returns a <see cref="String"/> containing the beginning end the ending a the specified <paramref name="source"/> string. the number of characters in the beginning and the ending are equals and corresponding to the specified <paramref name="length"/> divide by 2. </summary>
		/// <param name="source">The <see cref="String"/> expression from which the rightmost characters are returned. </param>
		/// <param name="length">The 32-bit signed integer indicating how many characters to return. </param>
		/// <returns>The <see cref="String"/> equivalent that represent the leftmost and rightmost of <paramref name="source"/> with a <paramref name="length"/> number of chars.  </returns>
        public static string    StartEndString(string source, int length)
        {
            if(Validation.IsSet(source) && (source.Length > length))
            {
                int __mid = length / 2;
                return string.Concat(StartString(source, __mid), EndString(source, __mid));
            }
            else
            {
                return source;
            }
        }
		/// <summary>Surrounds the specified <see cref="Object"/> with the provided <see cref="CharType"/>. </summary>
		/// <param name="value">The <see cref="Object"/> to enclose. </param>
		/// <param name="frameType">The frame <see cref="CharType"/>. </param>
		/// <returns>The enclosed <see cref="String"/>; or <see cref="String.Empty"/> if <paramref name="value"/> is not set. </returns>
		public static string	Frame(object value, CharType frameType)
		{
			if(Validation.IsNotSet(value)) return String.Empty;
			switch(frameType)
			{
				case CharType.Bracket:							return string.Format("{1}{0}{2}", value, "(", ")");
				case CharType.CurledBracket:				return string.Format("{1}{0}{2}", value, "{", "}");
				case CharType.SquareBracket:				return string.Format("{1}{0}{2}", value, "[", "]");
				case CharType.Quote:								return string.Format("{1}{0}{2}", value, "'", "'");
				case CharType.QuotedBracket:				return string.Format("{1}{0}{2}", value, "'(", ")'");
				case CharType.QuotedCurledBracket:	return string.Format("{1}{0}{2}", value, "'{", "}'");
				case CharType.QuotedSquareBracket:	return string.Format("{1}{0}{2}", value, "'[", "]'");
				default:														return Conversion.ToString(value);
			}
		}
		/// <summary>Gets an undescored string representation. </summary>
		/// <param name="param1">The <see cref="Object"/> to format. </param>
		/// <returns>The underscored <see cref="String"/> representation of <paramref name="param1"/>. </returns>
		public static string UnderScoreString(object param1)
		{
			return string.Format(StringFormat.UnderScoreFormat, param1);
		}
		/// <summary>Gets a braced string representation of the <paramref name="param1"/>. </summary>
		/// <param name="param1">The <see cref="Object"/> to brace format. </param>
		/// <returns>The braced <see cref="String"/> representation. </returns>
		public static string BraceString(object param1)
		{
			return string.Format(StringFormat.BraceFormat, param1);
		}
		/// <summary>Gets a hook string representation of the <paramref name="param1"/>. </summary>
		/// <param name="param1">The <see cref="Object"/> to brace format. </param>
		/// <returns>The hooked <see cref="String"/> representation. </returns>
		public static string HookString(object param1)
		{
			return string.Format(StringFormat.HookFormat, param1);
		}
		/// <summary>Gets a piped string representation of the <paramref name="param1"/>. </summary>
		/// <param name="param1">The <see cref="Object"/> to pipe format. </param>
		/// <returns>The pipe formatted <see cref="String"/> representation. </returns>
		public static string PipeBraceString(object param1)
		{
			return string.Format(StringFormat.PipeBraceFormat, param1);
		}
		/// <summary>Gets a dash separated string represention of the <paramref name="param1"/> and <paramref name="param2"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to dash format. </param>
		/// <param name="param2">The second <see cref="Object"/> to dash format. </param>
		/// <returns>The dash joined <see cref="String"/> representation of the <paramref name="param1"/> and <paramref name="param2"/>. </returns>
		public static string Dash2String(object param1, object param2)
		{
			return string.Format(StringFormat.Dash2Format, param1, param2);
		}
		/// <summary>Gets a dot separated string representation of the <paramref name="param1"/> and <paramref name="param2"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to dot format. </param>
		/// <param name="param2">The second <see cref="Object"/> to dot format. </param>
		/// <returns>The dot joined <see cref="String"/> representation of the <paramref name="param1"/> and <paramref name="param2"/>. </returns>
		public static string Dot2String(object param1, object param2)
		{
			return string.Format(StringFormat.Dot2Format, param1, param2);
		}		
		/// <summary>Gets a dot separated string representation of the <paramref name="param1"/>,<paramref name="param2"/> and <paramref name="param3"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to dot format. </param>
		/// <param name="param2">The second <see cref="Object"/> to dot format. </param>
		/// <param name="param3">The third <see cref="Object"/> to dot format. </param>
		/// <returns>The dot joined <see cref="String"/> representation of the <paramref name="param1"/>,<paramref name="param2"/> and <paramref name="param3"/>. </returns>
		public static string Dot3String(object param1, object param2, object param3)
		{
			return string.Format(StringFormat.Dot3Format, param1, param2, param3);
		}
		/// <summary>Gets a dot separated string representation of the <paramref name="param1"/> and <paramref name="param2"/> ended with a new line. </summary>
		/// <param name="param1">The first <see cref="Object"/> to dot format. </param>
		/// <param name="param2">The second <see cref="Object"/> to dot format. </param>
		/// <returns>The dot joined <see cref="String"/> representation of the <paramref name="param1"/> and <paramref name="param2"/> finished with a new line characters. </returns>
		public static string Dot2StringLine(object param1, object param2)
		{
			return string.Format(StringFormat.Dot2FormatLine, param1, param2);
		}
		/// <summary>Gets a slash separated string representation of the <paramref name="param1"/> and <paramref name="param2"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to slash format. </param>
		/// <param name="param2">The second <see cref="Object"/> to slash format. </param>
		/// <returns>The slash joined <see cref="String"/> representaion of the <paramref name="param1"/> and <paramref name="param2"/>. </returns>
		public static string Slash2String(object param1, object param2)
		{
			return string.Format(StringFormat.Slash2Format, param1, param2);
		}
		/// <summary>Gets a slash separated string representation of the <paramref name="param1"/>,<paramref name="param2"/> and <paramref name="param3"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to slash format. </param>
		/// <param name="param2">The second <see cref="Object"/> to slash format. </param>
		/// <param name="param3">The third <see cref="Object"/> to slash format. </param>
		/// <returns>The slash joined <see cref="String"/> representaion of the <paramref name="param1"/>,<paramref name="param2"/> and <paramref name="param3"/>. </returns>
		public static string Slash3String(object param1, object param2, object param3)
		{
			return string.Format(StringFormat.Slash3Format, param1, param2, param3);
		}
		/// <summary>Gets a slash separated string representation of the <paramref name="param1"/>,<paramref name="param2"/>,<paramref name="param3"/> and <paramref name="param4"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to slash format. </param>
		/// <param name="param2">The second <see cref="Object"/> to slash format. </param>
		/// <param name="param3">The third <see cref="Object"/> to slash format. </param>
		/// <param name="param4">The fourth <see cref="Object"/> to slash format. </param>
		/// <returns>The slash joined <see cref="String"/> representation of the <paramref name="param1"/>,<paramref name="param2"/>,<paramref name="param3"/> and <paramref name="param4"/>. </returns>
		public static string Slash4String(object param1, object param2, object param3, object param4)
		{
			return string.Format(StringFormat.Slash4Format, param1, param2, param3, param4);
		}
		/// <summary>Gets a slash separated string representation of the <paramref name="param1"/>,<paramref name="param2"/>,<paramref name="param3"/>,<paramref name="param4"/>  and <paramref name="param5"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to slash format. </param>
		/// <param name="param2">The second <see cref="Object"/> to slash format. </param>
		/// <param name="param3">The third <see cref="Object"/> to slash format. </param>
		/// <param name="param4">The fourth <see cref="Object"/> to slash format. </param>
		/// <param name="param5">The fifth <see cref="Object"/> to slash format. </param>
		/// <returns>The slash joined <see cref="String"/> representation of the <paramref name="param1"/>,<paramref name="param2"/>,<paramref name="param3"/>,<paramref name="param4"/>  and <paramref name="param5"/>. </returns>
		public static string Slash5String(object param1, object param2, object param3, object param4, object param5)
		{
			return string.Format(StringFormat.Slash5Format, param1, param2, param3, param4, param5);
		}
		/// <summary>Gets a slash separated string representation of an object array (<paramref name="args"/>). </summary>
		/// <param name="args">an Array of <see cref="Object"/> to slash join. </param>
		/// <returns>The slash joined <see cref="String"/> representation of the <paramref name="args"/> array of <see cref="Object"/>. </returns>
		public static string SlashNString(params object[] args)
		{
			if(Validation.IsNotSet(args)) return string.Empty;
			ArrayList __args = new ArrayList();
			foreach(object obj in args)
			{
				string __str = Conversion.ToString(obj);
				if(Validation.IsSet(__str) && __str != "/")
				{
					__args.Add(__str);
				}
			}
			string __string  = string.Join("/", (string[])__args.ToArray(ValueType.CLSstring));
			return __string;
		}
		public static string SlashNString(Array array)
		{
			if(Validation.IsNotSet(array)) return string.Empty;
			ArrayList __args = new ArrayList();
			foreach(object obj in array)
			{
				string __str = Conversion.ToString(obj);
				if(Validation.IsSet(__str) && __str != "/")
				{
					__args.Add(__str);
				}
			}
			string __string  = string.Join("/", (string[])__args.ToArray(ValueType.CLSstring));
			return __string;
		}
		/// <summary>Gets a backslash separated string representation of the <paramref name="param1"/> and <paramref name="param2"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to backslash format. </param>
		/// <param name="param2">The second <see cref="Object"/> to backslash format. </param>
		/// <returns>The backslash joined <see cref="String"/> representation of the <paramref name="param1"/> and <paramref name="param2"/>. </returns>
		public static string BackSlash2String(object param1, object param2)
		{
			return string.Format(StringFormat.BackSlash2Format, param1, param2);
		}
		/// <summary>Gets a backslash separated string representation of the <paramref name="param1"/>,<paramref name="param2"/> and <paramref name="param3"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to backslash format. </param>
		/// <param name="param2">The second <see cref="Object"/> to backslash format. </param>
		/// <param name="param3">The third <see cref="Object"/> to backslash format. </param>
		/// <returns>The backslash joined <see cref="String"/> representation of the <paramref name="param1"/>,<paramref name="param2"/> and <paramref name="param3"/>. </returns>
		public static string BackSlash3String(object param1, object param2, object param3)
		{
			return string.Format(StringFormat.BackSlash3Format, param1, param2, param3);
		}
		/// <summary>Gets a backslash separated string representation of the <paramref name="param1"/>,<paramref name="param2"/>,<paramref name="param3"/> and <paramref name="param4"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to backslash format. </param>
		/// <param name="param2">The second <see cref="Object"/> to backslash format. </param>
		/// <param name="param3">The third <see cref="Object"/> to backslash format. </param>
		/// <param name="param4">The fourth <see cref="Object"/> to backslash format. </param>
		/// <returns>The backslash joined <see cref="String"/> representation of the <paramref name="param1"/>,<paramref name="param2"/>,<paramref name="param3"/> and <paramref name="param4"/>. </returns>
		public static string BackSlash4String(object param1, object param2, object param3, object param4)
		{
			return string.Format(StringFormat.BackSlash4Format, param1, param2, param3, param4);
		}
		/// <summary>Gets a backslash separated string representation of the <paramref name="param1"/>,<paramref name="param2"/>,<paramref name="param3"/>,<paramref name="param4"/> and <paramref name="param5"/>. </summary>
		/// <param name="param1">The first <see cref="Object"/> to backslash format. </param>
		/// <param name="param2">The second <see cref="Object"/> to backslash format. </param>
		/// <param name="param3">The third <see cref="Object"/> to backslash format. </param>
		/// <param name="param4">The fourth <see cref="Object"/> to backslash format. </param>
		/// <param name="param5">The fifth <see cref="Object"/> to backslash format. </param>
		/// <returns>The backslash joined <see cref="String"/> representation of the <paramref name="param1"/>,<paramref name="param2"/>,<paramref name="param3"/>,<paramref name="param4"/> and <paramref name="param5"/>. </returns>
		public static string BackSlash5String(object param1, object param2, object param3, object param4, object param5)
		{
			return string.Format(StringFormat.BackSlash5Format, param1, param2, param3, param4, param5);
		}
		/// <summary>Gets a backslash separated string representation of an object array (<paramref name="args"/>). </summary>
		/// <param name="args">The Array of <see cref="Object"/> to slash join. </param>
		/// <returns>The backslash joined <see cref="String"/> representation of the <paramref name="args"/> array of <see cref="Object"/>. </returns>
		public static string BackSlashNString(params object[] args)
		{
			ArrayList __args = new ArrayList();
			foreach(object obj in args)
			{
				string __str = Conversion.ToString(obj);
				if(Validation.IsSet(__str) && __str != "\\")
				{
					__args.Add(__str);
				}
			}
			string __string  = string.Join("\\", (string[])__args.ToArray(ValueType.CLSstring));
			return __string;
		}

        /// <summary>
        /// Format a given string to be Web compliant 
        ///  - \r\n are replaced by BR
        /// </summary>
        /// <param name="text">text to format</param>
        /// <returns></returns>
        public static string ConvertTextForWeb(string text)
        {
            text = text.Replace(RNConst, BRConst);
            return text;
        }
		/// <summary>
		/// Permet de convertir un texte windows en texte compatible avec javascript
		/// remplace les \r\n par des \n et les ' en \' et les " par \" et les \ par \\
		/// </summary>
		/// <param name="text">le texte � convertir</param>
		/// <returns>le text compatible avec javascript</returns>
		/// <remarks>
		/// Le texte aisin converti peut �tre pass� � une m�thode javascript
		/// </remarks>
        public static string ConvertTextToJavascript(string text)
        {
            return text.Replace(@"\", @"\\").Replace(RNConst, "\\n").Replace(@"""", @"\""").Replace("'", @"\'");
        }
		
		/// <summary>
		/// Permet de convertir un texte windows en texte compatible avec javascript
		/// remplace les \r\n par des <br/> et les ' en \\'
		/// </summary>
		/// <param name="text">le texte � convertir</param>
		/// <returns>le texte compatible avec HTML et javascript</returns>
		/// <remarks>
		/// Cette fonction doit �tre appel� pour afficher des messages non control�s (commentaire utilisateur par exemple) dans le Controle Basic.ToolTip,
		/// Cela �vite des failles de s�curit� qui permettent d'afficher des contenus ext�rieur � notre application (ex iframe, image ..) dans nos tooltip.
		/// </remarks>
        public static string ConvertTextToHTMLJavascript(string text)
        {
            //Permet de conserver les sauts de lignes (sans les encoder)
			string[] __strings		= text.Split(new string[]{RNConst}, StringSplitOptions.None); 
			string[] __stringsHTML	= __strings.Select(str => System.Web.HttpUtility.HtmlEncode(ConvertTextToJavascript(str))).ToArray();
            return string.Join(BRConst, __stringsHTML);
        }
	}
}
