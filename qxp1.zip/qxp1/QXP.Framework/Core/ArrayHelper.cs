using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Reflection;
using QXPDiagnostic = QXP.Framework.Diagnostic;

namespace QXP.Framework
{
    public class ArrayHelper
    {
        /// <summary>
        /// Ce Type de Trie (InsertionSort) est le plus rapide comparer � celui de Microsoft ou au QuickSort !!
        /// </summary>
        /// <param name="al"></param>
        /// <param name="fieldName"></param>
        public static void Sort(object al, string fieldName)
        {
            Sort(al, fieldName, true);
        }
        /// <summary>
        /// Ce Type de Trie est le plus rapide comparer � celui de Microsoft ou au QuickSort !!
        /// </summary>
        /// <param name="al"></param>
        /// <param name="fieldName"></param>
        public static void Sort(object al, string fieldName, bool ascending)
        {
            InternalInsertionSort(al, fieldName, ascending);
        }
        /// <summary>
        /// Ce Type de Trie est le plus rapide comparer � celui de Microsoft ou au QuickSort !!
        /// </summary>
        /// <param name="al"></param>
        /// <param name="comparer"></param>
        public static void Sort(object al, IComparer comparer)
        {
            InternalInsertionSort(al, comparer);
        }
        /// <summary>
        /// Ce Type de Trie (InsertionSort) est le plus rapide comparer � celui de Microsoft ou au QuickSort !!
        /// </summary>
        /// <param name="al"></param>
        /// <param name="fieldName"></param>
        public static void QuickSort(object al, string fieldName)
        {
            QuickSort(al, fieldName, true);
        }
        /// <summary>
        /// Ce Type de Trie (InsertionSort) est le plus rapide comparer � celui de Microsoft
        /// </summary>
        /// <param name="al"></param>
        /// <param name="fieldName"></param>
        public static void QuickSort(object al, string fieldName, bool ascending)
        {
            InternalQuickSort(al, fieldName, ascending);
        }
        /// <summary>
        /// Ce Type de Trie (InsertionSort) est le plus rapide comparer � celui de Microsoft
        /// </summary>
        /// <param name="al"></param>
        /// <param name="comparer"></param>
        public static void QuickSort(object al, IComparer comparer)
        {
            InternalQuickSort(al, comparer);
        }
        #region Internal Sorts
        static void InternalQuickSort(object obj, string fieldName, bool ascending)
        {
            Type __elemenType = Reflection.Reflection.GetElemenType(obj);
            if (Validation.IsNull(__elemenType)) return;
            UniversalComparer __comparer = new UniversalComparer(__elemenType, fieldName, ascending);
            InternalQuickSort(obj, __comparer);
        }
        static void InternalQuickSort(object obj, IComparer comparer)
        {
            ListSorter __sorter = new ListSorter(obj, comparer);
            __sorter.QuickSort();
        }
        static void InternalInsertionSort(object obj, string fieldName, bool ascending)
        {
            Type __elemenType = Reflection.Reflection.GetElemenType(obj);
            if (Validation.IsNull(__elemenType)) return;
            UniversalComparer __comparer = new UniversalComparer(__elemenType, fieldName, ascending);
            InternalInsertionSort(obj, __comparer);
        }
        static void InternalInsertionSort(object obj, IComparer comparer)
        {
            ListSorter __sorter = new ListSorter(obj, comparer);
            __sorter.InsertionSort();
        }
        #endregion
    }

    /// <summary>
    /// Class UniversalComparerMulti<T> : Permet d'effectuer une comparaison universelle entre 2 objets du m�me type
    /// </summary>
    /// <author></author>
    /// <date></date>
    public class UniversalComparer : IComparer
    {
        #region Membres

        FieldInfo _fieldInfo = null;
        PropertyInfo _propertyInfo = null;
        bool _isField = false;
        bool _isProperty = false;
        bool _ascending = true;
        int __i = 0;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de UniversalComparer
        /// </summary>
        /// <param name="elementType">Type des �l�ments � comparer</param>
        /// <param name="fieldName">Nom du champs � comparer</param>
        public UniversalComparer(Type elementType, string fieldName)
        {
            MemberInfo __memberInfo = this.GetMemberInfo(elementType, fieldName);
            if (__memberInfo is FieldInfo)
            {
                _isField = true;
                _fieldInfo = (FieldInfo)__memberInfo;
            }
            if (__memberInfo is PropertyInfo)
            {
                _isProperty = true;
                _propertyInfo = (PropertyInfo)__memberInfo;
            }
        }

        /// <summary>
        /// Cr�e une instance de UniversalComparer
        /// </summary>
        /// <param name="elementType">Type des �l�ments � comparer</param>
        /// <param name="fieldName">Nom du champs � comparer</param>
        /// <param name="ascending">Sens de comparaison</param>
        public UniversalComparer(Type elementType, string fieldName, bool ascending)
            : this(elementType, fieldName)
        {
            _ascending = ascending;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Permet d'obtenir la valeur de la propri�t� ou de la variable � comparer
        /// </summary>
        /// <param name="obj">objet � comparer</param>
        /// <returns>Valeur</returns>
        private object GetValue(object obj)
        {
            object __value = null;

            if (_isField)
            {
                __value = _fieldInfo.GetValue(obj);
            }
            if (_isProperty)
            {
                __value = _propertyInfo.GetValue(obj, new object[0]);
            }
            return __value;
        }

        /// <summary>
        /// Permet d'obtenir (par reflexion) le membre sur lequel on obtiendra la valeur � comparer.
        /// le membre peut �tre une propri�t� ou une variable.
        /// </summary>
        /// <param name="type">Type des �l�ments � comparer</param>
        /// <param name="fieldsName">Nom du membre</param>
        /// <returns>Informations du membres</returns>
        private MemberInfo GetMemberInfo(Type type, string fieldName)
        {
            MemberInfo[] __members = type.GetMember(fieldName);
            if (__members.Length == 1)
            {
                return __members[0];
            }
            return null;
        }

        /// <summary>
        /// M�thode qui effectue la comparaison
        /// </summary>
        /// <param name="objA">Objet � comparer A</param>
        /// <param name="objB">Objet � comparer B</param>
        /// <returns>int</returns>
        int IComparer.Compare(object objA, object objB)
        {
            object __valA = this.GetValue(objA);
            object __valB = this.GetValue(objB);

            __i++;
            IComparable __comparableA = __valA as IComparable;
            if (__comparableA != null)
            {
                return this.GetCompare(__comparableA.CompareTo(__valB));
            }
            IComparable __comparableB = __valB as IComparable;
            if (__comparableB == null)
            {
                throw new ArgumentException("bad objB");
            }
            return this.GetCompare(-__comparableB.CompareTo(__valA));
        }

        /// <summary>
        /// Permet de tenir compte de l'ordre de la comparaison (ascendant/descendant).
        /// </summary>
        /// <param name="compare">valeur de la comparaison (ascendant)</param>
        /// <returns>resultat finale de la comparaison en tenant compte de ascendant/descendant.</returns>
        private int GetCompare(int compare)
        {
            if (_ascending) return compare;
            return -compare;
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Permet de connaitre le nombre d'it�rations effectu�es par la comparaison
        /// </summary>
        public int NbComparaison
        {
            get { return __i; }
        }

        #endregion Propri�t�s
    }

    /// <summary>
    /// Class UniversalComparerMulti<T> : Permet d'effectuer une comparaison (Generic) universelle entre 2 objets du m�me type sur plusieurs champs
    /// </summary>
    /// <author>BTO</author>
    /// <date>20/05/2011</date>
    public class UniversalComparerMulti<T> : IComparer<T>
    {
        #region Membres

        List<FieldInfo> _fieldsInfo = new List<FieldInfo>();
        List<PropertyInfo> _propertiesInfo = new List<PropertyInfo>();
        bool _hasField = false;
        bool _hasProperty = false;
        List<bool> _ascending = null ;
        int __nbComparaison = 0;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de UniversalComparerMulti<T>
        /// </summary>
        /// <param name="fieldsName">Liste des nom de champs � comparer</param>
        public UniversalComparerMulti(List<string> fieldsName)
        {
            List<MemberInfo> __membersInfo = this.GetMembersInfo(fieldsName);

            foreach (MemberInfo __memberInfo in __membersInfo)
            {
                if (Validation.IsNull(__memberInfo))
                {
                    QXPDiagnostic.Log.LogError(string.Format("UniversalComparer<T> - Le membre [{0}] n'existe pas", fieldsName[__membersInfo.IndexOf(__memberInfo)]), new ArgumentException());
                }
                if (__memberInfo is FieldInfo)
                {
                    _hasField = true;
                    _fieldsInfo.Add((FieldInfo)__memberInfo);
                }
                if (__memberInfo is PropertyInfo)
                {
                    _hasProperty = true;
                    _propertiesInfo.Add((PropertyInfo)__memberInfo);
                }
            }
        }

        /// <summary>
        /// Cr�e une instance de UniversalComparerMulti<T>
        /// </summary>
        /// <param name="fieldsName">Liste des nom de champs � comparer</param>
        /// <param name="ascending">Liste des sens de comparaison correspondant � chaque champs � comparer</param>
        public UniversalComparerMulti(List<string> fieldsName, List<bool> ascending)
            : this(fieldsName)
        {
            _ascending = ascending;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Permet d'obtenir les valeurs des propri�t�s et/ou des variables � comparer
        /// </summary>
        /// <param name="obj">objet � comparer</param>
        /// <returns>Liste des valeurs</returns>
        private List<object> GetValues(object obj)
        {
            List<object> __listValues = new List<object>();
            if (_hasField)
            {
                foreach (FieldInfo __fieldInfo in _fieldsInfo)
                {
                    __listValues.Add(__fieldInfo.GetValue(obj));
                }
            }
            if (_hasProperty)
            {
                foreach (PropertyInfo __propertyInfo in _propertiesInfo)
                {
                    __listValues.Add(__propertyInfo.GetValue(obj, new object[0]));
                }
            }
            if (!_hasField && !_hasProperty)
                __listValues = null;

            return __listValues;
        }

        /// <summary>
        /// Permet d'obtenir (par reflexion) les membres sur lesquels on obtiendra la valeur � comparer.
        /// les membres peuvent �tre des propri�t�s ou des variables.
        /// </summary>
        /// <param name="fieldsName">Liste des noms des membres</param>
        /// <returns>Liste des informations des membres</returns>
        private List<MemberInfo> GetMembersInfo(List<string> fieldsName)
        {
            List<MemberInfo> __Allmembers = new List<MemberInfo>();
            foreach (string fieldName in fieldsName)
            {
                MemberInfo[] __members = typeof(T).GetMember(fieldName);
                if (__members.Length == 1)
                    __Allmembers.Add(__members[0]);
                else
                    __Allmembers.Add(null);
            }
            return __Allmembers;
        }

        /// <summary>
        /// M�thode qui effectue la comparaison
        /// </summary>
        /// <param name="objA">Objet � comparer A</param>
        /// <param name="objB">Objet � comparer B</param>
        /// <returns>int</returns>
        int IComparer<T>.Compare(T objA, T objB)
        {
            List<object> __membersA = this.GetValues(objA);
            List<object> __membersB = this.GetValues(objB);

            __nbComparaison++;

            if (Validation.IsNotSet(__membersA) && Validation.IsNotSet(__membersB)) return 0;

            int __resultCompareTo = int.MinValue;
            int __currentIndex = int.MinValue;
            bool __ascending = true;

            foreach (object __valA in __membersA)
            {
                __currentIndex = __membersA.IndexOf(__valA);
                __ascending = Validation.IsNotNull(_ascending) && _ascending.Count > __currentIndex ? _ascending[__currentIndex] : true;

                IComparable __comparableA = __valA as IComparable;
                if (__comparableA != null)
                {
                    __resultCompareTo = this.GetCompare(__comparableA.CompareTo(__membersB[__currentIndex]), __ascending);
                    if (__resultCompareTo != 0)
                        return __resultCompareTo;
                }
                else
                {
                    IComparable __comparableB = __membersB[__currentIndex] as IComparable;
                    if (__comparableB != null) // Les deux valeurs sont null, donc �gales 
                    {
                        return this.GetCompare(-__comparableB.CompareTo(__valA), __ascending);
                    }
                }
            }
            return 0;
        }

        /// <summary>
        /// Permet de tenir compte de l'ordre de la comparaison (ascendant/descendant).
        /// </summary>
        /// <param name="compare">valeur de la comparaison (ascendant)</param>
        /// <param name="ascending">comparaison ascendante ou non</param>
        /// <returns>resultat finale de la comparaison en tenant compte de ascendant/descendant.</returns>
        private int GetCompare(int compare, bool ascending)
        {
            if (Validation.IsNull(ascending) || ascending) return compare;
            return -compare;
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Permet de connaitre le nombre d'it�rations effectu�es par la comparaison
        /// </summary>
        public int NbComparaison
        {
            get { return __nbComparaison; }
        }

        #endregion Propri�t�s
    }

    public class ListSorter
    {
        IList _il;
        IComparer _comparer;
        public ListSorter(object obj) : this(obj, Comparer.Default) { }
        public ListSorter(object obj, IComparer comparer)
        {
            if (obj is IList)
            {
                _il = (IList)obj;
            }
            else
            {
                throw new ArgumentNullException("Invalid col Type");
            }
            _comparer = comparer;
        }
        #region Classic (DotNet) Sort
        public void Sort()
        {
            this.InsertionSort();
        }
        #endregion
        #region Quick Sort
        public void QuickSort()
        {
            if (_il.Count == 0) return;
            this.Q_Sort(0, _il.Count - 1);
        }
        private void Q_Sort(int left, int right)
        {
            int __l_hold, __r_hold, __i_pivot;
            object __pivot;

            __l_hold = left;
            __r_hold = right;
            __pivot = _il[left];

            while (left < right)
            {
                while ((_comparer.Compare(_il[right], __pivot) >= 0) && (left < right))
                {
                    right--;
                }

                if (left != right)
                {
                    _il[left] = _il[right];
                    left++;
                }

                while ((_comparer.Compare(_il[left], __pivot) <= 0) && (left < right))
                {
                    left++;
                }

                if (left != right)
                {
                    _il[right] = _il[left];
                    right--;
                }
            }

            _il[left] = __pivot;
            __i_pivot = left;
            left = __l_hold;
            right = __r_hold;

            if (left < __i_pivot)
            {
                Q_Sort(left, __i_pivot - 1);
            }

            if (right > __i_pivot)
            {
                Q_Sort(__i_pivot + 1, right);
            }
        }
        #endregion
        #region Insertion Sort
        public void InsertionSort()
        {
            this.I_Sort();
        }
        private void I_Sort()
        {
            int __i, __j;
            int x = _il.Count;
            object __obj;

            for (__i = 1; __i < x; __i++)
            {
                __obj = _il[__i];
                __j = __i;

                while ((__j > 0) && (_comparer.Compare(_il[__j - 1], __obj) > 0))
                {
                    _il[__j] = _il[__j - 1];
                    __j = __j - 1;
                }

                _il[__j] = __obj;
            }
        }
        #endregion
    }

    public class EnumHelper
    {
        public static Enum[] GetEnums(Type enumType)
        {
            Array __enums = Enum.GetValues(enumType);
            ArrayList __aemuns = new ArrayList(__enums);
            return (Enum[])__aemuns.ToArray(typeof(Enum));
        }

        public static Enum[] GetValues(Enum @enum)
        {
            Type enumType = @enum.GetType();
            if (!enumType.IsEnum) throw new ArgumentException("Must be an enum type");
            string __str_enum = @enum.ToString();
            string[] __str_enums = __str_enum.Split(',');
            Enum[] __enums = new Enum[__str_enums.Length];
            for (int __i = 0; __i < __str_enums.Length; __i++)
            {
                Enum __enum = (Enum)Enum.Parse(enumType, __str_enums[__i], true);
                __enums[__i] = __enum;
            }
            return __enums;
        }

        public static Hashtable GetKeysValues(Enum @enum)
        {
            Enum[] __enums = GetValues(@enum);
            Hashtable __list = new Hashtable();
            foreach (Enum __enum in __enums)
            {
                __list.Add(Conversion.ToInt(__enum), __enum.ToString());
            }
            return __list;
        }

        public static Hashtable GetKeysValues(Type enumType)
        {
            Enum[] __enums = GetEnums(enumType);
            Hashtable __list = new Hashtable();
            foreach (Enum __enum in __enums)
            {
                __list.Add(Conversion.ToInt(__enum), __enum.ToString());
            }
            return __list;
        }

        public static Hashtable GetKeysValues_Localized(Enum @enum, Array sections)
        {
            return GetKeysValues_Localized(@enum, false, sections);
        }

        public static Hashtable GetKeysValues_Localized(Enum @enum, bool delNSValue, Array sections)
        {
            Enum[] __enums = GetValues(@enum);
            return GetKeysValues_Localized(__enums, delNSValue, sections);
        }

        public static Hashtable GetKeysValues_Localized(Enum @enum, params object[] sections)
        {
            return GetKeysValues_Localized(@enum, false, (Array)sections);
        }

        public static Hashtable GetKeysValues_Localized(Enum @enum, bool delNSValue, params object[] sections)
        {
            return GetKeysValues_Localized(@enum, delNSValue, (Array)sections);
        }

        public static Hashtable GetKeysValues_Localized(Type enumType, Array sections)
        {
            return GetKeysValues_Localized(enumType, false, sections);
        }

        public static Hashtable GetKeysValues_Localized(Type enumType, bool delNSValue, Array sections)
        {
            Enum[] __enums = GetEnums(enumType);
            return GetKeysValues_Localized(__enums, delNSValue, sections);
        }

        public static Hashtable GetKeysValues_Localized(Type enumType, params object[] sections)
        {
            return GetKeysValues_Localized(enumType, false, (Array)sections);
        }

        public static Hashtable GetKeysValues_Localized(Type enumType, bool delNSValue, params object[] sections)
        {
            return GetKeysValues_Localized(enumType, delNSValue, (Array)sections);
        }

        public static Hashtable GetKeysValues_Localized(Enum[] enums, Array sections)
        {
            return GetKeysValues_Localized(enums, false, (Array)sections);
        }

        public static Hashtable GetKeysValues_Localized(Enum[] enums, bool delNSValue, Array sections)
        {
            Hashtable __list = new Hashtable();
            foreach (Enum __enum in enums)
            {
                if (!delNSValue || Validation.IsSet(Conversion.ToInt(__enum)))
                    __list.Add(Conversion.ToInt(__enum), GetLocalized_Enum(__enum, sections));
            }
            return __list;
        }

        public static OrderedDictionary GetOrderedKeysValues(Enum @enum)
        {
            Enum[] __enums = GetValues(@enum);
            OrderedDictionary __list = new OrderedDictionary();
            foreach (Enum __enum in __enums)
            {
                __list.Add(Conversion.ToInt(__enum), __enum.ToString());
            }
            return __list;
        }

        public static OrderedDictionary GetOrderedKeysValues(Type enumType)
        {
            Enum[] __enums = GetEnums(enumType);
            OrderedDictionary __list = new OrderedDictionary();
            foreach (Enum __enum in __enums)
            {
                __list.Add(Conversion.ToInt(__enum), __enum.ToString());
            }
            return __list;
        }

        public static OrderedDictionary GetOrderedKeysValues_Localized(Enum @enum, Array sections)
        {
            Enum[] __enums = GetValues(@enum);
            return GetOrderedKeysValues_Localized(__enums, sections);
        }

        public static OrderedDictionary GetOrderedKeysValues_Localized(Enum @enum, params object[] sections)
        {
            return GetOrderedKeysValues_Localized(@enum, (Array)sections);
        }

        public static OrderedDictionary GetOrderedKeysValues_Localized(Type enumType, Array sections)
        {
            Enum[] __enums = GetEnums(enumType);
            return GetOrderedKeysValues_Localized(__enums, sections);
        }

        public static OrderedDictionary GetOrderedKeysValues_Localized(Type enumType, params object[] sections)
        {
            return GetOrderedKeysValues_Localized(enumType, (Array)sections);
        }

        public static OrderedDictionary GetOrderedKeysValues_Localized(Enum[] enums, Array sections)
        {
            OrderedDictionary __list = new OrderedDictionary();
            foreach (Enum __enum in enums)
            {
                __list.Add(Conversion.ToInt(__enum), GetLocalized_Enum(__enum, sections));
            }
            return __list;
        }

        public static OrderedDictionary GetOrderedKeysValues_Localized(Enum[] enums, params object[] sections)
        {
            return GetOrderedKeysValues_Localized(enums, (Array)sections);
        }

        public static string GetLocalized_Enum(Enum @enum, Array sections)
        {
            return Application.Application.Resources.GetData(sections, @enum.ToString());
        }

        public static string GetLocalized_Enum(Enum @enum, params object[] sections)
        {
            return GetLocalized_Enum(@enum, (Array)sections);
        }

        /// <summary>
        /// Permet de tester l'existance d'une enum�ration dans un type d'�num�ration sp�cifique
        /// </summary>
        /// <param name="enumType">Type de l'enum�ration</param>
        /// <param name="value">Valeur de l'�num�ration (peut �tre une valeur enti�re ou du texte) </param>
        /// <param name="ignoreCase">si c'est du texte la comparaison doit-elle etre sensible � la casse ?</param>
        /// <returns>true si la valeur existe dans enum�ration</returns>
        public static bool IsDefined(Type enumType, object value, bool ignoreCase)
        {
            if (!ignoreCase)
                return Enum.IsDefined(enumType, value);
            else
            {
                try
                {
                    object __enumParsed = Enum.Parse(enumType, Conversion.ToString(value), true);
                    return true;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    public class SortableCollectionBase : CollectionBase
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="comparer"></param>
        public void Sort(IComparer comparer)
        {
            this.InnerList.Sort(comparer);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        public void Sort(string fieldName)
        {
            this.Sort(fieldName, true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="ascending"></param>
        public void Sort(string fieldName, bool ascending)
        {
            ArrayHelper.Sort(this.InnerList, fieldName, ascending);
        }
    }

    public class SortableArrayList : ArrayList
    {

        public SortableArrayList() : base() { }
        public SortableArrayList(int capacity) : base(capacity) { }

        #region Classic Sort (Dotnet)
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        public void Sort(string fieldName)
        {
            this.Sort(fieldName, true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="ascending"></param>
        public void Sort(string fieldName, bool ascending)
        {
            if (this.Count == 0) return;
            ArrayHelper.Sort(this, fieldName, ascending);
        }

        public new void Sort(IComparer comparer)
        {
            ArrayHelper.Sort(this, comparer);
        }
        #endregion
        #region Quick Sort
        public void QuickSort(string fieldName)
        {
            this.QuickSort(fieldName, true);
        }
        public void QuickSort(string fieldName, bool ascending)
        {
            ArrayHelper.QuickSort(this, fieldName, ascending);
        }
        public void QuickSort(IComparer comparer)
        {
            ArrayHelper.QuickSort(this, comparer);
        }
        #endregion
        #region Insertion Sort
        public void InsertionSort(string fieldName)
        {
            this.InsertionSort(fieldName, true);
        }
        public void InsertionSort(string fieldName, bool ascending)
        {
            ArrayHelper.Sort(this, fieldName, ascending);
        }
        public void InsertionSort(IComparer comparer)
        {
            ArrayHelper.Sort(this, comparer);
        }
        #endregion
    }

    /// <summary>
    /// Classe g�n�rique utilisant les fonctions de tri de liste
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class SortableList<T> : BaseList<T>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de SortableList
        /// </summary>
        public SortableList()
            : base()
        {
        }

        /// <summary>
        /// Cr�e une instance de SortableList avec une capacit� initiale
        /// </summary>
        /// <param name="capacity">Capacit� de la liste</param>
        public SortableList(int capacity)
            : base(capacity)
        {
        }

        /// <summary>
        /// Cr�e une instance de SortableList initialis�e avec une liste des �l�ments
        /// </summary>
        /// <param name="liste">Liste d'�l�ments</param>
        public SortableList(IEnumerable<T> liste)
            : base(liste)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #region Sort

        /// <summary>
        /// Tri selon une propri�t� de l'objet de la liste
        /// </summary>
        /// <param name="fieldName">Nom de la propri�t�</param>
        public void Sort(string fieldName)
        {
            ArrayHelper.Sort(this, fieldName);
        }

        /// <summary>
        /// Tri selon une propri�t� de l'objet de la liste et selon un ordre
        /// </summary>
        /// <param name="fieldName">Nom de la propri�t�</param>
        /// <param name="ascending">Sens de tri ascendant ou non</param>
        public void Sort(string fieldName, bool ascending)
        {
            ArrayHelper.Sort(this, fieldName, ascending);
        }

        /// <summary>
        /// Tri la liste � partir d'un comparer
        /// </summary>
        /// <param name="comparer">Comparer</param>
        public void Sort(IComparer comparer)
        {
            ArrayHelper.Sort(this, comparer);
        }

        #endregion

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }


    /// <summary>
    /// Classe g�n�rique mutualisant des fonctions de manipulation de listes
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <author>Laure Lippens</author>
    /// <date>29/07/2009</date>   
    public class BaseList<T> : List<T>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de BaseList
        /// </summary>
        public BaseList()
            : base()
        {
        }

        /// <summary>
        /// Cr�e une instance de BaseList avec une capacit� initiale
        /// </summary>
        /// <param name="capacity">Capacit� de la liste</param>
        public BaseList(int capacity)
            : base(capacity)
        {
        }

        /// <summary>
        /// Cr�e une instance de BaseList initialis�e avec une liste des �l�ments
        /// </summary>
        /// <param name="liste">Liste d'�l�ments</param>
        public BaseList(IEnumerable<T> liste)
            : base(liste)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #region FindIn

        /// <summary>
        /// Retourne la liste des �l�ments de la liste actuelle �tant �galement dans la liste pass�e en param�tre
        /// </summary>
        /// <param name="list">Liste contenant les �l�ments � comparer</param>
        /// <returns>Liste des �l�ments communs</returns>
        public BaseList<T> FindIn(BaseList<T> list)
        {
            return new BaseList<T>(this.FindAll(list.Contains));
        }

        #endregion FindIn

        #region FindNotIn

        /// <summary>
        /// Retourne la liste des �l�ments de la liste actuelle n'�tant pas dans la liste pass�e en param�tre
        /// </summary>
        /// <param name="list">Liste contenant les �l�ments � comparer</param>
        /// <returns>Liste des �l�ments non pr�sents</returns>
        public BaseList<T> FindNotIn(BaseList<T> list)
        {
            return new BaseList<T>(this.FindAll(delegate(T item) { return !list.Contains(item); }));
        }

        #endregion FindNotIn

        #region Universal Sort

        /// <summary>
        /// Permet d'effectuer un tri ascendant sur la propri�t� sp�cifi�e par field dans les objects contenu dans la liste
        /// </summary>
        /// <param name="field">Champs sur lequel appliquer le tri</param>
        public void Sort(Enum field)
        {
            this.Sort(field, true);
        }

        /// <summary>
        /// Permet d'effectuer un tri ascendant ou descendant sur la propri�t� sp�cifi�e par field dans les objects contenu dans la liste
        /// </summary>
        /// <param name="field">Champs sur lequel appliquer le tri</param>
        /// <param name="ascending">Sens du tri (ascendant ou non)</param>
        public void Sort(Enum field, bool ascending)
        {
            this.Sort(Conversion.ToString(field), ascending);
        }

        /// <summary>
        /// Permet d'effectuer un tri ascendant sur la propri�t� sp�cifi�e par field dans les objects contenu dans la liste
        /// </summary>
        /// <param name="fieldName">Champs sur lequel appliquer le tri</param>
        public void Sort(string fieldName)
        {
            this.Sort(fieldName, true);
        }

        /// <summary>
        /// Permet d'effectuer un tri ascendant ou descendant sur la propri�t� sp�cifi�e par fieldName dans les objects contenu dans la liste
        /// </summary>
        /// <param name="fieldName">Champs sur lequel appliquer le tri</param>
        /// <param name="ascending">Sens du tri (ascendant ou non)</param>
        public void Sort(string fieldName, bool ascending)
        {
            IComparer<T> __comparer = new UniversalComparerMulti<T>(new List<string>(){fieldName}, new List<bool>(){ascending});
            this.Sort(__comparer);
        }

        /// <summary>
        /// Permet d'effectuer un tri ascendant ou descendant sur les propri�t�s sp�cifi�es par fieldsName dans les objects contenu dans la liste
        /// </summary>
        /// <param name="fieldsName">Liste des champs sur lesquels appliquer le tri</param>
        /// <param name="ascending">Liste des sens de tri (ascendant ou non) par champs</param>
        public void Sort(List<string> fieldsName, List<bool> ascending)
        {
            IComparer<T> __comparer = new UniversalComparerMulti<T>(fieldsName, ascending);
            this.Sort(__comparer);
        }

        #endregion Universal Sort

        #region Universal Convert

        /// <summary>
        /// Converti la liste en une autre liste g�n�rique de T
        /// </summary>
        /// <typeparam name="T">Type souhait� pour les �lements de la nouvelle liste</typeparam>
        /// <returns>La liste convertie</returns>
        public BaseList<T> ToConvert<T>()
        {
            return Conversion.ToBaseList<T>(this);
        }

        /// <summary>
        /// Convertit la liste en une autre liste g�n�rique de TOutput.
        /// Les �l�ments convertis en null ne sont pas ajout�s � la liste finale
        /// </summary>
        /// <typeparam name="TOutput">Type souhait� pour les �lements de la nouvelle liste</typeparam>
        /// <param name="converter">Converter</param>
        /// <returns>BaseList de TOutput</returns>
        public BaseList<TOutput> ConvertAllNotNull<TOutput>(Converter<T, TOutput> converter)
        {
            List<TOutput> _list = new List<TOutput>();
            this.ForEach
            (
                delegate(T __item)
                {

                    TOutput __newitem = converter(__item);
                    if (__newitem != null)
                        _list.Add(__newitem);
                }
            );
            return new BaseList<TOutput>(_list);
        }

        #endregion

        #region Contains
        /// <summary>
        /// Permet de tester si la liste en cours contient au moins un element de la liste pass�e
        /// </summary>
        /// <param name="list">la liste � tester</param>
        /// <returns>true au moins un element de list existe la liste en cours.sinon false </returns>
        public bool ContainsOne(BaseList<T> list)
        {
            foreach (T __t in list)
            {
                if (this.Contains(__t)) return true;
            }
            return false;
        }
        #endregion

        #region Iteration
        /// <summary>
        /// permet l'implementation d'un foreach � l'envers � partir de l'objet start sans creation d'un custom IEnumerator
        /// </summary>
        /// <param name="start">objet � partir duquel l'it�ration inverse doit �tre r�alis�e.</param>
        /// <returns>Un enumerable utilisable dans un foreach</returns>
        public IEnumerable<T> Get_Reverse_Enumerable(T start)
        {
            int __start;
            if (Validation.IsNull(start))
            {
                __start = -1; //on prend le dernier �l�ment
            }
            else
            {
                __start = this.IndexOf(start);
            }

            if (__start < 0)
            {
                __start = this.Count - 1;
            }
            for (int __i = __start; __i >= 0; __i--)
            {
                yield return this[__i];
            }
        }


        /// <summary>
        /// permet l'implementation d'un foreach � � partir de l'objet start sans creation d'un custom IEnumerator
        /// </summary>
        /// <param name="start">objet � partir duquel l'it�ration doit �tre r�alis�e.</param>
        /// <returns>Un enumerable utilisable dans un foreach</returns>
        public IEnumerable<T> Get_Enumerable(T start)
        {
            int __start;
            if (Validation.IsNull(start))
            {
                __start = 0; //on prend le premier �l�ment
            }
            else
            {
                __start = this.IndexOf(start);
            }

            for (int __i = __start; __i < this.Count; __i++)
            {
                yield return this[__i];
            }
        }

        /// <summary>
        /// permet l'implementation d'un foreach � l'envers � partir du dernier �l�ment sans creation d'un custom IEnumerator
        /// </summary>
        /// <param name="start"></param>
        /// <returns>Un enumerable utilsiable dans un foreach</returns>
        public IEnumerable<T> Get_Reverse_Enumerable()
        {
            return Get_Reverse_Enumerable(default(T));
        }

        #endregion

        #region RemoveAll

        /// <summary>
        /// Permet de supprimer de la liste courante tous les elements pr�sent dans la liste 'items'
        /// </summary>
        /// <param name="items">la liste des elements � supprimer</param>
        public void RemoveAll(BaseList<T> items)
        {
            this.RemoveAll(delegate(T item) { return items.Contains(item); });
        }

        #endregion

        /// <summary>
        /// Clone la liste
        /// </summary>
        /// <returns>BaseList de T</returns>
        public BaseList<T> Clone()
        {
            return new BaseList<T>(this);
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }



    public class HashArrayList : IEnumerable
    {
        ArrayList __objects = new ArrayList();
        Hashtable __hash_Objects = new Hashtable();
        public virtual void Add(object key, object value)
        {
            if (!__hash_Objects.ContainsKey(key))
            {
                __objects.Add(value);
                __hash_Objects.Add(key, value);
            }
        }
        public virtual void Remove(object key)
        {
            object __obj = this[key];
            if (Validation.IsNotNull(__obj))
            {
                __hash_Objects.Remove(key);
                __objects.Remove(__obj);
            }
        }
        public virtual ICollection Values
        {
            get
            {
                return __objects;
            }
        }
        public virtual object this[object key]
        {
            get
            {
                return __hash_Objects[key];
            }
            set
            {
                int __pos = this.GetPos(key);
                if (Validation.IsSet(__pos))
                {
                    __hash_Objects[key] = value;
                    __objects[__pos] = value;
                }
            }
        }
        public virtual void Clear()
        {
            __hash_Objects.Clear();
            __objects.Clear();
        }
        public IEnumerator GetEnumerator()
        {
            return __objects.GetEnumerator();
        }
        private int GetPos(object key)
        {
            object __obj = __hash_Objects[key];
            if (Validation.IsSet(__obj))
            {
                return __objects.IndexOf(__obj);
            }
            else
            {
                return int.MinValue;
            }
        }
    }

    public class CountReference : Dictionary<string, int>
    {
        public int AddReferenceAndCount(string name)
        {
            string __name = Conversion.ToString(name).ToUpper();
            if (this.ContainsKey(__name))
            {
                this[__name]++;
            }
            else
            {
                this.Add(__name, 1);
            }
            return this[__name];
        }
    }

    /// <summary>
    /// Specific Comparers
    /// </summary>
    public class Comparers
    {
        public class ListItemComparer : IComparer
        {

            bool _ascending = true;
            int _nbComparaison = 0;
            public ListItemComparer() { }
            public ListItemComparer(bool ascending)
            {
                _ascending = ascending;
            }
            int IComparer.Compare(object objA, object objB)
            {
                System.Web.UI.WebControls.ListItem __itemA = objA as System.Web.UI.WebControls.ListItem;
                System.Web.UI.WebControls.ListItem __itemB = objB as System.Web.UI.WebControls.ListItem;

                _nbComparaison++;
                if (__itemA != null)
                {
                    if (__itemB != null)
                    {
                        string __textA = __itemA.Text;
                        string __textB = __itemB.Text;

                        return this.GetCompare(__textA.CompareTo(__textB));
                    }
                    return this.GetCompare(1);
                }
                return 0;

            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="compare"></param>
            /// <returns></returns>
            private int GetCompare(int compare)
            {
                if (_ascending) return compare;
                return -compare;
            }
            public int NbComparaison
            {
                get { return _nbComparaison; }
            }
        }
    }


    /// <summary>
    /// Contient un clef et une valeur toute deux de type string
    /// peu �galement contenir un tag de type object pour plus de souplesse
    /// </summary>
    /// <author>MDO</author>
    /// <date>05/08/2009</date>    
    public class KeyValue_String
    {
        #region Membres
        string _key;
        string _value;
        object _tag = null;
        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de StringKeyValue
        /// </summary>
        public KeyValue_String()
        {

        }

        /// <summary>
        /// Cr�e une instance de StringKeyValue
        /// </summary>
        public KeyValue_String(string key, string value)
        {
            _key = key;
            _value = value;
        }
        public KeyValue_String(string key, string value, object tag)
            : this(key, value)
        {
            _tag = tag;
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s
        /// <summary>
        /// 
        /// </summary>
        public string Key
        {
            get { return _key; }
            set { _key = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Value
        {
            get { return _value; }
            set { _value = value; }
        }
        public object Tag
        {
            get { return _tag; }
            set { _tag = value; }
        }
        #endregion Propri�t�s
    }


    /// <summary>
    /// Repr�sente une liste de KeyValue_String
    /// </summary>
    /// <author>MDO</author>
    /// <date>05/08/2009</date>    
    public class ListKeyValue : SortableList<KeyValue_String>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ListKeyValue
        /// </summary>
        public ListKeyValue()
        {
        }

        #endregion Constructeur

        #region M�thodes
        /// <summary>
        /// Permet d'ajouter un element de type key/value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void Add(string key, string value)
        {
            this.Add(new KeyValue_String(key, value));
        }
        /// <summary>
        /// Permet d'ajouter un element de type key/value avec un tag
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="tag"></param>
        public void Add(string key, string value, object tag)
        {
            this.Add(new KeyValue_String(key, value, tag));
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }


}
