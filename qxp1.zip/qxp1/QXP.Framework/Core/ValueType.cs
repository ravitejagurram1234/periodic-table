using System;

namespace QXP.Framework
{
    /// <summary>
    /// Class ValueType : Provides services to specify the type of an object and to automatically convert supported types.
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class ValueType
    {
        #region Membres

        /// <summary>An integral type representing unsigned 8-bit integers with values between 0 and 255. </summary>
        public static Type CLSbyte = typeof(byte);

        /// <summary>An integral type representing signed 16-bit integers with values between -32768 and 32767. </summary>
        public static Type CLSint16 = typeof(short);

        /// <summary>An integral type representing signed 32-bit integers with values between -2147483648 and 2147483647. </summary>
        public static Type CLSint32 = typeof(int);

        /// <summary>An integral type representing signed 64-bit integers with values between -9223372036854775808 and 9223372036854775807. </summary>
        public static Type CLSint64 = typeof(long);

        /// <summary>A floating point type representing values ranging from negative 3.402823e38 to positive 3.402823e38 with a precision of 7 digits. </summary>
        public static Type CLSsingle = typeof(float);

        /// <summary>A floating point type representing values ranging from negative 1.79769313486232e308 to positive 1.79769313486232e308 with a precision of 15-16 digits. </summary>
        public static Type CLSdouble = typeof(double);

        /// <summary>A simple type representing Boolean values of true or false. </summary>
        public static Type CLSboolean = typeof(bool);

        /// <summary>An integral type representing unsigned 16-bit integers with values between 0 and 65535. The set of possible values for the Char type corresponds to the Unicode character set. </summary>
        public static Type CLSchar = typeof(char);

        /// <summary>A simple type representing values ranging from positive 79,228,162,514,264,337,593,543,950,335 to negative 79,228,162,514,264,337,593,543,950,335 with 28-29 significant digits. </summary>
        public static Type CLSdecimal = typeof(decimal);

        /// <summary>A general type representing any reference or value type not explicitly represented by another TypeCode. </summary>
        public static Type CLSobject = typeof(object);

        /// <summary>A sealed class type representing Unicode character strings. </summary>
        public static Type CLSstring = typeof(string);

        /// <summary>A type representing a <see cref="Enum"/> enumeration value. </summary>
        public static Type Enum = typeof(Enum);

        /// <summary>A type representing a <see cref="CLSbyte"/> enumeration value. </summary>
        public static Type EnumByte = typeof(byte);

        /// <summary>A type representing a <see cref="CLSint16"/> enumeration value. </summary>
        public static Type EnumInt16 = typeof(short);

        /// <summary>A type representing a <see cref="CLSint32"/> enumeration value. </summary>
        public static Type EnumInt32 = typeof(int);

        /// <summary>A type representing a <see cref="CLSint64"/> enumeration value. </summary>
        public static Type EnumInt64 = typeof(long);

        /// <summary>A type representing a date and time value. </summary>
        public static Type DateTime = typeof(System.DateTime);

        /// <summary>A type representing a time span value. </summary>
        public static Type TimeSpan = typeof(System.TimeSpan);

        /// <summary>A array type representing an array of string. </summary>
        public static Type[] ArrayOf1String = new Type[] { CLSstring };

        public static Type[] ArrayOf1Int = new Type[] { CLSint32 };

        public static Type ArrayOfBool = typeof(bool[]);

        public static Type ArrayOfInt16 = typeof(Int16[]);

        public static Type ArrayOfInt = typeof(int[]);

        public static Type ArrayOfInt64 = typeof(Int64[]);

        public static Type ArrayOfString = typeof(string[]);

        public static Type ArrayOfDate = typeof(DateTime[]);

        public static Type ArrayOfDecimal = typeof(Decimal[]);

        public static Type ArrayOfByte = typeof(byte[]);

        public static Type ArrayOfChar = typeof(char[]);

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        /// <summary>Specifies the code of <see cref="ValueType"/> types. </summary>
        public enum TypeCode
        {
            /// <summary>@@F: To be completed. </summary>
            CLSobject = 0,
            /// <summary>@@F: To be completed. </summary>
            CLSbyte = 1,
            /// <summary>@@F: To be completed. </summary>
            CLSint16 = 2,
            /// <summary>@@F: To be completed. </summary>
            CLSint32 = 3,
            /// <summary>@@F: To be completed. </summary>
            CLSint64 = 4,
            /// <summary>@@F: To be completed. </summary>
            CLSsingle = 5,
            /// <summary>@@F: To be completed. </summary>
            CLSboolean = 6,
            /// <summary>@@F: To be completed. </summary>
            CLSchar = 7,
            /// <summary>@@F: To be completed. </summary>
            CLSdecimal = 8,
            /// <summary>@@F: To be completed. </summary>
            CLSstring = 9,
            /// <summary>@@F: To be completed. </summary>
            CLSdouble = 14,
            /// <summary>@@F: To be completed. </summary>
            EnumByte = 16,
            /// <summary>@@F: To be completed. </summary>
            EnumInt16 = 17,
            /// <summary>@@F: To be completed. </summary>
            EnumInt32 = 18,
            /// <summary>@@F: To be completed. </summary>
            EnumInt64 = 19,
            /// <summary>@@F: To be completed. </summary>
            DateTime = 64,
            /// <summary>@@F: To be completed. </summary>
            TimeSpan = 65,
            /// <summary>@@F: To be completed. </summary>
            Unit = 66,
        }

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ValueType
        /// </summary>
        private ValueType() { }

        #endregion Constructeur

        #region M�thodes

        /// <summary>Returns the type for the provided <paramref name="typeCode" />. </summary>
        /// <param name="typeCode">The <see cref="TypeCode"/> to retrieve. </param>
        /// <returns>The corresponding <see cref="Type"/> of the <see cref="TypeCode"/>. </returns>
        public static Type GetType(TypeCode typeCode)
        {
            switch (typeCode)
            {
                default:
                case TypeCode.CLSobject: return CLSobject;
                case TypeCode.CLSboolean: return CLSboolean;
                case TypeCode.CLSbyte: return CLSbyte;
                case TypeCode.CLSchar: return CLSchar;
                case TypeCode.CLSdecimal: return CLSdecimal;
                case TypeCode.CLSdouble: return CLSdouble;
                case TypeCode.CLSint16: return CLSint16;
                case TypeCode.CLSint32: return CLSint32;
                case TypeCode.CLSint64: return CLSint64;
                case TypeCode.CLSsingle: return CLSsingle;
                case TypeCode.CLSstring: return CLSstring;
                case TypeCode.DateTime: return DateTime;
                case TypeCode.EnumByte: return EnumByte;
                case TypeCode.EnumInt16: return EnumInt16;
                case TypeCode.EnumInt32: return EnumInt32;
                case TypeCode.EnumInt64: return EnumInt64;
                case TypeCode.TimeSpan: return TimeSpan;
            }
        }

        /// <summary>Returns the type for the provided <paramref name="typeCode" />. </summary>
        /// <param name="typeCode">An object representing a <see cref="TypeCode"/>. </param>
        /// <returns>The corresponding <see cref="Type"/> of the <see cref="TypeCode"/>. </returns>        
        public static Type GetType(object typeCode)
        {
            return GetType((TypeCode)(Conversion.ToInt(typeCode)));
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
