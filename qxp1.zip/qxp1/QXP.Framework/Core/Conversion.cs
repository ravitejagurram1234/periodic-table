using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Web.UI.WebControls;
using Oracle.DataAccess.Client;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework
{
    /// <summary>
    /// Objet Conversion
    /// </summary>
    /// <author>cueffl</author>
    /// <date>19/01/2011 13:50:19</date>    
    public class Conversion
    {
        #region Membres

        #endregion Membres

        #region Constantes

        private const string NString = "N";
        private const string OString = "O";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Conversion
        /// </summary>
        public Conversion()
        {
        }

        #endregion Constructeur

        #region M�thodes

        public static string ToString(object value, string format)
        {
            if (Validation.IsSet(format)) return string.Format(string.Concat("{0:", format, "}"), value);
            else return ToString(value);
        }

        public static string ToString(object value)
        {
            return Convert.ToString(value);
        }
        
        public static string ToHexString(byte[] values)
        {
            StringBuilder __sb = new StringBuilder();
            if (Validation.IsSet(values))
            {
                foreach (int __i in values)
                {
                    __sb.AppendFormat("{0:X2}", __i);
                }
            }
            return __sb.ToString();
        }
        
        public static byte[] ToByteArray(string hexString)
        {
            if (Validation.IsNotSet(hexString) || hexString.Length % 2 != 0) return new byte[0];
            byte[] _bytes = new byte[hexString.Length / 2];
            for (int i = hexString.Length - 2, j = 0; i > 1; i -= 2, j++)
                _bytes[j] = Convert.ToByte(hexString.Substring(i, 2), 16);
            return _bytes;
        }
        
        public static bool ToBool(object value)
        {
            return ToBool(value, false);
        }
        
        public static bool ToBool(object value, bool defaultValue)
        {
            if (Validation.IsNull(value)) return defaultValue;
            return ToBool(ToString(value), defaultValue);
        }
        
        public static bool ToBool(string value)
        {
            return ToBool(value, false);
        }
        
        public static bool ToBool(string value, bool defaultValue)
        {
            bool __defaultValue = defaultValue;
            bool __newvalue = defaultValue;

            if (Validation.IsSet(value) && Boolean.TryParse(value, out __newvalue))
            {
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static bool ToBoolFromON(string value)
        {
            return ToBoolFromON(value, false);
        }
        
        public static bool ToBoolFromON(string value, bool defaultValue)
        {
            bool __defaultValue = defaultValue;
            if (Validation.IsNotSet(value)) return __defaultValue;
            try
            {
                if (value.ToUpper() == OString) return true;
                else return false;
            }
            catch
            {
                return __defaultValue;
            }
        }
        
        public static byte ToByte(object value)
        {
            if (Validation.IsNull(value)) return 0;
            return ToByte(Conversion.ToString(value));
        }
        
        public static byte ToByte(string value)
        {
            byte __defaultValue = 0;
            Decimal __newDecimalValue = Decimal.MinValue;
            byte __newvalue = 0;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, NumberFormatInfo.CurrentInfo, out __newDecimalValue))
            {
                __newvalue = (byte)__newDecimalValue;
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static short ToShort(object value)
        {
            return ToShort(ToString(value));
        }
        
        public static short ToShort(string value)
        {
            short __defaultValue = short.MinValue;
            Decimal __newDecimalValue = Decimal.MinValue;
            short __newvalue = short.MinValue;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, NumberFormatInfo.CurrentInfo, out __newDecimalValue))
            {
                __newvalue = (Int16)__newDecimalValue;
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static int ToInt(object value)
        {
            return ToInt(ToString(value));
        }
        
        public static int ToInt(object value, int defaultValue)
        {
            return ToInt(ToString(value), defaultValue);
        }
        
        public static int ToInt(string value)
        {
            return ToInt(value, int.MinValue);
        }
        
        public static int ToInt(string value, int defaultValue)
        {
            int __defaultValue = defaultValue;
            Decimal __newDecimalValue = Decimal.MinValue;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, NumberFormatInfo.CurrentInfo, out __newDecimalValue))
            {
                int __newvalue = __defaultValue;

                if (Validation.IsSet(__newDecimalValue))
                {
                    __newvalue = (Int32)__newDecimalValue;
                }

                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }

        public static int ToInt(Enum value)
        {
            return Convert.ToInt32(value);
        }
        
        public static long ToLong(object value)
        {
            return ToLong(ToString(value));
        }
        
        public static long ToLong(string value)
        {
            long __defaultValue = long.MinValue;
            Decimal __newDecimalValue = Decimal.MinValue;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, NumberFormatInfo.CurrentInfo, out __newDecimalValue))
            {
                long __newvalue = (Int64)__newDecimalValue;
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static decimal ToDecimal(object value)
        {
            return ToDecimal(ToString(value));
        }
        
        public static decimal ToDecimal(string value)
        {
            return ToDecimal(value, null);
        }
        
        public static decimal ToDecimal(string value, NumberFormatInfo format, decimal defaultValue)
        {
            decimal __defaultValue = defaultValue;
            Decimal __newDecimalValue = Decimal.MinValue;

            if (Validation.IsNull(format))
                format = NumberFormatInfo.CurrentInfo;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, format, out __newDecimalValue))
            {
                return __newDecimalValue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static decimal ToDecimal(string value, NumberFormatInfo format)
        {
            return ToDecimal(value, format, decimal.MinValue);
        }
        
        public static float ToFloat(object value)
        {
            return ToFloat(ToString(value));
        }
        
        public static float ToFloat(string value)
        {
            return ToFloat(value, null);
        }
        
        public static float ToFloat(string value, NumberFormatInfo format)
        {
            float __defaultValue = float.MinValue;

            if (Validation.IsNotSet(value))
                return __defaultValue;


            Single __newSingleValue = Single.MinValue;

            string __value = value.Replace(" ", "");

            if (Validation.IsNull(format))
                format = NumberFormatInfo.CurrentInfo;

            //BUG: this special test perform because Single.MinValue.ToString could not be parse to exact Single.MinValue !! 
            //round-trip Exception problem
            if (__value == Single.MinValue.ToString())
            {
                return __newSingleValue;
            }
            else if (Single.TryParse(__value, NumberStyles.Any, format, out __newSingleValue))
            {
                return __newSingleValue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static double ToDouble(object value)
        {
            return ToDouble(ToString(value));
        }
        
        public static double ToDouble(string value)
        {
            return ToDouble(value, null);
        }
        
        public static double ToDouble(decimal value)
        {
            //Permet de d�finir double.MinValue si value �gale decimal.MinValue
            if (Validation.IsNotSet(value)) return double.MinValue;
            return ToDouble(ToString(value));
        }
        
        public static double ToDouble(string value, NumberFormatInfo format)
        {
            double __defaultValue = double.MinValue;

            if (Validation.IsNotSet(value)) return __defaultValue;
            if (Validation.IsNull(format)) format = NumberFormatInfo.CurrentInfo;

            double __newDoubleValue = Double.MinValue;

            string __value = value.Replace(" ", "");

            //BUG: this special test perform because Single.MinValue.ToString could not be parse to exact Single.MinValue !! 
            //round-trip Exception problem
            if (__value == Double.MinValue.ToString())
            {
                return __newDoubleValue;
            }
            else if (Double.TryParse(__value, NumberStyles.Any, format, out __newDoubleValue))
            {
                return __newDoubleValue;
            }
            else
            {
                return __defaultValue;
            }

        }
        
        public static DateTime ToDateTime(object value)
        {
            if (value is DateTime) return (DateTime)value;
            return ToDateTime(ToString(value));
        }
        
        /// <summary>
        /// Converti un Oravalue en datetime
        /// </summary>
        /// <param name="value">OraValue</param>
        /// <returns>Un date time</returns>
        public static DateTime ToDateTime(Data.Oracle.OraValue value)
        {
            if (Validation.IsNotNull(value))
            {
                return (DateTime)value;
            }
            else
            {
                return DateTime.MinValue;
            }
        }
        
        public static DateTime ToDateTime(string value)
        {
            DateTime __defaultValue = DateTime.MinValue;
            DateTime __newvalue = DateTime.MinValue;

            if (Validation.IsSet(value) && DateTime.TryParse(value, out __newvalue))
            {
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static string[] ToStringArray(object value)
        {
            if (Validation.IsNull(value)) return new string[0];
            if (value.GetType() == ValueType.ArrayOfString) return (string[])value;
            if (value is ICollection && ((ICollection)value).Count > 0)
            {
                ArrayList __list = new ArrayList();
                foreach (object __value in (ICollection)value)
                {
                    __list.Add(Conversion.ToString(__value));
                }
                return (string[])__list.ToArray(ValueType.CLSstring);
            }
            return new string[0];
        }

        /// <summary>
        /// Permet de convertir une collection d'objet en collection de Datetime fortement typ�
        /// </summary>
        /// <param name="value">La collection � convertir</param>
        /// <returns>la liste de Datetime</returns>
        public static DateTime[] ToDateTimeArray(object value)
        {
            if (Validation.IsNull(value)) return new DateTime[0];
            if (value.GetType() == ValueType.ArrayOfDate) return (DateTime[])value;
            if (value is ICollection && ((ICollection)value).Count > 0)
            {
                ArrayList __list = new ArrayList();
                foreach (object __value in (ICollection)value)
                {
                    __list.Add(Conversion.ToDateTime(__value));
                }
                return (DateTime[])__list.ToArray(ValueType.DateTime);
            }
            return new DateTime[0];
        }

        /// <summary>
        /// Permet de convertir une collection d'objet en collection de int fortement typ�
        /// </summary>
        /// <param name="value">La collection � convertir</param>
        /// <returns>la liste de int</returns>
        public static Int32[] ToIntArray(object value)
        {
            if (Validation.IsNull(value)) return new Int32[0];
            if (value.GetType() == ValueType.ArrayOfInt) return (Int32[])value;
            if (value is ICollection && ((ICollection)value).Count > 0)
            {
                ArrayList __list = new ArrayList();
                foreach (object __value in (ICollection)value)
                {
                    __list.Add(Conversion.ToInt(__value));
                }
                return (Int32[])__list.ToArray(ValueType.CLSint32);
            }
            return new Int32[0];
        }

        /// <summary>
        /// Permet de convertir une collection d'objet en collection de decimal fortement typ�
        /// </summary>
        /// <param name="value">La collection � convertir</param>
        /// <returns>la liste de decimal</returns>
        public static Decimal[] ToDecimalArray(object value)
        {
            if (Validation.IsNull(value)) return new decimal[0];
            if (value.GetType() == ValueType.ArrayOfDecimal) return (decimal[])value;
            if (value is ICollection && ((ICollection)value).Count > 0)
            {
                ArrayList __list = new ArrayList();
                foreach (object __value in (ICollection)value)
                {
                    __list.Add(Conversion.ToDecimal(__value));
                }
                return (decimal[])__list.ToArray(ValueType.CLSdecimal);
            }
            return new decimal[0];
        }

        public static ICollection ToArray(ICollection collection, Type innerType)
        {

            ArrayList __list = new ArrayList();
            foreach (object __obj in collection)
            {
                __list.Add(ToObject(__obj, innerType));
            }

            if ((innerType == ValueType.CLSstring)) return (string[])__list.ToArray(ValueType.CLSstring);
            else if ((innerType == ValueType.CLSint16) || (innerType == ValueType.EnumInt16)) return (short[])__list.ToArray(ValueType.CLSint16);
            else if ((innerType == ValueType.CLSint32) || (innerType == ValueType.EnumInt32)) return (int[])__list.ToArray(ValueType.CLSint32);
            else if (innerType == ValueType.CLSint64 || (innerType == ValueType.EnumInt64)) return (long[])__list.ToArray(ValueType.CLSint64);
            else if (innerType == ValueType.CLSdecimal) return (decimal[])__list.ToArray(ValueType.CLSdecimal);
            else if (innerType == ValueType.CLSsingle) return (float[])__list.ToArray(ValueType.CLSsingle);
            else if (innerType == ValueType.CLSbyte) return (byte[])__list.ToArray(ValueType.CLSbyte);
            else if (innerType == ValueType.CLSboolean) return (bool[])__list.ToArray(ValueType.CLSboolean);
            else if (innerType == ValueType.DateTime) return (DateTime[])__list.ToArray(ValueType.DateTime);
            else return collection;
        }

        public static string[] ToStringArray(object value, bool shortDateString, string dateFormat)
        {
            if (Validation.IsNull(value)) return new string[0];
            if (value.GetType() == ValueType.ArrayOfString) return (string[])value;
            if (value is ICollection && ((ICollection)value).Count > 0)
            {
                ArrayList __list = new ArrayList();
                foreach (object __value in (ICollection)value)
                {
                    if (Validation.IsNotNull(__value))
                    {
                        if (__value.GetType() == typeof(DateTime))
                        {
                            // if shortDateString is set then we convert the datetime in shortDateString
                            if (shortDateString)
                                __list.Add(((DateTime)__value).ToShortDateString());

                            // else if the date format is set the convertion use the specified format
                            else if (Validation.IsNotNull(dateFormat))
                                __list.Add(((DateTime)__value).ToString(dateFormat));

                            // if none of the conditions is true then a basic toString is made
                            else
                                __list.Add(Conversion.ToString(__value));
                        }
                        else __list.Add(Conversion.ToString(__value));
                    }
                    else
                    {
                        __list.Add(null);
                    }
                }
                return (string[])__list.ToArray(ValueType.CLSstring);
            }
            return new string[0];
        }

        public static string[] ToStringArray(object value, bool shortDateString)
        {
            return ToStringArray(value, shortDateString, null);
        }

        public static object ToObject(object value, Type innerType)
        {
            if (value is ICollection && innerType.IsArray)
            {
                return ToArray((ICollection)value, innerType.GetElementType());
            }
            else
            {
                if ((innerType == ValueType.CLSstring)) return ToString(value);
                else if ((innerType == ValueType.CLSint16) || (innerType == ValueType.EnumInt16)) return ToShort(value);
                else if ((innerType == ValueType.CLSint32) || (innerType == ValueType.EnumInt32)) return ToInt(value);
                else if (innerType == ValueType.CLSint64 || (innerType == ValueType.EnumInt64)) return ToLong(value);
                else if (innerType == ValueType.CLSdecimal) return ToDecimal(value);
                else if (innerType == ValueType.CLSsingle) return ToFloat(value);
                else if (innerType == ValueType.CLSbyte) return ToByte(value);
                else if (innerType == ValueType.CLSboolean) return ToBool(value);
                else if (innerType == ValueType.DateTime) return ToDateTime(value);
                else if (innerType == ValueType.ArrayOfString) return ToStringArray(value);
                else if (innerType == ValueType.ArrayOfInt) return ToIntArray(value);
                else if (innerType == ValueType.CLSdouble) return ToDouble(value);
                else return value;
            }
        }

        public static object ToObject(Data.Oracle.OraValue value, Type innerType)
        {
            if ((innerType == ValueType.CLSstring)) return (string)value;
            else if ((innerType == ValueType.CLSint16) || (innerType == ValueType.EnumInt16)) return (short)value;
            else if ((innerType == ValueType.CLSint32) || (innerType == ValueType.EnumInt32)) return (int)(value);
            else if (innerType == ValueType.CLSint64 || (innerType == ValueType.EnumInt64)) return (long)(value);
            else if (innerType == ValueType.CLSdecimal) return (decimal)(value);
            else if (innerType == ValueType.CLSsingle) return (float)(value);
            else if (innerType == ValueType.CLSbyte) return (byte)(value);
            else if (innerType == ValueType.CLSboolean) return (bool)(value);
            else if (innerType == ValueType.DateTime) return (DateTime)(value);
            else if (innerType == ValueType.CLSdouble) return (double)(value);
            else return value;
        }

        public static ValidationDataType ToValidationDataType(Type type)
        {
            try
            {
                ValidationDataType __dataType;
                if (type == ValueType.CLSstring)
                {
                    __dataType = ValidationDataType.String;
                }
                else if (type == ValueType.CLSdouble)
                {
                    __dataType = ValidationDataType.Double;
                }
                else if (type == ValueType.CLSdecimal)
                {
                    //We use 'ValidationDataType.Double' Type instead of 'ValidationDataType.Currency' because Currency define group number with ',' character which can interfere with other locales !!!.
                    __dataType = ValidationDataType.Double;
                }
                else if (type == ValueType.CLSint32)
                {
                    __dataType = ValidationDataType.Integer;
                }
                else if (type == ValueType.DateTime)
                {
                    __dataType = ValidationDataType.Date;
                }
                else
                {
                    __dataType = ValidationDataType.String;
                }
                return __dataType;
            }
            catch
            {
                return ValidationDataType.String;
            }
        }
        
        public static OracleDbType ToOracleDBType(Type type)
        {
            try
            {
                OracleDbType __dbType;
                if (type == ValueType.CLSstring)
                {
                    __dbType = OracleDbType.Varchar2;
                }
                else if (type == ValueType.CLSdouble)
                {
                    __dbType = OracleDbType.Double;
                }
                else if (type == ValueType.CLSdecimal)
                {
                    __dbType = OracleDbType.Decimal;
                }
                else if (type == ValueType.CLSint32)
                {
                    __dbType = OracleDbType.Int32;
                }
                else if (type == ValueType.DateTime)
                {
                    __dbType = OracleDbType.Date;
                }
                else if (type == ValueType.TimeSpan)
                {
                    __dbType = OracleDbType.IntervalDS;
                }
                else if (type == ValueType.CLSboolean)
                {
                    __dbType = OracleDbType.Int32;
                }
                else if (ValueType.GetType(type) == ValueType.CLSobject)
                {
                    __dbType = OracleDbType.Object;
                }
                else
                {
                    __dbType = OracleDbType.Varchar2;
                }
                return __dbType;
            }
            catch
            {
                return OracleDbType.Varchar2;
            }
        }

        public static object ToEnum(Type type, string value)
        {
            return ToEnum(type, value, false);
        }

        public static object ToEnum(Type type, object value)
        {
            return ToEnum(type, ToString(value), false);
        }

        public static object ToEnum(Type type, string value, bool ignoreCase)
        {
            return Enum.Parse(type, value, ignoreCase);
        }

        public static object ToEnum(Type type, object value, bool ignoreCase)
        {
            return ToEnum(type, ToString(value), ignoreCase);
        }

        public static T_Enum ToEnum<T_Enum>(string value)
        {
            return ToEnum<T_Enum>(value, false);
        }

        public static T_Enum ToEnum<T_Enum>(object value)
        {
            return ToEnum<T_Enum>(ToString(value), false);
        }

        public static T_Enum ToEnum<T_Enum>(string value, bool ignoreCase)
        {
            return (T_Enum)Enum.Parse(typeof(T_Enum), value, ignoreCase);
        }

        public static T_Enum ToEnum<T_Enum>(object value, bool ignoreCase)
        {
            return ToEnum<T_Enum>(ToString(value), ignoreCase);
        }

        /// <summary>
        /// Permet de convertir une collection non generique en IEnumerable generique
        /// Cette fonction est utile par exemple lorsqu'il s'agit d'ajouter � une liste generique par la methode AddRange une liste d'object non generique (non Typ�)
        /// </summary>
        /// <typeparam name="T">Type de IEnumerable � retourner</typeparam>
        /// <param name="collection">la liste d'objet non generique</param>
        /// <returns>un type IEnumerable <![CDATA[<T>]]>.</returns>
        public static IEnumerable<T> ToIEnumerable<T>(ICollection collection)
        {
            foreach (T __val in collection)
            {
                yield return __val;
            }
        }

        /// <summary>
        /// Permet de convertir une collection non generique en IEnumerable generique
        /// Effectue �galement une conversion des �l�ments de la collection en type de T
        /// Cette fonction est utile par exemple lorsqu'il s'agit d'ajouter � une liste generique par la methode AddRange une liste d'object non generique (non Typ�)
        /// </summary>
        /// <typeparam name="T">Type de IEnumerable � retourner</typeparam>
        /// <param name="collection">la liste d'objet non generique</param>
        /// <returns>un type IEnumerable <![CDATA[<T>]]>.</returns>
        public static IEnumerable<T> ToIEnumerableConversion<T>(ICollection collection)
        {
            foreach (object __val in collection)
            {
                yield return (T)Conversion.ToObject(__val, typeof(T));
            }
        }

        /// <summary>
        /// Converti une collection en une liste g�n�rique de T
        /// </summary>
        /// <typeparam name="T">Type final des �lements de la liste</typeparam>
        /// <param name="collection">Collection � convertir</param>
        /// <returns>Une liste g�n�rique de T</returns>
        public static BaseList<T> ToBaseList<T>(ICollection collection)
        {
            BaseList<T> __baseList = new BaseList<T>();
            IEnumerator __iEnumerator = collection.GetEnumerator();
            while (__iEnumerator.MoveNext())
            {
                __baseList.Add((T)Conversion.ToObject(__iEnumerator.Current, ((Type)(typeof(T)))));
            }
            return __baseList;
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
