using System;
using System.Collections;
using System.Globalization;
using System.Text;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework
{
    /// <summary>
    /// Objet ConversionInvariante
    /// </summary>
    /// <author>cueffl</author>
    /// <date>19/01/2011 13:52:35</date>    
    public class ConversionInvariante
    {
        #region Membres

        static CultureInfo InvariantCulture = CultureInfo.InvariantCulture;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ConversionInvariante
        /// </summary>
        public ConversionInvariante()
        {
        }

        #endregion Constructeur

        #region M�thodes

        public static string ToString(object value, string format)
        {
            if (Validation.IsSet(format)) return string.Format(InvariantCulture, string.Concat("{0:", format, "}"), value);
            else return ToString(value);
        }
        
        public static string ToString(object value)
        {
            return Convert.ToString(value, InvariantCulture);
        }
        
        public static string ToHexString(byte[] values)
        {
            StringBuilder __sb = new StringBuilder();
            if (Validation.IsSet(values))
            {
                foreach (int __i in values)
                {
                    __sb.AppendFormat("{0:X2}", __i);
                }
            }
            return __sb.ToString();
        }
        
        public static byte[] ToByteArray(string hexString)
        {
            if (Validation.IsNotSet(hexString) || hexString.Length % 2 != 0) return new byte[0];
            byte[] _bytes = new byte[hexString.Length / 2];
            for (int i = hexString.Length - 2, j = 0; i > 1; i -= 2, j++)
                _bytes[j] = Convert.ToByte(hexString.Substring(i, 2), 16);
            return _bytes;
        }
        
        public static bool ToBool(object value)
        {
            return ToBool(value, false);
        }
        
        public static bool ToBool(object value, bool defaultValue)
        {
            if (Validation.IsNull(value)) return defaultValue;
            return ToBool(ToString(value), defaultValue);
        }
        
        public static bool ToBool(string value)
        {
            return ToBool(value, false);
        }
        
        public static bool ToBool(string value, bool defaultValue)
        {
            bool __defaultValue = defaultValue;
            bool __newvalue;

            if (Validation.IsSet(value) && Boolean.TryParse(value, out __newvalue))
            {
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static byte ToByte(object value)
        {
            if (Validation.IsNull(value)) return 0;
            return ToByte(Conversion.ToString(value));
        }
        
        public static byte ToByte(string value)
        {
            byte __defaultValue = 0;
            Decimal __newDecimalValue = Decimal.MinValue;
            byte __newvalue = 0;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, InvariantCulture.NumberFormat, out __newDecimalValue))
            {
                __newvalue = (Byte)__newDecimalValue;
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static short ToShort(object value)
        {
            return ToShort(ToString(value));
        }
        
        public static short ToShort(string value)
        {
            short __defaultValue = short.MinValue;
            Decimal __newDecimalValue = Decimal.MinValue;
            short __newvalue = short.MinValue;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, InvariantCulture.NumberFormat, out __newDecimalValue))
            {
                __newvalue = (Int16)__newDecimalValue;
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static int ToInt(object value)
        {
            return ToInt(ToString(value));
        }
        
        public static int ToInt(object value, int defaultValue)
        {
            return ToInt(ToString(value), defaultValue);
        }
        
        public static int ToInt(string value)
        {
            return ToInt(value, int.MinValue);
        }
        
        public static int ToInt(string value, int defaultValue)
        {
            int __defaultValue = defaultValue;
            Decimal __newDecimalValue = Decimal.MinValue;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, InvariantCulture.NumberFormat, out __newDecimalValue))
            {
                int __newvalue = (Int32)__newDecimalValue;
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static int ToInt(Enum value)
        {
            return Convert.ToInt32(value);
        }
        
        public static long ToLong(object value)
        {
            return ToLong(ToString(value));
        }
        
        public static long ToLong(string value)
        {
            long __defaultValue = long.MinValue;
            Decimal __newDecimalValue = Decimal.MinValue;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, InvariantCulture.NumberFormat, out __newDecimalValue))
            {
                long __newvalue = (Int64)__newDecimalValue;
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static decimal ToDecimal(object value)
        {
            return ToDecimal(ToString(value));
        }
        
        public static decimal ToDecimal(string value)
        {
            decimal __defaultValue = decimal.MinValue;
            Decimal __newDecimalValue = Decimal.MinValue;

            if (Validation.IsSet(value) && Decimal.TryParse(value.Replace(" ", ""), NumberStyles.Any, InvariantCulture.NumberFormat, out __newDecimalValue))
            {
                return __newDecimalValue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static float ToFloat(object value)
        {
            return ToFloat(ToString(value));
        }
        
        public static float ToFloat(string value)
        {
            float __defaultValue = float.MinValue;

            if (Validation.IsNotSet(value))
                return __defaultValue;


            Single __newSingleValue = Single.MinValue;

            string __value = value.Replace(" ", "");

            //BUG: this special test perform because Single.MinValue.ToString could not be parse to exact Single.MinValue !! 
            //round-trip Exception problem
            if (__value == Single.MinValue.ToString())
            {
                return __newSingleValue;
            }
            else if (Single.TryParse(__value, NumberStyles.Any, InvariantCulture.NumberFormat, out __newSingleValue))
            {
                return __newSingleValue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static double ToDouble(object value)
        {
            return ToDouble(ToString(value));
        }
        
        public static double ToDouble(string value)
        {
            double __defaultValue = double.MinValue;

            if (Validation.IsNotSet(value)) return __defaultValue;

            double __newDoubleValue = Double.MinValue;

            string __value = value.Replace(" ", "");

            //BUG: this special test perform because Single.MinValue.ToString could not be parse to exact Single.MinValue !! 
            //round-trip Exception problem
            if (__value == Double.MinValue.ToString())
            {
                return __newDoubleValue;
            }
            else if (Double.TryParse(__value, NumberStyles.Any, InvariantCulture.NumberFormat, out __newDoubleValue))
            {
                return __newDoubleValue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static DateTime ToDateTime(object value)
        {
            if (value is DateTime) return (DateTime)value;
            return ToDateTime(ToString(value));
        }
        
        public static DateTime ToDateTime(string value)
        {
            DateTime __defaultValue = DateTime.MinValue;
            DateTime __newvalue = DateTime.MinValue;

            if (Validation.IsSet(value) && DateTime.TryParse(value, InvariantCulture.DateTimeFormat, DateTimeStyles.None, out __newvalue))
            {
                return __newvalue;
            }
            else
            {
                return __defaultValue;
            }
        }
        
        public static string[] ToStringArray(object value)
        {
            if (Validation.IsNull(value)) return new string[0];
            if (value.GetType() == ValueType.ArrayOfString) return (string[])value;
            if (value is ICollection && ((ICollection)value).Count > 0)
            {
                ArrayList __list = new ArrayList();
                foreach (object __value in (ICollection)value)
                {
                    __list.Add(ToString(__value));
                }
                return (string[])__list.ToArray(ValueType.CLSstring);
            }
            return new string[0];
        }
        
        public static ICollection ToArray(ICollection collection, Type innerType)
        {

            ArrayList __list = new ArrayList();
            foreach (object __obj in collection)
            {
                __list.Add(ToObject(__obj, innerType));
            }

            if ((innerType == ValueType.CLSstring)) return (string[])__list.ToArray(ValueType.CLSstring);
            else if ((innerType == ValueType.CLSint16) || (innerType == ValueType.EnumInt16)) return (short[])__list.ToArray(ValueType.CLSint16);
            else if ((innerType == ValueType.CLSint32) || (innerType == ValueType.EnumInt32)) return (int[])__list.ToArray(ValueType.CLSint32);
            else if (innerType == ValueType.CLSint64 || (innerType == ValueType.EnumInt64)) return (long[])__list.ToArray(ValueType.CLSint64);
            else if (innerType == ValueType.CLSdecimal) return (decimal[])__list.ToArray(ValueType.CLSdecimal);
            else if (innerType == ValueType.CLSsingle) return (float[])__list.ToArray(ValueType.CLSsingle);
            else if (innerType == ValueType.CLSbyte) return (byte[])__list.ToArray(ValueType.CLSbyte);
            else if (innerType == ValueType.CLSboolean) return (bool[])__list.ToArray(ValueType.CLSboolean);
            else if (innerType == ValueType.DateTime) return (DateTime[])__list.ToArray(ValueType.DateTime);
            else return collection;
        }
        
        public static int[] ToIntArray(object value)
        {
            if (Validation.IsNull(value)) return null;
            if (value.GetType() == ValueType.ArrayOfInt) return (int[])value;
            if (value is ICollection && ((ICollection)value).Count > 0)
            {
                ArrayList __list = new ArrayList();
                foreach (object __value in (ICollection)value)
                {
                    __list.Add(ToInt(__value));
                }
                return (int[])__list.ToArray(ValueType.CLSint32);
            }
            return null;
        }
        
        public static object ToObject(object value, Type innerType)
        {
            if ((innerType == ValueType.CLSstring)) return ToString(value);
            else if ((innerType == ValueType.CLSint16) || (innerType == ValueType.EnumInt16)) return ToShort(value);
            else if ((innerType == ValueType.CLSint32) || (innerType == ValueType.EnumInt32)) return ToInt(value);
            else if (innerType == ValueType.CLSint64 || (innerType == ValueType.EnumInt64)) return ToLong(value);
            else if (innerType == ValueType.CLSdecimal) return ToDecimal(value);
            else if (innerType == ValueType.CLSsingle) return ToFloat(value);
            else if (innerType == ValueType.CLSdouble) return ToDouble(value);
            else if (innerType == ValueType.CLSbyte) return ToByte(value);
            else if (innerType == ValueType.CLSboolean) return ToBool(value);
            else if (innerType == ValueType.DateTime) return ToDateTime(value);
            else if (innerType == ValueType.ArrayOfString) return ToStringArray(value);
            else if (innerType == ValueType.ArrayOfInt) return ToIntArray(value);
            else return value;
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
