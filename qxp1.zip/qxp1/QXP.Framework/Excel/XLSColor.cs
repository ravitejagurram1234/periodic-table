using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Excel
{
    /// <summary>
    /// Classe utilis�e pour les couleurs Excel
    /// </summary>
    public class XLSColor
    {
        /// <summary>
        /// Ensemble des couleurs XLS diff�rente de la palette d'origine
        /// </summary>
		public enum EnumXLSColor
		{
            /// <summary>
            /// Violet QXP
            /// </summary>
			CustomizePurple, //Color.FromArgb(120,36,113)
            /// <summary>
            /// Rouge QXP
            /// </summary>
			CustomizeRed,	// Color.FromArgb(230,0,40)
            /// <summary>
            /// Orange QXP
            /// </summary>
			CustomizeOrange,// Color.FromArgb(244,121,32)
            /// <summary>
            /// Gris QXP
            /// </summary>
			CustomizeGray,	// Color.FromArgb(230,224,230)
            /// <summary>
            /// Saumon QXP
            /// </summary>
			CustomizeSaumon	// Color.FromArgb(255,221,195)
		}
        
        /// <summary>
        /// L'index des couleurs attribu� dans la palette est num�rot� bizarement, cette Hastable associe un ordre logique � l'index dans la palette de couleurs
        /// Excel pour les couleurs associ�es aux Ligne des graphiques
        /// </summary>
        public static Hashtable IndexLinePalette = new Hashtable();

        /// <summary>
        /// L'index des couleurs attribu� dans la palette est num�rot� bizarement, cette Hastable associe un ordre logique � l'index dans la palette de couleurs
        /// Excel pour les couleurs associ�es aux Remplissage des graphiques
        /// </summary>
        public static Hashtable IndexFillingPalette = new Hashtable();

        /// <summary>
        /// L'index des couleurs attribu� dans la palette est num�rot� bizarement, cette Hastable associe un ordre logique � l'index dans la palette de couleurs
        /// Excel pour les couleurs associ�es au classeur
        /// </summary>
        public static Hashtable IndexStandardPalette = new Hashtable();

        /// <summary>
        /// Cr�e une instance statique de XLSColor
        /// </summary>
        static XLSColor()
        {               
            // Remplissage 16 -> 23  et Line 24 -> 31 : 
            for(int __i=0;__i<8; __i++)
            {
                IndexFillingPalette.Add(__i, __i + 16);
                IndexLinePalette.Add(__i, __i + 24);
            }
            
            //Standard :
            IndexStandardPalette.Add(0, 0);
            //Ici la couleur dans la palette standard situ�e � deuxieme position (index = 1) est en fait associ�e � l'index 52...bizar bizar
            IndexStandardPalette.Add(1, 52);
            IndexStandardPalette.Add(2, 51);
            IndexStandardPalette.Add(3, 50);
            IndexStandardPalette.Add(4, 48);
            IndexStandardPalette.Add(5, 10);
            IndexStandardPalette.Add(6, 54);
            IndexStandardPalette.Add(7, 55);
            IndexStandardPalette.Add(8, 8);
            IndexStandardPalette.Add(9, 45);
            IndexStandardPalette.Add(10, 11);
            IndexStandardPalette.Add(11, 9);
            IndexStandardPalette.Add(12, 13);
            IndexStandardPalette.Add(13, 4);
            IndexStandardPalette.Add(14, 46);
            IndexStandardPalette.Add(15, 15);
            IndexStandardPalette.Add(16, 2);
            IndexStandardPalette.Add(17, 44);
            IndexStandardPalette.Add(18, 42);
            IndexStandardPalette.Add(19, 49);
            IndexStandardPalette.Add(20, 41);
            IndexStandardPalette.Add(21, 40);
            IndexStandardPalette.Add(22, 12);
            IndexStandardPalette.Add(23, 47);
            IndexStandardPalette.Add(24, 6);
            IndexStandardPalette.Add(25, 43);
            IndexStandardPalette.Add(26, 5);
            IndexStandardPalette.Add(27, 3);
            IndexStandardPalette.Add(28, 7);
            IndexStandardPalette.Add(29, 32);
            IndexStandardPalette.Add(30, 53);
            IndexStandardPalette.Add(31, 14);
            IndexStandardPalette.Add(32, 37);
            IndexStandardPalette.Add(33, 39);
            IndexStandardPalette.Add(34, 35);
            IndexStandardPalette.Add(35, 34);
            IndexStandardPalette.Add(36, 33);
            IndexStandardPalette.Add(37, 36);
            IndexStandardPalette.Add(38, 38);
            IndexStandardPalette.Add(39, 1);
          }

    }
}