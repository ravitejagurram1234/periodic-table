using System;
using System.Collections.Generic;

using Cells				= Aspose.Cells;

namespace QXP.Framework.Excel
{
	/// <summary>
	/// Caract�rise une coordonn�e X,Y dans une feuille Excel
	/// Conserv� pour les lignes et colonnes les valeurs maximale et minimale utilis�es.
	/// </summary>
	public class XLSCoordonnees
	{
        #region Membres

		private XLSMinValueMax	_ligne;
		private XLSMinValueMax	_colonne;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

		public XLSCoordonnees(int ligne, int colonne)
		{
			this._ligne			= new XLSMinValueMax(ligne);
			this._colonne		= new XLSMinValueMax(colonne);
		}

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Ligne de la coordonn�e
        /// </summary>
		public XLSMinValueMax	Ligne
        {
			get{return _ligne;}
		}
		
        /// <summary>
        /// Colonne de la coordonn�e
        /// </summary>
        public XLSMinValueMax	Colonne
        {
			get{return _colonne;}
		}

        #endregion Propri�t�s
	}

    /// <summary>
    /// Caract�rise une liste de valeurs utilis�es et d'�tat verrouill� ou pas (true ou false)
    /// - valeur (valeur en cours) repr�sente la position de la ligne ou de la colonne
    /// - min,  max (valeurs min et max dans la zone en cours)
    /// - grand_min, grand_max (valeurs min et max extr�mes utilis�es dans toutes les zones parcourues)
    /// Lorsque l'on appel la methode Reset_MinMax() cela sous entend que l'on change de zone (reinitialisation des min/Max/Valeur) mais PAS de grand_min, grand_max
    /// qui representent les valeurs extremes parcourues depuis la cr�ation de cette classe.
    /// </summary>
	public class XLSMinValueMax
	{
		#region Membres

		private int					_value;
		private int					_min;
		private int					_max;
		private int					_grand_min;
		private int					_grand_max;
		private bool				_lock_State = false;
		private readonly List<bool> _locked_values;

		#endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

		#region Constructeur

		public XLSMinValueMax(int val)
        {
			this._min 
				= this._max
				= this._value 
				= _grand_min 
				= _grand_max
				= val;

			_locked_values = new List<bool>(new bool[val+1]);
        }
		
		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// r�initialise la position (valeur) , valeur_min, valeur_max � la valeur sp�cifi�
		/// MAIS ne r�initialise pas Grand_Min et Grand_Max
		/// </summary>
		/// <param name="val"></param>
		public void		Reset_MinMax(int val)
		{
			_value = _min = _max = val;
			//par simplification j'appel cette methode !!
			Update_MinMax(val);
		}

    	/// <summary>
    	/// Mise � jour des valeur min, grand_min, max, grand_max � la valeur pass�
    	/// Assure egalement le verrouille (ou pas) de la ligne
    	/// </summary>
    	/// <param name="value"></param>
		private void	Update_MinMax(int value)
        {
			this._min		= Math.Min(this._min, value);
			this._max		= Math.Max(this._max, value);
			this._grand_min	= Math.Min(this._grand_min, value);
			this._grand_max	= Math.Max(this._grand_max, value);
			EnsureCapacity();
			if(_lock_State) Lock(value);
        }

		/// <summary>
		/// Maintien � jour la taille de la collection des valeurs utilis�
		/// </summary>
		private void	EnsureCapacity()
		{
			if(_locked_values.Count <= this._max)
			{
				int __nb = (this._max + 1) - _locked_values.Count;
				_locked_values.AddRange(new bool[__nb]); //Par d�faut toutes les lignes et colonnes sont s�parables
			}
		}
		
		/// <summary>
		/// Permet de verrouiller ou de d�verouiller une valeur
		/// </summary>
		/// <param name="value"></param>
		/// <param name="locked"></param>
		private void	Lock_Unlock(int value, bool locked)
		{
			_locked_values[value] = locked;
		}
		
		/// <summary>
		/// Permet de verrouiller une valeur
		/// </summary>
		private void	Lock(int value)
		{
			Lock_Unlock(value, true);
		}
    	
		/// <summary>
		/// Permet de d�finir si la valeur (ligne/colonne) en cours peut �tre s�par�e des autres pendant l'imppresion (dans certain format Excel par exemple). 
		/// </summary>
		public	void	Lock()
		{
			Lock(_value);
		}

		//private void	Unlock(int value)
		//{
		//    Lock_Unlock(value, false);
		//}

    	/// <summary>
		/// Permet de mettre � jour les max sans changer de position courante
		/// retourne la valeur de nbspan c'etait juste pour mettre � jour les min/max
		/// </summary>
		/// <param name="nbSpan"></param>
		/// <returns></returns>
		public int		Span(int nbSpan)
		{
			int __val = this.Value;
			for(int __i = 1; __i < nbSpan; __i++)
			{
				__val++;
				this.Update_MinMax(__val);
			}
			return nbSpan;
		}

    	/// <summary>
		/// Permet d'ajouter le nombre en plus � la valeur en cours et de retourner cette nouvelle valeur !
		/// </summary>
		/// <param name="nbenPlus"></param>
		/// <returns></returns>
		public int		Plus(int nbenPlus)
        {
			int __val = this.Value;
			for(int __i = 1; __i <= nbenPlus; __i++)
			{
				this.Value++;
			}
			return this.Value;
		}

    	/// <summary>
		/// Permet d'ajouter le nombre en plus � la valeur max en cours et de retourner cette nouvelle valeur !
		/// Attention pas de notion de locked sur cette appel de methode (� v�rifier si cela doit �tre n�cessaire plus tard)
		/// </summary>
		/// <param name="nbenPlus"></param>
		/// <returns></returns>
		public int		MaxPlus(int nbenPlus)
        {
			this._max += nbenPlus;
			return this._max;
		}

		#endregion        

		#region Propri�t�s

        /// <summary>
        /// Valeur Min utilis�e (cette valeur peut etre r�initialis�)
        /// </summary>
		public int			Min
		{
			get { return _min; }
		}
		/// <summary>
		/// Valeur Max utilis�e (cette valeur peut etre r�initialis�)
		/// </summary>
		public int			Max
		{
			get { return _max; }
		}
		
    	/// <summary>
    	/// Valeur Min utilis�e (cette valeur ne peut PAS etre r�initialis�)
    	/// </summary>
		public int			Grand_Min
    	{
    		get { return _grand_min; }
    	}

    	/// <summary>
    	/// Valeur Max utilis�e (cette valeur ne peut PAS etre r�initialis�)
    	/// </summary>
    	public int			Grand_Max
    	{
    		get { return _grand_max; }
    	}
		
		/// <summary>
		/// Permet d'affect� la nouvelle valeur et d'�valuer les nouveaux min et max
		/// Permet �galement de conserver la valeur en cours.
		/// </summary>
		public int			Value
        {
			get{return _value;}
			set{
				this._value = value;
				this.Update_MinMax(value);
			}
		}

    	/// <summary>
    	/// Permet de d�finir que l'etat du verrouillage des mouvements effectu�es
    	/// si Lock_State est true tout les d�placements par Value/Span/Plus mettrons le Lock sur les lignes parcourus
    	/// </summary>
		public bool			Lock_State
    	{
    		get { return _lock_State; }
			set { 
				_lock_State = value ; 
				Lock(_value); //Lock la ligne en cours !
			}
    	}
		
		/// <summary>
		/// Permet de savoir si la valeur en cours est lock
		/// c'est un etat mono stable s'il est pass� � true personne ne peux le refaire passer � false !!!
		/// </summary>
		public bool			Locked
    	{
    		get {return _locked_values[_value]; }
    	}

    	/// <summary>
    	/// Permet de r�cup�rer la collection des locks (bool) pour toutes les valeurs parcourues
    	/// </summary>
		public List<bool>	Locked_Values
    	{
    		get { return _locked_values; }
    	}
		#endregion Propri�t�s
	}

    /// <summary>
    /// Carat�rise la zone de travail + la coordonn�e courante
    /// </summary>
	public class XLSLayout
	{
        #region Membres

		private Cells.Worksheet				_worksheet;
		private readonly XLSCoordonnees		_coordonnees;
        #endregion Membres

        #region Constantes
        const int FIRST_COLONNE = 1;
        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

		public XLSLayout(Cells.Worksheet worksheet, int ligne, int colonne)
		{
			_coordonnees	= new XLSCoordonnees(ligne, colonne);
			_worksheet		= worksheet;
		}

		public XLSLayout(Cells.Worksheet worksheet, int ligne) : this(worksheet, ligne, FIRST_COLONNE){ }

        #endregion Constructeur

        #region M�thodes

        #region Lignes

        /// <summary>
        /// Saute 1 ligne (maj de la ligne min de la zonne courante)
        /// </summary>
		public void		LigneSuivante()
		{
		    Saut2Ligne(1);			
		}

        /// <summary>
        /// Saute 2 lignes (maj de la ligne min de la zonne courante)
        /// </summary>
		public void		Saut2Ligne()
		{ 
			Saut2Ligne(2);
		}

        /// <summary>
        /// Saute n lignes (maj de la ligne min de la zonne courante)
        /// </summary>
        /// <param name="nbLigne">Nombre de lignes � sauter</param>
		public void		Saut2Ligne(int nbLigne)
		{ 
			this.Coordonnees.Ligne.Plus(nbLigne);
		}

		#endregion Lignes

        #region Colonnes

        /// <summary>
        /// Saute 1 colonne (maj de la colonne min de la zonne courante)
        /// </summary>
		public void		ColonneSuivante()
		{
			Saut2Colonne(1);					    
		}

        /// <summary>
        /// Saute 2 colonnes (maj de la colonne min de la zonne courante)
        /// </summary>
		public void		Saut2Colonne()
		{ 
			Saut2Colonne(2);
		}

        /// <summary>
        /// Saute n colonnes (maj de la colonne min de la zonne courante)
        /// </summary>
        /// <param name="nbColonne">Nombre de colonnes � sauter</param>
		public void		Saut2Colonne(int nbColonne)
		{ 
			this.Coordonnees.Colonne.Plus(nbColonne);
		}

		#endregion Colonnes

        #region CoordonneesCourante / ZoneCourante

        /// <summary>
        /// Commence une nouvele ligne d'une nouvelle zone
        /// </summary>
		public void				DebutRow()
		{
			this.SetNewZone(this.Coordonnees.Ligne.Grand_Max + 1, this.Coordonnees.Colonne.Grand_Min);
		}

        /// <summary>
        /// Commence une nouvelle cellule d'une nouvelle zone
        /// </summary>
		public void				DebutCellSuivante()
		{			
			this.SetNewZone(_coordonnees.Ligne.Min, _coordonnees.Colonne.Max+2);
		}

    	/// <summary>
        /// Passe une ligne et r�initialise la colonne de la zone courante au min
        /// </summary>
		public void				RetourChariot()
		{
			SetNewZone(_coordonnees.Ligne.Value + 1, _coordonnees.Colonne.Grand_Min);
		}

		/// <summary>
		/// D�but d'une nouvelle zone dans la zone globale, les coordonn�es Min et Max des lignes et colonnes sont r�initialiser � la nouvelle coordonn�e.
		/// </summary>
		/// <param name="ligne"></param>
		/// <param name="colonne"></param>
		private void			SetNewZone(int ligne, int colonne)
		{
			_coordonnees.Ligne.Reset_MinMax(ligne);
			_coordonnees.Colonne.Reset_MinMax(colonne);
		}

		#endregion

		#endregion M�thodes

		#region Propri�t�s

		#region Coordonnees Courante

		/// <summary>
        /// Coordonn�es courantes
        /// </summary>
        public XLSCoordonnees	Coordonnees
		{
			get { return _coordonnees; }
		}
		
		/// <summary>
		/// Index de la ligne courante
		/// </summary>
    	public int				Ligne_Courante
    	{
    		get { return _coordonnees.Ligne.Value; }
			set { _coordonnees.Ligne.Value  = value; }
    	}
    	
		/// <summary>
    	/// Index de la colonne courante
    	/// </summary>
		public int				Colonne_Courante
    	{
    		get { return _coordonnees.Colonne.Value; }
			set { _coordonnees.Colonne.Value  = value; }
    	}
        #endregion Coordonnees Courante

        #endregion Propri�t�s
	}
}
