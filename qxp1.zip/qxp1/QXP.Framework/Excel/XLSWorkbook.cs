using System.Collections.Generic;
using System.Globalization;
using QXP.Framework.Graph.Colors;
using Cells = Aspose.Cells;

namespace QXP.Framework.Excel
{
    /// <summary>
    /// D�finit un classeur excel QXP
    /// </summary>
    public class XLSWorkbook
    {
        #region Membres

        /// <summary>
        /// Classeur Excel
        /// </summary>
        private Cells.Workbook _classeurExcel;

        /// <summary>
        /// Feuille Excel
        /// </summary>
        private XLSWorksheet _currentSheet;

        /// <summary>
        /// Culture du fichier Excel
        /// </summary>
        private CultureInfo _culture;

        /// <summary>
        /// Titre (Titre par d�faut : Rapport)
        /// </summary>
        private string _titre;

        /// <summary>
        /// Titre Version courte sans argument
        /// </summary>
        private string _titre_court = string.Empty;

        /// <summary>
        /// Liste des feuilles du classeur
        /// </summary>
        Dictionary<string, XLSWorksheet> _workSheets = new Dictionary<string, XLSWorksheet>();

        /// <summary>
        /// Permet de d�finir l'orientation d'impression (portrait/paysage)
        /// </summary>
        bool _portrait = false;

        Palette _palette = null;

        #endregion Membres

        #region Constantes

        const string TITRE_DEFAUT = "Rapport";
        /// <summary>
        /// D�finit la largeur ajout� syst�matiquement au entete (colonnedef) des tableaux
        /// Cette valeur est historique 
        /// </summary>
        public const int MARGE_WIDTH = 30;
        const int FooterPosition = 2; //0:Left 1:Center 2:Right
        const string FooterScript = "&P"; //&P: Page number (&10 Taille police)

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Instancie un classeur excel
        /// </summary>
        /// <param name="classeurExcel">Classeur Excel Aspose manipul�</param>
        public XLSWorkbook(Cells.Workbook classeurExcel)
        {
            _classeurExcel = classeurExcel;

            this.ResetTitleToDefault();

            //Cas particulier de la cr�ation du XLSWorkbook on affecte _current � la premi�re feuille mais ont ne l'ajoute pas dans la collection des _worksheets
            _currentSheet = new XLSWorksheet(_classeurExcel.Worksheets[0]);

        }

        #endregion Constructeur

        #region M�thodes

        #region Worksheet Add/Get stuff

        /// <summary>
        /// D�finit la feuille courante (la feuille est cr��e si elle n'existe pas)
        /// </summary>
        /// <param name="worksheetName"></param>
        /// <returns></returns>
        public bool SetCurrentWorksheet(string worksheetName)
        {
            return SetCurrentWorksheet(worksheetName, 0, false);
        }

        /// <summary>
        /// D�finit la feuille courante (la feuille est cr��e si elle n'existe pas)
        /// </summary>
        /// <param name="worksheetName"></param>
        /// <param name="verifName"></param>
        /// <returns></returns>
        public bool SetCurrentWorksheet(string worksheetName, bool verifName)
        {
            return SetCurrentWorksheet(worksheetName, 0, verifName);
        }

        /// <summary>
        /// D�finit la feuille courante (la feuille est cr��e si elle n'existe pas)
        /// </summary>
        /// <param name="worksheetName"></param>
        /// <param name="premiereLigne"></param>
        /// <param name="verifName">Nom � v�rifier, si la feuille existe deja on cr�e une nouvelle feuille</param>
        /// <returns>Vrai la feuille exist�e d�ja, Faux sinon</returns>
        public bool SetCurrentWorksheet(string worksheetName, int premiereLigne, bool verifName)
        {
            XLSWorksheet __xlsWorksheet = null;
            string __worksheetName = StringHelper.StartString(worksheetName, 31, string.Empty);


            //Cas particulier : Aspose cr�e automatiquement une feuille � la cr�ation du classeur
            //Inutile d'en cr�er une nouvelle, on d�finit la feuille en cours
            if (_workSheets.Count == 0)
            {
                __xlsWorksheet = _currentSheet;
            }
            else
            {


                //La feuille existe deja
                if (_workSheets.ContainsKey(__worksheetName))
                {
                    //Le nom est � v�rifier, cr�ation d'une nouvelle feuille
                    if (verifName)
                    {
                        __worksheetName = StringHelper.StartString(worksheetName, 28, string.Empty);
                        __worksheetName = string.Concat(__worksheetName, _workSheets.Count);
                    }
                    else
                    {
                        _currentSheet = _workSheets[__worksheetName];
                        return true;
                    }
                }

                int __pos = this._classeurExcel.Worksheets.Add(Cells.SheetType.Worksheet);
                __xlsWorksheet = new XLSWorksheet(this._classeurExcel.Worksheets[__pos], premiereLigne);

            }

            __xlsWorksheet.SetPageSetup(this.Portrait);



            //Renommage de la feuille
            if (Validation.IsSet(__worksheetName))
            {
                __xlsWorksheet.Worksheet.Name = __worksheetName;
            }


            _workSheets.Add(__xlsWorksheet.Worksheet.Name, __xlsWorksheet);

            _currentSheet = __xlsWorksheet;

            return false;
        }

        /// <summary>
        ///  D�place une feuille du classeur en derni�re position
        /// </summary>
        /// <param name="workSheetName"></param>
        public void MoveSheetToEnd(string workSheetName)
        {
            Cells.Worksheet __graph_data_Worksheet = _classeurExcel.Worksheets[workSheetName];

            if (Validation.IsNotNull(__graph_data_Worksheet))
            {
                __graph_data_Worksheet.MoveTo(_classeurExcel.Worksheets.Count - 1);
            }
        }

        /// <summary>
        /// Evaluation des zones d'impression de toutes les feuilles excel
        /// </summary>
        public void UpdatePrintedArea()
        {

            foreach (XLSWorksheet __worksheet in _workSheets.Values)
            {
                __worksheet.UpdatePrintedArea();
            }
        }

        /// <summary>
        /// Mise � jour des entetes et des pieds de page de toutes les feuilles excel
        /// </summary>
        /// <param name="addPageNumber"></param>
        /// <param name="startFirstPageNumber"></param>
        public void UpdateWorksheet_Header_Footer(bool addPageNumber, bool startFirstPageNumber)
        {
            //Pase de num�rotation des pages
            if (!addPageNumber) return;

            List<XLSWorksheet> __worksheets = new List<XLSWorksheet>();
            __worksheets.AddRange(_workSheets.Values);

            //Tri des worksheet par index pour leur affecter un num�ro de page dans le footer
            //exemple graph_data est cr�� lorsque le premier graph est ajout�, il est ensuite mise � la fin
            // _workSheets �tant un Dictionaire il est impossible de trier !! je met donc tout �a dans une liste g�n�rique
            __worksheets.Sort(delegate(XLSWorksheet worksheet1, XLSWorksheet worksheet2)
                        { return worksheet1.Worksheet.Index.CompareTo(worksheet2.Worksheet.Index); });

            int __numPage = 1;
            bool __firstPage = true;
            foreach (XLSWorksheet __worksheet in __worksheets)
            {
                bool __add = true;
                if (__firstPage)
                {
                    __firstPage = false;
                    __add = startFirstPageNumber;
                }

                if (__add)
                {
                    __worksheet.Worksheet.PageSetup.FirstPageNumber = __numPage;
                    __worksheet.Worksheet.PageSetup.SetFooter(FooterPosition, FooterScript);
                }
                __numPage += __worksheet.Nb_Page;

            }
        }

        #endregion

        /// <summary>
        /// Load les propri�t�s customis�es utilis�es dans les rapports
        /// </summary>
        public void LoadCustomProperties()
        {
            #region Palette de couleur

            if (Validation.IsNotNull(this.Palette))
            {
                //Chargement de la Palette dans le classeur Excel 
                int __index = 0;
                foreach (Graph.Colors.Gcolor __colorStandard in this.Palette.StandardPalette)
                {

                    this._classeurExcel.ChangePalette(__colorStandard.Color, (int)XLSColor.IndexStandardPalette[__index]);
                    __index++;
                }

                __index = 0;
                foreach (Graph.Colors.Gcolor __colorStandard in this.Palette.FillingPalette)
                {
                    this._classeurExcel.ChangePalette(__colorStandard.Color, (int)XLSColor.IndexFillingPalette[__index]);
                    __index++;
                }

                __index = 0;
                foreach (Graph.Colors.Gcolor __colorStandard in this.Palette.LinePalette)
                {
                    this._classeurExcel.ChangePalette(__colorStandard.Color, (int)XLSColor.IndexLinePalette[__index]);
                    __index++;
                }
            }

            #endregion Palette de couleur
        }

        /// <summary>
        /// D�finit les informations de culture du workbook en cours
        /// </summary>
        /// <param name="cultureName"></param>
        /// <param name="dateFormat"></param>
        /// <param name="decimalChar"></param>
        /// <param name="numberGroupSeparator"></param>
        /// <param name="formatNombreNegatif"></param>
        public void SetCulture(string cultureName, string dateFormat, string decimalChar, string numberGroupSeparator, int formatNombreNegatif)
        {
            CultureInfo __culture = CultureInfo.CreateSpecificCulture(cultureName);

            if (Validation.IsSet(numberGroupSeparator))
                __culture.NumberFormat.NumberGroupSeparator = numberGroupSeparator;

            if (Validation.IsSet(decimalChar))
                __culture.NumberFormat.NumberDecimalSeparator = decimalChar;

            if (Validation.IsSet(formatNombreNegatif))
                __culture.NumberFormat.NumberNegativePattern = formatNombreNegatif;

            if (Validation.IsSet(dateFormat))
                __culture.DateTimeFormat.ShortDatePattern = dateFormat;

            this.Culture = System.Threading.Thread.CurrentThread.CurrentCulture = __culture;

        }

        public void ResetTitleToDefault()
        {
            this._titre = TITRE_DEFAUT;
        }

        #endregion M�thodes

        #region Propri�t�s

        #region Informations Courantes (Manipulation de la zone de travaille)

        /// <summary>
        /// Feuille courante du workbook
        /// </summary>
        public XLSWorksheet Feuille_Courante
        {
            get { return _currentSheet; }
        }
        /// <summary>
        /// Cellule courante dans la feuille courante
        /// </summary>
        public Cells.Cell Cellule_Courante
        {
            get { return _currentSheet.Cellule_Courant; }
        }

        /// <summary>
        /// Mise en page de la feuille courante
        /// </summary>
        public XLSLayout Layout
        {
            get { return _currentSheet.Layout; }
        }
        /// <summary>
        /// Index de la ligne en cours (base 0)
        /// </summary>
        public int Ligne_Courante
        {
            get { return _currentSheet.Layout.Ligne_Courante; }
            set { _currentSheet.Layout.Ligne_Courante = value; }
        }
        /// <summary>
        /// Index de la colonne en cours (base 0)
        /// </summary>
        public int Colonne_Courante
        {
            get { return _currentSheet.Layout.Colonne_Courante; }
            set { _currentSheet.Layout.Colonne_Courante = value; }
        }
        /// <summary>
        /// D�fini les propri�t�s (grand_min/min/valeur/max/grand_max) de la ligne en cours
        /// </summary>
        public XLSMinValueMax Ligne
        {
            get { return _currentSheet.Layout.Coordonnees.Ligne; }
        }

        /// <summary>
        /// D�fini les propri�t�s (grand_min/min/valeur/max/grand_max) de la colonne en cours
        /// </summary>
        public XLSMinValueMax Colonne
        {
            get { return _currentSheet.Layout.Coordonnees.Colonne; }
        }

        #endregion

        /// <summary>
        /// D�fini les styles excel attach� au workbook
        /// </summary>
        //public Cells.Styles Styles
        //{
        //    get { return _classeurExcel.Styles; }
        //}

        /// <summary>
        /// Classeur Excel Aspose
        /// </summary>
        public Cells.Workbook Workbook
        {
            get { return _classeurExcel; }
        }

        /// <summary>
        /// Dictionnaire contenant la liste des feuilles identifi�es par leur nom
        /// </summary>
        public Dictionary<string, XLSWorksheet> Worksheets
        {
            get { return _workSheets; }
        }

        /// <summary>
        /// Titre du workbook
        /// </summary>
        public string Titre
        {
            get { return _titre; }
            set { _titre = value; }
        }

        /// <summary>
        /// Version courte du titre du rapport (sans les arguments), utiliser parfois pour nommer les feuilles.
        /// </summary>
        public string Titre_Court
        {
            get { return _titre_court; }
            set { _titre_court = value; }
        }

        /// <summary>
        /// Vrai si le Titre du classeur est diff�rent du titre par d�faut
        /// </summary>
        public bool HasTitre
        {
            get { return !this._titre.Equals(TITRE_DEFAUT); }
        }
        /// <summary>
        /// Culture du workbook
        /// </summary>
        public CultureInfo Culture
        {
            get { return _culture; }
            set { _culture = value; }
        }
        /// <summary>
        /// Caract�re d�cimal 
        /// </summary>
        public string DecimalChar
        {
            get { return this.Culture.NumberFormat.NumberDecimalSeparator; }
        }
        /// <summary>
        /// Format du nombre n�gatif utilis�
        /// </summary>
        public int FormatNombreNegatif
        {
            get { return this.Culture.NumberFormat.NumberNegativePattern; }
        }

        /// <summary>
        /// Format du s�parateur de nombre (millier...)
        /// </summary>
        public string NumberGroupSeparator
        {
            get { return this.Culture.NumberFormat.NumberGroupSeparator; }
        }
        /// <summary>
        /// Format de date
        /// </summary>
        public string DateFormat
        {
            get
            {
                return this.Culture.DateTimeFormat.ShortDatePattern.Replace("yyyy", "yy");
            }
        }

        /// <summary>
        /// Orientation de la page en portrait (true) en paysage(false)
        /// Par d�faut en paysage
        /// </summary>
        public bool Portrait
        {
            get { return _portrait; }
            set { _portrait = value; }
        }

        /// <summary>
        /// Indique si la ligne en cours est pair ou impaire
        /// </summary>
        public bool LigneCouranteIsPaire
        {
            get { return this.Ligne_Courante % 2 == 0; }
        }

        /// <summary>
        /// Palette de couleur associ� au rapport
        /// </summary>
        public Palette Palette
        {
            get { return _palette; }
            set { _palette = value; }
        }

        #endregion Propri�t�s
    }
}