using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

using QXP.Framework.Data.Format;

namespace QXP.Framework.Excel.Helper
{
    /// <summary>
    /// Helper XLSFormatHelper
    /// </summary>
    /// <author>cueffl</author>
    /// <date>15/05/2009 11:48:44</date>    
    public class XLSFormatHelper
    {
        #region Membres

        #endregion Membres

        #region Constantes
        
        /// <summary>
		/// S�parateur des d�cimaux propres � Excel (en d�finissant le point Excel l'interpretera comme s�parateur des d�cimaux
        /// et le remplacera par celui propre au param�tre d'Excel (comme les param�tres linguistiques))
		/// </summary>
		internal const string SEPARATEUR_DECIMAL		= ".";
		
        /// <summary>
		/// S�parateur des milliers propres � Excel (en d�finissant la virgule Excel l'interpretera comme s�parateur des milliers
        /// et le remplacera par celui propre au param�tre d'Excel (comme les param�tres linguistiques))
		/// </summary>
        internal const string SEPARATEUR_MILLIER	    = ",";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Constructeur static XLSFormatHelper
        /// </summary>
        static XLSFormatHelper()
        {
        }

        #endregion Constructeur

        #region M�thodes

	    /// <summary>
		/// Retourne le  "format personnalis�" Excel de tous les types de donn�es g�r�s
        /// � partir d'un QXP_Format
		/// (ex : dd/mm/yy pour les dates)
		/// </summary>
		/// <param name="format">QXP_Format � utiliser pour g�n�rer le Format Excel</param>
		/// <returns>Le custom format Excel</returns>
        public static string Get_XLS_Custom_Format(QXP_Format format)
        {

            //Un format personnalis� est d�fini
            if (Validation.IsSet(format.Custom_Format_String))
            {
                return Get_XLS_Custom_Format_From_Custom_String_Format(format);
                
            }
            else
            {
                //Le format est un nombre (pourcentage, devise, nombre..)
                if (format is QXP_Format.QXP_Format_Number)
                {
                    //Ici on ne peut pas utiliser le s�parateur fourni par l'QXP_Format � cause des contraintes Excel

                    string __customFormatPositif = string.Concat("#", SEPARATEUR_MILLIER, "##0");

                    if (format.Number_Nb_Decimal.HasValue && Validation.IsSet(format.Number_Nb_Decimal.Value))
                    {
                        //Format d�fini en fonction du nombre de d�cimal
                        for (int __i = 0; __i < format.Number_Nb_Decimal; __i++)
                        {
                            if (__i == 0)
                                __customFormatPositif = string.Concat(__customFormatPositif, SEPARATEUR_DECIMAL, "0");
                            else
                                __customFormatPositif = string.Concat(__customFormatPositif, "0");
                        }
                    }

                    string __customFormatNegatif = __customFormatPositif;

                    //Format d�fini en fonction du format des nombres n�gatifs (se base sur le format d�fini par .Net)
                    switch (format.Number_Format_Negatif)
                    {
                        case 0:
                            __customFormatNegatif = string.Concat("(", __customFormatNegatif, ")");
                            break;
                        case 1:
                            __customFormatNegatif = string.Concat("-", __customFormatNegatif);
                            break;
                        case 2:
                            __customFormatNegatif = string.Concat("- ", __customFormatNegatif);
                            break;
                        case 3:
                            __customFormatNegatif = string.Concat(__customFormatNegatif, "-");
                            break;
                        case 4:
                            __customFormatNegatif = string.Concat(__customFormatNegatif, " -");
                            break;
                    }

                    //Format de type pourcentage
                    if (format.Is_Percent)
                    {
                        __customFormatPositif = string.Concat(__customFormatPositif, "%");
                        __customFormatNegatif = string.Concat(__customFormatNegatif, "%");
                    }

                    return string.Concat(__customFormatPositif, ";", __customFormatNegatif);
                }
                else if (format is QXP_Format.QXP_Format_DateTime)
                {
                    string __dateFormat = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;

                    if (format.Is_DateTime)
                        __dateFormat = string.Concat(__dateFormat, " h:mm");
                    return __dateFormat;
                }
                else
                    return null;
            }

        }

        /// <summary>
        /// Retourne le XLS_Custom_Format � partir d'un Custom_String_Format d�finit dans l'QXP_Format pass� en param�tre
        /// </summary>
        /// <param name="format">QXP_Format</param>
        /// <returns>Le custom format Excel</returns>
        private static string Get_XLS_Custom_Format_From_Custom_String_Format(QXP_Format format)
        {
            if (format is QXP_Format.QXP_Format_Number)
            {
                //rien pour le moment
                return format.Custom_Format_String;
            }
            else if (format is QXP_Format.QXP_Format_DateTime)
            {
                string xls_format = format.Custom_Format_String;

                //Gestion des mois
                xls_format = xls_format.Replace("M", "m");

                //Gestion des heures
                if(xls_format.Contains("h"))
                {
                    //Heure de 1 � 12 
                    xls_format = string.Concat(xls_format, " AM/PM");
                }

                return xls_format;
            }

            return format.Custom_Format_String;
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
