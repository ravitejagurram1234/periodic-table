using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using Cells = Aspose.Cells;
using QXPFkDataOracle = QXP.Framework.Data.Oracle;
using QXP.Framework.Data;
using QXP.Framework.Data.Format;

namespace QXP.Framework.Excel.Helper
{
	/// <summary>
	/// Helper utilis� pour la manipulation de document/format excel
	/// </summary>
	public class XLSHelper
	{
        #region Membres

        private static Hashtable _assocColorsXLSNET			= new Hashtable();

        #endregion Membres

        #region Constantes

        private const int defaultNbDecimal					= 2;

		#region types
			private const string type_int			="int";
			private const string type_int16			="int16";
			private const string type_int32			="int32";
			private const string type_currency		="currency";
			private const string type_decimal		="decimal";
			private const string type_number		="number";
			private const string type_double		="double";
			private const string type_pourcentage	="pourcentage";
			private const string type_datetime		="datetime";					
			private const string type_date			="date";
			private const string type_object		="object";
			private const string type_string		="string";
		#endregion types
		#region alignements
			const string alignement_left			= "left";
            const string alignement_center			= "center";
            const string alignement_right			= "right";
		#endregion alignements

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static permettant d'initialer les couleurs d'Excel
		/// </summary>
		static XLSHelper()
		{
			//Association des couleurs .Net au couleur Excel
            _assocColorsXLSNET.Add(XLSColor.EnumXLSColor.CustomizePurple, Color.FromArgb(120, 36, 113)); 
            _assocColorsXLSNET.Add(XLSColor.EnumXLSColor.CustomizeRed,Color.FromArgb(230,0,40)); 
            _assocColorsXLSNET.Add(XLSColor.EnumXLSColor.CustomizeOrange, Color.FromArgb(244,121,32)); 
            _assocColorsXLSNET.Add(XLSColor.EnumXLSColor.CustomizeGray, Color.FromArgb(230,224,230)); 
            _assocColorsXLSNET.Add(XLSColor.EnumXLSColor.CustomizeSaumon, Color.FromArgb(255,221,195));
		}

		public XLSHelper()
		{

		}
		
		#endregion Constructeur

		#region M�thodes

        #region Nouvelles m�thodes avec utilisation des QXP_Value

        /// <summary>
        /// Ajout du contenu � la cellule
        /// </summary>
        /// <param name="cell">Cellule Aspose</param>
        /// <param name="qxp_value">Valeur � ajouter</param>
        /// <param name="alignement">Aligmement horizontal de la cellulle</param>
        /// <param name="backgroundColor">Couleur de fond</param>
        /// <param name="fontColor">Couleur de la font de la valeur ins�r�e</param>
        /// <param name="fontSize">Taille de la font de la valeur</param>
        /// <param name="bold">Font gras ou non</param>
        /// <param name="isItalic">Font italique on non</param>
        public static void AddContent(Cells.Cell cell, IQXP_Value qxp_value, string alignement, Color backgroundColor, Color fontColor, short fontSize, bool bold, bool isItalic)
        {

            Set_Cell_Style(cell, qxp_value.Format, backgroundColor, isItalic, fontColor, alignement, fontSize, bold);            

            if (qxp_value.Type == typeof(string))
            {                
                string __value = Conversion.ToString(qxp_value.Value).Replace("\r\n", "\n");
                cell.PutValue(__value);
            }
            else if(qxp_value.Format.Is_Percent)
            {
                //Car la valeur re�ue est d�j� en pourcentage, il faut diviser cette valeur par 100 pour r�tablir la donn�e originale..
                decimal __value = (decimal)qxp_value.Value/100m;
                cell.PutValue(__value);
            }
            else
            {
                cell.PutValue(qxp_value.Value);
            }

        }

        /// <summary>
        /// D�finit le style de la cellule
        /// </summary>        
        /// <param name="cell">Cellule Aspose</param>
        /// <param name="format">QXP_Format associ�</param>
        /// <param name="backgroundColor">Couleur de fond</param>
		/// <param name="isItalic"></param>
        /// <param name="fontColor">Couleur de la font de la valeur ins�r�e</param>
        /// <param name="alignement">Aligmement horizontal de la cellulle</param>
        /// <param name="fontSize">Taille de la font de la valeur</param>
        /// <param name="bold">Font gras ou non</param>
        private static void Set_Cell_Style(Aspose.Cells.Cell cell, QXP_Format format, Color backgroundColor, bool isItalic, Color fontColor, string alignement, short fontSize, bool bold)
        {
            Cells.Style __style = cell.GetStyle();

            //D�finition du pattern de la cellule
            __style.Pattern = Cells.BackgroundType.Solid;

            //Background color de la cellule
            __style.ForegroundColor = backgroundColor;

            //Italic ou non pour la police
            __style.Font.IsItalic = isItalic;

            //Couleur du texte
            __style.Font.Color = fontColor;

            //Alignement horizontal dans la cellule
            __style.HorizontalAlignment = GetHorizontalAlignment(alignement);

            //Alignement Vertical
            __style.VerticalAlignment = Cells.TextAlignmentType.Center;

            //Taille de la police
            __style.Font.Size = fontSize;

            //Poids de la police
            __style.Font.IsBold = bold;

            __style.Custom = XLSFormatHelper.Get_XLS_Custom_Format(format);

            cell.SetStyle(__style);
        }

        #endregion Nouvelles m�thodes avec utilisation des QXP_Value

        /// <summary>
        /// Ins�re des donn�es dans une cellule excel
        /// </summary>
        /// <param name="wb">Work Book d'aspose cell</param>
        /// <param name="cell">Cell d'aspose</param>
        /// <param name="value">valeur</param>
        /// <param name="text">texte de la valeur</param>
        /// <param name="type">type de la valeur</param>
        /// <param name="alignement">alignement de la vie</param>
        /// <param name="backgroundColor">couleur de fond</param>
        /// <param name="fontColor">couleur de la fonte</param>
        /// <param name="fontSize">taille de la fonte</param>
        /// <param name="bold">la fonte s'affiche t-elle en gras</param>
        /// <param name="isItalic">la fonte s'affiche t-elle en italique</param>
		/// <param name="showZero">faut-il afficher les valeurs 0</param>
        public static void AddContent(XLSWorkbook wb, Cells.Cell cell, QXPFkDataOracle.OraValue value, string text, string type, string alignement, Color backgroundColor, Color fontColor, short fontSize, bool bold, bool isItalic, bool showZero)
		{
			object		__value		= null;
            QXPFkDataOracle.OraObject __oraObject = null;
			//__type = type sauf dans le cas du type object ou __type est en faite �gal au subType de Object
			string __type = type;
			
			//Si le type est object il faut r�cup�rer le subType contenu dans l'OraObject
			if (type == type_object)
			{
                __oraObject = (QXPFkDataOracle.OraObject)value;
				switch(__oraObject.Type)
				{
					case QXPFkDataOracle.Enums.OraObjectValType.Val_Int:
						__type	= type_int;
						break;
                    case QXPFkDataOracle.Enums.OraObjectValType.Val_Decimal:
						__type	= type_decimal;
						break;
                    case QXPFkDataOracle.Enums.OraObjectValType.Val_Currency:
						__type	= type_currency;
						break;
                    case QXPFkDataOracle.Enums.OraObjectValType.Val_Pourcentage:
						__type	= type_pourcentage;
						break;
                    case QXPFkDataOracle.Enums.OraObjectValType.Val_Date:
						__type	= type_date;
						break;
                    case QXPFkDataOracle.Enums.OraObjectValType.Val_DateTime:
						__type	= type_datetime;
						break;
                    case QXPFkDataOracle.Enums.OraObjectValType.Val_String:
					default:
						__type	= type_string;
						break;
				}				
			}
			else
			{
				__type = type;
			}

			switch (__type)
            {
				case type_int:
				case type_int16:
				case type_int32:
				case type_currency:
				case type_decimal:
				case type_number:
				case type_double:
				case type_pourcentage:
				{
					if (Validation.IsNotNull(__oraObject))
					{
						__value = __oraObject.Decimal;
					}
					else
					{
						__value = (Decimal)value;
					}
					break;
				}

				case type_datetime:					
				case type_date:
				{
					if (Validation.IsNotNull(__oraObject))
					{
						__value = __oraObject.DateTime;
					}
					else
					{
						__value = (DateTime)value;
					}
					break;
					break;
				}
				case type_string:					
				default:
					if (Validation.IsNotNull(__oraObject))
					{
						__value = __oraObject.String;
					}
					else
					{
						__value = (String)value;
					}
					break;
            }			
			
			AddContent(wb, cell, __value, text, __type, alignement, backgroundColor, fontColor, fontSize, bold, isItalic, showZero);
		}
        
        /// <summary>
        /// Ins�re des donn�es (de type string) dans une cellule excel
        /// </summary>
        /// <param name="wb">Work Book d'aspose cell</param>
        /// <param name="cell">Cell d'aspose</param>
        /// <param name="value">valeur</param>
        /// <param name="alignement">alignement de la vie</param>
        /// <param name="backgroundColor">couleur de fond</param>
        /// <param name="fontColor">couleur de la fonte</param>
        /// <param name="fontSize">taille de la fonte</param>
        /// <param name="bold">la fonte s'affiche t-elle en gras</param>
        /// <param name="isItalic">la fonte s'affiche t-elle en italique</param>
		/// <param name="showZero">faut-il afficher les valeurs 0</param>
		public static void AddContent(XLSWorkbook wb, Cells.Cell cell, string value, string alignement, Color backgroundColor, Color fontColor, short fontSize, bool bold, bool isItalic, bool showZero)
		{
			AddContent(wb, cell, value, string.Empty, "string", alignement, backgroundColor, fontColor, fontSize, bold, isItalic, showZero);
		}
		
        /// <summary>
        /// Ins�re des donn�es dans une cellule excel
        /// </summary>
        /// <param name="wb">Work Book d'aspose cell</param>
        /// <param name="cell">Cell d'aspose</param>
        /// <param name="value">valeur</param>
        /// <param name="text">texte de la valeur</param>
        /// <param name="type">type de la valeur</param>
        /// <param name="alignement">alignement de la vie</param>
        /// <param name="backgroundColor">couleur de fond</param>
        /// <param name="fontColor">couleur de la fonte</param>
        /// <param name="fontSize">taille de la fonte</param>
        /// <param name="bold">la fonte s'affiche t-elle en gras</param>
        /// <param name="isItalic">la fonte s'affiche t-elle en italique</param>
		/// <param name="nbDecimal">nombre de d�cimale affich�e</param>
		/// <param name="showZero">faut-il afficher les valeurs 0</param>
		static void AddContent(XLSWorkbook wb, Cells.Cell cell, object value, string text, string type, string alignement, Color backgroundColor, Color fontColor, short fontSize, bool bold, bool isItalic, bool showZero)
		{

		    if (type==type_string && Validation.IsNotNull(text) && text.IndexOf("\r\n") != -1)
            {
				value = text.Replace("\r\n", "\n");
            }

			int nbDecimal; 

            Cells.Style __style = cell.GetStyle();

			//D�finition du pattern de la cellule
			__style.Pattern				= Cells.BackgroundType.Solid;

			//Background color de la cellule
			__style.ForegroundColor		= backgroundColor;

			//Italic ou non pour la police
			__style.Font.IsItalic		= isItalic;

			//Couleur du texte
			__style.Font.Color			= fontColor;

            //Alignement horizontal dans la cellule
            __style.HorizontalAlignment  = GetHorizontalAlignment(alignement);

			//Alignement Vertical
            __style.VerticalAlignment	= Cells.TextAlignmentType.Center;

			//Taille de la police
			__style.Font.Size			= fontSize;

			//Poids de la police
			__style.Font.IsBold			= bold;

			__style.Number				= GetType(type);

            

            if(Validation.IsSet(text))
            {
            	//Si le texte contient le caract�re d�cimal
            	if (text.Contains(wb.DecimalChar))
            	{
					switch (type)
					{
						//Cas particulier du pourcentage ou l'ont elimine le text ' %' � la fin !
						case type_pourcentage:
							//Cette mani�re de faire et simple car ce type de valeur est toujours compl�ter par ' %' � la fin (cf XLSLigneBusiness.AddValues et FormatHandler de ColonneDef dans le cas d'un pourcentage)
							//si ce n'est plus le cas il faudrait v�rifier que le signe % est pr�sent � la fin du texte
							nbDecimal = text.Substring(text.LastIndexOf(wb.DecimalChar) + 1).Length - 2;
							break;
						//Cas standard !
						default:
							nbDecimal = text.Substring(text.LastIndexOf(wb.DecimalChar) + 1).Length;
							break;
					}
				}
            	else
            	{
            		//Sinon le nb de decimal est fix� � 0
            		nbDecimal = 0;
				}
			}
			else
            {
                //Si pas de nbDecimal, on prend celui par d�faut
				nbDecimal = defaultNbDecimal;
            }
			

			string	__value     = null;
		    
            __style.Custom = GetCustomFormat(type, nbDecimal, wb);

            cell.SetStyle(__style);

	        switch (type)
            {
				case type_int:
				case type_int16:
				case type_int32:
				case type_currency:
				case type_decimal:
				case type_number:
				case type_double:
				{
					__value = GetStringValue(Conversion.ToDecimal(value), false, showZero);
					cell.PutValue(__value, true);
					break;
				}
				case type_pourcentage:
				{
					__value = GetStringValue(Conversion.ToDecimal(value), true, showZero);					
					cell.PutValue(__value, true);
					break;
				}

				case type_datetime:					
				case type_date:
				{
					if(Validation.IsSet(value))
						cell.PutValue(value);
					else
						cell.PutValue(string.Empty);
					break;
				}
				case type_string:					
				default:
                    cell.PutValue(value.ToString());
					break;
            }
            
		}

        
        #region Format (� exporter dans le XLSFormatHelper plus tard si n�cessaire)

        /// <summary>
		/// Retourne le  "format personnalis�" Excel de tous les types de donn�es g�r�s
		/// (ex : dd/mm/YY pour les dates)
		/// </summary>
		/// <param name="type">Type de donn�e pour lequel on souhaite r�cup�rer le format</param>
		/// <param name="nbDecimal">Nombre de d�cimal � utiliser si les donn�es en abcisses sont des nombres</param>
		/// <param name="wb">WorkBook Excel</param>
		/// <returns>Le custom format Excel</returns>
        public static string    GetCustomFormat(string type, int nbDecimal, XLSWorkbook wb)
        {
	        switch (type)
            {
				case type_int:
				case type_int16:
				case type_int32:
				case type_currency:
				case type_decimal:
				case type_number:
				case type_double:
				{
					return GetNumberCustomFormat(nbDecimal, wb.FormatNombreNegatif, false);
					break;
				}
                case type_pourcentage:
				{
					return GetNumberCustomFormat(nbDecimal, wb.FormatNombreNegatif, true);
					break;
				}
				case type_datetime:					
				case type_date:
				{
                    string	__dateFormat = wb.DateFormat;
					
                    if(type.Equals(type_datetime))
						__dateFormat = string.Concat(__dateFormat, " h:mm");

				    return __dateFormat;

				}
				default:
                    return null;
                    break;
            }

        }

	    /// <summary>
		/// Retourne le  "format personnalis�" Excel des nombres (decimal, double, pourcentage...)
		/// </summary>
		/// <param name="nbDecimal">nombre de d�cimale</param>
		/// <param name="formatNombreNegatif">format des nombres n�gatifs</param>
		/// <param name="isPercent">est une valeur en pourcentage</param>
		/// <returns>Format d'afficher utilis� par Excel</returns>
		private static string	GetNumberCustomFormat(int nbDecimal, int formatNombreNegatif, bool isPercent)
		{
			string __customFormatPositif = string.Concat("#", XLSFormatHelper.SEPARATEUR_MILLIER ,"##0");

			for (int __i = 0; __i < nbDecimal; __i++)
			{
					if (__i == 0)
						__customFormatPositif = string.Concat(__customFormatPositif, XLSFormatHelper.SEPARATEUR_DECIMAL, "0");
					else
						__customFormatPositif = string.Concat(__customFormatPositif, "0");
			}
	

			string __customFormatNegatif = __customFormatPositif;

			switch (formatNombreNegatif)
			{
				case 0:
					__customFormatNegatif = string.Concat("(", __customFormatNegatif, ")");
					break;
				case 1:
					__customFormatNegatif = string.Concat("-", __customFormatNegatif);
					break;
				case 2:
					__customFormatNegatif = string.Concat("- ", __customFormatNegatif);
					break;
				case 3:
					__customFormatNegatif = string.Concat(__customFormatNegatif, "-");
					break;
				case 4:
					__customFormatNegatif = string.Concat(__customFormatNegatif, " -");
					break;
			}

			if (isPercent)
			{
				__customFormatPositif = string.Concat(__customFormatPositif, "%");
				__customFormatNegatif = string.Concat(__customFormatNegatif, "%");
			}
			return string.Concat(__customFormatPositif, ";", __customFormatNegatif);
			
		}

		/// <summary>
		/// Retourne la valeur texte afficher dans Excel
		/// </summary>
		/// <param name="value">la valeur decimal</param>
		/// <param name="isPercent">est un pourcentage</param>
		/// <param name="showZero">faut-il afficher les valeurs z�ros</param>
		/// <returns>le texte de la valeur</returns>
		private static string	GetStringValue(decimal value, bool isPercent, bool showZero)
		{
			if (Validation.IsSet(value, false))
			{
				//La valeur r�cup�r� est d�j� le pourcentage
				//Ex : Si val = 0.21 -> val sera �gal � 0.0021 et lors du passage au format pourcentage
				//Excel convertira 0.0021 en 0.21%

				//Historiquement tous les rapports EOS fourni les donn�es de type pourcentage sous la forme : 100% = 100
				//et non 100% = 1 , de ce fait � cause du format excel (cf ci-dessus) il faut diviser par 100 la valeur.
				//En pratique il serait pr�f�rable de recevoir 0.25 au lieu de 25 pour 25%.

				if (isPercent)
					value /= 100m;

				return value.ToString();
			}
			else
			{
				//Correction: maintenant les donn�es null (decimal.minValue) n'affiche plus rien lorsque showZero est � true
				if (showZero && value == 0)
				{
					return "0";
				}
				else
				{
					return string.Empty;
				}
				
			}
				
		}

        /// <summary>
        /// Retourne le type Excel de la valeur
        /// </summary>
        /// <param name="type">Valeur du type de valeur Excel</param>
        public static int GetType(string type)
        {
            switch (type)
            {
                case type_int:
                case type_int16:
                case type_int32:
                    return 1;
                case type_currency:
                case type_decimal:
                case type_number:
                case type_double:
                    return 3;
                case type_pourcentage:
                    return 10;
				case type_date:
                    return 14;
                case type_datetime:
                    return 22;
				case type_string:
				default:
                    return 49;
            }
        }

        #endregion Format (� exporter dans le XLSFormatHelper plus tard si n�cessaire)
        
		/// <summary>
		/// Permet de d�placer la Colonne courante d'autant de colonne n�cessaires pour la largeur sp�cifi�
		/// </summary>
		/// <param name="wb">WorkBook Aspose</param>
		/// <param name="widthInPixel">Largeur en pixel</param>
		public static void MoveCurrentColToWidth(XLSWorkbook wb, int widthInPixel)
        {
			int __nbCol = GetNbColForWidth(wb, widthInPixel);
			wb.Colonne_Courante += (__nbCol - 1);
		}

		/// <summary>
		/// Permet de d�placer la ligne courante avec d'autant de ligne n�cessaires  pour la hauteur sp�cifi�
		/// </summary>
		/// <param name="wb">WorkBook Aspose</param>
		/// <param name="heightInPixel">hauteur en pixel</param>
		public static void MoveCurrentRowToHeight(XLSWorkbook wb, int heightInPixel)
        {
			int __nbRow = GetNbRowForHeight(wb, heightInPixel);
			wb.Ligne_Courante += (__nbRow - 1);
		}

		/// <summary>
		/// Retourne l'alignement Aspose d'un texte en fonction de l'alignement QXP
		/// </summary>
		/// <param name="alignement">l'alignement QXP (exemple left)</param>
		/// <returns>L'alignement Aspose</returns>
        public static Cells.TextAlignmentType   GetHorizontalAlignment(string alignement)
        {
            switch (alignement)
            {
                default:
                case alignement_left:
                    return Cells.TextAlignmentType.Left;
                case alignement_center:
                    return Cells.TextAlignmentType.Center;
                case alignement_right:
                    return Cells.TextAlignmentType.Right;
            }
        }

		/// <summary>
		/// Merge deux cellules
		/// </summary>
		/// <param name="cells">Liste des cellules</param>
		/// <param name="coord">Cordonn�es dans la feuille</param>
		/// <param name="colspan">Nombre de colonnes fusionn�es</param>
		public static void Merge(Cells.Cells cells, XLSCoordonnees coord, int colspan)
		{
			cells.Merge(coord.Ligne.Value, coord.Colonne.Value, 1, colspan);
		}

        #region Get Nombre Colonne / Ligne

		/// <summary>
		/// Permet de d�terminer le nombre de colonne qu'il faut pour obtenir la largeur sp�cifi�e (en pixel).
		/// </summary>
		/// <param name="wb">WorkBook Aspose</param>
		/// <param name="widthInPixel">largeur en pixel souhait�e</param>
		/// <returns>Nombre de colonnes pour obtenir la largeur souhait�e</returns>
		public static int		GetNbColForWidth(XLSWorkbook wb, int widthInPixel)
        {
			return GetNbColForWidth(wb, wb.Colonne_Courante, widthInPixel);
		}
		
        /// <summary>
		/// Permet de d�terminer le nombre de colonne qu'il faut pour obtenir la largeur sp�cifi�e (en pixel).
		/// </summary>
		/// <param name="wb">WorkBook Aspose</param>
		/// <param name="startColIndex">index de la colonne de d�but</param>
		/// <param name="widthInPixel">largeur en pixel souhait�e</param>
		/// <returns>Nombre de colonnes pour obtenir la largeur souhait�e</returns>
        public static int		GetNbColForWidth(XLSWorkbook wb, int startColIndex, int widthInPixel)
        {
			if(widthInPixel < 0) return 1;
			int		__totalColsWidth	= 0 ;
			int		__idxCol			= 0;

            while(__totalColsWidth < widthInPixel)
            {
				__totalColsWidth += wb.Feuille_Courante.Worksheet.Cells.GetColumnWidthPixel(startColIndex + __idxCol++);
			}
			
            //Si __idxCol == 0 alors cela sous entend que la colonne en cours est d�j� assez large !
			return __idxCol;			
		}

		/// <summary>
		/// Permet de d�terminer le nombre de ligne qu'il faut sauter pour obtenir la hauteur sp�cifi�e (en pixel).
		/// </summary>
		/// <param name="wb">WorkBook aspose</param>
		/// <param name="heightInPixel">Hauteur en pixel</param>
		/// <returns>Nombre de ligne pour obtenir la hauteur souhait�e</returns>
		public static int		GetNbRowForHeight(XLSWorkbook wb, int heightInPixel)
        {
			return GetNbRowForHeight(wb, wb.Ligne_Courante, heightInPixel);
		}

		/// <summary>
		/// Permet de d�terminer le nombre de ligne qu'il faut sauter pour obtenir la hauteur sp�cifi�e (en pixel).
		/// </summary>
		/// <param name="wb">WorkBook Aspose</param>
		/// <param name="startRowIndex">index de la ligne de d�but</param>
		/// <param name="HeightInPixel">hauteur en pixel souhait�e</param>
		/// <returns>Nombre de ligne pour obtenir la hauteur souhait�e</returns>
		public static int		GetNbRowForHeight(XLSWorkbook wb, int startRowIndex, int heightInPixel)
        {
			if(heightInPixel < 0) return 1;
			int		__totalRowsHeight	= 0;
			int		__idxRow			= 0;
		
            while(__totalRowsHeight < heightInPixel)
            {
				__totalRowsHeight += wb.Feuille_Courante.Worksheet.Cells.GetRowHeightPixel(startRowIndex + __idxRow++);
			}
			
            //Si __idxCol == 1 alors cela sous entend que la ligne en cours est d�j� assez haute !
			return __idxRow;			
		}

        #endregion Get Nombre Colonne / Ligne

        #region Color
        
        /// <summary>
		/// Retourne un objet Color correspondant � la couleur XLS  (normalement pr�sente dans la palette de couleur d'un classeur)
		/// </summary>
		/// <param name="xlsColor">code le la couleur</param>
		/// <returns>Une couleur</returns>
		public static Color GetColor(XLSColor.EnumXLSColor xlsColor)
		{
			if(_assocColorsXLSNET.ContainsKey(xlsColor))
				return (Color)_assocColorsXLSNET[xlsColor];
			else
				return Color.Black;

		}

		/// <summary>
		/// Couleur de la ligne en fonction du num�ro de la ligne
		/// </summary>
		/// <param name="wb">WorkBook Aspose</param>
		/// <returns>Une couleur</returns>
		public static Color GetColorRow(XLSWorkbook wb)
		{
			if(wb.LigneCouranteIsPaire)	
				return GetColor(XLSColor.EnumXLSColor.CustomizeGray);
			else
				return GetColor(XLSColor.EnumXLSColor.CustomizeSaumon);
        }

        #endregion Color

        #endregion M�thodes

        #region Propri�t�s
		/// <summary>
		/// Liste des couleurs personnalis�es
		/// </summary>
        public static Hashtable CustomColorsXLS
		{
			get { return XLSHelper._assocColorsXLSNET; }
		}

		#endregion Propri�t�s

	}
}
