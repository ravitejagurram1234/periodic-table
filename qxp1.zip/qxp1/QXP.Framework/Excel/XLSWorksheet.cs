using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;

//Aspose.Cells
using Cells				= Aspose.Cells;

namespace QXP.Framework.Excel
{
	/// <summary>
    /// D�finit un feuille excel QXP
	/// </summary>
	public class XLSWorksheet
	{
		#region Membres

        private XLSLayout								_layout;
        private Cells.Worksheet							_worksheet;
		private int										_nb_Page = 1;
		private List<XLSHeader>							_headers	= new List<XLSHeader>();
		
		/// <summary>
		/// C'est valeur ne sont pas prise au hasard elle ont �t� evaluer par rapport � une page A4 (21/29.7 en portrait)
		/// les param�tres pris en compte:
		/// - marge gauche (1cm)/droite (1cm)  haut(1.5cm+1.3cm(entete) / bas (1cm +0.5cm(footer))
		/// - 36 (points) 48 (pixels) 1,27( cm) valeurs donn�es par excel
		/// tous ces param�tres ont permis d'�valuer une valeur th�orique, qui a fallu adapter en fonction de divers essais ^^
		/// </summary>
		
		//C'est nouvelle valeurs sont plus pr�cise que les anciennes qui pouvait entrain�e des erreurs d'estimation du zoom
		static int A4_Largeur_Portrait			= 682;
		static int A4_Hauteur_Portrait			= 1059;

		static int A4_Largeur_Paysage			= 994;
		static int A4_Hauteur_Paysage			= 720;
		
		#endregion Membres

        #region Constantes

		private int DEFAULT_CELL_WIDTH;
		private const int MAX_WORKSHEET_PAGINATION_ROWS = 65535; /* en faite 65536 mais la pagination ajoute*/
		private const int MAX_WORKSHEET_PAGINATION_COLS = 229; /* en faite 230 mais la pagination ajoute*/
        private const decimal MIN_ZOOM = 0.1m; /* Valeur minimum du zoom permettant la prise en compte de la pagination avec un r�sultat lisible */

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de XLSWorksheet
        /// </summary>
        /// <param name="worksheet">Feuille Excel Aspose</param>
        public XLSWorksheet(Cells.Worksheet worksheet): this(worksheet, 0){}

        /// <summary>
        /// Cr�e une instance de XLSWorksheet
        /// </summary>
        /// <param name="premiereLigne">Index de la 1ere ligne utilis�e pour la g�n�ration</param>
		public XLSWorksheet(Cells.Worksheet worksheet, int premiereLigne)
		{
        	DEFAULT_CELL_WIDTH	= worksheet.Cells.GetColumnWidthPixel(0); //plut�t que de fix� une valeur dans le code ont prend la largeur de la premiere colonne du graphique
			_worksheet			= worksheet;
			_layout				= new XLSLayout(worksheet, worksheet.Cells.MaxDataRow + premiereLigne);
		}
		
		#endregion Constructeur
		
		#region M�thodes

        /// <summary>
        /// D�finit la largeur de la colonne en cours
        /// </summary>
        /// <param name="largeur">Taille de la colonne en pixel</param>
		public void	Set_Largeur_Colonne_Courante(int largeur)
		{
            _worksheet.Cells.SetColumnWidthPixel(this.Layout.Colonne_Courante, largeur);
		}
		
        /// <summary>
        /// D�finit la hauteur de la ligne en cours
        /// </summary>
        /// <param name="hauteur">Taille de la hauteur en pixel</param>
		public void	Set_Hauteur_Ligne_Courante(int hauteur)
		{
			_worksheet.Cells.SetRowHeightPixel(this.Layout.Ligne_Courante, hauteur);
		}
		
        /// <summary>
        /// Hauteur auto sur la ligne en cours (en fonction du contenu)
        /// </summary>
		public void	Hauteur_Auto_Ligne_Courante()
		{
			this.Hauteur_Auto_Ligne(this.Layout.Ligne_Courante);
		}
        
        /// <summary>
        /// Hauteur auto sur la ligne (en fonction du contenu)
        /// <param name="ligne">Num�ro de la ligne</param>
        /// </summary>
		public void	Hauteur_Auto_Ligne(int ligne)
		{
			_worksheet.AutoFitRow(ligne);
		}        
        
        /// <summary>
        /// Largeur auto sur la colonne en cours (en fonction du contenu)
        /// </summary>
		public void	Largeur_Auto_Colonne_Courante()
		{
			this.Largeur_Auto_Colonne(this.Layout.Colonne_Courante);
		}

        /// <summary>
        /// Largeur auto sur la colonne (en fonction du contenu)
        /// <param name="colonne">Num�ro de la colonne</param>
        /// </summary>
		public void	Largeur_Auto_Colonne(int colonne)
		{
			_worksheet.AutoFitColumn(colonne);
		}

		/// <summary>
		/// Permet de trouver la prochaine ligne � la distance (en pixel indiqu�).
		/// </summary>
		/// <param name="pixelHeight">Nombre de pixel</param>
		/// <returns>Num�ro de ligne</returns>
		public int GoToNextRowWithPixel(int pixelHeight)
        {
			int __rowidx		= this.Layout.Ligne_Courante;
			int __totalHeight	= 0;
			
            while(__totalHeight < pixelHeight)
            {
				__totalHeight += _worksheet.Cells.GetRowHeightPixel(__rowidx++);
			}

			return __rowidx;
		}
		
        /// <summary>
        /// D�finit la zone d'impression de la feuille (PrintArea) en r�cup�rant une r�f�rence sur la cellule en haut � gauche et tout en bas � droite
        /// </summary>
		public void			UpdatePrintedArea()
		{

			#region Largeur
			//Calcul de la largeur total entre colonne min et max

			int		__newWidth          = 0;
			int		__min_Col			= _layout.Coordonnees.Colonne.Grand_Min;
			int		__max_Col			= _layout.Coordonnees.Colonne.Grand_Max;
			int		__nb_Col_Theorique  = (__max_Col - __min_Col) + 1; //�tant sur une base 0 si max = 12 et min = 1 => 12-1 = 11 mais il y a bien 12 colonnes (1,2,3...,10,11,12)
			int		__nb_Col_Pratique   = 0;
			int		__nb_ColData		= (_worksheet.Cells.MaxDataColumn - __min_Col) + 1;

			//Largeur en pixel des _layout.CoordonneesCourante.Colonne.Max cellules
			int __widthCurrentCells = DEFAULT_CELL_WIDTH * __nb_Col_Theorique;
            
			int __pos = 0;
			__newWidth = this._worksheet.Cells.GetColumnWidthPixel(__min_Col + __pos);
			while(__newWidth < __widthCurrentCells)
			{
				__pos++;
				__newWidth += this._worksheet.Cells.GetColumnWidthPixel(__min_Col + __pos);
			}

			__nb_Col_Pratique = __pos + 1; //Toujours ce pb de base 0 !
			__nb_Col_Pratique	= Math.Max(__nb_ColData, __nb_Col_Pratique);

			int __largeur = 0;

			for(int __i = 0; __i < __nb_Col_Pratique; __i++)
			{
				__largeur += this._worksheet.Cells.GetColumnWidthPixel(__min_Col + __i);
			}

			__max_Col = (__min_Col + __nb_Col_Pratique) - 1; //�tant en base 0 !!
			
			#endregion

			#region Zoom

        	//Calcul de ratio � appliquer en largeur pour tenir sur la page
        	int __largeur_100p;
        	int __hauteur_100p;

        	if (_worksheet.PageSetup.Orientation == Aspose.Cells.PageOrientationType.Landscape)
        	{
        		__largeur_100p = A4_Largeur_Paysage;
        		__hauteur_100p = A4_Hauteur_Paysage;
        	}
        	else
        	{
        		__largeur_100p = A4_Largeur_Portrait;
        		__hauteur_100p = A4_Hauteur_Portrait;
        	}

        	//Zoom � appliquer sur l'impression excel
			decimal __z		= ((decimal) ((decimal) __largeur_100p/(decimal) __largeur));

            // Si __z est inf�rieur � MIN_ZOOM on ne fait pas de pagination, sinon le r�sultat est illisible...
            // PI la valeur minimum accept�e par Excel pour le zoom est de 0.1, en dessous la g�n�ration plante
            if (__z > MIN_ZOOM)
            {
                //si la zone n�cessaire est plus petit que la zone dispo pas d'agrandissement
                if (__z > 1) __z = 1;

                int __zoom = (int)(__z * 100m);

                _worksheet.PageSetup.Zoom = __zoom;

            #endregion zoom

                #region Hauteur Stuff

                #region Repetitions des entetes de tableau
                int __hauteur_entete_tableau = 0;
                string __minHeaderName = string.Empty;
                string __maxHeaderName = string.Empty;
                // Pour l'instant nous ne traitons que le cas ou il y a un seul tableau sur la feuille
                if (_headers.Count == 1)
                {
                    XLSHeader __header = _headers[0];
                    if (__header.Type == XLSHeaderType.Tableau)
                    {
                        for (int __ligne = __header.Ligne.Min; __ligne <= __header.Ligne.Max; __ligne++)
                        {
                            __hauteur_entete_tableau += this._worksheet.Cells.GetRowHeightPixel(__ligne);
                        }
                        __minHeaderName = Cells.CellsHelper.RowIndexToName(__header.Ligne.Min);
                        __maxHeaderName = Cells.CellsHelper.RowIndexToName(__header.Ligne.Max);
                    }
                }

                #endregion Repetitions des entetes de tableau

                int __hauteur_Zone_Allowed = (int)(__hauteur_100p / __z);
                int __min_Ligne = _layout.Coordonnees.Ligne.Grand_Min;
                int __max_Ligne = _layout.Coordonnees.Ligne.Grand_Max;

                int __hauteur_Zones = 0;


                int __last_unlocked = int.MinValue;

                for (int __i = __min_Ligne; __i <= __max_Ligne; __i++)
                {
                    int __hauteur_Ligne = this._worksheet.Cells.GetRowHeightPixel(__i);

                    bool __locked = _layout.Coordonnees.Ligne.Locked_Values[__i];

                    //La ligne en cours est verrouill�e on ne peux pas faire de saute de page !!
                    if (!__locked)
                    {
                        __last_unlocked = __i;
                    }

                    if (__hauteur_Zones + __hauteur_Ligne > __hauteur_Zone_Allowed)
                    {
                        /* S'il y � d�j� 1024 (limitation de Aspose.Cells) page break il ne faut pas ajouter le saut de page suivant sinon �a plante */
                        if (_nb_Page == 1024)
                        {
                            //on efface tous les sauts de page existant puisque qu'on ne pourra pas les avoirs tous
                            _worksheet.HorizontalPageBreaks.Clear();
                            //ont arr�t la boucle de pagination
                            break;

                        }
                        //Si la ligne est locked et que nous avons trouv� une ligne non locked au dessus on l'utilise
                        //sinon on ajoute le saute de page quand m�me
                        if (__locked && Validation.IsSet(__last_unlocked))
                        {
                            __i = __last_unlocked;
                            _worksheet.HorizontalPageBreaks.Add(__last_unlocked, __max_Col);
                            __hauteur_Zones = __hauteur_entete_tableau + this._worksheet.Cells.GetRowHeightPixel(__last_unlocked);
                            __last_unlocked = int.MinValue;
                        }
                        else
                        {
                            _worksheet.HorizontalPageBreaks.Add(__i, __max_Col);
                            __hauteur_Zones = __hauteur_entete_tableau + __hauteur_Ligne;
                        }
                        _nb_Page++;
                    }
                    else
                    {
                        __hauteur_Zones += __hauteur_Ligne;
                    }
                }


                #endregion Hauteur Stuff

                string __minCellName = Cells.CellsHelper.CellIndexToName(__min_Ligne, __min_Col);
                string __maxCellName = Cells.CellsHelper.CellIndexToName(Math.Min(__max_Ligne, MAX_WORKSHEET_PAGINATION_ROWS), Math.Min(__max_Col, MAX_WORKSHEET_PAGINATION_COLS));

                _worksheet.PageSetup.PrintArea = string.Format("{0}:{1}", __minCellName, __maxCellName);

                //on ajoute les r�p�titions d'ent�te
                if (Validation.IsSet(__minHeaderName) && Validation.IsSet(__maxHeaderName))
                {
                    _worksheet.PageSetup.PrintTitleRows = string.Format("{0}:{1}", __minHeaderName, __maxHeaderName);
                }
            }
		}

		//private string GetZoneImpression(int min_Ligne, int max_Ligne, int min_Col, int max_Col)
		//{
		//    string __minCellName = Cells.CellsHelper.CellIndexToName(min_Ligne, min_Col);
		//    string __maxCellName = Cells.CellsHelper.CellIndexToName(max_Ligne, max_Col);

		//    return string.Format("{0}:{1}", __minCellName, __maxCellName);
		//}

		/// <summary>
        /// Permet de configurer la mise en page d'impression de la feuille
        /// </summary>
        /// <param name="portrait">Portrait ou non</param>
		public void			SetPageSetup(bool portrait)
        {
			_worksheet.PageSetup.Orientation			= portrait?Cells.PageOrientationType.Portrait:Cells.PageOrientationType.Landscape;
			//_worksheet.PageSetup.CenterHorizontally	= true;
			_worksheet.PageSetup.TopMargin			= 1.5;
			_worksheet.PageSetup.BottomMargin		= 1;
			_worksheet.PageSetup.FooterMargin		= .5;
			_worksheet.PageSetup.LeftMargin			= 1.0;
			_worksheet.PageSetup.RightMargin		= 1.0;

            ////EN TEST: Permet d'afficher la zone d'impression sur 1 seul page quelque soit le contenu
			//_worksheet.PageSetup.FitToPagesTall		= 1;
			//_worksheet.PageSetup.FitToPagesWide		= 1;
		}


        /// <summary>
        /// Permet de d�finir les largeurs des certaines colonnes � partir des largeurs en pixels contenus dans la liste
        /// </summary>
        /// <param name="listeLargeurColonnes">Liste des largeurs en pixel de chaque colonne</param>
        public void Set_Largeur_Colonnes(Dictionary<int, int> listeLargeurColonnes)
        {
            foreach (KeyValuePair<int, int> __kvp in listeLargeurColonnes)
            {
                    this.Worksheet.Cells.SetColumnWidthPixel(__kvp.Key, __kvp.Value);
            }
        }

		#endregion M�thodes

		#region Propri�t�s

        /// <summary>
        /// Liste des cellules Aspose contenues dans la feuille
        /// </summary>
		public Cells.Cells								Cellules
		{
			get{return _worksheet.Cells;}
		}
		
        /// <summary>
        /// Layout de la feuille
        /// </summary>
		public XLSLayout							    Layout
		{
			get{return _layout;}
		}
        
        /// <summary>
        /// Cellule Aspose en cours
        /// </summary>
		public Cells.Cell								Cellule_Courant
		{
			get{return _worksheet.Cells[this.Layout.Ligne_Courante, this.Layout.Colonne_Courante];}
		}
		
        /// <summary>
        /// Feuille Excel Aspose
        /// </summary>
		public Cells.Worksheet							Worksheet
		{
			get{return _worksheet;}
		}
		
        /// <summary>
        /// Largeur en pixel de la ligne courante
        /// </summary>
		public int										Largeur_Colonne_Courante
		{
			get{return _worksheet.Cells.GetColumnWidthPixel(this.Layout.Colonne_Courante);}
		}
		
        /// <summary>
        /// Hauteur en pixel de la ligne courante
        /// </summary>
		public int										Hauteur_Ligne_Courante
		{
			get{return _worksheet.Cells.GetRowHeightPixel(this.Layout.Ligne_Courante);}
		}
		
		/// <summary>
		/// Nombre de page calculer en fonction de la zone d'impression
		/// </summary>
		public int										Nb_Page
		{
			get { return _nb_Page; }
		}

		/// <summary>
		/// Repr�sente la liste des zones d'ent�te utilis�es par les �l�ments (tableau/image/graphique etc..)
		/// </summary>
		public List<XLSHeader>							Headers
		{
			get { return _headers; }
		}
		#endregion Propri�t�s
    }
}