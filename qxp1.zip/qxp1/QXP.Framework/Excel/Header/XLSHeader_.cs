using System;
using System.Collections.Generic;

using Cells				= Aspose.Cells;

namespace QXP.Framework.Excel
{
	/// <summary>
	/// Caract�rise le type d'entete de l'�l�ment
	/// </summary>
	public enum XLSHeaderType
	{
		Inconnu,
		Tableau,
		Graphique,
		Texte,
		Image,
	}
}
