using System;
using System.Collections.Generic;

using Cells				= Aspose.Cells;

namespace QXP.Framework.Excel
{
	/// <summary>
	/// Caract�rise une coordonn�e X,Y d'ent�te d'�l�ments (Tableau/Image/Graphique etc) dans une feuille Excel
	/// Conserv� pour les lignes et colonnes les valeurs maximale et minimale utilis�es.
	/// </summary>
	public class XLSHeader
	{
        #region Membres

		private XLSMinValueMax	_ligne;
		private XLSMinValueMax	_colonne;
		private XLSHeaderType	_type		= XLSHeaderType.Inconnu;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

		public XLSHeader(int ligne, int colonne, XLSHeaderType type)
		{
			this._ligne			= new XLSMinValueMax(ligne);
			this._colonne		= new XLSMinValueMax(colonne);
			_type				= type;
		}

		public XLSHeader(XLSCoordonnees coordonnees, XLSHeaderType type): this(coordonnees.Ligne.Value, coordonnees.Colonne.Value, type)
		{
		}

		#endregion Constructeur

        #region M�thodes
		public void UpdateCoordonnee(XLSCoordonnees coordonnees)
		{
			_ligne.Value	= coordonnees.Ligne.Value;
			_colonne.Value	= coordonnees.Colonne.Value;
		}

		#endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Ligne de la coordonn�e
        /// </summary>
		public XLSMinValueMax	Ligne
        {
			get{return _ligne;}
		}
		
        /// <summary>
        /// Colonne de la coordonn�e
        /// </summary>
        public XLSMinValueMax	Colonne
        {
			get{return _colonne;}
		}

		/// <summary>
		/// Type d'entete, ceci permet des traitements sp�cifiques en fonction des ent�tes
		/// </summary>
		public XLSHeaderType	Type
		{
			get { return _type; }
		}
        #endregion Propri�t�s
	}
}
