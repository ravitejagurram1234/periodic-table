using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Graph.XLSCharts
{
	/// <summary>
    /// D�finit deux Range Values nomm�s cat�gories et valeurs, une range value est une selection de cellule excel.
    /// </summary>
    public class XLSRangeValues
	{
		#region Membres

		private string _dataSheetName;

        private string _categoryStartCell;

        private string _valuesStartCell;

        private string _categoryEndCell;

        private string _valuesEndCell;

		#endregion Membres

		#region Constructeur

		public XLSRangeValues(string dataSheetName) 
        {
            this._dataSheetName = dataSheetName;
        }

        #endregion Constructeur

        #region Propri�t�s

		#region Cat�gories

		public string CategoryStartCell
        {
            get { return _categoryStartCell; }
            set { _categoryStartCell = value; }
        }
        
		public string CategoryEndCell
        {
            get { return _categoryEndCell; }
            set { _categoryEndCell = value; }
        }

        public string CategoryRangeCells
        {
            get { return string.Concat(this._dataSheetName, "!", this._categoryStartCell, ":", this._categoryEndCell); }
		}

		#endregion Cat�gories

		#region Valeurs

		public string ValuesStartCell
        {
            get { return _valuesStartCell; }
            set { _valuesStartCell = value; }
        }

		public string ValuesEndCell
        {
            get { return _valuesEndCell; }
            set { _valuesEndCell = value; }
        }
        
		public string ValuesRangeCells
        {
            get { return string.Concat(this._dataSheetName, "!", this._valuesStartCell, ":", this._valuesEndCell); }
        }

		#endregion Valeurs

		#endregion Propri�t�s
    }
}
