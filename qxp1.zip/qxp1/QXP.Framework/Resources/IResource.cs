/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Resources
{
    /// <summary>
    /// Interface IResource
    /// </summary>
    /// <author>cueffl</author>
    /// <date>19/01/2011 11:47:58</date>    
    public interface IResource
    {
        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        ResourceInfo ResourceInfo
        {
            get;
        }

        #endregion Propri�t�s
    }
}
