using System;
using System.IO;

//using QXPApplication			    = QXP.Framework.Application;
//using QXPDiagnostic				= QXP.Framework.Diagnostic;

using QXPIO = QXP.Framework.IO;


namespace QXP.Framework.Resources
{
    public class ProxyRessource_Log
    {
        #region internal variables
        ProxyCommand _proxyCommand;
        StreamWriter _file;
        const string LogFolder = "Logs";
        const string LogFile_Pattern = "Ressource_{0}.log";
        const string Log_Pattern = "/*{0:dd/MM/yyyy HH:mm:ss,fff} - */ {1}";
        #endregion
        public ProxyRessource_Log(ProxyCommand proxyCommand)
        {
            _proxyCommand = proxyCommand;
        }
        public bool AcquireLock()
        {
            try
            {
                _file = new StreamWriter(this.FullFileName, true);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public ProxyCommand Command
        {
            get { return _proxyCommand; }
        }
        public void Close()
        {
            if (Validation.IsNotNull(_file))
            {
                _file.Flush();
                _file.Close();
            }
        }
        public void Log_Activity(string message, params object[] args)
        {
            _file.WriteLine(Log_Pattern, DateTime.Now, string.Format(message, args));
        }
        private string FullFileName
        {
            get
            {
                string __fullFileName = QXPIO.FileHelper.GetFileName(LogFolder, string.Format(LogFile_Pattern, _proxyCommand));
                return __fullFileName;
            }
        }
    }
    public class LockedLog_Exception : Exception
    {
        public LockedLog_Exception(string fullFileName) : base(string.Format("File lock exception: {0}", fullFileName)) { }
    }
    public enum ProxyCommand
    {
        All,
        Update,
        Insert,
        Remove,
    }
}
