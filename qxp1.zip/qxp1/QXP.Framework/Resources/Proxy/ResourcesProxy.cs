using System;
using System.Collections;
using System.Data;
using QXP.Framework.Proxy;
using Oracle.DataAccess.Client;
using QXPDataOracle = QXP.Framework.Data.Oracle;

namespace QXP.Framework.Resources
{
    /// <summary>
    /// Proxy ResourcesProxy : ResourcesProxy
    /// </summary>
    /// <author></author>
    /// <date></date>   
    public class ResourcesProxy : BaseProxy
    {
        #region Membres

        int _id_Langue;

        #endregion Membres

        #region Constantes

        private const string PACKAGE_PATTERN = "{0}.{0}_PK_RESSOURCE.";
		private const string IDMarkerPattern = "[id:{0}]";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ResourcesProxy
        /// </summary>
        public ResourcesProxy()
        {
        }

        /// <summary>
        /// Cr�e une instance de ResourcesProxy
        /// </summary>
        public ResourcesProxy(string cultureCode)
        {
            _id_Langue = this.GetIDLangue(cultureCode);
        }

        /// <summary>
        /// Cr�e une instance de ResourcesProxy
        /// </summary>
        /// <param name="oraClient">Connexion Oracle</param>
        public ResourcesProxy(string cultureCode, QXPDataOracle.OraClient oraClient)
            : base(oraClient)
        {
        }

        /// <summary>
        /// Cr�e une instance de ResourcesProxy
        /// </summary>
        /// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
        public ResourcesProxy(string cultureCode, string dataBase)
            : base(dataBase)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #region Acc�s Base

        #region SELECT

        /// <summary>
        /// R�cup�ration des valeurs d'une langue
        /// </summary>
        /// <param name="cultureCode"></param>
        /// <returns></returns>
		public Hashtable GetResources(string cultureCode)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __culture_code = new QXPDataOracle.OraParameter("p_culture_code", cultureCode);
            string __sql = string.Concat(this.Package, "GetResources");
            Hashtable __resources = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __culture_code))
            {
                string __marker;
                string __value;
                while (__odr.Read())
                {
                    __marker = __odr["marker"];
                    __value = __odr["value"];
                    if (__resources.ContainsKey(__marker))
                    {
                        __resources[__marker] = __value;
                    }
                    else
                    {
                        __resources.Add(__marker, __value);
                    }
                }
            }

            return __resources;
        }

        /// <summary>
        /// R�cup�ration de l'identifiant d'une langue par son code
        /// </summary>
        /// <param name="codeLangue"></param>
        /// <returns></returns>
		private int GetIDLangue(string codeLangue)
        {
            QXPDataOracle.OraParameter __codeLangue = new QXPDataOracle.OraParameter("p_culture_code", codeLangue);
            string __sql = string.Concat(this.Package, "GetIdLangue");
            int __idLangue = int.MinValue;
            try
            {
                __idLangue = this.ExecuteScalar(CommandType.StoredProcedure, __sql, __codeLangue);
            }
            catch { }

            return __idLangue;
        }

        /// <summary>
        /// R�cup�ration de toute les Ressource sections
        /// </summary>
        /// <returns></returns>
		public Hashtable GetAllRS()
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            string __sql = string.Concat(this.Package, "GetAllRS");
            Hashtable __rs = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor))
            {
                int __id;
                string __name;
                while (__odr.Read())
                {
                    __id = __odr["id_rs"];
                    __name = __odr["nom_rs"];
                    __rs.Add(__id, __name);
                }
            }

            return __rs;
        }

        /// <summary>
        /// R�cup�ration de toute les resssources groupes
        /// </summary>
        /// <returns></returns>
		public Hashtable GetAllRG()
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            string __sql = string.Concat(this.Package, "GetAllRG");
            Hashtable __rg = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor))
            {
                int __id;
                string __name;
                while (__odr.Read())
                {
                    __id = __odr["id_rg"];
                    __name = __odr["nom_rg"];
                    __rg.Add(__id, __name);
                }
            }

            return __rg;
        }

        /// <summary>
        /// R�cup�ration des ressource groupe ppour une section
        /// </summary>
        /// <param name="id_section"></param>
        /// <returns></returns>
		public Hashtable GetRG_By_Section(int id_section)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_section = new QXPDataOracle.OraParameter("p_Id_Section", id_section);
            string __sql = string.Concat(this.Package, "GetRG_By_Section");
            Hashtable __rg = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_section))
            {
                int __id;
                string __name;
                while (__odr.Read())
                {
                    __id = __odr["id_rg"];
                    __name = __odr["nom_rg"];
                    __rg.Add(__id, __name);
                }
            }

            return __rg;
        }

        /// <summary>
        /// R�cup�ration des ressource groupe pour un nom
        /// </summary>
        /// <param name="nom_groupe"></param>
        /// <returns></returns>
		public Hashtable GetRG_By_Nom(string nom_groupe)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __mom_group = new QXPDataOracle.OraParameter("p_Nom_RG", Conversion.ToString(nom_groupe).ToUpper());
            string __sql = string.Concat(this.Package, "GetRG_By_Name");
            Hashtable __rg = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __mom_group))
            {
                int __id;
                string __name;
                while (__odr.Read())
                {
                    __id = __odr["id_rg"];
                    __name = __odr["nom_rg"];
                    __rg.Add(__id, __name);
                }
            }

            return __rg;
        }

        /// <summary>
        /// R�cup�ration des ressource key pour un ressource groupe
        /// </summary>
        /// <param name="id_group"></param>
        /// <returns></returns>
		public Hashtable GetRK_By_Group(int id_group)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_group = new QXPDataOracle.OraParameter("p_Id_RG", id_group);
            string __sql = string.Concat(this.Package, "GetRK_By_Group");
            Hashtable __rk = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_group))
            {
                int __id;
                string __code;
                while (__odr.Read())
                {
                    __id = __odr["id_rk"];
                    __code = __odr["code_rk"];
                    __rk.Add(__id, __code);
                }
            }

            return __rk;
        }

        /// <summary>
        /// R�cup�ration des ressource key pour un nom
        /// </summary>
        /// <param name="code_clef"></param>
        /// <returns></returns>
		public Hashtable GetRK_By_Nom(string code_clef)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __code_clef = new QXPDataOracle.OraParameter("p_Code_RK", Conversion.ToString(code_clef).ToUpper());
            string __sql = string.Concat(this.Package, "GetRK_By_Name");
            Hashtable __rk = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __code_clef))
            {
                int __id;
                string __code;
                while (__odr.Read())
                {
                    __id = __odr["id_rk"];
                    __code = __odr["code_rk"];
                    __rk.Add(__id, __code);
                }
            }

            return __rk;
        }

        /// <summary>
        /// R�cup�ration des ressource key pour une trad et une langue 
        /// </summary>
        /// <param name="trad_value"></param>
        /// <param name="langue"></param>
        /// <returns></returns>
		public Hashtable GetRK_By_Trad(string trad_value, string langue)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __code_clef = new QXPDataOracle.OraParameter("p_Trad_Value", trad_value);
            QXPDataOracle.OraParameter __langue = new QXPDataOracle.OraParameter("p_langue", langue);

            string __sql = string.Concat(this.Package, "GetRK_By_Trad");
            Hashtable __rk = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __code_clef, __langue))
            {
                int __id;
                string __code;
                while (__odr.Read())
                {
                    __id = __odr["id_rk"];
                    __code = __odr["code_rk"];
                    __rk.Add(__id, __code);
                }
            }

            return __rk;
        }

        /// <summary>
        /// R�cup�ration des ressource key pour une trad
        /// </summary>
        /// <param name="trad_value"></param>
        /// <returns></returns>
		public Hashtable GetRK_By_Trad(string trad_value)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __code_clef = new QXPDataOracle.OraParameter("p_Trad_Value", trad_value);
            QXPDataOracle.OraParameter __langue = new QXPDataOracle.OraParameter("p_langue", "FR");

            string __sql = string.Concat(this.Package, "GetRK_By_Trad");
            Hashtable __rk = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __code_clef))
            {
                int __id;
                string __code;
                while (__odr.Read())
                {
                    __id = __odr["id_rk"];
                    __code = __odr["code_rk"];
                    __rk.Add(__id, __code);
                }
            }

            return __rk;
        }

        /// <summary>
        /// R�cup�ration des ressources key pour une section et un group
        /// </summary>
        /// <param name="id_section"></param>
        /// <param name="id_group"></param>
        /// <returns></returns>
		public Hashtable GetRK_By_Section_Group(int id_section, int id_group)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_section = new QXPDataOracle.OraParameter("p_Id_RS", id_section);
            QXPDataOracle.OraParameter __id_group = new QXPDataOracle.OraParameter("p_Id_RG", id_group);
            string __sql = string.Concat(this.Package, "GetRK_By_Section_Group");
            Hashtable __rk = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_section, __id_group))
            {
                int __id;
                string __code;
                while (__odr.Read())
                {
                    __id = __odr["id_rk"];
                    __code = __odr["code_rk"];
                    __rk.Add(__id, __code);
                }
            }

            return __rk;
        }

		/// <summary>
		/// R�cup�ration des codes "ressources_section.ressource_key"
		/// </summary>
		/// <returns></returns>
        public Hashtable GetRS_RG()
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            string __sql = string.Concat(this.Package, "GetRS_RG");
            Hashtable __rg = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor))
            {
                int __id;
                string __rs_rg;
                while (__odr.Read())
                {
                    __id = __odr["id_rg"];
                    __rs_rg = __odr["marker"];
                    __rg.Add(__id, __rs_rg);
                }
            }

            return __rg;
        }

        /// <summary>
        /// R�cup�ration des ressources section
        /// </summary>
        /// <param name="id_rs"></param>
        /// <returns></returns>
		public Admin.Res_RS GetRS(int id_rs)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rs = new QXPDataOracle.OraParameter("p_Id_RS", id_rs);
            string __sql = string.Concat(this.Package, "GetRS");
            Admin.Res_RS __rs = null;

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_rs))
            {
                if (__odr.Read())
                {
                    __rs = new Admin.Res_RS(__odr["id_rs"], __odr["nom_rs"]);
                }
            }

            return __rs;
        }

        /// <summary>
        /// r�cup�ration des ressources group
        /// </summary>
        /// <param name="id_rg"></param>
        /// <returns></returns>
		public Admin.Res_RG GetRG(int id_rg)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rg = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            string __sql = string.Concat(this.Package, "GetRG");
            Admin.Res_RG __rg = null;

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_rg))
            {
                if (__odr.Read())
                {
                    __rg = new Admin.Res_RG(__odr["id_rg"], __odr["nom_rg"]);
                }
            }

            return __rg;
        }

        /// <summary>
        /// R�cup�ration des ressources key
        /// </summary>
        /// <param name="id_rk"></param>
        /// <returns></returns>
		public Admin.Res_RK GetRK(int id_rk)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rk = new QXPDataOracle.OraParameter("p_Id_RK", id_rk);
            string __sql_rk = string.Concat(this.Package, "GetRK");
            Admin.Res_RK __rk = null;

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql_rk, __cursor.Clone(), __id_rk.Clone()))
            {
                if (__odr.Read())
                {
                    __rk = new Admin.Res_RK(__odr["id_rk"], __odr["code_rk"], __odr["commentaire_rk"]);
                }
            }

            return __rk;
        }

        /// <summary>
        /// R�cup�ration des traduction pour un identifiant de trad
        /// </summary>
        /// <param name="id_rk"></param>
        /// <returns></returns>
		public Admin.Res_RK GetRK_Trads(int id_rk)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rk = new QXPDataOracle.OraParameter("p_Id_RK", id_rk);
            string __sql_rk = string.Concat(this.Package, "GetRK");
            string __sql_rk_trad = string.Concat(this.Package, "GetRK_Trad");
            Admin.Res_RK __rk = null;
            Admin.Res_RK_Trad __rk_trad = null;

            //chargement de la clef
            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql_rk, __cursor.Clone(), __id_rk.Clone()))
            {
                if (__odr.Read())
                {
                    __rk = new Admin.Res_RK(__odr["id_rk"], __odr["code_rk"], __odr["commentaire_rk"]);
                }
            }
            //chargement des trads si la clef existe
            if (Validation.IsNotNull(__rk))
            {
                using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql_rk_trad, __cursor.Clone(), __id_rk.Clone()))
                {
                    while (__odr.Read())
                    {
                        __rk_trad = new Admin.Res_RK_Trad(__odr["id_rk_trad"], __odr["id_langue"], __odr["valeur_rk"]);
                        __rk.Trads.Add(__rk_trad.ID_Langue, __rk_trad);
                    }
                }
            }


            return __rk;
        }        

        /// <summary>
        /// R�cup�ration des associations Ressource groupe / Ressources section
        /// </summary>
        /// <param name="id_rs"></param>
        /// <returns></returns>
		public Hashtable GetRG_Asso_RS(int id_rs)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rs = new QXPDataOracle.OraParameter("p_Id_RS", id_rs);
            string __sql = string.Concat(this.Package, "GetRG_Asso_RS");
            Hashtable __rg = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_rs))
            {
                while (__odr.Read())
                {
                    int __id = __odr["id_rg"];
                    string __name = __odr["nom_rg"];
                    __rg.Add(__id, __name);
                }
            }

            return __rg;
        }

		/// <summary>
		/// R�cup�ration des associations ressources key / ressources group
		/// </summary>
		/// <param name="id_rg"></param>
		/// <returns></returns>
        public Hashtable GetRK_Asso_RG(int id_rg)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rg = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            string __sql = string.Concat(this.Package, "GetRK_Asso_RG");
            Hashtable __rk = new Hashtable();
            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_rg))
            {
                while (__odr.Read())
                {
                    int __id = __odr["id_rk"];
                    string __code = __odr["code_rk"];
                    __rk.Add(__id, __code);
                }
            }

            return __rk;
        }

        /// <summary>
        /// R�cup�ration des associations ressources section / ressource group
        /// </summary>
        /// <param name="id_rg"></param>
        /// <returns></returns>
		public Hashtable GetRS_Asso_RG(int id_rg)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rg = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            string __sql = string.Concat(this.Package, "GetRS_Asso_RG");
            Hashtable __rs = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_rg))
            {
                while (__odr.Read())
                {
                    int __id = __odr["id_rs"];
                    string __name = __odr["nom_rs"];
                    __rs.Add(__id, __name);
                }
            }

            return __rs;
        }

        /// <summary>
        /// R�cup�ration des associations ressources group / ressources key
        /// </summary>
        /// <param name="id_rk"></param>
        /// <returns></returns>
		public Hashtable GetRG_Asso_RK(int id_rk)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rk = new QXPDataOracle.OraParameter("p_Id_RK", id_rk);
            string __sql = string.Concat(this.Package, "GetRG_Asso_RK");
            Hashtable __rg = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_rk))
            {
                while (__odr.Read())
                {
                    int __id = __odr["id_rg"];
                    string __code = __odr["nom_rg"];
                    __rg.Add(__id, __code);
                }
            }

            return __rg;
        }
        
        /// <summary>
        /// R�cup�ration des marqueurs de ressource (RS.RG.RK) pour un ressources group
        /// </summary>
        /// <param name="id_rg"></param>
        /// <returns></returns>
		public ArrayList GetAllMarkerUsed_By_RG(int id_rg)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rg = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            string __sql = string.Concat(this.Package, "GetAllMarker_By_RG");
            ArrayList __markers = new ArrayList();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_rg))
            {
                __markers.Add(string.Format(IDMarkerPattern, id_rg));
				while (__odr.Read())
                {
                    string __marker = __odr["marker"];
                    __markers.Add(__marker);
                }
            }

            return __markers;
        }

		/// <summary>
		/// R�cup�ration des marqueurs de ressource (RS.RG.RK) pour un ressources key
		/// </summary>
		/// <param name="id_rk"></param>
		/// <returns></returns>
		public ArrayList GetAllMarkerUsed_By_RK(int id_rk)
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __id_rk = new QXPDataOracle.OraParameter("p_Id_RK", id_rk);
            string __sql = string.Concat(this.Package, "GetAllMarker_By_RK");
            ArrayList __markers = new ArrayList();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor, __id_rk))
            {
                __markers.Add(string.Format(IDMarkerPattern, id_rk));
				while (__odr.Read())
                {
                    string __marker = __odr["marker"];
                    __markers.Add(__marker);
                }
            }

            return __markers;
        }

        /// <summary>
        /// Get Liste de langue
        /// </summary>
        /// <returns></returns>
		public Hashtable GetListeLangue()
        {
            QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue);
            string __sql = string.Concat(this.Package, "GetListeLangue");
            Hashtable __rs = new Hashtable();

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(CommandType.StoredProcedure, __sql, __cursor))
            {
                int __idLangue;
                string __codeLangue;
                while (__odr.Read())
                {
                    __idLangue = __odr["id_langue"];
                    __codeLangue = __odr["code_langue"];
                    __rs.Add(__idLangue, __codeLangue);
                }
            }

            return __rs;
        }
        
        #endregion SELECT

        #region INSERT / UPDATE / DELETE

        public int AddRS(Admin.Res_Section section)
        {
            QXPDataOracle.OraParameter __idSection = new QXPDataOracle.OraParameter("p_Id_RS", OracleDbType.Int32, ParameterDirection.Output);
            QXPDataOracle.OraParameter __nomSection = new QXPDataOracle.OraParameter("p_Nom_RS", section.Name);
            string __sql = string.Concat(this.Package, "InsertRS");

            this.Execute(CommandType.StoredProcedure, __sql, __idSection, __nomSection);

            int __id = Conversion.ToInt(__idSection.Value);
            return __id;
        }

        public int AddRG(Admin.Res_Group group, int id_RS)
        {
            QXPDataOracle.OraParameter __idGroup = new QXPDataOracle.OraParameter("p_Id_RG", OracleDbType.Int32, ParameterDirection.Output);
            QXPDataOracle.OraParameter __idRS = new QXPDataOracle.OraParameter("p_Id_RS", id_RS);
            QXPDataOracle.OraParameter __nomGroup = new QXPDataOracle.OraParameter("p_Nom_RG", group.Name);
            string __sql = string.Concat(this.Package, "InsertRG");

            this.Execute(CommandType.StoredProcedure, __sql, __idGroup, __idRS, __nomGroup);

            int __id = Conversion.ToInt(__idGroup.Value);
            return __id;
        }

        public int AddRK(Admin.Res_Item item, int id_RG)
        {
            QXPDataOracle.OraParameter __idItem = new QXPDataOracle.OraParameter("p_Id_RK", OracleDbType.Int32, ParameterDirection.Output);
            QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", id_RG);
            QXPDataOracle.OraParameter __codeRK = new QXPDataOracle.OraParameter("p_Code_RK", item.Code);
            string __sql = string.Concat(this.Package, "InsertRK");

            this.Execute(CommandType.StoredProcedure, __sql, __idItem, __idRG, __codeRK);

            int __id = Conversion.ToInt(__idItem.Value);
            return __id;
        }

        public int AddRK_Trad(Admin.Res_Item item)
        {
            QXPDataOracle.OraParameter __idItem_Trad = new QXPDataOracle.OraParameter("p_Id_RK_Trad", OracleDbType.Int32, ParameterDirection.Output);
            QXPDataOracle.OraParameter __idLangue = new QXPDataOracle.OraParameter("p_Id_Langue", this.ID_Langue);
            QXPDataOracle.OraParameter __idRK = new QXPDataOracle.OraParameter("p_Id_RK", item.ID);
            QXPDataOracle.OraParameter __value = new QXPDataOracle.OraParameter("p_Value", item.Value);
            string __sql = string.Concat(this.Package, "InsertRK_Trad");

            this.Execute(CommandType.StoredProcedure, __sql, __idItem_Trad, __idLangue, __idRK, __value);

            int __id = Conversion.ToInt(__idItem_Trad.Value);
            return __id;
        }

        public void Asso_RS_RG(int id_RS, int id_RG)
        {
            QXPDataOracle.OraParameter __idRS = new QXPDataOracle.OraParameter("p_Id_RS", id_RS);
            QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", id_RG);
            string __sql = string.Concat(this.Package, "Asso_RS_RG");

            this.Execute(CommandType.StoredProcedure, __sql, __idRS, __idRG);
        }

        public void Asso_RG_RK(int id_RG, int id_RK)
        {
            QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", id_RG);
            QXPDataOracle.OraParameter __idRK = new QXPDataOracle.OraParameter("p_Id_RK", id_RK);
            string __sql = string.Concat(this.Package, "Asso_RG_RK");

            this.Execute(CommandType.StoredProcedure, __sql, __idRG, __idRK);
        }

        public void SaveTrad(int id_rk, int id_langue, string value)
        {
            QXPDataOracle.OraParameter __idRK_Trad = new QXPDataOracle.OraParameter("p_Id_RK_Trad", int.MinValue);
            __idRK_Trad.Direction = ParameterDirection.Output;
            QXPDataOracle.OraParameter __idRK = new QXPDataOracle.OraParameter("p_Id_RK", id_rk);
            QXPDataOracle.OraParameter __idLangue = new QXPDataOracle.OraParameter("p_Id_Langue", id_langue);
            QXPDataOracle.OraParameter __value = new QXPDataOracle.OraParameter("p_Value", value);
            string __sql = string.Concat(this.Package, "Insert_Update_RK_Trad");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                this.Execute(CommandType.StoredProcedure, __sql, __idRK_Trad, __idRK, __idLangue, __value);
                int __newId = Conversion.ToInt(__idRK_Trad.Value);
                //if __newId is minvalue this is a update RK_Trad record !
                if (__newId == int.MinValue)
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.UpdateRK_Trad, SitePrefix, id_rk, id_langue, value);
                }
                else
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.InsertRK_Trad, SitePrefix, __newId, id_rk, id_langue, value);
                }
                this.CommitTransaction();

            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }
        }

        public bool SaveRS(int id_rs, string nom)
        {
            QXPDataOracle.OraParameter __return = new QXPDataOracle.OraParameter("p_Return", OracleDbType.Byte, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __idRS = new QXPDataOracle.OraParameter("p_Id_RS", id_rs);
            __idRS.Direction = ParameterDirection.InputOutput;
            QXPDataOracle.OraParameter __nom = new QXPDataOracle.OraParameter("p_Nom", nom);
            string __sql = string.Concat(this.Package, "Insert_Update_RS");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);
            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                this.Execute(CommandType.StoredProcedure, __sql, __return, __idRS, __nom);
                int __newId = Conversion.ToInt(__idRS.Value);
                if (__newId == id_rs)
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.UpdateRS, SitePrefix, __newId, nom);
                }
                else
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.InsertRS, SitePrefix, __newId, nom);
                }
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }
            bool __result = __return.ReturnValue;
            return __result;
        }

        public bool SaveRG(int id_rg, string nom)
        {
            QXPDataOracle.OraParameter __return = new QXPDataOracle.OraParameter("p_Return", OracleDbType.Byte, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            __idRG.Direction = ParameterDirection.InputOutput;
            QXPDataOracle.OraParameter __nom = new QXPDataOracle.OraParameter("p_Nom", nom);
            string __sql = string.Concat(this.Package, "Insert_Update_RG");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                this.Execute(CommandType.StoredProcedure, __sql, __return, __idRG, __nom);
                int __newId = Conversion.ToInt(__idRG.Value);
                if (__newId == id_rg)
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.UpdateRG, SitePrefix, __newId, nom);
                }
                else
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.InsertRG, SitePrefix, __newId, nom);
                }
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }

            bool __result = __return.ReturnValue;
            return __result;
        }

        public bool SaveRG_And_Asso(int id_rg, string nom, int id_rs)
        {
            QXPDataOracle.OraParameter __return = new QXPDataOracle.OraParameter("p_Return", OracleDbType.Byte, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            __idRG.Direction = ParameterDirection.InputOutput;
            QXPDataOracle.OraParameter __idRS = new QXPDataOracle.OraParameter("p_Id_RS", id_rs);
            QXPDataOracle.OraParameter __nom = new QXPDataOracle.OraParameter("p_Nom", nom);
            string __sql = string.Concat(this.Package, "Insert_Update_RG_And_Asso");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                this.Execute(CommandType.StoredProcedure, __sql, __return, __idRG, __nom, __idRS);
                int __newId = Conversion.ToInt(__idRG.Value);
                if (__newId == id_rg)
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.UpdateRG, SitePrefix, __newId, nom);
                }
                else
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.InsertRG_Asso, SitePrefix, __newId, nom, id_rs);
                }
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }

            bool __result = __return.ReturnValue;
            return __result;
        }

        public bool SaveRK_And_Asso(int id_rk, string code, string commentaire, int id_rg)
        {
            QXPDataOracle.OraParameter __return = new QXPDataOracle.OraParameter("p_Return", OracleDbType.Byte, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            QXPDataOracle.OraParameter __idRK = new QXPDataOracle.OraParameter("p_Id_RK", id_rk);
            __idRK.Direction = ParameterDirection.InputOutput;
            QXPDataOracle.OraParameter __code = new QXPDataOracle.OraParameter("p_Code", code);
            QXPDataOracle.OraParameter __commentaire = new QXPDataOracle.OraParameter("p_Commentaire", commentaire);
            string __sql = string.Concat(this.Package, "Insert_Update_RK_And_Asso");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                this.Execute(CommandType.StoredProcedure, __sql, __return, __idRK, __code, __commentaire, __idRG);
                int __newId = Conversion.ToInt(__idRK.Value);
                if (__newId == id_rk)
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.UpdateRK, SitePrefix, __newId, code, commentaire);
                }
                else
                {
                    __log.Log_Activity(ResourcesProxy_LogMessage.InsertRK_Asso, SitePrefix, __newId, code, commentaire, id_rg);
                }
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }

            bool __result = __return.ReturnValue;
            return __result;
        }

        public bool DeleteRS(int id_rs)
        {
            QXPDataOracle.OraParameter __return = new QXPDataOracle.OraParameter("p_Return", OracleDbType.Byte, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __idRS = new QXPDataOracle.OraParameter("p_Id_RS", id_rs);
            string __sql = string.Concat(this.Package, "Delete_RS");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);
            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                this.Execute(CommandType.StoredProcedure, __sql, __return, __idRS);
                __log.Log_Activity(ResourcesProxy_LogMessage.DeleteRS, SitePrefix, id_rs);
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }

            }
            bool __result = __return.ReturnValue;
            return __result;
        }

        public bool DeleteRG(int id_rg)
        {
            QXPDataOracle.OraParameter __return = new QXPDataOracle.OraParameter("p_Return", OracleDbType.Byte, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            string __sql = string.Concat(this.Package, "Delete_RG");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                this.Execute(CommandType.StoredProcedure, __sql, __return, __idRG);
                __log.Log_Activity(ResourcesProxy_LogMessage.DeleteRG, SitePrefix, id_rg);
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }
            bool __result = __return.ReturnValue;
            return __result;
        }

        public bool DeleteRK(int id_rk)
        {
            QXPDataOracle.OraParameter __return = new QXPDataOracle.OraParameter("p_Return", OracleDbType.Byte, ParameterDirection.ReturnValue);
            QXPDataOracle.OraParameter __idRK = new QXPDataOracle.OraParameter("p_Id_RK", id_rk);
            string __sql = string.Concat(this.Package, "Delete_RK");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                this.Execute(CommandType.StoredProcedure, __sql, __return, __idRK);
                __log.Log_Activity(ResourcesProxy_LogMessage.DeleteRK, SitePrefix, id_rk);
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }
            bool __result = __return.ReturnValue;
            return __result;
        }

        public void Remove_Asso_RS_RG(int id_rs, int id_rg)
        {
            this.Remove_Asso_RS_RG(id_rs, new int[] { id_rg });
        }

        public void Remove_Asso_RS_RG(int id_rs, int[] id_rgs)
        {
            QXPDataOracle.OraParameter __idRS = new QXPDataOracle.OraParameter("p_Id_RS", id_rs);
            string __sql = string.Concat(this.Package, "Remove_Asso_RS_RG");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                foreach (int __irg in id_rgs)
                {
                    QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", __irg);
                    this.Execute(CommandType.StoredProcedure, __sql, __idRS.Clone(), __idRG);
                    __log.Log_Activity(ResourcesProxy_LogMessage.DeleteRS_RG, SitePrefix, id_rs, __irg);
                }

                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }
        }

        public void Remove_Asso_RG_RK(int id_rg, int id_rk)
        {
            this.Remove_Asso_RG_RK(id_rg, new int[] { id_rk });
        }

        public void Remove_Asso_RG_RK(int id_rg, int[] id_rks)
        {
            QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            string __sql = string.Concat(this.Package, "Remove_Asso_RG_RK");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                foreach (int __irk in id_rks)
                {
                    QXPDataOracle.OraParameter __idRK = new QXPDataOracle.OraParameter("p_Id_RK", __irk);
                    this.Execute(CommandType.StoredProcedure, __sql, __idRG.Clone(), __idRK);
                    __log.Log_Activity(ResourcesProxy_LogMessage.DeleteRG_RK, SitePrefix, id_rg, __irk);
                }
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }
        }

        public void Insert_Asso_RS_RG(int id_rs, int id_rg)
        {
            this.Insert_Asso_RS_RG(id_rs, new int[] { id_rg });
        }

        public void Insert_Asso_RS_RG(int id_rs, int[] id_rgs)
        {
            QXPDataOracle.OraParameter __idRS = new QXPDataOracle.OraParameter("p_Id_RS", id_rs);
            string __sql = string.Concat(this.Package, "Insert_Asso_RS_RG");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                foreach (int __irg in id_rgs)
                {
                    QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", __irg);
                    this.Execute(CommandType.StoredProcedure, __sql, __idRS.Clone(), __idRG);
                    __log.Log_Activity(ResourcesProxy_LogMessage.InsertRS_RG, SitePrefix, id_rs, __irg);
                }
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }
        }
		/// <summary>
        /// Insertion d'une association entre Ressource groupe et une ressource key
		/// </summary>
		/// <param name="id_rg">identifiant ressource group</param>
		/// <param name="id_rk">identifiant ressource key</param>
        public void Insert_Asso_RG_RK(int id_rg, int id_rk)
        {
            this.Insert_Asso_RG_RK(id_rg, new int[] { id_rk });
        }

        /// <summary>
        /// Insertion d'une association entre Ressource groupe et des ressources keys
        /// </summary>
        /// <param name="id_rg">identifiant de la ressource groupe</param>
        /// <param name="id_rks">identifiants des ressources keys</param>
		public void Insert_Asso_RG_RK(int id_rg, int[] id_rks)
        {
            QXPDataOracle.OraParameter __idRG = new QXPDataOracle.OraParameter("p_Id_RG", id_rg);
            string __sql = string.Concat(this.Package, "Insert_Asso_RG_RK");
            ProxyRessource_Log __log = new ProxyRessource_Log(ProxyCommand.All);

            try
            {
                if (!__log.AcquireLock()) throw new LockedLog_Exception(__log.Command.ToString());
                this.BeginTransaction();
                foreach (int __irk in id_rks)
                {
                    QXPDataOracle.OraParameter __idRK = new QXPDataOracle.OraParameter("p_Id_RK", __irk);
                    this.Execute(CommandType.StoredProcedure, __sql, __idRG.Clone(), __idRK);
                    __log.Log_Activity(ResourcesProxy_LogMessage.InsertRG_RK, SitePrefix, id_rg, __irk);
                }
                this.CommitTransaction();
            }
            catch
            {
                this.RoolBackTransaction();
                throw;
            }
            finally
            {
                if (Validation.IsNotNull(__log))
                {
                    __log.Close();
                }
            }
        }

		/// <summary>
		/// Mise jour des commentaires de la ressource key
		/// </summary>
		/// <param name="culture_code"></param>
        public void UpdateCommentaireRK(string culture_code)
        {
            QXPDataOracle.OraParameter __culture_code = new QXPDataOracle.OraParameter("p_culture_code", culture_code);
            string __sql = string.Concat(this.Package, "Update_RKComment");

            try
            {
                this.Execute(CommandType.StoredProcedure, __sql, __culture_code);
            }
            catch
            {
                throw;
            }
        }

        #endregion INSERT / UPDATE / DELETE

        #endregion Acc�s Base

        #endregion M�thodes

        #region Propri�t�s

		/// <summary>
		/// Identifiant de la langue
		/// </summary>
        private int ID_Langue
        {
            get { return _id_Langue; }
        }

        /// <summary>
        /// Nom du Package
        /// </summary>
        private string Package
        {
            get { return string.Format(PACKAGE_PATTERN, SitePrefix); }
        }

        #endregion Propri�t�s
    }

	/// <summary>
	/// Mod�le des log SQL
	/// </summary>
    public class ResourcesProxy_LogMessage
    {
        public const string InsertRS = "INSERT INTO {0}_RS (id_rs, nom_rs) VALUES ({1}, UPPER('{2}'));";
        public const string InsertRG = "INSERT INTO {0}_RG (id_rg, nom_rg) VALUES ({1}, UPPER('{2}'));";
        public const string InsertRK_Trad = "INSERT INTO {0}_RK_TRAD (id_rk_Trad, id_rk, id_langue, valeur_rk) VALUES ({1}, {2}, {3}, '{4}');";
        public const string InsertRG_Asso = "INSERT INTO {0}_RG (id_rg, nom_rg) VALUES ({1}, UPPER('{2}')); INSERT INTO {0}_ASSO_RS_RG (id_rs, id_rg) VALUES ({3}, {1});";
        public const string InsertRK_Asso = "INSERT INTO {0}_RK (id_rk, code_rk, commentaire_rk) VALUES ({1}, UPPER('{2}'), '{3}'); INSERT INTO {0}_ASSO_RG_RK (id_rg, id_rk) VALUES ({4}, {1});";
        public const string UpdateRS = "UPDATE {0}_RS rs SET rs.nom_rs = UPPER('{2}') WHERE rs.id_rs = {1}";
        public const string UpdateRG = "UPDATE {0}_RG rg SET rg.nom_rg = UPPER('{2}') WHERE rg.id_rg = {1};";
        public const string UpdateRK = "UPDATE {0}_RK rk SET rk.code_rk = UPPER('{2}'), rk.commentaire_rk = '{3}'  WHERE rk.id_rk = {1};";
        public const string UpdateRK_Trad = "UPDATE {0}_RK_TRAD rk_trad SET rk_trad.valeur_rk = '{3}' WHERE rk_trad.id_rk = {1} AND rk_trad.id_langue = {2};";
        public const string DeleteRS = "DELETE FROM {0}_RS rs WHERE rs.id_rs = {1};";
        public const string DeleteRG = "DELETE FROM {0}_ASSO_RS_RG rs_rg WHERE rs_rg.id_rg = {1}; DELETE FROM {0}_RG rg WHERE rg.id_rg = {1};";
        public const string DeleteRK = "DELETE FROM {0}_RK_TRAD rk_trad WHERE rk_trad.id_rk = {1}; DELETE FROM {0}_ASSO_RG_RK rg_rk WHERE rg_rk.id_rk = {1}; DELETE FROM {0}_RK rk WHERE rk.id_rk = {1};";
        public const string DeleteRS_RG = "DELETE FROM {0}_ASSO_RS_RG WHERE id_rs = {1} AND id_rg = {2};";
        public const string DeleteRG_RK = "DELETE FROM {0}_ASSO_RG_RK WHERE id_rg = {1} AND id_rk = {2};";
        public const string InsertRS_RG = "INSERT INTO {0}_ASSO_RS_RG (id_rs, id_rg) VALUES ({1}, {2});";
        public const string InsertRG_RK = "INSERT INTO {0}_ASSO_RG_RK (id_rg, id_rk) VALUES ({1}, {2});";
    }
}
