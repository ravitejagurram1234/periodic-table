using System;
using System.Globalization;
using QXPApplication = QXP.Framework.Application;

namespace QXP.Framework.Resources
{
    /// <summary>
    /// Class ResourceInfo
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class ResourceInfo
    {
        #region Membres

        Array _sections = null;
        object _group = null;
        
        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ResourceInfo
        /// </summary>
        public ResourceInfo() { }

        /// <summary>
        /// Cr�e une instance de ResourceInfo
        /// </summary>
        public ResourceInfo(object obj)
        {
            if (Validation.IsNull(obj)) return;
            string __typeName = obj.GetType().Name;
            this.SetInfo(null, __typeName);
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Ajoute au d�but des sections la ou les sections pass�es en param�tre.
        /// </summary>
        /// <param name="sections">Sections � ajouter</param>
        public void AddSectionInfo(params object[] sections)
        {
            BaseList<object> __sections = new BaseList<object>();
            __sections.AddRange(sections);
            if (Validation.IsSet(this._sections))
                __sections.AddRange(Conversion.ToIEnumerable<object>(this._sections));
            _sections = __sections.ToArray();
        }

        /// <summary>
        /// Ajoute � la fin des sections la ou les sections pass�es en param�tre.
        /// </summary>
        /// <param name="sections">Sections � ajouter</param>
        public void AddSectionInfoToEnd(params object[] sections)
        {
            BaseList<object> __sections = new BaseList<object>();
            __sections.AddRange(Conversion.ToIEnumerable<object>(this._sections));
            __sections.AddRange(sections);
            _sections = __sections.ToArray();
        }

        public void SetInfo(object group, params object[] sections)
        {
            _group = group;
            //ce test v�rifie s'il y a une seule section de type array si oui prend le contenu de cette element comme liste de sections.
            if (sections.Length == 1 && sections[0] is Array)
            {
                _sections = sections[0] as Array;
            }
            else
            {
                _sections = sections;
            }
        }

        public void Clear()
        {
            _sections = null;
            _group = null;
        }

        #region Exist

        public bool ExistLabel()
        {
            return ExistLabel(_group);
        }

        public bool ExistLabel(object group)
        {
            return QXPApplication.Application.Resources.Exist(_sections, group, ResourceParams.Key.Label);
        }

        public bool ExistToolTip()
        {
            return this.ExistToolTip(_group);
        }

        public bool ExistToolTip(object group)
        {
            return QXPApplication.Application.Resources.Exist(_sections, group, ResourceParams.Key.ToolTip);
        }

        public bool ExistMessage()
        {
            return this.ExistMessage(_group);
        }

        public bool ExistMessage(object group)
        {
            return QXPApplication.Application.Resources.Exist(_sections, group, ResourceParams.Key.Message);
        }

        public bool ExistData()
        {
            return this.ExistData(_group);
        }

        public bool ExistData(object group)
        {
            return QXPApplication.Application.Resources.Exist(_sections, group, ResourceParams.Key.Data);
        }

        #endregion

        #region Gets Locales

        public string GetToolTip()
        {
            return this.GetToolTip(_group);
        }

        public string GetToolTip(object group, params object[] args)
        {
            return QXPApplication.Application.Resources.Get(_sections, group, ResourceParams.Key.ToolTip, args);
        }

        public string GetLabel()
        {
            return this.GetLabel(_group);
        }

        public string GetLabel(object group, params object[] args)
        {
            return QXPApplication.Application.Resources.Get(_sections, group, ResourceParams.Key.Label, args);
        }

        public string GetLabel(CultureInfo culture, object group, params object[] args)
        {
            return QXPApplication.Application.Resources.Get(culture, _sections, group, ResourceParams.Key.Label, args);
        }

        public string GetMessage()
        {
            return this.GetMessage(_group);
        }

        public string GetMessage(object group, params object[] args)
        {
            return QXPApplication.Application.Resources.Get(_sections, group, ResourceParams.Key.Message, args);
        }

        public string GetMessage(CultureInfo culture, object group, params object[] args)
        {
            return QXPApplication.Application.Resources.Get(culture, _sections, group, ResourceParams.Key.Message, args);
        }

        public string GetData()
        {
            return this.GetData(_group);
        }

        public string GetData(object group, params object[] args)
        {
            return QXPApplication.Application.Resources.Get(_sections, group, ResourceParams.Key.Data, args);
        }


        public string GetData(CultureInfo culture, object group, params object[] args)
        {
            return QXPApplication.Application.Resources.Get(culture, _sections, group, ResourceParams.Key.Data, args);
        }

        public string Get(object group, object key, params object[] args)
        {
            return QXPApplication.Application.Resources.Get(_sections, group, key, args);
        }

        public string GetOperationDoneMessage()
        {
            return QXPApplication.Application.Resources.GetOperationDoneMessage();
        }

        public string GetOperationDoneMessage(CultureInfo culture)
        {
            return QXPApplication.Application.Resources.GetOperationDoneMessage(culture);
        }


        public string GetOperationFailedMessage()
        {
            return QXPApplication.Application.Resources.GetOperationFailedMessage();
        }

        public string GetOperationFailedMessage(CultureInfo culture)
        {
            return QXPApplication.Application.Resources.GetOperationFailedMessage(culture);
        }

        #endregion

        #endregion M�thodes

        #region Propri�t�s

        public bool HaveInfo
        {
            get { return this.HaveGroup && this.HaveSections; }
        }

        public bool HaveGroup
        {
            get { return Validation.IsSet(_group); }
        }

        public bool HaveSections
        {
            get { return Validation.IsSet(_sections); }
        }

        public bool HaveLabel
        {
            get
            {
                return QXPApplication.Application.Resources.Exist(_sections, _group, ResourceParams.Key.Label);
            }
        }

        public bool HaveToolTip
        {
            get
            {
                return QXPApplication.Application.Resources.Exist(_sections, _group, ResourceParams.Key.ToolTip);
            }
        }

        public object Group
        {
            get { return _group; }
        }

        public Array Sections
        {
            get { return _sections; }
        }

        #endregion Propri�t�s
    }
}
