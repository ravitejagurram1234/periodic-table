using System;
using System.Collections;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPIO = QXP.Framework.IO;

namespace QXP.Framework.Resources
{
    /// <summary>
    /// Class ResourceManager : Provides methods to retrieve localized message.
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class ResourceManager
    {
        #region Membres

        private ListDictionary _resources;
        private ListDictionary _syncObjects;
        public static bool Enabled = true;

        #endregion Membres

        #region Constantes

        private const string RG_ERROR = "Error";
        private const string RG_DELETECONFIRM = "DeleteConfirm";
        private const string RK_MESSAGE = "Message";
        /// <summary>Represents the base folder for all localized resource files. </summary>
        /// <remarks>Each culture must have a sub folder where his name is it's TwoISOCode. for exemple FR for French culture. </remarks>
        public const string SubPath = "Culture";
        /// <summary>The full file name of a localized resource file. </summary>
        public const string FileName = "Locales.xml";
        const string PatternKey = "{0}.{1}.{2}";
        const string PatternMarker = "[{0}.{1}.{2}]";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ResourceManager
        /// </summary>
        public ResourceManager()
        {
            this.Reset();
        }

        #endregion Constructeur

        #region M�thodes

        public string GetGlobalErrorMessage()
        {
            return GetGlobal(RG_ERROR, RK_MESSAGE);
        }

        public string GetGlobalDeleteConfirmMessage()
        {
            return GetGlobal(RG_DELETECONFIRM, RK_MESSAGE);
        }

        #region GetLabel

        /// <summary>Gets a localized label from the <paramref name="section"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetLabel(object section, object group, params object[] args)
        {
            return this.Get(section, group, ResourceParams.Key.Label, args);
        }

        /// <summary>Gets a localized label from the <paramref name="sections"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetLabel(Array sections, object group, params object[] args)
        {
            return this.Get(sections, group, ResourceParams.Key.Label, args);
        }

        /// <summary>Gets a localized label from the <paramref name="section"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetLabel(CultureInfo culture, object section, object group, params object[] args)
        {
            return this.Get(culture, section, group, ResourceParams.Key.Label, args);
        }

        /// <summary>Gets a localized label from the <paramref name="sections"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetLabel(CultureInfo culture, Array sections, object group, params object[] args)
        {
            return this.Get(culture, sections, group, ResourceParams.Key.Label, args);
        }

        #endregion

        #region GetMessage

        /// <summary>Gets a localized message from the <paramref name="section"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetMessage(object section, object group, params object[] args)
        {
            return this.Get(section, group, ResourceParams.Key.Message, args);
        }

        /// <summary>Gets a localized message from the <paramref name="sections"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetMessage(Array sections, object group, params object[] args)
        {
            return this.Get(sections, group, ResourceParams.Key.Message, args);
        }

        /// <summary>Gets a localized message from the <paramref name="section"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetMessage(CultureInfo culture, object section, object group, params object[] args)
        {
            return this.Get(culture, section, group, ResourceParams.Key.Message, args);
        }

        /// <summary>Gets a localized message from the <paramref name="sections"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetMessage(CultureInfo culture, Array sections, object group, params object[] args)
        {
            return this.Get(culture, sections, group, ResourceParams.Key.Message, args);
        }

        #endregion

        #region GetToolTip

        /// <summary>Gets a localized tooltip from the <paramref name="section"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetToolTip(object section, object group, params object[] args)
        {
            return this.Get(section, group, ResourceParams.Key.ToolTip, args);
        }

        /// <summary>Gets a localized tooltip from the <paramref name="sections"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetToolTip(Array sections, object group, params object[] args)
        {
            return this.Get(sections, group, ResourceParams.Key.ToolTip, args);
        }

        /// <summary>Gets a localized tooltip from the <paramref name="section"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetToolTip(CultureInfo culture, object section, object group, params object[] args)
        {
            return this.Get(culture, section, group, ResourceParams.Key.ToolTip, args);
        }

        #endregion

        #region GetData

        /// <summary>Gets a localized data from the <paramref name="section"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetData(object section, object group, params object[] args)
        {
            return this.Get(section, group, ResourceParams.Key.Data, args);
        }

        /// <summary>Gets a localized data from the <paramref name="sections"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetData(Array sections, object group, params object[] args)
        {
            return this.Get(sections, group, ResourceParams.Key.Data, args);
        }

        /// <summary>Gets a localized data from the <paramref name="section"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetData(CultureInfo culture, object section, object group, params object[] args)
        {
            return this.Get(culture, section, group, ResourceParams.Key.Data, args);
        }

        /// <summary>Gets a localized data from the <paramref name="sections"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="group">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// </returns>
        public string GetData(CultureInfo culture, Array sections, object group, params object[] args)
        {
            return this.Get(culture, sections, group, ResourceParams.Key.Data, args);
        }

        #endregion

        #region GetGlobal

        /// <summary>Gets a global localized command text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>Command</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalCommand(object key, params object[] args)
        {
            return this.Get(ResourceParams.Section.Global, ResourceParams.Group.Command, key, args);
        }

        /// <summary>Gets a global localized command text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>Command</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalToolTip(CultureInfo culture, object key, params object[] args)
        {
            return this.Get(culture, ResourceParams.Section.Global, ResourceParams.Group.Command, key, args);
        }

        /// <summary>Gets a global localized Tooltip text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>Command</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalToolTip(object key, params object[] args)
        {
            return this.Get(ResourceParams.Section.Global, ResourceParams.Group.ToolTip, key, args);
        }

        /// <summary>Gets a global localized Tooltip text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>Command</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalCommand(CultureInfo culture, object key, params object[] args)
        {
            return this.Get(culture, ResourceParams.Section.Global, ResourceParams.Group.ToolTip, key, args);
        }

        /// <summary>Gets a global localized error text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>ErrorMsg</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalErrorMessage(object key, params object[] args)
        {
            return this.Get(ResourceParams.Section.Global, ResourceParams.Group.ErrorMsg, key, args);
        }

        /// <summary>Gets a global localized error text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>ErrorMsg</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalErrorMessage(CultureInfo culture, object key, params object[] args)
        {
            return this.Get(culture, ResourceParams.Section.Global, ResourceParams.Group.ErrorMsg, key, args);
        }

        /// <summary>Gets a global localized message text from the <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="group">The <see cref="Object"/> resource group. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is is <paramref name="group"/> and resource key is <c>Message</c>.
        /// </returns>
        public string GetGlobalMessage(object group, params object[] args)
        {
            return this.Get(ResourceParams.Section.Global, group, ResourceParams.Key.Message, args);
        }

        /// <summary>Gets a global localized message from the <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="culture">The <see cref="CultureInfo"/> culture info to use. </param>
        /// <param name="group">The <see cref="Object"/> resource group. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is is <paramref name="group"/> and resource key is <c>Message</c>.
        /// </returns>
        public string GetGlobalMessage(CultureInfo culture, object group, params object[] args)
        {
            return this.Get(culture, ResourceParams.Section.Global, group, ResourceParams.Key.Message, args);
        }

        /// <summary>Gets a global localized label text from the <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="group">The <see cref="Object"/> resource group. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is is <paramref name="group"/> and resource key is <c>Message</c>.
        /// </returns>
        public string GetGlobalLabel(object group, params object[] args)
        {
            return this.Get(ResourceParams.Section.Global, group, ResourceParams.Key.Label, args);
        }

        /// <summary>Gets a global label message from the <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="culture">The <see cref="CultureInfo"/> culture info to use. </param>
        /// <param name="group">The <see cref="Object"/> resource group. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is is <paramref name="group"/> and resource key is <c>Message</c>.
        /// </returns>
        public string GetGlobalLabel(CultureInfo culture, object group, params object[] args)
        {
            return this.Get(culture, ResourceParams.Section.Global, group, ResourceParams.Key.Label, args);
        }

        /// <summary>Gets a global localized exception text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>ErrorMsg</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalExceptionMessage(object key, params object[] args)
        {
            return this.Get(ResourceParams.Section.Global, ResourceParams.Group.Exceptions, key, args);
        }

        /// <summary>Gets a global localized exception text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>ErrorMsg</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalExceptionMessage(CultureInfo culture, object key, params object[] args)
        {
            return this.Get(culture, ResourceParams.Section.Global, ResourceParams.Group.Exceptions, key, args);
        }

        /// <summary>Gets a localized info text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>InfoMsg</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalInfoMessage(object key, params object[] args)
        {
            return this.Get(ResourceParams.Section.Global, ResourceParams.Group.InfoMsg, key, args);
        }

        /// <summary>Gets a localized info text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">The <see cref="Object"/> resource key. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>InfoMsg</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalInfoMessage(CultureInfo culture, object key, params object[] args)
        {
            return this.Get(culture, ResourceParams.Section.Global, ResourceParams.Group.InfoMsg, key, args);
        }

        /// <summary>Gets a global localized validator text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">the resource key. </param>
        /// <param name="args">an array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// the localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// the pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>Validator</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalValidator(object key, params object[] args)
        {
            return this.Get(ResourceParams.Section.Global, ResourceParams.Group.Validator, key, args);
        }

        /// <summary>Gets a global localized validator text from the <paramref name="key"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="key">the resource key. </param>
        /// <param name="args">an array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// the localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// the pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <c>Validator</c> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobalValidator(CultureInfo culture, object key, params object[] args)
        {
            return this.Get(culture, ResourceParams.Section.Global, ResourceParams.Group.Validator, key, args);
        }

        /// <summary>Gets a global localized text from the <paramref name="key"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="group">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobal(object group, object key, params object[] args)
        {
            return this.Get(ResourceParams.Section.Global, group, key, args);
        }

        /// <summary>Gets a global localized text from the <paramref name="key"/> and <paramref name="group"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="group">The <see cref="Object"/> group name in the global section. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <c>Global</c>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string GetGlobal(CultureInfo culture, object group, object key, params object[] args)
        {
            return this.Get(culture, ResourceParams.Section.Global, group, key, args);
        }

        #endregion

        #region Get

        /// <summary>Gets a localized text from the <paramref name="key"/>, <paramref name="group"/> and <paramref name="section"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> section name in the resource file. </param>
        /// <param name="group">The <see cref="Object"/> group name in the <paramref name="section"/>. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <paramref name="section"/>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string Get(object section, object group, object key, params object[] args)
        {
            return this.Get(new object[] { section }, group, key, args);
        }

        /// <summary>Gets a localized text from the <paramref name="key"/>, <paramref name="group"/> and section item of <paramref name="sections"/> array possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">An <paramref name="Array"/> of section in the resource file. try the first item in array then the second etc. stop at end or array or when found the localized text. </param>
        /// <param name="group">The <see cref="Object"/> group name of the section item in <paramref name="sections"/> array. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the first pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is the first section of <paramref name="sections"/>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string Get(Array sections, object group, object key, params object[] args)
        {
            return Get(CultureInfo.CurrentUICulture, sections, group, key, args);
        }

        /// <summary>Gets a localized text from the <paramref name="key"/>, <paramref name="group"/> and <paramref name="section"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> section name in the resource file. </param>
        /// <param name="group">The <see cref="Object"/> group name in the <paramref name="section"/>. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <paramref name="section"/>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string Get(CultureInfo culture, object section, object group, object key, params object[] args)
        {
            return this.Get(culture, new object[] { section }, group, key, args);
        }

        /// <summary>Gets a localized text from the <paramref name="key"/>, <paramref name="group"/> and section item of <paramref name="sections"/> array possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">An <paramref name="Array"/> of section in the resource file. try the first item in array then the second etc. stop at end or array or when found the localized text. </param>
        /// <param name="group">The <see cref="Object"/> group name of the section item in <paramref name="sections"/> array. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the first pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is the first section of <paramref name="sections"/>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string Get(CultureInfo culture, Array sections, object group, object key, params object[] args)
        {
            if (Enabled)
            {
                if (Validation.IsSet(sections))
                {
                    foreach (object section in sections)
                    {
                        string __key = GetKey(section, group, key);
                        if (this.Exist(culture, __key))
                        {
                            return this.Get_Trad(culture, __key, args);
                        }
                    }
                    return this.GetMarker(sections, group, key);
                }
                else
                {
                    string __key = GetKey(null, group, key);
                    if (this.Exist(__key))
                    {
                        return this.Get_Trad(culture, __key, args);
                    }
                    return this.GetMarker(null, group, key);
                }
            }
            else
            {
                return this.GetMarker(sections, group, key);
            }
        }

        /// <summary>Gets a localized text from the <paramref name="key"/>, <paramref name="group"/> and <paramref name="section"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> section name in the resource file. </param>
        /// <param name="group">The <see cref="Object"/> group name in the <paramref name="section"/>. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <paramref name="section"/>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string Get(object section, Array groups, object key, params object[] args)
        {
            return this.Get(CultureInfo.CurrentUICulture, new object[] { section }, groups, key, args);
        }

        /// <summary>Gets a localized text from the <paramref name="key"/>, <paramref name="group"/> and section item of <paramref name="sections"/> array possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">An <paramref name="Array"/> of section in the resource file. try the first item in array then the second etc. stop at end or array or when found the localized text. </param>
        /// <param name="group">The <see cref="Object"/> group name of the section item in <paramref name="sections"/> array. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the first pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is the first section of <paramref name="sections"/>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string Get(Array sections, Array groups, object key, params object[] args)
        {
            return Get(CultureInfo.CurrentUICulture, sections, groups, key, args);
        }

        /// <summary>Gets a localized text from the <paramref name="key"/>, <paramref name="group"/> and <paramref name="section"/> possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="section">The <see cref="Object"/> section name in the resource file. </param>
        /// <param name="group">The <see cref="Object"/> group name in the <paramref name="section"/>. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is <paramref name="section"/>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string Get(CultureInfo culture, object section, Array groups, object key, params object[] args)
        {
            return this.Get(culture, new object[] { section }, groups, key, args);
        }

        /// <summary>Gets a localized text from the <paramref name="key"/>, <paramref name="group"/> and section item of <paramref name="sections"/> array possibly combined with some arguments (<paramref name="args"/>). </summary>
        /// <param name="sections">An <paramref name="Array"/> of section in the resource file. try the first item in array then the second etc. stop at end or array or when found the localized text. </param>
        /// <param name="group">The <see cref="Object"/> group name of the section item in <paramref name="sections"/> array. </param>
        /// <param name="key">The <see cref="Object"/> resource key in <paramref name="group"/>. </param>
        /// <param name="args">An array of <see cref="Object"/> that represent values inserted in the localized text. </param>
        /// <returns>
        /// The localized value combined with <paramref name="args"/> if specified, otherwise the first pattern that it try to find. 
        /// The pattern has this format <c>"section.group.key"</c>, 
        /// where section is the first section of <paramref name="sections"/>, group section is <paramref name="group"/> and resource key is <paramref name="key"/>.
        /// </returns>
        public string Get(CultureInfo culture, Array sections, Array groups, object key, params object[] args)
        {
            if (Enabled)
            {
                if (Validation.IsSet(sections))
                {
                    foreach (object section in sections)
                    {
                        if (Validation.IsSet(groups))
                        {
                            foreach (object group in groups)
                            {
                                string __key = GetKey(section, group, key);
                                if (this.Exist(culture, __key))
                                {
                                    return this.Get_Trad(culture, __key, args);
                                }
                            }
                        }
                        else
                        {
                            string __key = GetKey(section, null, key);
                            if (this.Exist(culture, __key))
                            {
                                return this.Get_Trad(culture, __key, args);
                            }
                        }
                    }
                    return this.GetMarker(sections, groups, key);
                }
                else
                {
                    if (Validation.IsSet(groups))
                    {
                        foreach (object group in groups)
                        {
                            string __key = GetKey(null, group, key);
                            if (this.Exist(culture, __key))
                            {
                                return this.Get_Trad(culture, __key, args);
                            }
                        }
                    }
                    else
                    {
                        string __key = GetKey(null, null, key);
                        if (this.Exist(culture, __key))
                        {
                            return this.Get_Trad(culture, __key, args);
                        }
                    }
                    return this.GetMarker(null, groups, key);
                }
            }
            else
            {
                return this.GetMarker(sections, groups, key);
            }
        }

        #endregion

        /// <summary>Clears all previously loaded resource. </summary>
        public void Reset()
        {
            _resources = new ListDictionary();
            _syncObjects = new ListDictionary();
        }

        /// <summary>Determines whether some localized resource exist with the specified <paramref name="key"/> in <paramref name="group"/> of the Global section. </summary>
        /// <param name="group">The <see cref="String"/> group name in the <c>Global</c> section resource file. </param>
        /// <param name="key">The <see cref="String"/> resource key in group. </param>
        /// <returns><see langword="true"/> if exist otherwise <see langword="false"/>. </returns>
        public bool ExistGlobal(string group, string key)
        {
            return this.Exist(ResourceParams.Section.Global, group, key);
        }

        /// <summary>Determines whether some localized resource exist with the specified <paramref name="key"/>, <paramref name="group"/> and array of section (<paramref name="sections"/>). </summary>
        /// <param name="sections">An <see cref="Array"/> of section name to check. </param>
        /// <param name="group">The <see cref="Object"/> group name in each section. </param>
        /// <param name="key">The <see cref="Object"/> resource key in group name. </param>
        /// <returns><see langword="true"/> if exist otherwise <see langword="false"/>. </returns>
        public bool Exist(Array sections, object group, object key)
        {
            foreach (object __section in sections)
            {
                if (this.Exist(GetKey(__section, group, key))) return true;
            }
            return false;
        }

        /// <summary>Determines whether some localized resource exist with the specified <paramref name="key"/>, <paramref name="group"/> and <paramref name="section"/>. </summary>
        /// <param name="section">The <see cref="Object"/> section name in the resource file. </param>
        /// <param name="group">The <see cref="Object"/> group name in each section. </param>
        /// <param name="key">The <see cref="Object"/> resource key in group name. </param>
        /// <returns><see langword="true"/> if exist otherwise <see langword="false"/>. </returns>
        public bool Exist(object section, object group, object key)
        {
            return this.Exist(GetKey(section, group, key));
        }

        public bool ExistLabel(Array sections, object group)
        {
            foreach (object __section in sections)
            {
                if (this.Exist(GetKey(__section, group, ResourceParams.Key.Label))) return true;
            }
            return false;
        }

        public bool ExistLabel(object section, object group)
        {
            return this.Exist(GetKey(section, group, ResourceParams.Key.Label));
        }

        public bool ExistData(Array sections, object group)
        {
            foreach (object __section in sections)
            {
                if (this.Exist(GetKey(__section, group, ResourceParams.Key.Data))) return true;
            }
            return false;
        }

        public bool ExistData(object section, object group)
        {
            return this.Exist(GetKey(section, group, ResourceParams.Key.Data));
        }

        public bool Exist(string key)
        {
            return this.Exist(CultureInfo.CurrentUICulture, key);
        }

        public bool Exist(CultureInfo culture, string key)
        {
            string __cultureCode = culture.TwoLetterISOLanguageName;
            if (!_resources.Contains(__cultureCode) || Validation.IsNull(_resources[__cultureCode]))
            {
                if (this.Load(__cultureCode)) return this.ExistValue(key, __cultureCode);
                else return false;
            }
            return this.ExistValue(key, __cultureCode);
        }

        private bool ExistValue(string key, string cultureCode)
        {
            Hashtable __resource = _resources[cultureCode] as Hashtable;
            if (Validation.IsNull(__resource)) return false;
            string __key = Conversion.ToString(key).ToUpper();
            return __resource.ContainsKey(__key);
        }

        public string Get_Trad(string key, params object[] args)
        {
            return this.Get_Trad(CultureInfo.CurrentUICulture, key, args);
        }

        public string Get_Trad(CultureInfo culture, string key, params object[] args)
        {
            string __cultureCode = culture.TwoLetterISOLanguageName;//CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
            if (!_resources.Contains(__cultureCode) || Validation.IsNull(_resources[__cultureCode]))
            {
                if (!this.Load(__cultureCode)) return string.Empty;
            }
            string __resource = GetValue(key, __cultureCode);
            if (args.Length > 0)
            {
                try
                {
                    __resource = string.Format(__resource, args);
                }
                catch (Exception) { }
            }
            return __resource;
        }

        private string GetValue(string key, string cultureCode)
        {
            string __key = Conversion.ToString(key).ToUpper();
            object __value = ((Hashtable)_resources[cultureCode])[__key];
            if (Validation.IsSet(__value)) return Conversion.ToString(__value);
            return string.Empty;
        }

        private string GetMarker(object section, object group, object key)
        {
            return string.Format(PatternMarker, section, group, key).ToUpper();
        }

        private string GetMarker(Array sections, object group, object key)
        {
            return string.Format(PatternMarker, StringHelper.SlashNString(sections), group, key).ToUpper();
        }

        private string GetMarker(object section, Array groups, object key)
        {
            return string.Format(PatternMarker, section, StringHelper.SlashNString(groups), key).ToUpper();
        }

        private string GetMarker(Array sections, Array groups, object key)
        {
            return string.Format(PatternMarker, StringHelper.SlashNString(sections), StringHelper.SlashNString(groups), key).ToUpper();

        }

        public static string GetKey(object section, object group, object key)
        {
            return string.Format(PatternKey, section, group, key);
        }

        private bool Load(string cultureCode)
        {
            Hashtable __resources = new Hashtable();
            QXPDiagnostic.Performance __perf = new QXPDiagnostic.Performance();
            if (!_syncObjects.Contains(cultureCode)) _syncObjects.Add(cultureCode, new object());
            lock (_syncObjects[cultureCode])
            {
                if (_resources.Contains(cultureCode))
                {
                    return true;
                }
                //				//INFO: Then load user resources
                //				foreach(string __fileName in this.ResourceFiles(cultureCode)){
                try
                {
                    __resources = this.LoadData(cultureCode);
                    System.Diagnostics.Debug.WriteLine(__perf.GetTotalMilliseconds(string.Format("LoadResource on culture '{0}' with {1} locale(s)", cultureCode, __resources.Count)));
                }
                catch (Exception ex)
                {
                    //INFO: log exception;
                    //System.Diagnostics.Debug.WriteLine(e.ToString());
                    QXPDiagnostic.Log.LogError("ResourceManager Load", ex);
                    return false;
                }
                finally
                {
                    if (_resources.Contains(cultureCode)) _resources[cultureCode] = __resources;
                    else _resources.Add(cultureCode, __resources);
                }
            }
            return true;
        }

        private Hashtable LoadData(string cultureCode)
        {
            ResourcesProxy __proxy = new ResourcesProxy();
            Hashtable __resources = __proxy.GetResources(cultureCode);
            return __resources;
        }

        public bool ExistLocales(string cultureName)
        {
            if (Validation.IsNotSet(cultureName)) return false;
            try
            {
                CultureInfo __culture = new CultureInfo(cultureName);
                string __cultureFilePath = QXPIO.FileHelper.GetFileName(SubPath, __culture.TwoLetterISOLanguageName, FileName);
                return File.Exists(__cultureFilePath);
            }
            catch
            {
                return false;
            }
        }

        #region miscellaneous resource functions

        /// <summary>Gets an <see cref="IDictionary"/> Localized messages for the items key <see cref="Array"/> <paramref name="RS"/> sections and <paramref name="RK"/> key of <see cref="Type"/> <paramref name="itemKeyType"/>. </summary>
        /// <param name="RS">The <see cref="Array"/> of resource sections. </param>
        /// <param name="RK">The <see cref="Enum"/> common resource key. </param>
        /// <param name="items">The <see cref="Array"/> of resource group used to localize the resource. </param>
        /// <param name="itemKeyType">The <see cref="Type"/> of the key returned with the localized <see cref="IDictionary"/>. </param>
        /// <returns>The <see cref="IDictionary"/> that can enumerate localized message. </returns>
        public IDictionary GetLocalizedArray(Array RS, object RK, Array items, System.Type itemKeyType)
        {
            if (RS == null) throw new ArgumentNullException("RS");
            if (RK == null) throw new ArgumentNullException("RK");
            if (items == null) throw new ArgumentNullException("items");
            if (itemKeyType == null) throw new ArgumentNullException("itemKeyType");

            int __arraySize = items.Length;
            ListDictionary __localizedArray = new ListDictionary();
            Array __items = Array.CreateInstance(itemKeyType, __arraySize);
            Array.Copy(items, 0, __items, 0, __arraySize);

            for (int __itemIdx = 0; __itemIdx < __arraySize; __itemIdx++)
            {
                __localizedArray.Add(__items.GetValue(__itemIdx), Get(RS, items.GetValue(__itemIdx), RK));
            }
            return __localizedArray;
        }

        /// <summary>Gets an <see cref="IDictionary"/> Localized messages of a specified <paramref name="enumType"/> <see cref="Type"/> for the item key <paramref name="RK"/> and <paramref name="RS"/> sections. </summary>
        /// <param name="RS">The <see cref="Array"/> of resource sections. </param>
        /// <param name="RK">The resource key. </param>
        /// <param name="enumType">The <see cref="Type"/> of the Enum to translate. </param>
        /// <returns>An <see cref="IDictionary"/> that can enumerate localized message. </returns>
        /// <exception cref="ArgumentException"> was throw if <paramref name="enumType"/> is not an Enum <see cref="Type"/>. </exception>
        public IDictionary GetLocalizedEnum(Array RS, object RK, Type enumType)
        {
            if (!enumType.IsEnum) throw new ArgumentException();
            return GetLocalizedArray(RS, RK, Enum.GetValues(enumType), ValueType.CLSint32);
        }

        #endregion

        #region global Traduction

        public string GetOperationDoneMessage()
        {
            return GetGlobalMessage(ResourceParams.Group.OperationDone);
        }

        public string GetOperationDoneMessage(CultureInfo culture)
        {
            return GetGlobalMessage(culture, ResourceParams.Group.OperationDone);
        }

        public string GetOperationFailedMessage()
        {
            return GetGlobalMessage(ResourceParams.Group.OperationFailed);
        }

        public string GetOperationFailedMessage(CultureInfo culture)
        {
            return GetGlobalMessage(culture, ResourceParams.Group.OperationFailed);
        }

        #endregion

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
