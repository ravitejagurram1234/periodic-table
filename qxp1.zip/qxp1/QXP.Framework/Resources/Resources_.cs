using System;

namespace QXP.Framework.Resources
{
    public class ResourceParams
    {
        public enum Section
        {
            Global,
            Framework,
            Composant,
            Control,
            NoScript,
            Requete_Edition,
        }
        public enum Group
        {
            Title,
            Command,
            ErrorMsg,
            InfoMsg,
            Validator,
            ToolTip,
            Exceptions,
            OperationDone,
            OperationFailed,
            Collapse,
            Expand,
            InvalidPanel
        }
        public enum Key
        {
            Label,
            ToolTip,
            LabelOfMin,
            ToolTipOfMin,
            LabelOfMax,
            ToolTipOfMax,
            Message,
            Data,
            RequiredMessage,
            RangeMinMessage,
            RangeMaxMessage,
            RangeFullMessage,
            RequiredMessageOfMin,
            RangeMinMessageOfMin,
            RangeMaxMessageOfMin,
            RangeFullMessageOfMin,
            RequiredMessageOfMax,
            RangeMinMessageOfMax,
            RangeMaxMessageOfMax,
            RangeFullMessageOfMax,
            CompareRangedControls,
            GreaterThanEqual,
            Greater,
            LesserThanEqual,
            Lesser,
        }
    }

    public enum LangueTravail
    {
        Espagnol = 15,
        Fran�ais = 10,
        Anglais = 12,
        Italien = 3,
    }
}
