using System;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Globalization;
using System.Threading;
using System.Xml;

using QXPApplication			= QXP.Framework.Application;
using QXPDiagnostic				= QXP.Framework.Diagnostic;
using QXPIO						= QXP.Framework.IO;

namespace QXP.Framework.Resources.Admin
{
	#region Importations XML Files
	/// <summary>Provides methods to retrieve localized message. </summary>
	public class			ResourceAdmin
	{
		/// <summary>Represents the base folder for all localized resource files. </summary>
		/// <remarks>Each culture must have a sub folder where his name is it's TwoISOCode. for exemple FR for French culture. </remarks>
		public const string SubPath		= "Culture";
		/// <summary>The full file name of a localized resource file. </summary>
		public const string FileName	= "Locales.xml";
		/// <summary>Creates a new instance of <see cref="ResourceHelper"/> class.</summary>

		public static void	ImportLocales()
		{
		
		}
		public static void	ImportLocaleFile(string cultureCode)
		{
				string __fileName = QXPIO.FileHelper.GetFileName(SubPath, cultureCode, FileName);;
				if(File.Exists(__fileName)){
					Uri			__localeStoreURI	= new Uri(__fileName);
					XmlDocument __localeStore		= new XmlDocument();
					__localeStore.Load(__localeStoreURI.AbsoluteUri);

					//INFO: Define XSD Schema used by de XML File, this is Mandatory or SelectNode return nothing..
					XmlNamespaceManager	__nsmng = new XmlNamespaceManager(__localeStore.NameTable);
					__nsmng.AddNamespace("nsLocales", @"http://QXP.Framework/Locales/Schema");

					XmlNodeList __nodes	= __localeStore.SelectNodes("//nsLocales:Item", __nsmng); // "//Section//child::*/Item");
						
					Res_Locales		__locales = new Res_Locales();
					Res_Section		__section;
					Res_Group		__group;
					Res_Item		__item;
					
					__locales.CultureCode = cultureCode;
					foreach(XmlNode __node in __nodes)
					{
						string __value;
						string __section_Name	= __node.ParentNode.ParentNode.Attributes[0].Value;
						string __group_Name		= __node.ParentNode.Attributes[0].Value;
						string __item_Key		= __node.Attributes[0].Value;
						__section	= __locales.GetSection(__section_Name);
						__group		= __section.GetGroup(__group_Name);
						__item		= __group.GetItem(__item_Key);

						//string __key = StringHelper.Dot3String(__locale.ParentNode.ParentNode.Attributes[0].Value, __locale.ParentNode.Attributes[0].Value, __locale.Attributes[0].Value);
						if(__node.Attributes.Count > 1)	__value	=	__node.Attributes[1].Value;
						else							__value	=	__node.InnerText;
						__item.Value = __value;
					}
					SaveLocales(__locales);
				}
				else
				{
					//INFO: log Unable to find resource file! !!
					System.Diagnostics.Debug.WriteLine(string.Format("Unable to find ressource file {0}", __fileName));
				}
			//TODO: Locales update data Base
		}
		public static void	Update_CommentaireRK(string cultureCode){
			ResourcesProxy	__proxy = new ResourcesProxy();
			__proxy.UpdateCommentaireRK(cultureCode);
		}
		static void			SaveLocales(Res_Locales locales){
			ResourcesProxy	__proxy = new ResourcesProxy(locales.CultureCode);
			int				__id;
			try
			{
				foreach(Res_Section section in locales.Sections)
				{
					__id = __proxy.AddRS(section);
					if(Validation.IsSet(__id))
					{
						section.ID = __id;
						foreach(Res_Group group in section.Groups)
						{
							__id = __proxy.AddRG(group, section.ID);
							if(Validation.IsSet(__id))
							{
								group.ID = __id;
								__proxy.Asso_RS_RG(section.ID, group.ID);
								foreach(Res_Item item in group.Items)
								{
									__id = __proxy.AddRK(item, group.ID);
									if(Validation.IsSet(__id))
									{
										item.ID = __id;
										__proxy.Asso_RG_RK(group.ID, item.ID);
										__proxy.AddRK_Trad(item);
									}
								}
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				QXPDiagnostic.Log.LogError("SaveLocales", ex);
			}
			finally{
				__proxy.Close();
			}
		}
	}
	public class			Res_Locales
	{
		#region internal variables
		Hashtable	_sections =  new Hashtable();
		string		_cultureCode;
		#endregion
		public Res_Section	GetSection(string sectionName)
		{
			if(_sections.ContainsKey(sectionName))
			{
				return _sections[sectionName] as Res_Section;
			}
			else
			{
				Res_Section __section = new Res_Section();
				__section.Name = sectionName;
				_sections.Add(sectionName, __section);
				return __section;
			}
		}
		public string		CultureCode{
			get{return _cultureCode;}
			set{_cultureCode = value;}
		}
		public ICollection	Sections{
			get{return _sections.Values;}
		}
	}
	public class			Res_Section{
		#region internal variables
		int		_id;
		string	_name;
		Hashtable _groups = new Hashtable();
		#endregion
		public Res_Section(){}
		public int				ID{
			get{return _id;}
			set{_id = value;}
		}
		public string			Name
		{
			get{return _name;}
			set{_name = value;}
		}
		
		public Res_Group		GetGroup(string groupName)
		{
			if(_groups.ContainsKey(groupName))
			{
				return _groups[groupName] as Res_Group;
			}
			else
			{
				Res_Group __group = new Res_Group();
				__group.Name = groupName;
				_groups.Add(groupName, __group);
				return __group;
			}
		}
	
		public ICollection		Groups
		{
			get{return _groups.Values;}
		}
	}
	public class			Res_Group
	{
		#region internal variables
		int		_id;
		string		_name;
		ArrayList	_items = new ArrayList();
		#endregion
		public Res_Group(){}
		public int				ID
		{
			get{return _id;}
			set{_id = value;}
		}
		public string		Name
		{
			get{return _name;}
			set{_name = value;}
		}
			
		public Res_Item		GetItem(string itemCode)
		{
			Res_Item __item = new Res_Item();
			__item.Code = itemCode;
			_items.Add(__item);
			return __item;
		}
		
		public ICollection	Items
		{
			get{return _items;}
		}
	}
	public class			Res_Item{
		#region internal variables
		int		_id;
		string _code;
		string _value;
		#endregion
		public Res_Item(){}
		public int				ID
		{
			get{return _id;}
			set{_id = value;}
		}
		public string			Code
		{
			get{return _code;}
			set{_code = value;}
		}
		public string			Value
		{
			get{return _value;}
			set{_value = value;}
		}
	}
	#endregion
	#region Admin Tables
	public class			Res_RS{
		#region internal variables
		int			_id;
		string		_name;
		#endregion	
		public Res_RS(int id, string name){
			_id		= id;
			_name	= name;
		}
		public int ID{
			get{return _id;}
		}
		public string Name
		{
			get{return _name;}
		}
	}
	public class			Res_RG
	{
		#region internal variables
		int			_id;
		string		_name;
		#endregion	
		public Res_RG(int id, string name)
		{
			_id		= id;
			_name	= name;
		}
		public int ID
		{
			get{return _id;}
		}
		public string Name
		{
			get{return _name;}
		}
	}
	public class			Res_RK
	{
		#region internal variables
		int			_id;
		string		_code;
		string		_commentaire;
		Hashtable	_rk_trads = new Hashtable();
		#endregion
		public Res_RK(int id, string code, string commentaire)
		{
			_id				= id;
			_code			= code;
			_commentaire	= commentaire;
		}
		public	int			ID{
			get{return _id;}
		}
		public string		Code
		{
			get{return _code;}
		}
		public string		Commentaire
		{
			get{return _commentaire;}
		}
		public Hashtable	Trads{
			get{return _rk_trads;}
		}
	}
	public class			Res_RK_Trad
	{
		#region internal variables
		int			_id;
		int			_id_langue;
		string		_value;
		#endregion
		public Res_RK_Trad(int id, int id_langue, string value)
		{
			_id			= id;
			_id_langue	= id_langue;
			_value		= value;
		}
		public	int		ID
		{
			get{return _id;}
		}
		public	int		ID_Langue
		{
			get{return _id_langue;}
		}
		public	string	Value
		{
			get{return _value;}
		}
	}

	#endregion
}
