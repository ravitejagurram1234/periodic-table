


/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Resources
{
    /// <summary>
    /// Objet Object_Resource
    /// </summary>
    /// <author>cueffl</author>
    /// <date>19/01/2011 11:53:04</date>    
    public class Object_Resource
    {
        #region Membres

        string _rs;
        ResourceInfo _resourceInfo;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Object_Resource
        /// </summary>
        public Object_Resource()
            : base()
        {
            this.InitRessourceInfo();
        }

        #endregion Constructeur

        #region M�thodes

        private void InitRessourceInfo()
        {
            _resourceInfo = new ResourceInfo(this);
        }


        #endregion M�thodes

        #region Propri�t�s

        public ResourceInfo ResourceInfo
        {
            get { return _resourceInfo; }
        }

        #endregion Propri�t�s
    }
}
