using System;

/* 
 * Code g�n�r� avec le template project : QXP.ProjectTemplate
*/
namespace QXP.Framework
{
    /// <summary>
    /// Ensembles des �num�rations communes au module QXP.Framework
    /// </summary>
    /// <author>touxb</author>
    /// <date>03/02/2012 09:36:31</date>    
    public class Enums
    {

    }
}
