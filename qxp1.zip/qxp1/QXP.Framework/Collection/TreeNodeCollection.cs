using System;
using System.Collections.Generic;


namespace QXP.Framework.Collection{
	
	/// <summary>
	/// 
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public class TreeNodeCollection<T>: List<T> where T: TreeNode<T>
	{
		private	T			_parent;

		/// <summary>
		/// 
		/// </summary>
		public TreeNodeCollection(){}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="parent"></param>
		public TreeNodeCollection(T parent)
		{
			_parent = parent;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="item"></param>
		/// <returns></returns>
		public new  T				Add(T item)
		{
			UpdateItem(item);
			base.Add(item);
			return item;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="items"></param>
		/// <returns></returns>
		public new  IEnumerable<T>	AddRange(IEnumerable<T> items)
		{
			foreach (T __item in items)
			{
				UpdateItem(__item);
			}
			
			base.AddRange(items);
			return items;
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="index"></param>
		/// <param name="item"></param>
		/// <returns></returns>
		public new  T				Insert(int index, T item)
		{
			UpdateItem(item);
			base.Insert(index, item);
			return item;
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="index"></param>
		/// <param name="items"></param>
		/// <returns></returns>
		public new  IEnumerable<T>	InsertRange(int index, IEnumerable<T> items)
		{
			foreach (T __item in items)
			{
				UpdateItem(__item);
			}
			
			base.InsertRange(index, items);
			return items;
		}
		
		///// <summary>
		///// 
		///// </summary>
		///// <param name="match"></param>
		///// <returns></returns>
		//public T		Find(Predicate<T> match)
		//{
		//    return _list.Find(match);
		//}

		///// <summary>
		///// 
		///// </summary>
		///// <param name="match"></param>
		///// <returns></returns>
		//public List<T>	FindAll(Predicate<T> match)
		//{
		//    return _list.FindAll(match);
		//}

		/// <summary>
		/// Retrouve tous les noeuds dans toute la hierarchie.
		/// </summary>
		/// <param name="match"></param>
		/// <returns></returns>
		public List<T>				GetAll_Deep()
		{
			List<T> __deep = new List<T>();
			foreach (T node in this)
			{
				__deep.Add(node);
				__deep.AddRange(node.Nodes.GetAll_Deep());
			}

			return __deep;
		}

		/// <summary>
		/// Retrouve tous les noeuds correspondant au predicate ( dans toute la hierarchie)
		/// </summary>
		/// <param name="match"></param>
		/// <returns></returns>
		public List<T>				FindAll_Deep(Predicate<T> match)
		{
			// Genere une liste r�pondant aux crit�res match
			List<T> __deep = this.FindAll(match);
			foreach (T node in this)
			{
				__deep.AddRange(node.Nodes.FindAll_Deep(match));
			}

			return __deep;
		}

		/// <summary>
		/// Retrouve le premier noeud correspondant au predicate ( dans toute la hierarchie )
		/// </summary>
		/// <param name="match"></param>
		/// <returns></returns>
		public T					Find_Deep(Predicate<T> match)
		{
			// Genere une liste r�pondant aux crit�res match
			T __item = this.Find(match);
			if(Validation.IsNotNull(__item)) return __item;
			foreach (T __node in this)
			{
				__item = __node.Nodes.Find_Deep(match);
				if(Validation.IsNotNull(__item)) return __item;
			}

			return null;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="item"></param>
		private void				UpdateItem(T item)
		{
			item.Parent = _parent;
		}

		/// <summary>
		/// Permet d'appliquer une action � tout les noeuds de la hierarchie
		/// </summary>
		/// <param name="action">action � r�aliser. </param>
		public void					ActionAll_Deep(Action<T> action)
		{
			foreach (T __node in this)
			{
				action(__node);
				__node.Nodes.ActionAll_Deep(action);
			}
		}
	}
}
