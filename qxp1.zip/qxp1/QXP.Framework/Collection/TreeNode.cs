using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

using QXPFrk					= QXP.Framework;

namespace QXP.Framework.Collection{
	/// <summary>
	/// 
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public class TreeNode<T> where T: TreeNode<T>
	{
		private bool					_checked	= false;
		private bool					_visible	= true;
		private T						_parent		= null;
	    private TreeNodeCollection<T>	_nodes		= null;
		
		
	    /// <summary>
	    /// Niveau du menu dans la hierarchie
		/// Si ce menu n'a pas de parent sont niveau est 0
	    /// </summary>
		public int						Level
	    {
	        get{
				if(QXPFrk.Validation.IsNull(_parent)){
					return 0;
				}
				return _parent.Level + 1;
			}
	    }

		/// <summary>
		/// Permet d'appliquer une action � tout les noeuds de la hierarchie
		/// </summary>
		/// <param name="action">action � r�aliser. </param>
		public void						ActionAll_Deep(Action<T> action)
		{
			action(this as T);
			this.Nodes.ActionAll_Deep(action);
		}

		public void						RemoveAll_Deep(Predicate<T> match)
		{
			//1 - Supprimer ce qui ne correspond pas au match
			this.Nodes.RemoveAll(match);

			//2 - Les restants on test les match pour les fils et ainsi de suite...
			foreach (T __node in this.Nodes)
			{
			   __node.RemoveAll_Deep(match);
			}
		}
		public virtual T				Clone(){
			T __clone = Activator.CreateInstance<T>();
			
			foreach(T __node in this.Nodes){
				__clone.Nodes.Add(__node.Clone());
			}
			return __clone;
		}
		
	    /// <summary>
	    /// 
	    /// </summary>
		public TreeNodeCollection<T>	Nodes
	    {
	        get
	        {
	            if(Validation.IsNull(_nodes))
	            {
	                _nodes = new TreeNodeCollection<T>(this as T);
	            }
	            return _nodes;
	        }
	    }

	    /// <summary>
	    /// 
	    /// </summary>
		public T						Parent
	    {
	        get{ return _parent;}
			internal set{ _parent = value;}
	    }

		/// <summary>
		/// Permet de d�finir si ce noeud est selectionn�
		/// </summary>
		public bool						Checked
		{
			get{ return _checked;}
			set{  _checked = value;}
		}
		
		/// <summary>
		/// Permet de d�finir si ce noeud est visible
		/// </summary>
		public bool						Visible
		{
			get{ return _visible;}
			set{  _visible = value;}
		}
	}

}
