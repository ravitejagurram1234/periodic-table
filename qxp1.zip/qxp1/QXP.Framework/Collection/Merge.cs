using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Collection
{
    /// <summary>
    /// Class Merge permet d'effectuer des fusions de collections/listes.
    /// </summary>
    /// <author>cueffl</author>
    /// <date>17/04/2009 11:31:28</date>    
    public class Merge
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Retourne un IEnumerable tri� contenant les �lements de l'iEnum1 + l'iEnum2 � condition que les elts de l'iEnum2 ne soient pas d�j� pr�sent dans l'iEnum1. 
        /// </summary>
        /// <typeparam name="T">Type des �lements contenu dans chaque IEnumerable</typeparam>
        /// <param name="iEnum1">IEnumerable 1</param>
        /// <param name="iEnum2">IEnumerable 2</param>
        /// <param name="comparer">Si diff�rent de null, est utilis� pour compar� les �lements des deux IEnumerables</param>
        /// <returns>Un IEnumerable contenant le merge des IEnumerables</returns>
        public static IEnumerable<T> MergeEnumerable<T>(IEnumerable<T> iEnum1, IEnumerable<T> iEnum2, IComparer<T> comparer)
            where T : IComparable<T>
        {
            if (Validation.IsNull(iEnum1) && Validation.IsNull(iEnum2))
                    return null;

            if (Validation.IsNotNull(iEnum1) && Validation.IsNull(iEnum2))
                    return iEnum1;

            if (Validation.IsNull(iEnum1) && Validation.IsNotNull(iEnum2))
                    return iEnum2;
                

            List<T> __lstDest   = new List<T>(iEnum1);
            List<T> __lst       = new List<T>(iEnum2);
            
            //On recherche dans la liste __lst tous les elements qui ne sont pas pr�sents dans la liste de destination
            //Puis ces �lements sont ajout�s avec un addrange � la liste de destination
            __lstDest.AddRange
            (
                
                __lst.FindAll
                (
                    delegate(T __elt)
                    {
                        //On recherche l'�lement de la liste __lst dans la liste de destination
                        return !__lstDest.Exists
                        (
                            delegate(T __eltDest)
                            {
                                //Si un comparer est pass� en param�tre on l'utilise pour comparer 
                                if(Validation.IsNull(comparer))
                                    return __eltDest.CompareTo(__elt).Equals(0);
                                else
                                    return comparer.Compare(__eltDest, __elt).Equals(0);

                            }
                        );
                    }
                )
            );

            //On tri la liste retourn�e
            if(Validation.IsNotNull(comparer))
                __lstDest.Sort(comparer);
            else
                __lstDest.Sort();

            return __lstDest;
        }

        /// <summary>
        /// Retourne un IEnumerable tri� contenant les �lements de l'iEnum1 + l'iEnum2 � condition que les elts de l'iEnum2 ne soient pas d�j� pr�sent dans l'iEnum1. 
        /// </summary>
        /// <typeparam name="T">Type des �lements contenu dans chaque IEnumerable</typeparam>
        /// <param name="iEnum1">IEnumerable 1</param>
        /// <param name="iEnum2">IEnumerable 2</param>
        /// <returns>Un IEnumerable contenant le merge des IEnumerables</returns>
        public static IEnumerable<T> MergeEnumerable<T>(IEnumerable<T> iEnum1, IEnumerable<T> iEnum2)
            where T : IComparable<T>
        {
            return MergeEnumerable<T>(iEnum1, iEnum2, null);
        }

        /// <summary>
        /// Concatene deux IEnumerable
        /// </summary>
        /// <typeparam name="T">Type des �lements contenus dans chaque IEnumerable</typeparam>
        /// <param name="iEnum1">IEnumerable 1</param>
        /// <param name="iEnum2">IEnumerable 2</param>
        /// <returns>La concatenation des deux IEnumerables</returns>
        public static IEnumerable<T> Concatene<T>(IEnumerable<T> iEnum1, IEnumerable<T> iEnum2)
        {
            List<T> __res         = new List<T>(iEnum1);
            __res.AddRange(iEnum2);
            return __res;
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
