using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;


namespace QXP.Framework.Serialization
{
	/// <summary>Provides methods to serialize/deserialize data. </summary>
	public class Serializer
	{
		//1Mo pour serialization de gros objects
        //Cette m�moire est ensuite lib�r�e � la fin de la s�rialization
        // cette valeur permet de ne pas fragmenter la m�moire g�r�e compact�. en utilisant une pile sp�cial d'objets larges.
        public static int LargeAllocationSize = 1048576; 
        #region internal variables
		#endregion
		private Serializer(){}
		/// <summary>Deserialize specified <paramref name="data"/> into an instance of specified <paramref name="objectType"/>. </summary>
		/// <param name="data">the string data to deserialize. </param>
		/// <param name="destinationType">The <see cref="Type"/> of the object type to create. </param>
		/// <returns>The instance of the create object. </returns>
		public	static object Deserialize(string data, Type destinationType)
		{
			XmlSerializer __xmlSerializer = new XmlSerializer(destinationType);
			return __xmlSerializer.Deserialize(new StringReader(data));
		}
		/// <summary>Deserialize specified <paramref name="fileName"/> into an instance of specified <paramref name="objectType"/>. </summary>
		/// <param name="fileName">the full file name used to retrieve string data to deserialize. </param>
		/// <param name="objectType">The <see cref="Type"/> of the object type to create. </param>
		/// <returns>The instance of the create object. </returns>
		public	static object DeserializeFromFile(string fileName, Type objectType)
		{
			return DeserializeFromFile(fileName, objectType, false);
		}
		public static object DeserializeFromFile(string fileName, Type objectType, bool ignoreNamespace){
			XmlSerializer __xmlSerializer = new XmlSerializer(objectType);
			XmlTextReader	__reader				= null;
			object				__object				= null;
			try
			{
				__reader			= new XmlTextReader(fileName);
				__reader.Namespaces	= !ignoreNamespace;
				__object			= __xmlSerializer.Deserialize(__reader);
			}
			finally
			{
				if(Validation.IsNotNull(__reader))
				{
					__reader.Close();
				}
			}
			return __object;
		}

        public static object DeserializeFromStream(Stream stream, Type objectType)
        {
            return DeserializeFromStream(stream, objectType, false);
        }

        public static object DeserializeFromStream(Stream stream, Type objectType, bool ignoreNamespace)
        {
            XmlSerializer __xmlSerializer = new XmlSerializer(objectType);
            XmlTextReader __reader = null;
            object __object = null;
            try
            {
                __reader = new XmlTextReader(stream);
                __reader.Namespaces = !ignoreNamespace;
                __object = __xmlSerializer.Deserialize(__reader);
            }
            finally
            {
                if (Validation.IsNotNull(__reader))
                {
                    __reader.Close();
                }
            }
            return __object;
        }

        public static object Deserialize(string stringToDeserialize, Type objectType, bool ignoreNamespace)
        {
            XmlSerializer __xmlSerializer = new XmlSerializer(objectType);
            XmlTextReader __reader = null;
            object __object = null;
            try
            {
                __reader = new XmlTextReader(new StringReader(stringToDeserialize));
                __reader.Namespaces = !ignoreNamespace;
                __object = __xmlSerializer.Deserialize(__reader);
            }
            finally
            {
                if (Validation.IsNotNull(__reader))
                {
                    __reader.Close();
                }
            }
            return __object;
        }




		/// <summary>Serialize the specified data object. </summary>
		/// <param name="data">The object instance to serialize. </param>
		/// <returns>The string serialized representation of the <paramref name="data"/> object. </returns>
		public	static string Serialize(object data)
		{
            return Serialize(data, false);
        }

		/// <summary>Serialize the specified data object. </summary>
		/// <param name="data">The object instance to serialize. </param>
		/// <returns>The string serialized representation of the <paramref name="data"/> object. </returns>
		public	static string Serialize(object data, bool largeAllocation)
		{
			if(Validation.IsNull(data))			return string.Empty;
            StringBuilder   __sb;
            //pour eviter les handles d'allocation inutile et la fragmentation de la m�moire !!
            //la methode empirique � determiner que les erreurs outofmemoryexception sont moins rare avec une allocation large de la m�moire utilis� par le stringwriter du serializer
            if(largeAllocation){
                __sb = new StringBuilder(LargeAllocationSize); //de 1Mo pour serialization de gros objects
            }else{
                __sb = new StringBuilder(); //Default Object for string writer !
            }
			Type			__type			= data.GetType();
			XmlSerializer   __serializer	= new XmlSerializer(__type);
			StringWriter	__sw			= new StringWriter(__sb);
			__serializer.Serialize(__sw, data);
			return __sw.ToString();
		}

		/// <summary>Serialize the data object into the specified filename. </summary>
		/// <param name="fileName">the full file name used to save the serialiazed object. </param>
		/// <param name="data">The object instance to serialize. </param>
		public	static void		SerializeToFile(string fileName, object data)
		{
			if(Validation.IsNull(data))			return;
			Type			__type			= data.GetType();
			XmlSerializer   __serializer	= new XmlSerializer(__type);
			FileStream		__fileStream	= null;

			try
			{
				__fileStream	= new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);
				__serializer.Serialize(__fileStream, data);
			}
			finally
			{
				if(Validation.IsNotNull(__fileStream))
				{
					__fileStream.Close();
				}
			}
		}

        
    }
}
