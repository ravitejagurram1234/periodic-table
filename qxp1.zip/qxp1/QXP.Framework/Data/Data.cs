using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.Reflection;

namespace QXP.Framework.Data{
	/// <summary>Provides methods to dynamically retrieves/set values for fields or properties on objects. </summary>
	public sealed class			DataBinder {
		private readonly static char[] _expressionPartSeparator;
		private readonly static char[] _indexExprStartChars;
		private readonly static char[] _indexExprEndChars;

		static DataBinder() {
			char[] __chars = new char[]{'.'};
			_expressionPartSeparator	= __chars;
			__chars										= new char[]{'[', '('};
			_indexExprStartChars			= __chars;
			__chars										= new char[]{']', ')'};
			_indexExprEndChars				= __chars;
		}
		/// <summary>Retrieves object or value from the <paramref name="container"/> evaluated by the <paramref name="expression"/>. </summary>
		/// <param name="container">the <see cref="Object"/> where to retrieve the object or value. </param>
		/// <param name="expression">the expression used to retrieve the object or value in the <paramref name="container"/>. </param>
		/// <returns>the boxed object or value if expression is matched, otherwise <see langword="null"/>. </returns>
		/// <remarks><paramref name="expression"/> could be an expression separated by '.' or an indexed expression. </remarks>
		/// <example>
		/// Sample 1
		/// An intance of <c>country</c> with a property <c>state</c>.
		/// the <paramref name="container"/> is <c>country</c> and expression is <c>"state"</c>
		/// result: you retrieve the <c>state</c> of the <c>country</c>.
		/// Sample 2
		/// An intance of <c>countries</c> that is a collection of <c>country</c> with a property <c>state</c>.
		/// the <paramref name="container"/> is <c>countries</c> and expression is <c>"[1].state"</c>
		/// result: you retrieve the <c>state</c> of the second country in <c>countries</c>.
		/// Sample 3
		/// An intance of <c>countries</c> that is a collection of <c>country</c> with a property <c>state</c> that has a property <c>zipcode</c>.
		/// the <paramref name="container"/> is <c>countries</c> and expression is <c>"[0].state.zipcode"</c>
		/// result: you retrieve the <c>zipcode</c> of the <c>state</c> of the first country in <c>countries</c>.
		/// </example>
		public	static object							Eval(object container, string expression) 
		{
			string[] __expressions = expression.Trim().Split(_expressionPartSeparator);
			return Eval(container, __expressions);
		}
		/// <summary>Retrieves string value from the <paramref name="container"/> evaluated by the <paramref name="expression"/>. </summary>
		/// <param name="container">the <see cref="Object"/> where to retrieve the object or value. </param>
		/// <param name="expression">the expression used to retrieve the object or value in the <paramref name="container"/>. </param>
		/// <param name="format">the string format used to display the result, otherwise <see langword="null"/> or <see cref="String.Empty"/>. </param>
		/// <returns>A <see cref="String"/> value formatted with <paramref name="format"/> if <paramref name="expression"/> is matched otherwise <see cref="String.Empty"/>. </returns>
		public	static string							Eval(object container, string expression, string format) 
		{
			object __local = Eval(container, expression);
			if (Validation.IsNull(__local))		return String.Empty;
			if (Validation.IsNotSet(format))	return __local.ToString();
			return	string.Format(format, __local);
		}
		private static object							Eval(object container, string[] expressionParts) {
			object __object = container;
			for (int i = 0; i < expressionParts.Length && Validation.IsNotNull(__object); i++) {
				string str = expressionParts[i];
				if (str.IndexOfAny(_indexExprStartChars) < 0)		__object = GetMemberValue(__object, str);
				else																						__object = GetIndexedPropertyValue(__object, str);
			}
			return __object;
		}
		private	static object							GetMemberValue(object container, string memberName) {
			return GetMemberValue(container, memberName, true);
		}
		private	static object							GetMemberValue(object container, string memberName, bool checkIfSet) {
			return GetMemberValue(container, memberName, checkIfSet, new object[0]);
		}
		private	static object							GetMemberValue(object container, string memberName, bool checkIfSet, object[] args) {
			object				__local		= null;
			object				__member;
			
			if(container is ICustomTypeDescriptor)	__member			= GetPropertyDescriptor(container, memberName, args);
			else																		__member			= GetMatchedMember(container, memberName, args);
			if(Validation.IsNull(__member)) return null; //INFO: nothing to Evaluate.
			if(__member is FieldInfo){
				__local = ((FieldInfo)__member).GetValue(container);
			}else if(__member is PropertyInfo){
				__local = ((PropertyInfo)__member).GetValue(container, args);
			}else if(__member is PropertyDescriptor){
				__local = ((PropertyDescriptor)__member).GetValue(container);
			}else{
				throw new ArgumentNullException(string.Format(Constantes.DataBinderInvalidMemberType, memberName, container.GetType().FullName));
			}
			if(checkIfSet && Validation.IsNotSet(__local))	return null;
			else											return __local;
		}
		private static MemberInfo					GetMatchedMember(object container, string memberName, object[] args){
			MemberInfo[]	__members	= container.GetType().GetMember(memberName); 
			//INFO:On FieldInfo and PropertyInfo there are allways only ONE Member !!! except on the indexer "this".
			MemberInfo		__member	= null;
			switch(__members.Length){
				case(0):
					throw new ArgumentNullException(string.Format(Constantes.DataBinderPropertyNotFound, memberName, container.GetType().FullName));
				case(1): //INFO: Common case
					__member = __members[0];
					break;
				default:
					//INFO there is more than one members : probably an indexer with one or more overload :)
					// in this case all members ARE propertyInfo Type.
					Type[] __types = new Type[args.Length]; // [0].k .GetType(); //retrieve the overload parameter type
					for(int i = 0; i < args.Length;i++){
						__types[i] = args[i].GetType();
					}
					foreach(MemberInfo __mbr in __members){
						PropertyInfo __property = __mbr as PropertyInfo;
						bool	__allMatched = true;
						int		__position = 0;
						foreach(ParameterInfo __parameter in __property.GetIndexParameters()){
							if(__parameter.ParameterType != __types[__position++]){
								__allMatched = false;
								break;
							}
						}
						if(__allMatched){
							__member = __mbr;
							break;
						}
					}
					break;
			}
			return __member;
		}
		private static PropertyDescriptor GetPropertyDescriptor(object container, string memberName, object[] args){
			PropertyDescriptor __propertyDescriptor = TypeDescriptor.GetProperties(container).Find(memberName, true);
			return __propertyDescriptor;
		}
		private	static object							GetIndexedPropertyValue(object container, string expr) {
			object	__obj1			= null;
			bool		__flag			= false;
			int			__i					= expr.IndexOfAny(_indexExprStartChars);
			int			__j					= expr.IndexOfAny(_indexExprEndChars, __i + 1);
			if (__i < 0 || __j < 0 || __j == __i + 1) throw new ArgumentNullException(string.Format(Constantes.DataBinderInvalidIndexUsed, expr));
			string	__string1		= null;
			object	__obj2			= null;
			string __string2		= expr.Substring(__i + 1, __j - __i - 1).Trim();
			if (__i != 0)				__string1 = expr.Substring(0, __i);
			if (__string2.Length != 0) {
				if (__string2[0] == '\"' && __string2[__string2.Length - 1] == '\"' || __string2[0] == '\'' && __string2[__string2.Length - 1] == '\'') {
					__obj2 = __string2.Substring(1, __string2.Length - 2);
				}
				else if (Char.IsDigit(__string2[0])) {
					try {
						__obj2 = Int32.Parse(__string2, CultureInfo.InvariantCulture);
						__flag = true;
					}catch (Exception){
						__obj2 = __string2;
					}
				}else {
					__obj2 = __string2;
				}
			}
			if (Validation.IsNull(__obj2)) throw new ArgumentNullException(string.Format(Constantes.DataBinderInvalidIndexUsed, expr));
			object __obj3 = null;
			if (Validation.IsSet(__string1))	__obj3 = GetMemberValue(container, __string1);
			else															__obj3 = container;
			if (Validation.IsNotNull(__obj3)) {
				if (__obj3 is Array && __flag) {
					__obj1 = ((object[])__obj3)[(int)__obj2];
				}else if (__obj3 is IList && __flag) {
					__obj1 = ((IList)__obj3)[(int)__obj2];
				}else {
					__obj1 = GetMemberValue(__obj3, "Item", true, new object[]{__obj2});
				}
			}
			return __obj1;
		}
		private	static string							GetIndexedPropertyValue(object container, string memberName, string format) {
			object __local = GetIndexedPropertyValue(container, memberName);
			if (Validation.IsNull(__local)) return String.Empty;
			return string.Format(format, __local);
		}
		private	static object							GetIndexedProperty(object container, string expr) {
			object	__obj1			= null;
			bool		__flag			= false;
			int			__i					= expr.IndexOfAny(_indexExprStartChars);
			int			__j					= expr.IndexOfAny(_indexExprEndChars, __i + 1);
			if (__i < 0 || __j < 0 || __j == __i + 1) throw new ArgumentNullException(string.Format(Constantes.DataBinderInvalidIndexUsed, expr));
			string	__string1		= null;
			object	__obj2			= null;
			string __string2		= expr.Substring(__i + 1, __j - __i - 1).Trim();
			if (__i != 0)				__string1 = expr.Substring(0, __i);
			if (__string2.Length != 0) {
				if (__string2[0] == '\"' && __string2[__string2.Length - 1] == '\"' || __string2[0] == '\'' && __string2[__string2.Length - 1] == '\'') {
					__obj2 = __string2.Substring(1, __string2.Length - 2);
				}
				else if (Char.IsDigit(__string2[0])) {
					try {
						__obj2 = Int32.Parse(__string2, CultureInfo.InvariantCulture);
						__flag = true;
					}catch (Exception){
						__obj2 = __string2;
					}
				}else {
					__obj2 = __string2;
				}
			}
			if (Validation.IsNull(__obj2)) throw new ArgumentNullException(string.Format(Constantes.DataBinderInvalidIndexUsed, expr));
			object __obj3 = null;
			if (Validation.IsSet(__string1))	__obj3 = GetMemberValue(container, __string1);
			else															__obj3 = container;
			if (Validation.IsNotNull(__obj3)) {
				if (__obj3 is Array && __flag) {
					__obj1 = ((object[])__obj3)[(int)__obj2];
				}else if (__obj3 is IList && __flag) {
					__obj1 = ((IList)__obj3)[(int)__obj2];
				}else {
					__obj1 = GetMemberValue(__obj3, "Item", false, new object[]{__obj2});
				}
			}
			return __obj1;
		}
		private	static void								SetIndexedPropertyValue(object container, string expr, object value) {
			bool		__flag			= false;
			int			__i					= expr.IndexOfAny(_indexExprStartChars);
			int			__j					= expr.IndexOfAny(_indexExprEndChars, __i + 1);
			if (__i < 0 || __j < 0 || __j == __i + 1) throw new ArgumentNullException(string.Format(Constantes.DataBinderInvalidIndexUsed, expr));
			string	__string1		= null;
			object	__obj2			= null;
			string __string2		= expr.Substring(__i + 1, __j - __i - 1).Trim();
			if (__i != 0)				__string1 = expr.Substring(0, __i);
			if (__string2.Length != 0) {
				if (__string2[0] == '\"' && __string2[__string2.Length - 1] == '\"' || __string2[0] == '\'' && __string2[__string2.Length - 1] == '\'') {
					__obj2 = __string2.Substring(1, __string2.Length - 2);
				}
				else if (Char.IsDigit(__string2[0])) {
					try {
						__obj2 = Int32.Parse(__string2, CultureInfo.InvariantCulture);
						__flag = true;
					}catch (Exception){
						__obj2 = __string2;
					}
				}else {
					__obj2 = __string2;
				}
			}
			if (Validation.IsNull(__obj2)) throw new ArgumentNullException(string.Format(Constantes.DataBinderInvalidIndexUsed, expr));
			object __obj3 = null;
			if (Validation.IsSet(__string1))	__obj3 = GetMemberValue(container, __string1);
			else															__obj3 = container;
			if (Validation.IsNotNull(__obj3)) {
				if (__obj3 is Array && __flag) {
					((object[])__obj3)[(int)__obj2] = value;
				}else if (__obj3 is IList && __flag) {
					((IList)__obj3)[(int)__obj2]		= value;
				}else {
					SetMemberValue(__obj3, "Item", value, new object[]{__obj2});
				}
			}
		}
		/// <summary>Gets an object by mapping <paramref name="obj"/>, <paramref name="property"/> with the specified <paramref name="key"/> indexer value. </summary>
		/// <param name="property">The <see cref="PropertyInfo"/> metadata in the <paramref name="obj"/>. </param>
		/// <param name="obj">The instance of the object to use. </param>
		/// <param name="key">The value of the indexer to retrieve. </param>
		/// <returns>an <see cref="Object"/> if <paramref name="property"/> exist in <paramref name="obj"/> and indexer value is matched in <paramref name="obj"/>. otherwise <see langword="null"/>. </returns>
		public static object							GetIndexedValue(PropertyInfo property, object obj, object key)
		{
			object				__returnValue		= property.GetValue(obj, new object[]{key});
			return				__returnValue;
		}
		/// <summary>Gets an object from the default indexer of <paramref name="obj"/>. </summary>
		/// <param name="obj">The <see cref="Object"/> used to retrieve value. </param>
		/// <param name="key">The value of the indexer. </param>
		/// <returns>The <see cref="Object"/> if <paramref name="key"/> exist in the default indexer of <paramref name="obj"/>. otherwise <see langword="null"/>. </returns>
		public static object							GetIndexedValue(object obj, object key)
		{
			Type					__type					= obj.GetType();
			PropertyInfo	__property			= __type.GetProperty("Item", ValueType.ArrayOf1String);
			return GetIndexedValue(__property, obj, key);
		}
		/// <summary>Set the specified <paramref name="value"/> to the <paramref name="container"/> where the <paramref name="expression is matched"/>. </summary>
		/// <param name="container">the object to update. </param>
		/// <param name="expression">the expression used to match a property or the indexer. </param>
		/// <param name="value">the new value. </param>
		public	static void								SetVal(object container, string expression, object value)
		{
			string[] __expressions = expression.Trim().Split(_expressionPartSeparator);
			object __object = SetVal(container, __expressions, value);
		}
		private	static object							SetVal(object container, string[] expressionParts, object value){
			object __object = container;
			for (int i = 0; i < expressionParts.Length && Validation.IsNotNull(__object); i++) {
				string str = expressionParts[i];
				if(i == expressionParts.Length - 1){
					if (str.IndexOfAny(_indexExprStartChars) < 0)		SetMemberValue(__object, str, value);
					else																						SetIndexedPropertyValue(__object, str, value);
				}else{
					if (str.IndexOfAny(_indexExprStartChars) < 0)		__object	= GetMemberValue(__object, str, false);
					else																						__object	= GetIndexedProperty(__object, str);
				}
			}
			return __object;
		}
		private	static void								SetMemberValue(object container, string memberName, object value, object[] args) {
			object							__value								= null;
			Type								__type;
			object							__member; 
			
			if(container is ICustomTypeDescriptor)	__member	= GetPropertyDescriptor(container, memberName, args);
			else																		__member	= GetMatchedMember(container, memberName, args);
			if(__member is FieldInfo){
				FieldInfo __fieldInfo = ((FieldInfo)__member);
				__type = __fieldInfo.FieldType;
				if(__type.IsEnum) __value = Enum.Parse(__type, Conversion.ToString(value));
				else							__value = value;
				__fieldInfo.SetValue(container, __value);
			}else if(__member is PropertyInfo){
				PropertyInfo __propertyInfo = ((PropertyInfo)__member);
				__type = __propertyInfo.PropertyType;
				if(__type.IsEnum) __value = Enum.Parse(__type, Conversion.ToString(value));
				else							__value = value;
				__propertyInfo.SetValue(container, __value, args);
			}else if(__member is PropertyDescriptor){
				PropertyDescriptor __propertydescriptor = ((PropertyDescriptor)__member);
				__propertydescriptor.SetValue(container, value);
			}else{
				throw new ArgumentNullException(string.Format(Constantes.DataBinderInvalidMemberType, memberName, container.GetType().FullName));
			} 
		}
		private	static void								SetMemberValue(object container, string memberName, object value) {
			SetMemberValue(container, memberName, value, new object[0]);
		}
		/// <summary>Allow user to check existance of a member on the <paramref name="container"/> evaluated by the <paramref name="expression"/>.</summary>
		/// <param name="container">the <see cref="Object"/> where to retrieve the object or value. </param>
		/// <param name="expression">the expression used to retrieve the object or value in the <paramref name="container"/>. </param>
		/// <returns><see langword="true"/> if expression match a member otherwise <see langword="false"/>.</returns>
		public	static bool								CheckMember(object container, string expression){
			string[] __expressions	= expression.Trim().Split(_expressionPartSeparator);
			bool			__result			= false;
			try{
				__result = CheckMember(container, __expressions);
			}catch{}
			return __result;
		}
		private	static bool								CheckMember(object container, string[] expressionParts){
			if(Validation.IsNull(container)) return false;
			bool					__result			= false;
			object				__object			= container;
			for (int i = 0; i < expressionParts.Length && Validation.IsNotNull(__object); i++) {
				string str = expressionParts[i];
				if(i == expressionParts.Length-1){
						__result = GetMember(__object.GetType() , str);
					break;
				}else{
					if (str.IndexOfAny(_indexExprStartChars) < 0)		__object = GetMemberValue(__object, str);
					else																						__object = GetIndexedPropertyValue(__object, str);
				}
			}
			return __result;
		}
		private static bool								GetMember(Type type, string memberName){
			if(Validation.IsNull(type)) return false;
			MemberInfo[]	__members			= type.GetMember(memberName);
			if(__members.Length > 0)		return true;
			return false;
		}
	}
	/// <summary>Provides Method to retrieve specific dataMember from a instance. </summary>
	/// <remarks>the instance must implement <see cref="ITypedList"/> to be resolved correctly. </remarks>
	public sealed class			DataSourceResolver {
		/// <summary>Gets the <see cref="IEnumerable"/> interface from the <paramref name="dataSource"/> where the name is <paramref name="dataMember"/></summary>
		/// <param name="dataSource">the <see cref="Object"/> where to retrieve the <paramref name="dataMember"/> or value.  </param>
		/// <param name="dataMember">the name of the Member to retrieve in <paramref name="dataSource"/>. </param>
		/// <returns>the <see cref="IEnumerable"/> interface of the dataMember</returns>
		/// <remarks>this method retrieve a dataMember is a <see cref="System.Data.DataSet"/> for exemple. </remarks>
		public static IEnumerable GetResolvedDataSource(object dataSource, string dataMember) {
			if (Validation.IsNull(dataSource)) return null;
			
			IListSource __iListSource = dataSource as IListSource;
			if (Validation.IsNotNull(__iListSource)) {
				IList __iList = __iListSource.GetList();
				if (!__iListSource.ContainsListCollection) return __iList;
				if (Validation.IsNotNull(__iList) && __iList is ITypedList) {
					PropertyDescriptorCollection __propertyDescriptorCollection = ((ITypedList)__iList).GetItemProperties(new PropertyDescriptor[0]);
					if (Validation.IsNull(__propertyDescriptorCollection) || __propertyDescriptorCollection.Count == 0) {
						throw new ArgumentNullException(Constantes.DataSourceResolverMemberEmpty);
					}
					PropertyDescriptor __propertyDescriptor = null;
					if (Validation.IsNotSet(dataMember))	__propertyDescriptor = __propertyDescriptorCollection[0];
					else									__propertyDescriptor = __propertyDescriptorCollection.Find(dataMember, true);
					if (Validation.IsNotNull(__propertyDescriptor)) {
						object __obj1 = __iList[0];
						object __obj2 = __propertyDescriptor.GetValue(__obj1);
						if (Validation.IsNotNull(__obj2) && __obj2 is IEnumerable) return (IEnumerable)__obj2;
					}
					throw new ArgumentNullException(string.Format(Constantes.DataSourceResolverMemberMissing, dataMember));
				}
			}
			if (dataSource is IEnumerable)	return (IEnumerable)dataSource;
			return null;
		}
	}
	/// <summary>Provides method to manipulate a parameters collection. </summary>
	public class						Parameters{
		#region internal variables
		ListDictionary __parameters;
		#endregion
		/// <summary>Creates new instance of a <see cref="Parameters"/> class. </summary>
		public Parameters(){
			__parameters = new ListDictionary();
		}
		/// <summary>Adds a element with the specified <paramref name="param"/> and <paramref name="value"/> into the <see cref="Parameters"/>. </summary>
		/// <param name="param">an <see cref="Enum"/> that represent the key of the new element. </param>
		/// <param name="value">the new <see cref="Object"/> to store in <see cref="Parameters"/>. </param>
		/// <remarks>If <paramref name="param"/> already exist in <see cref="Parameters"/> the old value will be replaced by the new one. </remarks>
		public void		Add(Enum param, object value){
			this.Add(param.ToString(), value);
		}
		/// <summary>Adds a element with the specified <paramref name="param"/> and <paramref name="value"/> into the <see cref="Parameters"/>. </summary>
		/// <param name="paramName">a <see cref="String"/> that represent the key of the new element. </param>
		/// <param name="value">the new <see cref="Object"/> to store in <see cref="Parameters"/>. </param>
		/// <remarks>If <paramref name="paramName"/> already exist in <see cref="Parameters"/> the old value will be replaced by the new one. </remarks>
		public void		Add(string paramName, object value){
			if(this.Contains(paramName))	__parameters[paramName] = value;
			else													__parameters.Add(paramName, value);
		}
		/// <summary>Clears all stored parameters. </summary>
		public void		Clear(){
			__parameters.Clear();
		}
		/// <summary>Determines whether this instance of <see cref="Parameters"/> class contains one or more parameters. </summary>
		/// <returns><see langword="true"/> if this instance contains parameters otherwise <see langword="false"/>. </returns>
		public bool		HasParameter{
			get{return __parameters.Count > 0;}
		}
		/// <summary>Gets the reference of parameter that corresponding to the <paramref name="param"/> key. </summary>
		/// <param name="param">an <see cref="Enum"/> that represent the key of the parameter. </param>
		/// <returns>The reference of the parameter if exist otherwise <see langword="null"/>. </returns>
		public object this[Enum param]{
			get{return this[param.ToString()];}
		}
		/// <summary>Gets the reference of parameter that corresponding to the <paramref name="paramName"/> key. </summary>
		/// <param name="paramName">a <see cref="String"/> that represent the key of the parameter. </param>
		/// <returns>The reference of the parameter if exist otherwise <see langword="null"/>. </returns>
		public object this[string paramName]{
			get{
				if(this.Contains(paramName)) return __parameters[paramName];
				return	null;
			}
		}
		/// <summary>Determines whether this instance of <see cref="Parameters"/> contains the specified <paramref name="param"/> key. </summary>
		/// <param name="param">an <see cref="Enum"/> that represent the key of the parameter. </param>
		/// <returns><see langword="true"/> if <paramref name="param"/> key exist otherwise <see langword="false"/>. </returns>
		public bool		Contains(Enum param){
			return this.Contains(param.ToString());
		}
		/// <summary>Determines whether this instance of <see cref="Parameters"/> contains the specified <paramref name="param"/> key. </summary>
		/// <param name="paramName">an <see cref="String"/> that represent the key of the parameter. </param>
		/// <returns><see langword="true"/> if <paramref name="param"/> key exist otherwise <see langword="false"/>. </returns>
		public bool		Contains(string paramName){
			if(Validation.IsNull(paramName)) return false;
			return __parameters.Contains(paramName);
		}
		/// <summary>Remove the parameter with the key <paramref name="param"/>. </summary>
		/// <param name="param">An <see cref="Enum"/> key to remove</param>
		public void		Remove(Enum param){
			this.Remove(param.ToString());
		}
		/// <summary>Remove the parameter with the key <paramref name="paramName"/>. </summary>
		/// <param name="paramName">An <see cref="String"/> key to remove</param>
		public void		Remove(string paramName){
			__parameters.Remove(paramName);
		}
	}
}
