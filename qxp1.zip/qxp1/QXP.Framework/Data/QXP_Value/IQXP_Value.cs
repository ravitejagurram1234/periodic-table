using System;
using System.Collections.Generic;
using System.Text;

using QXP.Framework.Data.Format;

namespace QXP.Framework.Data
{
    /// <summary>
    /// Interface IQXP_Value
    /// </summary>
    /// <author>cueffl</author>
    /// <date>14/05/2009 12:10:10</date>    
    public interface IQXP_Value : IComparable<IQXP_Value>, IEquatable<IQXP_Value>
    {        

        #region M�thodes

        string ToString();

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Format associ� � la valeur
        /// </summary>
        QXP_Format Format { get;}
        
        /// <summary>
        /// Valeur
        /// </summary>
        object Value  { get;}

        /// <summary>
        /// Type de la valeur
        /// </summary>
        Type Type { get;}

        /// <summary>
        /// Indique si la valeur est diff�rent de null et d�finie
        /// </summary>
        bool ValueIsSet { get; }

        #endregion Propri�t�s
    }


    /// <summary>
    /// Interface IQXP_Value <typeparam name="T">Type de donn�e valeur</typeparam>
    /// </summary>
    /// <author>cueffl</author>
    /// <date>14/05/2009 12:10:10</date> 
    public interface IQXP_Value<T> : IQXP_Value
    {
        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s
    
        /// <summary>
        /// Valeur de type <typeparam name="T">Type de donn�e valeur</typeparam>
        /// </summary>
        T   TValue  { get;}

        #endregion Propri�t�s
    }
}
