using System;
using System.Collections.Generic;
using System.Text;
using QXP.Framework.Data.Format;

namespace QXP.Framework.Data
{
    /// <summary>
    /// QXP_Value : caract�rise une valeur QXP (avec son format)
    /// </summary>
    /// <typeparam name="T">Type de donn�e contenu dans l'QXP_Value</typeparam>
    /// <author>cueffl</author>
    /// <date>13/05/2009 11:51:39</date>    
    public class QXP_Value<T> : IQXP_Value<T>
        where T : IComparable<T>, IEquatable<T>
    {
        #region Membres

        private QXP_Format                 _format;
        private T                          _value;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de QXP_Value du type de donn�e sp�cifi�
        /// </summary>
        /// <param name="value">Valeur � stocker dans l'QXP_Value</param>        
        public QXP_Value(T value)
        {            
            _value          = value;
        }

        /// <summary>
        /// Cr�e une instance de QXP_Value du type de donn�e sp�cifi�
        /// </summary>
        /// <param name="value">Valeur � stocker dans l'QXP_Value</param>        
        /// <param name="format">Format � associer � la valeur</param>
        public QXP_Value(T value, QXP_Format format) : this(value)
        {
            _format = format;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Valeur en string de l'objet
        /// </summary>
        /// <returns>Un string</returns>
        public override string ToString()
        {
            return QXP_Format_Helper.Get_Formatted_String_Value<T>(this);
        }

        /// <summary>
        /// Compare deux QXP_Value entre elles
        /// </summary>
        /// <param name="qxp_value">Valeur � comparer</param>
        /// <returns>0 : les deux valeurs sont �gales; sup 0 : l'instance en cours est plus grande que l'qxp_value pass� en param�tre;
        /// inf 0 : l'instance en cours est plus petite que l'qxp_value pass� en param�tre</returns>
        public int CompareTo(IQXP_Value qxp_value)
        {
            ComparerQXP_Value __comparer = new ComparerQXP_Value();
            return __comparer.Compare(this, qxp_value);
        }

        /// <summary>
        /// Indique si l'QXP_Value pass� en param�tre est �gal ou non � cette instance
        /// </summary>
        /// <param name="qxp_value">Valeur � comparer</param>
        /// <returns>Vrai si les valeurs sont �gales</returns>
        public bool Equals(IQXP_Value qxp_value)
        {
            return qxp_value.CompareTo(this).Equals(0);
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Valeur contenue dans l'QXP_Value
        /// </summary>
        public T TValue
        {
            get { return _value; }
            //set { _value = value; }
        }

        /// <summary>
        /// Valeur contenue dans l'QXP_Value
        /// </summary>
        public object Value
        {
            get { return TValue; }
            //set { _value = value; }
        }

        /// <summary>
        /// Format associ� � la valeur QXP
        /// </summary>
        public QXP_Format Format
        {
            get { return _format; }
            set { _format = value; }
        }

        /// <summary>
        /// Type de la valeur
        /// </summary>
        public Type        Type 
        {
            get { return typeof(T); }
        }

        /// <summary>
        /// Indique si la valeur est diff�rent de null et d�finie
        /// </summary>
        public bool ValueIsSet
        {
           get { return Validation.IsSet(this.Value); }
        }

        #endregion Propri�t�s
    }

    /// <summary>
    /// Class ComparerQXP_Value : D�finit l'impl�mentation de la comparaison entre deux QXP_Value
    /// </summary>
    /// <author>LCU</author>
    /// <date>17/04/2009</date>    
    public class ComparerQXP_Value : IComparer<IQXP_Value>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ComparerQXP_Value
        /// </summary>
        public ComparerQXP_Value()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Permet de comparer deux QXP_Value
        /// </summary>
        /// <param name="x">QXP_Value � comparer</param>
        /// <param name="y">QXP_Value � comparer</param>
        /// <returns>Le r�sultat de la comparaison des values contenues dans les deux QXP_Value pass�s en param�tre
        /// 0 : les deux valeurs sont �gales
        /// sup 0 : x est plus grand que y
        /// inf 0 : x est plus petit que y
        /// </returns>
        public int Compare(IQXP_Value x, IQXP_Value y)
        {
			IComparable __x_value	= x.Value as IComparable;
			IComparable __y_value	= y.Value as IComparable;
            			
			if(Validation.IsNotNull(__x_value))
            {
				if(Validation.IsNotNull(__y_value))
                {
					return __x_value.CompareTo(__y_value);
				}else
                {
					return 1;
				}
			}else
            {
                if (Validation.IsNull(__y_value))
                {
                    return 0;
                }
                
                return -1;
			}
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
