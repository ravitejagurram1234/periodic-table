using System;

/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/
namespace QXP.Framework.Data.Oracle
{
	/// <summary>
	/// Ensembles des �num�rations communes au module
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/12/2010 10:42:16</date>    
	public class Enums
	{
		public enum OraObjectValType
		{
			  Val_String	    = 1
			, Val_Decimal		= 2
			, Val_Int			= 3
			, Val_Currency		= 4
			, Val_Pourcentage	= 5
			, Val_Date			= 6
			, Val_DateTime		= 7
		}
	}
}
