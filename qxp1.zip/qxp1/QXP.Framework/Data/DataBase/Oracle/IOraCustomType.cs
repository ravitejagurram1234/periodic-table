using Oracle.DataAccess.Types;

/* 
 * Code g�n�r� avec le template : QXPInterface
*/
namespace QXP.Framework.Data.Oracle
{
    /// <summary>
    /// Interface IOraCustomType : Interface de mapping d'objet Oracle - .NET
    /// </summary>
    /// <author>cueffl</author>
    /// <date>09/09/2011 16:14:53</date>    
    public interface IOraCustomType : INullable, IOracleCustomType
    {
        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Indique le nom de l'objet oracle utilis� dans le mapping Oracle avec l'objet
        /// </summary>
        string UdtTypeName
        {
            get;
        }

        #endregion Propri�t�s
    }
}
