using System.Data;

namespace QXP.Framework.Data.Oracle
{
    /// <summary>
    /// Objet permettant de caract�riser une requ�te et utilisable par l'ensemble des proxys
    /// Permet aussi de d�finir une autre source de donn�e via le membre Oraclient
    /// </summary>
    public class SQLRequest
    {
        #region Membres

        private string _sqlString;
        private CommandType _commandType;
        private OraParameterList _oraParameters;
        private OraClient _oraClient = null;
        OraClient.OracleConnectionOwnership _oracleConnectionOwnership = OraClient.OracleConnectionOwnership.Internal;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de SQLRequest
        /// </summary>
        public SQLRequest()
        {
        }

        /// <summary>
        /// Cr�e une instance de SQLRequest
        /// </summary>
        /// <param name="commandType">Type de commande</param>
        /// <param name="sqlString">Cha�ne de connexion</param>
        /// <param name="oraParameters">Param�tres</param>
        public SQLRequest(CommandType commandType, string sqlString, OraParameterList oraParameters)
        {
            this._commandType = commandType;
            this._sqlString = sqlString;
            this._oraParameters = oraParameters;
        }

        /// <summary>
        /// Cr�e une instance de SQLRequest
        /// </summary>
        /// <param name="commandType">Type de commande</param>
        /// <param name="sqlString">cha�ne de connexion</param>
        /// <param name="oraParameters">Param�tres</param>
        /// <param name="oracleConnectionOwnership">Gestion de la connexion</param>
        public SQLRequest(CommandType commandType, string sqlString, OraParameterList oraParameters, OraClient.OracleConnectionOwnership oracleConnectionOwnership)
            : this(commandType, sqlString, oraParameters)
        {
            this._oracleConnectionOwnership = oracleConnectionOwnership;
        }

        /// <summary>
        /// Cr�e une instance de SQLRequest
        /// </summary>
        /// <param name="oraClient">Objet d'acc�s � la base</param>
        /// <param name="commandType">Type de commande</param>
        /// <param name="sqlString">Cha�ne de connexion</param>
        /// <param name="oraParameters">Param�tres</param>
        public SQLRequest(OraClient oraClient, CommandType commandType, string sqlString, OraParameterList oraParameters)
            : this(commandType, sqlString, oraParameters)
        {
            this._oraClient = oraClient;
        }

        /// <summary>
        /// Cr�e une instance de SQLRequest
        /// </summary>
        /// <param name="oraClient">Objet d'acc�s � la base</param>
        /// <param name="commandType">Type de commande</param>
        /// <param name="sqlString">Cha�ne de connexion</param>
        /// <param name="oraParameters">Param�tres</param>
        /// <param name="oracleConnectionOwnership">Gestion de la connexion</param>
        public SQLRequest(OraClient oraClient, CommandType commandType, string sqlString, OraParameterList oraParameters, OraClient.OracleConnectionOwnership oracleConnectionOwnership)
            : this(oraClient, commandType, sqlString, oraParameters)
        {
            this._oracleConnectionOwnership = oracleConnectionOwnership;
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Cha�ne de connexion
        /// </summary>
        public string SqlString
        {
            get { return _sqlString; }
            set { _sqlString = value; }
        }

        /// <summary>
        /// Type de commande
        /// </summary>
        public CommandType CommandType
        {
            get { return _commandType; }
            set { _commandType = value; }
        }

        /// <summary>
        /// Param�tres
        /// </summary>
        public OraParameterList OraParameters
        {
            get { return _oraParameters; }
            set { _oraParameters = value; }
        }

        /// <summary>
        /// Objet d'acc�s � la base
        /// </summary>
        public OraClient OraClient
        {
            get { return _oraClient; }
            set { _oraClient = value; }
        }

        /// <summary>
        /// Gestion de la connexion
        /// </summary>
        public OraClient.OracleConnectionOwnership OracleConnectionOwnership
        {
            get { return _oracleConnectionOwnership; }
            set { _oracleConnectionOwnership = value; }
        }

        #endregion Propri�t�s
    }
}
