using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace QXP.Framework.Data.Oracle
{
    /// <summary>
    /// Class OraParameter : Provides methods and properties of an oracle query parameter.
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public sealed class OraParameter
    {
        #region Membres

        private OracleParameter _parameter;
        private Stream _stream;
        private bool _cached = true;
        private int _streamBufferSize = 2000000; //~2 Mb.
        private bool _autoCloseStream = true;

        #endregion Membres

        #region Constantes

        private const int DefaultVarCharSize = 255;

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de OraParameter
        /// </summary>
        public OraParameter() 
        {
            _parameter = new OracleParameter();
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/>. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">The <see cref="object"/> value associated with the new <see cref="OraParameter"/>. </param>
        public OraParameter(string parameterName, object value)
        {
            if (Validation.IsNotNull(value))
            {
                Type __valueType = value.GetType();
                if (__valueType == ValueType.ArrayOfBool)
                {
                    _parameter = this.GetParameter(parameterName, (bool[])value);
                }
                else if (__valueType == ValueType.ArrayOfInt)
                {
                    _parameter = this.GetParameter(parameterName, (int[])value);
                }
                else if (__valueType == ValueType.ArrayOfString)
                {
                    _parameter = this.GetParameter(parameterName, (string[])value);
                }
                else if (__valueType == ValueType.ArrayOfDate)
                {
                    _parameter = this.GetParameter(parameterName, (DateTime[])value);
                }
                else if (__valueType == ValueType.ArrayOfDecimal)
                {
                    _parameter = this.GetParameter(parameterName, (Decimal[])value);
                }
                else if (__valueType == ValueType.ArrayOfByte)
                {
                    _parameter = this.GetParameter(parameterName, (byte[])value);
                }
                else if (__valueType == ValueType.ArrayOfChar)
                {
                    _parameter = this.GetParameter(parameterName, (char[])value);
                }
                else if (__valueType == ValueType.CLSboolean)
                {
                    _parameter = this.GetParameter(parameterName, (bool)value);
                }
                else if (__valueType == ValueType.DateTime)
                {
                    _parameter = GetParameter(parameterName, (DateTime)value);
                }
                else if (__valueType == ValueType.TimeSpan)
                {
                    _parameter = GetParameter(parameterName, (TimeSpan)value);
                }
                else if (__valueType == ValueType.CLSint32)
                {
                    _parameter = GetParameter(parameterName, (Int32)value);
                }
                else if (__valueType == ValueType.CLSint16)
                {
                    _parameter = GetParameter(parameterName, (Int16)value);
                }
                else if (__valueType == ValueType.CLSdecimal)
                {
                    _parameter = GetParameter(parameterName, (decimal)value);
                }
                // Cas particulier o� la valeur est d'un type d�riv� de Stream
                else if (value is Stream)
                {
                    _parameter = GetParameter(parameterName, (Stream)value);
                }                   
                else if (value is IOraCustomType)
                {
                    _parameter = GetParameter(parameterName, (IOraCustomType)value);
                }
                else
                {
                    _parameter = new OracleParameter(parameterName, value);
                }
            }
            // Cas ou la value est null
            // on cr�� un OraParameter de type varchar2
            else
            {
                _parameter = new OracleParameter(parameterName, OracleDbType.Varchar2);
                _parameter.Value = value;
                _parameter.Size = DefaultVarCharSize; //by default
            }
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/>. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="type">The <see cref="OracleDbType"/> of the parameter. </param>
        /// <param name="direction">The <see cref="ParameterDirection"/> of the parameter. </param>
        public OraParameter(string parameterName, OracleDbType type, ParameterDirection direction)
            : this(parameterName, type)
        {
            _parameter.Direction = direction;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/>. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="type">The <see cref="OracleDbType"/> of the parameter. </param>
        /// <param name="value">the value of the parameter. otherwise null. </param>
        public OraParameter(string parameterName, OracleDbType type, object value)
            : this(parameterName, type)
        {
            _parameter.Value = value;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified <paramref name="parameterName"/> and <paramref name="type"/>. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="type">The <see cref="OracleDbType"/> of the parameter. </param>
        public OraParameter(string parameterName, OracleDbType type)
        {
            _parameter = new OracleParameter(parameterName, type);
            if (type == OracleDbType.Varchar2)
            {
                _parameter.Size = DefaultVarCharSize;
            }
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/>. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="type">The <see cref="OracleDbType"/> of the parameter. </param>
        /// <param name="value">the value of the parameter. otherwise null. </param>
        /// <param name="size">the <see cref="Int32"/> size of the parameter. </param>
        public OraParameter(string parameterName, OracleDbType type, object value, int size)
            : this(parameterName, type, value)
        {
            _parameter.Size = size;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/>. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="type">The <see cref="OracleDbType"/> of the parameter. </param>
        /// <param name="value">the value of the parameter. otherwise null. </param>
        /// <param name="direction">The <see cref="ParameterDirection"/> of the parameter. </param>
        public OraParameter(string parameterName, OracleDbType type, object value, ParameterDirection direction)
        {
            _parameter = new OracleParameter(parameterName, type);
            _parameter.Direction = direction;
            _parameter.Value = value;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/>. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="type">The <see cref="OracleDbType"/> of the parameter. </param>
        /// <param name="value">the value of the parameter. otherwise null. </param>
        /// <param name="direction">The <see cref="ParameterDirection"/> of the parameter. </param>
        /// <param name="size">the <see cref="Int32"/> size of the parameter. </param>
        public OraParameter(string parameterName, OracleDbType type, object value, ParameterDirection direction, int size)
            : this(parameterName, type, value, direction)
        {
            _parameter.Size = size;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Boolean"/> value of the parameter. </param>
        public OraParameter(string parameterName, bool value)
        {
            _parameter = this.GetParameter(parameterName, value);
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Int32"/> value of the parameter. </param>
        public OraParameter(string parameterName, int value)
        {
            _parameter = GetParameter(parameterName, value);
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Int64"/> value of the parameter. </param>
        public OraParameter(string parameterName, long value)
        {
            _parameter = new OracleParameter(parameterName, OracleDbType.Long);
            _parameter.Value = value;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="short"/> value of the parameter. </param>
        public OraParameter(string parameterName, short value)
        {
            _parameter = GetParameter(parameterName, value);
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="char"/> value of the parameter. </param>
        public OraParameter(string parameterName, char value)
        {
            _parameter = new OracleParameter(parameterName, OracleDbType.Char);
            _parameter.Value = value;
            _parameter.Size = 1;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="string"/> value of the parameter. </param>
        public OraParameter(string parameterName, string value)
        {
            _parameter = new OracleParameter(parameterName, OracleDbType.Varchar2);
            _parameter.Value = value;
            if (Validation.IsSet(value))
            {
                _parameter.Size = value.Length;
            }
            else
            {
                _parameter.Size = DefaultVarCharSize; //by default
            }
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified parameterName and value furthermore specify if parameter is clob type. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="string"/> value of the parameter. </param>
        /// <param name="isClob"><see langword="true"/> if the parameter type is Clob otherwise <see langword="false"/>. </param>
        public OraParameter(string parameterName, string value, bool isClob)
            : this(parameterName, value)
        {
            if (isClob)
            {
                _parameter.OracleDbType = OracleDbType.Clob;
            }
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="string"/> value of the parameter. </param>
        /// <param name="size">the <see cref="Int32"/> size of the string parameter. </param>
        public OraParameter(string parameterName, string value, int size)
            : this(parameterName, value)
        {
            _parameter.Size = size;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Decimal"/> value of the parameter. </param>
        public OraParameter(string parameterName, Decimal value)
        {
            _parameter = new OracleParameter(parameterName, OracleDbType.Decimal);
            _parameter.Value = value;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="DateTime"/> value of the parameter. </param>
        public OraParameter(string parameterName, DateTime value)
        {
            _parameter = new OracleParameter(parameterName, OracleDbType.Date);
            if (Validation.IsSet(value)) _parameter.Value = value;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="TimeSpan"/> value of the parameter. </param>
        public OraParameter(string parameterName, TimeSpan value)
        {
            _parameter = new OracleParameter(parameterName, OracleDbType.IntervalDS);
            if (Validation.IsSet(value))
            {
                _parameter.Value = value;
            }
            else
            {
                _parameter.Value = null;
            }
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Byte"/> value of the parameter. </param>
        public OraParameter(string parameterName, Byte value)
        {
            _parameter = new OracleParameter(parameterName, OracleDbType.Byte);
            _parameter.Value = value;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. (Blob typed)</summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Byte"/> array value of the parameter. </param>
        public OraParameter(string parameterName, Byte[] value)
        {
            _parameter = GetParameter(parameterName, value);
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. (Clob typed)</summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Char"/> array value of the parameter. </param>
        public OraParameter(string parameterName, Char[] value)
        {
            _parameter = GetParameter(parameterName, value);
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="float"/> value of the parameter. </param>
        public OraParameter(string parameterName, float value)
        {
            string __value = value.ToString("r");
            _parameter = new OracleParameter(parameterName, OracleDbType.Double);
            _parameter.Value = __value;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="double"/> value of the parameter. </param>
        public OraParameter(string parameterName, double value)
        {
            throw new InvalidOperationException();
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="string"/> array values of the parameter. </param>
        public OraParameter(string parameterName, string[] values)
        {
            _parameter = this.GetParameter(parameterName, values);
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="int"/> array values of the parameter. </param>
        public OraParameter(string parameterName, int[] values)
        {
            _parameter = this.GetParameter(parameterName, values);
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="decimal"/> array values of the parameter. </param>
        public OraParameter(string parameterName, decimal[] values)
        {
            _parameter = this.GetParameter(parameterName, values);
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> from the specified name and value. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="bool"/> array values of the parameter. </param>
        public OraParameter(string parameterName, bool[] values)
        {
            _parameter = this.GetParameter(parameterName, values);
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> (Blob typed)) from the specified <paramref name="parameterName"/> and <paramref name="value"/> (Stream). </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Stream"/> value of the parameter. </param>
        public OraParameter(string parameterName, Stream value)
        {
            if (Validation.IsNull(value)) throw new ArgumentNullException(Constantes.NullValueException);
            _parameter = new OracleParameter(parameterName, OracleDbType.Blob);
            _stream = value;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> (Blob typed)) from the specified <paramref name="parameterName"/>, <paramref name="value"/> (Stream) and streamBufferSize. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Stream"/> value of the parameter. </param>
        /// <param name="streamBufferSize">the <paramref name="Int32"/> flush buffer size of the streamed data. </param>
        public OraParameter(string parameterName, Stream value, int streamBufferSize)
            : this(parameterName, value)
        {
            _streamBufferSize = streamBufferSize;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> (Blob or Clob typed)) from the specified <paramref name="parameterName"/>, <paramref name="value"/> (Stream) and streamBufferSize. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Stream"/> value of the parameter. </param>
        /// <param name="isClob"><see langword="true"/> if the parameter is Clob types, <see langword="false"/> if it is Blob type. </param>
        public OraParameter(string parameterName, Stream value, bool isClob)
            : this(parameterName, value)
        {
            if (isClob) _parameter.OracleDbType = OracleDbType.Clob;
            else _parameter.OracleDbType = OracleDbType.Blob;
        }

        /// <summary>Creates a new Instance of <see cref="OraParameter"/> (Blob or Clob typed)) from the specified <paramref name="parameterName"/>, <paramref name="value"/> (Stream) and streamBufferSize. </summary>
        /// <param name="parameterName">the name of the oracle parameter. </param>
        /// <param name="value">the <see cref="Stream"/> value of the parameter. </param>
        /// <param name="isClob"><see langword="true"/> if the parameter is Clob types, <see langword="false"/> if it is Blob type. </param>
        /// <param name="streamBufferSize">the <paramref name="Int32"/> flush buffer size of the streamed data. </param>
        public OraParameter(string parameterName, Stream value, bool isClob, int streamBufferSize)
            : this(parameterName, value, isClob)
        {
            _streamBufferSize = streamBufferSize;
        }
        

        #endregion Constructeur

        #region M�thodes

        private OracleParameter GetParameter(string parameterName, bool[] values)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Byte);
            this.UpdateArrayParameterStatus(__parameter, values);
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, int[] values)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Int32);
            this.UpdateArrayParameterStatus(__parameter, values);
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, decimal[] values)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Decimal);
            this.UpdateArrayParameterStatus(__parameter, values);
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, string[] values)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Varchar2);
            this.UpdateArrayParameterStatus(__parameter, values);
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, DateTime[] values)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Date);
            this.UpdateArrayParameterStatus(__parameter, values);
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, byte[] values)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Blob);
            __parameter.Value = values;
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, char[] values)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Clob);
            __parameter.Value = values;
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, bool value)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Byte);
            __parameter.Value = value;
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, Int16 value)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Int16);
            if (Validation.IsSet(value))
            {
                __parameter.Value = value;
            }
            else
            {
                __parameter.Value = DBNull.Value;
            }
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, Int32 value)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Int32);
            if (Validation.IsSet(value))
            {
                __parameter.Value = value;
            }
            else
            {
                __parameter.Value = DBNull.Value;
            }
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, decimal value)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Decimal);
            if (Validation.IsSet(value))
            {
                __parameter.Value = value;
            }
            else
            {
                __parameter.Value = DBNull.Value;
            }
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, DateTime value)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Date);
            if (Validation.IsSet(value))
            {
                __parameter.Value = value;
            }
            else
            {
                __parameter.Value = DBNull.Value;
            }
            return __parameter;
        }

        private OracleParameter GetParameter(string parameterName, TimeSpan value)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.IntervalDS);
            if (Validation.IsSet(value))
            {
                __parameter.Value = value;
            }
            else
            {
                __parameter.Value = DBNull.Value;
            }
            return __parameter;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parameterName"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private OracleParameter GetParameter(string parameterName, Stream value)
        {
            if (Validation.IsNull(value)) throw new ArgumentNullException(Constantes.NullValueException);
            _parameter = new OracleParameter(parameterName, OracleDbType.Blob);
            _stream = value;
            return _parameter;

        }

        /// <summary>
        /// Retourne l'OracleParameter associ�
        /// </summary>
        /// <param name="parameterName">Nom du param�tre</param>
        /// <param name="value">IOraCustomType (Oracle Object)</param>
        /// <returns>OracleParameter</returns>
        private OracleParameter GetParameter(string parameterName, IOraCustomType value)
        {
            OracleParameter __parameter = new OracleParameter(parameterName, OracleDbType.Object);
            if (!value.IsNull)
            {
                __parameter.Value = value;
                __parameter.UdtTypeName = value.UdtTypeName;
            }
            else
            {
                __parameter.Value = DBNull.Value;
            }
            return __parameter;
        }

        /// <summary>
        /// Permet d�valuer les BindStatus d'une collection, c'est � dire si chaques param�tres � bien �t� �valuer par le provider
        /// </summary>
        /// <param name="values">Une liste de valeur</param>
        /// <returns>Une liste de <see cref="OracleParameterStatus"/> bindstatus</returns>
        private void UpdateArrayParameterStatus(OracleParameter parameter, IList values)
        {
            //C'est une collection
            parameter.CollectionType = OracleCollectionType.PLSQLAssociativeArray;

            if (Validation.IsNotSet(values))
            {
                parameter.ArrayBindStatus = new OracleParameterStatus[] { OracleParameterStatus.NullInsert };
                //parameter.Size				= 0;
                //parameter.Value = DBNull.Value;
            }
            else
            {

                OracleParameterStatus[] __status = new OracleParameterStatus[values.Count];
                List<object> __values = new List<object>();
                for (int __i = 0; __i < values.Count; __i++)
                {
                    //si la valeur est non d�fini ou null il faut le pr�ciser � oracle 
                    //afin qu'il n'essaye pas de r�cup�rer des valeurs non significative pour lui exemple DateTime.MinValue
                    if (Validation.IsNotSet(values[__i]))
                    {
                        //__status[__i] = OracleParameterStatus.NullInsert;
                        //on force la mise � DBNull de la valeur non significative
                        __values.Add(DBNull.Value);
                    }
                    else
                    {
                        __values.Add(values[__i]);
                    }
                }
                parameter.Value = __values.ToArray();
            }

        }

        /// <summary>Allow you to clone OraParameter Instance. </summary>
        /// <returns>The new OraParameter. </returns>
        public OraParameter Clone()
        {
            OraParameter __newParameter = new OraParameter();
            __newParameter._parameter = (OracleParameter)this.Parameter.Clone();
            return __newParameter;
        }

        /// <summary>Allows implicit OraParameter to OracleParameter casting. </summary>
        /// <param name="value">The <see cref="OraParameter"/> to cast. </param>
        /// <returns>The result <see cref="OracleParameter"/>. </returns>
        public static implicit operator OracleParameter(OraParameter value)
        {
            return value._parameter;
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>Gets the internal <see cref="OracleParameter"/> instance. </summary>
        /// <remarks>this allow developper to manipulate all parameters properties. </remarks>
        public OracleParameter Parameter
        {
            get { return _parameter; }
        }

        /// <summary>Retrieves parameter return value if exist. </summary>
        public OraValue ReturnValue
        {
            get { return new OraValue(_parameter.ParameterName, _parameter.Value); }
        }

        public ParameterDirection Direction
        {
            get { return _parameter.Direction; }
            set { _parameter.Direction = value; }
        }

        /// <summary>
        /// UdtTypeName (utilis� pour les objets .net mapp�s avec des objets oracle)
        /// </summary>
        public string UdtTypeName
        {
            get { return _parameter.UdtTypeName; }
            set { _parameter.UdtTypeName = value; }
        }

        /// <summary>Retrieves parameter value. </summary>
        public object Value
        {
            get
            {
                if (Validation.IsNotNull(_parameter)) return _parameter.Value;
                else return null;
            }
            set { if (Validation.IsNotNull(_parameter)) _parameter.Value = value; }
        }

        /// <summary>Gets or sets the <see cref="Stream"/> instance for Blob or Clob OraParameter. </summary>
        public Stream Stream
        {
            get { return _stream; }
            set { _stream = value; }
        }

        /// <summary>Gets or sets if or <see cref="OraParameter.Stream"/> was temporary cached (tablespace) on oracle server during temporary lob's loading. </summary>
        /// <remarks>default value <see langword="true"/>. </remarks>
        public bool Cached
        {
            get { return _cached; }
            set { _cached = value; }
        }

        /// <summary>Gets or sets the size of the buffer streamed to the oracle server. </summary>
        /// <remarks>default value 2000000. ~2M</remarks>
        public int StreamBufferSize
        {
            get { return _streamBufferSize; }
            set { _streamBufferSize = value; }
        }

        /// <summary>Checks if current oraParameter must be streamed to oracle server before command execution. </summary>
        public bool IsStreamed
        {
            get { return Validation.IsNotNull(_stream); }
        }

        /// <summary>Gets or sets if OraParameter.Stream must be close after the streaming. </summary>
        /// <remarks>default value <see langword="true"/>. </remarks>
        public bool AutoCloseStream
        {
            get { return _autoCloseStream; }
            set { _autoCloseStream = value; }
        }

        #endregion Propri�t�s
    }

			
}