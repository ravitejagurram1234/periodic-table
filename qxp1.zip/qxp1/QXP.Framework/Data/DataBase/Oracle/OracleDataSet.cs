using System;
using System.Collections;
using System.Data;
using System.IO;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace QXP.Framework.Data.Oracle
{
	/// <summary>Provides an user friendly access to a <see cref="DataSet"/> instance. </summary>
	public sealed class OraDataSet
	{
		#region internal variables
		DataSet _dataSet;
		#endregion
		/// <summary>Creates a new <see cref="OraDataSet"/> class from the specified <paramref name="dataSet"/>. </summary>
		/// <param name="dataSet">the <see cref="DataSet"/> to encapsulate into the OraDataSet. </param>
		public OraDataSet(DataSet dataSet)
		{
			_dataSet = dataSet;
		}
        /// <summary>
        /// Supprime le Dataset courant
        /// </summary>
        /// <param name="ds"></param>
        public void Dispose()
        {
            this._dataSet.Dispose();
            this._dataSet = null;
        }
        /// <summary>
        /// Merge une table dans le DataSet
        /// </summary>
        /// <param name="ds"></param>
        public void Merge(DataTable dt)
        {
            this._dataSet.Merge(dt);
        }
		/// <summary>Gets the <paramref name="OraTable"/> at the specified <paramref name="index"/> position. </summary>
		public OraDataTable this[int index]
		{
			get{return new OraDataTable(_dataSet.Tables[index]);}
		}
		/// <summary>Gets the <paramref name="OraTable"/> with the specified table <paramref name="name"/>. </summary>
		public OraDataTable this[string name]
		{
			get{return new OraDataTable(_dataSet.Tables[name]);}
		}
		/// <summary>Gets the <see cref="DataRelationCollection"/> of the OraDataSet. </summary>
		public DataRelationCollection		Relations
		{
			get{return _dataSet.Relations;}
		}
        /// <summary>Gets the <see cref="DataTableCollection"/> of the OraDataSet. </summary>
        public DataTableCollection Tables
        {
            get { return _dataSet.Tables; }
        }
		/// <summary>Allows implicit <see cref="OraDataSet"/> to <see cref="DataSet"/> casting. </summary>
		/// <param name="value">The <see cref="OraDataSet"/> to cast. </param>
		/// <returns>The result <see cref="DataSet"/>. </returns>
		public	static implicit	operator	DataSet(OraDataSet value)
		{
			return (DataSet)value._dataSet;
		}

		/// <summary>
		/// Jointure externe gauche ou interne entre les deux premi�res tables du DataSet
		/// </summary>
		/// <param name="sourceColumns">Champs de la 1�re table � joindre</param>
		/// <param name="destinationColumns">Champs de la seconde table � joindre</param>
		public void JoinData(DataColumn[] sourceColumns, DataColumn[] destinationColumns, JoinType joinType)
		{
			DataTable       __tableResult           = new DataTable("ResultOfJoin");
			DataTable		__tableFirstSource		= this.Tables[0];
			DataTable		__tableSecondSource		= this.Tables[1];
            			
            //Creation de la relation de contrainte
            DataRelation __relation = new DataRelation(string.Empty, sourceColumns, destinationColumns, false);
            this.Relations.Add(__relation);

            //Ajout des colonnes de la DataTable principale dans la  table de sortie
            foreach (DataColumn __sourceColumn in __tableFirstSource.Columns)
            {
                __tableResult.Columns.Add(__sourceColumn.ColumnName, __sourceColumn.DataType);
            }

            foreach (DataColumn __destinationColumn in __tableSecondSource.Columns)
            {
                if (!__tableResult.Columns.Contains(__destinationColumn.ColumnName))
                    __tableResult.Columns.Add(__destinationColumn.ColumnName, __destinationColumn.DataType);
                else
                    __tableResult.Columns.Add(string.Concat(__destinationColumn.ColumnName, "_2"), __destinationColumn.DataType);
            }

            //Chargement des donn�es
            __tableResult.BeginLoadData();
            foreach (DataRow __firstRow in __tableFirstSource.Rows)
            {
                //R�cup�rer les lignes jointes
                DataRow[] __childRows = __firstRow.GetChildRows(__relation);
		
			    if (__childRows != null && __childRows.Length > 0)
				{
					object[] __parentArray = __firstRow.ItemArray;
					foreach (DataRow __secondRow in __childRows)
					{
						object[] __secondArray = __secondRow.ItemArray;
						object[] __joinArray = new object[__parentArray.Length + __secondArray.Length];
						Array.Copy(__parentArray, 0, __joinArray, 0, __parentArray.Length);
						Array.Copy(__secondArray, 0, __joinArray, __parentArray.Length, __secondArray.Length);
						__tableResult.LoadDataRow(__joinArray, true);
					}
				}
				else if (joinType == JoinType.LeftOuterJoin)
				{
					object[] __parentArray = __firstRow.ItemArray;
					object[] __joinArray = new object[__parentArray.Length + __tableSecondSource.Columns.Count];
					Array.Copy(__parentArray, 0, __joinArray, 0, __parentArray.Length);
					__tableResult.LoadDataRow(__joinArray, true);
				}
				

            }
            __tableResult.EndLoadData();

            //Suppression des tables et des relations existantes
            this.Relations.Clear();
            this.Tables.Clear();

            //Ajout de la table de jointure
            this.Tables.Add(__tableResult);

		}

	}

	public enum JoinType
	{
		LeftOuterJoin,
		InnerJoin
	}

}