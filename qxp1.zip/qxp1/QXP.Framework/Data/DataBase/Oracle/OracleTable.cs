using System;
using System.Collections;
using System.Data;
using System.IO;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace QXP.Framework.Data.Oracle
{
	/// <summary>Provides an user friendly access to a <see cref="DataTable"/> instance. </summary>
	public sealed class OraDataTable: IEnumerable
	{
		#region internal variables
		DataTable _table;
		#endregion
		/// <summary>Creates a new <see cref="OraDataTable"/> class from the specified <paramref name="dataSet"/>. </summary>
		/// <param name="table">the <see cref="DataTable"/> to encapsulate into the <see cref="OraDataTable"/>. </param>
		public OraDataTable(DataTable table)
		{
			_table = table;
		}
		/// <summary>Gets the <see cref="OraDataRow"/> at the specified index position. </summary>
		public OraDataRow		this[int index]
		{
			get{return new OraDataRow(_table.Rows[index]);}
		}
		/// <summary>Gets <see cref="Int32"/> record count. </summary>
		public int					RecordCount
		{
			get{return _table.Rows.Count;}
		}
		/// <summary>Gets the <see cref="IEnumerator"/> of the current <see cref="OraDataTable"/>. </summary>
		/// <returns>The <see cref="IEnumerator"/> interface. </returns>
		public IEnumerator	GetEnumerator()
		{
			return new OraDataTableEnumerator(this);
		}
		/// <summary>Gets the default <see cref="DataView"/> evaluated from the current <see cref="OraDataTable"/>. </summary>
		public DataView			DefaultView
		{
			get{return _table.DefaultView;}
		}
		/// <summary>Allows implicit <see cref="OraDataTable"/> to <see cref="DataTable"/> casting. </summary>
		/// <param name="value">The OraDataTable to cast. </param>
		/// <returns>The result <see cref="DataTable"/>. </returns>
		public	static implicit	operator	DataTable(OraDataTable value)
		{
			return (DataTable)value._table;
		}
		private class OraDataTableEnumerator: IEnumerator
		{
			#region internal variables
			OraDataTable	_table;
			int						_position = -1;
			#endregion
			internal OraDataTableEnumerator(OraDataTable table) 
			{
				_table = table;
			}
			/// <summary>Gets the current OraDataRow of the enumeration. </summary>
			public object Current 
			{
				get 
				{
					return _table[_position];
				}
			}
			/// <summary>Sets the current position of the enumeration to -1. </summary>
			public void Reset() 
			{
				_position = -1;
			}
			/// <summary>Move the enumeration to the next position and return if it's allowed. </summary>
			/// <returns><see langword="true"/> if more elements exist. otherwise <see langword="false"/>. </returns>
			public bool MoveNext() 
			{
				return (++_position < _table.RecordCount);
			}
		}
	}
}