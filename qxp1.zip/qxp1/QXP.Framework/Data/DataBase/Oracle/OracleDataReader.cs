using System;
using System.Collections;
using System.Data;
using System.IO;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace QXP.Framework.Data.Oracle
{
	/// <summary>
	/// Provides an user friendly access to a <see cref="OracleDataReader"/> instance.
	/// </summary>
	public sealed class OraDataReader: IEnumerable,IDisposable
	{
		#region internal variables
		OracleDataReader	_reader;
		OracleCommand		_command;
		#endregion
		/// <summary>Creates a new <see cref="OraDataReader"/> class from the specified <paramref name="reader"/>. </summary>
		/// <param name="command"></param>
		/// <param name="reader">the <see cref="OracleDataReader"/> to encapsulate into the OraDataReader. </param>
		public OraDataReader(OracleCommand command, OracleDataReader reader)
		{
			//throw exception if reader is null;
			_reader		= reader;
			_command	= command;
		}
		/// <summary>Gets the <see cref="OraValue"/> at the specified <paramref name="index"/> position of the current row. </summary>
		public OraValue this[int index]
		{
			get
			{
				if(Validation.IsNull(_reader)) return new OraValue("NoDatabase", "NoDatabase");
                try
				{
					//INFO: dont try to retrieve typed data if it's value is equal to dbnull.
					if(_reader.IsDBNull(index)) return new OraValue(null, null);
					return new OraValue(_reader.GetName(index), _reader.GetOracleValue(index));
				}
				catch(Exception ex)
				{
					throw new OraDataReaderException(string.Format("column index {0} problem :", index), ex);
				}
			}
		}
		/// <summary>Gets the <see cref="OraValue"/> at the specified <paramref name="columnName"/> position of the current row. </summary>
		public OraValue this[string columnName]
		{
			get
			{
				if(Validation.IsNull(_reader)) return new OraValue("NoDatabase", "NoDatabase");
				int __index = -1;
				try
				{
					__index = _reader.GetOrdinal(columnName);
				}
				catch(Exception ex)
				{
					throw new OraDataReaderException("Column:" + columnName, ex);
				}
				return this[__index];
			}
		}
		/// <summary>Close the current OraDataReader. </summary>
		public void							Close()
		{
			if(Validation.IsNotNull(_reader) && !_reader.IsClosed)
			{
				_reader.Close();
				_reader.Dispose();
				_reader = null;
			}
			if(Validation.IsNotNull(_command)){
				//TEST ! nettoyage des parametres oracle avec reference serveur !
				foreach(OracleParameter __param in _command.Parameters){
					switch(__param.OracleDbType){
						case OracleDbType.RefCursor:
						case OracleDbType.Clob:
						case OracleDbType.Blob:
							__param.Dispose();
							break;
					}
				}
				_command.Dispose();
				_command = null;


			}
		}
		/// <summary>Gets the next row in the data reader and return true if exist, otherwise false. </summary>
		/// <returns><see langword="true"/> if there are more rows; otherwise, <see langword="false"/>.</returns>
		public bool							Read()
		{
			if(Validation.IsNull(_reader)) return false;
			return _reader.Read();
		}
		/// <summary>This method advances the data reader to the next result set. </summary>
		public bool							NextResult()
		{
			if(Validation.IsNull(_reader)) return false;
			return _reader.NextResult();
		}
		/// <summary>This method returns the name of the specified column. </summary>
		/// <param name="position">The zero-based column index. </param>
		/// <returns>The name of the column. </returns>
		public string						GetName(int position)
		{
			if(Validation.IsNull(_reader)) return "NoDatabase";
			return _reader.GetName(position);
		}
		/// <summary>This method returns the <see cref="OraValue"/> of the specified column. </summary>
		/// <param name="position">The zero-based column index. </param>
		/// <returns>The <see cref="OraValue"/> of the column. </returns>
		public OraValue					    GetValue(int position)
		{
			return this[position];
		}
		
		/// <summary>
		/// Permet de tester l'existance d'une colonne dans un reader. 
		/// Attention il faut que le reader soit ouvert pour pouvoir lancer cette commande
		/// </summary>
		/// <param name="columnName">Le nom de la colonne � tester</param>
		/// <returns>true si la colonne existe sinon false</returns>
		public bool							Exist_Column(string columnName)
		{
			try
			{
				return _reader.GetOrdinal(columnName)>=0;
			}
			catch
			{
				//Le reader est ferm� ou la colonne n'existe pas
			}
			return false;
		}

		/// <summary>This property gets the number of columns in the result set. </summary>
		public int							FieldCount
		{
			get{
	    		if(Validation.IsNull(_reader)) return 0;
                return _reader.FieldCount;
            }
		}
		/// <summary>This property check if current reader count at least 1 row.</summary>
		public bool							HasRows
		{
			get{
				if(Validation.IsNull(_reader)) return false;
				return _reader.HasRows;
			}
		}
		/// <summary>Retrieves an object that can iterate through the columns in this instance. </summary>
		/// <returns>The <see cref="IEnumerator"/> Instance. </returns>
		public IEnumerator					GetEnumerator()
		{
			return new OraDataReaderColumnsEnumerator(this);
		}
		/// <summary>This property gets the inner <see cref="OracleDataReader"/> encapsuled in the current instance. </summary>
		/// <remarks>Internal use, you should used OraDataReader methods/properties instead of this object. </remarks>
		public OracleDataReader				InnerDataReader
		{
			get{return _reader;}
		}
		/// <summary>Allows implicit <see cref="OraDataReader"/> to <see cref="OracleDataReader"/> casting. </summary>
		/// <param name="value">The <see cref="OraDataReader"/> to cast. </param>
		/// <returns>the <see cref="OracleDataReader"/> result. </returns>
		public	static implicit	operator	OracleDataReader(OraDataReader value)
		{
			return (OracleDataReader)value._reader;
		}
		private class OraDataReaderColumnsEnumerator: IEnumerator
		{
			#region internal variables
			OraDataReader	_reader;
			int						_position = -1;
			#endregion
			/// <summary>Creates a new <see cref="OraDataReaderColumnsEnumerator"/> instance from the specified <paramref name="reader"/>. </summary>
			/// <param name="reader">the <paramref name="OraDataReader"/> used to enumerate columns. </param>
			internal OraDataReaderColumnsEnumerator(OraDataReader reader) 
			{
				_reader = reader;
			}
			/// <summary>Gets the current OraValue column of the enumeration. </summary>
			public object Current 
			{
				get 
				{
					return _reader[_position];
				}
			}
			/// <summary>Sets the current position of the enumeration to -1. </summary>
			public void		Reset() 
			{
				_position = -1;
			}
			/// <summary>Move the enumeration to the next position and return if it's allowed. </summary>
			/// <returns><see langword="true"/> if more elements exist. otherwise <see langword="false"/>. </returns>
			public bool		MoveNext() 
			{
				return (++_position < _reader.FieldCount);
			}
		}

        #region IDisposable Members

        public void Dispose()
        {
            this.Close();
        }

        #endregion
    }

	public class OraDataReaderException: Exception{
		public OraDataReaderException(string columnName, Exception innerException): base(columnName, innerException){
			
		}
	}
}