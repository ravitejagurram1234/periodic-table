using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Oracle.DataAccess.Client;



namespace QXP.Framework.Data.Oracle
{
    /// <summary>
    /// Liste d'OraParameter
    /// </summary>
	public class OraParameterList : List<OraParameter>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance d'OraParameterList
        /// </summary>
        public OraParameterList ()
		{
		}

        /// <summary>
        /// Cr�e une instance d'OraParameterList � partir d'un Ienumerable d'OraParameter
        /// </summary>
        public OraParameterList (IEnumerable<OraParameter> enumerableOraParameter) : base(enumerableOraParameter)
		{
		}

        /// <summary>
        /// Cr�e une instance d'OraParameterList
        /// </summary>
        /// <param name="capacity">Nombre d'�l�ments de la liste</param>
		public OraParameterList (int capacity) : base(capacity)
		{
		}

        #endregion Constructeur

        #region M�thodes

        #region ADD

        ///<summary>
        /// Ajoute un OraParameter � la Liste
        /// </summary>
        /// <param name="paramName">Nom du parametre</param>
        /// <param name="value">Valeur du parametre</param>
        /// <returns>La liste OraParameterList</returns>
        public OraParameterList AddParameterToSqlParamList(string paramName, object value)
        {
            // On laisse volontairement potentiellement un pointeur null entrer afin de lever l'exception.
            this.Add(new OraParameter(paramName, value));            
            return this;
        }

        ///<summary>
        /// Ajoute un OraParameter � la Liste
        /// </summary>
        /// <param name="paramName">Nom du parametre</param>
        /// <param name="value">Valeur du parametre</param>
        /// <param name="prefixeParam">Pr�fixe du nom du parametre</param>
        /// <returns>La liste OraParameterList</returns>
        public OraParameterList AddParameterToSqlParamList(string paramName, object value, string prefixeParam)
        {
            return this.AddParameterToSqlParamList(string.Concat(prefixeParam, paramName), value);
        }
        
        ///<summary>
        /// Ajoute un OraParameter � la Liste
        /// </summary>
        /// <param name="paramName">Nom du parametre</param>
        /// <param name="type">Type du param�tre (OracleDbType)</param>
        /// <param name="direction">Direction du param�tre (ParameterDirection)</param>
        /// <returns>La liste OraParameterList</returns>
        public OraParameterList AddParameterToSqlParamList(string paramName, OracleDbType type, ParameterDirection direction)
        {
            this.Add(new OraParameter(paramName, type, direction));
            return this;
        }

        ///<summary>
        /// Ajoute un OraParameter � la Liste
        /// </summary>
        /// <param name="paramName">Nom du parametre</param>
        /// <param name="value">Valeur du parametre</param>
        /// <param name="type">Type du param�tre (OracleDbType)</param>
        /// <param name="direction">Direction du param�tre (ParameterDirection)</param>
        /// <returns>La liste OraParameterList</returns>
        public OraParameterList AddParameterToSqlParamList(string paramName, object value, OracleDbType type, ParameterDirection direction)
        {
            // On laisse volontairement potentiellement un pointeur null entrer afin de lever l'exception.
            this.Add(new OraParameter(paramName, type, value, direction));
			return this;
        }
        
        #endregion ADD

        #region DEL

        /// <summary>
        /// Supprime un OraParameter de la Liste
        /// </summary>
        /// <param name="paramName">Nom du parametre</param>
        /// <returns>Vrai si l'objet existe et a �t� supprim�</returns>
        public bool DelParameterToSqlParamList(string paramName)
        {
            OraParameter __parameter = GetParameter(paramName);
            if(Validation.IsNotNull(__parameter))
            {
                this.Remove(__parameter);
                return true;
            }
            
            return false;
        }

        #endregion DEL

        #region REPLACE

        ///<summary>
        /// Remplace un OraParameter � la Liste
        /// </summary>
        /// <param name="paramName">Nom du parametre</param>
        /// <param name="value">Valeur du parametre</param>
        /// <returns>La liste OraParameterList</returns>
        public OraParameterList ReplaceParameterToSqlParamList(string paramName, object value)
        {
            DelParameterToSqlParamList(paramName);
            return AddParameterToSqlParamList(paramName, value);
        }

        ///<summary>
        /// Remplace un OraParameter � la Liste
        /// </summary>
        /// <param name="paramName">Nom du parametre</param>
        /// <param name="value">Valeur du parametre</param>
        /// <param name="prefixeParam">Pr�fixe du nom du parametre</param>
        /// <returns>La liste OraParameterList</returns>
		public OraParameterList ReplaceParameterToSqlParamList(string paramName, object value, string prefixeParam)
        {
			return this.ReplaceParameterToSqlParamList(string.Concat(prefixeParam, paramName), value);
        }
        
        ///<summary>
        /// Remplace un OraParameter � la Liste
        /// </summary>
        /// <param name="paramName">Nom du parametre</param>
        /// <param name="type">Type du param�tre (OracleDbType)</param>
        /// <param name="direction">Direction du param�tre (ParameterDirection)</param>
        /// <returns>La liste OraParameterList</returns>
        public OraParameterList ReplaceParameterToSqlParamList(string paramName, OracleDbType type, ParameterDirection direction)
        {
            DelParameterToSqlParamList(paramName);
            return AddParameterToSqlParamList(paramName, type, direction);           
        }

        #endregion REPLACE

        public OraParameter GetParameter(string paramName)
        {
            return this.Find
                (
                    delegate (OraParameter __parameter)
                    {
                        return __parameter.Parameter.ParameterName == paramName;
                    }
            );
        }

        public OraParameterList Clone()
        {
            OraParameterList __oraParameterList = new OraParameterList();
            this.ForEach
            (
                delegate(OraParameter __oraParameter)
                {
                    OraParameter __oraParameterCloned = __oraParameter.Clone();
                    __oraParameterList.Add(__oraParameterCloned);
                }
            );
            return __oraParameterList;
        }
        
        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s



    }
}
