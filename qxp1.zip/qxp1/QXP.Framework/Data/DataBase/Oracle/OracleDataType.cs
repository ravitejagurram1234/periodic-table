using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Text;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace QXP.Framework.Data.Oracle
{
//	public class OraBinary{
//		byte[]		_value		= new byte[0];
//		public OraBinary(string value){
//			_value		= Conversion.ToByteArray(value);
//		}
//		public OraBinary(byte[] value){
//			_value = value;
//		}
//		public byte[]			Value{
//			get{return _value;}
//		}
//		public int				Length{
//			get{return _value.Length;}
//		}
//		public override string	ToString()
//		{
//			return Conversion.ToHexString(_value);
//		}
//	}
}