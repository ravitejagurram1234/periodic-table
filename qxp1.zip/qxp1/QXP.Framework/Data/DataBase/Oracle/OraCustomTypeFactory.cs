using System;
using System.Collections.Generic;
using System.Text;
using QXPFrk = QXP.Framework;
using Oracle.DataAccess.Types;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Data.Oracle
{
    /// <summary>
    /// Class OraCustomTypeFactory : Factory de base de la factory des objets .NET mapp�s � des objets Oracle
    /// </summary>
    /// <author>cueffl</author>
    /// <date>12/09/2011 16:13:32</date>    
    public class OraCustomTypeFactory<T> : IOracleCustomTypeFactory where T : IOracleCustomType, new()  
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de OraCustomTypeFactory
        /// </summary>
        public OraCustomTypeFactory()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Cr�ation de l'objet IOracleCustomType
        /// </summary>
        /// <returns>IOracleCustomType</returns>
        public virtual IOracleCustomType CreateObject()
        {
            T obj = new T();
            return obj;
        }  

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
