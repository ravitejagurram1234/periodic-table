using System;
using System.Collections;
using System.Data;
using System.IO;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using QXP.Framework.Configuration;

namespace QXP.Framework.Data.Oracle
{
    /// <summary>
    /// Class OraClient : Provides methods to access Oracle Database.
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class OraClient : IDisposable
    {
        #region Membres

        /// <summary>Gets the <see cref="OracleConnection"/> of the current client. </summary>
        protected OracleConnection _connection;
        private int _command_Timeout = 0; // en sec (def 0 alors pas de timeout);
        private int _maxPoolSize = 10;
        private FillErrorEventHandler _fillError;
        private OracleTransaction _transaction;
        private Hashtable _safeMapping;
        private bool _individualConnection = false;
        private string _connection_String;
        private bool _no_database = true;
        private string _dataBaseName = null;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        /// <summary>Defines oracle connection management. </summary>
        public enum OracleConnectionOwnership
        {
            /// <summary>Connection is owned and managed by OracleHelper</summary>
            Internal,
            /// <summary>Connection is owned and managed by the caller</summary>
            External
        }

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new Instance of <see cref="OraClient"/> class with specified <paramref name="connectionString"/>. </summary>
        /// <param name="connectionString">Specifies the connection information used to connect to an Oracle database. </param>
        public OraClient(string connectionString)
        {
            if (Validation.IsSet(connectionString))
            {
                if (connectionString.ToLower().IndexOf("max pool size") == -1)
                {
                    connectionString = string.Format("{0};Max Pool Size={1}", connectionString, _maxPoolSize);
                }
                _connection_String = connectionString;
                _no_database = false;
            }
            //_connection		= new OracleConnection(connectionString);
            _safeMapping = new Hashtable();
        }

        #endregion Constructeur

        #region M�thodes

        public static OraClient Create(string dbName)
        {
            OraClient __client = new OraClient(GetDBConnexionString(dbName));
            __client._dataBaseName = dbName;
            return __client;
        }

        private static string GetDBConnexionString(string nameConnection)
        {
            string __DBConnectionString = string.Empty;
            if (Validation.IsSet(nameConnection))
            {
                __DBConnectionString = DBConnectionSettings.Current.GetDBConnectionString(nameConnection);
            }
            else
            {
                __DBConnectionString = DBConnectionSettings.Current.GetDefaultDBConnectionString();
            }
            return __DBConnectionString;
        }

        private void AttachParameters(OracleCommand command, OraParameter[] parameters)
        {
            if (Validation.IsNull(parameters)) return;
            foreach (OraParameter __p in parameters)
            {
                OracleParameter p = __p;

                if (__p.IsStreamed)
                {
                    Stream __lobObject = null;
                    //INFO: enter in critical section bloc because Lob's data type are generated on server and can be large amount on data.
                    //INFO: this Try..Catch..Finaly prevent memory leaks on Oracle server.
                    try
                    {
                        //INFO: It's time to generate a temporary Blob or Clob on server.
                        switch (p.OracleDbType)
                        {
                            case OracleDbType.Blob:
                                __lobObject = new OracleBlob(command.Connection, __p.Cached);
                                break;
                            case OracleDbType.Clob:
                                __lobObject = new OracleClob(command.Connection, __p.Cached, false);
                                break;
                            default: //Invalid OracleDbType
                                break;
                        }
                        if (Validation.IsNotNull(__lobObject))
                        {
                            byte[] __buffer = new byte[__p.StreamBufferSize];
                            int __bytesRead;
                            while ((__bytesRead = __p.Stream.Read(__buffer, 0, __p.StreamBufferSize)) > 0)
                            {
                                __lobObject.Write(__buffer, 0, __bytesRead);
                            }
                            __p.Value = __lobObject;
                            //						if(!this.IsTransactional){
                            //							this.BeginTransaction();
                            //						}
                            //						_isTransactionnalStreamed = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        //INFO: LOG EXCEPTION
                        if (Validation.IsNotNull(__lobObject)) ((IDisposable)__lobObject).Dispose();
                        throw new OracleClientException("AttachParameters", ex);
                    }
                    finally
                    {
                        if (__p.AutoCloseStream) __p.Stream.Close();
                    }
                }
                else
                {
                    //check for derived output value with no value assigned
                    if ((p.Direction == ParameterDirection.InputOutput) && (p.Value == null))
                    {
                        p.Value = DBNull.Value;
                    }
                    if (p.CollectionType != OracleCollectionType.PLSQLAssociativeArray)
                    {
                        //INFO: Added to handle empty string params
                        if (Validation.IsNotSet(p.Value)) p.Value = DBNull.Value;
                    }
                }

                //INFO: special test for blob or clob parameter type:
                command.Parameters.Add(p);
            }
        }

        private void PrepareCommand(OracleCommand command, CommandType commandType, string commandText, params OraParameter[] parameters)
        {
            OracleConnection __connection = this.GetConnection();
            //if the provided connection is not open, we will open it
            if (__connection.State != ConnectionState.Open)
            {
                __connection.Open();
            }

            //associate the connection with the command
            command.Connection = __connection;

            //set the command text (stored procedure name or Oracle statement)
            command.CommandText = commandText;

            //set the command type
            command.CommandType = commandType;

            //attach the command parameters if they are provided
            if (Validation.IsNotNull(parameters))
            {
                AttachParameters(command, parameters);
            }

            return;
        }

        private OracleConnection GetConnection()
        {
            if (_individualConnection && Validation.IsNull(_transaction))
            {
                return new OracleConnection(_connection_String);
            }
            else
            {
                if (Validation.IsNull(_connection))
                {
                    _connection = new OracleConnection(_connection_String);
                }
                return _connection;
            }
        }

        private OracleCommand GetCommand()
        {
            OracleCommand __command = new OracleCommand();
            __command.BindByName = true;
            if (_command_Timeout > 0) __command.CommandTimeout = _command_Timeout;
            return __command;
        }

        internal void CloseConnection()
        {
            try
            {
                if (Validation.IsNotNull(_connection))
                {
                    _connection.Close();
                    _connection.Dispose();
                    _connection = null;
                }
            }
            catch { }
        }

        internal void CloseTransaction()
        {
            try
            {
                if (Validation.IsNotNull(_transaction))
                {
                    _transaction.Rollback();
                    _transaction.Dispose();
                    _transaction = null;
                }
            }
            catch { }
        }

        /// <summary>Close the oracle connection if opened. </summary>
        public void Close()
        {
            try
            {
                this.CloseTransaction();
                this.CloseConnection();
            }
            catch { }
        }

        /// <summary>Start a new transaction. </summary>
        /// <returns></returns>
        public OracleTransaction BeginTransaction()
        {
            this.CloseTransaction();
            OracleConnection __connection = this.GetConnection();
            if (__connection.State != ConnectionState.Open) __connection.Open();
            _transaction = __connection.BeginTransaction();
            return _transaction;
        }

        /// <summary>Commit current transaction if exist. </summary>
        public void CommitTransaction()
        {
            if (Validation.IsNotNull(_transaction))
            {
                try
                {
                    _transaction.Commit();
                    _transaction.Dispose();
                    _transaction = null;
                    this.CloseConnection();
                }
                catch { }
            }
        }

        /// <summary>RollBack current transaction if exist. </summary>
        public void RollBackTransaction()
        {
            this.Close();
        }

        #region ExecuteScalar

        /// <summary>
        ///  Executes the query, and returns the first column of the first row in the resultset returned by the query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <param name="parameters">Optional, The <see cref="OraParameter"/> array of the query. </param>
        /// <returns>The <see cref="OraValue"/> which contains the evaluated result. </returns>
        public OraValue ExecuteScalar(CommandType commandType, string commandText, params OraParameter[] parameters)
        {
            return ExecuteScalar(commandType, commandText, ValueType.CLSstring, string.Empty, parameters);
        }

        /// <summary>
        ///  Executes the query, and returns the first column of the first row in the resultset returned by the query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <param name="udtTypeName">Si d�finit, il indique le nom de l'objet oracle utilis� dans le mapping Oracle avec l'objet retourn�</param>
        /// <param name="parameters">Optional, The <see cref="OraParameter"/> array of the query. </param>
        /// <returns>The <see cref="OraValue"/> which contains the evaluated result. </returns>
        public OraValue ExecuteScalar(CommandType commandType, string commandText, string udtTypeName, params OraParameter[] parameters)
        {
            return ExecuteScalar(commandType, commandText, ValueType.CLSstring, udtTypeName, parameters);
        }

        /// <summary>
        ///  Executes the query, and returns the first column of the first row in the resultset returned by the query. Extra columns or rows are ignored.
        /// </summary>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <param name="returnType">The return system type of the query. </param>
        /// <param name="udtTypeName">Si d�finit, il indique le nom de l'objet oracle utilis� dans le mapping Oracle avec l'objet retourn�</param>
        /// <param name="parameters">Optional, The <see cref="OraParameter"/> array of the query. </param>
        /// <returns>The <see cref="OraValue"/> which contains the evaluated result. </returns>
        public OraValue ExecuteScalar(CommandType commandType, string commandText, Type returnType, string udtTypeName, params OraParameter[] parameters)
        {
            if (_no_database) return new OraValue("NoDataBase", "NoDataBase");
            //create a command and prepare it for execution
            OracleCommand __cmd = this.GetCommand();
            OraValue __result = new OraValue(null, null);
            OracleParameter __resultParameter = null;
            bool __isStoreProc = (commandType == CommandType.StoredProcedure);

            try
            {
                PrepareCommand(__cmd, commandType, commandText, parameters);

                if (__isStoreProc)
                {
                    //INFO: Insert Default ReturnValue parameter !!
                    if (Validation.IsNull(parameters) || parameters.Length == 0 || parameters[0].Parameter.Direction != ParameterDirection.ReturnValue)
                    {
                        OracleDbType __dbType = Conversion.ToOracleDBType(returnType);
                        __resultParameter = new OracleParameter("RETURN_VALUE", __dbType, ParameterDirection.ReturnValue);
                        if (Validation.IsSet(udtTypeName))
                            __resultParameter.UdtTypeName = udtTypeName;
                        if (__dbType == OracleDbType.Varchar2) __resultParameter.Size = 255;
                        __cmd.Parameters.Insert(0, __resultParameter);
                    }
                    else
                    {
                        __resultParameter = parameters[0];
                    }
                }

                if (__isStoreProc)
                {
                    __cmd.ExecuteNonQuery();
                    __result = new OraValue(__resultParameter.ParameterName, __resultParameter.Value);
                }
                else
                {
                    OraDataReader __reader = new OraDataReader(__cmd, __cmd.ExecuteReader());
                    if (__reader.Read())
                    {
                        __result = __reader[0];
                    }
                    __reader.Close();
                }
            }
            catch (Exception ex)
            {
                throw new OracleClientException("ExecuteScalar", commandType, commandText, ex);
            }
            finally
            {
                if (Validation.IsNotNull(__cmd))
                {
                    __cmd.Dispose();
                }
                if (!this.IsTransactional) this.Close();
            }
            return __result;
        }

        #endregion ExecuteScalar

        #region ExecuteNonQuery

        /// <summary>Executes a query and returns the number of rows affected. </summary>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <returns>the <see cref="Int32"/> affected records. </returns>
        public int ExecuteNonQuery(CommandType commandType, string commandText)
        {
            //pass through the call providing null for the set of OracleParameters
            return ExecuteNonQuery(commandType, commandText, (OraParameter[])null);
        }
        
        /// <summary>Executes a query and returns the number of rows affected. </summary>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <param name="parameters">Optional, The <see cref="OraParameter"/> array of the query. </param>
        /// <returns>the <see cref="Int32"/> affected records. </returns>
        public int ExecuteNonQuery(CommandType commandType, string commandText, params OraParameter[] parameters)
        {
            if (_no_database) return 0;

            //create a command and prepare it for execution
            OracleCommand __cmd = this.GetCommand();
            PrepareCommand(__cmd, commandType, commandText, parameters);

            int __result = 0;
            try
            {
                //finally, execute the command.
                __result = __cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new OracleClientException("ExecuteNonQuery", commandType, commandText, ex);
            }
            finally
            {
                if (Validation.IsNotNull(__cmd))
                {
                    __cmd.Dispose();
                }
                if (!this.IsTransactional) this.Close();

            }
            //			if(!this.IsTransactional){
            //				this.Close();
            //			}else{
            //				if(_isTransactionnalStreamed){
            //					_isTransactionnalStreamed = false;
            //					_transaction.Commit();
            //				}
            //			}
            return __result;
        }
        
        #endregion ExecuteNonQuery

        #region ExecuteReader
        
        /// <summary>Executes a query and build an <see cref="OraDataReader"/>. </summary>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <param name="parameters">Optional, The <see cref="OraParameter"/> array of the query. </param>
        /// <param name="connectionOwnership">Defines oracle connection management type. default value is <see cref="OracleConnectionOwnership.Internal"/>. </param>
        /// <returns>The <see cref="OraDataReader"/> generated from the query. </returns>
        public OraDataReader ExecuteReader(CommandType commandType, string commandText, OraParameter[] parameters, OracleConnectionOwnership connectionOwnership)
        {
            if (_no_database) return new OraDataReader(null, null);

            //create a command and prepare it for execution
            OracleCommand __cmd = this.GetCommand();
            //create a reader
            OraDataReader __dr = null;
            try
            {
                PrepareCommand(__cmd, commandType, commandText, parameters);

                // call ExecuteReader with the appropriate CommandBehavior
                if (connectionOwnership == OracleConnectionOwnership.External)
                {
                    __dr = new OraDataReader(__cmd, __cmd.ExecuteReader());
                }
                else
                {
                    __dr = new OraDataReader(__cmd, __cmd.ExecuteReader((CommandBehavior)((int)CommandBehavior.CloseConnection)));
                }
            }
            catch (Exception ex)
            {
                if (Validation.IsNotNull(__cmd))
                {
                    __cmd.Dispose();
                }
                this.Close();
                throw new OracleClientException("ExecuteReader", commandType, commandText, ex);
            }
            return __dr;
        }
        
        /// <summary>Executes a query and build an <see cref="OraDataReader"/>. </summary>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <param name="parameters">Optional, The <see cref="OraParameter"/> array of the query. </param>
        /// <returns>The <see cref="OraDataReader"/> generated from the query. </returns>
        public OraDataReader ExecuteReader(CommandType commandType, string commandText, params OraParameter[] parameters)
        {
            return ExecuteReader(commandType, commandText, parameters, OracleConnectionOwnership.Internal);
        }
        
        /// <summary>Executes a query and build an <see cref="OraDataReader"/>. </summary>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <returns>The <see cref="OraDataReader"/> generated from the query. </returns>
        public OraDataReader ExecuteReader(CommandType commandType, string commandText)
        {
            //pass through the call providing null for the set of OracleParameters
            return ExecuteReader(commandType, commandText, (OraParameter[])null);
        }
        
        #endregion ExecuteReader

        #region ExecuteDataSet
        
        /// <summary>Adds or refreshes rows in the DataSet to match those in the data source using the DataSet name, and creates a DataTable named "Table". </summary>
        /// <param name="ds">The <see cref="DataSet"/> to fill, otherwise null to generate a new DataSet. </param>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <returns>The <see cref="OraDataSet"/> that encapsulate the generated dataset. </returns>
        public OraDataSet ExecuteDataset(DataSet ds, CommandType commandType, string commandText)
        {
            //pass through the call providing null for the set of OracleParameters
            return ExecuteDataset(ds, commandType, commandText, (OraParameter[])null);
        }
        
        /// <summary>Adds or refreshes rows in the DataSet to match those in the data source using the DataSet name, and creates a DataTable named <paramref name="tableName"/>. </summary>
        /// <param name="ds">The <see cref="DataSet"/> to fill, otherwise null to generate a new DataSet. </param>
        /// <param name="tableName">the name of the new created table in the dataSet. </param>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <returns>The <see cref="OraDataSet"/> that encapsulate the generated dataset. </returns>
        public OraDataSet ExecuteDataset(DataSet ds, string tableName, CommandType commandType, string commandText)
        {
            return ExecuteDataset(ds, tableName, commandType, commandText, (OraParameter[])null);
        }
        
        /// <summary>Adds or refreshes rows in the DataSet to match those in the data source using the DataSet name, and creates a DataTable named "Table". </summary>
        /// <param name="ds">The <see cref="DataSet"/> to fill, otherwise null to generate a new DataSet. </param>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <param name="parameters">Optional, The <see cref="OraParameter"/> array of the query. </param>
        /// <returns>The <see cref="OraDataSet"/> that encapsulate the generated dataset. </returns>
        public OraDataSet ExecuteDataset(DataSet ds, CommandType commandType, string commandText, params OraParameter[] parameters)
        {
            return ExecuteDataset(ds, null, commandType, commandText, parameters);
        }
        
        /// <summary>Adds or refreshes rows in the DataSet to match those in the data source using the DataSet name, and creates a DataTable named <paramref name="tableName"/>. </summary>
        /// <param name="ds">The <see cref="DataSet"/> to fill, otherwise null to generate a new DataSet. </param>
        /// <param name="tableName">the name of the new created table in the dataSet. </param>
        /// <param name="commandType">The <see cref="CommandType"/> of the query. </param>
        /// <param name="commandText">The string text of the query. </param>
        /// <param name="parameters">Optional, The <see cref="OraParameter"/> array of the query. </param>
        /// <returns>The <see cref="OraDataSet"/> that encapsulate the generated dataset. </returns>
        public OraDataSet ExecuteDataset(DataSet ds, string tableName, CommandType commandType, string commandText, params OraParameter[] parameters)
        {
            if (_no_database) return new OraDataSet(new DataSet());
            if (Validation.IsNull(ds)) ds = new DataSet();
            //create a command and prepare it for execution
            OracleCommand __cmd = this.GetCommand();

            OracleDataAdapter __da = null;

            try
            {
                PrepareCommand(__cmd, commandType, commandText, parameters);

                //create the DataAdapter
                __da = new OracleDataAdapter(__cmd);

                if (_safeMapping.Count > 0)
                {
                    foreach (DictionaryEntry __entry in _safeMapping) __da.SafeMapping.Add(__entry.Key, __entry.Value);
                }
                if (Validation.IsSet(_fillError))
                {
                    __da.FillError += _fillError;
                }

                //fill the DataSet using default values for DataTable names, etc.
                if (Validation.IsSet(tableName))
                {
                    __da.Fill(ds, tableName);
                }
                else
                {
                    __da.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                throw new OracleClientException("ExecuteDataset", commandType, commandText, ex);
            }
            finally
            {
                if (Validation.IsNotNull(__da))
                {
                    __da.Dispose();
                }
                if (Validation.IsNotNull(__cmd))
                {
                    __cmd.Dispose();
                }
                this.Close();
            }
            //return the dataset
            return new OraDataSet(ds);
        }

        #endregion ExecuteDataSet

        #region Clean Finalize

        /// <summary>perform a proper client finalization. </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        
        private void Dispose(bool disposing)
        {
            try
            {
                this.Close();
                if (Validation.IsNotNull(_connection)) _connection.Dispose();
            }
            catch { }
        }

        #endregion Clean Finalize

        public OracleParameterCollection DeriveParameters(string sp_or_fn_name)
        {
            //create a command and prepare it for execution
            OracleCommand __cmd = this.GetCommand();
            OracleParameterCollection __params = null;

            PrepareCommand(__cmd, CommandType.StoredProcedure, sp_or_fn_name, (OraParameter[])null);

            try
            {
                //OracleDataAdapter		__adapter			= new OracleDataAdapter(__cmd);
                OracleCommandBuilder.DeriveParameters(__cmd);
                __params = __cmd.Parameters;
            }
            catch (Exception ex)
            {
                throw new OracleClientException("DeriveParameters", CommandType.StoredProcedure, sp_or_fn_name, ex);
            }
            finally
            {
                this.Close();
            }
            return __params;
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>Defines a mapping between column names in the result set to .NET types that represent column values in the DataSet, to preserve the data. </summary>
        public Hashtable SafeMapping
        {
            get { return _safeMapping; }
        }

        /// <summary>Returned when an error occurs during a fill operation. </summary>
        public event FillErrorEventHandler FillError
        {
            add { _fillError += value; }
            remove { _fillError -= value; }
        }

        /// <summary>Gets the <see cref="OracleTransaction"/> associated with current client. </summary>
        public OracleTransaction Transaction
        {
            get
            {
                return _transaction;
            }
        }

        /// <summary>Checks if current client is in transactional mode. </summary>
        public bool IsTransactional
        {
            get { return Validation.IsNotNull(_transaction); }
        }

        public bool Individual_Connection
        {
            get { return _individualConnection; }
            set { _individualConnection = value; }
        }

        /// <summary>
        /// Command Timeout execution (in seconds) def = 0 (no limit)
        /// </summary>
        public int Command_Timeout
        {
            get { return _command_Timeout; }
            set { _command_Timeout = value; }
        }

        /// <summary>
        /// Nom de la dataBase dans le fichier de configuration de l'application
        /// Null si l'oraclient a �t� cr�� directement � partir d'une chaine de connexion
        /// Diff�rent de Null si l'oraclient a �t� cr�� � partir du nom de la database dans le ficheir de config
        /// </summary>
        public string DataBaseName
        {
            get { return _dataBaseName; }
        }

        #endregion Propri�t�s
    }

    /// <summary>
    /// Class OracleClientException : OracleClientException
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class OracleClientException : Exception
    {
        #region Membres

        int _error_Number = int.MinValue;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        public OracleClientException(string message, Exception innerException)
            : base(message, innerException)
        {
            this.EvaluateOracleInfo();
        }

        public OracleClientException(string method, CommandType commandType, string sql, Exception innerException)
            : this(GetMessage(method, commandType, sql), innerException)
        {
            this.EvaluateOracleInfo();
        }

        #endregion Constructeur

        #region M�thodes

        private void EvaluateOracleInfo()
        {
            OracleException __oex = InnerException as OracleException;
            if (Validation.IsNotNull(__oex))
            {
                _error_Number = __oex.Number;
            }
        }

        public override string ToString()
        {
            Exception __inner = InnerException;
            if (Validation.IsNotNull(__inner))
            {
                return string.Concat(__inner.Message, ":", this.Message);
            }
            else
            {
                return base.ToString();
            }
        }

        static string GetMessage(string method, CommandType commandType, string sql)
        {
            string __message = string.Format("Method:{0} CommandType:{1} SQL:{2}", method, commandType, sql);
            return __message;
        }

        #endregion M�thodes

        #region Propri�t�s

        public int Error_Number
        {
            get { return _error_Number; }
        }

        #endregion Propri�t�s
    }
}