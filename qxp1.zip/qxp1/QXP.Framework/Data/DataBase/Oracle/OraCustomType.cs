using System;
using System.Collections.Generic;
using System.Text;
using QXPFrk = QXP.Framework;
using Oracle.DataAccess.Types;
using Oracle.DataAccess.Client;
using System.Linq;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Data.Oracle
{
    /// <summary>
    /// Attribut utilis� pour d�finir une propri�t� � ignorer
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class IgnoreAttribute : Attribute
    {
    }

    /// <summary>
    /// Class OraCustomType : Objet de base pour la cr�ation d'objets .NET mapp�s � des objets Oracle
    /// </summary>
    /// <author>cueffl</author>
    /// <date>12/09/2011 16:07:00</date>    
    public abstract class OraCustomType : IOraCustomType
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de OraCustomType
        /// </summary>
        public OraCustomType()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// M�thode utilis�e par Oracle pour construire l'objet qui sera envoy� � Oracle � partir de l'objet en cours
        /// Tous les propri�t�s OracleObjectMappingAttribute sont envoy�es
        /// </summary>
        /// <param name="con">OracleConnection</param>
        /// <param name="pUdt">IntPtr Pointeur Oracle</param>
        public virtual void FromCustomObject(OracleConnection con, IntPtr pUdt)
        {
            foreach (var __property in GetType().GetProperties())
            {
                var __oracleObjectMappingAttributes = __property.GetCustomAttributes(typeof(OracleObjectMappingAttribute), false);
                if (__oracleObjectMappingAttributes.Count() != 0)
                {
                    string __attributeName = (__oracleObjectMappingAttributes[0] as OracleObjectMappingAttribute).AttributeName;

                    if (__property.GetCustomAttributes(typeof(IgnoreAttribute), false).Length == 0)
                    {
                        var __value = __property.GetValue(this, null);
                        if (QXPFrk.Validation.IsSet(__value))
                            OracleUdt.SetValue(con, pUdt, __attributeName, __value);
                        else
                            OracleUdt.SetValue(con, pUdt, __attributeName, DBNull.Value);
                    }
                }
            }
        }

        /// <summary>
        /// M�thode utilis�e par Oracle pour construire l'objet qui sera r�cup�r�e d'Oracle (ex RETURN d'une fonction d'un package)
        /// Tous les propri�t�s OracleObjectMappingAttribute sont aliment�es
        /// </summary>
        /// <param name="con">OracleConnection</param>
        /// <param name="pUdt">IntPtr Pointeur Oracle</param>
        public virtual void ToCustomObject(OracleConnection con, IntPtr pUdt)
        {
            foreach (var __property in GetType().GetProperties())
            {
                var __oracleObjectMappingAttributes = __property.GetCustomAttributes(typeof(OracleObjectMappingAttribute), false);
                if (__oracleObjectMappingAttributes.Count() != 0)
                {
                    string __attributeName = (__oracleObjectMappingAttributes[0] as OracleObjectMappingAttribute).AttributeName;
                    if (!OracleUdt.IsDBNull(con, pUdt, __attributeName))
                    {
                        __property.SetValue(this, QXP_Value_Helper.ToObject(OracleUdt.GetValue(con, pUdt, __attributeName), __property.PropertyType), null);
                    }
                }
            }
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Indique si l'objet est null ou non
        /// </summary>
        public abstract bool IsNull
        {
            get;
        }

        /// <summary>
        /// Indique le nom de l'objet oracle utilis� dans le mapping Oracle avec l'objet OraCustomType
        /// </summary>
        public abstract string UdtTypeName
        {
            get;
        }

        #endregion Propri�t�s
    }
}
