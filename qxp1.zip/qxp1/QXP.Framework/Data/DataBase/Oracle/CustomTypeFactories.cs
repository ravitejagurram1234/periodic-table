using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;

using Oracle.DataAccess.Types;
using Oracle.DataAccess.Client;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Data.Oracle
{
	/// <summary>
	/// Factory utilis�e par oracle pour cr��e les objets qui vont contenir les valeurs du type ORA_OBJECT
	/// </summary>
	/// <remarks>
	/// le mapping doit est d�fini dans le fichier oracle.dataaccess.client / setting / add
	/// </remarks>
	public class OraObjectFactory : IOracleCustomTypeFactory
	{
	  public IOracleCustomType CreateObject()
	  {
		return new OraObject();
	  }
	}	
}
