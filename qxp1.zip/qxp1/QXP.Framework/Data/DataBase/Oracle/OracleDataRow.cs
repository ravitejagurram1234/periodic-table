using System;
using System.Collections;
using System.Data;
using System.IO;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace QXP.Framework.Data.Oracle
{
	/// <summary>Provides an user friendly access to a <see cref="DataRow"/> instance. </summary>
	public sealed class OraDataRow
	{
		#region internal variables
		DataRow				_row;
		DataTable			_table;
		#endregion
		/// <summary>Creates a new instance of <see cref="OraDataRow"/> class from the specified <paramref name="row"/>. </summary>
		/// <param name="row">The <paramref name="DataRow"/>  to encapsulate into the <see cref="OraDataRow"/>. </param>
		public OraDataRow(DataRow row)
		{
			_row		= row;
			_table	= _row.Table;
		}
		/// <summary>Gets the <see cref="OraValue"/> at from the <paramref name="columnName"/>. </summary>
		public OraValue this[string columnName]
		{
			get{return new OraValue(columnName, _row[columnName]);}
		}
		/// <summary>Gets the <see cref="OraValue"/> at the specified <paramref name="index"/> position. </summary>
		public OraValue this[int index]
		{
			get{return new OraValue(_table.Columns[index].ColumnName, _row[index]);}
		}
		/// <summary>Allows implicit <see cref="OraDataRow"/> to <see cref="DataRow"/> casting. </summary>
		/// <param name="value">The <see cref="OraDataRow"/> to cast. </param>
		/// <returns>the <see cref="DataRow"/> result. </returns>
		public	static implicit	operator	DataRow(OraDataRow value)
		{
			return (DataRow)value._row;
		}
	}
}