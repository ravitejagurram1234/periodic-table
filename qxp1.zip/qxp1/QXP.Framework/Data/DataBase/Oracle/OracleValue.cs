using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace QXP.Framework.Data.Oracle
{
	/// <summary>Provides means to convert Oracle Value to .NET Value. </summary>
	public sealed class OraValue: IComparable<OraValue>
	{
		#region internal variables
		string			_columnName;
		object			_value;
		#endregion

		#region locale classe

		/// <summary>
		/// Class ComparerOraValue : D�finit l'impl�mentation de la comparaison entre deux oravalue
		/// </summary>
		/// <author>LCU</author>
		/// <date>17/04/2009</date>    
		public class ComparerOraValue : IComparer<OraValue>
		{
			#region Membres

			#endregion Membres

			#region Constantes

			#endregion Constantes

			#region Enums

			#endregion Enums

			#region Constructeur

			/// <summary>
			/// Cr�e une instance de ComparerOraValue
			/// </summary>
			public ComparerOraValue()
			{
			}

			#endregion Constructeur

			#region M�thodes

			/// <summary>
			/// Permet de comparer deux OraValue
			/// </summary>
			/// <param name="oraValue1">Oravalue � comparer</param>
			/// <param name="oraValue2">Oravalue � comparer</param>
			/// <returns>Le r�sultat de la comparaison des values contenues dans les deux OraValue pass�s en param�tre</returns>
			public int Compare(OraValue oraValue1, OraValue oraValue2)
			{
				
				//Valeur � comparer
				IComparable __i_comparable	= oraValue1.Value as IComparable;
				IComparable __e_comparable	= oraValue2.Value as IComparable;
	            			
				if(Validation.IsNotNull(__i_comparable))
				{
					if(Validation.IsNotNull(__e_comparable))
					{
						return __i_comparable.CompareTo(__e_comparable);
					}else
					{
						return 1;
					}
				}else
				{
					if(Validation.IsNull(__e_comparable))
					{
						return 0;
					}

					return -1;
				}
			}

			#endregion M�thodes

			#region Propri�t�s

			#endregion Propri�t�s
    }

		#endregion

		/// <summary>Creates a new Instance of <see cref="OraValue"/> with the specied <paramref name="value"/>. </summary>
		/// <param name="columnName">The string column name associated with the value. </param>
		/// <param name="value">the object value.</param>
		public OraValue(string columnName, object value)
		{
			_columnName = columnName;
			if(value is byte[])
			{
				byte[] __bytes = (byte[]) value;
				_value = new OracleDecimal(__bytes);
			}
			else
			{
				_value = value;
			}
		}

		#region IComparable 

		/// <summary>
		/// Permet de comparer un OraValue avec l'instance
		/// </summary>
		/// <param name="value">OraValue � comparer</param>
		/// <returns>Le r�sultat de la comparaison</returns>
		public int CompareTo(OraValue value)
        {
		    ComparerOraValue __comparerOraValue = new ComparerOraValue();
            return __comparerOraValue.Compare(this, value);
		}

		#endregion

		/// <summary>Retrieve the name of the column associated with the value. </summary>
		public	string						ColumnName
		{
			get{return _columnName;}
		}

		/// <summary>Checks if OraValue is null or DBNull. </summary>
		public	bool						IsNull
		{
            get
			{   
                return QXP_Value_Helper.IsNull(this._value);
            }
		}

		/// <summary>Gets the <see cref="string"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="String"/> value. </returns>
		public	override string				ToString()
		{
			return QXP_Value_Helper.ToString(this._value);

		}

		/// <summary>Gets the <see cref="bool"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Boolean"/> value. </returns>
		public	bool						ToBoolean()
		{
			return QXP_Value_Helper.ToBoolean(this._value);
		}

		/// <summary>Gets the <see cref="Byte"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Byte"/> value. </returns>
		public	Byte						ToByte()
		{
			return QXP_Value_Helper.ToByte(this._value);
		}

		/// <summary>Gets the <see cref="Int16"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Int16"/> value. </returns>
		public	Int16						ToInt16()
		{
			return QXP_Value_Helper.ToInt16(this._value);
		}

		/// <summary>Gets the <see cref="Int32"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Int32"/> value. </returns>
		public	Int32						ToInt32()
		{
			return QXP_Value_Helper.ToInt32(this._value);
		}

		/// <summary>Gets the <see cref="Int32"/> array representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Int32"/> array. </returns>
		public	Int32[]						ToInt32s()
		{
			return QXP_Value_Helper.ToInt32s(this._value);
		}

		/// <summary>Gets the <see cref="Decimal"/> array representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Decimal"/> array. </returns>
		public	Decimal[]					ToDecimals()
		{
			return QXP_Value_Helper.ToDecimals(this._value);
		}

		/// <summary>Gets the <see cref="Int64"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Int64"/> value. </returns>
		public	Int64						ToInt64()
		{
			return QXP_Value_Helper.ToInt64(this._value);
		}

		/// <summary>Gets the <see cref="Decimal"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Decimal"/> value. </returns>
		public	Decimal						ToDecimal()
		{
			return QXP_Value_Helper.ToDecimal(this._value);
		}

		/// <summary>Gets the <see cref="Single"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Single"/> value. </returns>
		public	Single						ToSingle()
		{
			return QXP_Value_Helper.ToSingle(this._value);
		}

		/// <summary>Gets the <see cref="Double"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Double"/> value. </returns>
		public	Double						ToDouble()
		{
			return QXP_Value_Helper.ToDouble(this._value);
		}

		/// <summary>Gets the <see cref="DateTime"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="DateTime"/> value. </returns>
		public	DateTime					ToDateTime()
		{
			return QXP_Value_Helper.ToDateTime(this._value);
		}

		/// <summary>Gets the <see cref="OracleDecimal"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="OracleDecimal"/> value. </returns>
		public	OracleDecimal				ToOracleDecimal()
		{
			return QXP_Value_Helper.ToOracleDecimal(this._value);
		}

		/// <summary>Gets the <see cref="byte"/> array representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="byte"/> array value. </returns>
		/// <exception cref="ArgumentException">if OraValue is not Blob compatible. </exception>
		public	byte[]						ToBytes()
		{
			return QXP_Value_Helper.ToBytes(this._value);
		}

		/// <summary>Gets the <see cref="Stream"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Stream"/> value. </returns>
		/// <exception cref="ArgumentException">if OraValue is not Blob or Clob compatible. </exception>
		public	Stream						ToStream()
		{
			return QXP_Value_Helper.ToStream(this._value);
		}

		/// <summary>Gets the <see cref="Char"/> array representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="Char"/> array value. </returns>
		/// <exception cref="ArgumentException">if OraValue is not Clob compatible. </exception>
		public	Char[]						ToChars()
		{
			return QXP_Value_Helper.ToChars(this._value);
		}
		/// <summary>Gets the <see cref="String"/> array representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="string"/> array value. </returns>
		/// <exception cref="ArgumentException">if OraValue is not string array compatible. </exception>
		public	string[]					ToStrings()
		{
			return QXP_Value_Helper.ToStrings(this._value);
		}

		/// <summary>Gets the <see cref="DateTime"/> array representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="DateTime"/> array value. </returns>
		/// <exception cref="ArgumentException">if OraValue is not DateTime array compatible. </exception>
		public	DateTime[]					ToDateTimes()
		{
			return QXP_Value_Helper.ToDateTimes(this._value);
		}

		/// <summary>Gets the <see cref="TimeSpan"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="TimeSpan"/> value. </returns>
		/// <exception cref="ArgumentException">if OraValue is not TimeSpan compatible. </exception>
		public	TimeSpan					ToTimeSpan()
		{
			return QXP_Value_Helper.ToTimeSpan(this._value);
		}

		/// <summary>Gets the <see cref="OraObject"/> representation of the <see cref="OraValue"/>. </summary>
		/// <returns>The <see cref="OraObject"/> value. </returns>
		public OraObject					ToOraObject()
		{
			return QXP_Value_Helper.ToOraObject(this._value);
		}

		/// <summary>
        /// Converti l'Oravalue en type T g�n�rique
        /// </summary>
        /// <typeparam name="T">Type voulu</typeparam>
        /// <returns>Un object de type T</returns>
        public object						ToObject<T>()
        {
            Type __type = typeof(T);
			if(__type == typeof(String))
                return (String)this;
            else if(__type == typeof(Boolean))
                return (Boolean)this;
            else if(__type == typeof(Byte))
                return (Byte)this;            
            else if(__type == typeof(Int16))
                return (Int16)this;
            else if(__type == typeof(Int32))
                return (Int32)this;
            else if(__type == typeof(Int64))
                return (Int64)this;
            else if(__type == typeof(Decimal))
                return (Decimal)this;
            else if(__type == typeof(Single))
                return (Single)this;
            else if(__type == typeof(Double))
                return (Double)this;
            else if(__type == typeof(DateTime))
                return (DateTime)this;
            else if(__type == typeof(OracleDecimal))
                return (OracleDecimal)this;
            else if(__type == typeof(byte[]))
                return (byte[])this;
            else if(__type == typeof(Stream))
                return (Stream)this;
            else if(__type == typeof(char[]))
                return (char[])this;
            else if(__type == typeof(string[]))
                return (string[])this;
            else if(__type == typeof(TimeSpan))
                return (TimeSpan)this;
            else 
                return this;            
        }

		public	object						Value{
			get{return _value;}
		}

		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="String"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="String"/> value. </returns>
		public	static implicit	operator	String(OraValue value)
		{
            return value.ToString();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Boolean"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Boolean"/> value. </returns>
		public	static implicit	operator	Boolean(OraValue value)
		{
            return value.ToBoolean();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Byte"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Byte"/> value. </returns>
		public	static implicit	operator	Byte(OraValue value)
		{
            return value.ToByte();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Int16"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Int16"/> value. </returns>
		public	static implicit	operator	Int16(OraValue value)
		{
            return value.ToInt16();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Int32"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Int32"/> value. </returns>
		public	static implicit	operator	Int32(OraValue value)
		{
             return value.ToInt32();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Int64"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Int64"/> value. </returns>
		public	static implicit	operator	Int64(OraValue value)
		{
             return value.ToInt64();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Decimal"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Decimal"/> value. </returns>
		public	static implicit	operator	Decimal(OraValue value)
		{
            return value.ToDecimal();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Single"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Single"/> value. </returns>
		public	static implicit	operator	Single(OraValue value)
		{
            return value.ToSingle();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Single"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Single"/> value. </returns>
		public	static implicit	operator	Double(OraValue value)
		{
			return value.ToDouble();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="DateTime"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="DateTime"/> value. </returns>
		public	static implicit	operator	DateTime(OraValue value)
		{
			return value.ToDateTime();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="OracleDecimal"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="OracleDecimal"/> value. </returns>
		public	static implicit	operator	OracleDecimal(OraValue value)
		{
			return value.ToOracleDecimal();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="byte"/> array casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="byte"/> array value. </returns>
		public	static implicit	operator	byte[](OraValue value)
		{
			return value.ToBytes();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Stream"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Stream"/> value. </returns>
		public	static implicit	operator	Stream(OraValue value)
		{
			return value.ToStream();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Char"/> array casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Char"/> array value. </returns>
		public	static implicit	operator	char[](OraValue value)
		{
			return value.ToChars();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="string"/> array casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="string"/> array value. </returns>
		public	static implicit	operator	string[](OraValue value)
		{
			return value.ToStrings();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="DateTime"/> array casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="DateTime"/> array value. </returns>
		public	static implicit	operator	DateTime[](OraValue value)
		{
			return value.ToDateTimes();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Int"/> array casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Int"/> array value. </returns>
		public	static implicit	operator	Int32[](OraValue value)
		{
			return value.ToInt32s();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="Decimal"/> array casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="Decimal"/> array value. </returns>
		public	static implicit	operator	Decimal[](OraValue value)
		{
			return value.ToDecimals();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="TimeSpan"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="TimeSpan"/> array value. </returns>
		public	static implicit	operator	TimeSpan(OraValue value)
		{
			return value.ToTimeSpan();
		}
		
		/// <summary>Allows implicit <see cref="OraValue"/> to <see cref="OraObject"/> casting. </summary>
		/// <param name="value">The <see cref="OraValue"/> to cast. </param>
		/// <returns>The <see cref="OraObject"/> value. </returns>
		public	static implicit	operator	OraObject(OraValue value)
		{
			return value.ToOraObject();
		}
	}

}