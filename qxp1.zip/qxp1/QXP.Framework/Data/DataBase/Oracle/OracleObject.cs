using System;
using System.Collections.Generic;
using Oracle.DataAccess.Types;
using Oracle.DataAccess.Client;
using System.Text;

using QXPFrk = QXP.Framework;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Data.Oracle
{
	/// <summary>
	/// Il s'agit d'une classe qui correspond � un type oracle qui peut contenir plusieurs types de valeur (string/decimal/int/datetime).
	/// </summary>
	/// <remarks>
	/// Cette classe est associ�e � un type oracle qui peut �tre r�cup�r�e dans un reader (au travers de OraValue).
	/// Pour l'instant il n'est pas pr�vu de pouvoir passer cette valeur comme param�tre.
	/// les performances sembles bonnes (test� avec 10 000 OraObject).
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>22/12/2010 17:12:27</date>    
	public class OraObject: INullable, IOracleCustomType
	{
	    #region Membres
	    private bool						_isNull;
		
		//Le faite de travailler sur des OracleDecimal etc... permet de conserver la pr�cision maximum jusqu'au bout
		private OracleString				_ora_String		= OracleString.Null;
		private OracleDecimal				_ora_Decimal	= OracleDecimal.Null;
		private OracleDate					_ora_DateTime	= OracleDate.Null;
		private Enums.OraObjectValType		_type			= Enums.OraObjectValType.Val_String;
	    #endregion Membres

	    #region Constantes

	    #endregion Constantes

	    #region Enums

	    #endregion Enums

	    #region Constructeur

	    /// <summary>
	    /// Cr�e une instance de OracleObject
	    /// </summary>
	    public OraObject()
	    {
	    }

	    #endregion Constructeur

	    #region M�thodes
		
	    #region Impl�mentation de IOracleCustomType

	    /// <summary>
	    /// Permet de d�finir les param�tre de valeur de la connection en fonction des propri�t�s de la classe OraObjet
	    /// </summary>
	    /// <param name="con">Connectin Oracle</param>
	    /// <param name="pUdt">pointeur ??</param>
	    public void FromCustomObject(OracleConnection con, IntPtr pUdt)
	    {
			OracleUdt.SetValue(con, pUdt, "VAL_TYPE", (int)_type);

			switch (_type)
			{
				case Enums.OraObjectValType.Val_Int:
				case Enums.OraObjectValType.Val_Decimal:
				case Enums.OraObjectValType.Val_Currency:
				case Enums.OraObjectValType.Val_Pourcentage:
					if(QXPFrk.Validation.IsSet(_ora_Decimal))	OracleUdt.SetValue(con, pUdt, "ORA_DECIMAL", _ora_Decimal);
					break;
				case Enums.OraObjectValType.Val_Date:
				case Enums.OraObjectValType.Val_DateTime:
					if(QXPFrk.Validation.IsSet(_ora_DateTime))	OracleUdt.SetValue(con, pUdt, "ORA_DATETIME", _ora_DateTime);
					break;
				default: // Enums.OraObjectValType.Val_String
					if(QXPFrk.Validation.IsSet(_ora_String))	OracleUdt.SetValue(con, pUdt, "ORA_STRING", _ora_String);
					break;
			}
	    }
		
	    /// <summary>
	    /// Permet de d�finir la valeur des propri�t�s de la classe OraObjet en fonction des param�tres de valeur de la connection.
	    /// </summary>
	    /// <param name="con">Connectin Oracle</param>
	    /// <param name="pUdt">pointeur ??</param>
	    public void ToCustomObject(OracleConnection con, IntPtr pUdt)
	    {
			int __val_Type		= QXP_Value_Helper.ToInt32(OracleUdt.GetValue(con, pUdt, "VAL_TYPE"));
	        _type	= QXPFrk.Conversion.ToEnum<Enums.OraObjectValType>(__val_Type);
			
			switch(_type)
			{
				case Enums.OraObjectValType.Val_Int:
				case Enums.OraObjectValType.Val_Decimal:
				case Enums.OraObjectValType.Val_Currency:
				case Enums.OraObjectValType.Val_Pourcentage:
					_ora_Decimal	= (OracleDecimal)OracleUdt.GetValue(con, pUdt, "ORA_DECIMAL");
					break;
				case Enums.OraObjectValType.Val_Date:
				case Enums.OraObjectValType.Val_DateTime:
					_ora_DateTime	= (OracleDate)OracleUdt.GetValue(con, pUdt, "ORA_DATETIME");
					break;
				default: //Par defaut c'est du string, Enums.OraObjectValType.Val_String:
					_ora_String		= (OracleString)OracleUdt.GetValue(con, pUdt, "ORA_STRING");
					break;
			}
	    }
	    
		#endregion Impl�mentation de IOracleCustomType

	    #endregion M�thodes

	    #region Propri�t�s
	    /// <summary>
	    /// l'objet OraObject est-il null pour Oracle
	    /// </summary>
		/// <remarks>
		/// Le code peut paraitre �trange puisque isNull n'est pas d�fini, Cependant 
		/// je ne sais pas comment exactement comment mais si la valeur retourn�e dans oracle est null pour la colonne alors on re�oit l'objet OraObject.Null avec la propri�t� IsNull � true !!
		/// </remarks>
	    public bool						IsNull
	    {
	        get{return _isNull;}
	    }

	    /// <summary>
	    /// OraObject.Null is used to return a NULL OraObject object
	    /// </summary>
	    public static OraObject			Null
	    {
	        get
	        {
	          OraObject __o = new OraObject();
	          __o._isNull = true;
	          return __o;
	        }
		}

		#region Mappings Types

		[OracleObjectMappingAttribute("VAL_TYPE")]
	    /// <summary>
	    /// type de valeur contenue
	    /// </summary>
	    public int						Val_Type
	    {
	        get{return (int)_type;}
			set{_type = QXPFrk.Conversion.ToEnum<Enums.OraObjectValType>(value);}
	    }

		[OracleObjectMappingAttribute("ORA_STRING")]
		/// <summary>
	    /// Une valeur Oracle String
	    /// </summary>
	    public OracleString				Ora_String
	    {
	        get{return _ora_String;}
	        set{
				_ora_String		= value;
				_type			= Enums.OraObjectValType.Val_String;
			}
	    }

		[OracleObjectMappingAttribute("ORA_DECIMAL")]
	    /// <summary>
	    /// Une valeur Oracle Decimal
	    /// </summary>
	    public OracleDecimal			Ora_Decimal
	    {
	        get{return _ora_Decimal;}
	        set{
				_ora_Decimal	= value;
				_type			= Enums.OraObjectValType.Val_Decimal;
			}
	    }

		[OracleObjectMappingAttribute("ORA_DATETIME")]
	    /// <summary>
	    /// Une valeur Oracle Date
	    /// </summary>
	    public OracleDate				Ora_DateTime
	    {
	        get{return _ora_DateTime;}
	        set{
				_ora_DateTime	= value;
				_type			= Enums.OraObjectValType.Val_DateTime;
			}
	    }

		#endregion 	Mappings Types

		/// <summary>
		/// Permet de connaitre le type de donn�e contenu dans l'OraObject
		/// </summary>
		public Enums.OraObjectValType	Type
		{
			get
			{
				return _type;
			}
		}

		/// <summary>
		/// Une chaine de caract�re
		/// </summary>
		public string					String
		{
			get
			{
				return QXP_Value_Helper.ToString(_ora_String);
			}
		}

		/// <summary>
		/// Une valeur d�cimale
		/// </summary>
		public Decimal					Decimal
		{
			get
			{
				return QXP_Value_Helper.ToDecimal(_ora_Decimal);
			}
		}

		/// <summary>
		/// Une valeur enti�re
		/// </summary>
		public Int32					Int
		{
			get
			{
				return QXP_Value_Helper.ToInt32(_ora_Decimal);
			}
		}

		/// <summary>
		/// Une date
		/// </summary>
		public DateTime					DateTime
		{
			get
			{
				return QXP_Value_Helper.ToDateTime(_ora_DateTime);
			}
		}

	    #endregion Propri�t�s
	}
}
