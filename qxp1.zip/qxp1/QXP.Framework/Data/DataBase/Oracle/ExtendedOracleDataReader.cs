using System;
using System.Collections;
using System.Data;
using System.IO;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace QXP.Framework.Data.Oracle
{
    #region Delegates 

    public delegate OraValue    OraValueByIndexHandler(int index);

    public delegate OraValue    OraValueByNameHandler(string columnName);

    public delegate bool        HasRowsHandler();

    public delegate bool        ReadDataHandler();

    public delegate void        CloseDataHandler();

    #endregion Delegates

    /// <summary>
	/// Permet d'utiliser de mani�re simple un DataReader ou un DataSet de mani�re transparante.
	/// </summary>
	public sealed class ExtendedOraDataReader: IEnumerable
	{
		#region Membres
		
        /// <summary>
        /// DataReader
        /// </summary>
        private OracleDataReader            _dataReader;

        /// <summary>
        /// DataSet
        /// </summary>
        private OraDataSet                  _dataSet;
	
        /// <summary>
        /// 
        /// </summary>
        private DataTableReader             _dataSetReader;

        /// <summary>
        /// 
        /// </summary>
        private OraValueByIndexHandler      _oraValueByIndex;        

        /// <summary>
        /// 
        /// </summary>
        private OraValueByNameHandler       _oraValueByName;

        /// <summary>
        /// 
        /// </summary>
        private HasRowsHandler              _hasRowsHandler;

        /// <summary>
        /// 
        /// </summary>
        private ReadDataHandler             _readDataHandler;

        /// <summary>
        /// 
        /// </summary>
        private CloseDataHandler            _closeDataHandler;

		#endregion Membres

        #region Properties

        /// <summary>
        /// Determine si la source de donn�es poss�de des lignes
        /// </summary>
        public bool HasRows
        {
            get { return this._hasRowsHandler(); }
        }

        /// <summary>
        /// Permet d'acceder � la source de donn�es par un nom de colonne
        /// </summary>
        /// <param name="ColumnName"></param>
        /// <returns></returns>
        public OraValue this[string ColumnName]
        {
            get { return _oraValueByName(ColumnName); }
        }

        /// <summary>
        /// Permet d'acceder � la source de donn�es par un index
        /// </summary>
        /// <param name="ColumnIndex"></param>
        /// <returns></returns>
        public OraValue this[int ColumnIndex]
        {
            get { return _oraValueByIndex(ColumnIndex); }
        }
        
        #endregion Properties

        #region Constructeurs

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reader"></param>
        public ExtendedOraDataReader(OracleDataReader reader)
		{
			this._dataReader        = reader;
            this._oraValueByIndex   += new OraValueByIndexHandler(this.GetDataReaderValueByIndex);
            this._oraValueByName    += new OraValueByNameHandler(this.GetDataReaderValueByName);
            this._hasRowsHandler    += new HasRowsHandler(this.HasRowsDataReader);
            this._readDataHandler   += new ReadDataHandler(this.ReadDataReader);
            this._closeDataHandler  += new CloseDataHandler(this.CloseDataReader);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataSet"></param>
        public ExtendedOraDataReader(OraDataSet dataSet)
        {
            this._dataSet           = dataSet;
            this._dataSetReader     = dataSet.Tables[0].CreateDataReader();
            this._oraValueByIndex   += new OraValueByIndexHandler(this.GetDataSetValueByIndex);
            this._oraValueByName    += new OraValueByNameHandler(this.GetDataSetValueByName);
            this._hasRowsHandler    += new HasRowsHandler(this.HasRowsDataSet);
            this._readDataHandler   += new ReadDataHandler(this.ReadDataSet);
            this._closeDataHandler  += new CloseDataHandler(this.CloseDataSet);
        }

        #endregion Constructeurs

        #region M�thodes

        /// <summary>
        /// Parcours la source de donn�es
        /// </summary>
        /// <returns></returns>
        public bool     Read()
        {
            return this._readDataHandler();
        }

        /// <summary>
        /// Ferme la source de donn�es
        /// </summary>
        /// <returns></returns>
        public void     Close()
        {
            this._closeDataHandler();
        }
		
		/// <summary>
		/// M�thode propre au DataSet, permet d'actualiser le _dataSetReader
		/// </summary>
		public void UpdateDataSetReader()
		{
			this.UpdateDataSetReader(0);
		}

		/// <summary>
		/// M�thode propre au DataSet, permet d'actualiser le _dataSetReader
		/// </summary>
		public void UpdateDataSetReader(int i)
		{
			if(Validation.IsNull(_dataSet))
				return;
			this._dataSetReader     = _dataSet.Tables[i].CreateDataReader();

		}

        #endregion M�thodes

        #region Evenements

        /// <summary>
        /// Retourne l'oraValue d'un DataReader gr�ce � un index
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        private OraValue GetDataReaderValueByIndex(int index)
        {
            if (this._dataReader.IsDBNull(index)) return new OraValue(null, null);
            return new OraValue(this._dataReader.GetName(index), this._dataReader.GetOracleValue(index));
        }

        /// <summary>
        /// Retourne l'oraValue d'un DataReader gr�ce � un nom de colonne
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private OraValue GetDataReaderValueByName(string columnName)
        {
            if (Validation.IsNull(this._dataReader)) return new OraValue("NoDatabase", "NoDatabase");
            int __index = -1;
            try
            {
                __index = this._dataReader.GetOrdinal(columnName);
            }
            catch (Exception ex)
            {
                throw new OraDataReaderException("Column:" + columnName, ex);
            }
            return this.GetDataReaderValueByIndex(__index);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        private OraValue GetDataSetValueByIndex(int index)
        {
            if (this._dataSetReader.IsDBNull(index)) return new OraValue(null, null);
            return new OraValue(this._dataSetReader.GetName(index), this._dataSetReader.GetValue(index));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private OraValue GetDataSetValueByName(string name)
        {
            if (Validation.IsNull(this._dataSetReader)) return new OraValue("NoDatabase", "NoDatabase");
            int __index = -1;
            try
            {
                __index = this._dataSetReader.GetOrdinal(name);
            }
            catch (Exception ex)
            {
                throw new OraDataReaderException("Column:" + name, ex);
            }
            return this.GetDataSetValueByIndex(__index);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool HasRowsDataReader()
        {
            if (Validation.IsNull(this._dataReader)) return false;
            return this._dataReader.HasRows;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool HasRowsDataSet()
        {
            if (Validation.IsNull(this._dataSet)) return false;
            return this._dataSet.Tables[0].Rows.Count > 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool ReadDataReader()
        {
            if (Validation.IsNull(this._dataReader)) return false;
            return this._dataReader.Read();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool ReadDataSet()
        {
            if (Validation.IsNull(this._dataSet)) return false;
            return this._dataSetReader.Read();
        }

        /// <summary>
        /// Close the current OraDataReader.
        /// </summary>
        private void CloseDataReader()
        {
            if (Validation.IsNotNull(this._dataReader))
            {
                if (!this._dataReader.IsClosed)
                {
                    this._dataReader.Close();
                }
            }
        }

        /// <summary>
        /// Ferme le DataSet courant
        /// </summary>
        private void CloseDataSet()
        {
            if (Validation.IsNotNull(this._dataSet))
            {
                this._dataSet.Dispose();
            }
        }

        #endregion Evenements

		#region Propri�t�s

		public OracleDataReader DataReader
		{
			get { return _dataReader; }
			set { _dataReader = value; }
		}
		public OraDataSet DataSet
		{
			get { return _dataSet;  }
			set { _dataSet = value; }
		}

		#endregion Propri�t�s

		/// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerator GetEnumerator()
        {
            return null;
        }
	}
}