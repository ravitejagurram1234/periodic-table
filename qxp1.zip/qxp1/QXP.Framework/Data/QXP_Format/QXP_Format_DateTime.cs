using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Data.Format
{
    /// <summary>
    /// QXP_Format : caract�rise un format QXP
    /// </summary>
    /// <author>cueffl</author>
    /// <date>13/05/2009 11:49:57</date>    
    public abstract partial class QXP_Format
    {
        /// <summary>
        /// QXP_Format_DateTime : caract�rise un format de date QXP
        /// </summary>
        /// <author>cueffl</author>
        /// <date>14/05/2009 10:53:06</date>    
        public class QXP_Format_DateTime : QXP_Format
        {
            #region Membres

            #endregion Membres

            #region Constantes

            #endregion Constantes

            #region Enums

            #endregion Enums

            #region Constructeur

            /// <summary>
            /// Cr�e une instance de QXP_Format_DateTime
            /// </summary>
            /// <param name="custom_Format_String">Custom Format String : correspond au param dans le string.format(...{0:param}) de .Net</param>
            public QXP_Format_DateTime(string custom_Format_String) : base(custom_Format_String)
            {                
            }

            /// <summary>
            /// Cr�e une instance de QXP_Format_DateTime
            /// </summary>
            /// <param name="is_DateTime">Le format de date est une date + heure ou non</param>
            public QXP_Format_DateTime(bool is_DateTime) : base()
            {
                base._is_DateTime = is_DateTime;
            }

            #endregion Constructeur

            #region M�thodes

            #endregion M�thodes

            #region Propri�t�s

            /// <summary>
            /// Le format de date est une date + heure
            /// </summary>
            public bool Is_DateTime
            {
                get { return _is_DateTime; }
                set { _is_DateTime = value; }
            }

            #endregion Propri�t�s
        }
    }
}
