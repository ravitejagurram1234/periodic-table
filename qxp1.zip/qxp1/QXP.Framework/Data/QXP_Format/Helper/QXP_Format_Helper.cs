using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Globalization;

namespace QXP.Framework.Data.Format
{
    /// <summary>
    /// Helper QXP_Format_Helper
    /// </summary>
    /// <author>cueffl</author>
    /// <date>13/05/2009 15:08:49</date>    
    public class QXP_Format_Helper
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Constructeur static QXP_Format_Helper
        /// </summary>
        static QXP_Format_Helper()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Retourne la valeur en string de la value contenue dans l'QXP_Value en fonction du type T
        /// Utilise l'QXP_Format contenu dans l'QXP_Value
        /// </summary>
        /// <typeparam name="T">Type de la value contenue dans l'QXP_Value</typeparam>
        /// <param name="qxp_value">QXP_Value</param>
        /// <returns>Un string de l'qxp_value</returns>
        internal static string Get_Formatted_String_Value<T>(QXP_Value<T> qxp_value)
            where T : IComparable<T>, IEquatable<T>
        {            
            //Si un format custom est pr�sent, on l'utilise comme chaine de formattage
            if (Validation.IsSet(qxp_value.Format.Custom_Format_String))
            {
                return string.Format(qxp_value.Format.GetCustomFormatString(), qxp_value.Value);
            }
            else
            {       
                //Sinon on charge dynamiquement la bonne m�thode � executer en fonction du type de T
                //via la reflexion

                Type __valueType = typeof(T);

    			Type __QXPFormatType	= typeof(QXP_Format);
    			
			    MethodInfo __method = typeof (QXP_Format_Helper).GetMethod("Get_Formatted_String_Value"
																	    , BindingFlags.Static | BindingFlags.NonPublic
																	    , null
																	    , new Type[]{__valueType, __QXPFormatType}
																	    , null);
                return (string) __method.Invoke(null, new object[] { qxp_value.Value, qxp_value.Format });
            }
        }

        /// <summary>
        /// Retourne la valeur en string de la value contenue � partir des informations contenues dans
        /// l'QXP_Format
        /// </summary>
        /// <param name="value">Valeur � formatter</param>
        /// <param name="format">QXP_Format</param>
        /// <returns>Valeur formatt�e en string</returns>
        static string Get_Formatted_String_Value(string value, QXP_Format format) 
        { 
            return value;
        }

        /// <summary>
        /// Retourne la valeur en string de la value contenue � partir des informations contenues dans
        /// l'QXP_Format
        /// </summary>
        /// <param name="value">Valeur � formatter</param>
        /// <param name="format">QXP_Format</param>
        /// <returns>Valeur formatt�e en string</returns>
        static string Get_Formatted_String_Value(int value, QXP_Format format)
        {
            return Get_Formatted_String_Value((decimal)value, format);
        }

        /// <summary>
        /// Retourne la valeur en string de la value contenue � partir des informations contenues dans
        /// l'QXP_Format
        /// </summary>
        /// <param name="value">Valeur � formatter</param>
        /// <param name="format">QXP_Format</param>
        /// <returns>Valeur formatt�e en string</returns>
        static string Get_Formatted_String_Value(Int16 value, QXP_Format format)
        {
            return Get_Formatted_String_Value((decimal)value, format);
        }

        /// <summary>
        /// Retourne la valeur en string de la value contenue � partir des informations contenues dans
        /// l'QXP_Format
        /// </summary>
        /// <param name="value">Valeur � formatter</param>
        /// <param name="format">QXP_Format</param>
        /// <returns>Valeur formatt�e en string</returns>
        static string Get_Formatted_String_Value(Int64 value, QXP_Format format)
        {
            return Get_Formatted_String_Value((decimal)value, format);
        }

        /// <summary>
        /// Retourne la valeur en string de la value contenue � partir des informations contenues dans
        /// l'QXP_Format
        /// </summary>
        /// <param name="value">Valeur � formatter</param>
        /// <param name="format">QXP_Format</param>
        /// <returns>Valeur formatt�e en string</returns>
        static string Get_Formatted_String_Value(double value, QXP_Format format)
        {
            return Get_Formatted_String_Value((decimal)value, format);
        }

        /// <summary>
        /// Retourne la valeur en string de la value contenue � partir des informations contenues dans
        /// l'QXP_Format
        /// </summary>
        /// <param name="value">Valeur � formatter</param>
        /// <param name="format">QXP_Format</param>
        /// <returns>Valeur formatt�e en string</returns>
        static string Get_Formatted_String_Value(decimal value, QXP_Format format) 
        { 
            NumberFormatInfo __number_Info = NumberFormatInfo.CurrentInfo.Clone() as NumberFormatInfo;

            //En fonction des informations contenues dans le format on d�finit ou non les membres du number_Info
            if(format.Number_Nb_Decimal.HasValue)
                __number_Info.NumberDecimalDigits       = format.Number_Nb_Decimal.Value;

            if(format.Number_Format_Negatif.HasValue)
                __number_Info.NumberNegativePattern     = format.Number_Format_Negatif.Value;

            if(Validation.IsSet(format.Number_Decimal_Separator))
                __number_Info.NumberDecimalSeparator    = format.Number_Decimal_Separator;

            if(Validation.IsSet(format.Number_Millier_Separator))
                __number_Info.NumberGroupSeparator   = format.Number_Millier_Separator;

            string __value_Formatted = value.ToString("N" , __number_Info);

            /* Le choix de ne pas utiliser les CurrencyDecimalSeparator ... et PercentDecimalDigits ..
             * est volontaire, le but �tant d'utiliser le m�me affichage en fonction du format des nombres n�gatifs
             * car .Net g�re de facon diff�rente l'affichage des pourcentages et devises des nombres n�gatifs.
             * cf Aide  :  NumberFormatInfo.CurrencyNegativePattern et NumberFormatInfo.PercentNegativePattern
             */
            
            if (format.Is_Percent)
            {
                return string.Concat(__value_Formatted, " ", __number_Info.PercentSymbol);
            }
            else if (format.Is_Currency)
            {                
                if(Validation.IsSet(format.Symbol_Currency))
                    __number_Info.CurrencySymbol = format.Symbol_Currency;

                return string.Concat(__value_Formatted, " ", __number_Info.CurrencySymbol);
            }
            else
            {                                
                return __value_Formatted;
            }
        }

        /// <summary>
        /// Retourne la valeur en string de la value contenue � partir des informations contenues dans
        /// l'QXP_Format
        /// </summary>
        /// <param name="value">Valeur � formatter</param>
        /// <param name="format">QXP_Format</param>
        /// <returns>Valeur formatt�e en string</returns>
        static string Get_Formatted_String_Value(DateTime value, QXP_Format format) 
        {
            if (Validation.IsSet(value))
            {
                if (format.Is_DateTime)
                {
                    //ex : dd/mm/yyyy hh:mm:ss"
                    return value.ToString("G");
                }
                else
                {
                    return value.ToShortDateString();
                }
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Retourne la valeur en string de la value contenue � partir des informations contenues dans
        /// l'QXP_Format
        /// </summary>
        /// <param name="value">Valeur � formatter</param>
        /// <param name="format">QXP_Format</param>
        /// <returns>Valeur formatt�e en string</returns>
        static string Get_Formatted_String_Value(object value, QXP_Format format) 
        { 
            //On ne doit jamais passer ici normalement...
            return value.ToString();
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
