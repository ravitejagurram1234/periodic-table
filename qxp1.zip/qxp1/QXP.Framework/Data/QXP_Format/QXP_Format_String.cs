using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Data.Format
{
    /// <summary>
    /// QXP_Format : caract�rise un format QXP
    /// </summary>
    /// <author>cueffl</author>
    /// <date>13/05/2009 11:49:57</date>    
    public abstract partial class QXP_Format
    {
        /// <summary>
        /// QXP_Format_String : caract�rise un format string QXP
        /// </summary>
        /// <author>cueffl</author>
        /// <date>14/05/2009 10:53:14</date>    
        public class QXP_Format_String : QXP_Format
        {
            #region Membres

            #endregion Membres

            #region Constantes

            #endregion Constantes

            #region Enums

            #endregion Enums

            #region Constructeur

            /// <summary>
            /// Cr�e une instance de QXP_Format_String
            /// </summary>
            public QXP_Format_String() : base()
            {
            }

            /// <summary>
            /// Cr�e une instance de QXP_Format_String
            /// </summary>
            /// <param name="custom_Format_String">Custom Format String : correspond au param dans le string.format(...{0:param}) de .Net</param>
            public QXP_Format_String(string custom_Format_String) : base(custom_Format_String)
            {
            }

            #endregion Constructeur

            #region M�thodes

            #endregion M�thodes

            #region Propri�t�s

            #endregion Propri�t�s
        }
    }
}
