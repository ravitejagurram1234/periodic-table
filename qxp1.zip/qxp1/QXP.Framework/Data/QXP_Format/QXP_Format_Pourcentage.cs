using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Data.Format
{
    /// <summary>
    /// QXP_Format : caract�rise un format QXP
    /// </summary>
    /// <author>cueffl</author>
    /// <date>13/05/2009 11:49:57</date>    
    public abstract partial class QXP_Format
    {
        /// <summary>
        /// QXP_Format_Pourcentage : caract�rise un format de pourcentage QXP
        /// </summary>
        /// <author>cueffl</author>
        /// <date>14/05/2009 10:52:51</date>    
        public class QXP_Format_Pourcentage : QXP_Format_Number
        {
            #region Membres

            #endregion Membres

            #region Constantes

            #endregion Constantes

            #region Enums

            #endregion Enums

            #region Constructeur

            /// <summary>
            /// Cr�e une instance de QXP_Format_Pourcentage
            /// </summary>
            public QXP_Format_Pourcentage() : base()
            {
                base._is_Percent = true;
            }

            /// <summary>
            /// Cr�e une instance de QXP_Format_Pourcentage
            /// </summary>
            /// <param name="nb_Decimal">Nombre de d�cimal</param>
            /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
            /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
            /// <param name="number_Millier_Separator">S�parateur des milliers</param>
            public QXP_Format_Pourcentage(int? nb_Decimal, int? format_Nombre_Negatif, string number_Decimal_Separator, string number_Millier_Separator) : base(nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator)
            {
                base._is_Percent = true;
            }

            #endregion Constructeur

            #region M�thodes

            #endregion M�thodes

            #region Propri�t�s

            #endregion Propri�t�s
        }
    }
}
