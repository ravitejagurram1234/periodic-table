using System;
using System.Collections.Generic;
using System.Text;


namespace QXP.Framework.Data.Format
{
    /// <summary>
    /// QXP_Format : caract�rise un format QXP
    /// </summary>
    /// <author>cueffl</author>
    /// <date>13/05/2009 11:49:57</date>    
    public abstract partial class QXP_Format
    {
        /// <summary>
        /// QXP_Format_Number : caract�rise un format de nombre QXP
        /// </summary>
        /// <author>cueffl</author>
        /// <date>14/05/2009 10:52:26</date>    
        public class QXP_Format_Number : QXP_Format
        {
            #region Membres

            #endregion Membres

            #region Constantes

            #endregion Constantes

            #region Enums

            #endregion Enums

            #region Constructeur

            /// <summary>
            /// Cr�e une instance de QXP_Format_Number
            /// </summary>
            public QXP_Format_Number() : base()
            {
            }

            /// <summary>
            /// Cr�e une instance de QXP_Format_Number
            /// </summary>
            /// <param name="custom_Format_String">Custom Format String : correspond au param dans le string.format(...{0:param}) de .Net</param>
            public QXP_Format_Number(string custom_Format_String) : base(custom_Format_String)
            {
            }
            
            /// <summary>
            /// Cr�e une instance de QXP_Format_Number
            /// </summary>
            /// <param name="nb_Decimal">Nombre de d�cimal</param>
            /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
            /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
            /// <param name="number_Millier_Separator">S�parateur des milliers</param>
            public QXP_Format_Number(int? nb_Decimal, int? format_Nombre_Negatif, string number_Decimal_Separator, string number_Millier_Separator) : base(nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator)
            {
            }

            #endregion Constructeur

            #region M�thodes

            #endregion M�thodes

            #region Propri�t�s

            /// <summary>
            /// Nombre de d�cimal
            /// </summary>
            public int? Number_Nb_Decimal
            {
              get { return _nb_Decimal; }
              set { _nb_Decimal = value; }
            }

            /// <summary>
            /// Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)
            /// </summary>
            public int? Number_Format_Negatif
            {
                get { return _format_Nombre_Negatif; }
                set { _format_Nombre_Negatif = value; }
            }

            /// <summary>
            /// S�parateur des nombres d�cimaux
            /// </summary>
            public string Number_Decimal_Separator
            {
                get { return _number_Decimal_Separator; }
                set { _number_Decimal_Separator = value; }
            }

            /// <summary>
            /// S�parateur des milliers
            /// </summary>
            public string Number_Millier_Separator
            {
                get { return _number_Millier_Separator; }
                set { _number_Millier_Separator = value; }
            }

            #endregion Propri�t�s
        }
    }
}
