using System;
using System.Collections.Generic;
using System.Text;


namespace QXP.Framework.Data.Format
{
    /// <summary>
    /// QXP_Format : caract�rise un format QXP
    /// </summary>
    /// <author>cueffl</author>
    /// <date>13/05/2009 11:49:57</date>    
    public abstract partial class QXP_Format
    {
        #region Membres

        protected bool    _is_Percent                 = false;
        protected bool    _is_Currency                = false;
        protected bool    _is_DateTime                = false;

        protected int?    _nb_Decimal                 = null;
        protected int?    _format_Nombre_Negatif      = null;
        protected string  _number_Decimal_Separator   = null;        
        protected string  _number_Millier_Separator   = null;
        protected string  _custom_Format_String       = null;
        protected string  _symbol_Currency            = null;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de QXP_Format
        /// </summary>
        public QXP_Format()
        {
        }

        /// <summary>
        /// Cr�e une instance de QXP_Format
        /// </summary>
        /// <param name="custom_Format_String">Custom Format String : correspond au param dans le string.format(...{0:param}) de .Net</param>
        public QXP_Format(string custom_Format_String) : this()
        {
            this._custom_Format_String = custom_Format_String;
        }

        /// <summary>
        /// Cr�e une instance de QXP_Format
        /// </summary>
        /// <param name="nb_Decimal">Nombre de d�cimal</param>
        /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
        /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
        /// <param name="number_Millier_Separator">S�parateur des milliers</param>
        public QXP_Format(int? nb_Decimal, int? format_Nombre_Negatif, string number_Decimal_Separator, string number_Millier_Separator) : this()
        {
            this._nb_Decimal                = nb_Decimal;
            this._format_Nombre_Negatif     = format_Nombre_Negatif;
            this._number_Decimal_Separator  = number_Decimal_Separator;
            this._number_Millier_Separator  = number_Millier_Separator;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Retourne le format utilisable par un string.Format en fonction du Custom_Format_String d�fini
        /// </summary>
        /// <returns>Le format utilisable par un string.Format()</returns>
        public string	GetCustomFormatString()
        {
            if (Validation.IsSet(this._custom_Format_String))
            {
                return string.Format("{0:{0}}", this._custom_Format_String);
            }
            else
                return string.Empty;
        }

		/// <summary>
		/// Permet de modifier le nombre de d�cimales d'un format existant
		/// </summary>
		/// <param name="nbDecimal"></param>
		public void		ChangeNbDecimal(int nbDecimal)
		{
			_nb_Decimal = nbDecimal;
		}
        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Le format est un format de pourcentage
        /// </summary>
        public bool Is_Percent
        {
          get { return _is_Percent; }
        }

        /// <summary>
        /// Le format est un format de devise
        /// </summary>
        public bool Is_Currency
        {
          get { return _is_Currency; }
        }        

        /// <summary>
        /// Symbole de la devise
        /// </summary>
        public string Symbol_Currency
        {
            get { return  _symbol_Currency; }
        }

        /// <summary>
        /// Le format de date est une date + heure
        /// </summary>
        public bool Is_DateTime
        {
            get { return _is_DateTime; }
        }

        /// <summary>
        /// Nombre de d�cimal
        /// </summary>
        public int? Number_Nb_Decimal
        {
          get { return _nb_Decimal; }
        }

        /// <summary>
        /// Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)
        /// </summary>
        public int? Number_Format_Negatif
        {
            get { return _format_Nombre_Negatif; }
        }

        /// <summary>
        /// S�parateur des nombres d�cimaux
        /// </summary>
        public string Number_Decimal_Separator
        {
            get { return _number_Decimal_Separator; }
        }

        /// <summary>
        /// S�parateur des milliers
        /// </summary>
        public string Number_Millier_Separator
        {
            get { return _number_Millier_Separator; }
        }     

        /// <summary>
        /// Format personnalis� (correspond � la valeur de "param" dans le {0:param} d'un string.Format())
        /// </summary>
        public string Custom_Format_String
        {
            get { return  _custom_Format_String; }
            set { _custom_Format_String = value; }
        }

        #endregion Propri�t�s
    }
}
