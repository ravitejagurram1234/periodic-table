using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Data.Format
{
    /// <summary>
    /// QXP_Format : caract�rise un format QXP
    /// </summary>
    /// <author>cueffl</author>
    /// <date>13/05/2009 11:49:57</date>    
    public abstract partial class QXP_Format
    {
        /// <summary>
        /// QXP_Format_Currency : caract�rise un format de devise QXP
        /// </summary>
        /// <author>cueffl</author>
        /// <date>14/05/2009 10:52:36</date>    
        public class QXP_Format_Currency : QXP_Format_Number
        {
            #region Membres

            #endregion Membres

            #region Constantes

            #endregion Constantes

            #region Enums

            #endregion Enums

            #region Constructeur

            /// <summary>
            /// Cr�e une instance de QXP_Format_Currency
            /// </summary>
            public QXP_Format_Currency(): base()
            {
                base._is_Currency = true;
            }
            
            /// <summary>
            /// Cr�e une instance de QXP_Format_Currency
            /// </summary>
            /// <param name="nb_Decimal">Nombre de d�cimal</param>
            /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
            /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
            /// <param name="number_Millier_Separator">S�parateur des milliers</param>
            public QXP_Format_Currency(int? nb_Decimal, int? format_Nombre_Negatif, string number_Decimal_Separator, string number_Millier_Separator) : base(nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator)
            {
                base._is_Currency = true;
            }

            /// <summary>
            /// Cr�e une instance de QXP_Format_Currency
            /// </summary>
            public QXP_Format_Currency(string symbol_Currency) : this()
            {
                base._symbol_Currency = symbol_Currency;
            }

            #endregion Constructeur

            #region M�thodes

            #endregion M�thodes

            #region Propri�t�s

            /// <summary>
            /// Format personnalis� (correspond � la valeur de "param" dans le {0:param} d'un string.Format())
            /// </summary>
            public string Symbol_Currency
            {
                get { return  _symbol_Currency; }
                set { _symbol_Currency = value; }
            }

            #endregion Propri�t�s
        }
    }
}
