using System;
using System.Collections.Generic;
using System.Text;

using QXP.Framework.Data.Format;


namespace QXP.Framework.Data
{
    /// <summary>
    /// QXP_Value_Format_Helper
    /// </summary>
    /// <author>cueffl</author>
    /// <date>14/05/2009 14:52:35</date>    
    public class QXP_Value_Format_Helper
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de QXP_Value_Helper
        /// </summary>
        public QXP_Value_Format_Helper()
        {
        }

        #endregion Constructeur

        #region M�thodes

        #region Factory QXP_Value

        /// <summary>
        /// Cr�e une QXP_Value
        /// </summary>
        /// <param name="value">Valeur � contenir dans l'QXP_Value</param>
        /// <param name="type">TypeCode de la valeur (utilis� pour d�finir le type de l'QXP_Value et le bon QXP_Format)</param>
        /// <param name="nb_Decimal">Nombre de d�cimal</param>
        /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
        /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
        /// <param name="number_Millier_Separator">S�parateur des milliers</param>
        /// <param name="is_Percent">Le format est un format de pourcentage</param>
        /// <param name="is_Currency">Le format est un format de devise</param>
        /// <param name="is_DateTime">Le format de date est une date + heure</param>
        /// <returns>Une QXP_Value</returns>
        public static IQXP_Value Create_QXP_Value(Oracle.OraValue value, ValueType.TypeCode type, int? nb_Decimal, int? format_Nombre_Negatif, string number_Decimal_Separator, string number_Millier_Separator, bool is_Percent, bool is_Currency, bool is_DateTime)
        {
            IQXP_Value          __qxp_value = null;
            QXP_Format          __qxp_format = null;
            __qxp_format = Create_QXP_Format(type, nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator, is_Percent, is_Currency, is_DateTime);
            __qxp_value = Create_QXP_Value(value, type, __qxp_format);
            return __qxp_value;           
        }

        /// <summary>
        /// Cr�e une QXP_Value � partir d'un QXP_Format
        /// </summary>
        /// <param name="value">Valeur � contenir dans l'QXP_Value</param>
        /// <param name="type">TypeCode de la valeur (utilis� pour d�finir le type de l'QXP_Value)</param>
        /// <param name="format">QXP_Format associ�</param>
        /// <returns>Une QXP_Value</returns>
        public static IQXP_Value Create_QXP_Value(Oracle.OraValue value, ValueType.TypeCode type, QXP_Format format)
        {
            IQXP_Value          __qxp_value = null;

            switch (type)
	        {
                //case ValueType.TypeCode.CLSbyte:
                case ValueType.TypeCode.CLSint16:
                    Int16 __value_Int16 = (Int16)value;
                    __qxp_value = new QXP_Value<Int16>(__value_Int16, format);
                    break;
                case ValueType.TypeCode.CLSint32:
                    int __value_int = (int)value;
                    __qxp_value = new QXP_Value<int>(__value_int, format);
                    break;
                case ValueType.TypeCode.CLSint64:                
                    Int64 __value_Int64 = (Int64)value;
                    __qxp_value = new QXP_Value<Int64>(__value_Int64, format);
                    break;
                case ValueType.TypeCode.CLSsingle:                              
                case ValueType.TypeCode.CLSdouble:
                case ValueType.TypeCode.CLSdecimal:
                    decimal __value_Decimal = (decimal)value;
                    __qxp_value = new QXP_Value<decimal>(__value_Decimal, format);
                     break;
                case ValueType.TypeCode.DateTime:       
                    DateTime __value_DateTime = (DateTime)value;
                    __qxp_value = new QXP_Value<DateTime>(__value_DateTime, format);
                    break;
                //case ValueType.TypeCode.CLSstring:
                default:
                    string __value_string = (string)value;
                    __qxp_value = new QXP_Value<string>(__value_string, format);
                 break;
	        }
            return __qxp_value;
        }
        
        /// <summary>
        /// Cr�e une QXP_Value contenant un Nombre
        /// </summary>
        /// <param name="value">Valeur � contenir dans l'QXP_Value</param>
        /// <param name="type">TypeCode de la valeur (utilis� pour d�finir le type de l'QXP_Value et le bon QXP_Format)</param>
        /// <param name="nb_Decimal">Nombre de d�cimal</param>
        /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
        /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
        /// <param name="number_Millier_Separator">S�parateur des milliers</param>
        /// <returns>Une QXP_Value</returns>
        public static IQXP_Value Create_QXP_Value_Number(Oracle.OraValue value, ValueType.TypeCode type, int? nb_Decimal, int? format_Nombre_Negatif, string number_Decimal_Separator, string number_Millier_Separator)
        {
            return Create_QXP_Value(value, type, nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator, false, false, false);
        }
    
        /// <summary>
        /// Cr�e une QXP_Value contenant un Pourcentage
        /// </summary>
        /// <param name="value">Valeur � contenir dans l'QXP_Value</param>
        /// <param name="type">TypeCode de la valeur (utilis� pour d�finir le type de l'QXP_Value et le bon QXP_Format)</param>
        /// <param name="nb_Decimal">Nombre de d�cimal</param>
        /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
        /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
        /// <param name="number_Millier_Separator">S�parateur des milliers</param>
        /// <returns>Une QXP_Value</returns>
        public static IQXP_Value Create_QXP_Value_Pourcentage(Oracle.OraValue value, ValueType.TypeCode type, int? nb_Decimal, int? format_Nombre_Negatif, string number_Decimal_Separator, string number_Millier_Separator)
        {
            return Create_QXP_Value(value, type, nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator, true, false, false);
        }

        /// <summary>
        /// Cr�e une QXP_Value contenant une Devise
        /// </summary>
        /// <param name="value">Valeur � contenir dans l'QXP_Value</param>
        /// <param name="type">TypeCode de la valeur (utilis� pour d�finir le type de l'QXP_Value et le bon QXP_Format)</param>
        /// <param name="nb_Decimal">Nombre de d�cimal</param>
        /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
        /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
        /// <param name="number_Millier_Separator">S�parateur des milliers</param>
        /// <param name="is_Percent">Le format est un format de pourcentage</param>
        /// <param name="is_Currency">Le format est un format de devise</param>
        /// <param name="is_DateTime">Le format de date est une date + heure</param>
        /// <returns>Une QXP_Value</returns>
        public static IQXP_Value Create_QXP_Value_Currency(Oracle.OraValue value, ValueType.TypeCode type, int? nb_Decimal, int? format_Nombre_Negatif, string number_Decimal_Separator, string number_Millier_Separator)
        {
            return Create_QXP_Value(value, type, nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator, false, true, false);                
        }

        /// <summary>
        /// Cr�e une QXP_Value contenant un DateTime
        /// </summary>
        /// <param name="value">Valeur � contenir dans l'QXP_Value</param>
        /// <param name="is_DateTime">Le format de date est une date + heure</param>
        /// <returns>Une QXP_Value</returns>
        public static IQXP_Value Create_QXP_Value_DateTime(Oracle.OraValue value, bool is_DateTime)
        {
            return Create_QXP_Value(value, ValueType.TypeCode.DateTime, null, null, null, null, false, false, is_DateTime);         
        }

        /// <summary>
        /// Cr�e une QXP_Value contenant un string
        /// </summary>
        /// <param name="value">Valeur � contenir dans l'QXP_Value</param>
        /// <returns>Une QXP_Value</returns>
        public static IQXP_Value Create_QXP_Value_String(Oracle.OraValue value)
        {
            return Create_QXP_Value(value, ValueType.TypeCode.CLSstring, null, null, null, null, false, false, false);
        }

        #endregion Factory QXP_Value

        #region Factory QXP_Format

        /// <summary>
        /// Cr�e un QXP_Format
        /// </summary>
        /// <param name="type">TypeCode de la valeur (utilis� pour d�finir le bon QXP_Format)</param>
        /// <param name="custom_Format_String">Custom Format String : correspond au param dans le string.format(...{0:param}) de .Net</param>
        /// <returns>Un QXP_Format</returns>
        public static QXP_Format Create_QXP_Format(ValueType.TypeCode type, string custom_Format_String)
        {
            QXP_Format   __qxp_format = null;

            switch (type)
	        {
                case ValueType.TypeCode.CLSbyte:
                case ValueType.TypeCode.CLSint16:
                case ValueType.TypeCode.CLSint32:
                case ValueType.TypeCode.CLSint64:
                case ValueType.TypeCode.CLSsingle:                              
                case ValueType.TypeCode.CLSdouble:
                case ValueType.TypeCode.CLSdecimal:
                    __qxp_format = Create_QXP_Format_Number(custom_Format_String);
                    break;
                case ValueType.TypeCode.DateTime:                    
                    __qxp_format = Create_QXP_Format_DateTime(custom_Format_String);
                    break;
                //case ValueType.TypeCode.CLSstring:
                default:
                    __qxp_format = Create_QXP_Format_String(custom_Format_String);
                    break;
	        }

            return __qxp_format;
        }

        /// <summary>
        /// Cr�e un QXP_Format
        /// </summary>
        /// <param name="type">TypeCode de la valeur (utilis� pour d�finir le bon QXP_Format)</param>
        /// <param name="nb_Decimal">Nombre de d�cimal</param>
        /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
        /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
        /// <param name="number_Millier_Separator">S�parateur des milliers</param>
        /// <param name="is_Percent">Le format est un format de pourcentage</param>
        /// <param name="is_Currency">Le format est un format de devise</param>
        /// <param name="is_DateTime">Le format de date est une date + heure</param>
        /// <returns>Un QXP_Format</returns>
        public static QXP_Format Create_QXP_Format(ValueType.TypeCode type, int? nb_Decimal,int? format_Nombre_Negatif,string number_Decimal_Separator,string number_Millier_Separator,bool is_Percent,bool is_Currency, bool is_DateTime)
        {
            QXP_Format   __qxp_format = null;

            switch (type)
	        {
                case ValueType.TypeCode.CLSbyte:
                case ValueType.TypeCode.CLSint16:
                case ValueType.TypeCode.CLSint32:
                case ValueType.TypeCode.CLSint64:
                case ValueType.TypeCode.CLSsingle:                              
                case ValueType.TypeCode.CLSdouble:
                case ValueType.TypeCode.CLSdecimal:
                    if(is_Percent)
                        __qxp_format = Create_QXP_Format_Pourcentage(nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator);
                    else if(is_Currency)
                        __qxp_format = Create_QXP_Format_Currency(nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator);
                    else
                        __qxp_format = Create_QXP_Format_Number(nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator);
                    break;
                case ValueType.TypeCode.DateTime:                    
                    __qxp_format = Create_QXP_Format_DateTime(is_DateTime);
                    break;
                //case ValueType.TypeCode.CLSstring:
                default:
                    __qxp_format = Create_QXP_Format_String();
                    break;
	        }
            return __qxp_format;
        }

        /// <summary>
        /// Cr�e un QXP_Format_Number
        /// </summary>
        /// <param name="custom_format_string">Custom Format String : correspond au param dans le string.format(...{0:param}) de .Net</param>
        /// <returns>Un QXP_Format_Number</returns>
        public static QXP_Format.QXP_Format_Number Create_QXP_Format_Number(string custom_format_string)
        {
            QXP_Format.QXP_Format_Number   __qxp_format = null;
            __qxp_format = new QXP_Format.QXP_Format_Number(custom_format_string);
            return __qxp_format;
        }

        /// <summary>
        /// Cr�e un QXP_Format_Number
        /// </summary>
        /// <param name="nb_Decimal">Nombre de d�cimal</param>
        /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
        /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
        /// <param name="number_Millier_Separator">S�parateur des milliers</param>
        /// <returns>Un QXP_Format_Number</returns>
        public static QXP_Format.QXP_Format_Number Create_QXP_Format_Number(int? nb_Decimal,int? format_Nombre_Negatif,string number_Decimal_Separator,string number_Millier_Separator)
        {
            QXP_Format.QXP_Format_Number   __qxp_format = null;
            __qxp_format = new QXP_Format.QXP_Format_Number(nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator);
            return __qxp_format;
        }

        /// <summary>
        /// Cr�e un QXP_Format_Pourcentage
        /// </summary>
        /// <param name="nb_Decimal">Nombre de d�cimal</param>
        /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
        /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
        /// <param name="number_Millier_Separator">S�parateur des milliers</param>
        /// <returns>Un QXP_Format_Pourcentage</returns>
        public static QXP_Format.QXP_Format_Pourcentage Create_QXP_Format_Pourcentage(int? nb_Decimal,int? format_Nombre_Negatif,string number_Decimal_Separator,string number_Millier_Separator)
        {
            QXP_Format.QXP_Format_Pourcentage   __qxp_format = null;
            __qxp_format = new QXP_Format.QXP_Format_Pourcentage(nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator);
            return __qxp_format;
        }

        /// <summary>
        /// Cr�e un QXP_Format_Currency
        /// </summary>
        /// <param name="nb_Decimal">Nombre de d�cimal</param>
        /// <param name="format_Nombre_Negatif">Format du nombre n�gatif (valeurs possibles : 0, 1, 2, 3, 4)</param>
        /// <param name="number_Decimal_Separator">S�parateur des nombres d�cimaux</param>
        /// <param name="number_Millier_Separator">S�parateur des milliers</param>
        /// <returns>Un QXP_Format_Currency</returns>
        public static QXP_Format.QXP_Format_Currency Create_QXP_Format_Currency(int? nb_Decimal,int? format_Nombre_Negatif,string number_Decimal_Separator,string number_Millier_Separator)
        {
            QXP_Format.QXP_Format_Currency   __qxp_format = null;
            __qxp_format = new QXP_Format.QXP_Format_Currency(nb_Decimal, format_Nombre_Negatif, number_Decimal_Separator, number_Millier_Separator);
            return __qxp_format;
        }

        /// <summary>
        /// Cr�e un QXP_Format_DateTime
        /// </summary>
        /// <param name="custom_format_string">Custom Format String : correspond au param dans le string.format(...{0:param}) de .Net</param>
        /// <returns>Un QXP_Format_DateTime</returns>
        public static QXP_Format.QXP_Format_DateTime Create_QXP_Format_DateTime(string custom_format_string)
        {
            QXP_Format.QXP_Format_DateTime   __qxp_format = null;
            __qxp_format = new QXP_Format.QXP_Format_DateTime(custom_format_string);
            return __qxp_format;
        }

        /// <summary>
        /// Cr�e un QXP_Format_DateTime
        /// </summary>
        /// <param name="is_DateTime">Le format de date est une date + heure</param>
        /// <returns>Un QXP_Format_DateTime</returns>
        public static QXP_Format.QXP_Format_DateTime Create_QXP_Format_DateTime(bool is_DateTime)
        {
            QXP_Format.QXP_Format_DateTime   __qxp_format = null;
            __qxp_format = new QXP_Format.QXP_Format_DateTime(is_DateTime);
            return __qxp_format;
        }

        /// <summary>
        /// Cr�e un QXP_Format_String
        /// </summary>
        /// <param name="custom_format_string">Custom Format String : correspond au param dans le string.format(...{0:param}) de .Net</param>
        /// <returns>Un QXP_Format_String</returns>
        public static QXP_Format.QXP_Format_String Create_QXP_Format_String(string custom_format_string)
        {
            QXP_Format.QXP_Format_String   __qxp_format = null;
            __qxp_format = new QXP_Format.QXP_Format_String(custom_format_string);
            return __qxp_format;
        }

        /// <summary>
        /// Cr�e un QXP_Format_String
        /// </summary>
        /// <returns>Un QXP_Format_String</returns>
        public static QXP_Format.QXP_Format_String Create_QXP_Format_String()
        {
            QXP_Format.QXP_Format_String   __qxp_format = null;
            __qxp_format = new QXP_Format.QXP_Format_String();
            return __qxp_format;
        }

        #endregion Factory QXP_Format

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
