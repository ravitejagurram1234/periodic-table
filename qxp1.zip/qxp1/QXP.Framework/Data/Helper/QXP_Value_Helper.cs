using System;
using System.IO;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;

using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Framework.Data
{
    /// <summary>
    /// Permet la conversion de valeur Oracle en valeur .net.
    /// Utilis� par OraValue et OraObject pour factoriser les conversions depuis les valeurs Oracle
    /// </summary>
    /// <author>doufarm</author>
    /// <date>23/12/2010 09:28:53</date>    
    public class QXP_Value_Helper
    {
        #region Membres

        #endregion Membres

        #region Constantes
        const int OracleDecimalPrecision = 28;
        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Constructeur static QXP_Value_Helper
        /// </summary>
        static QXP_Value_Helper()
        {
        }

        #endregion Constructeur

        #region M�thodes


        /// <summary>Checks if OraValue is null or DBNull. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>true si la valeur est null, sinon false</returns>
        public static bool IsNull(object oracleValue)
        {
            if (oracleValue is OracleDate)
            {
                return ((OracleDate)oracleValue).IsNull;
            }
            else if (oracleValue is OracleDecimal)
            {
                return ((OracleDecimal)oracleValue).IsNull;
            }
            else if (oracleValue is OracleString)
            {
                return ((OracleString)oracleValue).IsNull;
            }
            else if (oracleValue is OracleIntervalDS)
            {
                return ((OracleIntervalDS)oracleValue).IsNull;
            }
            else
            {
                return Validation.IsNull(oracleValue);
            }
        }

        /// <summary>Gets the <see cref="string"/> representation of an Oracle Value . </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="String"/> value. </returns>
        public static string ToString(object oracleValue)
        {
            if (IsNull(oracleValue)) return String.Empty;

            if (oracleValue is OracleString)
            {
                OracleString __oraString = (OracleString)oracleValue;
                string __string = (string)__oraString;
                return __string;
            }
            else if (oracleValue is OracleClob)
            {
                OracleClob __oraClob = (OracleClob)oracleValue;
                string __string = Conversion.ToString(__oraClob.Value);
                return __string;
            }
            else if (oracleValue is OracleBinary)
            {
                OracleBinary __oraBinary = (OracleBinary)oracleValue;
                string __string = string.Empty;
                if (!__oraBinary.IsNull)
                {
                    __string = Conversion.ToHexString(__oraBinary.Value);
                }
                return __string;
            }
            return Conversion.ToString(oracleValue);
        }

        /// <summary>Gets the <see cref="bool"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Boolean"/> value. </returns>
        public static bool ToBoolean(object oracleValue)
        {
            if (IsNull(oracleValue)) return false;

            byte __byte;

            if (oracleValue is OracleDecimal || oracleValue is OracleString)
            {
                OracleDecimal __oraDecimal = ToOracleDecimal(oracleValue);
                __byte = (byte)OracleDecimal.SetPrecision(__oraDecimal, 1);
            }
            else if (oracleValue is byte)
            {
                __byte = Conversion.ToByte(oracleValue);
            }
            else
            {
                return Conversion.ToBool(oracleValue);
            }
            return !(__byte == 0);
        }

        /// <summary>Gets the <see cref="Byte"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Byte"/> value. </returns>
        public static Byte ToByte(object oracleValue)
        {
            if (IsNull(oracleValue)) return Byte.MinValue;

            if (oracleValue is OracleDecimal)
            {
                OracleDecimal __oraDecimal = (OracleDecimal)oracleValue;
                byte __byte = __oraDecimal.ToByte();
                return __byte;
            }
            return Conversion.ToByte(oracleValue);
        }

        /// <summary>Gets the <see cref="Int16"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Int16"/> value. </returns>
        public static Int16 ToInt16(object oracleValue)
        {
            if (IsNull(oracleValue)) return Int16.MinValue;

            if (oracleValue is OracleDecimal)
            {
                OracleDecimal __oraDecimal = (OracleDecimal)oracleValue;
                short __int = __oraDecimal.ToInt16();
                return __int;
            }
            return Conversion.ToShort(oracleValue);
        }

        /// <summary>Gets the <see cref="Int32"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Int32"/> value. </returns>
        public static Int32 ToInt32(object oracleValue)
        {
            if (IsNull(oracleValue)) return Int32.MinValue;

            if (oracleValue is OracleDecimal)
            {
                OracleDecimal __oraDecimal = (OracleDecimal)oracleValue;
                int __int = __oraDecimal.ToInt32();
                return __int;
            }
            return Conversion.ToInt(oracleValue);
        }

        /// <summary>Gets the <see cref="Int32"/> array representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Int32"/> array. </returns>
        public static Int32[] ToInt32s(object oracleValue)
        {
            if (IsNull(oracleValue) || Validation.IsNull(oracleValue)) return new int[0];

            if (oracleValue is OracleDecimal[])
            {
                OracleDecimal[] __oraDecimals = (OracleDecimal[])oracleValue;
                List<int> __ints = new List<int>();
                foreach (OracleDecimal __oraDecimal in __oraDecimals)
                {
                    if (__oraDecimal.IsNull)
                    {
                        __ints.Add(int.MinValue);
                    }
                    else
                    {
                        __ints.Add(__oraDecimal.ToInt32());
                    }
                }
                return __ints.ToArray();
            }
            else
            {
                throw new ArgumentException(Constantes.InvalidOraValueTypeListeInts);
            }
        }

        /// <summary>Gets the <see cref="Int64"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Int64"/> value. </returns>
        public static Int64 ToInt64(object oracleValue)
        {
            if (IsNull(oracleValue)) return Int64.MinValue;

            if (oracleValue is OracleDecimal)
            {
                OracleDecimal __oraDecimal = (OracleDecimal)oracleValue;
                long __long = __oraDecimal.ToInt64();
                return __long;
            }
            return Conversion.ToLong(oracleValue);
        }

        /// <summary>Gets the <see cref="Decimal"/> array representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Decimal"/> array. </returns>
        public static Decimal[] ToDecimals(object oracleValue)
        {
            if (IsNull(oracleValue) || Validation.IsNull(oracleValue)) return new decimal[0];

            if (oracleValue is OracleDecimal[])
            {
                OracleDecimal[] __oraDecimals = (OracleDecimal[])oracleValue;
                List<decimal> __decimals = new List<decimal>();
                //Permet d'appliquer la pr�cision sur chaque valeur oracledecimal
                foreach (OracleDecimal __oraDecimal in __oraDecimals)
                {
                    if (__oraDecimal.IsNull)
                    {
                        __decimals.Add(decimal.MinValue);
                    }
                    else
                    {
                        __decimals.Add((decimal)OracleDecimal.SetPrecision(__oraDecimal, OracleDecimalPrecision));
                    }
                }
                return __decimals.ToArray();
            }
            else
            {
                throw new ArgumentException(Constantes.InvalidOraValueTypeListeDecimals);
            }
        }

        /// <summary>Gets the <see cref="Decimal"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Decimal"/> value. </returns>
        public static Decimal ToDecimal(object oracleValue)
        {
            if (IsNull(oracleValue)) return Decimal.MinValue;

            if (oracleValue is OracleDecimal)
            {
                OracleDecimal __oraDecimal = (OracleDecimal)oracleValue;
                Decimal __decimal = (Decimal)OracleDecimal.SetPrecision(__oraDecimal, OracleDecimalPrecision);
                return __decimal;
            }
            return Conversion.ToDecimal(oracleValue);
        }

        /// <summary>Gets the <see cref="Single"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Single"/> value. </returns>
        public static Single ToSingle(object oracleValue)
        {
            if (IsNull(oracleValue)) return Single.MinValue;

            if (oracleValue is OracleDecimal || oracleValue is OracleString)
            {
                OracleDecimal __oraDecimal = (OracleDecimal)oracleValue;
                Single __float = __oraDecimal.ToSingle();
                return __float;
            }
            return Conversion.ToFloat(oracleValue);
        }

        /// <summary>Gets the <see cref="Double"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Double"/> value. </returns>
        public static Double ToDouble(object oracleValue)
        {
            if (IsNull(oracleValue)) return Double.MinValue;

            if (oracleValue is OracleDecimal)
            {
                OracleDecimal __oraDecimal = (OracleDecimal)oracleValue;
                double __double = __oraDecimal.ToDouble();
                return __double;
            }
            return Conversion.ToDouble(oracleValue);
        }

        /// <summary>Gets the <see cref="DateTime"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="DateTime"/> value. </returns>
        public static DateTime ToDateTime(object oracleValue)
        {
            if (IsNull(oracleValue)) return DateTime.MinValue;

            if (oracleValue is OracleDate)
            {
                OracleDate __oraDate = (OracleDate)oracleValue;
                DateTime __date = (DateTime)__oraDate;
                return __date;
            }
            return Conversion.ToDateTime(oracleValue);
        }

        /// <summary>Gets the <see cref="OracleDecimal"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="OracleDecimal"/> value. </returns>
        public static OracleDecimal ToOracleDecimal(object oracleValue)
        {
            string __value = Conversion.ToString(oracleValue);
            OracleDecimal __oraDecimal = (OracleDecimal)__value;
            return __oraDecimal;
        }

        /// <summary>Gets the <see cref="byte"/> array representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="byte"/> array value. </returns>
        /// <exception cref="ArgumentException">if the Oracle Value is not Blob compatible. </exception>
        public static byte[] ToBytes(object oracleValue)
        {
            if (oracleValue is OracleBlob)
            {
                OracleBlob __oraBlob = (OracleBlob)oracleValue;
                return __oraBlob.Value;
            }
            else if (Validation.IsNull(oracleValue))
            {
                return new byte[0];
            }
            else
            {
                throw new ArgumentException(Constantes.InvalidOraValueTypeMBBlob);
            }
        }

        /// <summary>Gets the <see cref="Stream"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Stream"/> value. </returns>
        /// <exception cref="ArgumentException">if the Oracle Value is not Blob or Clob compatible. </exception>
        public static Stream ToStream(object oracleValue)
        {
            if (oracleValue is OracleBlob)
            {
                OracleBlob __oraBlob = (OracleBlob)oracleValue;
                return __oraBlob;
            }
            else if (oracleValue is OracleClob)
            {
                OracleClob __oraClob = (OracleClob)oracleValue;
                return __oraClob;
            }
            else if (Validation.IsNull(oracleValue))
            {
                return new MemoryStream();
            }
            else
            {
                throw new ArgumentException(Constantes.InvalidOraValueTypeMBBlobOrClob);
            }
        }

        /// <summary>Gets the <see cref="Char"/> array representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Char"/> array value. </returns>
        /// <exception cref="ArgumentException">if the Oracle Value is not Clob compatible. </exception>
        public static Char[] ToChars(object oracleValue)
        {
            if (oracleValue is OracleClob)
            {
                OracleClob __oraClob = (OracleClob)oracleValue;
                int __len = (int)__oraClob.Length / 2;	//INFO: I dont know why but the real len is equals to Clob lenght divide by 2. (thanks to reflector !!)				
                //return __oraClob.Value.ToCharArray();
                Char[] __chars = new Char[__len];
                __oraClob.Read(__chars, 0, __len);
                return __chars;
            }
            else if (Validation.IsNull(oracleValue))
            {
                return new Char[0];
            }
            else
            {
                throw new ArgumentException(Constantes.InvalidOraValueTypeMBClob);
            }
        }

        /// <summary>Gets the <see cref="String"/> array representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="string"/> array value. </returns>
        /// <exception cref="ArgumentException">if the Oracle Value is not string array compatible. </exception>
        public static string[] ToStrings(object oracleValue)
        {
            if (oracleValue is OracleString[])
            {
                OracleString[] __oraStrings = (OracleString[])oracleValue;
                List<string> __strings = new List<string>();
                //Permet de tester la nullit� de la valeur
                foreach (OracleString __oraString in __oraStrings)
                {
                    if (__oraString.IsNull)
                    {
                        __strings.Add(string.Empty);
                    }
                    else
                    {
                        __strings.Add(__oraString.Value);
                    }
                }
                return __strings.ToArray();
            }
            else if (Validation.IsNull(oracleValue))
            {
                return new string[0];
            }
            else
            {
                throw new ArgumentException(Constantes.InvalidOraValueTypeListeString);
            }
        }

        /// <summary>Gets the <see cref="DateTime"/> array representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="DateTime"/> array value. </returns>
        /// <exception cref="ArgumentException">if the Oracle Value is not DateTime array compatible. </exception>
        public static DateTime[] ToDateTimes(object oracleValue)
        {
            if (oracleValue is OracleDate[])
            {
                OracleDate[] __oraDates = (OracleDate[])oracleValue;
                List<DateTime> __dates = new List<DateTime>();
                //Permet de tester la nullit� de la valeur
                foreach (OracleDate __value in __oraDates)
                {
                    if (__value.IsNull)
                    {
                        __dates.Add(DateTime.MinValue);
                    }
                    else
                    {
                        __dates.Add(__value.Value);
                    }
                }
                return __dates.ToArray();
            }
            else if (Validation.IsNull(oracleValue))
            {
                return new DateTime[0];
            }
            else
            {
                throw new ArgumentException(Constantes.InvalidOraValueTypeListeDateTime);
            }
        }

        /// <summary>Gets the <see cref="TimeSpan"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="TimeSpan"/> value. </returns>
        /// <exception cref="ArgumentException">if the Oracle Value is not TimeSpan compatible. </exception>
        public static TimeSpan ToTimeSpan(object oracleValue)
        {
            if (IsNull(oracleValue)) return TimeSpan.MinValue;

            if (oracleValue is OracleIntervalDS)
            {
                OracleIntervalDS __oraIntervalDS = (OracleIntervalDS)oracleValue;
                return __oraIntervalDS.Value;
            }
            else
            {
                throw new ArgumentException(Constantes.InvalidOraValueTypeTimeSpan);
            }

        }

        /// <summary>Gets the <see cref="Oracle.OraObject"/> representation of an Oracle Value. </summary>
        /// <param name="oracleValue">la valeur Oracle</param>
        /// <returns>The <see cref="Oracle.OraObject"/> value. </returns>
        /// <exception cref="ArgumentException">if the Oracle Value is not Oracle.OraObject compatible. </exception>
        public static Oracle.OraObject ToOraObject(object oracleValue)
        {
            if (oracleValue is Oracle.OraObject)
            {
                return (Oracle.OraObject)oracleValue;
            }
            else
            {
                return Oracle.OraObject.Null;
            }
        }

        public static object ToObject(object oracleValue, Type type)
        {
            if (type == ValueType.CLSstring)
            {
                return ToString(oracleValue) ;
            }
            else if (type == ValueType.CLSboolean)
            {
                return ToBoolean(oracleValue) ;
            }
            else if (type == ValueType.CLSbyte)
            {
                return ToByte(oracleValue);
            }
            else if (type == ValueType.CLSint16)
            {
                return ToInt16(oracleValue);
            }
            else if (type == ValueType.CLSint32)
            {
                return ToInt32(oracleValue);
            }
            else if (type == ValueType.CLSint64)
            {
                return ToInt64(oracleValue);
            }
            else if (type == ValueType.ArrayOfDecimal)
            {
                return ToDecimals(oracleValue);
            }
            else if (type == ValueType.CLSdecimal)
            {
                return ToDecimal(oracleValue);
            }
            else if (type == ValueType.CLSsingle)
            {
                return ToSingle(oracleValue);
            }
            else if (type == ValueType.CLSdouble)
            {
                return ToDouble(oracleValue);
            }
            else if (type == ValueType.DateTime)
            {
                return ToDateTime(oracleValue);
            }
            else if (type == ValueType.ArrayOfByte)
            {
                return ToBytes(oracleValue);
            }
            else if (type == ValueType.ArrayOfChar)
            {
                return ToChars(oracleValue);
            }
            else if (type == ValueType.ArrayOfString)
            {
                return ToStrings(oracleValue);
            }
            else if (type == typeof(Oracle.OraObject))
            {
                return ToOraObject(oracleValue);
            }
            return oracleValue;
        }


        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
