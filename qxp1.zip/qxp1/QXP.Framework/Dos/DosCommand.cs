using System;
using System.Collections.Generic;
using System.Diagnostics;


namespace QXP.Framework.Dos
{
    /// <summary>
    /// DosCommand : Permet l'invocation de commandes MSDOS
    /// </summary>
    /// <author>LCU</author>
    /// <date>11/01/2010</date>    
    public class DosCommand : IDisposable
    {
        #region Membres

        /// <summary>
        /// Utilis� pour lancer la commande MS DOS
        /// </summary>
        Process _process;
        /// <summary>
        /// Par d�faut, le temps d'attente d'execution du process est fix� � 2 min
        /// </summary>
        private int _exit_Timeout = EXIT_TIMEOUT;

        #endregion Membres

        #region Constantes
        
        private const string MSDOS_APPLICATION  = "CMD.EXE";
        private const string EXIT_COMMAND       = "exit";
        private const int EXIT_TIMEOUT = 120000;

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de DosCommand
        /// </summary>
        public DosCommand()
        {

        }

        /// <summary>
        /// Cr�e une instance de DosCommand
        /// </summary>
        /// <param name="exit_Timeout">Temps d'attente de fin d'execution des commandes MSDOS (en millisecondes)</param>
        public DosCommand(int exit_Timeout)
        {
            this._exit_Timeout = exit_Timeout;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// D�marre le process MSDOS
        /// </summary>
        private void Start()
        {                    
            _process = new Process();
            _process.StartInfo.FileName = MSDOS_APPLICATION;
            _process.StartInfo.ErrorDialog = false;
            _process.StartInfo.UseShellExecute = false;
            _process.StartInfo.CreateNoWindow = true;
            _process.StartInfo.RedirectStandardOutput = true;
            _process.StartInfo.RedirectStandardInput = true;
            _process.StartInfo.RedirectStandardError = true;			
			_process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            _process.Start();
        }
        
        /// <summary>
        /// Close la commande (d�truit le process li�)
        /// </summary>
        private void Close()
        {        
            if(_process!=null)
                _process.Close();
        }


        /// <summary>
        /// Execute une ou plusieurs commandes MSDOS en un seul bloc
        /// </summary>
        /// <param name="commands">Commande(s) � executer</param>
        /// <returns>Un objet DosResult contenant les informations sur l'execution des commandes</returns>
        public DosResult SendCommand(params string[] commands)
        {
            return SendCommand<DosResult>(commands);
        }
        
        /// <summary>
        /// Execute une ou plusieurs commandes MSDOS en un seul bloc
        /// </summary>
        /// <param name="commands">Commande(s) � executer</param>
        /// <returns>Un objet de type DosResult contenant les informations sur l'execution des commandes</returns>
        public T SendCommand<T>(params string[] commands) where T : DosResult
        {
            T __result = Activator.CreateInstance<T>();
            //Par d�faut 2 min
           __result.Process_Exit_Timeout = this._exit_Timeout;
            try
            {            
                if (commands.Length != 0) 
                {
                    //D�marrage du process : on lance l'interpreteur de commande MSDOS
                    this.Start();

                    //Ecriture des commandes dans l'entr�e standard (on lance les commandes)
                    foreach (string __command in commands)
                    {
                        _process.StandardInput.WriteLine(__command);                
                    }                                            
                    //On ajoute la commande EXIT pour terminer l'interpreteur de commande MSDOS 
                    //_process.StandardInput.WriteLine(EXIT_COMMAND);
                    _process.StandardInput.Flush();
                    _process.StandardInput.Close();
                    //Analyse du r�sultat (code de retour etc)
                    __result.Analyse(_process, commands);
                }
            }
            finally
            {
                //Fermeture du process
                this.Close();
            }
            return __result;
        }
        
        /// <summary>
        /// Execute chaque commande unitairement et retourne une liste de DosResult pour chaque commande
        /// </summary>
        /// <param name="commands">Liste de commandes � executer</param>
        /// <returns>La liste des r�sultats de chaque commande</returns>
        public List<DosResult> SendCommands(params string[] commands)
        {
            return SendCommands<DosResult>(commands);
        }
        /// <summary>
        /// Execute chaque commande unitairement et retourne une liste de type DosResult pour chaque commande
        /// </summary>
        /// <param name="commands">Liste de commandes � executer</param>
        /// <returns>La liste des r�sultats de chaque commande</returns>
        public List<T> SendCommands<T>(params string[] commands) where T : DosResult
        {
            if (commands.Length == 0) 
                return new List<T>();
            List<T> __lstDosResult = new List<T>();
            
            foreach(string __command in commands)
            {
                __lstDosResult.Add(this.SendCommand<T>(__command));                
            }
            
            return __lstDosResult;
        }

        /// <summary>
        /// Lors de la suppression de l'objet DosCommand par le GC
        /// </summary>
        public void Dispose()
        {
            this.Close();
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Temps d'attente maximum de fin d'execution des commandes MSDOS
        /// </summary>
        public int Exit_Timeout
        {
            get { return _exit_Timeout; }
            set { _exit_Timeout= value; }
        }

        #endregion Propri�t�s
    }

			
}
