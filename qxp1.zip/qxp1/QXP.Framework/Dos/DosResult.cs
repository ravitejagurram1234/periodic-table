using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace QXP.Framework.Dos
{
    /// <summary>
    /// DosResult caract�rise le r�sultat d'une ou plusieurs commandes MSDOS.
    /// </summary> 
    public class DosResult
    {
        #region Membres

        List<string> _standardOutput    = new List<string>();
        List<string> _errorOutput       = new List<string>();
        string[] _commands;
        int _exitCode;

        /// <summary>
        /// Par d�faut : pas d'attente
        /// </summary>
        int _process_Exit_Timeout = 0;

        int _reading_Output_Timeout = 10000;

        Process _process = null;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de DosResult
        /// </summary>
        public DosResult()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Analyse d'une execution d'un process d'une commande MSDOS
        /// </summary>
        /// <param name="process">Process ayant execut� la commande</param>
        /// <param name="commands">Commande execut�e</param>
        public void Analyse(Process process, params string[] commands)
        {
            //Deux threads : l'un pour la lecture de la sortie standard, l'autre pour la sortie d'erreur
            Thread __outputDataReceivedThread = new Thread(new ParameterizedThreadStart(OnOutputDataReceived));
            Thread __errorDataReceivedThread = new Thread(new ParameterizedThreadStart(OnErrorDataReceived));
            
            //Lecture en asynchrone
            __outputDataReceivedThread.Start(process.StandardOutput);
            __errorDataReceivedThread.Start(process.StandardError);

            //Attente de fin d'execution du process
            //Si _exit_Timeout = 0 -> Pas d'attente
            if (!process.WaitForExit(this._process_Exit_Timeout))
            {
                throw new Exception(string.Format("Process TimeOut Exception : La commande ne s'est pas termin�e (max timeout : {0} ms)", this._process_Exit_Timeout));
            }
            
            //Attente de la fin de la lecture de la sortie standard
            if (!__outputDataReceivedThread.Join(_reading_Output_Timeout))
            {
                throw new Exception(string.Format("Process TimeOut Exception : La lecture du retour de la sortie standard de la commande ne s'est pas termin�e (max timeout : {0} ms)", this._reading_Output_Timeout));
            }

            //Attente de la fin de la lecture de la sortie d'erreur
            if(!__errorDataReceivedThread.Join(_reading_Output_Timeout))
            {
                throw new Exception(string.Format("Process TimeOut Exception : La lecture du retour d'erreur de la commande ne s'est pas termin�e (max timeout : {0} ms)", this._reading_Output_Timeout));
            }
            
            this._commands = commands;
            this._exitCode = process.ExitCode;
        }

        /// <summary>
        /// Effectue la lecture de la sortie standard
        /// </summary>
        /// <param name="standardOutput">StreamReader de la sortie standard</param>
        public virtual void OnOutputDataReceived(object standardOutput)
        {
            string __line;
            StreamReader __standardOutput = standardOutput as StreamReader;            
            while((__line = __standardOutput.ReadLine())!=null)
            {    
                if (Validation.IsSet(__line))
                {                
                    this._standardOutput.Add(__line);
                }            
            }
        }

        /// <summary>
        /// Effectue la lecture de la sortie d'erreur
        /// </summary>
        /// <param name="standardError">StreamReader de la sortie d'erreur</param>
        public virtual void OnErrorDataReceived(object standardError)
        {            
            string __line;
            StreamReader __standardError = standardError as StreamReader;
            while((__line = __standardError.ReadLine())!=null)
            {    
                if (Validation.IsSet(__line))
                {                
                    this._errorOutput.Add(__line);
                }            
            }

        }

        /// <summary>
        /// Retourne le r�sultat de la sortie standard + r�sultat de la sortie d'erreur
        /// Chaque ligne est s�par�e par un retour chariot
        /// </summary>
        /// <returns>R�sultat de la sortie standard + r�sultat de la sortie d'erreur</returns>
        private string GetAllOutputs()
        {
            string __retour = null;
            //R�cup�ration du r�sultat de la sortie standard (pour info la sortie standard stocke aussi l'entr�e standard (cad les commandes msdos pass�es)
            this.Outputs.ForEach
            (
                delegate(string __ligne)
                {
                    if (Validation.IsNotSet(__retour))
                        __retour = __ligne;
                    else
                        __retour += "\r\n" + __ligne;
                }
            );

            //R�cup�ration du r�sultat de la sortie des erreurs
            if (this.HaveError)
            {
                this.Errors.ForEach
                (
                    delegate(string __ligne)
                    {
                        if (Validation.IsNotSet(__retour))
                            __retour = __ligne;
                        else
                            __retour += "\r\n" + __ligne;
                    }
                );
            }
            return __retour;
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// R�sultat de la sortie standard
        /// </summary>
        public List<string> Outputs
        {
            get
            {
                return _standardOutput;
            }
        }

        /// <summary>
        /// R�sultat de la sortie d'erreur
        /// </summary>
        public List<string> Errors
        {
            get
            {
                return _errorOutput;
            }
        }

        /// <summary>
        /// Resultat de la sortie standard + r�sultat de la sortie d'erreur
        /// </summary>
        public string AllOutputsString
        {
            get { return GetAllOutputs(); }
        }

        /// <summary>
        /// Indique si la commande s'est termin�e en erreur
        /// </summary>
        public bool HaveError
        {
            get 
            { 
                return (_errorOutput.Count > 0 || this._exitCode !=0); 
            }
        }
        
        /// <summary>
        /// Commande execut�e
        /// </summary>
        public string[] Commands
        {
            get { return _commands; }
        }

        /// <summary>
        /// Code de retour de la commande, si Commands contient plus d'une commande, le code de retour sera celui de la derni�re commande
        /// </summary>
        public int ExitCode
        {
            get { return _exitCode; }
            set { _exitCode = value; }
        }

        /// <summary>
        /// Temps d'attente maximum en millisecondes d'execution des commandes MSDOS
        /// </summary>
        public int Process_Exit_Timeout
        {
            get { return _process_Exit_Timeout; }
            set { _process_Exit_Timeout = value; }
        }

        #endregion Propri�t�s
    }
}
