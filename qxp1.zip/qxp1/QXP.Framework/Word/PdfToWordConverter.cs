//using System;
//using System.Collections.Generic;
//using System.Text;
//using System.IO;

//using QXPFrk = QXP.Framework;

////using SolidFrk = SolidFramework;
////using SolidFrkConv = SolidFramework.Converters;
////using SolidFrkConvPlumb = SolidFramework.Converters.Plumbing;


//namespace QXP.Framework.Word
//{
//    /// <summary>
//    /// Description de PdfToWordConverter
//    /// </summary>
//    /// <author>cueffl</author>
//    /// <date>30/07/2009 11:33:38</date>    
//    public class PdfToWordConverter
//    {
//        #region Membres

//        private static PdfToWordConverter _current;
//        private bool _detectTables = true;
//        private bool _ignoreHeaderAndFooter = false;
//        private bool _removeHeaderAndFooter = false;
//        private string _pageRange = string.Empty;
//        private bool _autoRotate = true;
//        private OutputType _formatDeSortie = OutputType.WORD;
//        private ImageAncrageType _imageAncrageType = ImageAncrageType.Automatic;
//        private TypeDeReconstruction _typeDeReconstruction = TypeDeReconstruction.Suivi_En_Page;
//        private Resources.LangueTravail _langueDeTravail;
        
//        #endregion Membres

//        #region Constantes

//        #endregion Constantes

//        #region Enums

//        /// <summary>
//        /// Type de reconstruction possible
//        /// </summary>
//        public enum TypeDeReconstruction
//        {
//            /// <summary>
//            /// R�cup�ration de la mise en page, des colonnes, du formatage et des graphiques, et conservation du flux du texte
//            /// </summary>
//            Suivi_En_Page = 0,
//            /// <summary>
//            /// R�cup�ration de la page v�ritable au moyen de bo�tes de textes dans Microsoft Word
//            /// </summary>
//            Page_Veritable = 1,
//            /*Pas interressant*/
//            Continuous = 2,
//            Plaintext = 3,
//            /*Pas interressant*/
//        }

//        /// <summary>
//        /// Format de sortie possible
//        /// </summary>
//        public enum OutputType
//        {
//            RTF = 1,
//            WORD = 3
//        }

//        /// <summary>
//        /// Type d'ancrage des images
//        /// </summary>
//        public enum ImageAncrageType
//        {
//            NoImage = 3,
//            Automatic = 0
//        }

//        #endregion Enums

//        #region Constructeur

//        /// <summary>
//        /// Cr�e une instance de PdfToWordConverter
//        /// </summary>
//        private PdfToWordConverter()
//        {
//        }

//        #endregion Constructeur

//        #region M�thodes

//        /// <summary>
//        /// Active la licence Solid FrameWork
//        /// </summary>
//        /// <param name="licenseName">Licence Name</param>
//        /// <param name="licenseEmail">Licence Email</param>
//        /// <param name="licenseOrganization">Licence Organization</param>
//        /// <param name="licenseCode">Licence Code</param>
//        public static void ActivateLicence(string licenseName, string licenseEmail, string licenseOrganization, string licenseCode)
//        {
//            SolidFrk.LicenseCollection.Instance.Clear();
//            SolidFrk.License.Import(licenseName, licenseEmail, licenseOrganization, licenseCode, "NOCALL");            
//        }

//        /// <summary>
//        /// Converti un document SolidFrameWork (issu d'un pdf) en document word. Le document est renvoy� sous forme de MemoryStream.
//        /// </summary>
//        /// <param name="document">Document SolidFrameWork</param>
//        /// <returns>Le contenu du document word g�n�r�</returns>
//        public MemoryStream ConvertPdfToWord(SolidFrk.Plumbing.Document document)
//        {
//            string __wordFileName = null;
//            MemoryStream __wordFile = null;
//            //On v�rifie si la licence est valide
//            if (this.LicenceIsActive)
//            {
//                using(SolidFrk.Converters.PdfToWordConverter __pdfToWordConverter = this.GetConverter())
//                {
//                    //Ajout du document source � convertir
//                    __pdfToWordConverter.AddSourceFile(document);
//                    __pdfToWordConverter.Convert();                    
        
//                    if (        __pdfToWordConverter.Results.Count == 1 
//                            && (__pdfToWordConverter.Results[0].Status == SolidFrkConv.Plumbing.ConversionStatus.Success) 
//                            &&	(__pdfToWordConverter.Results[0].Paths.Count == 1)
//                       )	
//                    {
//                        //R�cup�ration du path pour acc�der au fichier (pour info SolidFramework stocke tous les fichiers dans les local setting du user de la session windows en cours...)
//                        __wordFileName = __pdfToWordConverter.Results[0].Paths[0];
//                        __wordFile = new MemoryStream(File.ReadAllBytes(__wordFileName));                        
//                        //On supprime le fichier word apr�s avoir r�cup�r� son contenu sous forme de stream
//                        File.Delete(__wordFileName);
//                    }
//                    else
//                    {
//                        throw new Exception("Erreur lors de la convertion du fichier pdf en fichier word");
//                    }                    
//                }
//                //Cette action est normalement accomplie par le dispose du PdfToWordConverter, finalement ce n est pas tjs le cas donc on force la suppression
//                //du document pdf stock� temporairement lors de l'instanciation de l'objet Document
//                if(File.Exists(document.Path))
//                    File.Delete(document.Path);
//            }
//            else
//                throw new Exception("La licence SolidFrameWork n'a pas �t� activ�e, appeler la m�thode ActivateLicence pour l'activer.");

//            return __wordFile;
//        }


//        /// <summary>
//        /// Converti un Stream (issu d'un pdf) en document word. Le document est renvoy� sous forme de MemoryStream.
//        /// </summary>
//        /// <param name="pdfFile">Contenu d'un fichier pdf</param>
//        /// <returns>Le contenu du document word g�n�r�</returns>
//        public MemoryStream ConvertPdfToWord(Stream pdfFile)
//        {
//            MemoryStream __wordFile = null;
//            SolidFrk.Pdf.PdfDocument __pdfDocument = new SolidFrk.Pdf.PdfDocument(pdfFile);
//            __wordFile = ConvertPdfToWord(__pdfDocument);
//            return __wordFile;
//        }

//        /// <summary>
//        /// Converti un tableau de byte (issu du contenu d'un fichier pdf) en document word. Le document est renvoy� sous forme de MemoryStream.
//        /// </summary>
//        /// <param name="pdfFile">Contenu d'un fichier pdf</param>
//        /// <returns>Le contenu du document word g�n�r�</returns>
//        public MemoryStream ConvertPdfToWord(Byte[] pdfFile)
//        {
//            MemoryStream __pdfStream = new MemoryStream();
//            __pdfStream.Write(pdfFile, 0, pdfFile.Length);
//            __pdfStream.Position = 0;
//            return ConvertPdfToWord(__pdfStream);
//        }

//        /// <summary>
//        /// Converti un fichier pdf en document word. Le document est renvoy� sous forme de MemoryStream.
//        /// </summary>
//        /// <param name="pdfFileName">Chemin du fichier PDF</param>
//        /// <returns>Le contenu du document word g�n�r�</returns>
//        public MemoryStream ConvertPdfToWord(string pdfFileName)
//        {
//            return ConvertPdfToWord(new SolidFrk.Pdf.PdfDocument(pdfFileName));
//        }

//        /// <summary>
//        /// Instancie le PdfToWordConverter et initialise les param�tres de conversion
//        /// </summary>
//        /// <returns>Un PdfToWordConverter</returns>
//        private SolidFrk.Converters.PdfToWordConverter GetConverter()
//        {
//            SolidFrk.Converters.PdfToWordConverter __pdfToWordConverter = new SolidFrk.Converters.PdfToWordConverter();

//            __pdfToWordConverter.HeaderAndFooterMode = this.HeaderAndFooterMode;
//            __pdfToWordConverter.DetectTables = this.DetectTables;
//            __pdfToWordConverter.ReconstructionMode = this.ReconstructionMode;
//            __pdfToWordConverter.ImageAnchoringMode = this.ImageAnchoringMode;
//            __pdfToWordConverter.AutoRotate = this.AutoRotate;

//            //Plus d'infos sur : http://www.soliddocuments.com/fr/frameworksample.htm?subject=ConvertToHtml
//            //TextRecovery = Always (te permettra de convertir toutes les pages).
//            __pdfToWordConverter.TextRecoveryType=SolidFrk.Converters.Plumbing.TextRecovery.Always;
//            //TextRecoveryNSE = Never (ne pas tenir compte des caract�res avec un encodage sp�cial).
//            __pdfToWordConverter.TextRecoveryNseType = SolidFrk.Converters.Plumbing.TextRecoveryNSE.Never;


//            #region PageRange

//            SolidFrk.PageRange __pageRange = null;
//            SolidFrk.PageRange.TryParse(this.PageRange, out __pageRange);
//            if(Validation.IsNotNull(__pageRange))
//                __pdfToWordConverter.PageRange = __pageRange;

//            #endregion PageRange

//            __pdfToWordConverter.OutputType= this.WordDocumentType;
//            __pdfToWordConverter.OverwriteMode = SolidFrk.Plumbing.OverwriteMode.ForceOverwrite;

//            return __pdfToWordConverter;

//        }

//        #endregion M�thodes

//        #region Propri�t�s

//        /// <summary>
//        /// Singleton assurant l'unicit� du PdfToWordConverter
//        /// </summary>
//	    public static PdfToWordConverter Current
//	    {
//            get 
//            {
//                if(_current == null)
//                {
//                    _current = new PdfToWordConverter();                    
//                }

//                return _current;

//            }
//	    }

//        /// <summary>
//        /// Indique si les tableaux contenus dans le document PDF seront d�tect�s et converti en tableau Word lors de la conversion
//        /// </summary>
//        public bool DetectTables
//        {
//            get { return _detectTables; }
//            set { _detectTables = value; }
//        }

//        /// <summary>
//        /// Indique si la licence a �t� activ�e ou non.
//        /// </summary>
//        public bool LicenceIsActive
//        {
//            get
//            {
//                return SolidFrk.LicenseCollection.Instance.ProfessionalOk();
//            }
//        }

//        /// <summary>
//        /// Indique si les entetes et pieds de pages doivent �tre ignor�s lors de la conversion (prioritaire devant RemoveHeaderAndFooter)
//        /// </summary>
//        public bool IgnoreHeaderAndFooter
//        {
//            get { return _ignoreHeaderAndFooter; }
//            set { _ignoreHeaderAndFooter = value; }
//        }

//        /// <summary>
//        /// Indique si les entetes et pieds de pages doivent �tre supprim�es lors de la conversion
//        /// </summary>
//        public bool RemoveHeaderAndFooter
//        {
//            get { return _removeHeaderAndFooter; }
//            set { _removeHeaderAndFooter = value; }
//        }

//        /// <summary>
//        /// Param�trage des entetes et pieds de page � suivre lors de la conversion
//        /// </summary>
//        private SolidFrkConvPlumb.HeaderAndFooterMode HeaderAndFooterMode
//        {
//            get 
//            {
//                if (_ignoreHeaderAndFooter)
//                {
//                    return SolidFrkConvPlumb.HeaderAndFooterMode.Ignore;
//                }
//                else if (_removeHeaderAndFooter)
//                {
//                    return SolidFrkConvPlumb.HeaderAndFooterMode.Remove;
//                }
//                else
//                    return SolidFrkConvPlumb.HeaderAndFooterMode.Detect;
//            }
//        }

//        /// <summary>
//        /// Retourne le mode de reconstruction de la page lors de la conversion
//        /// </summary>
//        private SolidFrkConvPlumb.ReconstructionMode ReconstructionMode
//        {
//            get{ return Conversion.ToEnum<SolidFrkConvPlumb.ReconstructionMode>((int)this._typeDeReconstruction); }
//        }

//        /// <summary>
//        /// D�finit le mode reconstruction
//        /// Valeur possible : 
//        ///     - Suivi_En_Page: R�cup�ration de la mise en page, des colonnes, du formatage et des graphiques, et conservation du flux du texte
//        ///     - Page_Veritable ; R�cup�ration de la page v�ritable au moyen de bo�tes de textes dans Microsoft Word
//        /// </summary>
//        public TypeDeReconstruction Reconstruction
//        {
//          get { return _typeDeReconstruction; }
//          set { _typeDeReconstruction = value; }
//        }
        
//        /// <summary>
//        /// Optionnel, d�finit la plage de pages � convertir, se d�finit sous la forme :
//        /// Num�ro page de d�but - Num�ro page de fin
//        /// ex : 1-5
//        /// </summary>
//        public string PageRange
//        {
//          get { return _pageRange; }
//          set { _pageRange = value; }
//        }

//        /// <summary>
//        /// Format de sortie (RTF ou Word)
//        /// </summary>
//        public OutputType FormatDeSortie
//        {
//          get { return _formatDeSortie; }
//          set { _formatDeSortie = value; }
//        }
        
//        /// <summary>
//        /// Format de sortie utilis� lors de la conversion
//        /// </summary>
//        private SolidFrkConvPlumb.WordDocumentType WordDocumentType
//        {
//            get{ return Conversion.ToEnum<SolidFrkConvPlumb.WordDocumentType>((int)this._formatDeSortie); }
//        }

//        /// <summary>
//        /// Type de r�cup�ration des images
//        /// </summary>
//        public ImageAncrageType ImageAncrage
//        {
//          get { return _imageAncrageType; }
//          set { _imageAncrageType = value; }
//        }

//        /// <summary>
//        /// R�cup�ration des images utilis� lors de la conversion
//        /// </summary>
//        private SolidFrkConvPlumb.ImageAnchoringMode ImageAnchoringMode
//        {
//            get{ return Conversion.ToEnum<SolidFrkConvPlumb.ImageAnchoringMode>((int)this._imageAncrageType); }
//        }

//        /// <summary>
//        /// Rotation automatique des pages selon l'orientation du texte utilis� lors de la conversion
//        /// </summary>
//        public bool AutoRotate
//        {
//          get { return _autoRotate; }
//          set { _autoRotate = value; }
//        }

//        /// <summary>
//        /// Langue de travail du document
//        /// </summary>
//        public Resources.LangueTravail LangueDeTravail
//        {
//            get { return _langueDeTravail; }
//            set { _langueDeTravail = value; }
//        }

//        #endregion Propri�t�s
//    }
//}
