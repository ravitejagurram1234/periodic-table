using System;
using System.Collections;
using System.Collections.Generic;

namespace QXP.Framework
{
	public class Profondeur{
		//si la profondeur n'est pas d�finit ont prend 1 jour
		DateTime _date_initiale	= DateTime.Today.AddDays(-1);
		DateTime _date_finale	= DateTime.Today;
		public Profondeur(object value){
			if(Validation.IsNotSet(value))	return;
			if(value is int)				this.Initialise((int)value);
			if(value is DateTime)			this.Initialise((DateTime)value);
		}
		public Profondeur(DateTime pi, DateTime pf){
			this.Initialise(pi, pf);
		}
		private void Initialise(DateTime pi, DateTime pf){
			if(Validation.IsSet(pi)){
				_date_initiale	= pi;
			}
			if(Validation.IsSet(pf)){
				_date_finale	= pf;
			}
		}
		private void Initialise(DateTime date_profondeur){
			_date_initiale = _date_finale = date_profondeur;
		}
		private void Initialise(int int_profondeur){
			//Cas ou la profondeur n'existe pas dans enum !!
			if(!Enum.IsDefined(typeof(Profondeurs), int_profondeur)){
				int __nbJour = int_profondeur;
				_date_initiale	= _date_finale.AddDays(-__nbJour);
				return;
			}
			Profondeurs	__profondeur	= (Profondeurs)int_profondeur;
			DateTime					__today			= DateTime.Today;
			switch(__profondeur){
				case Profondeurs.SC:	//semaine courante
					_date_initiale	= DateHelper.GetStartWeekDate(__today);
					//_date_finale	= __today;
					break;
				case Profondeurs.SP:	//semaine pr�cedente
					_date_initiale	= DateHelper.GetStartPreviousWeekDate(__today);
					_date_finale	= DateHelper.GetEndPreviousWeekDate(__today);
					break;
				case Profondeurs.MC:	//mois courante
					_date_initiale	= DateHelper.GetStartMonthDate(__today);
					//_date_finale	= __today;
					break;
				case Profondeurs.MP:	//mois pr�c�dent
					_date_initiale	= DateHelper.GetStartPreviousMonthDate(__today);
					_date_finale	= DateHelper.GetEndPreviousMonthDate(__today);
					break;
				default: //ce sont des jours !
					int __nbJour = (int)__profondeur; //je fais expres de tester __profondeur mais non int_profondeur (ceci pour �tre sur que la valeur est contenu dans enum).
					_date_initiale	= _date_finale.AddDays(-__nbJour);
					//_date_finale	= __today;
					break;
			}		
		}
		public DateTime Initiale{
			get{return _date_initiale;}
		}
		public DateTime Finale{
			get{return _date_finale;}
		}
	}
}
