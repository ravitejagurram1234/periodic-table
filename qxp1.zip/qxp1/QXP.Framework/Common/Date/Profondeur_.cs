using System;
using System.Collections;
using System.Globalization;
using System.Text;
using System.Web.UI.WebControls;


namespace QXP.Framework
{
	public enum Profondeurs{
		d_1		= 1,
		d_7		= 7,
		d_14	= 14,
		d_30	= 30,
		d_90	= 90,
		d_365	= 365,
		//definit les semaines
		SC		= 10000,
		SP		= 10001,
		//definit les mois
		MC		= 20000,
		MP		= 20001,
	}	
}
