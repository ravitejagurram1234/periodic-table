using System;
using System.Collections;
using System.Globalization;
using System.Text;
using System.Web.UI.WebControls;


namespace QXP.Framework
{
	public class DateHelper
	{
		const int NbDaysByWeek = 7;

		#region Common
		//R�-�criture de la fonction permettant de connaitre le jour de la semaine
		//en effet dans le calendrier gr�gorien le premier jour de la semaine est Dimanche et le dernier samedi
		//cependant en france qui se base pourtant sur le calendrier gr�gorien les semaines commence le lundi !!
		//nous voulons des semaines du lundi-au dimanche donc on ne peut pas utiliser les fonctions "CultureInfo.CurrentCulture.Calendar.GetDayOfWeek"...
		public static int GetDayOfWeek(DateTime date){
			int __dayofweek = ((int) ((date.Ticks / 0xc92a69c000L))) % 7;
			return __dayofweek;
		}
		#endregion
		#region Semaine
		#region Semaine en cours
		//debut semaine en cours
		public static DateTime GetStartWeekDate(){
			return GetStartWeekDate(DateTime.Today);
		}
		//debut semaine de la fromDate
		public static DateTime GetStartWeekDate(DateTime fromDate){
			if(Validation.IsNotSet(fromDate)) return fromDate;
			//on soustrait de la date encours le jour de la semaine (ce qui nous am�ne � lundi)
			return fromDate.AddDays(-GetDayOfWeek(fromDate));
		}

		//date fin de semaine en cours
		public static DateTime GetEndWeekDate(){
			return GetEndWeekDate(DateTime.Today);
		}
		//date fin de semaine de la fromDate
		public static DateTime GetEndWeekDate(DateTime fromDate){
			if(Validation.IsNotSet(fromDate)) return fromDate;
			//on soustrait de la date encours le jour de la semaine (ce qui nous am�ne en th�orie � dimanche) et ont ajoute 7 (1+6) jour pour arriv�e vendredi !
			return fromDate.AddDays(-GetDayOfWeek(fromDate) + 6);
		}
		#endregion

		#region Semaine pr�c�dente
		//debut semaine pr�cedente
		public static DateTime GetStartPreviousWeekDate(){
			return GetStartPreviousWeekDate(DateTime.Today);
		}
		//debut semaine pr�c�dente � fromDate
		public static DateTime GetStartPreviousWeekDate(DateTime fromDate){
			if(Validation.IsNotSet(fromDate)) return fromDate;
			//on change de semaine en plus !
			return GetStartWeekDate(fromDate.AddDays(-NbDaysByWeek));
		}

		//date fin de semaine pr�c�dente
		public static DateTime GetEndPreviousWeekDate(){
			return GetEndPreviousWeekDate(DateTime.Today);
		}
		//date fin de semaine pr�c�dente de la fromDate
		public static DateTime GetEndPreviousWeekDate(DateTime fromDate){
			if(Validation.IsNotSet(fromDate)) return fromDate;
			//on change de semaine en plus !
			return GetEndWeekDate(fromDate.AddDays(-NbDaysByWeek));
		}
		#endregion
		#endregion
		#region Mois
		#region Mois en cours
		//debut mois en cours
		public static DateTime GetStartMonthDate(){
			return GetStartMonthDate(DateTime.Today);
		}
		//debut mois de la fromDate
		public static DateTime GetStartMonthDate(DateTime fromDate){
			if(Validation.IsNotSet(fromDate)) return fromDate;
			//on soustrait de la date encours le jour du mois (ce qui nous am�ne en th�orie au premier)
			return fromDate.AddDays(-(int)CultureInfo.CurrentCulture.Calendar.GetDayOfMonth(fromDate)+1);
		}

		//date fin de mois en cours
		public static DateTime GetEndMonthDate(){
			return GetEndMonthDate(DateTime.Today);
		}
		//date fin de mois de la fromDate
		public static DateTime GetEndMonthDate(DateTime fromDate){
			if(Validation.IsNotSet(fromDate)) return fromDate;
			//date d�but mois
			DateTime __debutMois = GetStartMonthDate(fromDate);
			// on ajoute 1 mois et ont supprime 1 jour !!
			return __debutMois.AddMonths(1).AddDays(-1); 
		}

		#endregion

		#region Mois pr�c�dent
		//debut mois pr�c�dent en cours
		public static DateTime GetStartPreviousMonthDate(){
			return GetStartPreviousMonthDate(DateTime.Today);
		}
		//debut mois pr�c�dent de la fromDate
		public static DateTime GetStartPreviousMonthDate(DateTime fromDate){
			if(Validation.IsNotSet(fromDate)) return fromDate;
			DateTime __debutMois = GetStartMonthDate(fromDate);
			return __debutMois.AddMonths(-1);
		}

		//date fin de mois pr�c�dent en cours
		public static DateTime GetEndPreviousMonthDate(){
			return GetEndPreviousMonthDate(DateTime.Today);
		}
		//date fin de mois pr�c�dent de la fromDate
		public static DateTime GetEndPreviousMonthDate(DateTime fromDate){
			if(Validation.IsNotSet(fromDate)) return fromDate;
			DateTime __debutMois = GetStartMonthDate(fromDate);
			return	__debutMois.AddDays(-1);
		}
		#endregion
		#endregion
	}
}
