using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;



namespace QXP.Framework
{
	public class Profondeur_Helper{
		public static OrderedDictionary GetListeProfondeur(){
			return EnumHelper.GetOrderedKeysValues_Localized(typeof(Profondeurs), "Profondeurs");
		}
		public static OrderedDictionary GetListeProfondeur(Profondeurs[] enums){
			ArrayList __enums = new ArrayList(enums);
			return EnumHelper.GetOrderedKeysValues_Localized((Enum[])__enums.ToArray(typeof(Enum)), "Profondeurs");
		}
	}
}
