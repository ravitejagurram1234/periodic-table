using System;
using System.Collections;
using System.Reflection;

namespace QXP.Framework.Reflection {
    public class Reflection
    {
        /// <summary>
        /// Permet de retrouver le type des elements dans une collection.
		/// fonctionne sur les types g�n�rics (le premier type), les arrays, les listes qui impl�mentes IList (il faut que la liste poss�de au moins un �l�ments)
        /// </summary>
        /// <param name="obj">la collection � tester</param>
        /// <returns></returns>
		public static Type GetElemenType(object obj){
            if(Validation.IsNull(obj)) return null;
            Type __type         = obj.GetType();

            Type __elementType   = null;
            if(__type.IsGenericType){
                __elementType = __type.GetGenericArguments()[0];
            }else{
                if(__type.IsArray){
                    __elementType = __type.GetElementType();
                }else if (obj is IList){
                    IList __iList = (IList)obj;
                    if(__iList.Count > 0){
                        __elementType = __iList[0].GetType();
                    }
                }
            }
            if(Validation.IsNull(__type)) throw new ArgumentException("Not valide collection type !");
            return __elementType;
        }

		/// <summary>
		/// Permet de retrouver le System.Type � activer en fonction d'un objet (classe ou membre de classe).
		/// L'�l�ment doit avoir un attribut ActivationTypeAttribute sinon il y aura une erreur
		/// </summary>
		/// <param name="val">membre, valeur ou classe duquel il faut retrouver le type � activer.</param>
		/// <returns></returns>
		public static Type FromActivationType(object val)
		{
			Type		__type			= val.GetType();
			object[]	__attributes	= __type.GetCustomAttributes(typeof(ActivationTypeAttribute), false);
			if (__attributes.Length > 0)
			{
				//Il ne peut y avoir qu'un seul attribut de ce type par val.
				return ((ActivationTypeAttribute)__attributes[0]).ActivationType;
			}
			
			throw new ArgumentException(string.Format("le type '{0}' ne contient pas d'attribute d'activation de type", __type));
		}

		/// <summary>
		/// Permet de retrouver le System.Type � activer en fonction d'un objet (classe ou membre de classe).
		/// L'�l�ment doit avoir un attribut ActivationTypeAttribute sinon il y aura une erreur
		/// </summary>
		/// <param name="val">l'enum duquel il faut retrouver le type � activer.</param>
		/// <returns></returns>
		public static Type FromActivationType(Enum val)
		{
			Type		__enumType			= val.GetType();
			FieldInfo	__field				= __enumType.GetField(val.ToString());

			object[]	__attributes	= __field.GetCustomAttributes(typeof(ActivationTypeAttribute), false);
			if (__attributes.Length > 0)
			{
				//Il ne peut y avoir qu'un seul attribut de ce type par val.
				return ((ActivationTypeAttribute)__attributes[0]).ActivationType;
			}
			
			throw new ArgumentException(string.Format("le type '{0}' ne contient pas d'attribute d'activation de type", __enumType));
		}

    }
}
