using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;


/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Reflection
{
	/// <summary>
	/// Permet de d�finir un System.Type associ� � un membre ou � une classe 
	/// Ce syst�me type pourra �tre utilis� de diverse mani�re pour instancier une classe par exemple 
	/// </summary>
	[AttributeUsage(AttributeTargets.All, AllowMultiple=false)]
	public class ActivationTypeAttribute : Attribute
	{
		#region Membres
		Type _activationType;
        #endregion Membres
        
		#region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums
		
        #region Constructeur

		public ActivationTypeAttribute(Type activationType)
		{
			_activationType = activationType;
		}

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s
		
		/// <summary>
		/// System.Type associ� � d'activation
		/// </summary>
		public Type ActivationType
		{
			get{return _activationType;}
		}
 
        #endregion Propri�t�s		
	}	
}
