using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace QXP.Framework.Reflection
{
    public class CDeepCloner : ICloneable
    {
        public static object Clone(object vObj)
        {
            if (vObj.GetType().IsValueType || vObj.GetType() == Type.GetType("System.String"))
                return vObj;
            else
            {
                object newObject = Activator.CreateInstance(vObj.GetType());

                //foreach (PropertyInfo Item in newObject.GetType().GetProperties())
                //{
                //    if (Item.GetType().GetInterface("ICloneable") != null)
                //    {
                //        ICloneable IClone = (ICloneable)Item.GetValue(vObj, null);
                //        Item.SetValue(newObject, IClone.Clone(), null);
                //    }
                //    else
                //    {
                       
                //        Item.SetValue(newObject, Clone(Item.GetValue(vObj, null)), null);
                //    }
                //}

                foreach (FieldInfo Item in newObject.GetType().GetFields(BindingFlags.NonPublic|BindingFlags.Public|BindingFlags.Instance))
                {
                    object __obj = Item.GetValue(vObj);

                    if (__obj is ICloneable)
                    {
                        Item.SetValue(newObject, ((ICloneable)__obj).Clone());
                    }
                    else 
                    {
                        Item.SetValue(newObject, Clone(Item.GetValue(vObj)));
                    }

                    //if (Item is ICloneable) //.GetType().GetInterface("ICloneable") != null)
                    //{
                    //    ICloneable IClone = (ICloneable)Item.GetValue(vObj);
                    //    Item.SetValue(newObject, IClone.Clone());
                    //}
                    //else
                    //    Item.SetValue(newObject, Clone(Item.GetValue(vObj)));
                }
                return newObject;
            }
        }

        public object Clone()
        {
            return Clone(this);
        }
    }

}
