using System;
using System.IO;

namespace QXP.Framework.IO
{
	/// <summary>Contains available DatedFileWriter periodicity. </summary>
	public enum		Periodicity
	{
		/// <summary>Represents a hourly periodicity. </summary>
		Hour,
		/// <summary>Represents a Daily periodicity.</summary>
		Day,
		/// <summary>Represents a Weekly periodicity.</summary>
		Week,
	}

}
