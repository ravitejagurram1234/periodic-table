using System;
using System.IO;
using System.Collections.Generic;
using System.Text;


namespace QXP.Framework.IO
{
    /// <summary>
    /// Permet de stocker un flux binaire (stream, bytes ou string) et de le transformer en un autre flux binaire (stream, bytes ou string)
    /// </summary>
    /// <author>doufarm</author>
    /// <date>16/03/2010 10:56:30</date>    
    public class IOValue
    {
        #region Membres
        Stream	_stream	= null;
        byte[]	_bytes	= null;
        string	_string = null;
        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de IOValue � partir d'un stream
        /// </summary>
        /// <param name="value">l'objet stream de la source originale</param>
        public IOValue(Stream value){
            _stream = value;
        }
		
        /// <summary>
        /// Cr�e une instance de IOValue � partir d'une collection de byte
        /// </summary>
        /// <param name="value">la collection de bytes de la source originale</param>
        public IOValue(byte[] value){
            _bytes = value;
        }
		
        /// <summary>
        /// Cr�e une instance de IOValue � partir d'un string
        /// </summary>
        /// <param name="value">la chaine originale</param>
        public IOValue(string value){
            _string = value;
        }

        #endregion Constructeur

        #region M�thodes
        #region Conversion explicite en Bytes
		
        /// <summary>
        /// Conversion de la source de donn�e originale en array de byte
        /// </summary>
        /// <returns>array de byte</returns>
        public byte[]	To_Bytes(){
            byte[] __bytes = _bytes;
            if(Validation.IsNull(__bytes)){
                __bytes = Evaluate_Bytes();
            }
            return __bytes;
        }
        byte[]			Evaluate_Bytes(){
            byte[] __bytes = null;
            if(Validation.IsNotNull(_stream)){
                _stream.Seek(0, SeekOrigin.Begin);
                __bytes = new byte[_stream.Length];
                _stream.Read(__bytes, 0, __bytes.Length);                
            }else if(Validation.IsNotNull(_string)){
                __bytes = Encoding.UTF8.GetBytes(_string);
            }else{
                __bytes = new byte[0];
            }
            return __bytes;
        }
        #endregion
        #region Conversion explicite en Stream

        /// <summary>
        /// Conversion de la source de donn�e originale en stream
        /// </summary>
        /// <returns>Stream </returns>
        public	Stream	To_Stream(){
			
            Stream __stream = _stream;
            if(Validation.IsNull(__stream)){
                __stream = Evaluate_Stream();
            }
            __stream.Seek(0, SeekOrigin.Begin);
            return __stream;
        }
        Stream			Evaluate_Stream(){
            if(Validation.IsSet(_bytes)){
                return new MemoryStream(_bytes);
            }else{
                return new MemoryStream();
            }
        }
        #endregion
        #region Conversion explicite en String
        /// <summary>
        /// Conversion de la source de donn�e originale en string
        /// </summary>
        /// <returns>array de byte</returns>
        public	string	To_String(){
			
            string __string = _string;
            if(Validation.IsNull(__string)){
                __string = Evaluate_String();
            }
            return __string;
        }
        string			Evaluate_String(){
            if(Validation.IsNotNull(_stream)){
                //A tester
                return new StreamReader(_stream, Encoding.UTF8).ReadToEnd();
            }else if(Validation.IsNotNull(_bytes)){
                MemoryStream __stream = new MemoryStream(_bytes);
                StreamReader __reader = new StreamReader(__stream);
                return __reader.ReadToEnd();
            }else{
                return string.Empty;
            }
        }
        #endregion
		
        #region operateur implicites
        /// <summary>Allows implicit <see cref="IOValue"/> to <see cref="byte"/> array. </summary>
        /// <param name="byteStream">The <see cref="ioValue"/> to cast. </param>
        /// <returns>The <see cref="byte"/> array value. </returns>
        public	static implicit	operator	byte[](IOValue ioValue)
        {
            return ioValue.To_Bytes();
        }
		
        /// <summary>Allows implicit <see cref="IOValue"/> to <see cref="Stream"/> casting. </summary>
        /// <param name="byteStream">The <see cref="ioValue"/> to cast. </param>
        /// <returns>The <see cref="byte"/> array value. </returns>
        public	static implicit	operator	Stream(IOValue ioValue)
        {
            return ioValue.To_Stream();
        }
        /// <summary>Allows implicit <see cref="IOValue"/> to <see cref="String"/> casting. </summary>
        /// <param name="byteStream">The <see cref="ioValue"/> to cast. </param>
        /// <returns>The <see cref="byte"/> array value. </returns>
        public	static implicit	operator	string(IOValue ioValue)
        {
            return ioValue.To_String();
        }

        #endregion

        #endregion M�thodes

        #region Propri�t�s
        /// <summary>
        /// IOValue contient-t-il bien un flux de donn�e ?
        /// </summary>
        public bool IsSet{
            get{return Validation.IsNotNull(_bytes)
                || Validation.IsNotNull(_stream)
                || Validation.IsSet(_string);
            }
        }
        #endregion Propri�t�s
    }
}
