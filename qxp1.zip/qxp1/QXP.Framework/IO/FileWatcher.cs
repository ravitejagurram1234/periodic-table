using System;
using System.Collections;
using System.IO;
using System.Threading;

namespace QXP.Framework.IO
{
	/// <summary>Represents the method that will handle file modification event. </summary>
	public delegate void	FileChangeEventHandler(FileSystemWatcher sender, FileChangeEventArg fcea);
	
	/// <summary>Provides methods to monitor file change notification. </summary>
	public class	FileSystemWatcher: IDisposable
	{
		#region internal variables
		private Hashtable						_lastChanged						= new Hashtable();
		private Timer							_timer;
		private System.IO.FileSystemWatcher		_watcher;
		private string							_name;
		private object[]						_args								= new object[0];
		private int								_clearInterval						= 60000; //INFO: 60 seconds
		private WatcherChangeTypes				_watchChangeTypes					= WatcherChangeTypes.All;
		private const double					DefaultBounceChangeInterval	= 1000; //INFO: 1 second between change events.
		private double							_bounceChangeInterval				= DefaultBounceChangeInterval;
		#endregion
		/// <summary>Occurs when change notification occurs. </summary>
		public	event			FileChangeEventHandler		FileChange;
		/// <summary>Creates a new instance of <see cref="FileSystemWatcher"/> class that monitor the fullPath and hold some extra informations (<paramref name="args"/>). </summary>
		/// <param name="name">the <see cref="string"/> name of the current instance. </param>
		/// <param name="fullPath">The full path to monitor.</param>
		/// <param name="args">optional, some extra informations linked to this watcher. </param>
		public	FileSystemWatcher(string name, string fullPath, params object[] args): this(name, WatcherChangeTypes.All, fullPath, args){}
		/// <summary>Creates a new instance of <see cref="FileSystemWatcher"/> class that monitor the fullPath and hold some extra informations (<paramref name="args"/>). </summary>
		/// <param name="name">the <see cref="string"/> name of the current instance. </param>
		/// <param name="changeTypes">The <see cref="WatcherChangeTypes"/> of the file change notification types. </param>
		/// <param name="fullPath">The full path to monitor.</param>
		/// <param name="args">optional, some extra informations linked to this watcher. </param>
		public	FileSystemWatcher(string name, WatcherChangeTypes changeTypes, string fullPath, params object[] args)
		{
			string __path = string.Empty;
			string __file = string.Empty;
			
			//INFO: log missing full path !!
			//INFO: log missing dependancy name !!
//			if(Validation.IsNotSet(fullPath))			throw new Exception(Constant.FileWatcherMissingFullPath);
//			if(Validation.IsNotSet(name))				throw new Exception(Constant.FileWatcherMissingName);
			_watchChangeTypes	= changeTypes;
			_name							= name;
			_args							= args;
			if(Path.HasExtension(fullPath))	__path	= Path.GetDirectoryName(fullPath);
			else							__path	= fullPath;
			if(!Directory.Exists(__path))
			{
				//INFO: log invalid __path
				return;
			}
			_timer						= new Timer(new TimerCallback(Clear), null, Timeout.Infinite, Timeout.Infinite);
			if(Path.HasExtension(fullPath)) __file	= Path.GetFileName(fullPath);
			if(Validation.IsNotSet(__file))	__file	= "*.*";
			_watcher = new System.IO.FileSystemWatcher();
			_watcher.Path										= __path;
			_watcher.Filter									= __file;
			_watcher.EnableRaisingEvents		= true;
			_watcher.IncludeSubdirectories	= false;
			_watcher.NotifyFilter						= NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName;

			if((WatcherChangeTypes.Changed & _watchChangeTypes) == WatcherChangeTypes.Changed) _watcher.Changed += new FileSystemEventHandler(OnChange);
			if((WatcherChangeTypes.Created & _watchChangeTypes) == WatcherChangeTypes.Created) _watcher.Created += new FileSystemEventHandler(OnChange);
			if((WatcherChangeTypes.Deleted & _watchChangeTypes) == WatcherChangeTypes.Deleted) _watcher.Deleted += new FileSystemEventHandler(OnChange);
			if((WatcherChangeTypes.Renamed & _watchChangeTypes) == WatcherChangeTypes.Renamed) _watcher.Renamed += new RenamedEventHandler(OnRename);
		}
		/// <summary>Retrieves the <see cref="WatcherChangeTypes"/> of the file change notification types. </summary>
		public	WatcherChangeTypes	WatchChangeTypes
		{
			get{return _watchChangeTypes;}
		}
		/// <summary>Gets some extra arguments or <see langword="null"/>. </summary>
		public	object[]			Args
		{
			get{return _args;}
			set{_args = value;}
		}
		/// <summary>Gets FileSystemWatcher name. </summary>
		public	string				Name
		{
			get{return _name;}
		}
		/// <summary>Gets or sets if the FileSystemWatcher is monitoring changes. </summary>
		public  bool				Enable
		{
			get{return _watcher.EnableRaisingEvents;}
			set{_watcher.EnableRaisingEvents = value;}
		}
		/// <summary>Gets or sets if the monitoring includes subdirectories, default is false. </summary>
		public	bool				IncludeSubdirectories
		{
			get{return _watcher.IncludeSubdirectories;}
			set{_watcher.IncludeSubdirectories = value;}
		}
		private void				Clear(object arg)
		{
			_timer.Change(Timeout.Infinite, Timeout.Infinite);
			_lastChanged.Clear();
		}
		#region IDisposable
		/// <summary>perform a proper client finalization. </summary>
		public void		Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}
		private void		Dispose(bool disposing)
		{
			try
			{
				if(disposing) _watcher.Dispose();
			}
			catch{}
		}
		/// <summary>Release all resource used by curretn client. </summary>
		~FileSystemWatcher()
		{
			try 
			{
				this.Dispose(false);
			}
			catch{}
		}
		#endregion
		/// <summary>Occurs when a file change notification occurs. </summary>
		/// <param name="sender">The <see cref="FileSystemWatcher"/> that notify this change. </param>
		/// <param name="oldFullPath">The old full file Name. </param>
		/// <param name="newFullPath">The new full file Name, can be the same as old if no rename notification occured. </param>
		/// <param name="changeType">The <see cref="WatcherChangeTypes"/> change type. </param>
		protected	virtual void	OnChanged(object sender, string oldFullPath, string newFullPath ,WatcherChangeTypes changeType)
		{
			_timer.Change(_clearInterval, Timeout.Infinite);
			if(Validation.IsNotNull(FileChange))	FileChange(this, new FileChangeEventArg(oldFullPath, newFullPath, changeType));
		}
		private void				InternalOnChange(string oldFullPath, string newFullPath, WatcherChangeTypes changeType)
		{
			string		__fullPath			= newFullPath;
			DateTime	__lastWrite			= DateTime.MinValue;
			DateTime	__currentWrite;
			bool			__changefile		= false;
			FileInfo	__info					= new FileInfo(__fullPath);
			__currentWrite = __info.LastWriteTime;

			if(_lastChanged.ContainsKey(__fullPath))
			{
				__lastWrite = (DateTime)_lastChanged[__fullPath];
			}
			if(changeType == WatcherChangeTypes.Changed)
			{
				if(Directory.Exists(newFullPath))
				{
					__changefile = false;
				}
				else
				{
					__changefile = __lastWrite < __currentWrite.AddMilliseconds(-_bounceChangeInterval);
				}
			}
			else
			{
				//TODO LOWEST Raised deleted event on sub files if directory is deleted.
				__changefile = __lastWrite != __currentWrite;
			}
			if(__changefile)
			{
				if(_lastChanged.ContainsKey(__fullPath))
				{
					_lastChanged[__fullPath] = __currentWrite;
				}
				else
				{
					_lastChanged.Add(__fullPath, __currentWrite);
				}
				OnChanged(this, oldFullPath, newFullPath, changeType);
			}
		}
		/// <summary>Gets or sets the interval in milliseconds for clearing changes buffer if not changes occured. default 60000 ms (60s). </summary>
		public	int					ClearInterval
		{
			get{return _clearInterval;}
			set{_clearInterval = value;}
		}
		/// <summary>Gets or sets the interval beetween change notification. </summary>
		/// <remarks>if multiple changes occured on the same file during this interval only one event will be fired. </remarks>
		public	double				BounceChangeInterval
		{
			get{return _bounceChangeInterval;}
			set{_bounceChangeInterval = value;}
		}
		private void				OnChange(object obj, FileSystemEventArgs fcea)
		{
			this.InternalOnChange(fcea.FullPath, fcea.FullPath, fcea.ChangeType);
		}
		private void				OnRename(object obj, RenamedEventArgs rea)
		{
			this.InternalOnChange(rea.OldFullPath, rea.FullPath, rea.ChangeType);
		}
	}

	/// <summary>Provides data for <see cref="FileChangeEventHandler"/>. actually no data will be generated. </summary>
	public class	FileChangeEventArg: EventArgs
	{
		#region internal variables
		private string							_oldFullPath;
		private string							_newFullPath;
		private WatcherChangeTypes	_changeType;
		#endregion
		/// <summary>Represents the empty <see cref="FileChangeEventArg"/>. </summary>
		public static new FileChangeEventArg Empty = new FileChangeEventArg(null, null, WatcherChangeTypes.All);
		/// <summary>Creates a new <see cref="FileChangeEventArg"/> with the specified <paramref name="oldFullPath"/>, <paramref name="newFullPath"/> and <paramref name="changeType"/>. </summary>
		/// <param name="oldFullPath">the string old fulle file name. </param>
		/// <param name="newFullPath">the string old fulle file name</param>
		/// <param name="changeType">the <see cref="WatcherChangeTypes"/> change type. </param>
		public FileChangeEventArg(string oldFullPath, string newFullPath, WatcherChangeTypes changeType)
		{
			_oldFullPath		= oldFullPath;
			_newFullPath		= newFullPath;
			_changeType			= changeType;
		}
		/// <summary>returns the <see cref="WatcherChangeTypes"/>change type. </summary>
		public WatcherChangeTypes	ChangeType
		{
			get{return _changeType;}
		}
		/// <summary>returns the old fulle file name. </summary>
		public string				OldFullPath
		{
			get{return _oldFullPath;}
		}
		/// <summary>returns the new full file name. </summary>
		public string				NewFullPath
		{
			get{return _newFullPath;}
		}
	}
}
