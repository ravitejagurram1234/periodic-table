using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

using iTextSharp.text;
using iTextSharp.text.pdf;

namespace QXP.Framework.IO{
	public class	PDF_Tools{
        const string SplittedFilePattern = "{0}_{1}.pdf";
        public static List<PDF_File> Split_PDF(string pdf_file_name){
            return Split_PDF(new PDF_File(pdf_file_name));
        }
        public static List<PDF_File> Split_PDF(PDF_File pdf_file){
            return Split_PDF(pdf_file, Split_Preference.Default);
        }
        public static List<PDF_File> Split_PDF(string pdf_file_name, Split_Preference preference){
            return Split_PDF(new PDF_File(pdf_file_name), preference);
        }
        //public static List<PDF_File> Split_PDF(PDF_File pdf_file, Split_Preference preference){
        //    List<PDF_File>  __pdfs      = new List<PDF_File>();
        //    PDF_File        __pdf       = null;
            
        //    PdfReader   __reader = null;
        //    try{
        //        __reader    = GetPDFReader(pdf_file);
        //    }catch(Exception ex){
        //        throw new Exception("Invalid source pdf / or file not found", ex);
        //    }
        //    if(Validation.IsNull(__reader)) return __pdfs;
            
        //    int         __numPages  = __reader.NumberOfPages;
        //    int         __minPage   = preference.StartPage + 1;
        //    if(__numPages < __minPage)  return __pdfs;
        //    string      __fileName  = Path.GetFileNameWithoutExtension(pdf_file.FileName);

        //    Document        __doc       = null;
        //    PdfWriter       __writer    = null;
        //    MemoryStream    __stream    = null;
        //    PdfContentByte  __cb        = null;
        //    PdfImportedPage __page      = null;
        //    int             __rotation  = int.MinValue;

        //    try{
        //        for(int __current_page = preference.StartPage ; __current_page <= __numPages; __current_page++)
        //        {
        //            //Ont v�rifie si l'utilisateur veux r�cup�rer que certaine page ! 
        //            if(preference.NeedPages.Count > 0 && !preference.NeedPages.Contains(__current_page)) continue;
                    
        //            __doc                   = new Document(__reader.GetPageSizeWithRotation(__current_page));
        //            __stream                = new MemoryStream();
        //            __writer                = PdfWriter.GetInstance(__doc, __stream);
        //            __writer.CloseStream    = false;

        //            __doc.Open();
        //            __cb = __writer.DirectContent;

        //            __doc.SetPageSize(__reader.GetPageSizeWithRotation(__current_page));
        //            __doc.NewPage();
        //            __page      = __writer.GetImportedPage(__reader, __current_page);
        //            __rotation  = __reader.GetPageRotation(__current_page);
        //            if (__rotation == 90 || __rotation == 270) 
        //            {
        //                __cb.AddTemplate(__page, 0, -1f, 1f, 0, 0, __reader.GetPageSizeWithRotation(__current_page).Height);
        //            }
        //            else 
        //            {
        //                __cb.AddTemplate(__page, 1f, 0, 0, 1f, 0, 0);
        //            }
        //            __doc.Close();

        //            __pdf = new PDF_File(string.Format(SplittedFilePattern, __fileName, __current_page), __stream);
                    
        //            __pdfs.Add(__pdf);
        //        }
        //    }catch(Exception ex){
        //        throw new Exception("error occured during split operation", ex); 
        //    }
            
        //    return __pdfs;
        //}
        public static List<PDF_File> Split_PDF(PDF_File pdf_file, Split_Preference preference){
            List<PDF_File>  __pdfs      = new List<PDF_File>();
            PDF_File        __pdf       = null;
            
            PdfReader   __reader = null;
            try{
                __reader    = GetPDFReader(pdf_file);
            }catch(Exception ex){
                throw new Exception("Invalid source pdf / or file not found", ex);
            }
            if(Validation.IsNull(__reader)) return __pdfs;
            
            int         __numPages  = __reader.NumberOfPages;
            if(__numPages < preference.StartPage)  return __pdfs;
            string      __fileName  = Path.GetFileNameWithoutExtension(pdf_file.FileName);

            Document        __doc       = null;
            PdfWriter       __writer    = null;
            MemoryStream    __stream    = null;
            PdfContentByte  __cb        = null;
            PdfImportedPage __page      = null;
            int             __rotation  = int.MinValue;
            int             __cp        = 1;
            int             __pageCount = 0;
            int             __offSet    = 0;
            int             __index;     

            try{
                for(int __current_page = preference.StartPage ; __current_page <= __numPages; __current_page++)
                {
                    __index                 = __current_page;
                    //Ont v�rifie si l'utilisateur veux r�cup�rer que certaine page ! 
                    if(preference.NeedPages.Count > 0 && !preference.NeedPages.Contains(__current_page)) continue;
                    __doc                   = new Document(__reader.GetPageSizeWithRotation(__current_page));
                    __stream                = new MemoryStream();
                    __writer                = PdfWriter.GetInstance(__doc, __stream);
                    __writer.CloseStream    = false;

                    __doc.Open();
                    __cb        = __writer.DirectContent;
                    __pageCount = 0;
                    __offSet    = 0;
                    while(preference.NbPages == 0 | __pageCount < preference.NbPages ){
                        __cp        = __current_page + __offSet++;
                        if(preference.NeedPages.Count > 0 && !preference.NeedPages.Contains(__cp)){
                            continue;
                        }
                        __doc.SetPageSize(__reader.GetPageSizeWithRotation(__cp));
                        __doc.NewPage();
                        __page      = __writer.GetImportedPage(__reader, __cp);
                        __rotation  = __reader.GetPageRotation(__cp);
                        if (__rotation == 90 || __rotation == 270) 
                        {
                            __cb.AddTemplate(__page, 0, -1f, 1f, 0, 0, __reader.GetPageSizeWithRotation(__cp).Height);
                        }
                        else 
                        {
                            __cb.AddTemplate(__page, 1f, 0, 0, 1f, 0, 0);
                        }
                        __pageCount++;
                        if(__cp >= __numPages) break;
                    }
                    __current_page = __cp;
                    __doc.Close();

                    __pdf = new PDF_File(string.Format(SplittedFilePattern, __fileName, __index), __stream);
                    
                    __pdfs.Add(__pdf);
                }
            }catch(Exception ex){
                throw new Exception("error occured during split operation", ex); 
            }
            
            return __pdfs;
        }
        static PdfReader             GetPDFReader(PDF_File pdf_file){
            PdfReader __reader = null;
            if(Validation.IsNotNull(pdf_file.Stream)){
                __reader = new PdfReader(pdf_file.Stream);
            }else if(Validation.IsSet(pdf_file.Bytes)){
                __reader = new PdfReader(pdf_file.Bytes);
            }else if(Validation.IsSet(pdf_file.FileName)){
                __reader = new PdfReader(pdf_file.FileName);
            }
            return __reader;
        }
    }
    public class    Split_Preference{
        public static Split_Preference Default = new Split_Preference();
        /// <summary>
        /// Page de d�marrage du split par d�faut 1 (Page 1)
        /// </summary>
        public int          StartPage = 1;
        /// <summary>
        /// Premet de d�finir une liste de numero de page � r�cup�rer
        /// </summary>
        public List<int>    NeedPages = new List<int>();
        /// <summary>
        /// Premet de d�finir le nombre de page par split (def = 1) si 0 alors toutes les pages/needPages sont r�cup�r�es.
        /// </summary>
        public int          NbPages     = 1;
    }
    public class    PDF_File{
        string  _fileName   = "Document.pdf";
        Stream  _stream     = null;
        byte[]  _bytes      = new byte[0];
        public PDF_File(string fileName){
            _fileName  = fileName;
        }
        public PDF_File(string fileName, Stream stream){
            _fileName  = fileName;
            _stream     = stream;
            _stream.Seek(0, SeekOrigin.Begin); 
        }
        public PDF_File(string fileName, byte[] bytes){
            _fileName  = fileName;
            _bytes      = bytes;
        }

        #region properties
        public string FileName{
            get{return _fileName;}
        }
        public Stream Stream{
            get{return _stream;}
        }
        public byte[] Bytes{
            get{return _bytes;}
        }
        #endregion
    }
}
