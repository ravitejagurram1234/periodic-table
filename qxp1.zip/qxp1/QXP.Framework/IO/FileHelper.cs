using System;
using System.IO;

namespace QXP.Framework.IO
{
	/// <summary>Provides methods to manipulation files. </summary>
	public class	FileHelper
	{
		/// <summary>Gets a full file name from a array of sucessive directory. </summary>
		/// <param name="pathArgs">An <see cref="Array"/> of object that contains one or more directories</param>
		/// <returns>The full file name path. </returns>
		/// <remarks>The full file name path include running application path if <paramref name="pathArgs"/> is relative. </remarks>
		public static string	GetFileName(params object[] pathArgs)
		{
			string __path		= StringHelper.SlashNString(pathArgs);
			if(!Path.IsPathRooted(__path))
			{
				__path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, __path);
			}
			string __fullPath = Path.GetFullPath(__path);
			return __fullPath;
		}
		/// <summary>Reads entire content of a file and return into a single <see cref="String"/> object. </summary>
		/// <param name="fileName">The full file name. </param>
		/// <returns>The <see cref="String"/> that contains the entire file content. </returns>
		public static string	ReadFile(params object[] pathArgs)
		{
			StreamReader	__reader		= null;
			string			__text			= string.Empty;
			string			__fullFileName	= null;
			try
			{
				if(Validation.IsNotSet(pathArgs))	return string.Empty;
				__fullFileName	= GetFileName(pathArgs);
				if(!File.Exists(__fullFileName))	return string.Empty;
				__reader		= new StreamReader(__fullFileName);
				__text			= __reader.ReadToEnd();	
            }
            finally
            {
                if (Validation.IsNotNull(__reader))
				{
                    __reader.Close();
				}
            }
			return __text;
		}
		public static void	    WriteFile(string fullPath, Stream stream)
		{
			FileStream		__fileStream	= null;

			try
			{
				__fileStream	= new FileStream(fullPath, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);
				byte[] __data = new byte[stream.Length];
                stream.Read(__data, 0, __data.Length);
                __fileStream.Write(__data, 0, __data.Length);
			}
			finally
			{
				if(Validation.IsNotNull(__fileStream))
				{
					__fileStream.Close();
				}
			}
		}
		public static void	    WriteFile(string fullPath, string text)
		{
            StreamWriter    __writer = null;
			try
			{
				__writer	= new StreamWriter(fullPath);
                __writer.Write(text);
			}
			finally
			{
				if(Validation.IsNotNull(__writer))
				{
					__writer.Close();
				}
			}
        }


		/// <summary>
        /// Sauvegarde d'un fichier avec eventuellement creation du repertoire s'il n'existe pas
        /// </summary>
        /// <param name="path">chemin et nom du fichier</param>
        /// <param name="bytes">flux binaire � sauvegarder</param>
        /// <param name="createDir">faut-il creer le repertoire s'il est manquant</param>
        public static void SaveFile(string path, byte[] bytes, bool createDir){
            if(Validation.IsNotSet(bytes)) return;
            if(createDir){
                FileInfo __info = new FileInfo(path);
                if(!Directory.Exists(__info.Directory.FullName)){
                    Directory.CreateDirectory(__info.Directory.FullName);
                } 
            }
            File.WriteAllBytes(path, bytes);
        }
	}
}
