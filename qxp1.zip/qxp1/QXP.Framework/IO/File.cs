using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;


namespace QXP.Framework.IO{
	/// <summary>Represents a writer that can write a string into text file. </summary>
	public class	FileWriter{
		#region internal variables
		private object				synclock							= new object();
		Timer									_writeTimer;
		int										_writeDelay						= 1000;
		bool									_disposed							= false;
		ArrayList							_data									= new ArrayList();
		StringBuilder					_sb;
		StringWriter					_sw;

		private string				_fileName;
		private string				_path;
		private string				_extension;
		private string				_fullFileNamePattern;
		private	bool					_filePatternChanged		= false;
		private string				_fileHeader						= null;
		private	Encoding			_encoding							= Encoding.Unicode; //INFO: utf16 encoding.

		#endregion
		/// <summary>Creates a new instance of <see cref="FileWriter"/>. </summary>
		public FileWriter(){
			_sb				= new StringBuilder();
			_sw				= new StringWriter(_sb);
		}
		/// <summary>Creates a new instance of <see cref="FileWriter"/> from with specified parameters. </summary>
		/// <param name="path">The path where the file is placed. </param>
		/// <param name="fileName">The partial string name of the file. </param>
		/// <param name="extension">The file extension of the file. </param>
		/// <param name="writeDelay">The interval between the file open and close event. </param>
		public FileWriter(string path, string fileName, string extension, int writeDelay): this(){
			_path					= path;
			_extension				= extension;
			_fileName				= fileName;
			_writeDelay				= writeDelay;
			_filePatternChanged		= true;
		}
		private		void						UpdateFileNamePattern(){
			string __path;
			if(Validation.IsNotNull(_path)){
				if(System.IO.Path.IsPathRooted(_path))	__path = _path;	
				else																		__path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _path);
			}else{
				__path = AppDomain.CurrentDomain.BaseDirectory;
			}
			_fullFileNamePattern	= string.Format("{0}.{1}", System.IO.Path.Combine(__path, "{0}"), _extension);
		}
		/// <summary>Checks if File Pattern name has changed. </summary>
		protected bool						FilePatternChanged{
			get{return _filePatternChanged;}
			set{_filePatternChanged = value;}
		}
		/// <summary>Gets or sets the file name. </summary>
		public string							FileName{
			get{return _fileName;}
			set{_fileName = value;}
		}
		/// <summary>Gets or sets the path of the file. </summary>
		public string							Path{
			get{return _path;}
			set{
				_path								= value;
				_filePatternChanged = true;
			}
		}
		/// <summary>Gets or sets the extension of the file. </summary>
		public string							Extension{
			get{return _extension;}
			set{
				_extension					= value;
				_filePatternChanged = true;
			}
		}
		/// <summary>Gets or set the delay period before closing the file (in milliseconds).</summary>
		public		int							WriteDelay{
			get{return _writeDelay;}
			set{
				if(value < 0) throw new ArgumentOutOfRangeException(Constantes.FileWriterOutOfRangeWriteDelay);
				_writeDelay = value;
			}
		}
		/// <summary>Gets the full file name of the current instance. </summary>
		public		virtual string	FullFileName{
			get{return string.Format(this.FullFileNamePattern, _fileName);}
		}
		/// <summary>Gets or sets the header of the file when it will be created. </summary>
		public		virtual string	FileHeader{
			get{return _fileHeader;}
			set{_fileHeader = value;}
		}
		/// <summary>Gets or sets the <see cref="System.Text.Encoding"/> used by the <see cref="FileWriter"/>. </summary>
		public		Encoding				Encoding{
			get{return _encoding;}
			set{
				bool __encodingChanged = !_encoding.Equals(value);
				_encoding = value;
				if(__encodingChanged) this.EncodingUpdated();
			}
		}
		/// <summary>Inform derived class that encoding has changed. </summary>
		protected virtual void		EncodingUpdated(){}
		/// <summary>Gets the full file pattern used to evaluate the FullFileName. </summary>
		protected string					FullFileNamePattern{
			get{
				if(_filePatternChanged){
					this.UpdateFileNamePattern();
					_filePatternChanged = false;
				}
				return _fullFileNamePattern;
			}
		}
		private		void						Flush(){
			if(_writeTimer == null) return;
			this.InternalFlush();
		}
		private		void						InternalFlush(){
			string				__fullFileName	= this.FullFileName;
			if(_sb.Length == 0 || Validation.IsNotSet(__fullFileName)) return;
			FileStream		__file					= null;				
			StreamWriter	__streamWriter	= null;
			try{
				bool		__fileNameExist = File.Exists(__fullFileName);
				__file					= new FileStream(__fullFileName, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
				if(Validation.IsNull(_encoding) || _encoding.Equals(System.Text.Encoding.UTF8)){
					__streamWriter	= new StreamWriter(__file);
				}else{
					__streamWriter	= new StreamWriter(__file, _encoding);
				}
				if(!__fileNameExist && Validation.IsSet(_fileHeader)){
					__streamWriter.WriteLine(_fileHeader);
				}
				__streamWriter.Write(_sb.ToString());
			}finally{
				if(!_disposed){
					_sb = new StringBuilder();
					_sw = new StringWriter(_sb);
				}else{
					_sb = null;
					_sw = null;
				}
				_writeTimer			= null;
				if(__streamWriter != null){
					__streamWriter.Close();
					__streamWriter	= null;
				}
				if(__file != null){
					__file.Close();
					__file = null;
				}
			}
		}

		/// <summary>Flush buffer and close current file. </summary>
		public		void						Close(){
			lock(synclock){
				this.Flush();
			}
		}
		private		void						CreateTimer(){
			lock(synclock){
				_writeTimer			= new Timer(new TimerCallback(this.OnWriteTimer), null, _writeDelay, 0); 
			}
		}
		private		void						OnWriteTimer(object obj){
			lock(synclock){
				this.Flush();
			}
		}
		/// <summary>Occurs when the FileWriter is Finalized (disposed) by the GC. </summary>
		~FileWriter(){
			_disposed = true;
			this.Close();
		}
		#region Write/WriteLine
		/// <summary>Writes the specified text message with optional arguments and no break line into the current file instance. </summary>
		/// <param name="text">The <see cref="String"/> message to persist. </param>
		/// <param name="args">optional arguments to combine with the <paramref name="message"/>. </param>
		public		void						Write(string text, params object[] args){
			lock(synclock){
				try{
					//INFO: it's too late FileWriter is disposed.
					if(_disposed) return;
					this.CreateTimer();
					if(args.Length == 0)	_sw.Write(text);
					else									_sw.Write(text, args);
				}finally{}
			}
		}
		/// <summary>Writes the specified text message with optional arguments and break line into the current file instance. </summary>
		/// <param name="text">The <see cref="String"/> message to persist. </param>
		/// <param name="args">optional arguments to combine with the <paramref name="message"/>. </param>
		public		void						WriteLine(string text, params object[] args){
			lock(synclock){
				//INFO: it's too late FileWriter is disposed.
				if(_disposed) return;
				this.CreateTimer();
				if(args.Length == 0)	_sw.WriteLine(text);								
				else					_sw.WriteLine(text, args);
			}
		}
		#endregion
	}
	/// <summary>Provides functionality to persist text into a dated file. </summary>
	public class	DatedFileWriter: FileWriter{
		#region internal variables
		private Periodicity	_periodicity;
		#endregion
		/// <summary>Creates a new instance of <see cref="DatedFileWriter"/> class.</summary>
		public DatedFileWriter(): base(){}
		/// <summary>Creates a new instance of <see cref="DatedFileWriter"/> class from the specified params.</summary>
		/// <param name="periodicity">The <see cref="Periodicity"/> used by the instance to change periodically the file name date. </param>
		/// <param name="path">The path where the file is placed. </param>
		/// <param name="fileName">The partial string name of the file. </param>
		/// <param name="extension">The file extension of the file. </param>
		/// <param name="writeTimeOut">The interval between the file open and close event. </param>
		public DatedFileWriter(Periodicity periodicity, string path, string fileName, string extension, int writeTimeOut): base(path, fileName, extension, writeTimeOut){
			_periodicity = periodicity;
		}
		/// <summary>Gets the full evaluated file name. </summary>
		public override string	FullFileName{
			get{
				string		__fullFileName		= string.Empty;
				string		__datedPattern		= "{0}_{1}";
				string		__dateTime				= string.Empty;
				DateTime	__date						= DateTime.Now;
				switch (_periodicity){
					case Periodicity.Hour:	__dateTime = __date.ToString("yyyyMMdd'_'HH");	break;
					case Periodicity.Day:		__dateTime = __date.ToString("yyyyMMdd");				break;
					case Periodicity.Week:	__dateTime = string.Format("{0:yyyy}{1}", __date, CultureInfo.CurrentCulture.Calendar.GetWeekOfYear(__date, CalendarWeekRule.FirstDay, DayOfWeek.Monday)); break;
					default: break;
				}
				__fullFileName = string.Format(this.FullFileNamePattern, string.Format(__datedPattern, this.FileName, __dateTime));
				return __fullFileName;
			}
		}
		/// <summary>Gets the <see cref="Periodicity"/> of the current instance. </summary>
		public Periodicity			Periodicity{
			get{return _periodicity;}
			set{_periodicity = value;}
		}
	}
	/// <summary>Represents a DatedFileWriter with xml header. </summary>
	public class	XmlDatedFileWriter : DatedFileWriter{
		#region internal variables
		const string XmlFileHeaderPattern = "<?xml version=\"1.0\" encoding=\"{0}\" ?>";
		#endregion
		/// <summary>Creates a new instance of <see cref="XmlDatedFileWriter"/> class.</summary>
		public XmlDatedFileWriter(): base(){
			this.EncodingUpdated();
		}
		/// <summary>Creates a new instance of <see cref="XmlDatedFileWriter"/> class from the specified params.</summary>
		/// <param name="periodicity">The <see cref="Periodicity"/> used by the instance to change periodically the file name date. </param>
		/// <param name="path">The path where the file is placed. </param>
		/// <param name="fileName">The partial string name of the file. </param>
		/// <param name="extension">The file extension of the file. </param>
		/// <param name="writeTimeOut">The interval between the file open and close event. </param>
		public XmlDatedFileWriter(Periodicity periodicity, string path, string fileName, string extension, int writeTimeOut): base(periodicity, path, fileName, extension, writeTimeOut){
			this.EncodingUpdated();
		}
		/// <summary><see cref="FileWriter.EncodingUpdated"/></summary>
		protected override void		EncodingUpdated(){
			this.FileHeader = string.Format(XmlFileHeaderPattern, this.Encoding.HeaderName);
		}
	}
}
