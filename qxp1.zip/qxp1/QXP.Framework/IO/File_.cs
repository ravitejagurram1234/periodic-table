using System;

namespace QXP.Framework.IO{
	/// <summary>Contains IO Type. </summary>
	public class IOType{
		private IOType(){}
		/// <summary>Represents the <see cref="IO.Periodicity"/> <see cref="System.Type"/>. </summary>
		public static Type Periodicity = typeof(Periodicity);
	}
}
