using System;
using System.Security.Principal;

namespace QXP.Framework.Security
{
	/// <summary>
	/// Description r�sum�e de Crypt.
	/// </summary>
	public class Identity
	{
		#region Constructeur
		const string IdentityPattern = "Name:{0} \nIsAuthenticated:{1} \nIsSystem:n{2} \nIsAnonymous:n{3} \nIsGuest:n{4}";
		#endregion

		#region M�thodes

		public static string GetProcessIdentityInfo()
		{
			WindowsIdentity __identity		= null;
			string			__strIdentity	= "Unavailable";
			try
			{
				__identity		= WindowsIdentity.GetCurrent();
				__strIdentity	= string.Format(IdentityPattern, __identity.Name, __identity.IsAuthenticated, __identity.IsSystem, __identity.IsAnonymous, __identity.IsGuest);
			}
			catch{}
			return __strIdentity;
		}
		public static string GetProcessIdentityName()
		{
			WindowsIdentity __identity		= null;
			string			__strIdentity	= "Unavailable";
			try
			{
				__identity		= WindowsIdentity.GetCurrent();
				__strIdentity	= __identity.Name;
			}
			catch{}
			return __strIdentity;
		}

		public static string GetRequestIdentityName()
		{
			IIdentity		__identity		= null;
			string			__strIdentity	= "Unavailable";
			try
			{
				__identity		= System.Web.HttpContext.Current.User.Identity;
				__strIdentity	= __identity.Name;
			}
			catch{}
			return __strIdentity;
		}

		#endregion
	}
}
