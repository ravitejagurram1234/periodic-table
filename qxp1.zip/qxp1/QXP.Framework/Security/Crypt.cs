using System;
using System.Collections;
using System.Collections.Specialized;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace QXP.Framework.Security
{
	/// <summary>
	/// Description r�sum�e de Crypt.
	/// </summary>
	public class Crypt
	{
		#region Constructeur

		public Crypt(){}

		#endregion

		#region M�thodes

		/// <summary>
		/// fonction qui permet d'encrypter une chaine de caract�re en triple DES 192 bits 
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static string EncryptString(string value, string key)
		{
			ICryptoTransform 	__ct;
			MemoryStream	 	__ms;
			CryptoStream	 	__cs;
			UnicodeEncoding  	__UE = new UnicodeEncoding();
			byte[]           	__byt; 
			SymmetricAlgorithm	__mCSP;
			
			__mCSP      = new TripleDESCryptoServiceProvider(); // Cryptage TRIPLE DES 192 bits

			// formatage chaine cl� elle ne doit pas d�passer 16 bits
			if (key.Length > 8)
				key = key.Substring(0, 8);
			else if (key.Length < 8)
			{
				int add = 8-key.Length;
				for (int __i=0; __i<add; __i++)
					key = key+__i;
			}
			
			byte[] __key = __UE.GetBytes(key); 
			// fin formatage 

			__ct  = __mCSP.CreateEncryptor(__key, __key);
			__byt = Encoding.UTF8.GetBytes(value);
			__ms  = new MemoryStream();
			__cs  = new CryptoStream(__ms, __ct, CryptoStreamMode.Write);
			__cs.Write(__byt, 0, __byt.Length);
			__cs.FlushFinalBlock();
			__cs.Close();

			return Convert.ToBase64String(__ms.ToArray());
		}

		/// <summary>
		/// fonction qui permet de d�crypter une chaine de caract�re en triple DES 192 bits 
		/// </summary>
		/// <param name="value"></param>
		/// <returns>chaine decrypt�e </returns>
		public static string DecryptString(string value, string key)
		{
			ICryptoTransform 	__ct;
			MemoryStream	 	__ms;
			CryptoStream	 	__cs;
			UnicodeEncoding  	__UE = new UnicodeEncoding();
			byte[]           	__byt; 
			SymmetricAlgorithm	__mCSP;
			__mCSP      = new TripleDESCryptoServiceProvider();

			// formatage  cl� elle ne doit pas d�passer 16 bits
			if (key.Length > 8)
				key = key.Substring(0, 8);
			else if (key.Length < 8)
			{
				int add = 8 - key.Length;
				for (int __i = 0; __i<add; __i++)
					key = key+__i;
			}
			
			byte[] __key = __UE.GetBytes(key); 
			// fin formatage 

			__ct = __mCSP.CreateDecryptor(__key, __key);
			__byt = Convert.FromBase64String(value.Replace(" ", "+"));
			__ms = new MemoryStream();
			__cs = new CryptoStream(__ms, __ct, CryptoStreamMode.Write);
			__cs.Write(__byt, 0, __byt.Length);
			__cs.FlushFinalBlock();
			__cs.Close();

			return Encoding.UTF8.GetString(__ms.ToArray());
		}

		/// <summary>
		/// fonction qui permet d'encrypter une chaine de caract�re en triple DES 192 bits 
		/// avec cl� int�gr�e ( ne pas modifier la cl� !!! )
		/// </summary>
		/// <param name="value"></param>
		/// <returns> chaine crypt�e </returns>
		public static string EncryptStringFK(string value)
		{

			ICryptoTransform 	__ct;
			MemoryStream	 	__ms;
			CryptoStream	 	__cs;
			UnicodeEncoding  	__UE = new UnicodeEncoding();
			byte[]           	__byt; 
			SymmetricAlgorithm	__mCSP;
			string				key = "/0yueKHn9nfm+1Lrwnxdx+dqLLk=";

			
			__mCSP      = new TripleDESCryptoServiceProvider(); // Cryptage TRIPLE DES 192 bits

			// formatage chaine cl� elle ne doit pas d�passer 16 bits
			if (key.Length > 8)
				key = key.Substring(0, 8);
			else if (key.Length < 8)
			{
				int add = 8-key.Length;
				for (int __i=0; __i<add; __i++)
					key = key+__i;
			}
			
			byte[] __key = __UE.GetBytes(key); 
			// fin formatage 

			__ct  = __mCSP.CreateEncryptor(__key, __key);
			__byt = Encoding.UTF8.GetBytes(value);
			__ms  = new MemoryStream();
			__cs  = new CryptoStream(__ms, __ct, CryptoStreamMode.Write);
			__cs.Write(__byt, 0, __byt.Length);
			__cs.FlushFinalBlock();
			__cs.Close();

			return Convert.ToBase64String(__ms.ToArray());
		}

		/// <summary>
		/// fonction qui permet de d�crypter une chaine de caract�re en triple DES 192 bits 
		/// avec cl� int�gr�e ( ne pas modifier la cl� !!! )
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static string DecryptStringFK(string value)
		{
			ICryptoTransform 	__ct;
			MemoryStream	 	__ms;
			CryptoStream	 	__cs;
			UnicodeEncoding  	__UE = new UnicodeEncoding();
			byte[]           	__byt; 
			SymmetricAlgorithm	__mCSP;
			__mCSP					= new TripleDESCryptoServiceProvider();
			string				key = "/0yueKHn9nfm+1Lrwnxdx+dqLLk=";

            if(Validation.IsNotSet(value)) return value;
			// formatage  cl� elle ne doit pas d�passer 16 bits
			if (key.Length > 8)
				key = key.Substring(0, 8);
			else if (key.Length < 8)
			{
				int add = 8 - key.Length;
				for (int __i = 0; __i<add; __i++)
					key = key+__i;
			}
			
			byte[] __key = __UE.GetBytes(key); 
			// fin formatage 

			__ct = __mCSP.CreateDecryptor(__key, __key);
			__byt = Convert.FromBase64String(value.Replace(" ", "+"));
			__ms = new MemoryStream();
			__cs = new CryptoStream(__ms, __ct, CryptoStreamMode.Write);
			__cs.Write(__byt, 0, __byt.Length);
			__cs.FlushFinalBlock();
			__cs.Close();

			return Encoding.UTF8.GetString(__ms.ToArray());
		}

		/// <summary>
		/// Fonction qui permet de Hascher une chaine de caract�re selon l'algo SHA-256 
		/// La cl� retourn�e correspond � 44 caract�res  
		/// Attention : Une chaine crypt�e ne pourra plus �tre d�crypt�e !! 
		/// </summary>
		/// <param name="strSource"></param>
		/// <returns>Cha�ne de caract�re crypt�e</returns>
		public static string CreateHashSHA256(string strSource)
		{
			byte[] bytHash ;
			UnicodeEncoding uEncode = new UnicodeEncoding();

			//Stock la chaine source dans un tableau de byte
			byte[] bytSource= uEncode.GetBytes(strSource);
			SHA256 shaM = new SHA256Managed();

			//Cr�er les informations hash�es
			bytHash = shaM.ComputeHash(bytSource);

			
			// retour de la chaine cod�e 
			return Convert.ToBase64String(bytHash);
		}


		#endregion
	}
}
