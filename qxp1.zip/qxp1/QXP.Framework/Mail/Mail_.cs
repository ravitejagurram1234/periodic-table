using System;

namespace QXP.Framework.Mail{
	/// <summary>Contains the Mail Type. </summary>
	public class MailType{
		private MailType(){}
		/// <summary>Represents the <see cref="System.Web.Mail.MailPriority"/> <see cref="System.Type"/>. </summary>
		public static Type MailPriority = typeof(System.Web.Mail.MailPriority);
	}
}