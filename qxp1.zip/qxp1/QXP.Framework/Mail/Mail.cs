using System;
using System.Collections;
using System.IO;
using System.Web.Mail;

namespace QXP.Framework.Mail{
	/// <summary>Provides methods for constructing an e-mail message. </summary>
	public class MailMessage: System.Web.Mail.MailMessage{
		/// <summary>Creates a new Instance of <see cref="MailMessage"/> class. </summary>
		public MailMessage(): base(){}
		/// <summary>Creates a new Instance of <see cref="MailMessage"/> class with <paramref name="body"/> message. </summary>
		/// <param name="body">The text message to include in body of the email message. </param>
		public MailMessage(string body): this(){
			base.Body = body;
		}
		/// <summary>Creates a new Instance of <see cref="MailMessage"/> class with <paramref name="body"/> message and <paramref name="subject"/>. </summary>
		/// <param name="body">The text message to include in body of the email message. </param>
		/// <param name="subject">The subject of the message. </param>
		public MailMessage(string body, string subject): this(body){
			base.Subject = subject;
		}
		/// <summary>Creates a new Instance of <see cref="MailMessage"/> class with <paramref name="body"/> message and <paramref name="subject"/> to the recipient address specified with <paramref name="mailTo"/>. </summary>
		/// <param name="body">The text message to include in body of the email message. </param>
		/// <param name="subject">The subject of the message. </param>
		/// <param name="mailTo">The address of the recipient. </param>
		public MailMessage(string body, string subject, string mailTo): this(body, subject){
			base.To = mailTo;
		}
		/// <summary>Creates a new Instance of <see cref="MailMessage"/> class with <paramref name="body"/> message and <paramref name="subject"/> to the recipient address specified with <paramref name="mailTo"/>. this message have the <paramref name="mailFrom"/> sender address. </summary>
		/// <param name="body">The text message to include in body of the email message. </param>
		/// <param name="subject">The subject of the message. </param>
		/// <param name="mailTo">The address of the recipient. </param>
		/// <param name="mailFrom">The address of the sender. </param>
		public MailMessage(string body, string subject, string mailTo, string mailFrom): this(body, subject, mailTo){
			base.From = mailFrom;
		}
		/// <summary>Creates a new Instance of <see cref="MailMessage"/> class with <paramref name="body"/> message and <paramref name="subject"/> to the recipient address specified with <paramref name="mailTo"/>. this message have the <paramref name="mailFrom"/> sender address and a <paramref name="priority"/> level. </summary>
		/// <param name="body">The text message to include in body of the email message. </param>
		/// <param name="subject">The subject of the message. </param>
		/// <param name="mailTo">The address of the recipient. </param>
		/// <param name="mailFrom">The address of the sender. </param>
		/// <param name="priority">The <see cref="MailPriority"/> that specifie priority level of the message. </param>
		public MailMessage(string body, string subject, string mailTo, string mailFrom, MailPriority priority): this(body, subject, mailTo, mailFrom){
			base.Priority = priority;
		}
		/// <summary>Creates a new Instance of <see cref="MailMessage"/> class with <paramref name="body"/> message and <paramref name="subject"/> to the recipient address specified with <paramref name="mailTo"/>. this message have the <paramref name="mailFrom"/> sender address and a <paramref name="bodyFormat"/> options. </summary>
		/// <param name="body">The text message to include in body of the email message. </param>
		/// <param name="subject">the subject of the message. </param>
		/// <param name="mailTo">The address of the recipient. </param>
		/// <param name="mailFrom">The address of the sender. </param>
		/// <param name="bodyFormat">The <see cref="MailFormat"/> content type of the body message. </param>
		public MailMessage(string body, string subject, string mailTo, string mailFrom, MailFormat bodyFormat): this(body, subject, mailTo, mailFrom){
		}
		/// <summary>Creates a new Instance of <see cref="MailMessage"/> class with <paramref name="body"/> message and <paramref name="subject"/> to the recipient address specified with <paramref name="mailTo"/>. this message have the <paramref name="mailFrom"/> sender address, <paramref name="priority"/> level and <paramref name="bodyFormat"/> content type. </summary>
		/// <param name="body">The text message to include in body of the email message. </param>
		/// <param name="subject">the subject of the message. </param>
		/// <param name="mailTo">The address of the recipient. </param>
		/// <param name="mailFrom">The address of the sender. </param>
		/// <param name="bodyFormat">The <see cref="MailFormat"/> content type of the body message. </param>
		/// <param name="priority">The <see cref="MailPriority"/> that specifie priority level of the message. </param>
		public MailMessage(string body, string subject, string mailTo, string mailFrom, MailFormat bodyFormat, MailPriority priority): this(body, subject, mailTo, mailFrom, bodyFormat){
			base.Priority = priority;
		}
		/// <summary>Adds and array of file into that are attached with the current mail message. </summary>
		/// <param name="fileNames">An array of files name to include in message. </param>
		public void AddAttachments(string[] fileNames){
			if(!Validation.IsNull(fileNames)){
				IEnumerator __ie = fileNames.GetEnumerator();
				while(__ie.MoveNext()){
					this.AddAttachment(Conversion.ToString(__ie.Current));
				}																	
			}
		}
		/// <summary>Adds the specified <paramref name="fileName"/> to the current mail message. </summary>
		/// <param name="fileName">the name of the file to include in mail message. </param>
		public void AddAttachment(string fileName){
			if(Validation.IsSet(fileName)) Attachments.Add(new MailAttachment(fileName));
		}
		/// <summary>Sends the email message using the specified <paramref name="smtpServer"/> parameters. </summary>
		/// <param name="smtpServer">the name or ip address of the SMTP Server. </param>
		public void Send(string smtpServer){
			SmtpMail.SmtpServer = smtpServer;
			SmtpMail.Send(this);
		}
	}
}