using System;
using System.Data;

using QXPConfiguration      = QXP.Framework.Configuration;
using QXPDataOracle         = QXP.Framework.Data.Oracle;


namespace QXP.Framework.Proxy
{
    /// <summary>
    /// Description r�sum�e de BaseProxy.
    /// </summary>
    public class BaseProxy
    {
        #region Membres

        string _sitePrefix = null;
        QXPDataOracle.OraClient _client = null;

        #endregion Membres

        #region Constantes

        public static string DBConnectionString = string.Empty;
        static string _defaultSitePrefix = "QXP";
        const string SitePrefixKey = "SitePrefix";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        static BaseProxy()
        {
            string __sitePrefix = QXPConfiguration.Settings.Current.GetString(SitePrefixKey);
            if (Validation.IsSet(__sitePrefix)) _defaultSitePrefix = __sitePrefix;
        }

        public BaseProxy() : this(string.Empty) { }

        public BaseProxy(string nameConnection)
        {
            _client = QXPDataOracle.OraClient.Create(nameConnection);
            _sitePrefix = _defaultSitePrefix;
        }

        public BaseProxy(QXPDataOracle.OraClient oraClient)
        {
            _client = oraClient;
            _sitePrefix = _defaultSitePrefix;
        }

        #endregion Constructeur

        #region M�thodes

        public void BeginTransaction()
        {
            if (!this.OracleClient.IsTransactional) this.OracleClient.BeginTransaction();
        }

        public void CommitTransaction()
        {
            if (this.OracleClient.IsTransactional) this.OracleClient.CommitTransaction();
        }

        /// <summary>
        /// Annulation de toutes les op�rations effectu�es sur le proxy depuis le BeginTransaction
        /// </summary>
        public void RoolBackTransaction()
        {
            if (this.OracleClient.IsTransactional) this.OracleClient.RollBackTransaction();
        }

        /// <summary>
        /// Annulation de toutes les op�rations effectu�es sur le proxy apr�s le savePointName
        /// </summary>
        public void RoolBackTransaction(string savePointName)
        {
            if (this.OracleClient.IsTransactional)
            {
                this.OracleClient.Transaction.Rollback(savePointName);
            }
        }

        /// <summary>
        /// M�morise un point de sauvegarde de la transaction en cours il sera ainsi possible de revenir � ce point par RoolBackTransaction(savePointName)
        /// </summary>
        /// <param name="savePointName"></param>
        public void SavePoint(string savePointName)
        {
            if (this.OracleClient.IsTransactional)
            {
                this.OracleClient.Transaction.Save(savePointName);
            }
        }

        /// <summary>
        /// Fermeture volontaire du proxy (rollback si en mode transactionnel)
        /// </summary>
        public void Close()
        {
            _client.Close();
        }

        #region Execute / ExecuteScalar

        protected QXPDataOracle.OraValue ExecuteScalar(QXPDataOracle.SQLRequest sqlRequest, Type returnType)
        {
            return ExecuteScalar(sqlRequest, returnType, null);
        }

        protected QXPDataOracle.OraValue ExecuteScalar(QXPDataOracle.SQLRequest sqlRequest, Type returnType, string udtTypeName)
        {
            if (Validation.IsSet(sqlRequest.OraClient))
                return this.ExecuteScalar(sqlRequest.OraClient, sqlRequest.CommandType, sqlRequest.SqlString, returnType, udtTypeName, sqlRequest.OraParameters.ToArray());
            else
                return this.ExecuteScalar(sqlRequest.CommandType, sqlRequest.SqlString, returnType, udtTypeName, sqlRequest.OraParameters.ToArray());
        }

        protected QXPDataOracle.OraValue ExecuteScalar(CommandType type, string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            return this.ExecuteScalar(type, sql, string.Empty, parameters);
        }

        protected QXPDataOracle.OraValue ExecuteScalar(CommandType type, string sql, string udtTypeName, params QXPDataOracle.OraParameter[] parameters)
        {
            return this.ExecuteScalar(this._client, type, sql, udtTypeName,  parameters);
        }
        
        protected QXPDataOracle.OraValue ExecuteScalar(CommandType type, string sql, Type returnType, params QXPDataOracle.OraParameter[] parameters)
        {
            return this.ExecuteScalar(type, sql, returnType, string.Empty, parameters);
        }

        protected QXPDataOracle.OraValue ExecuteScalar(CommandType type, string sql, Type returnType,  string udtTypeName, params QXPDataOracle.OraParameter[] parameters)
        {
            return this.ExecuteScalar(this._client, type, sql, returnType, udtTypeName, parameters);
        }

        protected QXPDataOracle.OraValue ExecuteScalar(QXPDataOracle.OraClient client, CommandType type, string sql, string udtTypeName, params QXPDataOracle.OraParameter[] parameters)
        {
            return this.ExecuteScalar(this._client, type, sql, ValueType.CLSstring, udtTypeName, parameters);
        }

        protected QXPDataOracle.OraValue ExecuteScalar(QXPDataOracle.OraClient client, CommandType type, string sql, Type returnType, string udtTypeName, params QXPDataOracle.OraParameter[] parameters)
        {
            QXPDataOracle.OraValue __value = null;

            try
            {
                __value = client.ExecuteScalar(type, sql, returnType, udtTypeName, parameters);
            }
            catch
            {
                throw;
            }
            return __value;
        }

        protected int Execute(QXPDataOracle.SQLRequest sqlRequest)
        {
            if (Validation.IsSet(sqlRequest.OraClient))
                return this.Execute(sqlRequest.OraClient, sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OraParameters.ToArray());
            else
                return this.Execute(sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OraParameters.ToArray());
        }

        protected int Execute(CommandType type, string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            return this.Execute(this._client, type, sql, parameters);
        }

        protected int Execute(QXPDataOracle.OraClient client, CommandType type, string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            int __affected = 0;
            try
            {
                __affected = _client.ExecuteNonQuery(type, sql, parameters);
            }
            catch
            {
                throw;
            }
            return __affected;
        }

        #endregion Execute / ExecuteScalar

        #region GetReader

        protected QXPDataOracle.OraDataReader GetReader(QXPDataOracle.SQLRequest sqlRequest)
        {
            if (Validation.IsSet(sqlRequest.OraClient))
                return this.GetReader(sqlRequest.OraClient, sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OracleConnectionOwnership, sqlRequest.OraParameters.ToArray());
            else
                return this.GetReader(sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OracleConnectionOwnership, sqlRequest.OraParameters.ToArray());
        }

        protected QXPDataOracle.OraDataReader GetReader(CommandType type, string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            return GetReader(this._client, type, sql, parameters);
        }

        protected QXPDataOracle.OraDataReader GetReader(CommandType type, string sql, QXPDataOracle.OraClient.OracleConnectionOwnership ownerShip, params QXPDataOracle.OraParameter[] parameters)
        {
            return GetReader(this._client, type, sql, ownerShip, parameters);
        }

        protected QXPDataOracle.OraDataReader GetReader(QXPDataOracle.OraClient client, CommandType type, string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            return this.GetReader(client, type, sql, QXPDataOracle.OraClient.OracleConnectionOwnership.Internal, parameters);
        }

        protected QXPDataOracle.OraDataReader GetReader(QXPDataOracle.OraClient client, CommandType type, string sql, QXPDataOracle.OraClient.OracleConnectionOwnership ownerShip, params QXPDataOracle.OraParameter[] parameters)
        {
            QXPDataOracle.OraDataReader __odr = null;

            try
            {
                __odr = client.ExecuteReader(type, sql, parameters, ownerShip);
            }
            catch
            {
                if (__odr != null) __odr.Close();
                throw;
            }
            return __odr;
        }

        #endregion GetReader

        #region DataSet

        protected QXPDataOracle.OraDataSet GetDataSet(QXPDataOracle.SQLRequest sqlRequest)
        {
            if (Validation.IsSet(sqlRequest.OraClient))
                return this.GetDataSet(sqlRequest.OraClient, sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OraParameters.ToArray());
            else
                return this.GetDataSet(sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OraParameters.ToArray());
        }

        protected QXPDataOracle.OraDataSet GetDataSet(CommandType type, string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            return GetDataSet(this._client, type, sql, parameters);
        }

        protected QXPDataOracle.OraDataSet GetDataSet(QXPDataOracle.OraClient client, CommandType type, string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            QXPDataOracle.OraDataSet __ods = null;

            try
            {
                __ods = client.ExecuteDataset(null, type, sql, parameters);
            }
            catch
            {
                throw;
            }
            return __ods;
        }

        protected void FillDataSet(QXPDataOracle.OraDataSet dataset, string dataTable, QXPDataOracle.SQLRequest sqlRequest)
        {
            if (Validation.IsSet(sqlRequest.OraClient))
                this.FillDataSet(dataset, dataTable, sqlRequest.OraClient, sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OraParameters.ToArray());
            else
                this.FillDataSet(dataset, dataTable, sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OraParameters.ToArray());
        }

        protected void FillDataSet(QXPDataOracle.OraDataSet dataset, QXPDataOracle.SQLRequest sqlRequest)
        {
            string __dataTable = string.Concat("Table", dataset.Tables.Count.ToString());

            if (sqlRequest.CommandType == CommandType.StoredProcedure)
                __dataTable = sqlRequest.SqlString;

            if (Validation.IsSet(sqlRequest.OraClient))
                this.FillDataSet(dataset, __dataTable, sqlRequest.OraClient, sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OraParameters.ToArray());
            else
                this.FillDataSet(dataset, __dataTable, sqlRequest.CommandType, sqlRequest.SqlString, sqlRequest.OraParameters.ToArray());
        }

        /// <summary>
        /// Fill an existing DataSet
        /// </summary>
        /// <param name="dataset"></param>
        /// <param name="type"></param>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        protected void FillDataSet(QXPDataOracle.OraDataSet dataset, string dataTable, CommandType type, string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            FillDataSet(dataset, dataTable, _client, type, sql, parameters);
        }

        protected void FillDataSet(QXPDataOracle.OraDataSet dataset, string dataTable, QXPDataOracle.OraClient client, CommandType type, string sql, params QXPDataOracle.OraParameter[] parameters)
        {
            try
            {
                dataset = client.ExecuteDataset(dataset, dataTable, type, sql, parameters);
            }
            catch
            {
                throw;
            }
        }

        #endregion DataSet

        #region M�thodes Tools

        protected string EscapeString(string value)
        {
            string __newValue = Conversion.ToString(value);
            __newValue = __newValue.Replace(@"\", @"\\").Replace(@"%", @"\%").Replace(@"_", @"\_");
            return __newValue;
        }

        #endregion

        #endregion M�thodes

        #region Propri�t�s

        protected QXPDataOracle.OraClient OracleClient
        {
            get { return _client; }
        }

        protected string SitePrefix
        {
            get { return _sitePrefix; }
            set { _sitePrefix = value; }
        }

        public bool Individual_Connection
        {
            get { return _client.Individual_Connection; }
            set { _client.Individual_Connection = value; }
        }

        public int Command_Timeout
        {
            get { return _client.Command_Timeout; }
            set { _client.Command_Timeout = value; }
        }

        #endregion Propri�t�s
    }
}
