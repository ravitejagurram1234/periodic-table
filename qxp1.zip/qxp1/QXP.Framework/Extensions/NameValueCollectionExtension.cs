using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Extensions
{
	/// <summary>
	/// Etend les fonctions de tous les NameValueCollection
	/// </summary>
	/// <author>doufarm</author>
	/// <date>30/01/2011 17:19:09</date>    
	public static class NameValueCollectionExtension
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region M�thodes

        /// <summary>
        /// Permet de convertir une NameValueCollection en un Dictionary de (string, string)
        /// </summary>
        /// <param name="source">NameValueCollection</param>
        /// <param name="action">The System.Action<T> delegate to perform on each element of the System.Collections.Generic.List<T>.</param>
        public static IDictionary<string, string> ToDictionary(this NameValueCollection source)
        {
            return source.Cast<string>()  
                     .Select(s => new { Key = s, Value = source[s] })  
                     .ToDictionary(p => p.Key, p => p.Value); 
		}   

		#endregion M�thodes
	}
}
