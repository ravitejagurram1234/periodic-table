using System;
using System.Collections.Generic;
using System.Linq;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Extensions
{
	/// <summary>
	/// Etend les fonctions de tous les IEnumerable
	/// </summary>
	/// <author>doufarm</author>
	/// <date>06/01/2011 17:06:07</date>    
	public static class IEnumerableExtension
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region M�thodes

        /// <summary>
        /// Performs the specified action on each element of the System.Collections.Generic.List<T>.
        /// </summary>
        /// <typeparam name="T">Type des �l�ments contenus dans l'IEnumerable</typeparam>
        /// <param name="source">IEnumerable</param>
        /// <param name="action">The System.Action<T> delegate to perform on each element of the System.Collections.Generic.List<T>.</param>
        public static void ForEach<T>(this IEnumerable<T> source, Action<T> action)
        {
            source.ToList().ForEach(action);
        }

		#endregion M�thodes
	}
}
