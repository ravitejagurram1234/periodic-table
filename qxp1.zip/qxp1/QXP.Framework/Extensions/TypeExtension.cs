using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Extensions
{
	/// <summary>
	/// Etend les fonctions de tous les Type
	/// </summary>
	/// <author>cueffl</author>
	/// <date>05/05/2011 17:06:07</date>    
	public static class TypeExtension
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region M�thodes

        /// <summary>
        /// Retourne la fonction g�n�rique associ�e
        /// </summary>
        /// <param name="type">Type</param>
        /// <param name="name">Nom de la m�thode</param>
        /// <param name="genericArguments">Nombre de param�tres g�n�riques</param>
        /// <param name="bindingFlags">Flags de recherche</param>
        /// <param name="parameterTypes">Type des param�tres g�n�riques</param>
        /// <returns>MethodInfo</returns>
        public static MethodInfo GetGenericMethod(this Type type, string name, int genericArguments, BindingFlags bindingFlags, params Type[] parameterTypes)
        {
            return
            (
                from method in type.GetMethods(bindingFlags)
                where method.Name == name
                where parameterTypes.Select(parameterType => parameterType.Name).SequenceEqual(method.GetParameters().Select(p => p.ParameterType.Name))
                where method.GetGenericArguments().Count() == genericArguments
                select method
            ).Single();
        } 

		#endregion M�thodes
	}
}
