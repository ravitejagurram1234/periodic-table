using System;
using System.Collections;
using System.Web;

using QXPConfiguration = QXP.Framework.Configuration;
using QXPIO = QXP.Framework.IO;
using QXPResources = QXP.Framework.Resources;

namespace QXP.Framework.Application
{
    /// <summary>
    /// This class manage dependancies between application and some files/
    /// </summary>
    public class FileDependancies : IDisposable
    {
        #region Membres

        private Hashtable _dependancies = new Hashtable();

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de FileDependancies
        /// </summary>
        internal FileDependancies()
        {
        }

        /// <summary>Release all resource used by curretn client. </summary>
        ~FileDependancies()
        {
            try
            {
                this.Dispose(false);
            }
            catch { }
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>Adds new file dependancy to <paramref name="fileName"/>, with a callback method when file is was modified. </summary>
        /// <param name="fileName">The file name to monitor. </param>
        /// <param name="callBack">The callback method to call if the <paramref name="fileName"/> is been modified. </param>
        /// <param name="args">Optional, extra argument to return with callback. </param>
        public QXPIO.FileSystemWatcher AddDependancy(string fileName, IO.FileChangeEventHandler callBack, params object[] args)
        {
            QXPIO.FileSystemWatcher __watcher = new QXPIO.FileSystemWatcher(fileName, System.IO.WatcherChangeTypes.All, fileName, args);
            __watcher.FileChange += callBack;
            Add(__watcher);
            return __watcher;
        }

        private void Add(QXPIO.FileSystemWatcher watcher)
        {
            string __fileName = watcher.Name.ToUpper();
            if (Contains(__fileName))
            {
                _dependancies[__fileName] = watcher;
            }
            else
            {
                _dependancies.Add(__fileName, watcher);
            }
        }

        /// <summary>Checks if <paramref name="fileName"/> already been monitored by filedependancies. </summary>
        /// <param name="fileName">The <see cref="String"/> file name to check. </param>
        /// <returns><see langword="true"/> if <paramref name="fileName"/> is been monitored otherwise <see langword="false"/>. </returns>
        public bool Contains(string fileName)
        {
            return _dependancies.ContainsKey(fileName.ToUpper());
        }

        /// <summary>Remove all monitoring. </summary>
        public void Clear()
        {
            try
            {
                foreach (DictionaryEntry __entry in _dependancies)
                {
                    QXPIO.FileSystemWatcher __watcher = __entry.Value as QXPIO.FileSystemWatcher;
                    try
                    {
                        __watcher.Dispose();
                    }
                    catch (Exception ex)
                    {
                        string __exception = ex.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                string __exception = ex.ToString();
            }
            _dependancies.Clear();
        }


        /// <summary>perform a proper client finalization. </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        private void Dispose(bool disposing)
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("Disposing FileDependancies");
                this.Clear();
                //if(disposing) _watcher.Dispose();
            }
            catch { }
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }


    /// <summary>
    /// Class Application : Contains Global Application Data like resources and file dependancies
    /// </summary> 
    public class Application
    {
        #region Membres

        private static FileDependancies _fileDependancies = new FileDependancies();
        private static Resources.ResourceManager _resources = new Resources.ResourceManager();
        private static int _id_Application = int.MinValue;
        private static string _nom_Application = AppDomain.CurrentDomain.FriendlyName;
        
        #endregion Membres

        #region Constantes

        //Clef dans le fichier de config (appsetting) permettant d'identifier (int) l'application 
        private const string IDApplicationKey = "ID_Application";
        //Clef dans le fichier de config (appsetting) permettant de nommer l'application 
        private const string NomApplicationKey = "Nom_Application";
        private const string APPLICATION = "Application console";
        private const string IP_SENDER = "QXP IP";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance statique de Application
        /// </summary>
        static Application()
        {
            //Ne pas bloquer l'�x�cution si une erreur se produit � ce niveau
            try
            {
                _id_Application = QXPConfiguration.Settings.Current.GetInt(IDApplicationKey);
            }
            catch { }

            //Ne pas bloquer l'�x�cution si une erreur se produit � ce niveau
            try
            {
                string __user_Application_Name = QXPConfiguration.Settings.Current.GetString(NomApplicationKey);
                if (Validation.IsSet(__user_Application_Name))
                {
                    __user_Application_Name = string.Format(" (was {0})", __user_Application_Name);
                }
                _nom_Application += __user_Application_Name;
            }
            catch { }
        }

        #endregion Constructeur

        #region M�thodes

        public static void Unload()
        {
            System.Diagnostics.Debug.WriteLine("Unload Application");
            _fileDependancies.Clear();
            _resources.Reset();
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// identifiant de l'application doit �tre unique par application (mais non obligatoire)
        /// Valeur d�finit dans le fichier de config clef "Application_ID"  dans appSetting
        /// Cette valeur est surtout utile si plusieurs sites webs sont connect�s � une m�me base de donn�es.
        /// si cette valeur est int.MinValue alors aucun identifiant d�finit sur l'application.
        /// </summary>
        public static int ID
        {
            get { return _id_Application; }
        }

        /// <summary>
        /// Nom de l'application en cours d'�x�cution
        /// Valeur d�finit dans le fichier de config clef "Application_Name" dans appSetting
        /// </summary>
        public static string Name
        {
            get { return _nom_Application; }
        }

        /// <summary>
        /// 
        /// </summary>
        public static FileDependancies FileDependancies
        {
            get { return _fileDependancies; }
        }
   
        /// <summary>
        /// 
        /// </summary>
        public static Resources.ResourceManager Resources
        {
            get { return _resources; }
        }

        /// <summary>
        /// Permet d'obtenir l'adresse IP de la request en cours (si c'est une requete HTTP)
        /// sinon renvoi "QXP IP"
        /// </summary>
        public static string Current_IP
        {
            get
            {
                if (Validation.IsNotNull(Current_HTTPIPAccess))
                {
                    return Current_HTTPIPAccess.IP;
                }
                else
                {
                    return IP_SENDER;
                }
            }
        }



        /// <summary>
        /// Retourne les informations sur l'IP du client qui emet la requete HTTP
        /// </summary>
        public static HTTP_IP_Access Current_HTTPIPAccess
        {
            get 
            {
                if (HttpContext.Current != null)
                {
                    return new HTTP_IP_Access(HttpContext.Current.Request);
                }
                else
                {
                    return null;
                }
                   
            }
        }

        /// <summary>
        /// Permet d'obtenir la page de la request en cours (si c'est une requete HTTP)
        /// sinon renvoi "Application Console"
        /// </summary>
        public static string Current_Page
        {
            get
            {
                if (HttpContext.Current != null)
                {
                    return HttpContext.Current.Request.FilePath;
                }
                return APPLICATION;
            }
        }

        #endregion Propri�t�s
    }

    /// <summary>
    /// Class HTTP_IP_Access : Repr�sente une IP cliente
    /// </summary>
    /// <author>LCU</author>
    /// <date>29/04/2010</date>    
    public class HTTP_IP_Access
    {
        #region Membres

        string __ip_http_x_forwarded_for = null;
        string __ip_remote_addr = null;
        IPSource __ipSource = IPSource.REMOTE_ADDR;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        public enum IPSource
        {
            /// <summary>
            /// Source de l'entete HTTP d�finit par le champs HTTP_X_FORWARDED_FOR
            /// </summary>
            HTTP_X_FORWARDED_FOR,
            /// <summary>
            /// Source de l'entete HTTP d�finit par le champs REMOTE_ADDR
            /// </summary>
            REMOTE_ADDR
        }

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de HTTP_IP_Access
        /// </summary>
        /// <param name="request">Request HTTP</param>
        public HTTP_IP_Access(HttpRequest request)
        {
            GetIP(request);
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Recup�re les adresses IPs dans la request
        /// </summary>
        /// <param name="request">Request HTTP</param>
        private void GetIP(HttpRequest request)
        {
            string __http_x_forwarded_for = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            string __userHostAddress = HttpContext.Current.Request.UserHostAddress; //�quivalent � Request.ServerVariables("REMOTE_ADDR")

            if (Validation.IsSet(__http_x_forwarded_for) && __http_x_forwarded_for != "unknown")
            {
                //Dans le cas o� l'utilisateur a �t� forward� (par des proxy de redirection par exemple)
                //Dans ce cas la on a : "@IP_DU_CLIENT, @IP_EQUIPEMENT, ..."
                string __remoteIP = (__http_x_forwarded_for.Split(','))[0].Trim();

                if (Validation.IsSet(__remoteIP))
                {
                    __ip_http_x_forwarded_for = __remoteIP;
                    __ipSource = IPSource.HTTP_X_FORWARDED_FOR;
                }
            }

            __ip_remote_addr = HttpContext.Current.Request.UserHostAddress;

        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Adresse IP
        /// </summary>
        public string IP
        {
            get
            {
                if (Validation.IsSet(__ip_http_x_forwarded_for))
                {
                    return __ip_http_x_forwarded_for;
                }
                else
                {
                    return __ip_remote_addr;
                }
            }
        }

        /// <summary>
        /// Retourne la source de l'@IP retourn�e par la propri�t� IP 
        /// (la source correspond au champ de l'entete HTTP utilis�e pour r�cup�rer l'@IP)
        /// </summary>
        public IPSource IPSrc
        {
            get { return __ipSource; }
        }

        /// <summary>
        /// Adresse IP contenu dans le champ HTTP_X_FORWARDED_FOR de l'entete HTTP
        /// </summary>
        public string IP_HTTP_X_Forwarded_For
        {
            get { return __ip_http_x_forwarded_for; }
        }

        /// <summary>
        /// Adresse IP contenu dans le champ REMOTE_ADDR de l'entete HTTP
        /// </summary>
        public string IP_Remote_Addr
        {
            get { return __ip_remote_addr; }
        }


        #endregion Propri�t�s
    }


}
