using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;

namespace QXP.Framework.Xml 
{
    public class XmlTransformation 
    {
        /// <summary>
        /// Permet d'appliquer une transformation XSLT � une structure XML
        /// </summary>
        /// <param name="xml">La structure xml en entr�e</param>
        /// <param name="XslFullFileName">la feuille de style xsl � utiliser.</param>
        /// <returns>la chaine resultant de la transformation</returns>
        public static string Transform(string xml, string XslFullFileName)
        {
            if(Validation.IsNotSet(xml))                return string.Empty;
            if(Validation.IsNotSet(XslFullFileName))    return xml;
            StringWriter			__writer		= new StringWriter();
			XslCompiledTransform	__transformer	= new XslCompiledTransform();
			XmlReader				__xsl			= null;

            try
            {
                XPathDocument           __doc           = new XPathDocument(new StringReader(xml));

                XmlReaderSettings __xslSettings = new XmlReaderSettings();
                __xslSettings.ProhibitDtd = false;

                __xsl = XmlReader.Create(XslFullFileName, __xslSettings);

                __transformer.Load(XslFullFileName);

                __transformer.Transform(__doc, null, __writer);

            }finally{
				
				//Permet de lib�rer le flux
				if (Validation.IsNotNull(__xsl))
				{
					__xsl.Close();
				}
            }

            return __writer.ToString();
        }

        /// <summary>
        /// Permet d'appliquer une transformation XSLT � une structure XML. 
        /// </summary>
        /// <param name="xml">La structure xml en entr�e</param>
        /// <param name="XslFullFileName">la feuille de style xsl.</param>
		/// <param name="xsltArgument">liste d'argument passer � la premi�re transformation, si null aucun argument.</param>
        /// <param name="resultStream">le flux r�sultant de la transformation</param>
		public static void Transform(string xml, string XslFullFileName, XsltArgumentList xsltArgument, Stream resultStream)
		{
			if (Validation.IsNotSet(xml))
				return;
			if (Validation.IsNotSet(XslFullFileName))
				return;
			if (Validation.IsNull(resultStream))
				return;
			StringWriter			__writer = new StringWriter();
			XslCompiledTransform	__transformer = new XslCompiledTransform();
			XmlReader				__xsl = null;
			try
			{

				XPathDocument __doc = new XPathDocument(new StringReader(xml));

				XmlReaderSettings __xslSettings = new XmlReaderSettings();
				__xslSettings.ProhibitDtd = false;

				__xsl = XmlReader.Create(XslFullFileName, __xslSettings);

				__transformer.Load(__xsl);

				__transformer.Transform(__doc, xsltArgument, resultStream);

			}
			catch (Exception ex)
			{
				Diagnostic.Log.LogError("XmlTransformation.Transform", ex);

			}
			finally
			{
				//Permet de lib�rer le flux
				if (Validation.IsNotNull(__xsl))
				{
					__xsl.Close();
				}
			}
		}
		/// <summary>
		/// Effectue une transformation XSL en utilisant un XML Resolver pour d�terminer l'origine des feuilles XSL.
		/// </summary>
        /// <param name="xml">La structure xml en entr�e</param>
        /// <param name="XslFullFileName">la feuille de style xsl initiale.</param>
		/// <param name="xsltArgument">liste d'argument passer � la premi�re transformation, si null aucun argument.</param>
		/// <param name="resolver">la class permettant de retrouver les transformations incluses</param>
        /// <param name="resultStream">le flux r�sultant de la transformation</param>
		/// <remarks>
		/// toutes les sources (xslt) de transformation sont �valu�es par le resolver qui d�fini le contenu de la transformation.
		/// Le resolver recoit un URI est �value le contenu de la transformation. chaque feuille de style xslt inclues dans le document est ainsi �valu�s.  
		/// </remarks>
		public static void TransformWithResolver(string xml, string XslFullFileName, XsltArgumentList xsltArgument, XmlResolver resolver, Stream resultStream)
		{
			if(Validation.IsNotSet(xml))                return;
            if(Validation.IsNotSet(XslFullFileName))    return;
            if(Validation.IsNull(resultStream))         return;
            StringWriter			__writer		= new StringWriter();
			XslCompiledTransform	__transformer	= new XslCompiledTransform();
			XmlReader				__xsl			= null;
            try
            {

                XPathDocument           __doc             = new XPathDocument(new StringReader(xml));

                XmlReaderSettings __xslSettings = new XmlReaderSettings();
                __xslSettings.ProhibitDtd = false;
				__xslSettings.XmlResolver = resolver;

                __xsl = XmlReader.Create(XslFullFileName, __xslSettings);

                __transformer.Load(__xsl, null, resolver);

                __transformer.Transform(__doc, xsltArgument, resultStream);

            }
            catch(Exception ex)
            {
                Diagnostic.Log.LogError("XmlTransformation.TransformWithResolver", ex);
            }
			finally
			{
				//Permet de lib�rer le flux
				if (Validation.IsNotNull(__xsl))
				{
					__xsl.Close();
				}
			}					
		}
    }
}
