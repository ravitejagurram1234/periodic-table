using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Reflection;
using System.Xml;

using QXPFrk = QXP.Framework;

/* 
 * Code g�n�r� avec le template : QXPBusinessClass
*/
namespace QXP.Framework.Xml
{
	/// <summary>
	/// Fournit les fonctions permattant d'�valuer le contenu xslt utilis� pendant une transformation xml.
	/// Ce resolver charge des fichiers xslt incorpor� dans une assembly
	/// </summary>
	/// <author>doufarm</author>
	/// <date>17/01/2012 17:11:30</date>    
	public class EmbeddedResourceXmlResolver : XmlUrlResolver
	{
		#region Membres
		private Assembly	_assembly;
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de EmbeddedResourceXmlResolver.
		/// Les ressources xslt seront r�cup�r�s dans l'assembly framework
		/// </summary>
		public EmbeddedResourceXmlResolver()
		{
			_assembly = Assembly.GetExecutingAssembly();
		}

		/// <summary>
		/// Cr�e une instance de EmbeddedResourceXmlResolver
		/// </summary>
		/// <param name="assembly">Les ressources xslt seront r�cup�r�s dans l'assembly pass�e.</param>
		public EmbeddedResourceXmlResolver(Assembly assembly)
		{
			_assembly = assembly;
		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// Retourne le flux du fichier xslt demand� par absoluteUri
		/// </summary>
		/// <param name="absoluteUri">le chemin du fichier xslt n�cessaire.</param>
		/// <param name="role">le role .net de l'utilisateur (non utilis�).</param>
		/// <param name="ofObjectToReturn">Le type de retour demand� (non utilis�).</param>
		/// <returns>nous retournons syst�matiquement un flux (stream).</returns>
		public override object GetEntity(Uri absoluteUri, string role, Type ofObjectToReturn)
		{
			Stream __s = _assembly.GetManifestResourceStream(GetResourcePath(absoluteUri.Segments[absoluteUri.Segments.Length - 1]));
			return __s;
		}

		/// <summary>
		/// Evaluation du chemin de ressource du fichier demand�.
		/// Cette �valuation tient compte de EmbeddedResourcePrefix s'il est d�fini.
		/// </summary>
		/// <param name="fileName">le nom du fichier. </param>
		/// <returns>Le nom complet de la ressource.</returns>
		private string GetResourcePath(string fileName)
		{
			return string.Concat(this.EmbeddedResourcePrefix, fileName);
		}

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Le pr�fix � ajouter au nom de fichier de la ressource (ex "QXP.Generateur.Ressources.Generateur.XSL.") termin� par un point.
		/// sinon null ou string.empty, dans ce cas le nom du fichier doit �tre complet.
		/// </summary>
		public string EmbeddedResourcePrefix
		{
			get;
			set;
		}

		#endregion Propri�t�s
	}
}
