using System;
using System.Collections;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Collections.Generic;

using Cells							= Aspose.Cells;

using QXPDiagnostic					= QXP.Framework.Diagnostic;
using QXP.Framework.Excel;
using QXP.Framework.Excel.Helper;
using QXP.Framework.Graph.Colors;
using QXP.Framework.Data.Oracle;
using QXP.Framework.Data;
using QXP.Framework.Data.Format;

namespace QXP.Framework.Graph.XLSCharts
{
	/// <summary>
	/// D�finit un graphique excel QXP
	/// </summary>
	public abstract class  XLSChart
    {
        #region Membres

        private Graph                       _graph;
        private Cells.Charts.Chart					_chartExcel;		
		private SerieList					_series;		
		private bool						_showTitle;
		private string						_strNomAxisX;
		private string						_strNomAxisY;
		private bool						_boolIsShowXTitle;
		private bool						_boolIsShowYTitle;
		private string						_titleAxisX;		
		private string						_titleAxisY;
		private bool						_showPointValue;
		private decimal						_showPointValue_Min			= decimal.MinValue;
		private bool						_showPointValue_Min_Strict	= false;
		private bool						_isShowLegend;
		private int							_width = int.MinValue;		
		private int							_height = int.MinValue;
		private	Cells.Charts.LegendPositionType	_legendPosition;
		private string						_title;
		private ExcelSerieLocation			_excelSerieLocation;
		private bool						_display_X_Grid		= false;
		private bool						_display_Y_Grid		= false;
        private Queue<Colors.Gcolor>        _queueLinePalette = null;
        private Queue<Colors.Gcolor>        _queueFillingPalette = null;

		#endregion

        #region Constantes

	    private const int DEFAULT_SIZE_FONT_TITLE           = 9;
        private const int DEFAULT_SIZE_FONT_TEXT            = 8;
        private const int DEFAULT_SIZE_FONT_LEGEND          = 8;
        private const int DEFAULT_ROTATION_POINTVALUE       = 0; //en degr�

		//Repr�sente une valeur sp�ciale d'une cellule excel permettant au graphe excel d'ignorer la valeur de la cellule.
		//permet aux COURBES excel de ne pas se briser sur des cellules vides.
		protected const string				NA_VALEUR	    = "#N/A";

		//Repr�sente une valeur null dans une cellule excel � utiliser pour certains type de graph ex:camember, histo
		protected const string				NULL_VALEUR     = "";

        private const int					DEFAULT_WIDTH   = 600;
		private const int					DEFAULT_HEIGHT  = 400;		

        #endregion Constantes

        #region Enums
        #endregion Enums
		
		#region Constructeur
		
		/// <summary>
		/// Constructeur du graphique excel
		/// </summary>
		public XLSChart(Graph graph)
		{
			this._graph					    = graph;			
			
			this.Width				        = graph.Width;
			this.Height				        = graph.Height;
			this.Title				        = graph.Title;		
			this.IsShowTitle		        = graph.IsShowTitle;			
			this.IsShowLegend		        = graph.IsShowLegend;
			this.LegendPosition		        = graph.LegendPosition;
			this.Series				        = graph.Series;		

			this.NameAxisX			        = graph.NameAxisX;
			this.NameAxisY			        = graph.NameAxisY;
			this.IsShowXTitle		        = graph.IsShowXTitle;
			this.IsShowYTitle		        = graph.IsShowYTitle; 
			this.TitleAxisX			        = graph.TitleAxisX;
			this.TitleAxisY			        = graph.TitleAxisY;
			this.ShowPointValue				= graph.ShowPointValue;
			this.ShowPointValue_Min			= graph.ShowPointValue_Min;
			this.ShowPointValue_Min_Strict	= graph.ShowPointValue_Min_Strict;
			this.ExcelSerieLocation	        = graph.ExcelSerieLocation;
			this.Display_X_Grid		        = graph.Display_X_Grid;
			this.Display_Y_Grid		        = graph.Display_Y_Grid;
            
            this._queueLinePalette           = new Queue<Gcolor>(graph.Series.GcolorSeries.Palette.LinePalette);
            this._queueFillingPalette        = new Queue<Gcolor>(graph.Series.GcolorSeries.Palette.FillingPalette);

		}

		#endregion

		#region Methodes

		/// <summary>
		/// Ajoute les donn�es n�cessaires � la g�n�ration du graphique sur la feuille sheetNameData (� la ligne et colonne voulue)
		/// puis g�n�re le graphique dans l'objet ChartExcel
		/// </summary>
		/// <param name="XLSWorkBook">Classeur Excel conteneur</param>
		/// <param name="sheetNameData">Nom de la feuille sur laquelle les datas vont �tre ins�r�es</param>
		/// <param name="ligne">Ligne de d�part</param>
		/// <param name="colonne">Colonne de d�part</param>
		public void PrepareDataAndDrawIT(XLSWorkbook XLSWorkBook, string sheetNameData, int ligne, int colonne)
		{		
			XLSWorkBook.Layout.Coordonnees.Ligne.Value		= ligne;
			XLSWorkBook.Layout.Coordonnees.Colonne.Value	= colonne;
			this.PrepareDataAndDrawIT(XLSWorkBook, sheetNameData);
		}

		/// <summary>
		/// Ajoute les donn�es n�cessaires � la g�n�ration du graphique sur la feuille sheetNameData (� la ligne et colonne voulue)
		/// puis g�n�re le graphique dans l'objet ChartExcel
		/// </summary>
		/// <param name="XLSWorkBook">Classeur Excel conteneur</param>
		/// <param name="sheetNameData">Nom de la feuille sur laquelle les datas vont �tre ins�r�es</param>
		public void PrepareDataAndDrawIT(XLSWorkbook xlsWorkbook, string sheetNameData)
		{
            if (this.ExcelSerieLocation == ExcelSerieLocation.InHideSeparateWorkSheet)
            {
                //Anciennement = false, ceci est provisoire, c'est un besoin pour les FCPE, plus tard rajouter l'option au niveau du rapport.
                xlsWorkbook.Feuille_Courante.Worksheet.IsVisible = true;
            }

            //D�finit les param�tres g�n�raux du graphique (titre, couleurs...)
            DefineChartTemplate(xlsWorkbook);

            if (this.Series.Count > 0)
            {
                //La feuille courante devient la feuille o� les tableaux de donn�es excel seront ins�r�s

                xlsWorkbook.Layout.LigneSuivante();
                xlsWorkbook.Layout.DebutRow();

                Color __color = XLSHelper.GetColor(XLSColor.EnumXLSColor.CustomizeOrange);

                XLSRangeValues __xlsRangeValues = new XLSRangeValues(sheetNameData);

                Cells.Cell __cell = xlsWorkbook.Cellule_Courante;

                xlsWorkbook.Layout.ColonneSuivante();

                //Ajout des noms des serie
                List<string> __listSerieName = this.Series.GetSerieLabels();

                foreach (string serieName in __listSerieName)
                {
                    __cell = xlsWorkbook.Cellule_Courante;
                    XLSHelper.AddContent(__cell, new QXP_Value<string>(serieName, QXP_Value_Format_Helper.Create_QXP_Format_String()) ,  "left", __color, Color.White, 10, true, false);
                    xlsWorkbook.Layout.ColonneSuivante();
                }

                xlsWorkbook.Layout.Coordonnees.Colonne.Value = 1;
                


                int __ligneCellSerie = xlsWorkbook.Ligne_Courante;
                int __colCellSerie = xlsWorkbook.Colonne_Courante;

                xlsWorkbook.Layout.LigneSuivante();


                int __ligneDebut = xlsWorkbook.Layout.Coordonnees.Ligne.Value;

                // Cellules de d�part des s�ries de donn�es
                __xlsRangeValues.CategoryStartCell = Cells.CellsHelper.CellIndexToName(xlsWorkbook.Ligne_Courante, xlsWorkbook.Colonne_Courante);

                //On r�cup�re les valeurs
                List<IQXP_Value> __XValues = (List<IQXP_Value>)this.Series.GetLabelsAxisX();

                // Ajout des valeurs de l'axe des abcisses
                foreach (IQXP_Value __xValue in __XValues)
                {
                    __color = XLSHelper.GetColor(XLSColor.EnumXLSColor.CustomizeOrange);
                    __cell = xlsWorkbook.Cellule_Courante;
                    XLSHelper.AddContent(__cell, __xValue, "left", __color, Color.White, 10, true, false);
                    xlsWorkbook.Layout.LigneSuivante();
                }

                __xlsRangeValues.CategoryEndCell = Cells.CellsHelper.CellIndexToName(xlsWorkbook.Ligne_Courante - 1, xlsWorkbook.Colonne_Courante);

                //xlsWorkbook.Coordonnees_Courante.ResetColonneToMinZone();
                xlsWorkbook.Layout.Coordonnees.Colonne.Value = 1;


                //Ajout des valeurs des ordonn�es de chaque s�rie (attention l'ordre des donn�es des axes des abcisses doit etre identique pour toutes les s�ries)
                foreach (Serie __serie in this.Series.Values)
                {
                    xlsWorkbook.Layout.Coordonnees.Ligne.Value = __ligneDebut;
                    xlsWorkbook.Layout.ColonneSuivante();

                    //On r�cup�re les valeurs de la s�rie				
                    List<IQXP_Value> __YValues = (List<IQXP_Value>)__serie.GraphValues.Get_Y_Values_IQXPValues();

                    __xlsRangeValues.ValuesStartCell = Cells.CellsHelper.CellIndexToName(xlsWorkbook.Ligne_Courante, xlsWorkbook.Colonne_Courante);

                    __color = XLSHelper.GetColorRow(xlsWorkbook);

                    // Ajout des donn�es qui vont �tre utiliser pour binder le graphique
                    foreach (IQXP_Value __yValue in __YValues)
                    {
                        __cell = xlsWorkbook.Cellule_Courante;
                        
                        //Permet une courbe non discontinu si valeur null
                        if (Validation.IsNotSet(__yValue.Value))
                        {
                            XLSHelper.AddContent(__cell, new QXP_Value<string>(NA_Null_Value, QXP_Value_Format_Helper.Create_QXP_Format_String()), "center", __color, Color.Black, 10, false, false);
                        }
                        else
                        {
                            XLSHelper.AddContent(__cell, __yValue, "center", __color, Color.Black, 10, false, false);
                        }
                        xlsWorkbook.Layout.LigneSuivante();
                    }                    
                    
                    xlsWorkbook.Feuille_Courante.Largeur_Auto_Colonne_Courante();

                    __xlsRangeValues.ValuesEndCell = Cells.CellsHelper.CellIndexToName(xlsWorkbook.Ligne_Courante - 1, xlsWorkbook.Colonne_Courante);

                    //Ajout de la s�rie
                    int __indexSerie = _chartExcel.NSeries.Add(__xlsRangeValues.ValuesRangeCells, true);

                    //D�finit le style de la s�rie
                    DefineSerieTemplate(_chartExcel.NSeries[__indexSerie], __serie);

                }

                //Ajoute la d�finition de l'axe des abcisses
                _chartExcel.NSeries.CategoryData = __xlsRangeValues.CategoryRangeCells;

            }
		}

		/// <summary>
		/// D�finit le template d'une s�rie Aspose
		/// </summary>
		/// <param name="aSerie">S�rie Aspose (Excel)</param>
		/// <param name="serie">S�rie FrameWork QXP</param>
		protected virtual void DefineSerieTemplate(Cells.Charts.Series aSerie, Serie serie)
		{
			aSerie.Name = serie.Label;
			aSerie.XValues = null;

			//Affichage des valeurs de chaque point du graphique
			if (this.ShowPointValue)
			{
                
				aSerie.DataLabels.TextFont.Size         = DEFAULT_SIZE_FONT_TEXT;
				aSerie.DataLabels.Rotation		        = DEFAULT_ROTATION_POINTVALUE;
                aSerie.DataLabels.NumberFormatLinked    = true;

				//Si une valeur minimum est d�finie alors on affcihe que les points ayant une valeur sup�rieure ou �gale � cette valeur
				if(Validation.IsSet(this.ShowPointValue_Min, true))
				{
					//try catch r�alis� nous nous basons sur les valeurs des series et nous modifions les propri�t�s des points de la s�rie
					//on se sait jamais si excel �value un nombre de points diff�rents !!
					try
					{
						for (int __i = 0; __i < serie.GraphValues.Count; __i++)
						{
							decimal					__value = (decimal) serie.GraphValues[__i].Y.Value;
							bool					__show;
							if(this.ShowPointValue_Min_Strict)
							{
								__show = (__value > this.ShowPointValue_Min);
							}
							else
							{
								__show = (__value >= this.ShowPointValue_Min);
							}
							aSerie.Points[__i].DataLabels.IsValueShown = __show;
						}
					}
					catch
					{
					
					}
				}else
				{
					//sinon toutes les etiquettes sont affich�es.
					aSerie.DataLabels.IsValueShown          = true;
				}
			}

			aSerie.Type = this.ChartType;
		    
		}

		/// <summary>
		/// D�finit le template du graphique
		/// </summary>
		/// <param name="xlsWorkBook">Classeur Excel conteneur</param>
		protected virtual void DefineChartTemplate(XLSWorkbook xlsWorkBook)
		{
			#region G�om�trie du graph
			_chartExcel.ChartObject.Width				= this.Width;
			_chartExcel.ChartObject.Height				= this.Height;	
			_chartExcel.Placement						= Cells.Drawing.PlacementType.FreeFloating;
		
			#endregion G�om�trie du graph

			#region Affichage du graph
			// Zone de dessin du graphique
            _chartExcel.PlotArea.Border.IsVisible		= false;
			_chartExcel.PlotArea.Area.ForegroundColor	= Color.Transparent;
            // Les donn�es ne sont pas affich�es
            _chartExcel.IsDataTableShown				= false;		
			//Bordure du graphique
            _chartExcel.ChartArea.Border.Color			= Color.Black;	
			#endregion Affichage du graph

			#region Titre du graphique

			//INFO: il ne faut pas manipuler _chartExcel.Title si pas de titre sinon il(excel) affiche un titre par d�faut. 
			if (this.IsShowTitle && Validation.IsSet(this.Title))
            {
				_chartExcel.Title.Text						= this.Title;
				//Font du titre
				_chartExcel.Title.TextFont.Color			= Color.Black;
				_chartExcel.Title.TextFont.IsBold			= true;
				_chartExcel.Title.TextFont.Size				= DEFAULT_SIZE_FONT_TITLE;
			}
			
			#endregion Titre du graphique

			#region L�gende

			//Affichage de la l�gende
			_chartExcel.IsLegendShown					= this.IsShowLegend;
			_chartExcel.Legend.TextFont.Size			= DEFAULT_SIZE_FONT_LEGEND;
			_chartExcel.Legend.Position					= this._legendPosition;
            _chartExcel.Legend.Border.IsVisible			= false;

			#endregion L�gende

			#region Grille
			
			_chartExcel.CategoryAxis.MajorGridLines.IsVisible		= 
                _chartExcel.ValueAxis.MajorGridLines.IsVisible = false;		   

			// on affiche pas les marques interm�diaire sur l'axe
			_chartExcel.CategoryAxis.MinorTickMark				= Cells.Charts.TickMarkType.None;
			_chartExcel.CategoryAxis.MinorGridLines.IsVisible	= false;
			_chartExcel.CategoryAxis.MajorGridLines.Style		= Cells.Drawing.LineType.Dot;
			_chartExcel.CategoryAxis.MajorGridLines.Color		= Color.Black;
			_chartExcel.CategoryAxis.MajorGridLines.IsVisible	= this.Display_X_Grid;

			#endregion Grille
			
			#region Axes du graphique

			#region Axes X Abcisses (CategoryAxis)

			//Affichage du titre des axes des abcisses
			if (this.IsShowXTitle)
				this._chartExcel.CategoryAxis.Title.Text= this.TitleAxisX;
			
			_chartExcel.CategoryAxis.TickLabelPosition	= Aspose.Cells.Charts.TickLabelPositionType.Low;

			//Li� indirectement au FCPE, on r�applique le formatage des donn�es en fonction du type
			//de donn�es, pour les fcpe le formatage de la date sur 2 ann�es n'�taient pas pris en compte		
            _chartExcel.CategoryAxis.TickLabels.NumberFormat = XLSFormatHelper.Get_XLS_Custom_Format(Graph.QXP_Format_X);

			//Police du texte affich� sur l'axe des abcisses et des ordonn�es
            _chartExcel.CategoryAxis.TickLabels.Font.Size       = DEFAULT_SIZE_FONT_TEXT;

			//Permet de forcer l'affichage des valeurs de l'axe des X en horizontal
			//Cela permet � Excel d'�valuer plus justement les intervals
			//Cette propri�t� sera param�trable dans un proche avenir !
			_chartExcel.CategoryAxis.TickLabels.Rotation		= 0;

			#endregion Axes X Abcisses (CategoryAxis)

			#region Axes Y Ordonn�es (ValueAxis)

			//Affichage du titre des axes des ordonn�es
			if (this.IsShowYTitle)
				this._chartExcel.ValueAxis.Title.Text	= this.TitleAxisY;

			
			_chartExcel.ValueAxis.TickLabels.Font.Size          = DEFAULT_SIZE_FONT_TEXT;

			// on affiche pas les marques interm�diaire sur l'axe
			_chartExcel.ValueAxis.MinorTickMark					= Cells.Charts.TickMarkType.None;
			_chartExcel.ValueAxis.MinorGridLines.IsVisible		= false;
			_chartExcel.ValueAxis.MajorGridLines.Style			= Cells.Drawing.LineType.Dot;
			_chartExcel.ValueAxis.MajorGridLines.Color			= Color.Black;
			_chartExcel.ValueAxis.MajorGridLines.IsVisible		= this.Display_Y_Grid;

			#endregion Axes Y Ordonn�es (ValueAxis)

			//D�finition des limites inf�rieur et sup�rieur de l'axe des Y
			this.DefineGraphRanges();
			
			#endregion Axes du graphique            
		}

		/// <summary>
		/// Permet de d�finir les bornes min et max du graphique
		/// </summary>
		protected virtual void DefineGraphRanges()
		{
            if (_series.Count > 0)
            {
				AxisRange __axisRange_Y = this.Graph.AxisRange_Y;

				if(Validation.IsNotNull(__axisRange_Y))
                {
					decimal __axisMinValue	= __axisRange_Y.New_Min;
					decimal __axisMaxValue	= __axisRange_Y.New_Max;
					double	__step			= (double)__axisRange_Y.Step;

					
					//Mise � jour pour les cas Excel !
					// Si le type est pourcentage alors la valeur est divis� par 100 (ceci est historique) car toute les sources de donn�e * 100 les type pourcentage
					if(Graph.QXP_Format_Y.Is_Percent)
					{
						__axisMinValue	= __axisMinValue / 100;
						__axisMaxValue	= __axisMaxValue / 100;
						__step			= __step / 100;
					}

					_chartExcel.ValueAxis.MinValue = __axisMinValue;
					_chartExcel.ValueAxis.MaxValue = __axisMaxValue;

					_chartExcel.ValueAxis.MinorUnit = _chartExcel.ValueAxis.MajorUnit = __step;

					if (Validation.IsNotSet(Graph.QXP_Format_Y.Number_Nb_Decimal))
					{
						Graph.QXP_Format_Y.ChangeNbDecimal(__axisRange_Y.NbDecimal);
					}
					
					//Pour rester coh�rent avec l'axe des abcisses, on effectue le m�me traitement sur l axe des ordonn�es
					_chartExcel.ValueAxis.TickLabels.NumberFormat = XLSFormatHelper.Get_XLS_Custom_Format(Graph.QXP_Format_Y);


				}
            }
		}


		#endregion Methodes

		#region Properties

		public		abstract Cells.Charts.ChartType	ChartType{get;}

        protected Graph Graph
        {
            get { return _graph; }
            set { _graph = value; }
        }

		protected	abstract bool		Enabled3D{get;}

		/// <summary>
		/// Chaine � affecter lorsque la cellule n'a pas de valeur
		/// Change en fonction du type de graphe
		/// </summary>
		protected	virtual string		NA_Null_Value
		{
			get{ return NA_VALEUR;}
		}

		public		Cells.Charts.Chart			ChartExcel
		{
			get { return _chartExcel ; }
			set { _chartExcel = value; }
		}

		public		int					Width
		{
			get 
			{ 
				if(Validation.IsNotSet(this._width))
					this._width = DEFAULT_WIDTH;
				return this._width; 
			}
			set { this._width = value; }
		}

		public		int					Height
		{
			get 
			{ 
				if(Validation.IsNotSet(this._height))
					this._height = DEFAULT_HEIGHT;
				return this._height; 
			}
			set { this._height = value; }
		}

		public		bool				IsShowTitle
		{
			get	{ return _showTitle; }				
			set	{ _showTitle = value; }
		}

		public		string				Title
		{
		    set
		    {
				this._title = value;
		    }

		    get { return this._title; }
		}
		
		public		bool				IsShowLegend
		{
		    get{ return this._isShowLegend; }
		    set{ this._isShowLegend = value; }
		}

		public		PositionLegende		LegendPosition
		{
			
		    set
		    {
		        switch (value)
		        {
		            case PositionLegende.Top:
		                this._legendPosition = Cells.Charts.LegendPositionType.Top;
		                break;
		            case PositionLegende.Bottom:
		                this._legendPosition = Cells.Charts.LegendPositionType.Bottom;
		                break;
		            case PositionLegende.Left:
		                this._legendPosition = Cells.Charts.LegendPositionType.Left;
		                break;
		            case PositionLegende.Right:
		            default:
		                this._legendPosition = Cells.Charts.LegendPositionType.Right;
		                break;
		        }
		    }
		}
	
		public		SerieList			Series
		{
			get { return _series; }
			set { _series = value; }
		}
		
		public		string				NameAxisX
		{
			get{return this._strNomAxisX;}
			set{this._strNomAxisX = value;}
		}

		public		string				NameAxisY
		{
			get{return this._strNomAxisY;}
			set{this._strNomAxisY = value;}
		}

		public		bool				IsShowXTitle
		{
			get{return this._boolIsShowXTitle;}
			set{this._boolIsShowXTitle = value;}
		}

		public		bool				IsShowYTitle
		{
			get{return this._boolIsShowYTitle;}
			set{this._boolIsShowYTitle = value;}
		}	
	
		public		string				TitleAxisX
		{
			get{return this._titleAxisX;}
			set{this._titleAxisX = value;}
		}

		public		string				TitleAxisY
		{
			get{return this._titleAxisY;}
			set{this._titleAxisY = value;}
		}

		/// <summary>
		/// Afficher les etiquettes des valeurs des points
		/// </summary>
		public		bool				ShowPointValue
		{
			get { return _showPointValue; }
			set { _showPointValue = value; }
		}

		/// <summary>
		/// D�fini la limite � partir de laquelle les etiquettes des valeurs Y sont affich�es
		/// voir la propri�t� ShowPointValue_Min_Strict pour savoir si cette limit est stricte ou pas
		/// si cette valeurs est �gale � decimal.MinValue toutes les etiquettes sont affich�es.
		/// </summary>
		public		decimal				ShowPointValue_Min
		{
			get { return _showPointValue_Min; }
			set { _showPointValue_Min = value; }
		}
		
		/// <summary>
		/// D�fini Le faite que la valeur de ShowPointValue_Min correspond � une limite stricte
		/// si ShowPointValue_Min_Strict est true alors les valeurs doivent �tre strictement sup�rieur � ShowPointValue_Min
		/// sinon les valeurs doivents �tre sup�rieures ou �gales.
		/// par d�faut (false) c'est � dire sup�rieure ou �gale.
		/// </summary>
		public		bool				ShowPointValue_Min_Strict
		{
			get { return _showPointValue_Min_Strict; }
			set { _showPointValue_Min_Strict = value; }
		}

		public		ExcelSerieLocation	ExcelSerieLocation
        {
            get { return this._excelSerieLocation; }
            set { this._excelSerieLocation = value; }
        }
		        
		/// <summary>
		/// Permet de sp�cifi� si la grille de l'axe des X est affich�e
		/// </summary>	
		public		bool				Display_X_Grid
		{
			get { return _display_X_Grid; }
			set { _display_X_Grid = value; }
		}

		/// <summary>
		/// Permet de sp�cifi� si la grille de l'axe des Y est affich�e
		/// </summary>	
		public		bool				Display_Y_Grid
		{
			get { return _display_Y_Grid; }
			set { _display_Y_Grid = value; }
		}

        /// <summary>
        /// Palette de couleur � utiliser pour les lignes/points des graphiques
        /// A chaque besoin d'une couleur, on d�pile la QueueLinePalette
        /// </summary>
        protected Queue<Colors.Gcolor> QueueLinePalette
        {
            get { return _queueLinePalette; }
            set { _queueLinePalette = value; }
        }
        
        /// <summary>
        /// Palette de couleur � utiliser pour le remplissage de graphiques (camembert, histogramme...)
        /// A chaque besoin d'une couleur, on d�pile la QueueFillingPalette
        /// </summary>
        protected Queue<Colors.Gcolor> QueueFillingPalette
        {
            get { return _queueFillingPalette; }
            set { _queueFillingPalette = value; }
        }

		#endregion Properties

		
	}
	

}

