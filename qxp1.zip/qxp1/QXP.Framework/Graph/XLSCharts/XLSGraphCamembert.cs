using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using QXPFrk = QXP.Framework;
using System.Collections;
using Cells	= Aspose.Cells;

namespace QXP.Framework.Graph.XLSCharts
{
	/// <summary>
	/// Graphique Camembert Excel
	/// </summary>
    public class XLSGraphCamembert : XLSChart
	{
		#region Membres

		private Cells.Charts.ChartType		_chartType;
		private bool?				_enabled3D = null;

		#endregion Membres

        #region Constructeur
		
        public XLSGraphCamembert(Graph graphDefinition) : base(graphDefinition)
        {
			if (this.Series.Count > 1)
				throw new Exception("Impossible de g�n�rer le graphique Excel Camembert avec plus d'une s�rie de donn�e");

			//Inutile, cela est fait automatiquement et si le showpointvalue = true le texte dans la l�gende est erron�
			//this.ShowPointValue = false;
            
			if(Enabled3D)
                this._chartType = Cells.Charts.ChartType.Pie3D;
            else
                this._chartType = Cells.Charts.ChartType.Pie;

        }
		
        #endregion Constructeur

		#region Propri�t�s

		public override Cells.Charts.ChartType ChartType
        {
            get { return this._chartType;}
        }

		protected override bool Enabled3D
		{
			get
			{
				return GraphHelper.GetEnabled3D(GraphType.GraphCamembert);
			}
		}

		protected override string NA_Null_Value
		{
			get{return NULL_VALEUR;}
		}

        #endregion propri�t�s

        #region M�thodes

        /// <summary>
        /// Permet de d�finir les bornes min et max du graphique
        /// </summary>
        protected override void DefineGraphRanges()
        {
			//Pas de d�finition de range n�cessaire dans le cas de camenbert !!
		}

		/// <summary>
		/// D�finit le template d'une s�rie Aspose
		/// </summary>
		/// <param name="aSerie">S�rie Aspose (Excel)</param>
		/// <param name="serie">S�rie FrameWork QXP</param>
        protected override void DefineSerieTemplate(Cells.Charts.Series aSerie, Serie serie)
        {
            base.DefineSerieTemplate(aSerie, serie);
            
            int __i = 0;

            //Le cambert est forc�ment compos� d'une s�rie, on v�rifie des valeurs ont �t� associ�es aux labels de la s�rie
            //Les couleurs associ�es sont stock�es dans les GcolorValues
            serie.GraphValues.ForEach
            (
                delegate(GraphValue __graphValue)
                {
                    //On recherche le label dans les graphvalues, s'il est pr�sent, on set la couleur
                    if(Validation.IsNotNull(__graphValue.Gcolor))
                    {
                            aSerie.Points[__i++].Area.ForegroundColor = __graphValue.Gcolor.Color;
                    }
                    else
                    {
                        if (Validation.IsSet(base.QueueFillingPalette))
                        {
                            //Sinon on recup�re une couleur dans la QueueFillingPalette et on l'associe au "point" en cours du camembert.
                            Colors.Gcolor __gcolor = base.QueueFillingPalette.Dequeue();

                            if (Validation.IsNotNull(__gcolor))
                                aSerie.Points[__i++].Area.ForegroundColor = __gcolor.Color;
                        }
                    }                    
                }
            );
            
        }

        #endregion M�thodes

    }

	
}
