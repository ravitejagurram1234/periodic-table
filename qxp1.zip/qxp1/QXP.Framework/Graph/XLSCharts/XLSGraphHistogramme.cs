using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using QXPFrk = QXP.Framework;
using System.Collections;
using Cells					= Aspose.Cells;

namespace QXP.Framework.Graph.XLSCharts
{
	/// <summary>
	/// Graphique Histogramme Excel
	/// </summary>
    public class XLSGraphHistogramme : XLSChart
	{
		#region Membre

		private Cells.Charts.ChartType _chartType;

		#endregion Membres

		#region Constructeur

		public XLSGraphHistogramme(Graph graphDefinition) : base(graphDefinition)
        {
            if(Enabled3D)
                this._chartType = Cells.Charts.ChartType.Column3D;
            else
                this._chartType = Cells.Charts.ChartType.Column;
        }
		
        #endregion Constructeur

        #region M�thodes

		/// <summary>
		/// D�finit le template d'une s�rie Aspose
		/// </summary>
		/// <param name="aSerie">S�rie Aspose (Excel)</param>
		/// <param name="serie">S�rie FrameWork QXP</param>
        protected override void DefineSerieTemplate(Aspose.Cells.Charts.Series aSerie, Serie serie)
        {
            base.DefineSerieTemplate(aSerie, serie);

            //Si une couleur est d�finit sur la s�rie, on l'utilise
            if (Validation.IsNotNull(serie.Gcolor))
            {
                aSerie.Area.ForegroundColor = serie.Gcolor.Color;
            }
            else
            {
                if (Validation.IsSet(base.QueueFillingPalette))
                {
                    //Sinon on r�cup�re une couleur dans la QueueFillingPalette
                    Colors.Gcolor __gcolor = base.QueueFillingPalette.Dequeue();

                    if (Validation.IsNotNull(__gcolor))
                        aSerie.Area.ForegroundColor = __gcolor.Color;
                }
            }     
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Type de graphique
        /// </summary>
        public override Cells.Charts.ChartType ChartType
        {
            get { return this._chartType;}
        }
		
        /// <summary>
        /// Le graphique est en 3D ou non
        /// </summary>
		protected override bool Enabled3D
		{
			get
			{
				return GraphHelper.GetEnabled3D(GraphType.GraphHistogramme);
			}
		}

        /// <summary>
        /// Texte affich� si la valeur de la cellule est NULL
        /// </summary>
		protected override string NA_Null_Value
		{
			get{return NULL_VALEUR;}
		}

        #endregion Propri�t�s

    }

	
}
