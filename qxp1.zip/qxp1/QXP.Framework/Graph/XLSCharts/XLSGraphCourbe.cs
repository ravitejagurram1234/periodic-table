using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using QXPFrk = QXP.Framework;
using System.Collections;
using Cells					= Aspose.Cells;

namespace QXP.Framework.Graph.XLSCharts
{
	/// <summary>
	/// Graphique Courbe Excel
	/// </summary>
    public class XLSGraphCourbe : XLSChart
	{
		#region Membres

		private Cells.Charts.ChartType _chartType;

		#endregion Membres

        #region Constructeur
		
        /// <summary>
        /// Cr�e une instance de XLSGraphCourbe
        /// </summary>
        /// <param name="graphDefinition">Graph de d�finition</param>
        public XLSGraphCourbe(Graph graphDefinition) : base(graphDefinition)
        {
            if(Enabled3D)
                this._chartType = Cells.Charts.ChartType.Line3D;
            else
                this._chartType = Cells.Charts.ChartType.Line;
        }
		
        #endregion Constructeur

		#region Methodes

		/// <summary>
		/// D�finit le template d'une s�rie Aspose
		/// </summary>
		/// <param name="aSerie">S�rie Aspose (Excel)</param>
		/// <param name="serie">S�rie FrameWork QXP</param>
		protected override void DefineSerieTemplate(Cells.Charts.Series aSerie, Serie serie)
		{
			base.DefineSerieTemplate(aSerie, serie);
            
            //Ligne d'�paisseur moyenne (un peu plus �paisse que par d�faut)
			aSerie.Line.Weight  = Aspose.Cells.Drawing.WeightType.MediumLine;

            //Si une couleur est d�finit sur la s�rie, on l'utilise
            if (Validation.IsNotNull(serie.Gcolor))
            {
                aSerie.Line.Color = serie.Gcolor.Color;
            }
            else
            {
                if (Validation.IsSet(base.QueueLinePalette))
                {
                    //Sinon on r�cup�re une couleur dans la QueueLinePalette
                    Colors.Gcolor __gcolor = base.QueueLinePalette.Dequeue();

                    if (Validation.IsNotNull(__gcolor))
                        aSerie.Line.Color = __gcolor.Color;
                }
            }
        }

        #endregion Methodes

        #region Propri�t�s

        /// <summary>
        /// Type de graphique
        /// </summary>
        public override Cells.Charts.ChartType ChartType
        {
            get { return this._chartType;}
        }
		
        /// <summary>
        /// Le graphique est en 3D ou non
        /// </summary>
		protected override bool Enabled3D
		{
			get
			{
				return GraphHelper.GetEnabled3D(GraphType.GraphCourbe);
			}
		}

        #endregion Propri�t�s

    }

	
}
