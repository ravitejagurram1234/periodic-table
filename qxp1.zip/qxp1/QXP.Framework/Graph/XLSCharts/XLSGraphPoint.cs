using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using QXPFrk = QXP.Framework;
using System.Collections;
using Cells					= Aspose.Cells;

namespace QXP.Framework.Graph.XLSCharts
{
	/// <summary>
	/// Graphique � point (sans courbe trac�e) Excel
	/// </summary>
    public class XLSGraphPoint : XLSGraphCourbe
	{
		#region Membres

		private Cells.Charts.ChartType _chartType;
		
		#endregion Membres

        #region Constructeur
		
        /// <summary>
        /// Cr��e une instance de XLSGraphPoint
        /// </summary>
        /// <param name="graphDefinition">Graph de d�finition</param>
        public XLSGraphPoint(Graph graphDefinition) : base(graphDefinition)
        {
                this._chartType = Cells.Charts.ChartType.LineWithDataMarkers;            
        }
		
        #endregion Constructeur

		#region Methodes

		/// <summary>
		/// D�finit le template d'une s�rie Aspose
		/// </summary>
		/// <param name="aSerie">S�rie Aspose (Excel)</param>
		/// <param name="serie">S�rie FrameWork QXP</param>
		protected override void DefineSerieTemplate(Aspose.Cells.Charts.Series aSerie, Serie serie)
		{
			base.DefineSerieTemplate(aSerie, serie);
			aSerie.Line.IsVisible = false;
		}

		#endregion Methodes

		#region Propri�t�s
		
        /// <summary>
        /// Type de graphique
        /// </summary>
        public override Cells.Charts.ChartType ChartType
        {
            get { return this._chartType;}
        }
		
        /// <summary>
        /// 3D graphique
        /// </summary>
		protected override bool Enabled3D
		{
		    get
		    {
		        return true;
		    }
		}
		
        /// <summary>
        /// Texte affich� si la valeur de la cellule est NULL
        /// </summary>
		protected override string NA_Null_Value
		{
			get{return NULL_VALEUR;}
		}

        #endregion Propri�t�s

    }

	
}
