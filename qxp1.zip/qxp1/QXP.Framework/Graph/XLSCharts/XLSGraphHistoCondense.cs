using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using QXPFrk = QXP.Framework;
using System.Collections;
using Cells					= Aspose.Cells;

namespace QXP.Framework.Graph.XLSCharts
{
	/// <summary>
	/// Graphique Histogramme empil� 100% Excel
	/// </summary>
    public class XLSGraphHistoCondense : XLSGraphHistogramme
	{
		#region Membres

		private Cells.Charts.ChartType _chartType;
		private const int		Bar_Interval = 50;

		#endregion Membres

		#region Constructeur

		public XLSGraphHistoCondense(Graph graphDefinition) : base(graphDefinition)
        {
            if(Enabled3D)
                this._chartType = Cells.Charts.ChartType.Column3D100PercentStacked;
            else
                this._chartType = Cells.Charts.ChartType.Column100PercentStacked;
        }
		
        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Permet de d�finir les bornes min et max du graphique
        /// </summary>
        protected override void DefineGraphRanges()
        {
			//Pas de d�finition de range n�cessaire dans le cas de graph condens� !!
		}

		/// <summary>
		/// D�finit le template d'une s�rie Aspose
		/// </summary>
		/// <param name="aSerie">S�rie Aspose (Excel)</param>
		/// <param name="serie">S�rie FrameWork QXP</param>
		protected override void DefineSerieTemplate(Cells.Charts.Series aSerie, Serie serie)
		{

            //Les labels dans les histo condens� sont en gras
            aSerie.DataLabels.TextFont.IsBold = true;

            // Permet de d�finir l'espacement entre les barres d'histogramme
			// par d�faut cette valeur est de 150 le fait de reduire cette valeur permet d'�largir les barres !
			aSerie.GapWidth = Bar_Interval;

			base.DefineSerieTemplate(aSerie, serie);


        }
        #endregion M�thodes

		#region Propri�t�s

		public override Cells.Charts.ChartType ChartType
        {
            get { return this._chartType;}
        }
		
        #endregion Propri�t�s      

    }

	
}
