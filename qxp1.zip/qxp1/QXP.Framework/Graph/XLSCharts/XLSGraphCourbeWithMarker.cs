using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using QXPFrk = QXP.Framework;
using System.Collections;
using Cells					= Aspose.Cells;

namespace QXP.Framework.Graph.XLSCharts
{
	/// <summary>
	/// Graphique Courbe Excel avec des "Markers" au niveau de chaque point de la courbe
	/// </summary>
	public class XLSGraphCourbeWithMarker : XLSGraphCourbe
	{
		#region Membre

		private Cells.Charts.ChartType _chartType;

		#endregion Membre

		#region Constructeur

		public XLSGraphCourbeWithMarker(Graph graphDefinition) : base(graphDefinition)
        {
            if(Enabled3D)
                this._chartType = Cells.Charts.ChartType.Line3D;
            else
                this._chartType = Cells.Charts.ChartType.LineWithDataMarkers;
        }

		#endregion Constructeur
		
		#region Methodes

		protected override void DefineSerieTemplate(Cells.Charts.Series aSerie, Serie serie)
		{
			base.DefineSerieTemplate(aSerie, serie);
			aSerie.DataLabels.Position = Cells.Charts.LabelPositionType.Above;
		}		

		#endregion Methodes

		#region Propri�t�s

		public override Cells.Charts.ChartType ChartType
        {
            get { return this._chartType;}
        }


        #endregion Propri�t�s

    }

	
}
