using System;
using System.Collections.Generic;
using System.Text;


namespace QXP.Framework.Graph.Colors
{
    /// <summary>
    /// Objet GcolorSeries : d�finit un dictionnaire de string, couleur des s�ries d'un graphique (associe un nom de s�rie � une couleur)
    /// Attention le nom de la s�rie doit etre ajout� en minuscule!
    /// </summary>
    /// <author>cueffl</author>
    /// <date>05/05/2009 10:15:21</date>    
    public class GcolorSeries : ListGraphColors
    {
        #region Membres

        private Palette _palette = new Palette();

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de GcolorSeries
        /// </summary>
        public GcolorSeries()
        {
        }

        /// <summary>
        /// Cr�e une instance de GcolorSeries � partir d'une autre instance
        /// Attention le nom de la s�rie doit etre ajout� en minuscule!
        /// </summary>
        /// <param name="gcolorSeries">Instance source</param>
        public GcolorSeries(Dictionary<string, Gcolor> gcolorSeries) : base(gcolorSeries)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Palette associ�e au s�rie du graphique
        /// </summary>
        public Palette Palette
        {
            get { return _palette; }
            set { _palette = value; }
        }

        #endregion Propri�t�s
    }
}
