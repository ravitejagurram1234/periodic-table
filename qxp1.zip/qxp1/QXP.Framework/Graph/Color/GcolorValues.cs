using System;
using System.Collections.Generic;
using System.Text;


namespace QXP.Framework.Graph.Colors
{
    /// <summary>
    /// Objet GcolorValues : d�finit un dictionnaire de string, couleur des valeurs d'une s�rie d'un graphique
    /// (pour le camembert par exemple)
    /// </summary>
    /// <author>cueffl</author>
    /// <date>05/05/2009 10:13:57</date>    
    public class GcolorValues : ListGraphColors
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de GcolorValues
        /// </summary>
        public GcolorValues()
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
