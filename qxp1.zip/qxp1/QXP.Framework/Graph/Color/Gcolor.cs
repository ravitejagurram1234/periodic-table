using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;


namespace QXP.Framework.Graph.Colors
{
    /// <summary>
    /// Objet Gcolor d�finit une couleur QXP utilis�e par les graphs
    /// </summary>
    /// <author>cueffl</author>
    /// <date>05/05/2009 10:12:54</date>    
    public class Gcolor
    {
        #region Membres

        private Color       _mainColor;
        private Color       _fgColor;        
        private Color       _bgColor;
        private Color       _borderColor;
        private TypeColors  _typeColor;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Gcolor
        /// </summary>
        /// <param name="mainColor">Couleur principale de l'objet</param>
        public Gcolor(Color mainColor)
        {
            this._mainColor = mainColor;
        }

        /// <summary>
        /// Cr�e une instance de Gcolor
        /// </summary>
        /// <param name="mainColorHTML">Code HTML de la couleur principale de l'objet</param>
        public Gcolor(string mainColorHTML) : this(ColorTranslator.FromHtml(mainColorHTML))
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Couleur Foreground
        /// </summary>
        public Color FgColor
        {
            get { return _fgColor; }
            set { _fgColor = value; }
        }

        /// <summary>
        /// Couleur Background
        /// </summary>
        public Color BgColor
        {
            get { return _bgColor; }
            set { _bgColor = value; }
        }

        /// <summary>
        /// Couleur de bord
        /// </summary>
        public Color BorderColor
        {
            get { return _borderColor; }
            set { _borderColor = value; }
        }

        /// <summary>
        /// Couleur principale
        /// </summary>
        public Color Color
        {
            get { return _mainColor; }
            set { _mainColor = value; }
        }

        /// <summary>
        /// Type de couleur (line, remplissage). 
        /// </summary>
        public TypeColors TypeColor
        {
            get { return _typeColor; }
            set { _typeColor = value; }
        }

        #endregion Propri�t�s
    }
}
