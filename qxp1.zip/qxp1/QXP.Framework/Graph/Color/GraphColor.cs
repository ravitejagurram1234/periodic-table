using System;
using System.Drawing;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Graph.Colors
{
    /// <summary>
    /// Type de couleur d'un Gcolor
    /// </summary>
    public enum TypeColors
    {
            /// <summary>
            /// Couleur associ�e au ligne
            /// </summary>
            LINE,            
            /// <summary>
            /// Couleur associ�e au remplissage
            /// </summary>
            FILLING,
            /// <summary>
            /// Couleur standard
            /// </summary>
            STANDARD
    }

    /// <summary>
    /// D�finit les caract�ristiques de couleur d'un graphique
    /// </summary>
    public class GraphColor
    {
        #region Membres

        private Gcolor          _gcolor             = null;    
        private GcolorSeries    _gcolorSeries       = new GcolorSeries();      

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de GraphColor
        /// </summary>
        public GraphColor()
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Gcolor du graphique
        /// </summary>
        public Gcolor Gcolor
        {
            get { return _gcolor; }
            set { _gcolor = value; }
        }

        /// <summary>
        /// D�finit les couleurs des s�ries du graphique (dont la palette)
        /// </summary>
        public GcolorSeries GcolorSeries
        {
            get { return _gcolorSeries; }
            set { _gcolorSeries = value; }
        }

        #endregion Propri�t�s
    }
}
