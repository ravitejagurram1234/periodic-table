using System;
using System.Collections.Generic;
using System.Text;


namespace QXP.Framework.Graph.Colors
{
    /// <summary>
    /// Objet ListGraphColors : d�finit un dictionnaire de string, couleur
    /// </summary>
    /// <author>cueffl</author>
    /// <date>05/05/2009 10:13:14</date>    
    public abstract class ListGraphColors : Dictionary<string, Gcolor>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ListGraphColors
        /// </summary>
        public ListGraphColors()
        {
        }

        /// <summary>
        /// Cr�e une instance de ListGraphColors � partir d'une autre instance
        /// </summary>
        /// <param name="listGraphColors">Instance source</param>
        public ListGraphColors(Dictionary<string, Gcolor> listGraphColors) : base(listGraphColors)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
