using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;

namespace QXP.Framework.Graph.Colors
{
    /// <summary>
    /// Objet Palette : d�finit une palette de couleur
    /// </summary>
    /// <author>cueffl</author>
    /// <date>05/05/2009 11:23:02</date>    
    public class Palette : List<Gcolor>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr��e une instance de Palette
        /// </summary>
        public Palette()
        { 
        }

        /// <summary>
        /// Cr��e une instance de Palette
        /// </summary>
        /// <param name="lstGcolor">Liste de Gcolor � utiliser pour cr�er la palette</param>
        public Palette(List<Gcolor> lstGcolor) : base(lstGcolor)
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Retourne une liste de couleurs dans le type souhait�
        /// </summary>
        /// <param name="typeColor">Type de couleur recherch�</param>
        /// <returns>La liste de Gcolor dans le type voulu</returns>
        private List<Gcolor> GetColors(TypeColors typeColor)
        {
            return this.FindAll
            (
                delegate(Gcolor __gcolor)
                {
                    return __gcolor.TypeColor == typeColor;
                }
            );
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Palette de couleur associ�e aux lignes du graphique
        /// </summary>
        public List<Gcolor> LinePalette
        {
            get { return this.GetColors(TypeColors.LINE); }
        }

        /// <summary>
        /// Palette de couleur associ�e aux remplissages du graphique
        /// </summary>
        public List<Gcolor> FillingPalette
        {
            get { return this.GetColors(TypeColors.FILLING); }
        }

        /// <summary>
        /// Palette de couleur standard
        /// </summary>
        public List<Gcolor> StandardPalette
        {
            get { return this.GetColors(TypeColors.STANDARD); }
        }

        /// <summary>
        /// Palette de couleur associ�e aux lignes + remplissages du graphique
        /// </summary>
        public List<Gcolor> LineAndFillingPalette
        {
            get { return (List<Gcolor>)Collection.Merge.Concatene<Gcolor>(LinePalette, FillingPalette); }
        }

        #endregion Propri�t�s
    }
}
