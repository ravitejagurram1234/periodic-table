using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Graph
{
    /// <summary>
    /// Types de graphiques
	/// Liste identique dans GraphType du fichier rapports.xsd
    /// L'identifiant est conforem aux informations sur la table QXP_REF_TYPE_GRAPHIQUE
    /// </summary>
    public enum GraphType
    {
		GraphCamembert          = 1,
		GraphCourbe             = 2,
        GraphHistogramme        = 3,
	    GraphCourbeWithMarker   = 4,
		GraphPoint              = 5,
		GraphHistoCondense      = 6,
    }

	/// <summary>
    /// Localisation des donn�es d'un graphique dans un classeur Excel
    /// </summary>
    public enum ExcelSerieLocation
    {
        InHideSeparateWorkSheet,	// Dans une feuille s�par�e du graphique et cach�e
        InSeparateWorksheet	// Dans une feuille s�par�e du graphique
    }

    public enum PositionLegende
    {
        Right       = 1,
        Left        = 2,
        Top         = 3,
        Bottom      = 4,
    }


}
