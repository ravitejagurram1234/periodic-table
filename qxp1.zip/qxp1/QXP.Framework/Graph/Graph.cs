using System;
using System.Xml.Serialization;
using QXP.Framework.Data.Format;

namespace QXP.Framework.Graph
{
    /// <summary>
    /// D�finit un graphique "g�n�rique" QXP
    /// </summary>
    public class Graph
    {
        #region Membres

        private string _strNom;
        private string _id;
        private int _width;
        private int _height;
        private SerieList _series;
        private GraphType _type;
        private bool _useExcelGraph;
        private ExcelSerieLocation _excelSerieLocation;
        private bool _isShowTitle;
        private bool _isShowLegend;
        private PositionLegende _legendPosition;
        private double _displacement;
        private string _strNomAxisX;
        private string _strNomAxisY;
        private string _strNomAxisY2;
        private bool _isShowXTitle;
        private bool _isShowYTitle;
        private bool _isShowY2Title;
        private string _titleAxisX;
        private string _titleAxisY;
        private string _titleAxisY2;
        private bool _showPointValue;
        private decimal _showPointValue_Min = decimal.MinValue;
        private bool _showPointValue_Min_Strict = false;
        private bool _display_X_Grid;
        private bool _display_Y_Grid;
        private bool _display_Y2_Grid;
        private Colors.Gcolor _gcolor = null;
        private QXP_Format _qxp_Format_X = null;
        private QXP_Format _qxp_Format_Y = null;
        private QXP_Format _qxp_Format_Y2 = null;
        private bool _showAxisY2 = false;

		////Provisoire !! il faudrait que ce soit dans GrapWeb mais il y � un probl�me d'architecture dans le g�n�rateur actuellement je suis oblig� de remettre �a ici
		//private string _source;

        #endregion

        #region Constantes

		////Provisoire !! il faudrait que ce soit dans GrapWeb mais il y � un probl�me d'architecture dans le g�n�rateur actuellement je suis oblig� de remettre �a ici
		////� supprimer apr�s r�organisation Architecture
		//private const string URLHandler = "Graph_Image.aspx";
		////Provisoire !! Cette constante existe d�j� dans GraphHandler.GraphIDKey mais il y � un probl�me d'architecture dans le g�n�rateur actuellement je suis oblig� de remettre �a ici
		////� supprimer apr�s r�organisation Architecture
		//public const string GraphIDKey = "GraphID";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Graph
        /// </summary>
        public Graph()
        {
            this._id = Guid.NewGuid().ToString();
			////Provisoire !! il faudrait que ce soit dans GrapWeb mais il y � un probl�me d'architecture dans le g�n�rateur actuellement je suis oblig� de remettre �a ici
			////� supprimer apr�s r�organisation Architecture
			//this._source = string.Format("{0}?{1}={2}", URLHandler, GraphIDKey, this._id);
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Properties

        /// <summary>
        /// Nom du graphique
        /// </summary>
        [XmlIgnore]
        public string Nom
        {
            get { return this._strNom; }
            set { this._strNom = value; }
        }

        /// <summary>
        /// ID du graphique
        /// </summary>
        [XmlAttribute]
        public string ID
        {
            get { return this._id; }
            set { this._id = value; }
        }

        /// <summary>
        /// Largeur du graphique
        /// </summary>
        [XmlIgnore]
        public int Width
        {
            get { return _width; }
            set { _width = value; }
        }

        /// <summary>
        /// Hauteur du graphique
        /// </summary>
        [XmlIgnore]
        public int Height
        {
            get { return _height; }
            set { _height = value; }
        }

        /// <summary>
        /// Type de graphique
        /// </summary>
        [XmlIgnore]
        public GraphType Type
        {
            get { return this._type; }
            set { this._type = value; }
        }

        /// <summary>
        /// Utilisation des graphique Excel dans le format du m�me nom
        /// </summary>
        [XmlIgnore]
        public bool UseExcelGraph
        {
            get { return this._useExcelGraph; }
            set { this._useExcelGraph = value; }
        }

        /// <summary>
        /// Localisation des donn�es du graphique au format Excel
        /// </summary>
        [XmlIgnore]
        public ExcelSerieLocation ExcelSerieLocation
        {
            get { return this._excelSerieLocation; }
            set { this._excelSerieLocation = value; }
        }

        /// <summary>
        /// Listes des s�ries du graphique
        /// </summary>
        [XmlIgnore]
        public SerieList Series
        {
            get { return _series; }
            set { _series = value; }
        }

        /// <summary>
        /// Le titre du graph est affich� ou non
        /// </summary>
        [XmlIgnore]
        public bool IsShowTitle
        {
            get { return _isShowTitle; }
            set { _isShowTitle = value; }
        }

        /// <summary>
        /// La l�gende du graph est affich�e ou non
        /// </summary>
        [XmlIgnore]
        public bool IsShowLegend
        {
            get { return _isShowLegend; }
            set { _isShowLegend = value; }
        }

        /// <summary>
        /// Position de la l�gende
        /// </summary>
        [XmlIgnore]
        public PositionLegende LegendPosition
        {
            get { return _legendPosition; }
            set { _legendPosition = value; }
        }

        /// <summary>
        /// Displacement du graphique
        /// </summary>
        [XmlIgnore]
        public double Displacement
        {
            get { return _displacement; }
            set { _displacement = value; }
        }

        /// <summary>
        /// Nom de l'axe des abcisses
        /// </summary>
        [XmlIgnore]
        public string NameAxisX
        {
            get { return this._strNomAxisX; }
            set { this._strNomAxisX = value; }
        }

        /// <summary>
        /// Nom de l'axe des ordonn�es
        /// </summary>
        [XmlIgnore]
        public string NameAxisY
        {
            get { return this._strNomAxisY; }
            set { this._strNomAxisY = value; }
        }

        /// <summary>
        /// Nom du second axe des ordonn�es
        /// </summary>
        [XmlIgnore]
        public string NameAxisY2
        {
            get { return this._strNomAxisY2; }
            set { this._strNomAxisY2 = value; }
        }

        /// <summary>
        /// Le titre de l'axe des abcisses est affich� ou non
        /// </summary>
        [XmlAttribute]
        public bool IsShowXTitle
        {
            get { return this._isShowXTitle; }
            set { this._isShowXTitle = value; }
        }

        /// <summary>
        /// Le titre de l'axe des ordonn�es est affich� ou non
        /// </summary>
        [XmlAttribute]
        public bool IsShowYTitle
        {
            get { return this._isShowYTitle; }
            set { this._isShowYTitle = value; }
        }

        /// <summary>
        /// Le titre du second axe des ordonn�es est affich� ou non
        /// </summary>
        [XmlAttribute]
        public bool IsShowY2Title
        {
            get { return this._isShowY2Title; }
            set { this._isShowY2Title = value; }
        }

        /// <summary>
        /// Titre de l'axe des abcisses
        /// </summary>
        [XmlIgnore]
        public string TitleAxisX
        {
            get { return this._titleAxisX; }
            set { this._titleAxisX = value; }
        }

        /// <summary>
        /// Titre de l'axe des ordonn�es
        /// </summary>
        [XmlIgnore]
        public string TitleAxisY
        {
            get { return this._titleAxisY; }
            set { this._titleAxisY = value; }
        }

        /// <summary>
        /// Titre du second axe des ordonn�es
        /// </summary>
        [XmlIgnore]
        public string TitleAxisY2
        {
            get { return this._titleAxisY2; }
            set { this._titleAxisY2 = value; }
        }

        /// <summary>
        /// Les valeurs des points du graphique sont affich�es ou non
        /// </summary>
        [XmlIgnore]
        public bool ShowPointValue
        {
            get { return _showPointValue; }
            set { _showPointValue = value; }
        }

        /// <summary>
        /// D�fini la limite � partir de laquelle les etiquettes des valeurs Y sont affich�es
        /// voir la propri�t� ShowPointValue_Min_Strict pour savoir si cette limit est stricte ou pas
        /// si cette valeurs est �gale � decimal.MinValue toutes les etiquettes sont affich�es.
        /// </summary>
        [XmlIgnore]
        public decimal ShowPointValue_Min
        {
            get { return _showPointValue_Min; }
            set { _showPointValue_Min = value; }
        }

        /// <summary>
        /// D�fini Le faite que la valeur de ShowPointValue_Min correspond � une limite stricte
        /// si ShowPointValue_Min_Strict est true alors les valeurs doivent �tre strictement sup�rieur � ShowPointValue_Min
        /// sinon les valeurs doivents �tre sup�rieures ou �gales.
        /// par d�faut (false) c'est � dire sup�rieure ou �gale.
        /// </summary>
        [XmlIgnore]
        public bool ShowPointValue_Min_Strict
        {
            get { return _showPointValue_Min_Strict; }
            set { _showPointValue_Min_Strict = value; }
        }

        /// <summary>
        /// Affiche la grille sur l'axe des X
        /// </summary>
        [XmlAttribute]
        public bool Display_X_Grid
        {
            get { return _display_X_Grid; }
            set { _display_X_Grid = value; }
        }

        /// <summary>
        /// Affiche la grille sur les axes des ordonn�es
        /// </summary>
        [XmlAttribute]
        public bool Display_Y_Grid
        {
            get { return _display_Y_Grid; }
            set { _display_Y_Grid = value; }
        }

        /// <summary>
        /// Permet de g�rer les sauts de ligne dans les titres des graphiques        
        /// </summary>
        [XmlIgnore]
        public string Title
        {
            get { return Conversion.ToString(_strNom).Replace("<br>", "\n").Replace("<BR>", "\n"); }
        }

        /// <summary>
        /// Permet d'obtenir un calcul des bornes et des intervals optimum en fonctions des donn�es contenues dans les series
        /// </summary>
        [XmlIgnore]
        public AxisRange AxisRange_Y
        {
            get
            {
                if (Validation.IsNotNull(_series.Min_Y) && Validation.IsNotNull(_series.Max_Y))
                {
                    return new AxisRange(_series.Min_Y.Value, _series.Max_Y.Value);
                }

                return null;
            }

        }

        /// <summary>
        /// Permet d'obtenir un calcul des bornes et des intervals optimum en fonctions des donn�es contenues dans la seconde s�rie
        /// </summary>
        [XmlIgnore]
        public AxisRange AxisRange_Y2
        {
            get
            {
                if (Validation.IsNotNull(_series.Min_Y2) && Validation.IsNotNull(_series.Max_Y2))
                {
                    return new AxisRange(_series.Min_Y2.Value, _series.Max_Y2.Value);
                }

                return null;
            }

        }

        /// <summary>
        /// D�finit les couleurs du graph
        /// </summary>
        [XmlIgnore]
        public Colors.Gcolor Gcolor
        {
            get { return _gcolor; }
            set { _gcolor = value; }
        }

        /// <summary>
        /// Format associ� � l'axe des abcisses
        /// </summary>
        [XmlIgnore]
        public QXP_Format QXP_Format_X
        {
            get { return _qxp_Format_X; }
            set { _qxp_Format_X = value; }
        }

        /// <summary>
        /// Format associ� aux axes des ordonn�es
        /// </summary>
        [XmlIgnore]
        public QXP_Format QXP_Format_Y
        {
            get { return _qxp_Format_Y; }
            set { _qxp_Format_Y = value; }
        }

        /// <summary>
        /// Format associ� aux axes des ordonn�es secondaires
        /// </summary>
        [XmlIgnore]
        public QXP_Format QXP_Format_Y2
        {
            get { return _qxp_Format_Y2; }
            set { _qxp_Format_Y2 = value; }
        }

        /// <summary>
        /// Permet l'affichage d'un second axe des Y (uniquement si deux s�ries)
        /// </summary>
        [XmlIgnore]
        public bool ShowAxisY2
        {
            get { return _showAxisY2; }
            set { _showAxisY2 = value; }
        }

        /// <summary>
        /// Affiche la grille sur le second axe des Y (uniquement si deux s�ries)
        /// </summary>
        [XmlAttribute]
        public bool Display_Y2_Grid
        {
            get { return _display_Y2_Grid; }
            set { _display_Y2_Grid = value; }
        }

		////Provisoire !! il faudrait que ce soit dans GrapWeb mais il y � un probl�me d'architecture dans le g�n�rateur actuellement je suis oblig� de remettre �a ici
		////� supprimer apr�s r�organisation Architecture
		///// <summary>
		///// Source du graphique (chargement via les handlers)
		///// </summary>
		//[XmlAttribute]
		//public string Source
		//{
		//    get { return this._source; }
		//    set { this._source = value; }
		//}

        #endregion
    }
}
