using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace QXP.Framework.Graph
{
    /// <summary>
    /// Class GraphHelper : Helper utilis� pour la g�n�ration des graphiques
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class GraphHelper
    {
        #region Membres

        /// <summary>
        /// Associe le type de donn�es XLS au type .NET
        /// </summary>
        private static Dictionary<ValueType.TypeCode, string> _assocTypeXLS = new Dictionary<ValueType.TypeCode, string>();

        /// <summary>
        /// Associe � chaque graphique si celui-ci doit �tre g�n�r� en 3D ou non
        /// </summary>
        private static Hashtable _assocTypeGraphWithEnabled3D = new Hashtable();

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de GraphHelper
        /// </summary>
        static GraphHelper()
        {
            //Cr�ation des associations

            _assocTypeXLS.Add(ValueType.TypeCode.CLSdouble, "double");
            _assocTypeXLS.Add(ValueType.TypeCode.CLSdecimal, "decimal");
            _assocTypeXLS.Add(ValueType.TypeCode.CLSint32, "int32");
            _assocTypeXLS.Add(ValueType.TypeCode.CLSstring, "string");
            _assocTypeXLS.Add(ValueType.TypeCode.DateTime, "date");

            _assocTypeGraphWithEnabled3D.Add(GraphType.GraphHistogramme, GetEnabled3D("graph_bar_3D"));
            _assocTypeGraphWithEnabled3D.Add(GraphType.GraphCamembert, GetEnabled3D("graph_pie_3D"));
            _assocTypeGraphWithEnabled3D.Add(GraphType.GraphCourbe, GetEnabled3D("graph_line_3D"));
            _assocTypeGraphWithEnabled3D.Add(GraphType.GraphPoint, GetEnabled3D("graph_line_3D"));
        }

        #endregion Constructeur

        #region M�thodes

        public static List<string> DateListToStringList(List<DateTime> listDeDates)
        {
            return listDeDates.ConvertAll<string>(delegate(DateTime __myDateTime) { return __myDateTime.ToShortDateString(); });
        }

        public static List<string> DoubleListToStringList(List<double> listDeDoubles)
        {
            return listDeDoubles.ConvertAll<string>(delegate(Double __myDouble) { return __myDouble.ToString(); });
        }

        public static MemoryStream GetStream(Bitmap bitmap)
        {
            MemoryStream __memoryStream = new MemoryStream();
            bitmap.Save(__memoryStream, ImageFormat.Png);
            __memoryStream.Seek(0, SeekOrigin.Begin);
            return __memoryStream;
        }

        /// <summary>
        /// Retourne le type  XLS  associ� au type .Net
        /// </summary>
        /// <param name="valueTypeGraph"></param>
        /// <returns></returns>
        public static Type GetValueTypeDotNetFromXLSType(string valueTypeGraph)
        {
            foreach (ValueType.TypeCode __typeCode in _assocTypeXLS.Keys)
            {
                if (_assocTypeXLS[__typeCode] == valueTypeGraph)
                {
                    return ValueType.GetType(__typeCode);
                }
            }
            return ValueType.GetType(ValueType.CLSstring);
        }

        /// <summary>
        /// Retourne le type .NET  associ� au type XLS
        /// </summary>
        /// <param name="typeCode"></param>
        /// <param name="isPourcentage">Indique si la donn�e est une valeur pourcentage ou non</param>
        /// <returns></returns>
        public static string GetValueTypeXLS(ValueType.TypeCode typeCode, bool isPourcentage)
        {
            if (isPourcentage)
            {
                return "pourcentage";
            }
            else if (_assocTypeXLS.ContainsKey(typeCode))
            {
                return (string)_assocTypeXLS[typeCode];
            }
            else
            {
                return "string";
            }
        }


        private static bool GetEnabled3D(string enabled3Dparam)
        {
            if (Validation.IsSet(Configuration.Settings.Current.GetString(enabled3Dparam)))
            {
                return Configuration.Settings.Current.GetBool(enabled3Dparam);
            }
            else
                return false;
        }

        public static bool GetEnabled3D(GraphType typeGraph)
        {
            return Conversion.ToBool(_assocTypeGraphWithEnabled3D[typeGraph]);
        }

        /// <summary>
        /// Permet de g�n�rer la chaine de caract�re pour un CreateInstance afin d'automatiser l'instanciation d'un graphique en fonction du type de graphique
        /// </summary>
        /// <param name="typeGraph"></param>
        /// <param name="typeGraphFinal"></param>
        /// <returns></returns>
        public static string GetCreateInstanceString(GraphType typeGraph, string typeGraphFinal)
        {
            switch (typeGraphFinal)
            {
                case "Dundas":
                    return string.Format("QXP.Framework.Graph.DundasCharts.{0}Dundas, QXP.Framework", typeGraph);
                case "XLS":
                    return string.Format("QXP.Framework.Graph.XLSCharts.XLS{0}, QXP.Framework", typeGraph);
            }
            return string.Empty;
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }

			
}

