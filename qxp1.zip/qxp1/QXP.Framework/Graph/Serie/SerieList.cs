using System.Collections;
using System.Collections.Generic;
using System.Linq;
using QXPData = QXP.Framework.Data;

namespace QXP.Framework.Graph
{
    /// <summary>
    /// D�finit une liste de S�rie d'un graphique
    /// </summary>
    public class SerieList : Dictionary<string, Serie>
    {
        #region Membres

        Colors.GcolorSeries _gcolorSeries = null;

        #endregion Membres

        #region Constantes

        //Utilis� pour le renommage des s�ries
        static int cpt;
        const string PatternAddLastValue = "{0} : {1}";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de SerieList
        /// </summary>
        public SerieList()
        {
            cpt = 1;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Ajoute une s�rie au dictionnaire de s�rie
        /// </summary>
        /// <param name="serie">S�rie � ajouter</param>
        public void Add(Serie serie)
        {
            //La s�rie est renomm�e si le nom est deja utilis�e 
            RenameSerieIfAlreadyExist(serie);

            //Ajout de la s�rie
            this.Add(serie.Name, serie);
        }

        /// <summary>
        /// Renome la s�rie si le nom est deja utilis� dans la liste des s�ries
        /// </summary>
        /// <param name="serie">Serie � renommer</param>
        public void RenameSerieIfAlreadyExist(Serie serie)
        {
            foreach (Serie __serie in this.Values)
            {
                if (serie.Name.ToLower().Equals(__serie.Name.ToLower()) && !__serie.Equals(serie))
                    serie.Name = string.Concat(serie.Name, "_", cpt++);
            }
        }

        /// <summary>
        /// Retourne l'ensemble des labels de type QXP_Value de l'axe des abcisses
        /// </summary>
        /// <returns>Un IEnumerable de labels de type QXP_Value</returns>
        public IEnumerable<QXPData.IQXP_Value> GetLabelsAxisX()
        {
            IEnumerable<QXPData.IQXP_Value> __labels = null;

            foreach (Serie __serie in this.Values)
            {
                __labels = Collection.Merge.MergeEnumerable<QXPData.IQXP_Value>(__labels, __serie.GraphValues.Get_X_Values_IQXPValues());
            }

            return __labels;
        }
        
        /// <summary>
        /// Retourne l'ensemble des labels des s�ries du dictionnaire
        /// </summary>
        /// <returns>Une List de labels</returns>
        public List<string> GetSerieLabels()
        {
            List<string> __myList = new List<string>();
            foreach (Serie __serie in this.Values)
            {
                __myList.Add(__serie.Label);
            }
            return __myList;
        }

        /// <summary>
        /// Permet de supprimer toutes les series qui n'ont pas au moins une valeur significatives sur l'axe de Y.
        /// </summary>
        public void RemoveAllEmptySeries()
        {
            List<string> __names2Remove = new List<string>();

            foreach (Serie __serie in this.Values)
            {
                if (!__serie.GraphValues.HaveValues)
                    __names2Remove.Add(__serie.Name);
            }

            //Obliger de Faire cette op�ration en 2 passes, on ne peut pas supprimer une �l�ment d'une collection si elle est en cours d'�num�ration.
            foreach (string __name2Remove in __names2Remove)
            {
                this.Remove(__name2Remove);
            }
        }

        /// <summary>
        /// Permet de mettre � jour le nom de la serie si la prori�t� AddLastValueToNom est true
        /// </summary>
        public void UpdateSerieNomWithLastValue()
        {
            foreach (Serie __serie in this.Values)
            {
                if (__serie.AddLastValueToNom)
                {
                    __serie.Label = string.Format(PatternAddLastValue, __serie.Label, __serie.GraphValues.GetLastValueString());
                }
            }
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Permet de retrouver la valeur minimale sur l'axe des y toutes series confondues 
        /// sauf si ShowAxisY2 est vrai et que le nombre de s�ries est �gal � 2
        /// </summary>
        public QXPData.IQXP_Value Min_Y
        {
            get
            {
                if (ShowAxisY2 && this.Values.Count >= 1 && this.Values.Count <= 2)
                {
                    Serie __serie = this.Values.ElementAt(0);
                    return __serie.GraphValues.Min_Y;
                }
                else
                {
                    QXPData.IQXP_Value __minValue = null;
                    foreach (Serie __serie in this.Values)
                    {
                        if (Validation.IsNotNull(__serie.GraphValues.Min_Y)
                            && (Validation.IsNull(__minValue) || (__serie.GraphValues.Min_Y.ValueIsSet && __serie.GraphValues.Min_Y.CompareTo(__minValue) < 0))
                           )
                        {
                            __minValue = __serie.GraphValues.Min_Y;
                        }
                    }
                    return __minValue;
                }
            }
        }

        /// <summary>
        /// Permet de retrouver la valeur minimale sur l'axe des y de la seconde s�rie
        /// </summary>
        public QXPData.IQXP_Value Min_Y2
        {
            get
            {
                if (this.Values.Count >= 2)
                {
                    Serie __serie = this.Values.ElementAt(1);
                    return __serie.GraphValues.Min_Y;
                }
                return null;
            }
        }

        /// <summary>
        /// Permet de retrouver la valeur maximale sur l'axe des y toutes series confondues 
        /// sauf si ShowAxisY2 est vrai et que le nombre de s�ries est �gal � 2
        /// </summary>
        public QXPData.IQXP_Value Max_Y
        {
            get
            {
                if (ShowAxisY2 && this.Values.Count >= 1 && this.Values.Count <= 2)
                {
                    Serie __serie = this.Values.ElementAt(0);
                    return __serie.GraphValues.Max_Y;
                }
                else
                {
                    QXPData.IQXP_Value __maxValue = null;
                    foreach (Serie __serie in this.Values)
                    {
                        if (Validation.IsNotNull(__serie.GraphValues.Max_Y)
                            && (Validation.IsNull(__maxValue) || (__serie.GraphValues.Max_Y.ValueIsSet && __serie.GraphValues.Max_Y.CompareTo(__maxValue) > 0))
                           )
                        {
                            __maxValue = __serie.GraphValues.Max_Y;
                        }
                    }
                    return __maxValue;
                }
            }
        }

        /// <summary>
        /// Permet de retrouver la valeur maximale sur l'axe des y de la seconde s�rie
        /// </summary>
        public QXPData.IQXP_Value Max_Y2
        {
            get
            {
                if (this.Values.Count >= 2)
                {
                    Serie __serie = this.Values.ElementAt(1);
                    return __serie.GraphValues.Max_Y;
                }
                return null;
            }
        }

        /// <summary>
        /// D�finit les couleurs, palette des s�ries
        /// </summary>
        public Colors.GcolorSeries GcolorSeries
        {
            get { return _gcolorSeries; }
            set { _gcolorSeries = value; }
        }

        /// <summary>
        /// Indique si un second axe des Y est affich�
        /// Cette valeur agit sur le calcul des bornes de l'�chelle
        /// </summary>
        public bool ShowAxisY2
        {
            get;
            set;
        }
        
        #endregion Propri�t�s
    }
}
