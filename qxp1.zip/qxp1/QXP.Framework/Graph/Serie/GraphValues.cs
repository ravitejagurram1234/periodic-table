using System;
using System.Collections;
using System.Collections.Generic;
using QXPFrk	= QXP.Framework; 
using QXPGraph	= QXP.Framework.Graph; 
using QXPData = QXP.Framework.Data;

namespace QXP.Framework.Graph
{
	/// <summary>
	/// D�finit l'ensemble des coordonn�es d'une s�rie
	/// </summary>
	public class GraphValues : SortableList<GraphValue>
	{
        #region Membres

		QXPData.IQXP_Value	    _min_Y		= null;
		QXPData.IQXP_Value	    _max_Y		= null;
		private bool			_haveValues = false;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de GraphValues
        /// </summary>
        public GraphValues()
        {
        }

        #endregion Constructeur

        #region M�thodes

		/// <summary>
		/// Ajoute la nouvelle valeur et en profite pour mettre � jour les valeurs min/max sur l'axe des Y. 
		/// </summary>
		/// <param name="value">nouvelle GraphValue � ajouter</param>
		public new void	 Add(GraphValue value)
        {
			UpdateMinMax_Y(value.Y);
			base.Add(value);
		}

		/// <summary>
		/// Permet de mettre � jour le Min et le Max des Valeurs en fonction d'un IQXP_Value
		/// </summary>
		/// <param name="newValue">IQXP_Value ajout�</param>
		private void UpdateMinMax_Y(QXPData.IQXP_Value newValue)
        {
			//Valeur non comparable ou non d�finie
			if(!newValue.ValueIsSet) 
                return;

            _haveValues = true;

            //MAJ du MIN si la nouvelle valeur est inf�rieur � celle stock�e actuellement
            if (Validation.IsNull(_min_Y))
                _min_Y = newValue;
            else if(newValue.CompareTo(_min_Y) < 0)
            {
				_min_Y = newValue;
			}

            //MAJ du MAX si la nouvelle valeur est sup�rieur � celle stock�e actuellement
            if(Validation.IsNull(_max_Y))
				_max_Y = newValue;
            else if(newValue.CompareTo(_max_Y) > 0)
            {
				_max_Y = newValue;
			}
        }

        #region Abcisse (X)

        /// <summary>
		/// Retourne la liste des valeurs (Valeur contenue dans l'QXP_Value) des abcisses dans une IEnumerable d'objet
        /// Null est renvoy� pour les valeurs non d�finies (notset)
		/// </summary>
        /// <param name="onlySignificantValues">Uniquement les valeurs significatives</param>
		/// <returns>L'IEnumerable</returns>
		public  IEnumerable	Get_X_Values(bool onlySignificantValues)
		{
            List<GraphValue> __graphvalues = null;

            if (onlySignificantValues)
            {
                __graphvalues = this.Significant_GraphValues;
            }
            else
            {
                __graphvalues = this as List<GraphValue>;
            }

			return __graphvalues.ConvertAll<object>
			(
				delegate(GraphValue __myGraphValue)
				{
                    if(!__myGraphValue.X.ValueIsSet)
                        return null;
                    else
					    return	__myGraphValue.X.Value;
				}

			);
		}

		/// <summary>
		/// Retourne la liste d'QXP_Value de l'axe des abcisses dont l'ordonn�e associ�e (valeur Y) est d�finie (IS_SET) -> Valeur significative
		/// </summary>
		/// <returns>Un IEnumerable d'QXP_Value</returns>
		public IEnumerable<QXPData.IQXP_Value> Get_X_Values_IQXPValues()
		{
			return this.Significant_GraphValues.ConvertAll<QXPData.IQXP_Value>
			(
				delegate(GraphValue __myGraphValue)
				{
                    return __myGraphValue.X;
				}

			);
		}

        #endregion Abcisse (X)

        #region Ordonn�e (Y)

        /// <summary>
		/// Retourne la liste des valeurs (Valeur contenue dans l'QXP_Value) des ordonn�es dans une IEnumerable d'objet
        /// Null est renvoy� pour les valeurs non d�finies (notset)
		/// </summary>
        /// <param name="onlySignificantValues">Uniquement les valeurs significatives</param>
		/// <returns>L'IEnumerable</returns>
		public IEnumerable Get_Y_Values(bool onlySignificantValues)
		{
            List<GraphValue> __graphvalues = null;

            if (onlySignificantValues)
            {
                __graphvalues = this.Significant_GraphValues;
            }
            else
            {
                __graphvalues = this as List<GraphValue>;
            }

			return __graphvalues.ConvertAll<object>
			(
				delegate(GraphValue __myGraphValue)
				{
                    if(!__myGraphValue.Y.ValueIsSet)
                        return null;
                    else
					    return __myGraphValue.Y.Value;
				}

			);
		}
        
		/// <summary>
		/// Retourne la liste des ordonn�es dans une liste d'IQXP_Value
		/// </summary>
		/// <returns>L'IEnumerable</returns>
		public IEnumerable Get_Y_Values_IQXPValues()
		{
			return this.ConvertAll<QXPData.IQXP_Value>
			(
				delegate(GraphValue __myGraphValue)
				{
					return __myGraphValue.Y;
				}

			);
		}

		/// <summary>
		/// Permet de r�cup�rer que la liste des graphValues dont Y est d�fini
		/// </summary>
		/// <returns>La liste de GraphValue non null</returns>
		private List<GraphValue> GetSignificantGraphValues()
        {
			return this.FindAll
            (
                delegate(GraphValue __myGraphValue)
                {
                        return __myGraphValue.Y.ValueIsSet;
                }
            );
		}

		/// <summary>
		/// Permet de retourner la derni�re valeur significative de la serie sous forme de chaines de caract�re 
		/// </summary>
		/// <returns>La derni�re valeur significative convertie en string</returns>
		public string GetLastValueString()
		{
            if (Validation.IsSet(this.Significant_GraphValues))
            {
                GraphValue __lastGraphValue = Significant_GraphValues[Significant_GraphValues.Count - 1];
                return __lastGraphValue.Y.ToString();
            }
            else
                return string.Empty;
		}

        #endregion Ordonn�e (Y)


        #endregion M�thodes

        #region Propri�t�s

		/// <summary>
		/// Retourne la valeur Minimale sur l'axe des Y
		/// </summary>
		public QXPData.IQXP_Value	Min_Y
        {
			get{return _min_Y;}
		}
		
		/// <summary>
		/// Retourne la valeur Maximale sur l'axe des Y
		/// </summary>
		public QXPData.IQXP_Value	Max_Y
        {
			get{return _max_Y;}
		}
		
		/// <summary>
		/// Permet de savoir si la serie contient au moins une valeur significative sur l'axe des Y
		/// </summary>
		public bool						HaveValues
		{
			get { return _haveValues; }
		}

        /// <summary>
        /// Permet de r�cup�rer que la liste des graphValues dont Y est d�fini
        /// </summary>
        public List<GraphValue> Significant_GraphValues
        {
            get { return this.GetSignificantGraphValues(); }
        }

        #endregion Propri�t�s
	}
}
