using System;
using System.Drawing;
using System.Collections.Generic;
using System.Text;
using QXPData = QXP.Framework.Data;

namespace QXP.Framework.Graph
{
	/// <summary>
	/// D�finit une Serie d'un graphique (utilisable par Dundas, xls...)
	/// </summary>
	public class Serie
	{
        #region Membres
		
        private string		            _name;
		private string		            _label;
		private GraphValues             _graphValues;        
    	private bool		            _addLastValueToNom = false;
        private Colors.Gcolor           _gcolor = null;
        private Colors.GcolorValues     _gcolorValues = new Colors.GcolorValues();

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de S�rie
        /// </summary>
        /// <param name="name">Nom de la s�rie</param>
        /// <param name="label">Label de la s�rie (nom localis� par exemple)</param>
		public Serie(string name, string label)
		{
			this._name = name;
			this._label = label;
			_graphValues = new GraphValues();
		}

        #endregion Constructeur

        #region M�thodes

        /// <summary>
		/// Ajoute un graphValue (une coordonn�e X,Y) � la s�rie
		/// </summary>
		/// <param name="graphvalue">GraphValue � ajouter</param>
		public void AddGraphValue(GraphValue graphvalue)
		{
			this.GraphValues.Add(graphvalue);
		}
		
        /// <summary>
        /// Ajoute un graphValue (une coordonn�e X,Y) � la s�rie
        /// </summary>
        /// <param name="x">Valeur de X</param>
        /// <param name="y">Valeur de Y</param>
        /// <param name="y_Text">Valeur de Y convertie en string</param>
        /// <param name="gcolor">Couleur associ�</param>
		public void AddGraphValue(QXPData.IQXP_Value x, QXPData.IQXP_Value y, Colors.Gcolor gcolor)
		{
            this.GraphValues.Add(new GraphValue(x,y, gcolor));
		}

        #endregion M�thodes

        #region Propri�t�s

		/// <summary>
		/// Ensemble des coordonn�es de la s�rie
		/// </summary>
		public GraphValues GraphValues
		{
			get { return _graphValues; }
			set { _graphValues = value; }
		}

		/// <summary>
		/// Nom de la s�rie
		/// </summary>
		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}

		/// <summary>
		/// Nom localis�e de la s�rie
		/// </summary>
		public string Label
		{
			get { return _label; }
			set { _label = value; }
		}	
		
		/// <summary>
		/// Permet de d�finir si la derni�re valeur d'une serie est ajout�e au titre de la s�rie
		/// </summary>
		public bool	AddLastValueToNom
		{
			get { return _addLastValueToNom; }
			set { _addLastValueToNom = value; }
		} 

        /// <summary>
        /// D�finit la couleur de la s�rie
        /// </summary>
        public Colors.Gcolor Gcolor
        {
            get { return _gcolor; }
            set { _gcolor = value; }
        }

        /// <summary>
        /// D�finit les couleurs sp�cifiques � utiliser pour les valeurs contenues dans la s�rie
        /// </summary>
        public Colors.GcolorValues GcolorValues
        {
            get { return _gcolorValues; }
            set { _gcolorValues = value; }
        }

        #endregion Propri�t�s
    }
}
