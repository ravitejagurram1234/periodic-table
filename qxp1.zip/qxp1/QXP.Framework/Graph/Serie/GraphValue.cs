using System;
using QXPData = QXP.Framework.Data;

namespace QXP.Framework.Graph
{
	/// <summary>
	/// GraphValue d�finit une coordonn�e x et y
	/// </summary>
	public class GraphValue
	{
        #region Membres

		private QXPData.IQXP_Value          _x;
		private QXPData.IQXP_Value	        _y;
        private Colors.Gcolor               _gcolor;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de GraphValue
        /// </summary>
        /// <param name="x">Valeur en abcisse</param>
        /// <param name="y">Valeur en ordonn�e</param>
        /// <param name="gcolor">Coulor associ�e</param>
		public GraphValue(QXPData.IQXP_Value x, QXPData.IQXP_Value y, Colors.Gcolor gcolor)
		{
			this._x			= x;
			this._y			= y;
            this._gcolor    = gcolor;
		}

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
		/// Valeur de l'abcisse (Label)
		/// </summary>	
		public QXPData.IQXP_Value X
		{
			get { return _x; }
			set { _x = value; }
		}

		/// <summary>
		/// Valeur de l'ordonn�e (Valeur)
		/// </summary>
		public QXPData.IQXP_Value Y
		{
			get { return _y; }
			set { _y = value; }
		}

        /// <summary>
        /// D�finit la couleur de la valeur
        /// </summary>
        public Colors.Gcolor Gcolor
        {
            get { return _gcolor; }
            set { _gcolor = value; }
        }

        #endregion Propri�t�s
	}
}
