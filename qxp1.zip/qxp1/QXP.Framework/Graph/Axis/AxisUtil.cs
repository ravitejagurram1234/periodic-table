using System;

namespace QXP.Framework.Graph
{
	/// <summary>
	/// Fournit des fonctions permettant des informations sur les axes des graphiques
	/// </summary>
	/// <author>DOUFARM</author>
	/// <date>03/20/2009 11:50:04</date>    
	public static class AxisUtil{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Permet de calculer l'interval optimal entre 2 valeurs (min et max)
		/// et de red�finir les nouvelle valeurs (min et max)
		/// </summary>
		/// <param name="range">interval original des valeurs (entre min et max). </param>
		/// <param name="targetSteps">nombre d'interval maximum souhait�. </param>
		/// <returns>valeur d'un seul interval. </returns>
		public static float CalcStepSize(float range, float targetSteps)    {
			// calculate an initial guess at step size        
			float tempStep = range/targetSteps;        
			// get the magnitude of the step size        
			float mag		= CalcMagnitude(tempStep);        
			float magPow	= (float)Math.Pow(10, mag);        
			// calculate most significant digit of the new step size        
			float magMsd	= (int)(tempStep/magPow + 0.5);        
			// promote the MSD to either 1, 2, or 5        
			if (magMsd > 5.0)            
				magMsd = 10.0f;        
			else if (magMsd > 2.0)            
				magMsd = 5.0f;        
			else if (magMsd > 1.0)            
				magMsd = 2.0f;        
			return magMsd*magPow;    
		}

		/// <summary>
		/// Calculate the magnitude of the value
		/// </summary>
		/// <param name="value">the value</param>
		/// <returns>the magnitude</returns>
		public static float CalcMagnitude(float value)
		{
			return (float)Math.Floor(Math.Log10(value));
		}

		/// <summary>
		/// Permet de calculer le nombre de d�cimales d'un interval
		/// </summary>
		/// <param name="value">l'interval</param>
		/// <returns>le nombre de d�cimale de cette interval</returns>
		public static int CalcNbDecimal(decimal value)
		{
			if(Validation.IsNotSet(value)) return 0;
			
			float __mag = CalcMagnitude((float)value);
			//si la magnitude est n�gative c'est un nombre � d�cimal
			if(__mag < 0) return (int)Math.Abs(__mag);
			else return 0;
		}

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s


	}
}

