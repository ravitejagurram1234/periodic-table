using System;

namespace QXP.Framework.Graph
{

	/// <summary>
	/// Permet d'evaluer les bornes minimale et maximale ainsi que l'interval optimal
	/// </summary>
	/// <author>DOUFARM</author>
	/// <date>03/20/2009 11:43:00</date>    
	public class AxisRange
	{
		#region Membres
		readonly decimal	_step	 = 1m;
		readonly decimal	_old_Min;
		readonly decimal	_old_Max;
		readonly decimal	_new_Min = 0m;
		readonly decimal	_new_Max = 1m;
		readonly	 int	_nbDecimal;

		#endregion Membres

		#region Constantes
		const int Default_Max_Steps = 10;
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		
		
		/// <summary>
		/// Cr�e une instance de AxisRange en fonction des valeurs min et max pass�es 
		/// </summary>
		/// <param name="min">valeur minimale des donn�es. </param>
		/// <param name="max">valeur maximale des donn�es. </param>
		public AxisRange(object min, object max) : this((decimal)min, (decimal)max, Default_Max_Steps)
		{
		}

		/// <summary>
		/// Cr�e une instance de AxisRange en fonction des valeurs min et max pass�es (avec un nombre d'interval maximum)
		/// </summary>
		/// <param name="min">valeur minimale des donn�es. </param>
		/// <param name="max">valeur maximale des donn�es. </param>
		/// <param name="max_Steps">Nombre d'interval maximum � utilis� pour d�finir l'interval. </param>
		public AxisRange(decimal min, decimal max, int max_Steps )
		{
			_old_Min = (decimal)min;
			_old_Max = (decimal)max;
			
			decimal __range = max - min;
			
			try
			{
				if(Validation.IsSet(__range, false))
				{
					_step = (decimal) AxisUtil.CalcStepSize((float) __range, (float) max_Steps);

					decimal __min_reste = min/_step;
					decimal __max_reste = max/_step;

					_new_Min = Math.Floor(__min_reste)*_step;
					_new_Max = Math.Ceiling(__max_reste)*_step;

					_nbDecimal = AxisUtil.CalcNbDecimal(_step);
				}
				else
				// Si c'est ce cas cela sous entend que le min = max !
				{
					int __comparaison = max.CompareTo(0m);
					// �gal � 0
					if(__comparaison == 0)
					{
						_new_Min = 0m;
						_new_Max = 1m;
						_step	 = 1m;
					}
					//superieur � 0
					else if (__comparaison > 0)
					{
						_new_Min = 0m;
						_new_Max = max;
						_step	 = max;
					}
					//inf�rieur � 0
					else
					{
						_new_Min = min;
						_new_Max = 0m;
						_step	 = Math.Abs(min);
					}
					_nbDecimal = 0;
				}
			}
			catch
			{
			}

		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Valeur Min originale
		/// </summary>
		public decimal Old_Min
		{
			get { return _old_Min; }
		} 
		/// <summary>
		/// Valeur Max originale
		/// </summary>
		public decimal Old_Max
		{
			get { return _old_Max; }
		} 
		/// <summary>
		/// Nouvelle valeur Min calcul�e � partir de l'interval
		/// </summary>
		public decimal New_Min
		{
			get { return _new_Min; }
		} 
		/// <summary>
		/// Nouvelle valeur Max calcul�e � partir de l'interval
		/// </summary>
		public decimal  New_Max
		{
			get { return _new_Max; }
		} 
		/// <summary>
		/// Interval calcul�
		/// </summary>
		public decimal  Step
		{
			get { return _step; }
		}

		/// <summary>
		/// D�fini le nombre de d�cimales n�cessaire pour afficher les intervals, cette valeur est d�duite par la magnitude de l'interval
		/// </summary>
		public int		NbDecimal
		{
			get{return _nbDecimal;}
		}
		#endregion Propri�t�s
	}
}

