using System.Drawing;
using QXPFrk = QXP.Framework;
using SysCharting = System.Web.UI.DataVisualization.Charting;

namespace QXP.Framework.Graph.Charts
{
    /// <summary>
    /// Graphique Histogramme 
    /// </summary>
    public class GraphHistogramme : GraphChart
    {
        #region Membres

        private bool? _enabled3D = null;
        private Color[] _color;

        #endregion Membres

        #region Constructeur

        public GraphHistogramme(Graph graphDefinition)
            : base(graphDefinition)
        {
            _color = new Color[5] 
			{						
				Color.FromArgb(103,31,97),	 //violet3
				Color.FromArgb(244,121,32),  //orange
				Color.FromArgb(230,0,34),	 //rouge
				Color.FromArgb(127,181,57),	 //vert
				Color.FromArgb(192,176,191)  //violet2
			};
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// D�finit le Template d'une s�rie
        /// </summary>
        /// <param name="serie">S�rie </param>
        protected override void DefineSerieTemplate(SysCharting.Series serie)
        {
            base.DefineSerieTemplate(serie);
        }

        /// <summary>
        /// Fonction permettant de d�finir les param�tres hors donn�es des graphes 
        /// </summary>
        protected override void DefineChartTemplate()
        {
            base.DefineChartTemplate();

            #region 3D

            if (this.Enabled3D)
            {
                // Show a X% perspective
                base.ChartArea.Area3DStyle.Perspective = 20;
                // Set the X Angle 
                base.ChartArea.Area3DStyle.Inclination = 20;
                // Set the Y Angle 
                base.ChartArea.Area3DStyle.Rotation = 20;
                // Right angle axis 
                base.ChartArea.Area3DStyle.IsRightAngleAxes = false;
                // Wall width epaisseur du mur 
                base.ChartArea.Area3DStyle.WallWidth = 5;
            }

            #endregion

            this.DefineGridChart();
        }

        #endregion M�thodes

        #region Propri�t�s

        protected override SysCharting.SeriesChartType ChartType
        {
            get { return SysCharting.SeriesChartType.Column; }
        }

        protected override bool Enabled3D
        {
            get
            {
                if (QXPFrk.Validation.IsNull(_enabled3D))
                {
                    _enabled3D = GraphHelper.GetEnabled3D(GraphType.GraphHistogramme);
                }

                return (bool)_enabled3D;
            }
        }

        protected override Color[] ColorSet
        {
            get
            {
                return this._color;
            }
        }

        #endregion Propri�t�s
    }
}
