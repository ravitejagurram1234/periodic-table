using System;
using System.Drawing;
using QXP.Framework.Graph.Charts.Helper;
using QXPFrk = QXP.Framework;
using SysCharting = System.Web.UI.DataVisualization.Charting;

namespace QXP.Framework.Graph.Charts
{
    /// <summary>
    /// Graphique Camembert
    /// </summary>
    public class GraphCamembert : GraphChart
    {
        #region Membres

        private bool? _enabled3D = null;
        private Color[] _color;

        #endregion Membres

        #region Constructeur

        public GraphCamembert(Graph graphDefinition)
            : base(graphDefinition)
        {
            this._color = new Color[6] 
			{	
				//Color.FromArgb(255,221,194), //rose 
				Color.FromArgb(103,31,97),	  //violet3
				Color.FromArgb(192,176,191),  //violet2
				Color.FromArgb(230,223,230),  //violet1 				
				Color.FromArgb(230,0,34),	  //rouge
				Color.FromArgb(127,181,57),	  //vert
				Color.FromArgb(244,121,32)    //orange
			};
        }

        #endregion Constructeur

        #region M�thodes

        public override Bitmap Draw()
        {
            if (this.Series.Count > 1)
                throw new Exception("Impossible de g�n�rer le graphique Camembert avec plus d'une s�rie de donn�e");

            return base.Draw();
        }

        protected override void DefineSerieTemplate(SysCharting.Series serie)
        {
            //Attention ceci est un cas particulier qui affiche toujours soit la valeur des X soit la valeur des Y autour du camembert !
            //si ShowLabelAsValue = false alors on affiche la valeur des X, sinon on affiche la valeur des Y (Avec Formatage)
            serie.IsValueShownAsLabel = this.ShowPointValue;

            //Primordial pour afficher les valeurs de x dans la legende
            serie.LegendText = "";

            //Pour que si la l�gende est affich�e, ce soit les valeurs de l'axe des abcisses qui seront affich�es (cas specifique au camembert)
            //On passe le ShowPointValue a false (g�r�e par la base)
            this.ShowPointValue = false;
            //On affiche les valeurs des points en fonction du format de l'axe des Y
            serie.LabelFormat = FormatHelper.Get_Custom_Format(this.Graph.QXP_Format_Y);
            base.DefineSerieTemplate(serie);
        }


        /// <summary>
        /// Fonction permettant de d�finir les param�tres hors donn�es des graphes 
        /// </summary>
        /// <param name="Chart1"></param>
        /// <param name="type"></param>
        protected override void DefineChartTemplate()
        {

            base.DefineChartTemplate();

        }

        /// <summary>
        /// D�finition des propri�t�s sp�cifique aux series du camenbert
        /// </summary>
        protected override void DefineGraphSeries()
        {
            base.DefineGraphSeries();

            if (base.Chart.Series.Count > 0)
            {
                //ZOOM
                base.Chart.Series[0]["MinimumRelativePieSize"] = "60";


                //type 
                if (!this.Enabled3D)
                {
                    base.Chart.Series[0]["PieDrawingStyle"] = "Concave";
                    base.Chart.Series[0]["PieLabelStyle"] = "Outside";
                    base.Chart.Series[0]["LabelsRadialLineSize"] = "1";
                }
                else
                {
                    base.Chart.Series[0]["PieLabelStyle"] = "Outside";
                    base.Chart.Series[0]["3DLabelLineSize"] = "50"; // Label � l'interieur ou � l'exterieur
                }
            }

        }

        #endregion M�thodes

        #region Propri�t�s

        protected override SysCharting.SeriesChartType ChartType
        {
            get { return SysCharting.SeriesChartType.Pie; }
        }

        protected override bool Enabled3D
        {
            get
            {
                if (QXPFrk.Validation.IsNull(_enabled3D))
                {
                    _enabled3D = GraphHelper.GetEnabled3D(GraphType.GraphCamembert);
                }

                return (bool)_enabled3D;
            }
        }

        protected override Color[] ColorSet
        {
            get
            {
                return this._color;
            }
        }

        #endregion propri�t�s

    }


}
