using System.Collections;
using System.Drawing;
using System.IO;
using QXP.Framework.Graph.Charts.Helper;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using SysCharting = System.Web.UI.DataVisualization.Charting;

namespace QXP.Framework.Graph.Charts
{
    /// <summary>
    /// D�finit la base d'un graphique
    /// </summary>
    public abstract class GraphChart
    {
        #region Membres

        private Graph _graph;
        private SysCharting.Chart _chart;
        private string _id;
        private SysCharting.Title _chartTitle;
        private int _width = int.MinValue;
        private int _height = int.MinValue;
        private string _strNomAxisX;
        private string _strNomAxisY;
        private string _strNomAxisY2;
        private bool _isShowXTitle;
        private bool _isShowYTitle;
        private bool _isShowY2Title;
        private string _titleAxisX;
        private string _titleAxisY;
        private string _titleAxisY2;
        private bool _showPointValue;
        private double _showPointValue_Min = double.MinValue;
        private bool _showPointValue_Min_Strict = false;
        private bool _display_X_Grid = false;
        private bool _display_Y_Grid = false;
        private bool _display_Y2_Grid = false;
        private bool _showAxisY2 = false;

        private Font DefaultFontAxisX = new Font("Arial", 8, FontStyle.Regular);
        private Font DefaultFontAxisY = new Font("Arial", 8, FontStyle.Regular);
        private Font DefaultFontAxisY2 = new Font("Arial", 8, FontStyle.Regular);

        #endregion Membres

        #region Constantes

        private const int DEFAULT_WIDTH = 600;
        private const int DEFAULT_HEIGHT = 400;

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Graphique
        /// </summary>
        public GraphChart(Graph graph)
        {
            _graph = graph;

            _chart = new SysCharting.Chart();
            _chart.Legends.Add("Default");
            _chartTitle = new SysCharting.Title();

            this.Width = graph.Width;
            this.Height = graph.Height;
            this.Title = graph.Title;
            this.IsShowTitle = graph.IsShowTitle;
            this.IsShowLegend = graph.IsShowLegend;
            this.LegendPosition = graph.LegendPosition;
            this.ID = graph.ID;

            this.NameAxisX = graph.NameAxisX;
            this.NameAxisY = graph.NameAxisY;
            this.IsShowXTitle = graph.IsShowXTitle;
            this.IsShowYTitle = graph.IsShowYTitle;
            this.TitleAxisX = graph.TitleAxisX;
            this.TitleAxisY = graph.TitleAxisY;
            this.ShowPointValue = graph.ShowPointValue;
            this.ShowPointValue_Min = Conversion.ToDouble(graph.ShowPointValue_Min);
            this.ShowPointValue_Min_Strict = graph.ShowPointValue_Min_Strict;

            this.Display_X_Grid = graph.Display_X_Grid;
            this.Display_Y_Grid = graph.Display_Y_Grid;
            this.Display_Y2_Grid = graph.Display_Y2_Grid && this.Series.Count == 2; ;
            this.ShowAxisY2 = graph.ShowAxisY2 && this.Series.Count == 2;
            if (ShowAxisY2)
                this.ChartArea.AxisY2.Enabled = SysCharting.AxisEnabled.True;
            else
                this.ChartArea.AxisY2.Enabled = SysCharting.AxisEnabled.False;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Permet de g�n�rer le graphique � partir des s�ries du graph
        /// </summary>
        /// <returns>Le Bitmap du graphique</returns>
        public virtual Bitmap Draw()
        {

            DefineChartTemplate();

            DefineGraphSeries();

            return GetImage();
        }

        /// <summary>
        /// Retourne l'ensemble des labels / valeurs du graphique
        /// </summary>
        /// <param name="graphValues">Liste des valeurs d'une s�rie</param>
        /// <returns>Un tableau d'IEnumerable, le premier �lement est la liste des labels, le second la liste des valeurs</returns>
        protected IEnumerable[] GetXandYValues(GraphValues graphValues)
        {
            //On r�cup�re les valeurs de x et y
            IEnumerable __xv = graphValues.Get_X_Values(false);
            IEnumerable __yv = graphValues.Get_Y_Values(false);

            return new IEnumerable[] { __xv, __yv };
        }

        /// <summary>
        /// Permet d'ajouter une s�rie au graphique
        /// </summary>
        /// <param name="xValues">Valeurs de l'axe des abcisses</param>
        /// <param name="yValues">Valeurs de l'axe des ordonn�es</param>
        /// <param name="serie">S�rie associ�e</param>
        /// <param name="indexSerie">Index de la s�rie</param>
        protected virtual void DrawSerieWithXYValue(IEnumerable xValues, IEnumerable yValues, Serie serie, int indexSerie)
        {
            SysCharting.Series __serie = new SysCharting.Series(serie.Name);
            __serie.ChartType = this.ChartType;
            __serie.LegendText = serie.Label;
            this.Chart.Series.Add(__serie);
            __serie.Points.DataBindXY(xValues, yValues);
            if (indexSerie == 2 && ShowAxisY2)
                __serie.YAxisType = SysCharting.AxisType.Secondary;
            DefineSerieTemplate(__serie);

        }

        /// <summary>
        /// D�finit le Template d'une s�rie
        /// </summary>
        /// <param name="serie">S�rie </param>
        protected virtual void DefineSerieTemplate(SysCharting.Series serie)
        {
            //Affichage des valeurs de chaque point du graphique
            if (this.ShowPointValue)
            {

                //try catch r�alis� nous nous basons sur les valeurs des series et nous modifions les propri�t�s des points de la s�rie
                //on se sait jamais si on �value un nombre de points diff�rents !!
                try
                {
                    //Si une valeur minimum n'est d�finie alors on affiche toutes les etiquettes
                    bool __default_Show = Validation.IsNotSet(this.ShowPointValue_Min, true);

                    foreach (SysCharting.DataPoint __datapoint in serie.Points)
                    {
                        bool __show;
                        if (__default_Show)
                        {
                            __show = true;
                        }
                        else
                        {
                            if (this.ShowPointValue_Min_Strict)
                            {
                                __show = (__datapoint.YValues[0] > this.ShowPointValue_Min);
                            }
                            else
                            {
                                __show = (__datapoint.YValues[0] >= this.ShowPointValue_Min);
                            }
                        }

                        if (__show)
                        {
                            double __value;

                            if (this._graph.QXP_Format_Y.Is_Percent)
                                __value = __datapoint.YValues[0] / 100d;
                            else
                                __value = __datapoint.YValues[0];

                            __datapoint.Label = __value.ToString(FormatHelper.Get_Custom_Format(this._graph.QXP_Format_Y));
                        }
                    }

                }
                catch { }
            }

            //Pour que les valeurs null n'apparaissent pas
            serie.EmptyPointStyle.BorderWidth = 0;
        }

        /// <summary>
        /// Fonction permettant de d�finir les param�tres hors donn�es des graphes 
        /// </summary>
        protected virtual void DefineChartTemplate()
        {
            #region G�om�trie du graph

            this.Chart.Height = this.Height;
            this.Chart.Width = this.Width;

            #endregion G�om�trie du graph

            #region Affichage du graph

            //TODO : (� modifier prochainement avec l'arriv�e des GColors)
            this.Chart.Palette = SysCharting.ChartColorPalette.None;
            this.Chart.PaletteCustomColors = ColorSet;
            this.DefineBackgroundChart();

            //3D
            this.ChartArea.Area3DStyle.Enable3D = this.Enabled3D;

            #region cadre du graph

            // Cadre du graphique 
            this.Chart.BorderlineColor = Color.Black;
            this.Chart.BorderlineDashStyle = SysCharting.ChartDashStyle.Solid;
            this.Chart.BorderWidth = 1;

            #endregion

            #endregion Affichage du graph

            #region Titre du graphique
            #endregion Titre du graphique

            #region L�gende
            this.ChartLegend.IsTextAutoFit = true;
            #endregion L�gende

            #region Grille
            #endregion Grille

            #region Axes du graphique

            DefineAxisX();

            DefineAxisY();

            if (ShowAxisY2)
            {
                DefineAxisY2();
            }

            //D�finition des limites inf�rieur et sup�rieur de l'axe des Y et Y2
            this.DefineGraphRanges();

            #endregion Axes du graphique
        }

        /// <summary>
        /// D�finition des series du graph, cette methode peut �tre overrid�
        /// </summary>
        protected virtual void DefineGraphSeries()
        {
            if (this.Series.Values.Count > 0)
            {
                int __index = 1;
                foreach (Serie __serie in this.Series.Values)
                {
                    if (__serie.GraphValues.HaveValues)
                    {
                        IEnumerable[] tabIEnumerable = this.GetXandYValues(__serie.GraphValues);
                        this.DrawSerieWithXYValue(tabIEnumerable[0], tabIEnumerable[1], __serie, __index++);
                    }
                }
            }
        }

        /// <summary>
        /// M�thode permettant de retourner une image � partir d'un objet Graph 
        /// </summary>
        /// <returns>L'image BITMAP du graphique</returns>
        protected virtual Bitmap GetImage()
        {
#if (DEBUG)
            QXPDiagnostic.Performance __perf = new QXPDiagnostic.Performance("Graphique");
#endif

            this.Chart.ImageType = SysCharting.ChartImageType.Png;
            MemoryStream __ms = new MemoryStream();
            this.Chart.SaveImage(__ms, SysCharting.ChartImageFormat.Png);
            Bitmap _img = new Bitmap(__ms);

#if (DEBUG)
            System.Diagnostics.Debug.WriteLine(__perf.GetTotalMilliseconds("GetImage"));
#endif

            return _img;
        }

        /// <summary>
        /// Permet de d�finir le param�trage de l'axe des abcisses
        /// </summary>
        protected virtual void DefineAxisX()
        {
            this.ChartArea.AxisX.Name = this.NameAxisX;

            this.ChartArea.AxisX.LabelStyle.Font = DefaultFontAxisX;

            if (this.IsShowXTitle)
            {
                this.ChartArea.AxisX.Title = this.TitleAxisX;
            }

            //D�finition du nombre de d�cimal axe X
            this.ChartArea.AxisX.LabelStyle.Format = FormatHelper.Get_Custom_Format(this._graph.QXP_Format_X);

            this.ChartArea.AxisX.IntervalAutoMode = SysCharting.IntervalAutoMode.VariableCount;
        }

        /// <summary>
        /// Permet de d�finir le param�trage de l'axe des ordonn�es
        /// </summary>
        protected virtual void DefineAxisY()
        {
            this.ChartArea.AxisY.Name = this.NameAxisY;

            this.ChartArea.AxisY.LabelStyle.Font = DefaultFontAxisY;

            if (this.IsShowYTitle)
            {
                this.ChartArea.AxisY.Title = this.TitleAxisY;
            }

            if (ShowAxisY2)
            {
                //Si un second axe des ordonn�es est affich�, les couleurs des s�ries correspondent aux couleurs des axes des ordonn�es
                this.ChartArea.AxisY.LineColor = ColorSet[0];
                this.ChartArea.AxisY.InterlacedColor = ColorSet[0];
                this.ChartArea.AxisY.TitleForeColor = ColorSet[0];
                this.ChartArea.AxisY.MinorTickMark.LineColor = ColorSet[0];
                this.ChartArea.AxisY.MajorTickMark.LineColor = ColorSet[0];
                this.ChartArea.AxisY.LabelStyle.ForeColor = ColorSet[0];
            }
        }

        /// <summary>
        /// Permet de d�finir le param�trage de le second axe des ordonn�es (si souhait�)
        /// </summary>
        protected virtual void DefineAxisY2()
        {
            this.ChartArea.AxisY2.Name = this.NameAxisY2;

            this.ChartArea.AxisY2.LabelStyle.Font = DefaultFontAxisY;

            if (this.IsShowYTitle)
            {
                this.ChartArea.AxisY2.Title = this.TitleAxisY2;
            }

            this.ChartArea.AxisY2.LineColor = ColorSet[1];
            this.ChartArea.AxisY2.InterlacedColor = ColorSet[1];
            this.ChartArea.AxisY2.TitleForeColor = ColorSet[1];
            this.ChartArea.AxisY2.MinorTickMark.LineColor = ColorSet[1];
            this.ChartArea.AxisY2.MajorTickMark.LineColor = ColorSet[1];
            this.ChartArea.AxisY2.LabelStyle.ForeColor = ColorSet[1];
            this.ChartArea.AxisY2.IntervalAutoMode = SysCharting.IntervalAutoMode.VariableCount;
        }

        /// <summary>
        /// Permet de d�finir le quadrillage du graphique 
        /// </summary>
        protected virtual void DefineGridChart()
        {
            this.ChartArea.AxisX.MinorGrid.Enabled = false;
            this.ChartArea.AxisX.MinorTickMark.Enabled = false;

            this.ChartArea.AxisX.MajorGrid.Enabled = this.Display_X_Grid;
            this.ChartArea.AxisX.MajorGrid.LineDashStyle = SysCharting.ChartDashStyle.Dash;
            this.ChartArea.AxisX.MajorTickMark.Enabled = true;

            this.ChartArea.AxisY.MajorGrid.Enabled = this.Display_Y_Grid;
            this.ChartArea.AxisY.MajorGrid.LineDashStyle = SysCharting.ChartDashStyle.Dash;
            this.ChartArea.AxisY.MinorGrid.Enabled = false;

            if (ShowAxisY2)
            {
                this.ChartArea.AxisY2.MajorGrid.Enabled = this.Display_Y2_Grid;
                this.ChartArea.AxisY2.MajorGrid.LineDashStyle = SysCharting.ChartDashStyle.Dash;
                this.ChartArea.AxisY2.MinorGrid.Enabled = false;
            }

            // Set Line Color
            this.ChartArea.AxisX.MinorGrid.LineColor = Color.Silver;
            this.ChartArea.AxisY.MinorGrid.LineColor = Color.DarkGray;
            this.ChartArea.AxisY2.MinorGrid.LineColor = Color.DarkGray;

            this.ChartArea.AxisX.MajorGrid.LineColor = Color.Silver;
            this.ChartArea.AxisY.MajorGrid.LineColor = Color.DarkGray;
            this.ChartArea.AxisY2.MajorGrid.LineColor = Color.DarkGray;

        }

        /// <summary>
        /// Permet de d�finir les bornes min et max du graphique
        /// </summary>
        protected virtual void DefineGraphRanges()
        {
            if (Validation.IsNotNull(this.Series.Min_Y) && Validation.IsNotNull(this.Series.Max_Y))
            {
                if (this.Series.Count > 0)
                {
                    AxisRange __axisRange_Y = _graph.AxisRange_Y;

                    if (Validation.IsNotNull(__axisRange_Y))
                    {
                        double __axisMinValue = (double)__axisRange_Y.New_Min;
                        double __axisMaxValue = (double)__axisRange_Y.New_Max;
                        double __step = (double)__axisRange_Y.Step;

                        this.ChartArea.AxisY.Minimum = __axisMinValue;
                        this.ChartArea.AxisY.Maximum = __axisMaxValue;
                        this.ChartArea.AxisY.Interval
                            = this.ChartArea.AxisY.MajorGrid.Interval
                            = this.ChartArea.AxisY.MinorGrid.Interval
                            = __step;

                        if (Validation.IsNotSet(_graph.QXP_Format_Y.Number_Nb_Decimal))
                        {
                            //Mise � jour du nombre de d�cimales sur l'axe Y avec la valeur �valuer par AxisRange
                            this._graph.QXP_Format_Y.ChangeNbDecimal(__axisRange_Y.NbDecimal);
                        }

                        //D�finition du nombre de d�cimal axe Y
                        this.ChartArea.AxisY.LabelStyle.Format = FormatHelper.Get_Custom_Format(this._graph.QXP_Format_Y);
                    }
                }
            }

            if (ShowAxisY2 && Validation.IsNotNull(this.Series.Min_Y2) && Validation.IsNotNull(this.Series.Max_Y2))
            {
                if (this.Series.Count >= 2)
                {
                    AxisRange __axisRange_Y2 = _graph.AxisRange_Y2;
                    if (Validation.IsNotNull(__axisRange_Y2))
                    {
                        double __axisMinValue = (double)__axisRange_Y2.New_Min;
                        double __axisMaxValue = (double)__axisRange_Y2.New_Max;
                        double __step = (double)__axisRange_Y2.Step;

                        this.ChartArea.AxisY2.Minimum = __axisMinValue;
                        this.ChartArea.AxisY2.Maximum = __axisMaxValue;
                        this.ChartArea.AxisY2.Interval
                            = this.ChartArea.AxisY2.MajorGrid.Interval
                            = this.ChartArea.AxisY2.MinorGrid.Interval
                            = __step;

                        if (Validation.IsNotSet(_graph.QXP_Format_Y2.Number_Nb_Decimal))
                        {
                            //Mise � jour du nombre de d�cimales sur l'axe Y avec la valeur �valuer par AxisRange
                            this._graph.QXP_Format_Y2.ChangeNbDecimal(__axisRange_Y2.NbDecimal);
                        }

                        //D�finition du nombre de d�cimal axe Y
                        this.ChartArea.AxisY2.LabelStyle.Format = FormatHelper.Get_Custom_Format(this._graph.QXP_Format_Y2);
                    }
                }
            }
        }

        /// <summary>
        /// Permet de d�finir le fond du graphique
        /// </summary>
        protected virtual void DefineBackgroundChart()
        {
            // Set Back Color
            this.ChartArea.BackColor = Color.Transparent;
            this.ChartArea.BorderDashStyle = SysCharting.ChartDashStyle.NotSet;
            this.ChartLegend.BackColor = Color.Transparent;
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Liste des couleurs � utiliser (� modifier prochainement avec l'arriv�e des GColors)
        /// </summary>
        protected abstract Color[] ColorSet { get; }

        /// <summary>
        /// Type de graphique 
        /// </summary>
        protected abstract SysCharting.SeriesChartType ChartType { get; }

        /// <summary>
        /// La 3D est active ou non
        /// </summary>
        protected abstract bool Enabled3D { get; }

        /// <summary>
        /// Graphique QXP permettant de g�n�rer le graphique 
        /// </summary>
        public Graph Graph
        {
            get { return _graph; }
            set { _graph = value; }
        }

        /// <summary>
        /// ID du graphique (utilis�e pour l'handler graphique)
        /// </summary>
        public string ID
        {
            get { return this._id; }
            set { this._id = value; }
        }

        /// <summary>
        /// Graphique 
        /// </summary>
        protected SysCharting.Chart Chart
        {
            get { return _chart; }
            set { _chart = value; }
        }

        /// <summary>
        /// Zone de dessin du graphique 
        /// </summary>
        protected SysCharting.ChartArea ChartArea
        {
            get
            {
                if (Chart.ChartAreas.Count == 0)
                    this.Chart.ChartAreas.Add(new SysCharting.ChartArea());
                return Chart.ChartAreas[0];
            }
        }

        /// <summary>
        /// Largeur du graphique
        /// </summary>
        public int Width
        {
            get
            {
                if (Validation.IsNotSet(this._width))
                    this._width = DEFAULT_WIDTH;
                return this._width;
            }
            set { this._width = value; }
        }

        /// <summary>
        /// Hauteur du graphique
        /// </summary>
        public int Height
        {
            get
            {
                if (Validation.IsNotSet(this._height))
                    this._height = DEFAULT_HEIGHT;
                return this._height;
            }
            set { this._height = value; }
        }

        /// <summary>
        /// Le titre du graph est affich� ou non
        /// </summary>
        public bool IsShowTitle
        {
            get { return _chart.Titles[0].Visible; }
            set { _chart.Titles[0].Visible = value; }
        }

        /// <summary>
        /// Titre du graphique
        /// </summary>
        public string Title
        {
            set
            {
                // r�initialise tout les titres
                _chart.Titles.Clear();
                // ajout d'un nouveau Titre 
                _chart.Titles.Add(_chartTitle);
                // Valeur
                _chartTitle.Text = value;
                // Style Font
                _chartTitle.Font = new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Bold);

            }

            get { return _chartTitle.Text.ToString(); }
        }

        /// <summary>
        /// La l�gende du graph est affich�e ou non
        /// </summary>
        public bool IsShowLegend
        {
            get { return ChartLegend.Enabled; }
            set { ChartLegend.Enabled = value; }
        }

        /// <summary>
        /// La l�gende du graph 
        /// </summary>
        public SysCharting.Legend ChartLegend
        {
            get { return this._chart.Legends["Default"]; }
        }
        /// <summary>
        /// Position de la l�gende
        /// </summary>
        public PositionLegende LegendPosition
        {

            get
            {
                switch (this.ChartLegend.Docking)
                {
                    case SysCharting.Docking.Bottom:
                        return PositionLegende.Bottom;
                    case SysCharting.Docking.Left:
                        return PositionLegende.Left;
                    case SysCharting.Docking.Top:
                        return PositionLegende.Top;
                    case SysCharting.Docking.Right:
                    default:
                        return PositionLegende.Right;
                }
            }
            set
            {
                switch (value)
                {
                    case PositionLegende.Top:
                        this.ChartLegend.Docking = SysCharting.Docking.Top;
                        //par d�faut l'alignement est � gauche il faut donc le mettre au centre
                        this.ChartLegend.Alignment = StringAlignment.Center;
                        break;
                    case PositionLegende.Bottom:
                        this.ChartLegend.Docking = SysCharting.Docking.Bottom;
                        //par d�faut l'alignement est � gauche il faut donc le mettre au centre
                        this.ChartLegend.Alignment = StringAlignment.Center;
                        break;
                    case PositionLegende.Left:
                        this.ChartLegend.Docking = SysCharting.Docking.Left;
                        break;
                    case PositionLegende.Right:
                    default:
                        this.ChartLegend.Docking = SysCharting.Docking.Right;
                        break;
                }
            }
        }

        /// <summary>
        /// Listes des s�ries du graphique
        /// </summary>
        public SerieList Series
        {
            get { return Graph.Series; }
        }

        /// <summary>
        /// Nom de l'axe des abcisses
        /// </summary>
        public string NameAxisX
        {
            get { return this._strNomAxisX; }
            set { this._strNomAxisX = value; }
        }

        /// <summary>
        /// Nom de l'axe des ordonn�es
        /// </summary>
        public string NameAxisY
        {
            get { return this._strNomAxisY; }
            set { this._strNomAxisY = value; }
        }

        /// <summary>
        /// Nom du second axe des ordonn�es (si pr�sent)
        /// </summary>
        public string NameAxisY2
        {
            get { return this._strNomAxisY2; }
            set { this._strNomAxisY2 = value; }
        }

        /// <summary>
        /// Le titre de l'axe des abcisses est affich� ou non
        /// </summary>
        public bool IsShowXTitle
        {
            get { return this._isShowXTitle; }
            set { this._isShowXTitle = value; }
        }

        /// <summary>
        /// Le titre de l'axe des ordonn�es est affich� ou non
        /// </summary>
        public bool IsShowYTitle
        {
            get { return this._isShowYTitle; }
            set { this._isShowYTitle = value; }
        }

        /// <summary>
        /// Le titre du second axe des ordonn�es est affich� ou non
        /// </summary>
        public bool IsShowY2Title
        {
            get { return this._isShowY2Title; }
            set { this._isShowY2Title = value; }
        }

        /// <summary>
        /// Titre de l'axe des abcisses
        /// </summary>
        public string TitleAxisX
        {
            get { return this._titleAxisX; }
            set { this._titleAxisX = value; }
        }

        /// <summary>
        /// Titre de l'axe des ordonn�es
        /// </summary>
        public string TitleAxisY
        {
            get { return this._titleAxisY; }
            set { this._titleAxisY = value; }
        }

        /// <summary>
        /// Titre du second axe des ordonn�es
        /// </summary>
        public string TitleAxisY2
        {
            get { return this._titleAxisY2; }
            set { this._titleAxisY2 = value; }
        }

        /// <summary>
        /// Les valeurs des points du graphique sont affich�es ou non
        /// </summary>
        public bool ShowPointValue
        {
            get { return _showPointValue; }
            set { _showPointValue = value; }
        }

        /// <summary>
        /// D�fini la limite � partir de laquelle les etiquettes des valeurs Y sont affich�es
        /// voir la propri�t� ShowPointValue_Min_Strict pour savoir si cette limit est stricte ou pas
        /// si cette valeurs est �gale � decimal.MinValue toutes les etiquettes sont affich�es.
        /// </summary>
        public double ShowPointValue_Min
        {
            get { return _showPointValue_Min; }
            set { _showPointValue_Min = value; }
        }

        /// <summary>
        /// D�fini Le faite que la valeur de ShowPointValue_Min correspond � une limite stricte
        /// si ShowPointValue_Min_Strict est true alors les valeurs doivent �tre strictement sup�rieur � ShowPointValue_Min
        /// sinon les valeurs doivents �tre sup�rieures ou �gales.
        /// par d�faut (false) c'est � dire sup�rieure ou �gale.
        /// </summary>
        public bool ShowPointValue_Min_Strict
        {
            get { return _showPointValue_Min_Strict; }
            set { _showPointValue_Min_Strict = value; }
        }

        /// <summary>
        /// Permet l'affichage du quadrillage sur l'axe des X
        /// </summary>
        public bool Display_X_Grid
        {
            get { return _display_X_Grid; }
            set { _display_X_Grid = value; }
        }

        /// <summary>
        /// Permet l'affichage du quadrillage sur l'axe des ordonn�es
        /// </summary>
        public bool Display_Y_Grid
        {
            get { return _display_Y_Grid; }
            set { _display_Y_Grid = value; }
        }

        /// <summary>
        /// Permet l'affichage d'un second axe des Y (uniquement si deux s�ries pr�sentes)
        /// </summary>
        public bool ShowAxisY2
        {
            get { return _showAxisY2; }
            set { _showAxisY2 = value; }
        }


        /// <summary>
        /// Permet l'affichage du quadrillage sur le second axe des Y (uniquement si deux s�ries pr�sentes)
        /// </summary>
        public bool Display_Y2_Grid
        {
            get { return _display_Y2_Grid; }
            set { _display_Y2_Grid = value; }
        }

        #endregion Propri�t�s
    }

}

