using SysCharting = System.Web.UI.DataVisualization.Charting;

namespace QXP.Framework.Graph.Charts
{
    /// <summary>
    /// Graphique Histogramme empil� 100% 
    /// </summary>
    public class GraphHistoCondense : GraphHistogramme
    {
        #region Constructeur

        public GraphHistoCondense(Graph graphDefinition)
            : base(graphDefinition)
        {
        }

        #endregion Constructeur

        #region Methodes
        /// <summary>
        /// Permet de supprimer l'�valuation des intervals dans ce type de graphique
        /// </summary>
        protected override void DefineGraphRanges()
        {
            //rien � faire surtout ne pas appeler la base !
        }
        #endregion Methodes

        #region Propri�t�s

        protected override SysCharting.SeriesChartType ChartType
        {
            get { return SysCharting.SeriesChartType.StackedColumn100; }
        }

        #endregion Propri�t�s
    }

}
