using WinCharting = System.Web.UI.DataVisualization.Charting;

namespace QXP.Framework.Graph.Charts
{
    /// <summary>
    /// Graphique Courbe avec des "Markers" au niveau de chaque point de la courbe
    /// </summary>
    public class GraphCourbeWithMarker : GraphCourbe
    {
        #region Constructeur

        public GraphCourbeWithMarker(Graph graphDefinition)
            : base(graphDefinition)
        {
        }

        #endregion Constructeur

        #region M�thodes

        protected override void DefineSerieTemplate(WinCharting.Series serie)
        {
            base.DefineSerieTemplate(serie);
            serie["ShowMarkerLines"] = "true";
        }

        #endregion M�thodes
    }


}