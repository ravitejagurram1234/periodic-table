using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

using QXP.Framework.Data.Format;

namespace QXP.Framework.Graph.Charts.Helper
{
    /// <summary>
    /// Helper FormatHelper
    /// </summary>
    /// <author>cueffl</author>
    /// <date>15/05/2009 17:06:28</date>    
    public class FormatHelper
    {
        #region Membres

        #endregion Membres

        #region Constantes

        internal const string SEPARATEUR_DECIMAL = ".";
        internal const string SEPARATEUR_MILLIER = ",";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Constructeur static FormatHelper
        /// </summary>
        static FormatHelper()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Retourne le format � partir d'un QXP_Format
        /// </summary>
        /// <param name="format">QXP_Format � utiliser pour g�n�rer le Format </param>
        /// <returns>Le custom format </returns>
        public static string Get_Custom_Format(QXP_Format format)
        {

            //Un format personnalis� est d�fini
            if (Validation.IsSet(format.Custom_Format_String))
            {
                /*La d�finition du format fonctionne de la m�me mani�re que .NET : cf MSDN Custom Numeric Format Strings*/

                //on renvoit donc le custom_strong_format
                return format.Custom_Format_String;

            }
            else
            {

                /*La d�finition du format fonctionne de la m�me mani�re que .NET : cf MSDN Custom Numeric Format Strings*/

                //Le format est un nombre (pourcentage, devise, nombre..)
                if (format is QXP_Format.QXP_Format_Number)
                {

                    //Ici on ne peut pas utiliser le s�parateur fourni par l'QXP_Format
                    string __customFormatPositif = string.Concat("#", SEPARATEUR_MILLIER, "##0");

                    if (format.Number_Nb_Decimal.HasValue && Validation.IsSet(format.Number_Nb_Decimal.Value))
                    {
                        __customFormatPositif = string.Concat(__customFormatPositif, SEPARATEUR_DECIMAL, new string('0', format.Number_Nb_Decimal.Value));
                    }

                    string __customFormatNegatif = __customFormatPositif;

                    //Format d�fini en fonction du format des nombres n�gatifs (se base sur le format d�fini par .Net)
                    switch (format.Number_Format_Negatif)
                    {
                        case 0:
                            __customFormatNegatif = string.Concat("(", __customFormatNegatif, ")");
                            break;
                        case 1:
                            __customFormatNegatif = string.Concat("-", __customFormatNegatif);
                            break;
                        case 2:
                            __customFormatNegatif = string.Concat("- ", __customFormatNegatif);
                            break;
                        case 3:
                            __customFormatNegatif = string.Concat(__customFormatNegatif, "-");
                            break;
                        case 4:
                            __customFormatNegatif = string.Concat(__customFormatNegatif, " -");
                            break;
                    }

                    //Format de type pourcentage
                    if (format.Is_Percent)
                    {
                        //Le signe pourcentage n'est la que pour l'affichage !! s'il n'�tait pas pr�c�d� par \ la valeur de la chaine serait multipli� par 100
                        __customFormatPositif = string.Concat(__customFormatPositif, @"\%");
                        __customFormatNegatif = string.Concat(__customFormatNegatif, @"\%");
                    }

                    return string.Concat(__customFormatPositif, ";", __customFormatNegatif);

                }
                else if (format is QXP_Format.QXP_Format_DateTime)
                {
                    string __dateFormat = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern.Replace("yyyy", "yy");

                    if (format.Is_DateTime)
                        __dateFormat = string.Concat(__dateFormat, " HH:mm:ss");
                    return __dateFormat;
                }
                else
                    return string.Empty;
            }
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
