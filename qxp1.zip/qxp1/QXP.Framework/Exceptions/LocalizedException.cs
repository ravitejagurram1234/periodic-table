using System;

using QXPAPP					= QXP.Framework.Application;


namespace QXP.Framework.Exceptions
{
	/// <summary>
	/// Description r�sum�e de LocalizedException.
	/// </summary>
	public class LocalizedException: Exception
	{

		#region Variables Internes

		#endregion

		public LocalizedException()
		{
			//
			// TODO�: ajoutez ici la logique du constructeur
			//
		}

		public LocalizedException(string message): base(message)
		{
		}


		#region Propri�t�s

		public override string ToString()
		{
			string __exception = base.GetType().Name;
			return QXPAPP.Application.Resources.GetGlobalExceptionMessage(__exception);
		} // ToString


		#endregion


	}
}
