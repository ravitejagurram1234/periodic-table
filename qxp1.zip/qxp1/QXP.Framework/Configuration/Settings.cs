using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Configuration
{
    /// <summary>
    /// Class Settings
    /// Provides access to  configuration settings.
    /// </summary>
    /// <author>LCU</author>
    /// <date>23/09/2009</date>    
    public class Settings  : BaseSetting<Settings>
    {
        #region Membres

        private static Settings _setting;

        #endregion Membres

        #region Constantes

        const string APPSETTINGS_SECTION = "appSettings";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Settings
        /// </summary>
        public Settings():base(APPSETTINGS_SECTION)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
