using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace QXP.Framework.Configuration
{
    /// <summary>
    /// Class DBConnectionSettings
    /// Provides access to DB configuration settings.
    /// </summary>
    /// <author>LCU</author>
    /// <date>23/09/2009</date> 
    public class DBConnectionSettings : BaseSetting<DBConnectionSettings>
    {
        #region	Membres

        private string _defaultDBConnectionString;
        const string DBCONNECTION_SECTION = "DBConnectionSettings";
        const string DEFAULT_DB_SETTING_KEY = "DBConnection";
        const string DEFAULT_DB_CONNECTION_NAME = "Default"; //Nom de la chaine de connexion par d�faut et pr�sente dans le fichier de config

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur
        
        /// <summary>
        /// Initializes a new instance of the <see cref="DBConnectionSettings"/> class.
        /// </summary>
        public DBConnectionSettings() : base(DBCONNECTION_SECTION)
        {
            string __defaultDBConnectionString = Settings.Current.GetString(DEFAULT_DB_SETTING_KEY);

            if (Validation.IsSet(__defaultDBConnectionString))
            {
                _defaultDBConnectionString = Security.Crypt.DecryptStringFK(__defaultDBConnectionString);
            }
            else
            {
                _defaultDBConnectionString = GetDBConnectionString(DEFAULT_DB_CONNECTION_NAME);
            }
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Retourne la chaine de connexion identifi�e par la cl�
        /// </summary>
        /// <param name="DBkey">Cl� de la chaine de connexion</param>
        /// <returns>Un string</returns>
        public string GetDBConnectionString(string DBkey)
        {
            string __dbConnectionString = string.Empty;

            if (Validation.IsSet(DBkey))
            {
                if (Validation.IsNotNull(base.Section))
                {
                    __dbConnectionString = base.GetString(DBkey);

                    if (Validation.IsSet(__dbConnectionString))
                    {
                        __dbConnectionString = Security.Crypt.DecryptStringFK(__dbConnectionString);
                    }
                    else
                        throw new ArgumentException(string.Format("Chaine de connexion : {0} invalide", DBkey));
                }
                else
                {
                    throw new ArgumentException("Liste de Chaine de connexion dans le fichier de config non d�finie !");
                }
            }
            else
                throw new ArgumentNullException("Chaine de connexion inexistante.");

            return __dbConnectionString;
        }

        /// <summary>
        /// Chaine de connexion par d�faut
        /// </summary>
        /// <returns>Un string</returns>
        public string GetDefaultDBConnectionString()
        {
            return _defaultDBConnectionString;
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
