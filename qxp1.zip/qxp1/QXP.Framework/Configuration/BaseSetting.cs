using System;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Text;
using QXPFrk = QXP.Framework;

namespace QXP.Framework.Configuration
{
    /// <summary>
    /// Class BaseSetting
    /// </summary>
    /// <author>LCU</author>
    /// <date>23/09/2009</date>    
    public abstract class BaseSetting<T> where T : class, new()
    {
        #region Membres

        private static Dictionary<Type, T> _settings = new Dictionary<Type,T>();
        private NameValueCollection _section = null;
        private static object syncObject = new object();

        #endregion Membres

        #region Constantes   

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        protected BaseSetting(string sectionName)
        {
            this._section = (NameValueCollection) ConfigurationManager.GetSection(sectionName);
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <returns>A <see cref="bool"/> representation of the configuration setting value. </returns>
        public virtual bool GetBool(string key)
        {
            return Conversion.ToBool(this.GetSetting(key));
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <param name="defValue">default value if the setting doesn't exist. </param>
        /// <returns>A <see cref="bool"/> representation of the configuration setting value. </returns>
        public virtual bool GetBool(string key, bool defValue)
        {
            if(Validation.IsSet(this.GetSetting(key)))	return Conversion.ToBool(this.GetSetting(key));
			else										return defValue;
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <returns>A <see cref="String"/> representation of the configuration setting value. </returns>
        public virtual string GetString(string key)
        {
            return this.GetSetting(key);
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <param name="defValue">default value if the setting doesn't exist. </param>
        /// <returns>A <see cref="String"/> representation of the configuration setting value. </returns>
        public virtual string GetString(string key, string defValue)
        {
            if(Validation.IsSet(this.GetSetting(key)))	return this.GetSetting(key);
			else										return defValue;
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <returns>A <see cref="int"/> representation of the configuration setting value. </returns>
        public virtual int GetInt(string key)
        {
            return Conversion.ToInt(this.GetSetting(key));
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <param name="defValue">default value if the setting doesn't exist. </param>
        /// <returns>A <see cref="int"/> representation of the configuration setting value. </returns>
        public virtual int GetInt(string key, int defValue)
        {
            return Conversion.ToInt(this.GetSetting(key), defValue);
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <returns>A <see cref="decimal"/> representation of the configuration setting value. </returns>
        public virtual decimal GetDecimal(string key)
        {
            return Conversion.ToDecimal(this.GetSetting(key), System.Globalization.NumberFormatInfo.InvariantInfo);
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <param name="defValue">default value if the setting doesn't exist. </param>
        /// <returns>A <see cref="decimal"/> representation of the configuration setting value. </returns>
        public virtual decimal GetDecimal(string key, decimal defValue)
        {
			return Conversion.ToDecimal(this.GetSetting(key), System.Globalization.NumberFormatInfo.InvariantInfo, defValue);
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <returns>A <see cref="float"/> representation of the configuration setting value. </returns>
        public virtual float GetFloat(string key)
        {
            return Conversion.ToFloat(this.GetSetting(key), NumberFormatInfo.InvariantInfo);
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <returns>A <see cref="double"/> representation of the configuration setting value. </returns>
        public virtual double GetDouble(string key)
        {
            return Conversion.ToDouble(this.GetSetting(key), NumberFormatInfo.InvariantInfo);
        }

        /// <summary>Returns a configuration setting for the provided <paramref name="key"/> in the <see cref="DefaultSection"/>. </summary>
        /// <param name="key">A <see cref="String"/> representing the setting to read. </param>
        /// <returns>A <see cref="TimeSpan"/> representation of the configuration setting value. </returns>
        public virtual TimeSpan GetTimeSpanFromSeconds(string key)
        {
            int __seconds = this.GetInt(key);
            if (QXPFrk.Validation.IsSet(__seconds))
                return TimeSpan.FromSeconds(__seconds);
            else
                return TimeSpan.MinValue;
        }

        protected virtual string GetSetting(string key)
        {                     
            if (Validation.IsSet(key))
            {
                return Section[key];
            }
            else
            {
                return string.Empty;
            }
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>Gets or sets a <see cref="BaseSetting"/> instance containing all configuration information available to the current assembly. </summary>
        public static T Current
        {
            get
            {                               
                if(_settings.ContainsKey(typeof(T)))
                {
                    return _settings[typeof(T)];
                }
                else
                {
                    
                    lock (syncObject)
                    {
                        if (_settings.ContainsKey(typeof(T)))
                            return _settings[typeof(T)];
                        T __newSetting = new T();
                        _settings.Add(typeof(T), __newSetting);
                        return __newSetting;
                    }                    
                }                
            }
        }

        protected NameValueCollection Section
        {
            get { return _section; }
        }

        #endregion Propri�t�s
    }
}
