using System;

namespace QXP.Framework
{
	/// <summary>Provides Message/Pattern used by framework. </summary>
	public class Constantes
	{		
		/// <summary>Represents a space string. </summary>
		public const string Space						= " ";
		/// <summary>Represents a null argument error message. </summary>
		public const string NullArgumentException						= "Argument {0} can not be null";
		/// <summary>Represents an [*] databinder property not found error message. </summary>
		public const string DataBinderPropertyNotFound			= "DataBinder Member {0} Not Found On Type {1}";
		/// <summary>Represents an [*] databinder invalid index error message. </summary>
		public const string DataBinderInvalidIndexUsed			= "DataBinder Invalid Index used on expression {0}";
		/// <summary>Represents an [*] databinder invalid member type error message. </summary>
		public const string DataBinderInvalidMemberType			= "DataBinder Invalid member Type Found on Member {0} Not Found On Type {1}";
		/// <summary>Represents an [*] datasourceresolver empty dataMember error message. </summary>
		public const string DataSourceResolverMemberEmpty		= "DataSourceResolver ListSource Without DataMember";
		/// <summary>Represents an [*] datasourceresolver missing dataMember error message. </summary>
		public const string DataSourceResolverMemberMissing	= "DataSourceResolver ListSource Missing DataMember {0}";

		/// <summary>Represents an invalid OraValue type for Blob data type error message. </summary>
		public const string InvalidOraValueTypeMBBlob				= "Invalid OraValue type must be compatible with Blob";
		/// <summary>Represents an invalid OraValue type for Clob data type error message. </summary>
		public const string InvalidOraValueTypeMBClob				= "Invalid OraValue type must be compatible with Clob";
		/// <summary>Represents an invalid OraValue type for Liste String data type error message. </summary>
		public const string InvalidOraValueTypeListeString			= "Invalid OraValue type must be compatible with string array";
		/// <summary>Represents an invalid OraValue type for Liste DateTime type error message. </summary>
		public const string InvalidOraValueTypeListeDateTime		= "Invalid OraValue type must be compatible with DateTime array";
		/// <summary>Represents an invalid OraValue type for Liste Int type error message. </summary>
		public const string InvalidOraValueTypeListeInts			= "Invalid OraValue type must be compatible with Int array";
		/// <summary>Represents an invalid OraValue type for Liste Int type error message. </summary>
		public const string InvalidOraValueTypeListeDecimals		= "Invalid OraValue type must be compatible with Decimal array";
		/// <summary>Represents an invalid OraValue type for Blob or Clob data type error message. </summary>
		public const string InvalidOraValueTypeMBBlobOrClob			= "Invalid OraValue type must be compatible with Blob or Clob";
		/// <summary>Represents an invalid OraValue type for TimeSpan data type error message. </summary>
		public const string InvalidOraValueTypeTimeSpan				= "Invalid OraValue type must be compatible with TimeSpan";
		/// <summary>Represents an exception during temporary lob's generation error message. </summary>
		public const string TemporaryLobException					= "Error during temporary Lob's Generation";
		/// <summary>Represents an null 'value' exception argument for OraParameter class. </summary>
		public const string NullValueException						= "'value' cannot be null. ";

		public const string NotMatchingConstructor					= "Matching constructor not found!";
		/// <summary>Represents a invalid writeEntry into nt log event error message. </summary>
		public const string NTLogWriteError									= "Unable to log message in nt event log. ";
		/// <summary>Represents an application setting enable key. </summary>
		public const string ASEnableDebug										=	"EnableDebug";
		/// <summary>Represents a log server/user format pattern. </summary>
		public const string ServerUserInfo									= "Server ({0}) ;User ({1}) :";
		/// <summary>Represents a log user format pattern. </summary>
		public const string UserInfo												= "User ({0}) :";
		/// <summary>Represents a FileWriter write delay out of range error message. </summary>
		public const string FileWriterOutOfRangeWriteDelay	= "WriteDelay must be greater than 0 !";

		private Constantes(){}

			/// <summary>Represents a matching contructor not found when CreateIntance fail. </summary>
	}
}