using System;
using System.Collections;
using System.Reflection;
using System.Security.Policy;

namespace QXP.Framework.ObjectFactory{
	/// <summary>Provides methods to dynamically instanciate an object. </summary>
	public class ObjectFactory{
		/// <summary>Create an object instance from type with specified args. </summary>
		/// <param name="type">The <see cref="Type"/> of the object to create. </param>
		/// <param name="args">The optional Arguments. </param>
		/// <returns>The object instance. </returns>
		/// <remarks>If you have specified args don't forget to put them in object array like new object[]{arg1, arg2}. </remarks>
		public static object						CreateInstance(Type type, params object[] args){
			if(Validation.IsNull(type)) return null;
			if(args.Length > 0){
				Type[] __types = new Type[args.Length];
				for (int i=0; i < args.Length; i++) {
					__types[i] = args[i].GetType();
				}
				ConstructorInfo __info = type.GetConstructor(__types);
				if (Validation.IsNotNull(__types))	return __info.Invoke(args);
				else								throw new ArgumentException(Constantes.NotMatchingConstructor);
			}else{
				return Activator.CreateInstance(type);
			}
		}
		/// <summary>Create an object instance from type name with specified args. </summary>
		/// <param name="typeName">the string type name to instanciate. .</param>
		/// <param name="args">The optional Arguments. </param>
		/// <returns>The object instance. </returns>
		public static object						CreateInstance(string typeName, params object[] args){
			Type __type = Type.GetType(typeName);
			return CreateInstance(__type, args);
		}
	}
}
