namespace QXP.Framework.Diagnostic
{
    /// <summary>
    /// Interface IListener : IListener
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public interface IListener
    {
        #region M�thodes

        /// <summary>Write message to listener. </summary>
        /// <param name="message">The message to be persisted by the listener. </param>
        void Write(string message);

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>Checks if listener is operational by log test message on it. </summary>
        bool IsOperational { get; }

        #endregion Propri�t�s
    }
}
