using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;

using QXPFrk = QXP.Framework;

namespace QXP.Framework.Diagnostic
{
	/// <summary>
	/// Permet d'analyser la trace des appels
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/02/2010 13:53:24</date>    
	public class StackTraceHelper
	{
		#region Membres

		#endregion Membres

		#region Constantes
		const string PatternTypeMethod = "{0}.{1}";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static StackTraceHelper
		/// </summary>
		static StackTraceHelper()
		{
		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>
		/// Permet d'obtenir le nom de la methode qui � appell� la methode qui contient l'appel � GetPreviousMethodName 
		/// exemple:
		/// MethodA
		/// {
		///		Call MethodB
		/// }
		/// MethodB
		/// {
		///		string __previousMethodName = GetPreviousMethodName();
		/// }
		/// 
		/// __previousMethodName est donc �gale � MethodA !!
		/// 
		/// </summary>
		public static string GetPreviousMethodName(){
			StackTrace __trace = new StackTrace(2); //2 permet d'�liminer l'appel � la methode GetPreviousMethodName et l'appel pr�c�dent
			return GetMethod(__trace);
		}

		/// <summary>
		/// Permet d'obtenir le nom de la methode qui contient l'appel GetMethodName 
		/// exemple:
		/// MethodA
		/// {
		///		Call MethodB
		/// }
		/// MethodB
		/// {
		///		string __methodName			= GetMethodName();
		/// }
		/// 
		/// __methodName est donc �gale � MethodB !!
		/// 
		/// </summary>
		public static string GetMethodName(){
			StackTrace __trace = new StackTrace(1); //1 permet d'�liminer l'appel � la methode GetMethodName
			return GetMethod(__trace);
		}

		/// <param name="trace">la pile des appels</param>
		/// <returns>le nom de la methode</returns>
		static string GetMethod(StackTrace trace){
			if(trace.FrameCount > 0){
				return trace.GetFrame(0).GetMethod().Name;
			}
			return string.Empty;
		}
		/// <summary>
		/// Permet d'obtenir la classe et le nom de la methode qui � appell� la methode qui contient l'appel � GetPreviousMethodName 
		/// exemple:
		/// Class_A{
		///		MethodA
		///		{
		///			Call MethodB
		///		}
		///		MethodB
		///		{
		///			string __previousTypeAndMethodName = GetPreviousTypeAndMethodName();
		///		}
		/// }
		/// __previousTypeAndMethodName est donc �gale � ClassA.MethodA !!
		/// 
		/// </summary>
		public static string GetPreviousTypeAndMethodName()
		{
			StackTrace __trace = new StackTrace(2);  //2 permet d'�liminer l'appel � la methode GetPreviousTypeAndMethodName et l'appel pr�c�dent
			return GetTypeAndMethod(__trace);
		}

		/// <summary>
		/// Permet d'obtenir la classe et le nom de la methode qui � appell� la methode qui contient l'appel � GetPreviousMethodName 
		/// exemple:
		/// Class_A{
		///		MethodA
		///		{
		///			Call MethodB
		///		}
		///		MethodB
		///		{
		///			string __typeAndMethodName = GetTypeAndMethodName();
		///		}
		/// }
		/// __typeAndMethodName est donc �gale � ClassA.MethodB !!
		/// 
		/// </summary>
		public static string GetTypeAndMethodName()
		{
			StackTrace __trace = new StackTrace(1); //1 permet d'�liminer l'appel � la methode GetMethodName
			return GetTypeAndMethod(__trace);
		}

		static string GetTypeAndMethod(StackTrace trace)
		{
			if(trace.FrameCount > 0){
				MethodBase __method = trace.GetFrame(0).GetMethod();
				//ReflectedType repr�sent le System.Type qui contient la methode (donc la classe qui contient la methode)
				return string.Format(PatternTypeMethod, __method.ReflectedType, __method.Name);
			}
			return string.Empty;
		
		}
		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
