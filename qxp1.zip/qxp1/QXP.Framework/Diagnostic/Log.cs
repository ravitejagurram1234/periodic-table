using System;
using System.IO;
using System.Threading;
using log4net;
using log4net.Config;
using QXPConfiguration = QXP.Framework.Configuration;
using QXPIO = QXP.Framework.IO;

namespace QXP.Framework.Diagnostic
{
    /// <summary>
    /// Class Log : Application system error/info Log class
    /// </summary>
    /// <remarks>
    /// Par defaut le log s'effectue dans la base de donn�e table QXP_LOG
    /// mais il est possible d'utiliser log4net en param�trant la clef appsetting UseLog4Net = True
    /// ex: <add key="UseLog4Net" value="True"/>
    /// </remarks>
    /// <author></author>
    /// <date></date>    
    public class Log
    {
        #region Membres

        static bool UseLog4Net = QXPConfiguration.Settings.Current.GetBool(UseLog4NetKey);
        static object sync = new object();
        static string LogfilePath;
        private static readonly ILog log;

        #endregion Membres

        #region Constantes

        const string Log4NetConfig = "log4Net.config";
        const string ErrorLoggerName = "LogError";
        const string UseLog4NetKey = "UseLog4Net";
        public const string LogPattern = "{0:yyyy/MM/dd HH:mm:ss.fff} - {1} - {2}\r\n{3}";
        const int MaxLockDelay = 5000;
        public const string LogFilePattern = "{0}\\Errors_{1:yyyyMMdd}.log";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Log
        /// </summary>
        static Log()
        {
            if (UseLog4Net)
            {
                log = LogManager.GetLogger(ErrorLoggerName);
                string __configLogFile = QXPIO.FileHelper.GetFileName(Log4NetConfig);
                FileInfo __fileInfo = new FileInfo(__configLogFile);
                if (__fileInfo.Exists)
                {
                    XmlConfigurator.ConfigureAndWatch(__fileInfo);
                }
            }
            LogfilePath = QXPIO.FileHelper.GetFileName(LogConstant.ApplicationLogSubDir);
        }

        #endregion Constructeur

        #region M�thodes

        public static void Configure()
        {
            //INFO: nothing to do !! just launch initialize static properties !! 	
        }

        public static void LogError(string message, Exception ex)
        {
            if (UseLog4Net)
            {
                log.Error(message, ex);
            }
            else
            {
                string __ex = StringHelper.StartEndString(ex.ToString(), 3800);
                Internal_Log(DateTime.Now, LogType.Error, message, __ex);
            }
        }
        public static void LogError(string message, string info)
        {
            if (UseLog4Net)
            {
                log.Error(message + ", info: " + info);
            }
            else
            {
                Internal_Log(DateTime.Now, LogType.Error, message, info);
            }
        }


        public static void LogInfo(string message, string info)
        {
            if (UseLog4Net)
            {
                log.Info(info);
            }
            else
            {
                Internal_Log(DateTime.Now, LogType.Info, message, info);
            }
        }

        static void Internal_Log(DateTime date, LogType type, string message, string info)
        {
            Proxy.ProxyLog __proxy = new Proxy.ProxyLog();
            string __logMessage = string.Format(LogPattern, date, type, message, info);
            try
            {
                __proxy.SaveLog(date, type, message, info);
            }
            catch (Exception ex)
            {
                File_Log(__logMessage);
            }
            System.Diagnostics.Debug.WriteLine(__logMessage);
        }

        static void File_Log(string full_message)
        {
            //Essaye d'obtenir l'acc�s pendant 5 sec max, ceci afin de ne pas v�rrouiller tout les threads ind�finiment ^^
            if (Monitor.TryEnter(sync, MaxLockDelay))
            {
                try
                {
                    string __logFileName = string.Format(LogFilePattern, LogfilePath, DateTime.Now);
                    File.AppendAllText(__logFileName, full_message + "\r\n");
                }
                catch
                {

                }
                //quoiqu'il arrive on lib�re le lock et on ne l�ve plus d'exception, c'est fini !!
                finally
                {
                    Monitor.Exit(sync);
                }
            }
        }

        public static string GetLogFrom(LogType type, DateTime fromdate)
        {
            Proxy.ProxyLog __proxy = new Proxy.ProxyLog();
            return __proxy.GetLogFromDate(type, fromdate);
        }

        public static string GetLogFromToday(LogType type)
        {
            return GetLogFrom(type, DateTime.Today);
        }

        public static string GetErrorLogFromToday()
        {
            return GetLogFrom(LogType.Error, DateTime.Today);
        }

        public static string GetErrorLogFromYesterday()
        {
            return GetLogFrom(LogType.Error, DateTime.Today.AddDays(-1));
        }

        public static string GetErrorLogFromLastWeek()
        {
            return GetLogFrom(LogType.Error, DateTime.Today.AddDays(-7));
        }

        public static string GetErrorLogFromLastMonth()
        {
            return GetLogFrom(LogType.Error, DateTime.Today.AddDays(-30));
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }


}
