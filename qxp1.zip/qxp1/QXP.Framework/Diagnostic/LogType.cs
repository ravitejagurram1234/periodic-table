namespace QXP.Framework.Diagnostic
{
    public enum LogType
    {
        All = 0,
        Error = 1,
        Warning = 2,
        Info = 3,
    }
}
