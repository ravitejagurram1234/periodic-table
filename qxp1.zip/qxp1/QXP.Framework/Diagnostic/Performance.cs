using System;

namespace QXP.Framework.Diagnostic
{
    /// <summary>
    /// Class Performance : Provides methods to measure code performance.
    /// </summary>
    /// <remarks>
    /// Performances would be displayed in application Debug window with a specified time format.
    /// If you didn't reset internal timer after display message, all measures would be relative to class creation or last reset. 
    /// </remarks>
    /// <author></author>
    /// <date></date>    
    public class Performance
    {
        #region Membres

        bool _autoReset = false;
        string _source;
        DateTime _start;

        #endregion Membres

        #region Constantes

        const string ticksTemplate = "{0}-{1} took {2} ticks";
        const string millisecondsTemplate = "{0}-{1} took {2} ms";
        const string secondsTemplate = "{0}-{1} took {2} s";
        const string minutesTemplate = "{0}-{1} took {2} min";
        const string hoursTemplate = "{0}-{1} took {2} hr";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new <see cref="Performance"/> class and start measure. </summary>
        public Performance()
        {
            this.Reset();
        }

        /// <summary>Creates a new <see cref="Performance"/> class from the specified <paramref name="obj"/>  and start measure. </summary>
        /// <param name="source">the object linked to this performance instance. </param>
        public Performance(object source)
            : this()
        {
            _source = Convert.ToString(source);
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>Reset the internal timer to 0. </summary>
        public void Reset()
        {
            _start = DateTime.Now;
        }

        /// <summary>Gets the interval between the previous reset. </summary>
        /// <returns>The <see cref="TimeSpan"/>  interval beetween the previous reset. </returns>
        public TimeSpan GetDuration()
        {
            return GetDuration(false);
        }

        /// <summary>Gets the interval between the next reset then perform a reset internal timer. </summary>
        /// <param name="reset">the bool value which specify if the internal timer is reseted. </param>
        /// <returns>The <see cref="TimeSpan"/>  interval beetween the previous reset. </returns>
        public TimeSpan GetDuration(bool reset)
        {
            TimeSpan __interval = DateTime.Now.Subtract(_start);
            if (reset || _autoReset) this.Reset();
            return __interval;
        }

        /// <summary>Gets the message of current measure in Ticks format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <param name="reset">if <see langword="true"/> this instance reset internal timer to start a new measure. </param>
        /// <returns>The string formated message. </returns>        
        public string GetTotalTicks(string message, bool reset)
        {
            return string.Format(ticksTemplate, _source, message, this.GetDuration(reset).Ticks);
        }

        /// <summary>Gets the message of current measure in Ticks format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <returns>The string formated message. </returns>
        public string GetTotalTicks(string message)
        {
            return GetTotalTicks(message, false);
        }

        /// <summary>Gets the message of current measure in milliseconds format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <param name="reset">if <see langword="true"/> this instance reset internal timer to start a new measure. </param>
        /// <returns>The string formated message. </returns>
        public string GetTotalMilliseconds(string message, bool reset)
        {
            return string.Format(millisecondsTemplate, _source, message, this.GetDuration(reset).TotalMilliseconds);
        }

        /// <summary>Gets the message of current measure in milliseconds format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <returns>The string formated message. </returns>
        public string GetTotalMilliseconds(string message)
        {
            return GetTotalMilliseconds(message, false);
        }

        /// <summary>Gets the message of current measure in seconds format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <param name="reset">if <see langword="true"/> this instance reset internal timer to start a new measure. </param>
        /// <returns>The string formated message. </returns>
        public string GetTotalSeconds(string message, bool reset)
        {
            return string.Format(secondsTemplate, _source, message, this.GetDuration(reset).TotalSeconds);
        }

        /// <summary>Gets the message of current measure in seconds format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <returns>The string formated message. </returns>
        public string GetTotalSeconds(string message)
        {
            return GetTotalSeconds(message, false);
        }

        /// <summary>Gets the message of current measure in minutes format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <param name="reset">if <see langword="true"/> this instance reset internal timer to start a new measure. </param>
        /// <returns>The string formated message. </returns>
        public string GetTotalMinutes(string message, bool reset)
        {
            return string.Format(minutesTemplate, _source, message, this.GetDuration(reset).TotalMinutes);
        }

        /// <summary>Gets the message of current measure in minutes format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <returns>The string formated message. </returns>
        public string GetTotalMinutes(string message)
        {
            return GetTotalMinutes(message, false);
        }

        /// <summary>Gets the message of current measure in hours format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <param name="reset">if <see langword="true"/> this instance reset internal timer to start a new measure. </param>
        /// <returns>The string formated message. </returns>
        public string GetTotalHours(string message, bool reset)
        {
            return string.Format(hoursTemplate, _source, message, this.GetDuration(reset).TotalHours);
        }

        /// <summary>Gets the message of current measure in hours format. </summary>
        /// <param name="message">the <see cref="String"/> text to insert in message. </param>
        /// <returns>The string formated message. </returns>
        public string GetTotalHours(string message)
        {
            return GetTotalHours(message, false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public decimal GetSecondesAndMillseconds(bool reset)
        {
            TimeSpan __interval = DateTime.Now.Subtract(_start);
            if (reset || _autoReset) this.Reset();
            string __strTime = string.Format("{0:#0.000}", __interval.TotalSeconds);
            return ConversionInvariante.ToDecimal(__strTime);
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>Gets or sets if Performance instance reset automatically internal timer after each interval evaluation. </summary>
        public bool AutoReset
        {
            get { return _autoReset; }
            set { _autoReset = value; }
        }

        /// <summary>Gets or sets the source object which defined the Performance instance. </summary>
        public string Source
        {
            get { return _source; }
            set { _source = value; }
        }

        #endregion Propri�t�s
    }


}
