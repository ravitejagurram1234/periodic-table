using System;
using System.Xml.Serialization;

namespace QXP.Framework.Diagnostic
{
    /// <summary>Represents a listener constructor argument section. </summary>
    public class Arg
    {
        /// <summary>Create a new <see cref="Arg"/> class. </summary>
        public Arg() { }
        /// <summary>Create a new <see cref="Arg"/> class with specified <paramref name="argName"/> and <paramref name="argValue"/>. </summary>
        /// <param name="argName">The <see cref="String"/> Argument name. </param>
        /// <param name="argValue">The <see cref="String"/> Argument value.</param>
        public Arg(string argName, string argValue)
        {
            Name = argName;
            Value = argValue;
        }
        /// <summary>Represents the Name of the argument. </summary>
        [XmlAttribute]
        public string Name;
        /// <summary>Represents the string value of the argument. </summary>
        [XmlAttribute]
        public string Value;
    }
}
