using System;
using QXPIO = QXP.Framework.IO;

namespace QXP.Framework.Diagnostic
{
    /// <summary>
    /// Class FileListener : Provides functionalty to persist diagostic messages into file.
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class FileListener : QXPIO.DatedFileWriter, IListener
    {
        #region Membres

        #endregion Membres

        #region Constantes

        const QXPIO.Periodicity defaultPeriodicity = QXPIO.Periodicity.Day;
        const string defaultPath = LogConstant.ApplicationLogSubDir;
        const string defaultFileName = "Logs";
        const string defaultExtension = LogConstant.LogFileExtension;
        const int defaultWriteTimeOut = 1000;

        const string TestFileListenerMessage = "File Listener working Test.";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new instance of <see cref="FileListener"/> class with the specified arguments. </summary>
        /// <param name="args">The <see cref="Arg"/> array used to intialize the <see cref="FileListener"/>. </param>
        public FileListener(params Arg[] args)
            : base(defaultPeriodicity, defaultPath, defaultFileName, defaultExtension, defaultWriteTimeOut)
        {
            if (Validation.IsSet(args))
            {
                foreach (Arg __arg in args)
                {
                    switch (Conversion.ToString(__arg.Name).ToUpper())
                    {
                        case ("PATH"): this.Path = __arg.Value; break;
                        case ("FILENAME"): this.FileName = __arg.Value; break;
                        case ("EXTENSION"): this.Extension = __arg.Value; break;
                        case ("PERIODICITY"): this.Periodicity = (QXPIO.Periodicity)Enum.Parse(QXPIO.IOType.Periodicity, __arg.Value); break;
                        default: break;	//INFO: unkown arguments
                    }
                }
            }
        }

        #endregion Constructeur

        #region M�thodes

        void IListener.Write(string message)
        {
            this.WriteLine(message);
        }

        #endregion M�thodes

        #region Propri�t�s

        bool IListener.IsOperational
        {
            get
            {
                try
                {
                    this.WriteLine(TestFileListenerMessage);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }

        #endregion Propri�t�s
    }

			
}
