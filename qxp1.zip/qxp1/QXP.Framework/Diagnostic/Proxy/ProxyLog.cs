using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

using QXPFrk = QXP.Framework;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPProxy = QXP.Framework.Proxy;
using QXPApplication = QXP.Framework.Application.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;

using Oracle.DataAccess.Client;


namespace QXP.Framework.Diagnostic.Proxy
{

	/// <summary>
	/// Permet la manipulation des logs de l'application
	/// </summary>
	/// <author>DOUFARM</author>
	/// <date>12/09/2008 15:58:35</date>    
	public class ProxyLog : QXPProxy.BaseProxy
	{
	    #region Membres

	    #endregion Membres

	    #region Constantes

	    //Taille maximale en nombre de caract�re de la colonne Application de la table log
	    private const int		MaxApplicationLength	= 100;
	    //Taille maximale en nombre de caract�re de la colonne Message de la table log
	    private const int		MaxMessageLength		= 200;
	    //Taille maximale en nombre de caract�re de la colonne Info de la table log
	    private const int		MaxInfoLength			= 4000;
	    private const string	LogPattern				= "";
		private const string	CRLF_2					= "\r\n\r\n";
		private const string	Log_Batch_Error			= "Erreur lors de l'insertion du log Batch : ";

	    private const string PACKAGE = "_PK_LOG.";

	    #endregion Constantes

	    #region Enums

	    #endregion Enums

	    #region Constructeur

	    /// <summary>
	    /// Cr�e une instance de ProxyLog
	    /// </summary>
	    public ProxyLog()
	    {
	    }

	    /// <summary>
	    /// Cr�e une instance de ProxyLog
	    /// </summary>
	    /// <param name="oraClient">Connexion Oracle</param>
	    public ProxyLog(QXPDataOracle.OraClient oraClient)
	        : base(oraClient)
	    {
	    }

	    /// <summary>
	    /// Cr�e une instance de ProxyLog
	    /// </summary>
	    /// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
	    public ProxyLog(string dataBase)
	        : base(dataBase)
	    {
	    }

	    #endregion Constructeur

	    #region M�thodes

	    #region Acc�s Base

	    #region SELECT

		/// <summary>
		/// Retourne une chaine contenant les logs demand�s
		/// </summary>
		/// <param name="type">type de log (error, warning)</param>
		/// <param name="date">depuis qu'elle date ?</param>
		/// <returns>string contenant les log demand�s. </returns>
	    public string GetLogFromDate(LogType type, DateTime date)
        {        			
		        #region Variables
                  
                QXPDataOracle.OraParameterList	__oraParameters     = new QXPDataOracle.OraParameterList();
				List<string>					__logs				= new List<string>();

                  #endregion Variables
      			
		          #region Definition des OraParameters

                  __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
                                 .AddParameterToSqlParamList("p_from", date)
                                 .AddParameterToSqlParamList("p_type", (int)type);

                  #endregion Definition des OraParameters

                  string					__sql		= string.Concat(this.SitePrefix, PACKAGE, "GetLogFromDate");

                  QXPDataOracle.SQLRequest __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);
      			
                  using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
                  {   
                    DateTime	__log_date;
					LogType		__log_type;
					string		__log_message;
					string		__log_info;
					while(__odr.Read())
					{
						__log_date		= __odr["LOG_DATE"];
						__log_type		= (LogType)(int)__odr["LOG_TYPE"];
						__log_message	= __odr["LOG_MESSAGE"];
						__log_info		= __odr["LOG_INFO"];
						__logs.Add(string.Format(Log.LogPattern, __log_date, __log_type, __log_message, __log_info));
					}

                  }                   
				return string.Join(CRLF_2, __logs.ToArray());
              }
			
	    #endregion SELECT

	    #region INSERT / UPDATE / DELETE

	    /// <summary>
	    /// Sauvegarde du log
	    /// </summary>
	    /// <param name="date"></param>
	    /// <param name="type"></param>
	    /// <param name="message"></param>
	    /// <param name="info"></param>
	    public void SaveLog(DateTime date, LogType type, string message, string info)
	    {
	        #region Variables

	        QXPDataOracle.OraParameterList	__oraParameters      = new QXPDataOracle.OraParameterList();
	        
			#endregion Variables
			
	        #region Definition des OraParameters

	    	__oraParameters.AddParameterToSqlParamList("p_Date", date)
	    		.AddParameterToSqlParamList("p_Type", (int) type)
	    		.AddParameterToSqlParamList("p_Message", StringHelper.Left(message, MaxMessageLength))
	    		.AddParameterToSqlParamList("p_Info", StringHelper.Left(info, MaxInfoLength))
	    		.AddParameterToSqlParamList("p_id_application", QXPApplication.ID)
	    		.AddParameterToSqlParamList("p_nom_application", StringHelper.Left(QXPApplication.Name, MaxApplicationLength));
	                       

	        #endregion Definition des OraParameters

	        string						__sql			= string.Concat(SitePrefix, PACKAGE, "Save_Log");

	        QXPDataOracle.SQLRequest	__sqlRequest	= new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);
			
			//s'il y a une erreur elle doit remonter afin de pouvoir effectuer un traitement suppl�mentaire !!
	        this.Execute(__sqlRequest);
	    }		

	    #endregion INSERT / UPDATE / DELETE
 

	    #endregion Acc�s Base

	    #endregion M�thodes

	    #region Propri�t�s

	    #endregion Propri�t�s
	}

}
