namespace QXP.Framework.Diagnostic
{
    /// <summary>
    /// Class LogConstant : LogConstant
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class LogConstant
    {
        #region Membres

        #endregion Membres

        #region Constantes

        /// <summary>The log folder for log files. </summary>
        public const string ApplicationLogSubDir = "Logs";
        /// <summary>The log file extension. </summary>
        public const string LogFileExtension = "log";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de LogConstant
        /// </summary>
        private LogConstant()
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }

			
}