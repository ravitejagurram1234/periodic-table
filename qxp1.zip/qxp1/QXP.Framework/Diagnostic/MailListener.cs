using System;
using System.Web.Mail;
using QXPMail = QXP.Framework.Mail;

namespace QXP.Framework.Diagnostic
{    
    /// <summary>
    /// Class MailListener : Provides functionalities to sender diagostic message by Email.
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class MailListener : IListener
    {
        #region Membres

        string _smtpServer;
        string _sender;
        string _recipient;
        string _subject;
        MailFormat _mailFormat = MailFormat.Text;
        MailPriority _mailPriority = MailPriority.Normal;

        #endregion Membres

        #region Constantes
        
        internal const string MissingArguments = "Missing one or more argument to initialize MailListener";
        internal const string TestMailListenerMessage = "Mail Listener working Test.";
        
        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de MailListener
        /// </summary>
        /// <summary>Creates a new instance of <see cref="MailListener"/> class with the specified arguments. </summary>
        /// <param name="args">the <see cref="Arg"/> collection of arguments used to initialize the MailListener. </param>
        public MailListener(params Arg[] args)
            : base()
        {
            if (Validation.IsSet(args))
            {
                foreach (Arg __arg in args)
                {
                    switch (Conversion.ToString(__arg.Name).ToUpper())
                    {
                        case ("SMTPSERVER"): _smtpServer = __arg.Value; break;
                        case ("SENDER"): _sender = __arg.Value; break;
                        case ("RECIPIENT"): _recipient = __arg.Value; break;
                        case ("SUBJECT"): _subject = __arg.Value; break;
                        case ("ISHTML"): _mailFormat = Conversion.ToBool(__arg.Value) ? MailFormat.Html : MailFormat.Text; break;
                        case ("PRIORITY"): _mailPriority = (MailPriority)Enum.Parse(QXPMail.MailType.MailPriority, __arg.Value); break;
                        default: break;	//INFO: unkown arguments
                    }
                }
            }
            if (Validation.IsNotSet(_smtpServer) || Validation.IsNotSet(_sender) || Validation.IsNotSet(_recipient))
            {
                throw new ArgumentException(MissingArguments);
            }
        }

        #endregion Constructeur

        #region M�thodes

        void IListener.Write(string message)
        {
            QXPMail.MailMessage __mail = new QXPMail.MailMessage(null, _subject, _recipient, _sender, _mailFormat, _mailPriority);
            __mail.Body = message;
            __mail.Send(_smtpServer);
        }

        #endregion M�thodes

        #region Propri�t�s

        bool IListener.IsOperational
        {
            get
            {
                try
                {
                    ((IListener)this).Write(TestMailListenerMessage);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }

        #endregion Propri�t�s
    }

			
}
