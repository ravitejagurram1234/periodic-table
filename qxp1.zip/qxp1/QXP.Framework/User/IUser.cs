using System.Globalization;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.User
{
    /// <summary>
    /// Interface IUser : D�finit l'interface d'un utilisateur
    /// </summary>
    /// <author>LCU</author>
    /// <date>17/08/2011</date>    
    public interface IUser
    {
        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Identifiant de l'utilisateur
        /// </summary>
        int UserID
        {
            get;
        }

        /// <summary>
        /// Culture associ�e
        /// </summary>
        CultureInfo Culture
        {
            get;
        }

        /// <summary>
        /// Type d'utilisateur
        /// </summary>
        UserType UserType
        {
            get;
            set;
        }

        #endregion Propri�t�s
    }
}
