/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/
namespace QXP.Framework.User
{
    /// <summary>
    /// Type d'utilisateur
    /// </summary>
    public enum UserType
    {
        Anonymous,
        Standard,
        Admin,
    }
}
