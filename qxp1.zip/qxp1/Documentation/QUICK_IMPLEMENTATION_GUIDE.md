# CONFIGURATION-ONLY FIX - QUICK IMPLEMENTATION GUIDE
## No Code Changes Required

---

## ISSUE AT A GLANCE

**Problem:** User redirected to login after form submission  
**Root Cause:** Long Oracle query → Session expires → User authentication lost  
**Solution:** Increase session timeout via configuration

---

## FIX #1: Update Web.Config Session Timeout ⭐ MUST DO

### File Location
```
C:\inetpub\wwwroot\QXP\Web.Config
```

### Current Content (Find This)
```xml
<sessionState timeout="60"></sessionState>
```

### Change To
```xml
<sessionState timeout="120"></sessionState>
```

### How to Make Change

**Option A: Using Text Editor**
1. RDP to UAT server: `srvcldqxpu001.dns43.socgen`
2. Navigate to: `C:\inetpub\wwwroot\QXP\`
3. Open: `Web.Config` (use Notepad or Editor)
4. Find line with: `<sessionState timeout="60">`
5. Change `60` to `120`
6. Save file (Ctrl+S)
7. IIS will auto-reload configuration

**Option B: Using PowerShell (Remote)**
```powershell
# Replace srvcldqxpu001 with actual server name
$webConfigPath = "\\srvcldqxpu001\c$\inetpub\wwwroot\QXP\Web.Config"

# Read the file
$content = Get-Content -Path $webConfigPath -Raw

# Replace timeout value
$content = $content -replace 'timeout="60"', 'timeout="120"'

# Save the file
Set-Content -Path $webConfigPath -Value $content -Force

# Verify change
Select-String -Path $webConfigPath -Pattern "sessionState timeout"
```

### Verification
```powershell
# Verify the change was made
$webConfigPath = "C:\inetpub\wwwroot\QXP\Web.Config"
Select-String -Path $webConfigPath -Pattern 'sessionState timeout="120"'
# Should show: <sessionState timeout="120"></sessionState>
```

### What This Does
- **Before:** IIS session expires after 60 minutes of inactivity
- **After:** IIS session expires after 120 minutes of inactivity
- **Benefit:** Gives long-running queries time to complete without session expiration

---

## FIX #2: Update IIS Application Pool Idle Timeout ⭐ MUST DO

### On UAT Server via IIS Manager

**Step 1: Open IIS Manager**
```powershell
# On UAT server
inetmgr
```

**Step 2: Navigate to Application Pools**
- Left panel → Application Pools
- Look for: "QXP"

**Step 3: Select Pool "QXP"**
- Right-click → Advanced Settings...

**Step 4: Find "Idle Time-out (minutes)"**
- Default value: 20
- Change to: 0 (never recycle) OR 120 (recycle after 2 hours)
- Recommended: 120 (safer than 0)
- Click OK

### Via PowerShell (Remote)
```powershell
# Set idle timeout to 120 minutes
Set-ItemProperty "IIS:\AppPools\QXP" -Name idleTimeout -Value ([timespan]"00:120:00")

# OR set to unlimited (0)
Set-ItemProperty "IIS:\AppPools\QXP" -Name idleTimeout -Value ([timespan]"00:00:00")

# Verify
Get-ItemProperty "IIS:\AppPools\QXP" | Select-Object idleTimeout
```

### What This Does
- **Before:** Application pool recycles after 20 minutes of no requests
- **After:** Application pool recycles after 120 minutes (or never)
- **Benefit:** Prevents session loss from automatic pool recycling

---

## FIX #3: Restart IIS Application Pool ⭐ REQUIRED AFTER CONFIG CHANGES

### Option A: Via IIS Manager
1. In IIS Manager, right-click "QXP" application pool
2. Click "Restart"
3. Wait 10 seconds

### Option B: Via PowerShell
```powershell
# Stop the pool
Stop-WebAppPool -Name "QXP"

# Wait 5 seconds
Start-Sleep -Seconds 5

# Start the pool
Start-WebAppPool -Name "QXP"

# Wait 10 seconds for startup
Start-Sleep -Seconds 10

# Verify it's running
Get-WebAppPoolState -Name "QXP"
# Should show: Started
```

### Option C: Via Command Line
```cmd
REM On the UAT server
C:\Windows\System32\inetsrv\appcmd.exe stop apppool /apppool.name:"QXP"
timeout /t 5
C:\Windows\System32\inetsrv\appcmd.exe start apppool /apppool.name:"QXP"
timeout /t 10
C:\Windows\System32\inetsrv\appcmd.exe list apppool /apppool.name:"QXP"
```

---

## OPTIONAL FIX #4: Check/Enhance tnsnames.ora

**File Location:**
```
C:\oracle\product\12.1.0.2\client_1\network\admin\tnsnames.ora
```

**Current Content (Example):**
```
DEVDB =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = oracle.server.com)(PORT = 1521))
    (CONNECT_DATA =
      (SERVICE_NAME = devdb)
    )
  )
```

**Verify:**
- Entry for database alias exists (e.g., DEVDB, HBBDB, PRODDB)
- HOST points to correct server
- PORT is 1521 (default Oracle port)
- SERVICE_NAME matches database service

**No changes needed** unless alias is missing or incorrect.

---

## VALIDATION CHECKLIST

After making changes, verify:

```
✓ Web.Config contains: timeout="120"
✓ IIS Application Pool idle timeout set to 120 minutes (or 0)
✓ Application Pool is in "Started" state
✓ Application accessible: https://srvcldqxpu001.dns43.socgen/
✓ Can log in successfully
✓ Can navigate to Generation module
✓ Can fill and submit CreationSuiviEtape1 form
✓ User redirects to CreationSuiviEtape2 (NOT login page)
✓ No errors in Windows Event Viewer Application log
```

---

## TESTING THE FIX

### Test Scenario 1: Basic Form Submission
```
1. Log in to QXP
2. Click: Generation → CreationduSuivi
3. Fill form:
   - Date échéance: 31/12/2025
   - Type rapport: Annuel rapport
   - Language: Francais
   - Nom du gabarit: [select any]
   - Maquettiste: [select any]
   - Portefeuilles: [select at least one]
4. Click "Valider"
5. EXPECTED: Page shows CreationSuiviEtape2
6. NOT EXPECTED: Redirect to login page
```

### Test Scenario 2: Long Query Test
```
1. Same as above but select complex portfolio combinations
2. Wait 30-60 seconds for database query
3. EXPECTED: Still completes successfully, no timeout
4. NOT EXPECTED: Login page or error
```

### Test Scenario 3: Monitor Logs
```
PowerShell:
Get-EventLog -LogName Application -After (Get-Date).AddMinutes(-15) |
  Where-Object { $_.Source -like "*QXP*" -or $_.EntryType -eq "Error" } |
  Select-Object TimeGenerated, Source, Message

EXPECTED: No errors or warnings
```

---

## ROLLBACK (If Problems Occur)

### Rollback Web.Config
```
Change timeout back to: timeout="60"
OR
Restore from backup
```

### Rollback IIS Pool Timeout
```powershell
Set-ItemProperty "IIS:\AppPools\QXP" -Name idleTimeout -Value ([timespan]"00:20:00")
```

---

## SUMMARY OF CHANGES

| File | Change | Before | After | Risk |
|------|--------|--------|-------|------|
| Web.Config | Session timeout | 60 min | 120 min | ZERO |
| IIS Settings | Pool idle timeout | 20 min | 120 min | VERY LOW |
| tnsnames.ora | (Optional) Connection params | Standard | Enhanced | LOW |

---

## TIME REQUIRED

- Web.Config change: **5 minutes**
- IIS pool setting: **5 minutes**
- Restart pool: **2 minutes**
- Testing: **15 minutes**
- **TOTAL: ~25 minutes**

---

## EXPECTED RESULT

✅ Form submissions complete successfully  
✅ No login redirects  
✅ Users can proceed to CreationSuiviEtape2  
✅ Session maintained throughout operation  

---

## QUESTIONS?

Refer to: `ROOT_CAUSE_CONFIG_ONLY_FIX.md` for detailed technical explanation


