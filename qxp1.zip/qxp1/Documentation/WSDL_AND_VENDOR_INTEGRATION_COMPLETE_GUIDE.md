# WSDL & Vendor Service Integration: Complete Technical Guide

**Document Purpose:** Comprehensive explanation of how .NET applications interact with vendor services (QXPSMSDK) using WSDL, how Java Spring Boot can replicate this, and the complete request-response flow.

---

## Table of Contents
1. [Understanding the Line: `using QXPSMSDK = com.quark.qxpsm;`](#1-understanding-the-line)
2. [How Your Application Knows About QXPSMSDK](#2-how-your-application-knows-about-qxpsmsdk)
3. [WSDL: The Contract Between Services](#3-wsdl-the-contract-between-services)
4. [Reference.cs: The Auto-Generated Proxy](#4-referencecs-the-auto-generated-proxy)
5. [The Role of TElement_Helper](#5-the-role-of-telement_helper)
6. [Complete Request-Response Flow](#6-complete-request-response-flow)
7. [Current Architecture vs. Future Cloud Architecture](#7-current-architecture-vs-future-cloud-architecture)
8. [Java Spring Boot Implementation Strategy](#8-java-spring-boot-implementation-strategy)

---

## 1. Understanding the Line: `using QXPSMSDK = com.quark.qxpsm;`

### What This Line Does

```csharp
using QXPSMSDK = com.quark.qxpsm;
```

This is a **namespace alias** in C#. Let's break it down:

- **Left side (`QXPSMSDK`):** A shorter, convenient name you use in your code
- **Right side (`com.quark.qxpsm`):** The actual namespace from the vendor's library
- **Purpose:** Makes code more readable by replacing long namespace names with shorter ones

### Practical Example

Instead of writing:
```csharp
com.quark.qxpsm.Box myBox = new com.quark.qxpsm.Box();
```

You write:
```csharp
QXPSMSDK.Box myBox = new QXPSMSDK.Box();
```

### Real-World Usage in Your Code

From `Bloc_Box.cs`:
```csharp
QXPSMSDK.Box _srcBox = null;
QXPSMSDK.Box _srcExtraBox = null;
```

These variables hold references to actual Box objects that come from the vendor's library.

---

## 2. How Your Application Knows About QXPSMSDK

### Question: Does the Code Only Know the Name, or Does It Know the Implementation?

**Answer: Your code knows BOTH.**

### The Multi-Layer Knowledge System

```
┌─────────────────────────────────────────────────────────────┐
│ Your .NET Application (QXP.Engine.Core)                     │
│                                                              │
│ LAYER 1: Source Code                                        │
│ ┌──────────────────────────────────────────────────────┐   │
│ │ using QXPSMSDK = com.quark.qxpsm;                   │   │
│ │ QXPSMSDK.Box _srcBox = null;                        │   │
│ │ __tBox.SrcBox.content.value = "...";                │   │
│ └──────────────────────────────────────────────────────┘   │
│         ↓ (compile time)                                    │
│ LAYER 2: Metadata Reference                                 │
│ ┌──────────────────────────────────────────────────────┐   │
│ │ QXP.Interop.dll (project reference)                 │   │
│ │ └─ Contains QXPSMSDK proxy classes (Reference.cs)   │   │
│ │    - Box class definition                           │   │
│ │    - Methods: getXPressDOM(), processRequest()      │   │
│ │    - Properties: content, geometry, picture, etc.   │   │
│ └──────────────────────────────────────────────────────┘   │
│         ↓ (runtime)                                         │
│ LAYER 3: Service Connection                                 │
│ ┌──────────────────────────────────────────────────────┐   │
│ │ SOAP Client (System.Web.Services)                   │   │
│ │ └─ Converts method calls to SOAP XML messages       │   │
│ │ └─ Sends over HTTP to vendor service                │   │
│ └──────────────────────────────────────────────────────┘   │
│         ↓ (network)                                         │
│ LAYER 4: Vendor Service                                     │
│ └─ Remote QXPSMSDK service (Windows Server)                │
│    - Actually implements Box class                         │
│    - Executes the business logic                           │
│    - Sends response back as SOAP XML                       │
└─────────────────────────────────────────────────────────────┘
```

### What "Knowing" Means at Each Layer

#### **Compile Time (LAYER 1 & 2)**
Your code knows:
- Box class name and location (`com.quark.qxpsm.Box`)
- Available properties (`content`, `geometry`, `picture`)
- Available methods signatures
- Parameter types and return types
- This information comes from `Reference.cs` (the proxy)

```csharp
// From Reference.cs (auto-generated from WSDL)
public class Box {
    public Content content { get; set; }
    public Geometry geometry { get; set; }
    public Picture picture { get; set; }
}
```

#### **Runtime (LAYER 3 & 4)**
Your code:
- Creates instances of proxy classes
- Calls methods on these instances
- The proxy uses SOAP protocol to serialize your call
- Sends XML over HTTP to the actual service
- Receives XML response
- Deserializes back to .NET objects
- Returns to your code

### Key Insight

**Your application doesn't actually implement Box.** It implements a **local proxy** that mirrors the remote service's interface. The proxy knows how to talk to the service but doesn't know the internal logic.

---

## 3. WSDL: The Contract Between Services

### What is WSDL?

**WSDL** = Web Services Description Language

It's an **XML file** that describes:
1. **What services are available** (operations/methods)
2. **Where to find them** (service endpoints - URLs)
3. **What parameters they accept** (data types)
4. **What they return** (response structures)
5. **How to communicate** (SOAP protocol)

### WSDL File Structure

Your project contains: `qxpsmsdk.wsdl`

```xml
<?xml version="1.0" encoding="utf-8"?>
<wsdl:definitions xmlns:...>
  
  <!-- SECTION 1: DATA TYPES & COMPLEX OBJECTS -->
  <wsdl:types>
    <xsd:schema targetNamespace="http://ro.clientsdk.manager.quark.com">
      <xsd:complexType name="Box">
        <xsd:sequence>
          <xsd:element name="name" type="xsd:string"/>
          <xsd:element name="boxType" type="xsd:string"/>
          <xsd:element name="content" type="tns:Content"/>
          <xsd:element name="geometry" type="tns:Geometry"/>
          <xsd:element name="picture" type="tns:Picture"/>
        </xsd:sequence>
      </xsd:complexType>
      
      <xsd:complexType name="Content">
        <xsd:sequence>
          <xsd:element name="value" type="xsd:string"/>
        </xsd:sequence>
      </xsd:complexType>
      
      <xsd:complexType name="Geometry">
        <xsd:sequence>
          <xsd:element name="page" type="xsd:string"/>
          <xsd:element name="position" type="tns:Position"/>
        </xsd:sequence>
      </xsd:complexType>
    </xsd:schema>
  </wsdl:types>
  
  <!-- SECTION 2: SERVICE OPERATIONS (Methods) -->
  <wsdl:portType name="QManagerSDKSvc">
    <wsdl:operation name="processRequest">
      <wsdl:input message="tns:processRequestRequest"/>
      <wsdl:output message="tns:processRequestResponse"/>
    </wsdl:operation>
    
    <wsdl:operation name="getXPressDOM">
      <wsdl:input message="tns:getXPressDOMRequest"/>
      <wsdl:output message="tns:getXPressDOMResponse"/>
    </wsdl:operation>
  </wsdl:portType>
  
  <!-- SECTION 3: PROTOCOL BINDING (How to communicate) -->
  <wsdl:binding name="qxpsmsdkSoapBinding" type="tns:QManagerSDKSvc">
    <wsdlsoap:binding style="rpc" transport="http://schemas.xmlsoap.org/soap/http"/>
    <!-- Specifies SOAP protocol over HTTP -->
  </wsdl:binding>
  
  <!-- SECTION 4: SERVICE ENDPOINT (Where to connect) -->
  <wsdl:service name="QManagerSDKSvcService">
    <wsdl:port name="QManagerSDKSvcPort" binding="tns:qxpsmsdkSoapBinding">
      <wsdlsoap:address location="http://vendorserver:8080/axis/services/QManagerSDKSvc"/>
    </wsdl:port>
  </wsdl:service>
  
</wsdl:definitions>
```

### The Four Critical WSDL Sections

| Section | Purpose | Example |
|---------|---------|---------|
| **Types** | Defines data structures | Box, Content, Geometry classes |
| **Operations** | Lists available methods | getXPressDOM, processRequest, createSession |
| **Binding** | Protocol specification | SOAP over HTTP |
| **Endpoint** | Service location | `http://vendorserver:8080/...` |

---

## 4. Reference.cs: The Auto-Generated Proxy

### What is Reference.cs?

**Reference.cs** is an **auto-generated C# file** created by Visual Studio when you add a Web Service Reference.

**Tool Used:** Visual Studio's "Add Service Reference" or "Add Web Reference" wizard
**Input:** WSDL file (from vendor)
**Output:** Reference.cs proxy classes

### How It's Generated

```
┌─────────────────┐     Read WSDL      ┌──────────────────┐
│  qxpsmsdk.wsdl  │ ─────────────────→ │  Visual Studio   │
│ (XML Contract)  │                    │  Proxy Generator │
└─────────────────┘                    └──────────────────┘
                                               ↓
                                        Analyze structure
                                        Generate C# classes
                                               ↓
                                        ┌──────────────────┐
                                        │  Reference.cs    │
                                        │ (Proxy Classes)  │
                                        └──────────────────┘
```

### What Reference.cs Contains

From your project's `QXP.Interop/Web References/QXPSMSDK/Reference.cs`:

```csharp
// AUTO-GENERATED CODE
namespace QXP.Interop.QXPSMSDK {
    
    // ===== PROXY SERVICE CLASS =====
    // Inherits from SoapHttpClientProtocol (SOAP client)
    public partial class QManagerSDKSvcService : System.Web.Services.Protocols.SoapHttpClientProtocol {
        
        // Service URL from WSDL
        public QManagerSDKSvcService() {
            this.Url = "http://vendorserver:8080/axis/services/QManagerSDKSvc";
        }
        
        // ===== METHODS GENERATED FROM WSDL OPERATIONS =====
        
        // Synchronous method
        [System.Web.Services.Protocols.SoapRpcMethodAttribute("")]
        [return: System.Xml.Serialization.SoapElementAttribute("createSessionReturn")]
        public string createSession(long timeout) {
            object[] results = this.Invoke("createSession", new object[] { timeout });
            return ((string)(results[0]));
        }
        
        // Async method (for non-blocking calls)
        public void createSessionAsync(long timeout, object userState) {
            if ((this.createSessionOperationCompleted == null)) {
                this.createSessionOperationCompleted = new System.Threading.SendOrPostCallback(
                    this.OncreateSessionOperationCompleted);
            }
            this.InvokeAsync("createSession", new object[] { timeout }, 
                this.createSessionOperationCompleted, userState);
        }
        
        public event createSessionCompletedEventHandler createSessionCompleted;
        
        // ===== OTHER METHODS =====
        public void closeAllDocs(string sessionId) { ... }
        public void closeDoc(string docName, string sessionId) { ... }
        public void closeSession(string sessionId) { ... }
        public Project getXPressDOM(string documentName) { ... }
        public void saveDoc(string docName, string sessionId) { ... }
        public string processRequest(QRequest request) { ... }
        // ... and many more
    }
    
    // ===== DATA TYPE CLASSES GENERATED FROM WSDL =====
    
    public class Box {
        public string name { get; set; }
        public string boxType { get; set; }
        public Content content { get; set; }
        public Geometry geometry { get; set; }
        public Picture picture { get; set; }
    }
    
    public class Content {
        public string value { get; set; }
    }
    
    public class Geometry {
        public string page { get; set; }
        public Position position { get; set; }
    }
    
    public class Position {
        public string left { get; set; }
        public string top { get; set; }
        public string right { get; set; }
        public string bottom { get; set; }
    }
    
    public class Picture {
        public string angle { get; set; }
        public string offsetAcross { get; set; }
        public string offsetDown { get; set; }
    }
}
```

### Key Points About Reference.cs

1. **100% Auto-Generated:** Don't edit manually (it gets overwritten if you regenerate)
2. **Mirrors WSDL:** Every operation in WSDL becomes a method
3. **SOAP Protocol Handler:** Contains `Invoke()` method that handles SOAP serialization
4. **Type-Safe:** .NET compiler validates calls at compile time
5. **Location Information:** Hardcoded endpoint URL from WSDL

---

## 5. The Role of TElement_Helper

### Purpose of TElement_Helper

**TElement_Helper** is a **factory and utility class** that:
1. Loads template elements from the gabarit (template document)
2. Creates copies/clones of template elements for dynamic tasks
3. Converts between different element types (TBox → Bloc_Box)
4. Manages serialization/deserialization of elements

### TElement_Helper in Action

From the code flow:

```csharp
// In Process_Document.cs
switch (task.Sub_Task_Type)
{
    case Sub_Task_Type.File_PDF:
        // Get a copy of a template element
        __tBox = TElement_Helper.Get_TElement(Static_TElement_Name.PDF_1, __blocName) as TBox;
        // TBox now wraps a QXPSMSDK.Box from the template
        __tBox.SrcBox.content.value = __doc.GetPDFFileAbsolutePath(__file);
        break;
}
```

### Data Flow Through TElement_Helper

```
┌──────────────────────────────────────────────────────┐
│ Dynamic Task Creation                                │
│ (Processing PDF/Document)                            │
└────────────────────┬─────────────────────────────────┘
                     ↓
        Need template to create bloc
                     ↓
┌──────────────────────────────────────────────────────┐
│ TElement_Helper.Get_TElement()                       │
│                                                      │
│ 1. Load static template from gabarit                │
│ 2. Deserialize from XML/Binary cache               │
│ 3. Return as TBox wrapper                           │
│                                                      │
│ Returns: TBox object containing:                    │
│   - _srcBox (QXPSMSDK.Box from template)           │
│   - _srcExtraBox (optional extra Box)               │
│   - Metadata (type, page, dimensions)               │
└────────────────────┬─────────────────────────────────┘
                     ↓
┌──────────────────────────────────────────────────────┐
│ Your Code Modifies TBox Properties                  │
│                                                      │
│ __tBox.SrcBox.content.value = new_data;            │
│ __tBox.SrcBox.geometry.position.left = new_x;      │
│ __tBox.SrcBox.picture.angle = "90";                │
└────────────────────┬─────────────────────────────────┘
                     ↓
┌──────────────────────────────────────────────────────┐
│ Wrap in Bloc_Box for Processing                     │
│                                                      │
│ Bloc_Box __blocBox = new Bloc_Box(task,            │
│     __destinationName, __tBox);                     │
│                                                      │
│ __blocBox.SrcBox → accesses modified QXPSMSDK.Box  │
└────────────────────┬─────────────────────────────────┘
                     ↓
┌──────────────────────────────────────────────────────┐
│ Later: Send to QXPSMSDK Service                     │
│                                                      │
│ Bloc_Box is serialized along with its              │
│ QXPSMSDK.Box objects for server-side processing     │
└──────────────────────────────────────────────────────┘
```

### Key Relationship

```
TElement_Helper
    ↓
  Creates/Returns
    ↓
TBox (Your wrapper)
    ├─ _srcBox ─→ QXPSMSDK.Box
    ├─ _srcExtraBox ─→ QXPSMSDK.Box (optional)
    └─ Metadata
        ↓
  This eventually becomes
        ↓
Bloc_Box (Container for processing)
    ├─ SrcBox ─→ QXPSMSDK.Box (modified)
    └─ SrcExtraBox ─→ QXPSMSDK.Box (modified)
```

---

## 6. Complete Request-Response Flow

### End-to-End Example: Processing a PDF Document

#### **Step 1: Task Initialization**

```csharp
// Location: QXP.Engine.Core/Business/Task/Process_Document.cs
public static void Process(Task_Document task)
{
    // Task contains: document path, destination bloc name, etc.
    // Example: task.Document.FileFullPath = "C:\docs\report.pdf"
    //          task.DestinationBlocName = "PDF_Report"
```

#### **Step 2: Load Template Element**

```csharp
    // Get template element from gabarit (template document)
    __tBox = TElement_Helper.Get_TElement(Static_TElement_Name.PDF_1, __blocName) as TBox;
    
    // What happens inside TElement_Helper.Get_TElement():
    // 1. Loads cache of static template elements from template document
    // 2. Finds the element named "PDF_1"
    // 3. Deserializes from XML format (because templates are XML-based)
    // 4. Returns as TBox wrapper
    //
    // The TBox contains: QXPSMSDK.Box _srcBox (the actual Quark box object)
```

#### **Step 3: Modify the Box**

```csharp
    // Set the PDF file path in the box content
    __tBox.SrcBox.content.value = __doc.GetPDFFileAbsolutePath(__file);
    
    // At this point:
    // - You have a QXPSMSDK.Box object
    // - Its content.value property = "/path/to/file.pdf"
    // - This is a local proxy object, not at the vendor service yet
    
    // Set rotation if needed
    if(task.Rotation_Image)
    {
        __tBox.SrcBox.picture.angle = "90";
        __tBox.SrcExtraBox.picture.offsetAcross = task.Image_Offset.GetOffset(__i);
    }
```

#### **Step 4: Create Container for Block Processing**

```csharp
    __blocBox = new Bloc_Box(task, __blocName, __tBox);
    
    // Bloc_Box stores:
    // - Task reference (for tracking)
    // - Bloc name (identifier in document)
    // - _srcBox: QXPSMSDK.Box (modified)
    // - _srcExtraBox: QXPSMSDK.Box (modified)
    
    // Add to task for later processing
    task.Blocs_Modify.Add(__blocBox.Name, __blocBox);
```

#### **Step 5: Prepare Request for QXPSMSDK Service**

When it's time to save/modify the document:

```csharp
// Location: Somewhere in the execution engine
// Pseudocode showing the concept

// Create proxy service client
var qxpsmService = new QManagerSDKSvcService();
// The URL is: http://vendorserver:8080/axis/services/QManagerSDKSvc

// Create request object containing all modifications
var request = new QRequest();
request.docName = "document.qxp";
request.sessionId = currentSession;
request.modifications = new List<Modification>();

// For each Bloc_Box in task.Blocs_Modify
foreach(var blocBox in task.Blocs_Modify.Values)
{
    // Create modification with the QXPSMSDK.Box
    var mod = new Modification();
    mod.boxName = blocBox.Name;
    mod.box = blocBox.SrcBox;  // ← This is QXPSMSDK.Box
    request.modifications.Add(mod);
}
```

#### **Step 6: Serialize to SOAP XML**

Behind the scenes (in Reference.cs proxy):

```csharp
// The proxy's Invoke() method is called
public string processRequest(QRequest request) {
    object[] results = this.Invoke("processRequest", new object[] { request });
    return ((string)(results[0]));
}

// Invoke() method (inherited from SoapHttpClientProtocol) does:
// 1. Serialize QRequest object to XML
// 2. Wrap in SOAP envelope
// 3. Create XML that looks like:

/*
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <tns:processRequest xmlns:tns="http://webservice.manager.quark.com">
      <qrequest>
        <docName>document.qxp</docName>
        <sessionId>SESSION-12345</sessionId>
        <modifications>
          <modification>
            <boxName>PDF_Report_1</boxName>
            <box>
              <name>PDF_Report_1</name>
              <boxType>PICTURE</boxType>
              <content>
                <value>/path/to/report.pdf</value>
              </content>
              <geometry>
                <page>1</page>
                <position>
                  <left>100</left>
                  <top>200</top>
                  <right>400</right>
                  <bottom>600</bottom>
                </position>
              </geometry>
              <picture>
                <angle>90</angle>
                <offsetAcross>50</offsetAcross>
              </picture>
            </box>
          </modification>
        </modifications>
      </qrequest>
    </tns:processRequest>
  </soap:Body>
</soap:Envelope>
*/
```

#### **Step 7: Send Over HTTP to Vendor Service**

```
Client (.NET Application)          Network              Vendor Service
┌────────────────────────┐        ┌─────────┐         ┌──────────────────┐
│ QXP.Engine.Core        │        │         │         │ QXPSMSDK Service │
│                        │        │ HTTP    │         │ (Windows Server) │
│ processRequest()       ├───────→│ POST    ├────────→│                  │
│ sends SOAP XML         │        │ SOAP    │         │ Windows Service/ │
│                        │        │ message │         │ Apache Axis      │
└────────────────────────┘        │         │         │                  │
                                  │ TCP:    │         └──────────────────┘
                                  │ Port    │
                                  │ 8080/   │
                                  │ 8443    │
                                  └─────────┘
```

**Actual HTTP Request:**

```http
POST /axis/services/QManagerSDKSvc HTTP/1.1
Host: vendorserver:8080
Content-Type: text/xml; charset=utf-8
Content-Length: 2847
SOAPAction: ""

<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="...">
  <soap:Body>
    <tns:processRequest xmlns:tns="...">
      <!-- XML representation of QRequest object -->
    </tns:processRequest>
  </soap:Body>
</soap:Envelope>
```

#### **Step 8: Vendor Service Processes Request**

The QXPSMSDK service (Apache Axis, SOAP listener):

```
1. Receives HTTP POST with SOAP XML
2. Deserializes SOAP to Java objects (vendor uses Java)
3. Parses QRequest
4. For each modification:
   - Locate box in document by name
   - Update box properties (content, position, rotation, etc.)
   - Apply PDF file link
5. Executes business logic (rendering, layout calculations)
6. Returns success response
```

#### **Step 9: Serialize Response to SOAP XML**

```xml
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <tns:processRequestResponse xmlns:tns="http://webservice.manager.quark.com">
      <result>SUCCESS</result>
      <transactionId>TXN-67890</transactionId>
      <modifiedBoxes>
        <box>
          <name>PDF_Report_1</name>
          <updateStatus>APPLIED</updateStatus>
        </box>
      </modifiedBoxes>
    </tns:processRequestResponse>
  </soap:Body>
</soap:Envelope>
```

#### **Step 10: Send Response Over HTTP**

```http
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8
Content-Length: 1245

<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope ...>
  <!-- Response SOAP XML -->
</soap:Envelope>
```

#### **Step 11: Deserialize Response in Proxy**

The Reference.cs proxy receives SOAP response:

```csharp
// In SoapHttpClientProtocol.Invoke() method
// 1. Receives HTTP response with SOAP XML
// 2. Parses SOAP envelope
// 3. Extracts processRequestResponse from soap:Body
// 4. Deserializes XML back to C# objects
// 5. Returns to caller

public string processRequest(QRequest request) {
    object[] results = this.Invoke("processRequest", new object[] { request });
    return ((string)(results[0]));  // ← Returns "SUCCESS"
}
```

#### **Step 12: Handle Response in Your Code**

```csharp
// In your business logic
string result = qxpsmService.processRequest(request);

if(result == "SUCCESS")
{
    task.Status = TaskStatus.Completed;
    task.SaveDocument();  // Save the modified document
}
else
{
    task.Status = TaskStatus.Failed;
    task.Run.Errors.Add(result);
}
```

### Data Transformation Summary

```
Your Code                SOAP Serialization      Vendor Service
─────────────────────────────────────────────────────────────
C# Object               XML Element
└─ TBox                 └─ tns:TBox
   ├─ _srcBox              ├─ name: "PDF_Report"
   │  ├─ name              ├─ content
   │  ├─ content.value        ├─ value: "/file.pdf"
   │  ├─ geometry           ├─ geometry
   │  │  └─ position          ├─ page: "1"
   │  └─ picture            └─ position
   └─ metadata                └─ left, top, right, bottom


     ↓ (Via HTTP SOAP Protocol)
     
Java Object (Vendor Side)
└─ Box
   ├─ name: "PDF_Report"
   ├─ content
   │  └─ value: "/file.pdf"
   ├─ geometry
   │  ├─ page: "1"
   │  └─ position
   │     ├─ left: 100
   │     ├─ top: 200
   │     ├─ right: 400
   │     └─ bottom: 600
   └─ [Business Logic Executed]
      └─ Returns status/result
```

---

## 7. Current Architecture vs. Future Cloud Architecture

### Current Setup (All on Windows Server)

```
┌─────────────────────────────────────────────────────────────┐
│ Single Windows Server                                       │
│                                                              │
│ ┌──────────────────┐  ┌──────────────────┐                 │
│ │  QXP.Website     │  │  QXP.Engine      │                 │
│ │  (.NET)          │  │  (.NET)          │                 │
│ └────────┬─────────┘  └────────┬─────────┘                 │
│          │                     │                            │
│          └─────────┬───────────┘                            │
│                    ↓                                        │
│          ┌─────────────────┐    ┌──────────────────┐       │
│          │ QXP.Batch       │    │ QXP.Upload       │       │
│          │ (.NET Service)  │    │ (.NET Service)   │       │
│          └────────┬────────┘    └────────┬─────────┘       │
│                   │                      │                 │
│                   └──────────┬───────────┘                 │
│                              ↓                             │
│                   ┌─────────────────────┐                 │
│                   │   QXP.Framework     │                 │
│                   │   (.NET Library)    │                 │
│                   └────────┬────────────┘                 │
│                            │                              │
│                            ↓                              │
│                   ┌─────────────────────┐                 │
│                   │  QXP.Interop        │                 │
│                   │  (Proxy to Vendor)  │                 │
│                   └────────┬────────────┘                 │
│                            │                              │
│              Network call   │  (SOAP/HTTP)               │
│              Localhost      │  Port 8080-8443            │
│                            ↓                              │
│                   ┌─────────────────────┐                 │
│                   │  QXPSMSDK Service   │                 │
│                   │  (Vendor - Windows  │                 │
│                   │   Service/Axis)     │                 │
│                   └─────────────────────┘                 │
│                                                              │
│ All services within same network                           │
│ Low latency                                                │
│ Firewall not typically involved                            │
└─────────────────────────────────────────────────────────────┘
```

### Future Setup (Cloud + Windows Server for Vendor)

```
┌────────────────────────────────────────────────────────────────┐
│ Cloud Platform (AWS/Azure/Google Cloud)                        │
│                                                                │
│ ┌──────────────────────────────────────────────────────────┐  │
│ │ Kubernetes/Container Cluster                             │  │
│ │                                                           │  │
│ │ ┌──────────────┐  ┌──────────────┐                       │  │
│ │ │ QXP.Website  │  │ QXP.Engine   │                       │  │
│ │ │ (Java Spring)│  │ (Java Spring)│                       │  │
│ │ └──────┬───────┘  └──────┬───────┘                       │  │
│ │        │                 │                               │  │
│ │        └────────┬────────┘                               │  │
│ │               ↓                                          │  │
│ │ ┌──────────────────────────────┐                        │  │
│ │ │ Spring Core Library          │                        │  │
│ │ │ (Business Logic)             │                        │  │
│ │ └────────┬─────────────────────┘                        │  │
│ │          │                                              │  │
│ │          ↓                                              │  │
│ │ ┌──────────────────────────────┐                        │  │
│ │ │ QXPSMSDK Client              │                        │  │
│ │ │ (Generated from WSDL)        │                        │  │
│ │ │ - JAX-WS Client Classes      │                        │  │
│ │ │ - SOAP Protocol Handler      │                        │  │
│ │ └────────┬─────────────────────┘                        │  │
│ │          │                                              │  │
│ │          ↓                                              │  │
│ │ ┌──────────────────────────────┐                        │  │
│ │ │ HTTPS/TLS Encryption         │                        │  │
│ │ │ (Cloud egress)               │                        │  │
│ │ └────────┬─────────────────────┘                        │  │
│ └─────────┼────────────────────────────────────────────────┘  │
│           │                                                   │
│           │ HTTPS                                            │
│           │ Port 443                                         │
│           │ (Internet)                                       │
│           ↓                                                   │
│ ┌────────────────────────────────────────────────────────────┐
│ │ On-Premises Windows Server (Vendor Location)              │
│ │                                                            │
│ │ ┌──────────────────────────────────────┐                  │
│ │ │ QXPSMSDK Service                     │                  │
│ │ │ (Apache Axis / Windows Service)      │                  │
│ │ │                                      │                  │
│ │ │ SOAP Listener: Port 8080/8443        │                  │
│ │ │ TLS/Firewall configured              │                  │
│ │ └──────────────────────────────────────┘                  │
│ │                                                            │
│ │ Firewall Rules:                                           │
│ │ - Allow inbound: Cloud platform IP range                │
│ │ - Port 8080/8443                                         │
│ └────────────────────────────────────────────────────────────┘
```

### Key Differences

| Aspect | Current | Future |
|--------|---------|--------|
| **Platform** | Windows Server (.NET) | Cloud (Java Spring Boot) |
| **Network** | Local (LAN) | Internet (WAN) |
| **Security** | Network firewall | HTTPS/TLS + Firewall |
| **Latency** | ~10ms | ~50-100ms (depending on geography) |
| **Deployment** | Single machine | Multiple replicas |
| **Scaling** | Vertical | Horizontal (auto-scaling) |
| **Vendor Location** | Same server | Remote (on-premises) |
| **WSDL Usage** | Required | Required |

---

## 8. Java Spring Boot Implementation Strategy

### Key Point: WSDL is Technology-Agnostic

**WSDL works equally well with Java as it does with .NET.** The difference is:
- **.NET:** Uses `System.Web.Services` + auto-generated Reference.cs
- **Java:** Uses JAX-WS + `wsimport` tool to generate client

### Step-by-Step Java Migration

#### **1. Obtain the WSDL File**

The vendor provides: `qxpsmsdk.wsdl`

This file contains the complete contract:
- Service operations
- Data types
- Endpoints
- Protocol (SOAP/HTTP)

#### **2. Generate Java Client from WSDL**

Use Java's `wsimport` tool (JAX-WS):

```bash
# Generate Java stub classes from WSDL
wsimport -keep -p com.quark.qxpsm.client http://vendorserver:8080/axis/services/QManagerSDKSvc?wsdl

# Or from local file:
wsimport -keep -p com.quark.qxpsm.client qxpsmsdk.wsdl
```

This generates Java classes equivalent to Reference.cs:

```
Generated Files:
├─ QManagerSDKSvcService.java      (Service class - replaces QManagerSDKSvcService in C#)
├─ Box.java                        (Data type - replaces QXPSMSDK.Box)
├─ Content.java                    (Data type - replaces Content)
├─ Geometry.java                   (Data type - replaces Geometry)
├─ Position.java                   (Data type - replaces Position)
├─ Picture.java                    (Data type - replaces Picture)
├─ Project.java                    (Complex data type)
├─ QRequest.java                   (Request wrapper)
└─ ... (other generated classes)
```

#### **3. Project Structure (Java Spring Boot)**

```
qxp-engine-service/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── company/
│   │   │           └── qxp/
│   │   │               ├── QxpEngineApplication.java
│   │   │               ├── controller/
│   │   │               │   └── DocumentController.java
│   │   │               ├── service/
│   │   │               │   ├── DocumentProcessingService.java
│   │   │               │   └── QxpsmVendorService.java  ← Wraps WSDL client
│   │   │               ├── model/
│   │   │               │   ├── Task.java
│   │   │               │   ├── Document.java
│   │   │               │   └── TElement.java
│   │   │               ├── config/
│   │   │               │   └── QxpsmClientConfig.java
│   │   │               └── generated/  ← From wsimport
│   │   │                   ├── client/
│   │   │                   │   ├── QManagerSDKSvcService.java
│   │   │                   │   ├── Box.java
│   │   │                   │   └── ... (other generated)
│   │   └── resources/
│   │       └── application.properties
│   └── test/
├── pom.xml
└── README.md
```

#### **4. pom.xml Configuration**

```xml
<dependencies>
    <!-- Spring Boot -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    
    <!-- JAX-WS (SOAP Client) -->
    <dependency>
        <groupId>org.apache.cxf</groupId>
        <artifactId>cxf-spring-boot-starter-jaxws</artifactId>
        <version>3.4.5</version>
    </dependency>
    
    <!-- SOAP/XML Processing -->
    <dependency>
        <groupId>com.sun.xml.ws</groupId>
        <artifactId>jaxws-rt</artifactId>
        <version>2.3.3</version>
    </dependency>
</dependencies>

<plugins>
    <!-- Generate Java classes from WSDL -->
    <plugin>
        <groupId>org.apache.cxf</groupId>
        <artifactId>cxf-codegen-plugin</artifactId>
        <version>3.4.5</version>
        <executions>
            <execution>
                <id>generate-sources</id>
                <phase>generate-sources</phase>
                <goals>
                    <goal>wsdl2java</goal>
                </goals>
                <configuration>
                    <sourceRoot>${project.build.sourceDirectory}</sourceRoot>
                    <wsdlOptions>
                        <wsdlOption>
                            <wsdl>src/main/resources/wsdl/qxpsmsdk.wsdl</wsdl>
                            <packagename>com.quark.qxpsm.client</packagename>
                        </wsdlOption>
                    </wsdlOptions>
                </configuration>
            </execution>
        </executions>
    </plugin>
</plugins>
```

#### **5. Spring Configuration Class**

```java
package com.company.qxp.config;

import com.quark.qxpsm.client.QManagerSDKSvcService;
import com.quark.qxpsm.client.QManagerSDKSvc;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class QxpsmClientConfig {
    
    @Value("${qxpsm.service.url}")  // From application.properties
    private String qxpsmServiceUrl;
    
    @Bean
    public QManagerSDKSvc qxpsmService() {
        QManagerSDKSvcService service = new QManagerSDKSvcService();
        QManagerSDKSvc port = service.getQManagerSDKSvcPort();
        
        // Set endpoint URL
        ((BindingProvider) port).getRequestContext()
            .put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, qxpsmServiceUrl);
        
        // Configure timeouts
        ((BindingProvider) port).getRequestContext()
            .put("com.sun.xml.ws.connect.timeout", 30000);  // 30 seconds
        ((BindingProvider) port).getRequestContext()
            .put("com.sun.xml.ws.request.timeout", 30000);
        
        return port;
    }
}
```

#### **6. application.properties**

```properties
# QXPSMSDK Vendor Service Configuration
qxpsm.service.url=http://vendorserver:8080/axis/services/QManagerSDKSvc

# For production with HTTPS:
# qxpsm.service.url=https://vendorserver:8443/axis/services/QManagerSDKSvc
```

#### **7. Vendor Service Wrapper (Java)**

```java
package com.company.qxp.service;

import com.quark.qxpsm.client.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class QxpsmVendorService {
    
    @Autowired
    private QManagerSDKSvc qxpsmService;
    
    /**
     * Equivalent to .NET's: qxpsmService.processRequest(request)
     */
    public String processRequest(QRequest request) {
        try {
            // Call WSDL method
            String result = qxpsmService.processRequest(request);
            return result;
        } catch (Exception e) {
            throw new QxpsmServiceException("Failed to process request", e);
        }
    }
    
    /**
     * Create a session
     */
    public String createSession(long timeout) {
        try {
            return qxpsmService.createSession(timeout);
        } catch (Exception e) {
            throw new QxpsmServiceException("Failed to create session", e);
        }
    }
    
    /**
     * Get XPress DOM from vendor service
     */
    public Project getXPressDOM(String documentName) {
        try {
            return qxpsmService.getXPressDOM(documentName);
        } catch (Exception e) {
            throw new QxpsmServiceException("Failed to get XPress DOM", e);
        }
    }
    
    /**
     * Close session
     */
    public void closeSession(String sessionId) {
        try {
            qxpsmService.closeSession(sessionId);
        } catch (Exception e) {
            throw new QxpsmServiceException("Failed to close session", e);
        }
    }
}
```

#### **8. Document Processing Service (Java)**

```java
package com.company.qxp.service;

import com.quark.qxpsm.client.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class DocumentProcessingService {
    
    @Autowired
    private QxpsmVendorService vendorService;
    
    /**
     * Process PDF document - equivalent to .NET's Process_Document.Process()
     */
    public void processPDFDocument(Task task) {
        // Step 1: Create QXPSMSDK Box objects
        Box pdfBox = createPDFBox(
            task.getDestinationBlocName(),
            task.getDocument().getFilePath()
        );
        
        // Step 2: Set properties
        pdfBox.getContent().setValue(task.getDocument().getFilePath());
        pdfBox.getGeometry().setPage("1");
        
        if (task.isRotationImage()) {
            pdfBox.getPicture().setAngle("90");
        }
        
        // Step 3: Prepare request for vendor service
        QRequest request = new QRequest();
        request.setDocName(task.getDocument().getName());
        request.setSessionId(getCurrentSessionId());
        
        // Step 4: Add modification
        Modification modification = new Modification();
        modification.setBoxName(task.getDestinationBlocName());
        modification.setBox(pdfBox);
        request.getModifications().add(modification);
        
        // Step 5: Send to QXPSMSDK vendor service
        String result = vendorService.processRequest(request);
        
        if ("SUCCESS".equals(result)) {
            task.setStatus(TaskStatus.COMPLETED);
        } else {
            task.setStatus(TaskStatus.FAILED);
            throw new ProcessingException("Failed to process PDF: " + result);
        }
    }
    
    private Box createPDFBox(String name, String filePath) {
        Box box = new Box();
        box.setName(name);
        box.setBoxType("PICTURE");
        
        Content content = new Content();
        content.setValue(filePath);
        box.setContent(content);
        
        Geometry geometry = new Geometry();
        Position position = new Position();
        position.setLeft("100");
        position.setTop("200");
        position.setRight("400");
        position.setBottom("600");
        geometry.setPosition(position);
        box.setGeometry(geometry);
        
        Picture picture = new Picture();
        box.setPicture(picture);
        
        return box;
    }
    
    private String getCurrentSessionId() {
        // Implementation to get/create session
        // Using same QXPSMSDK service
        return vendorService.createSession(300000);  // 5 minutes
    }
}
```

#### **9. HTTP Request/Response (Java)**

When Java code calls the WSDL service:

```java
// Your code
String result = vendorService.processRequest(request);

// Behind the scenes (JAX-WS automatically does):
```

**HTTP Request (Same as .NET):**
```http
POST /axis/services/QManagerSDKSvc HTTP/1.1
Host: vendorserver:8080
Content-Type: text/xml; charset=utf-8
Content-Length: 2847
SOAPAction: ""
Authorization: Basic [credentials if needed]

<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <tns:processRequest xmlns:tns="http://webservice.manager.quark.com">
      <!-- QRequest as XML -->
    </tns:processRequest>
  </soap:Body>
</soap:Envelope>
```

**HTTP Response (Same as .NET):**
```http
HTTP/1.1 200 OK
Content-Type: text/xml; charset=utf-8

<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <tns:processRequestResponse xmlns:tns="http://webservice.manager.quark.com">
      <result>SUCCESS</result>
    </tns:processRequestResponse>
  </soap:Body>
</soap:Envelope>
```

### Key Takeaways for Java Migration

1. **WSDL is Universal:** The same WSDL works for .NET and Java
2. **Code Generation:** Both .NET (Reference.cs) and Java (wsimport) generate proxy classes
3. **Identical Protocol:** Both use SOAP/HTTP, so the request/response is identical
4. **Wrapper Service:** Create a Spring Service wrapper around JAX-WS client classes
5. **URL Configuration:** Use Spring properties to configure vendor service endpoint
6. **Error Handling:** Catch exceptions from WSDL calls and handle appropriately
7. **No Changes Needed to Vendor:** The vendor service remains unchanged on Windows server

### Diagram: Equivalence Between .NET and Java

```
.NET Implementation              Java Implementation
═══════════════════════════════════════════════════════════

using QXPSMSDK                  import com.quark.qxpsm.client.*;
  = com.quark.qxpsm;              (generated from WSDL)

Reference.cs                    QManagerSDKSvcService.java
(auto-generated)                (auto-generated from wsimport)

QXPSMSDK.Box                    Box
(proxy class)                   (generated Java class)

SoapHttpClientProtocol          JAX-WS Client
(SOAP protocol handler)         (SOAP protocol handler)

QManagerSDKSvcService client    QManagerSDKSvc port
  = new ...                       = service.getPort()

client.processRequest(req)      port.processRequest(req)

System.Web.Services             javax.xml.ws (JAX-WS)
(namespace)                     (namespace)

↓ Both send same SOAP/HTTP ↓

QXPSMSDK Service
(Vendor)
```

---

## Summary

### What is `using QXPSMSDK = com.quark.qxpsm;`?
A **namespace alias** that shortens vendor library references.

### How Does Your Code Know QXPSMSDK Methods?
1. **WSDL File:** Vendor provides contract in XML
2. **Reference.cs:** Visual Studio generates proxy classes from WSDL
3. **Compile Time:** .NET compiler validates method signatures
4. **Runtime:** SOAP client serializes calls and sends to vendor service

### What is Reference.cs?
**Auto-generated proxy** containing:
- Service client class (QManagerSDKSvcService)
- Data type classes (Box, Content, Geometry, etc.)
- SOAP protocol handlers
- Service endpoint URL

### What is TElement_Helper?
**Factory class** that:
- Loads template elements from gabarit
- Wraps QXPSMSDK.Box in TBox for easier handling
- Manages serialization/deserialization

### Complete Flow
```
Code → TElement_Helper → TBox → Bloc_Box → Serialize to SOAP XML → 
HTTP POST → QXPSMSDK Service → Process → HTTP Response → 
Deserialize → Return Result → Continue Processing
```

### Java Spring Boot Compatibility
- Use same **WSDL file** from vendor
- Run `wsimport` tool to generate Java classes
- Use JAX-WS instead of System.Web.Services
- Wrap in Spring Service
- Identical SOAP/HTTP protocol → Vendor service unchanged
- Zero code changes needed at vendor side

### Key Requirement
**WSDL file + Service installation at specific endpoint = Complete integration**

---

## Additional Resources

### Files Referenced in Your Project
- **WSDL:** `QXP/QXP.Interop/Web References/QXPSMSDK/qxpsmsdk.wsdl`
- **Proxy:** `QXP/QXP.Interop/Web References/QXPSMSDK/Reference.cs` (17,142 lines)
- **Wrapper:** `QXP/QXP.Engine.Core/Helper/TElement_Helper.cs`
- **Usage:** `QXP/QXP.Engine.Core/Business/Task/Process_Document.cs`
- **Data Model:** `QXP/QXP.Engine.Core/BusinessObject/Bloc/Bloc_Box.cs`

### Configuration Files
- **Service URL:** Typically in `app.config` or `application.properties`
- **Credentials:** May be stored in configuration or environment variables
- **Timeouts:** Configurable in SOAP client settings

### Common Troubleshooting

| Issue | Cause | Solution |
|-------|-------|----------|
| "Service unavailable" | Vendor service offline | Check endpoint URL, firewall, network |
| "Timeout" | Network latency | Increase timeout in config |
| "Deserialization error" | WSDL version mismatch | Regenerate Reference.cs/Java classes |
| "Authentication failed" | Wrong credentials | Check SOAP headers for auth |
| "Method not found" | Outdated WSDL | Update from vendor |

