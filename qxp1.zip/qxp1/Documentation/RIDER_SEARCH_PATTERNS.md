# Rider Structural Search & Regex Patterns for Oracle Connectivity Audit

This document provides search patterns for JetBrains Rider IDE to find additional Oracle connectivity points and verify completeness of the audit.

---

## SECTION 1: STRUCTURAL SEARCH PATTERNS (Rider Syntax)

### 1.1 Find All Oracle Namespaces

**Pattern (Structural Search):**
```
using $Package = Oracle.DataAccess.*
```

**Expected Results:** 20 matches (already found)

**What it finds:**
- All `using Oracle.DataAccess.Client;`
- All `using Oracle.DataAccess.Types;`

---

### 1.2 Find All OraClient Instantiations

**Pattern (Structural Search):**
```
new OraClient($args)
```

**Expected Results:** Multiple matches in Proxy base classes

**What it finds:**
- Every place where `new OraClient()` is called
- Identifies connection creation patterns

---

### 1.3 Find All OracleConnection Usage

**Pattern (Structural Search):**
```
new OracleConnection($arg)
```

**Expected Results:** 1 match in OracleClient.cs

**Location:** `QXP.Framework\Data\DataBase\Oracle\OracleClient.cs:206`

**What it finds:**
- Direct OracleConnection instantiation

---

### 1.4 Find All OracleCommand Execution

**Pattern (Structural Search):**
```
$cmd:OracleCommand.$method($args)
```

**with constraints:**
- Method = `ExecuteScalar | ExecuteReader | ExecuteDataSet | ExecuteNonQuery`

**Expected Results:** Multiple matches in OracleClient.cs

**What it finds:**
- All Oracle command execution points
- Query execution patterns

---

### 1.5 Find All Connection String Retrievals

**Pattern (Structural Search):**
```
$var.GetDBConnectionString($args)
```

**Expected Results:** Multiple in DBConnectionSettings.cs and OracleClient.cs

**What it finds:**
- Connection string loading points
- Decryption call sites

---

### 1.6 Find All Crypt.DecryptStringFK Calls

**Pattern (Structural Search):**
```
Crypt.DecryptStringFK($arg)
```

**Expected Results:** 2 matches in DBConnectionSettings.cs

**Locations:**
- `QXP.Framework\Configuration\DBConnectionSettings.cs:42`
- `QXP.Framework\Configuration\DBConnectionSettings.cs:66`

**What it finds:**
- All places where encrypted strings are decrypted

---

### 1.7 Find All appSettings References to DBConnection

**Pattern (Structural Search):**
```
Settings.Current.GetString("DBConnection")
```

**Expected Results:** 1 match in DBConnectionSettings.cs

**Location:** `QXP.Framework\Configuration\DBConnectionSettings.cs:38`

**What it finds:**
- Where encrypted DB connection is retrieved from config

---

### 1.8 Find All BaseProxy Inheritance

**Pattern (Structural Search):**
```
class $Class extends QXPProxy.BaseProxy
```

**Expected Results:** ~20 Proxy classes

**What it finds:**
- All data access proxy classes
- Classes that use OraClient

---

### 1.9 Find All OracleTransaction Usage

**Pattern (Structural Search):**
```
$var:OracleTransaction
```

**Expected Results:** Multiple in OracleClient.cs

**Locations:**
- Field declaration: `QXP.Framework\Data\DataBase\Oracle\OracleClient.cs:29`
- BeginTransaction: `QXP.Framework\Data\DataBase\Oracle\OracleClient.cs:264`

**What it finds:**
- Transaction handling code
- Commit/Rollback operations

---

### 1.10 Find All LOB Handling (BLOB/CLOB)

**Pattern (Structural Search):**
```
$var:OracleBlob | $var:OracleClob
```

**Expected Results:** 2 matches in OracleClient.cs

**Locations:**
- Line ~125: OracleBlob instantiation
- Line ~129: OracleClob instantiation

**What it finds:**
- Large object (LOB) streaming support
- Stream buffer handling

---

## SECTION 2: REGEX PATTERNS (for grep/Find & Replace)

### 2.1 Find All Oracle Assembly References in .csproj

**Regex Pattern:**
```
<Reference Include="Oracle\.DataAccess[^"]*Version=([0-9.]+)
```

**Captures:**
- Group 1: Version number (should be `4.121.2.0`)

**Search Scope:** `**/*.csproj`

**Expected Results:** 17 matches

---

### 2.2 Find All Encrypted Connection Strings in Config Files

**Regex Pattern:**
```
<add\s+key="DBConnection"\s+value="([A-Za-z0-9/+\=]+)"\s*/>
```

**Captures:**
- Group 1: Encrypted connection string value

**Search Scope:** `**/*.config`

**Expected Results:** 9 matches

---

### 2.3 Find All DBConnection Configuration Keys

**Regex Pattern:**
```
key="DBConnection"\s+value="([^"]*)"
```

**Captures:**
- Group 1: Value (encrypted or placeholder)

**Search Scope:** `**/*.config`

**Expected Results:** 9 matches (encrypted or `{{DBConnection}}`)

---

### 2.4 Find All Using Statements for Oracle.DataAccess

**Regex Pattern:**
```
^using\s+Oracle\.DataAccess\.(Client|Types);$
```

**Captures:**
- Group 1: Namespace (Client or Types)

**Search Scope:** `**/*.cs`

**Expected Results:** 20+ matches

---

### 2.5 Find All OracleConnection Instantiations

**Regex Pattern:**
```
new\s+OracleConnection\s*\(\s*([^)]*)\s*\)
```

**Captures:**
- Group 1: Connection string argument

**Search Scope:** `**/*.cs`

**Expected Results:** 1 match (OracleClient.cs:206)

---

### 2.6 Find All OracleCommand Creation

**Regex Pattern:**
```
(new\s+)?OracleCommand\s*\(\s*([^)]*)\s*\)
```

**Captures:**
- Group 1: Optional "new" keyword
- Group 2: Command arguments

**Search Scope:** `**/*.cs`

**Expected Results:** Multiple in OracleClient.cs

---

### 2.7 Find All ExecuteScalar/ExecuteReader/ExecuteNonQuery Calls

**Regex Pattern:**
```
\.Execute(Scalar|Reader|NonQuery|DataSet|DataTable)\s*\(\s*
```

**Captures:**
- Group 1: Method name (Scalar/Reader/NonQuery/etc)

**Search Scope:** `**/*.cs`

**Expected Results:** Multiple in OracleClient.cs

---

### 2.8 Find All DecryptStringFK Calls

**Regex Pattern:**
```
Crypt\.DecryptStringFK\s*\(\s*([^)]*)\s*\)
```

**Captures:**
- Group 1: String being decrypted

**Search Scope:** `**/*.cs`

**Expected Results:** 2 matches (DBConnectionSettings.cs)

---

### 2.9 Find All Assembly Binding Redirects (including Oracle)

**Regex Pattern:**
```
<assemblyIdentity\s+name="([^"]*Oracle[^"]*)"\s+
```

**Captures:**
- Group 1: Assembly name containing "Oracle"

**Search Scope:** `**/*.config`

**Expected Results:** 0 matches (correct - no redirects for Oracle)

---

### 2.10 Find All Connection String Properties

**Regex Pattern:**
```
(User\s+Id|Password|Data\s+Source|Provider|Max\s+Pool\s+Size)=
```

**Captures:**
- Group 1: Connection string property name

**Search Scope:** `**/*.cs` (in code) and encrypted strings

**Expected Results:** When decrypted

---

### 2.11 Find All Oracle DbType Enumerations

**Regex Pattern:**
```
OracleDbType\.(BLOB|CLOB|Varchar2|Number|Date|Timestamp)
```

**Captures:**
- Group 1: OracleDbType enum value

**Search Scope:** `**/*.cs`

**Expected Results:** Multiple in OracleClient.cs

---

### 2.12 Find All Transaction Begin/Commit/Rollback Calls

**Regex Pattern:**
```
\.(BeginTransaction|CommitTransaction|RollBackTransaction|Commit|Rollback)\s*\(\s*\)
```

**Captures:**
- Group 1: Transaction method name

**Search Scope:** `**/*.cs`

**Expected Results:** Multiple in OracleClient.cs

---

## SECTION 3: STRUCTURAL SEARCH TEMPLATES (XML)

These can be imported into Rider's Structural Search dialog.

### Template 3.1: Find All Database Proxy Classes

```xml
<template name="Database Proxy Classes" category="Oracle">
  <searchscope>File</searchscope>
  <pattern>
    public class $Class extends $BaseClass {
      where $BaseClass matches QXPProxy\\.BaseProxy
    }
  </pattern>
</template>
```

### Template 3.2: Find All Connection Pool Configurations

```xml
<template name="Connection Pool Settings" category="Oracle">
  <searchscope>File</searchscope>
  <pattern>
    Max Pool Size=$value
  </pattern>
</template>
```

### Template 3.3: Find All Oracle Parameter Bindings

```xml
<template name="Oracle Parameter Binding" category="Oracle">
  <searchscope>File</searchscope>
  <pattern>
    $cmd:OracleCommand.Parameters.Add($param)
  </pattern>
</template>
```

### Template 3.4: Find All Configuration Manager Accesses

```xml
<template name="Config Manager Access" category="Oracle">
  <searchscope>File</searchscope>
  <pattern>
    ConfigurationManager.GetSection($section)
  </pattern>
</template>
```

---

## SECTION 4: GREP COMMANDS (PowerShell)

### 4.1 List All Oracle References Across Solution

```powershell
Get-ChildItem -Recurse -Include "*.csproj", "*.cs" | 
  ForEach-Object { 
    Select-String -Path $_ -Pattern "Oracle\." | 
    Select-Object -Property Path,LineNumber,Line
  }
```

### 4.2 Extract All Encrypted Connection Strings

```powershell
Get-ChildItem -Recurse -Include "*.config" | 
  ForEach-Object { 
    Select-String -Path $_ -Pattern 'DBConnection.*value="([^"]*)"' | 
    Select-Object -Property Path,LineNumber,Matches
  }
```

### 4.3 List All Projects Using Oracle.DataAccess

```powershell
Get-ChildItem -Recurse -Include "*.csproj" | 
  ForEach-Object {
    $content = Get-Content $_ -Raw
    if ($content -match 'Oracle\.DataAccess.*4\.121\.2\.0') {
      Write-Output "$_ - Oracle.DataAccess 4.121.2.0"
    }
  }
```

### 4.4 Count Oracle.DataAccess References

```powershell
(Get-ChildItem -Recurse -Include "*.csproj" | 
  Select-String -Pattern "Oracle\.DataAccess.*4\.121\.2\.0" | 
  Measure-Object).Count
# Expected: 17
```

### 4.5 List All Proxy Classes Using Oracle

```powershell
Get-ChildItem -Recurse -Include "Proxy*.cs" | 
  ForEach-Object {
    $content = Get-Content $_ -Raw
    if ($content -match 'using Oracle\.DataAccess\.Client') {
      Write-Output $_.FullName
    }
  }
```

### 4.6 Extract Config File DBConnection Values

```powershell
Get-ChildItem -Recurse -Include "*.config" | 
  ForEach-Object {
    $content = Get-Content $_
    $matches = [regex]::Matches($content, 'DBConnection.*value="([^"]*)"')
    foreach ($match in $matches) {
      [PSCustomObject]@{
        File = $_.FullName
        Value = $match.Groups[1].Value
      }
    }
  }
```

---

## SECTION 5: VERIFICATION CHECKLIST USING SEARCH PATTERNS

Use these searches in order to verify the audit is complete:

- [ ] **Search 2.1** - 17 Oracle.DataAccess references at version 4.121.2.0 ✓
- [ ] **Search 2.2** - 9 encrypted connection strings in config ✓
- [ ] **Search 2.4** - 20+ using statements for Oracle.DataAccess ✓
- [ ] **Search 2.5** - 1 OracleConnection instantiation in OracleClient.cs ✓
- [ ] **Search 2.8** - 2 DecryptStringFK calls in DBConnectionSettings.cs ✓
- [ ] **Search 2.9** - 0 Oracle assembly binding redirects (correct) ✓
- [ ] **Search 2.12** - Multiple transaction methods in OracleClient.cs ✓

---

## SECTION 6: ADDITIONAL PATTERNS FOR ONGOING MAINTENANCE

### Pattern: Find All Security-Related Code

```regex
Security\.Crypt|Encrypt|Decrypt|Password
```

### Pattern: Find All Database-Related Exceptions

```regex
OracleException|OraException|ConnectionString
```

### Pattern: Find All Timeout Configurations

```regex
CommandTimeout|Timeout|TimeSpan\.FromSeconds
```

### Pattern: Find All LOB Handling Code

```regex
OracleBlob|OracleClob|Blob|Clob|Stream
```

### Pattern: Find All Pooling Configuration

```regex
Pool|PoolSize|MaxPoolSize|Min\s+Pool
```

---

## NOTES FOR AUDITORS

1. **Version Consistency:** All 17 projects reference exactly version `4.121.2.0` - no variation
2. **Architecture Specification:** All references specify `processorArchitecture=AMD64` (64-bit only)
3. **No Binding Redirects:** No assembly binding redirects for Oracle - strict version enforcement is active
4. **Centralized Data Layer:** All Oracle access flows through `QXP.Framework.Data.Oracle.OracleClient`
5. **Configuration-Driven:** Connection strings are configuration-driven, not hardcoded
6. **Encryption-First:** All connection strings are encrypted at rest in config files

---

**Last Updated:** 2026-03-10  
**Version:** 1.0  
**Scope:** Complete Oracle connectivity audit patterns

