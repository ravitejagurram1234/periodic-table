# Image Task Processing - Complete Reference Guide

## Overview
Complete documentation of image-related task processing in the QXP Engine, including image classes, document handling, and QuarkXPress server integration.

---

## Table of Contents
1. [Key Classes](#key-classes)
2. [Complete Source Code](#complete-source-code)
3. [Image Processing Flow](#image-processing-flow)
4. [Image Block Creation](#image-block-creation)
5. [QuarkXPress SDK Integration](#quarkxpress-sdk-integration)
6. [Supported Image Formats](#supported-image-formats)

---

## Key Classes

### Image Task Handler Classes
| Class | Location | Purpose |
|-------|----------|---------|
| `Task_Document` | `QXP.Engine.Core/BusinessObject/Run/Task/Task_Document.cs` | Main task handler for document/image insertion |
| `Task_Image_Offset` | `QXP.Engine.Core/BusinessObject/Run/Task/Task_Image_Offset.cs` | Manages image offset values for multi-page handling |
| `Task_Image_Position` | `QXP.Engine.Core/BusinessObject/Run/Task/Task_Image_Position.cs` | Defines image positioning (left, top, right, bottom) |
| `Process_Document` | `QXP.Engine.Core/Business/Task/Process_Document.cs` | Business logic for document/image processing |
| `Process_QXP_Previous` | `QXP.Engine.Core/Business/Task/Process_QXP_Previous.cs` | QXP file data extraction and block creation |

---

## Complete Source Code

### 1. Task_Document.cs

**Location:** `QXP/QXP.Engine.Core/BusinessObject/Run/Task/Task_Document.cs`

**Purpose:** Represents a task linked to documents/images to be inserted into QuarkXPress documents.

```csharp
using QXPFrk	= QXP.Framework;
using QXPIO		= QXP.Framework.IO;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Represents a task linked to documents to be inserted
	/// </summary>
	/// <author>doufarm</author>
	/// <date>22/03/2010 17:55:55</date>    
	public class Task_Document : Task_Base
	{
		#region Members
		string				_format_Document;
        bool				_rotation_image			= false;    // Apply 90° rotation to image block content
        int					_id_sous_categorie;					// Document sub-category
		bool				_conserver_Style		= false;	// false = copy content without style
        string				_offset_Values			= null;     // Image offset values (for PDF type tasks)
		Task_Image_Offset	_image_Offset			= null;		// Offset evaluation helper
		Document			_document				= null;
		string				_position_Values		= null;     // Image position values
		Task_Image_Position _image_Position;					// Position evaluation helper
		#endregion Members

		#region Constructors
		/// <summary>
		/// Creates an instance of Task_Document
		/// </summary>
		/// <param name="id_tache">task identifier</param>
		/// <param name="run">run that owns this task</param>
		public Task_Document(int id_tache, Run_Base run): base(id_tache, run)
		{
		}
		#endregion Constructors

		#region Methods
		/// <summary>
		/// Prepares the task before execution
		/// </summary>
		public override void Prepare()
		{
			switch(QXPFrk.Conversion.ToString(this.Format_Document).ToUpper())
			{
				case Constantes.Document_Format.PDF:
					this.Sub_Task_Type = Sub_Task_Type.File_PDF;
					this.ToLoad = true;
					break;
				case Constantes.Document_Format.JPG:
				case Constantes.Document_Format.JPEG:
				case Constantes.Document_Format.EPS:
				case Constantes.Document_Format.TIF:
				case Constantes.Document_Format.TIFF:
					this.Sub_Task_Type = Sub_Task_Type.File_IMG;
					this.ToLoad = true;
					break;
				case Constantes.Document_Format.GIF:
					this.Sub_Task_Type = Sub_Task_Type.File_IMG;
					this.ToLoad = true;
					break;
				case Constantes.Document_Format.RTF:
					this.Sub_Task_Type = Sub_Task_Type.File_RTF;
					break;
				case Constantes.Document_Format.DOC:
					this.Sub_Task_Type = Sub_Task_Type.File_DOC;
					break;
				case Constantes.Document_Format.XTG:
					this.Sub_Task_Type = Sub_Task_Type.File_XTG;
					break;
				default:
					this.Sub_Task_Type = Sub_Task_Type.Unknown;
					break;
			}			

            // This is a reference document to load and upload to server
		}

		/// <summary>
		/// Execution of the task
		/// </summary>
		public override void Execute()
		{
			Process_Document.Process(this);
		}

		/// <summary>
		/// Indicates if this task is based on a QXP document and size is too large, 
		/// task switches to degraded mode
		/// </summary>
		public override bool	Mode_Degrade
		{
			get
			{
				if (QXPFrk.Validation.IsNotNull(this.Document))
				{
					return this.Document.Mode_Degrade;
				}
				else
				{
					return false;
				}
			}
		}
		#endregion Methods

		#region Properties
		/// <summary>
		/// Document format (PDF, JPG, GIF, etc.)
		/// </summary>
		public string Format_Document
		{
			get { return _format_Document; }
			set { _format_Document = value; }
		}

		/// <summary>
		/// Apply 90° rotation to image content
		/// </summary>
		public bool Rotation_Image
		{
			get { return _rotation_image; }
			set { _rotation_image = value; }
		}

		/// <summary>
		/// Sub-category ID of associated document
		/// </summary>
		public int Id_Sous_Categorie
		{
			get { return _id_sous_categorie; }
			set { _id_sous_categorie = value; }
		}

		/// <summary>
		/// Copy content without styles (default false)
		/// </summary>
		public bool Conserver_Style
		{
			get { return _conserver_Style; }
			set { _conserver_Style = value; }
		}

		/// <summary>
		/// Image offset values (e.g., "-180|-130")
		/// </summary>
		public string Offset_Values
		{
			get { return _offset_Values; }
			set { _offset_Values = value; }
		}

		public string Position_Values
        {
            get { return _position_Values; }
            set { _position_Values = value; }
        }

		/// <summary>
		/// Helper for offset evaluation based on pages
		/// </summary>
		public Task_Image_Offset	Image_Offset
		{
			get { return _image_Offset; }
			set { _image_Offset = value; }
		}

		/// <summary>
		/// Helper for position evaluation based on pages
		/// </summary>
		public Task_Image_Position Image_Position
		{
			get { return _image_Position; }
			set { _image_Position = value; }
		}

		/// <summary>
		/// Document object containing info and stream of associated document
		/// </summary>
		public Document			Document 
		{
			get { return _document; }
			set { _document = value; }
		}

		/// <summary>
		/// Source block name (for style copying)
		/// </summary>
		public string SourceBlocName
		{
			get { return base._source_Bloc_Name; }
			set { base._source_Bloc_Name = value; }
		}

		/// <summary>
		/// Destination block name to insert document
		/// </summary>
		public string DestinationBlocName
		{
			get { return base._destination_Bloc_Name; }
			set { base._destination_Bloc_Name = value; }
		}
		#endregion Properties
	}
}
```

---

### 2. Task_Image_Position.cs

**Location:** `QXP/QXP.Engine.Core/BusinessObject/Run/Task/Task_Image_Position.cs`

**Purpose:** Defines the position of an image in certain task types with left, top, right, bottom coordinates.

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk	= QXP.Framework;
using QXPAudit	= QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Defines the position of an image in certain task types
	/// </summary>
	/// <author>doufarm</author>
	/// <date>05/10/2010 12:08:20</date>    
	public class Task_Image_Position
	{
		#region Members
		string _left;
		string _top;
		string _right;
		string _bottom;
		
		static readonly Task_Image_Position Default = new Task_Image_Position(DefImagePositionValues);
		#endregion Members

		#region Constants
        public const string DefImagePositionValues = "42,52;56,693;552,756;785,197";
		
		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructors

		/// <summary>
		/// Creates an instance of Task_Image_Position from values parameter (left;top;right;bottom)
		/// </summary>
		/// <param name="values">position values separated by semicolons (e.g., "42.52;56.693;552.756;785.197")</param>
		public Task_Image_Position(string values)
		{
			if(QXPFrk.Validation.IsSet(values))
			{
				string[] __tab = values.Split(new char[] { ';' });
				if(__tab.Length == 4)
				{
					_left	= __tab[0];
					_top	= __tab[1];
					_right	= __tab[2];
					_bottom = __tab[3];
				}
				else
				{
					_left	= Default._left;
					_top	= Default._top;
					_right	= Default._right;
					_bottom = Default._bottom;
				}
			}
			else
			{
				_left	= Default._left;
				_top	= Default._top;
				_right	= Default._right;
				_bottom = Default._bottom;
			}
		}

		#endregion Constructors

		#region Methods

		#endregion Methods

		#region Properties
		
		public string Left
		{
			get { return _left; }
		}

		public string Top
		{
			get { return _top; }
		}

		public string Right
		{
			get { return _right; }
		}

		public string Bottom
		{
			get { return _bottom; }
		}

		#endregion Properties
	}
}
```

---

### 3. Task_Image_Offset.cs

**Location:** `QXP/QXP.Engine.Core/BusinessObject/Run/Task/Task_Image_Offset.cs`

**Purpose:** Manages image offset values for multi-page handling, particularly for PDF files with rotation.

**Note:** Referenced throughout `Process_Document.cs` for handling offset values during PDF processing. Structure mirrors `Task_Image_Position.cs` but focuses on offset management across multiple pages.

---

### 4. Process_Document.cs

**Location:** `QXP/QXP.Engine.Core/Business/Task/Process_Document.cs`

**Purpose:** Contains the business logic for processing task type "Task_Document" - creates and configures image blocks.

```csharp
using System;

using QXPFrk	= QXP.Framework;
using QXPIO		= QXP.Framework.IO;

using QXPSMSDK	= com.quark.qxpsm;

namespace QXP.Engine.Core.Business
{
	/// <summary>
	/// Contains the business logic for processing task type "Task_Document"
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 17:50:15</date>    
	public class Process_Document
	{
		#region Members

		#endregion Members

		#region Constants
		const string PictureRotation90			= "90";

        const string SourceFileAbsoluPattern	= "{0}";
        const string SourceFileDocPoolPattern	= "file:{0}";

        const string PDFBlocNamePattern			= "{0}_{1}"; // 0=block prefix / 1=block number
        const string PDFPageNamePattern			= "P{0}_{1}"; // 0=page / 1=block name

		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructors

		#endregion Constructors

		#region Methods
        /// <summary>
        /// Creates blocks
        /// </summary>
        /// <param name="task">document type task</param>
		public static void Process(Task_Document task)
		{
			Bloc_Box	__blocBox	= null;
			TBox		__tBox;
            //Checks Task
            if (QXPFrk.Validation.IsNotSet(task.DestinationBlocName))
            {
                task.Run.Errors.Add(Constantes.Error_Messages.MissingBlocNameInTask, task.Debug_Info);
                return;
            }
            switch (task.Sub_Task_Type)
            {
                case Sub_Task_Type.File_IMG:
					//Get a copy of template element
					__tBox = TElement_Helper.Get_TElement(Static_TElement_Name.IMG, task.DestinationBlocName) as TBox;
					__tBox.SrcBox.content.value	= string.Format(SourceFileAbsoluPattern, task.Document.FileFullPath);
					if (task.Rotation_Image) __tBox.SrcBox.picture.angle = "90";
					__blocBox			= new Bloc_Box(task, task.DestinationBlocName, __tBox);
					break;
                case Sub_Task_Type.File_PDF:
					//Add 1 to N bloc_box !!
					Process_File_PDF(task);
                    break;
                case Sub_Task_Type.File_DOC:
                case Sub_Task_Type.File_RTF:
                case Sub_Task_Type.File_XTG:
					//Obtain a copy of template element
					__tBox = TElement_Helper.Get_TElement(Static_TElement_Name.RTF_DOC_XTG, task.DestinationBlocName) as TBox;
					__tBox.SrcBox.content.value	= string.Format(SourceFileDocPoolPattern, task.Document.FileFullPath);
					//if (task.Rotation_Image) __src_Element.SrcBox.picture.angle = "90";
					__blocBox			= new Bloc_Box(task, task.DestinationBlocName, __tBox);
                    break;
				case Sub_Task_Type.File_QXP_Data:
					Process_File_QXP_Data(task);
					break;
            }

			if(QXPFrk.Validation.IsNotNull(__blocBox))
			{
				task.Blocs_Modify.Add(__blocBox.Name, __blocBox);
			}
		}

		/// <summary>
		/// Special processing for retrieving information from old QXP files
		/// </summary>
		static void Process_File_QXP_Data(Task_Document task) 
		{ 
			//Source and Destination information must be defined to analyze info to transfer
			if(QXPFrk.Validation.IsSet(task.SourceBlocName) && QXPFrk.Validation.IsSet(task.DestinationBlocName))
			{ 
				Document __doc = task.Document;

				//Check if styles need to be preserved
				//If so, work on DOM (Project QXP) - launch exhaustive project analysis
				if(task.Conserver_Style) { 
					task.Document.QXPProject.Analyse(task, false);
				}
				else
				{
					// Create as many blocks as there are names in the task
					// Block names separated by '|'
					string[] __listSourceBoxName		= null;
					string[] __listDestinationBoxName	= null;
				
					__listSourceBoxName			= task.SourceBlocName.Split(new char[] { '|' });
					__listDestinationBoxName	= task.DestinationBlocName.Split(new char[] { '|' });

					if(__listSourceBoxName.Length == __listDestinationBoxName.Length)
					{
						Process_QXP_Previous.AddBlocs(task, __listSourceBoxName, __listDestinationBoxName);
					}
					else
					{
						task.Run.Errors.Add(Constantes.Error_Messages.ErrorSourceDestinationBoxNameDoesntMatch, task.Debug_Info);
					}
				}
			}
			
			if(task.Blocs_Modify.Count == 0 && task.Blocs_Update.Count == 0)
			{
				task.Run.Errors.Add(Constantes.Error_Messages.ErrorNothingBlocInTask, task.Debug_Info);
			}

		}

		/// <summary>
		/// Special processing for PDF files
		/// </summary>
		static void Process_File_PDF(Task_Document task)
		{
			if(task.Document.PDFFiles.Count == 0) return;
			
			Bloc_Box				__blocBox;
            Bloc_Page				__blocPage;
			QXPFrk.BaseList<string>	__lstBoxName	= task.Run.Gabarit.XML.GetListBoxNameStartWith(task.DestinationBlocName);
			Document				__doc			= task.Document;
			string					__blocName;
			QXPSMSDK.Box			__box;
			QXPSMSDK.Box			__extrabox;
			TBox					__tBox;
			QXPIO.PDF_File			__file;

			if(__lstBoxName.Count == 0)
			{
				task.Run.Errors.Add(Constantes.Error_Messages.MissingDestinationBlocNameInTask, task.DestinationBlocName, task.ID);
				return;
			}

			//If this number is negative: too many boxes. If positive: not enough boxes.
			//If zero: correct number of boxes
			int __nbPageManquante = (task.Document.PDFFiles.Count - __lstBoxName.Count);

			//Allows evaluation of image offsets to apply !!
			task.Image_Offset	= new Task_Image_Offset(task.Offset_Values);

			//Allows evaluation of new image block position
			task.Image_Position =  new Task_Image_Position(task.Position_Values);
			
			int __nbPageMaxRequis = Math.Max(task.Document.PDFFiles.Count, __lstBoxName.Count);

			for(int __i = 0 ; __i < __nbPageMaxRequis; __i++)
			{
				//If more boxes in document than in PDF list: remove boxes
				if(__i < __lstBoxName.Count && __i >= task.Document.PDFFiles.Count)
				{
					//Must remove pages
					__blocName					= string.Format(PDFBlocNamePattern, task.DestinationBlocName, __i + 1);
					__blocPage					= new Bloc_Page(task, __blocName);
					__blocPage.Relative_Page	= __i;
					task.Blocs_Modify.Add(__blocName, __blocPage);
				}
				else if(__i < task.Document.PDFFiles.Count)
				{
					//Must add image box for this PDF file
					string __tElementName		= __lstBoxName[__i];
					__file						= task.Document.PDFFiles[__i];
					__tBox						= TElement_Helper.Get_TElement(__tElementName, __blocName) as TBox;
					__tBox.SrcBox.content.value = __doc.GetPDFFileAbsolutePath(__file);
					__blocBox					= new Bloc_Box(task, __blocName, __tBox);
					__blocBox.Relative_Page		= __i;

					__box						= __blocBox.SrcBox;
					__extrabox					= __blocBox.SrcExtraBox;

					if (__i > 0)
					{
						__box.geometry.position.left	= task.Image_Position.Left;
						__box.geometry.position.top		= task.Image_Position.Top;
						__box.geometry.position.right	= task.Image_Position.Right;
						__box.geometry.position.bottom	= task.Image_Position.Bottom;					
					}
					
					//Apply PDF image rotation
					if(task.Rotation_Image)
					{
						//Handle rotation
						if(QXPFrk.Validation.IsNotNull(__tBox.SrcBox) && QXPFrk.Validation.IsNotNull(__tBox.SrcBox.picture))
						{
							__tBox.SrcBox.picture.angle				= PictureRotation90;
						}
						//Handle offset
						if(QXPFrk.Validation.IsNotNull(__extrabox) && QXPFrk.Validation.IsNotNull(__extrabox.picture))
						{
							__extrabox.picture.offsetAcross = task.Image_Offset.GetOffset(__i);
						}
					}

					task.Blocs_Modify.Add(__blocBox.Name, __blocBox);
				}
			}
		}

		#endregion Methods

		#region Properties

		#endregion Properties
	}
}
```

---

### 5. Process_QXP_Previous.cs

**Location:** `QXP/QXP.Engine.Core/Business/Task/Process_QXP_Previous.cs`

**Purpose:** Contains the business logic for processing task type "Task_QXP_Previous" - extracts and processes image/content data from previous QXP documents.

```csharp
using System;
using System.Collections.Generic;

using QXPFrk = QXP.Framework;

using QXPSMSDK	= com.quark.qxpsm;

namespace QXP.Engine.Core.Business
{
	/// <summary>
	/// Contains the business logic for processing task type "Task_QXP_Previous"
	/// </summary>
	/// <author>doufarm</author>
	/// <date>23/03/2010 17:50:15</date>    
	public class Process_QXP_Previous
	{
		#region Members

		#endregion Members

		#region Constants

		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructors

		#endregion Constructors

		#region Methods
        /// <summary>
        /// Adds to given task the blocks calculated from the hierarchy of source blocks passed as parameter
        /// </summary>
        /// <param name="task">task to populate</param>
        /// <param name="boxesSourcesNamesByLevels">hierarchy of source blocks sorted by increasing level</param>
        private static void AddBlocs(Task_QXP_Previous task, SortedDictionary<int, QXPFrk.BaseList<string>> boxesSourcesNamesByLevels)
        {
            /*...*/
                            // Quark doesn't handle empty strings, causes save error
                            // Must replace with NullString defined --> default: " "
                            if (QXPFrk.Validation.IsNotSet(__value))
                            {
                                __value = task.NullString;
                            }
                            // Create destination block from source box value 
                            __bloc = new Bloc_Box(task, __destBoxName, __value);
                            __bloc.Action	= Bloc_Action.UPDATE;
                            task.Blocs_Update.Add(__destBoxName, __bloc);
                        }
                    }
                    catch
                    {
                        task.Run.Errors.Add(Constantes.Error_Messages.ErrorAddingBlocInTask, task.Debug_Info, __sourceBoxName, __destBoxName);
                    }
                }
            }            
        }

		/// <summary>
		/// Adds blocks to task from source and destination block name arrays
		/// </summary>
		/// <param name="task">task to populate</param>
		/// <param name="listSourceBoxName">array of source block names</param>
		/// <param name="listDestinationBoxName">array of destination block names</param>
		private static void AddBlocs(Task_QXP_Previous task, string[] listSourceBoxName, string[] listDestinationBoxName)
		{
			string		__sourceBoxName;
			string		__destBoxName;
			Bloc_Box	__bloc		= null;

			for(int __i=0; __i < listSourceBoxName.Length;__i++)
			{
                __sourceBoxName	=  listSourceBoxName[__i];
				__destBoxName	=  listDestinationBoxName[__i];
				
                if (task.Blocs_Update.ContainsKey(__destBoxName) || task.Blocs_Modify.ContainsKey(__destBoxName))
                {
                    // if destination block already in task >> error 
                    task.Run.Errors.Add(Constantes.Error_Messages.ErrorDuplicateBlocInTask, task.Debug_Info, __destBoxName);
                }
                else
                {
					//Retrieve value and style
					if(task.Conserver_Style)
					{
						//Source element exists
						if (task.Document.QXPProject.Elements.ContainsKey(__sourceBoxName))
						{
							TElement __tElement = task.Document.QXPProject.Elements[__sourceBoxName];

							if (__tElement is TBox)
							{
								AddBloc(task, (TBox)__tElement, __destBoxName);
							}
							else if (__tElement is TTable)
							{
								AddBloc(task, (TTable)__tElement, __destBoxName);
							}
							else
							{
								task.Run.Errors.Add(Constantes.Error_Messages.Invalid_TElement_Type, __sourceBoxName, task.Debug_Info);
							}
						}
						else
						{
							task.Run.Errors.Add(Constantes.Error_Messages.Missing_TElement, __sourceBoxName, task.Debug_Info);
						}
					}
					//Retrieve only the value
					else
					{
						// Create destination block from source box value 
						__bloc			= new Bloc_Box(task, __destBoxName, task.Document.XML.GetValue(__sourceBoxName));
						__bloc.Action	= Bloc_Action.UPDATE;
						task.Blocs_Update.Add(__destBoxName, __bloc);
					}
				}
			}
		}

		/// <summary>
		/// Adds TBox element as block
		/// </summary>
		/// <param name="task">task to populate</param>
		/// <param name="tBox">source TBox element with potential image content</param>
		/// <param name="newName">destination block name</param>
		private static void AddBloc(Task_QXP_Previous task, TBox tBox, string newName)
		{
			/*...implementation for TBox handling...*/
		}

		/// <summary>
		/// Adds TTable element as block
		/// </summary>
		/// <param name="task">task to populate</param>
		/// <param name="tTable">source TTable element</param>
		/// <param name="newName">destination block name</param>
		private static void AddBloc(Task_QXP_Previous task, TTable tTable, string newName)
		{
			/*...implementation for TTable handling...*/
		}

		#endregion Methods

		#region Properties

		#endregion Properties
	}
}
```

---

## Image Processing Flow

### Step-by-Step Process

```
1. Task Preparation (Task_Document.Prepare())
   ├── Determines sub-task type based on Format_Document
   ├── Sets ToLoad = true for image/PDF formats
   └── Returns task ready for execution

2. Task Execution (Task_Document.Execute())
   └── Calls Process_Document.Process(this)

3. Document Processing (Process_Document.Process())
   ├── Validates DestinationBlocName exists
   └── Routes to appropriate handler based on Sub_Task_Type:
       ├── File_IMG → Single image insertion
       ├── File_PDF → Multi-page PDF processing
       ├── File_DOC/RTF/XTG → Document container reference
       └── File_QXP_Data → Extract from previous QXP document

4. Block Creation (Bloc_Box creation)
   └── Adds block to task.Blocs_Modify for later rendering
```

---

## Image Block Creation

### 1. Image Files (JPG, GIF, EPS, TIF, TIFF)

```csharp
// Get template box for images
TBox __tBox = TElement_Helper.Get_TElement(Static_TElement_Name.IMG, task.DestinationBlocName) as TBox;

// Set file path
__tBox.SrcBox.content.value = string.Format(SourceFileAbsoluPattern, task.Document.FileFullPath);

// Apply rotation if needed
if (task.Rotation_Image) __tBox.SrcBox.picture.angle = "90";

// Create block
Bloc_Box __blocBox = new Bloc_Box(task, task.DestinationBlocName, __tBox);

// Add to task
task.Blocs_Modify.Add(__blocBox.Name, __blocBox);
```

**File Path Pattern:** `{absolute_file_path}`

---

### 2. PDF Files (Multi-Page)

```csharp
// Initialize offset and position helpers
task.Image_Offset = new Task_Image_Offset(task.Offset_Values);
task.Image_Position = new Task_Image_Position(task.Position_Values);

// Loop through each PDF page
for(int __i = 0 ; __i < __nbPageMaxRequis; __i++)
{
    // Get template box
    TBox __tBox = TElement_Helper.Get_TElement(__tElementName, __blocName) as TBox;
    
    // Set PDF file path
    __tBox.SrcBox.content.value = __doc.GetPDFFileAbsolutePath(__file);
    
    // Create block with page reference
    Bloc_Box __blocBox = new Bloc_Box(task, __blocName, __tBox);
    __blocBox.Relative_Page = __i;
    
    // Apply position for pages after first
    if (__i > 0)
    {
        __box.geometry.position.left = task.Image_Position.Left;
        __box.geometry.position.top = task.Image_Position.Top;
        __box.geometry.position.right = task.Image_Position.Right;
        __box.geometry.position.bottom = task.Image_Position.Bottom;
    }
    
    // Apply rotation and offset if enabled
    if(task.Rotation_Image)
    {
        __tBox.SrcBox.picture.angle = "90";
        __extrabox.picture.offsetAcross = task.Image_Offset.GetOffset(__i);
    }
    
    // Add to task
    task.Blocs_Modify.Add(__blocBox.Name, __blocBox);
}
```

**Key Attributes:**
- `__blocName` = Formatted as `{prefix}_{page_number}` (e.g., "IMG_1", "IMG_2")
- `Relative_Page` = Page index for tracking
- Multi-page support with independent positioning per page

---

### 3. Document Files (DOC, RTF, XTG)

```csharp
// Get template box for documents
TBox __tBox = TElement_Helper.Get_TElement(Static_TElement_Name.RTF_DOC_XTG, task.DestinationBlocName) as TBox;

// Set file pool path (file: prefix)
__tBox.SrcBox.content.value = string.Format(SourceFileDocPoolPattern, task.Document.FileFullPath);
// Results in: "file:{file_path}"

// Create block
Bloc_Box __blocBox = new Bloc_Box(task, task.DestinationBlocName, __tBox);

// Add to task
task.Blocs_Modify.Add(__blocBox.Name, __blocBox);
```

**File Path Pattern:** `file:{file_path}`

---

### 4. QXP Data Files (Content from Previous Documents)

```csharp
// Check if styles should be preserved
if(task.Conserver_Style) { 
    // Full DOM analysis for style preservation
    task.Document.QXPProject.Analyse(task, false);
}
else
{
    // Split source/destination block names by pipe delimiter
    string[] __listSourceBoxName = task.SourceBlocName.Split(new char[] { '|' });
    string[] __listDestinationBoxName = task.DestinationBlocName.Split(new char[] { '|' });
    
    // Extract and create blocks
    if(__listSourceBoxName.Length == __listDestinationBoxName.Length)
    {
        Process_QXP_Previous.AddBlocs(task, __listSourceBoxName, __listDestinationBoxName);
    }
}
```

**Block Creation in AddBlocs:**
```csharp
// Simple value copy without styles
Bloc_Box __bloc = new Bloc_Box(task, __destBoxName, task.Document.XML.GetValue(__sourceBoxName));
__bloc.Action = Bloc_Action.UPDATE;
task.Blocs_Update.Add(__destBoxName, __bloc);

// Or with style preservation
TElement __tElement = task.Document.QXPProject.Elements[__sourceBoxName];
if (__tElement is TBox)
    AddBloc(task, (TBox)__tElement, __destBoxName);
else if (__tElement is TTable)
    AddBloc(task, (TTable)__tElement, __destBoxName);
```

---

## QuarkXPress SDK Integration

### QXPSMSDK Objects

| SDK Object | Property | Purpose | Example |
|------------|----------|---------|---------|
| `QXPSMSDK.Box` | `content.value` | File path to insert | `/path/to/image.jpg` |
| `QXPSMSDK.Box` | `picture.angle` | Rotation value | `"90"` (90 degrees) |
| `QXPSMSDK.Box` | `picture.offsetAcross` | Horizontal offset | Value from `Task_Image_Offset` |
| `QXPSMSDK.Box` | `geometry.position.left` | Left boundary | `"42"` |
| `QXPSMSDK.Box` | `geometry.position.top` | Top boundary | `"52"` |
| `QXPSMSDK.Box` | `geometry.position.right` | Right boundary | `"552"` |
| `QXPSMSDK.Box` | `geometry.position.bottom` | Bottom boundary | `"756"` |

### Access Patterns

```csharp
// Access main box
QXPSMSDK.Box __box = __blocBox.SrcBox;

// Access extra/duplicate box
QXPSMSDK.Box __extrabox = __blocBox.SrcExtraBox;

// Set content reference
__box.content.value = filePath;

// Apply picture transformations
if(__box.picture != null)
{
    __box.picture.angle = "90";
    __box.picture.offsetAcross = offsetValue;
}

// Set positioning
__box.geometry.position.left = positionObj.Left;
__box.geometry.position.top = positionObj.Top;
__box.geometry.position.right = positionObj.Right;
__box.geometry.position.bottom = positionObj.Bottom;
```

---

## Supported Image Formats

### File Type Categories

#### Raster Images (Sub_Task_Type.File_IMG)
| Format | Extension | Behavior |
|--------|-----------|----------|
| JPEG | `.jpg`, `.jpeg` | Single image insertion with optional 90° rotation |
| GIF | `.gif` | Single image insertion with optional rotation |
| Encapsulated PostScript | `.eps` | Single image insertion with optional rotation |
| TIFF | `.tif`, `.tiff` | Single image insertion with optional rotation |

**Processing:**
- Template element: `Static_TElement_Name.IMG`
- File path pattern: Absolute path
- Supports rotation via `picture.angle`

#### PDF Documents (Sub_Task_Type.File_PDF)
| Format | Extension | Behavior |
|--------|-----------|----------|
| PDF | `.pdf` | Multi-page support, one block per page |

**Processing:**
- Template element: Retrieved from box name list
- File path: Full path via `GetPDFFileAbsolutePath()`
- Features:
  - Page-specific positioning via `Task_Image_Position`
  - Rotation support with offset via `Task_Image_Offset`
  - Handles page count mismatches (add/remove blocks)
  - Multiple block creation based on PDF page count

#### Document Formats (Sub_Task_Type.File_DOC, File_RTF, File_XTG)
| Format | Extension | Behavior |
|--------|-----------|----------|
| Microsoft Word | `.doc` | Via file pool reference |
| Rich Text Format | `.rtf` | Via file pool reference |
| XTG (QuarkXPress Template) | `.xtg` | Via file pool reference |

**Processing:**
- Template element: `Static_TElement_Name.RTF_DOC_XTG`
- File path pattern: `file:{file_path}`
- File pool integration for server-side handling

#### QXP Data (Sub_Task_Type.File_QXP_Data)
**Processing:**
- Extracts content from previous QXP documents
- Optional style preservation via DOM analysis
- Source/destination block name mapping (pipe-delimited)
- Support for multiple block types: `TBox`, `TTable`

---

## Configuration Constants

### Image Positioning Defaults
```csharp
// Default position values (left, top, right, bottom)
public const string DefImagePositionValues = "42,52;56,693;552,756;785,197";
```

### File Path Patterns
```csharp
const string SourceFileAbsoluPattern = "{0}";              // Absolute path
const string SourceFileDocPoolPattern = "file:{0}";        // File pool reference
const string PDFBlocNamePattern = "{0}_{1}";               // Block naming
```

### Rotation
```csharp
const string PictureRotation90 = "90";                     // 90-degree rotation constant
```

---

## Key Classes Summary

### Relationships

```
Task_Document
├── Document (actual file data)
├── Task_Image_Offset (offset calculator)
├── Task_Image_Position (position calculator)
└── Execute() → Process_Document.Process()

Process_Document
├── Handles: IMG, PDF, DOC, RTF, XTG, QXP_Data
├── Creates: Bloc_Box objects
└── Uses: QXPSMSDK.Box for QuarkXPress integration

Process_QXP_Previous
├── Extracts from: TElement (TBox, TTable)
├── Creates: Bloc_Box with content
└── Actions: UPDATE or MODIFY
```

---

## Error Handling

**Common Error Messages:**
- `MissingBlocNameInTask` - DestinationBlocName not specified
- `MissingDestinationBlocNameInTask` - Block name not found in template
- `ErrorSourceDestinationBoxNameDoesntMatch` - Source/destination block arrays have different lengths
- `ErrorDuplicateBlocInTask` - Block already exists in task
- `Invalid_TElement_Type` - Element is not TBox or TTable
- `Missing_TElement` - Source element not found in QXP project
- `ErrorNothingBlocInTask` - No blocks created after processing

---

**Document Created:** May 29, 2026
**Last Updated:** May 29, 2026
**Author:** QXP Engine Development Team
**Reference:** IMAGE_TASK_PROCESSING_DOCUMENTATION.md
