# QXP Batch Service - Complete Beginner's Guide

**Document Version:** 1.0  
**Last Updated:** March 12, 2026  
**Target Audience:** Beginners (both application and technical)  
**Framework:** .NET Framework 4.6.1 (C#)  

---

## TABLE OF CONTENTS

1. [What is the Batch Service?](#what-is-the-batch-service)
2. [Why Do We Need It?](#why-do-we-need-it)
3. [High-Level Architecture](#high-level-architecture)
4. [Key Components](#key-components)
5. [How It Works - Step by Step](#how-it-works---step-by-step)
6. [Technical Stack & Dependencies](#technical-stack--dependencies)
7. [Configuration & Settings](#configuration--settings)
8. [Installation & Setup](#installation--setup)
9. [Operation & Monitoring](#operation--monitoring)
10. [Common Tasks](#common-tasks)
11. [Troubleshooting Guide](#troubleshooting-guide)
12. [FAQ](#faq)

---

## WHAT IS THE BATCH SERVICE?

### Simple Definition
The **QXP Batch Service** is a background application that automatically processes heavy, time-consuming tasks without requiring user interaction. Think of it as a helper that works in the background on your server.

### Real-World Analogy
Imagine a printing company:
- **Users** (Web Application): Submit print jobs through a website
- **Batch Service**: The actual printer that processes these jobs one by one
- **Results**: Completed documents ready for users to download

### In QXP Context
- **Users** submit "runs" (document generation requests) through the QXP web interface
- **Batch Service** picks up these requests and processes them
- **Output**: Generated documents (reports, PDFs, etc.)

---

## WHY DO WE NEED IT?

### Problem It Solves

| Problem | Solution |
|---------|----------|
| Users can't wait for long reports to generate | Batch processes them in background while users continue working |
| Multiple reports need processing | Batch processes several simultaneously (multi-threaded) |
| Reports crash the web application | Batch runs separately, web stays stable |
| Processing needs to happen at specific times | Batch has scheduling capability (planning/calendar) |
| User sessions timeout during long operations | Batch isn't affected by session timeouts |

### Business Value
✅ Better user experience (no waiting)  
✅ Increased server stability (heavy work offloaded)  
✅ Higher throughput (multiple documents processed together)  
✅ Scheduled automation (run reports at night, have results ready morning)  

---

## HIGH-LEVEL ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                    QXP Web Application                       │
│              (Users interact with this)                      │
└────────────────────┬────────────────────────────────────────┘
                     │
                     │ (User submits report request)
                     ▼
        ┌──────────────────────────┐
        │    Database (Oracle)     │
        │  (Stores pending tasks)  │
        └──────────────────────────┘
                     │
                     │ (Batch reads tasks)
                     ▼
┌─────────────────────────────────────────────────────────────┐
│          QXP BATCH SERVICE (Windows Service)                │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ Main Orchestrator (Watcher)                          │  │
│  │ - Monitors database for new tasks                    │  │
│  │ - Manages timing and scheduling                      │  │
│  │ - Keeps system running 24/7                          │  │
│  └──────────────────────────────────────────────────────┘  │
│                          │                                  │
│  ┌──────────┬──────────┬─┴─┬──────────┐                    │
│  │          │          │   │          │                    │
│  ▼          ▼          ▼   ▼          ▼                    │
│ ┌──┐      ┌──┐      ┌──┐┌──┐      ┌──┐                    │
│ │W1│      │W2│ ...  │WN││UP│ ...  │..│                    │
│ └──┘      └──┘      └──┘└──┘      └──┘                    │
│  Worker   Worker    Worker Upload   Checker               │
│ Thread 1  Thread 2  Thread N Manager Threads              │
│                                                            │
│ (Each thread processes one task at a time)                │
└─────────────────────────────────────────────────────────────┘
                     │
                     │ (Launches execution process)
                     ▼
        ┌──────────────────────────────┐
        │    QXP.Engine.exe            │
        │ (Actual report generator)    │
        └──────────────────────────────┘
                     │
                     ▼
        ┌──────────────────────────────┐
        │   QuarkXPress Server         │
        │   (Rendering engine)         │
        └──────────────────────────────┘
                     │
                     ▼
        ┌──────────────────────────────┐
        │  Generated Documents         │
        │  (PDFs, Reports, etc.)       │
        └──────────────────────────────┘
```

### Key Points from This Diagram

1. **Users interact with web** → They submit a report request
2. **Data stored in database** → Request waits in queue
3. **Batch Service runs** → Main orchestrator (Watcher) continuously monitors
4. **Multiple workers** → Processes multiple reports simultaneously (2+ threads by default)
5. **Launches Engine** → Each worker starts QXP.Engine.exe for actual processing
6. **Final output** → Documents generated and stored

---

## KEY COMPONENTS

### 1. **WATCHER** (The Brain)
**File:** `QXP.Batch.Core\BusinessObject\Watcher\Watcher.cs`

**What it does:**
- Starts the batch service
- Continuously monitors the database
- Checks for new tasks every 2 seconds (configurable)
- Manages all worker threads
- Handles graceful shutdown

**Analogy:** Like a supervisor in a factory checking if there's work to do

**Key Methods:**
```
Start()     → Service startup, initializes everything
Stop()      → Clean shutdown
Pause()     → Pause processing
Resume()    → Resume after pause
```

### 2. **WORKER THREADS** (The Laborers)
**File:** `QXP.Batch.Core\BusinessObject\Watcher\Worker_Thread.cs`

**What they do:**
- Process one task at a time
- Wait for tasks in a queue
- Launch the actual document generator (QXP.Engine.exe)
- Report completion back to database
- Default: 2 threads running simultaneously

**Analogy:** Like workers on an assembly line, each handling one item at a time

**Configuration:**
```
Number_Of_Threads = 2  → Run up to 2 documents in parallel
Worker_Thread_Wait_Seconds = 2  → Check for new work every 2 seconds
```

### 3. **RUN QUEUE** (The Task List)
**File:** `QXP.Batch.Core\BusinessObject\Watcher\Run_Queue.cs`

**What it does:**
- Holds tasks waiting to be processed
- Thread-safe (handles multiple threads accessing it)
- FIFO queue (First In, First Out - like a line at a bank)
- Prevents duplicate tasks

**Analogy:** Like a to-do list where items get checked off one by one

**How it works:**
```
Database → Watcher detects new task → Adds to Run_Queue
                                              ↓
Worker Thread 1 gets task #1 → processes it
Worker Thread 2 gets task #2 → processes simultaneously
(Both work at same time)
                                              ↓
Queue empty? → Threads wait for new tasks
```

### 4. **PLANNING ENGINE** (The Scheduler)
**File:** `QXP.Batch.Core\BusinessObject\Watcher\Watcher_Planning.cs`

**What it does:**
- Controls when batch processing happens
- Respects business hours
- Prevents processing outside allowed times

**Default Schedule:**
```
Monday - Friday:    06:00 to 23:59 (6 AM to 11:59 PM)
Saturday:           06:00 to 12:00 (6 AM to noon)
Sunday:             18:00 to 23:59 (6 PM to 11:59 PM)
```

**Analogy:** Like an office schedule - specifies when you can work

### 5. **UPLOAD MANAGER** (Document Handler)
**File:** `QXP.Batch.Core\Business\UploadManager.cs`

**What it does:**
- Checks for new documents to upload/import
- Validates documents
- Manages file handling
- Processes in stages to avoid crashes

**Process:**
```
1. Find new documents in upload pool
2. Validate each document
3. Process upload to database
4. Handle errors gracefully
```

### 6. **INTEROP SERVER** (Communication Hub)
**File:** `QXP.Batch.Core\BusinessObject\Interop\InteropServer.cs`

**What it does:**
- Provides WCF services (web services for communication)
- Allows web app to communicate with batch
- Two endpoints:
  - **Service endpoint**: Status monitoring (port 8751)
  - **ServiceCommand endpoint**: Send commands (port 8761)

**Analogy:** Like a telephone switchboard connecting different departments

### 7. **CONFIGURATION MANAGER** (Settings)
**File:** `QXP.Batch.Core\Configuration\BatchCoreSetting.cs`

**What it manages:**
- Number of worker threads
- Timeout values
- Logging settings
- Paths to external executables
- Upload pool directory

---

## HOW IT WORKS - STEP BY STEP

### The Complete Flow

#### **Phase 1: STARTUP (When Service Starts)**

```
1. Windows Service Manager starts QXP Batch service
   ↓
2. QXP_Batch_Program.Main() executes
   ↓
3. Check: Is "-debug" argument present?
   - YES: Run as console app (for testing)
   - NO: Run as Windows service (production)
   ↓
4. Load configuration from App.Config
   - Number of threads
   - Timeout values
   - Paths and settings
   ↓
5. Initialize database connections
   ↓
6. Start InteropServer (communication hub)
   - Starts WCF services on ports 8751, 8761
   ↓
7. Create N worker threads (default: 2)
   - Each thread waits for work
   ↓
8. Reset any failed runs in database
   - Handle previous interrupted operations
   ↓
9. Load initial pending tasks
   - Any reports waiting from before restart
   ↓
10. Watcher starts main loop (begins monitoring)
    - Service now ready
```

#### **Phase 2: CONTINUOUS OPERATION (Normal Running)**

```
WATCHER LOOP (Every 2 seconds):
┌─────────────────────────────────────┐
│ 1. Check if batch is paused         │
│    - If paused, wait and retry      │
├─────────────────────────────────────┤
│ 2. Check if currently allowed       │
│    (within working hours from       │
│     Watcher_Planning)               │
├─────────────────────────────────────┤
│ 3. Query database for new runs      │
│    - New tasks waiting to start     │
│    - Pending tasks to check status  │
├─────────────────────────────────────┤
│ 4. Add new runs to Run_Queue        │
├─────────────────────────────────────┤
│ 5. Notify worker threads            │
│    - Wake them up if sleeping       │
├─────────────────────────────────────┤
│ 6. Wait 2 seconds then repeat       │
└─────────────────────────────────────┘

WORKER THREAD LOOP (Each Thread):
┌─────────────────────────────────────┐
│ 1. Check if service shutting down   │
│    - If yes, exit thread            │
├─────────────────────────────────────┤
│ 2. Check if paused                  │
│    - If yes, wait and retry         │
├─────────────────────────────────────┤
│ 3. Get next task from Run_Queue     │
│    - (This is thread-safe)          │
├─────────────────────────────────────┤
│ 4. If task found:                   │
│    a. Launch QXP.Engine.exe         │
│    b. Pass task ID as argument      │
│    c. Wait for completion           │
│    d. Return to step 1              │
├─────────────────────────────────────┤
│ 5. If no task found:                │
│    a. Wait 2 seconds                │
│    b. Retry from step 1             │
└─────────────────────────────────────┘
```

#### **Phase 3: TASK EXECUTION (What Happens Per Task)**

```
USER ACTION:
├─ User fills out form in QXP web app
├─ Selects report type, parameters
└─ Clicks "Generate" button
   ↓
WEB APPLICATION:
├─ Validates input
├─ Creates database record with:
│  - Report type
│  - Parameters
│  - User who requested it
│  - Status = "Pending"
└─ Returns immediately to user
   ↓
WATCHER DETECTS:
├─ Queries database
├─ Finds pending task
├─ Adds to Run_Queue
└─ Notifies worker threads
   ↓
WORKER THREAD PROCESSES:
├─ Gets task from queue
├─ Updates database: Status = "Running"
├─ Launches QXP.Engine.exe <task_id>
│  (Process spawned as separate executable)
│
└─ Waits for completion (up to 10 minutes)
   ↓
QXP.ENGINE EXECUTION:
├─ Reads task parameters
├─ Queries database for data
├─ Launches QuarkXPress Server
├─ Renders document using template
├─ Generates PDF/output file
└─ Stores result in database
   ↓
ENGINE COMPLETION:
├─ Returns exit code (0 = success)
├─ Engine process terminates
└─ Back to worker thread
   ↓
WORKER THREAD CLEANUP:
├─ Checks exit code
├─ Updates database:
│  - If success: Status = "Completed"
│  - If failed: Status = "Error"
├─ Logs result
└─ Returns to queue for next task
   ↓
USER NOTIFICATION:
├─ User checks web app
├─ Sees status changed to "Completed"
└─ Downloads generated document
```

#### **Phase 4: UPLOAD HANDLING (Parallel Process)**

```
Happens WHILE tasks are being processed
(Separate from run generation)

CHECK_UPLOAD PROCESS (Periodically):
├─ Query database for new uploads
├─ Find files in upload pool directory
├─ For each upload:
│  ├─ Validate file
│  ├─ Import to database
│  ├─ Mark as processed
│  └─ Move to archive
└─ Log results

INDEPENDENT OPERATION:
- Upload checking doesn't block task processing
- Runs in same batch service but separate logic
```

#### **Phase 5: SHUTDOWN (Graceful Service Stop)**

```
SHUTDOWN INITIATED:
├─ Service receives stop command
├─ Watcher.End() called
├─ Exit flag set
└─ Main loop break next iteration
   ↓
WAIT FOR WORKERS:
├─ For each worker thread:
│  ├─ Signal thread to exit
│  ├─ Wait up to 60 seconds
│  └─ Verify termination
├─ If timeout: Force terminate
└─ Clean up resources
   ↓
CLEANUP:
├─ Close database connections
├─ Shutdown InteropServer
├─ Release locks
└─ Service stops
```

---

## TECHNICAL STACK & DEPENDENCIES

### Technologies Used

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Language | C# | Program written in C# |
| Framework | .NET Framework 4.6.1 | Runtime environment |
| Database | Oracle 12.1.0.2 | Store tasks and configuration |
| Web Service | WCF (Windows Communication Foundation) | Communicate with web app |
| Threading | System.Threading | Multi-threaded processing |
| Communication | .NET Remoting | Remote procedure calls |

### Architecture Pattern

```
Windows Service (Background Process)
    ↓
├─ Single Entry Point (Program.cs)
│  └─ Can run as Console OR Service
│
├─ Core Logic (QXP.Batch.Core)
│  ├─ Business Logic
│  │  └─ Watcher, Worker_Thread, Run_Queue
│  │
│  ├─ Data Access (Proxy)
│  │  ├─ RunProxy (reads/writes run data)
│  │  └─ DocumentProxy (handles document uploads)
│  │
│  ├─ Configuration
│  │  └─ BatchCoreSetting (loads from App.config)
│  │
│  ├─ Helpers
│  │  ├─ Trace_Helper (logging)
│  │  └─ Error_Helper (error handling)
│  │
│  └─ Communication (Interop)
│     ├─ Service (monitoring endpoint)
│     └─ ServiceCommand (command endpoint)
│
├─ Client/UI (QXP.Batch.Client)
│  └─ WPF application (admin interface)
│
└─ References
   ├─ QXP.Engine.Core (spawns QXP.Engine.exe)
   ├─ QXP.Framework (common utilities)
   └─ Oracle Data Provider for .NET
```

### Dependencies Explained

| Dependency | What It Is | Why Needed |
|-----------|-----------|-----------|
| QXP.Engine.Core | Library with engine functionality | Worker threads launch QXP.Engine.exe which uses this |
| QXP.Framework | Common utilities library | Logging, configuration, data conversion |
| Oracle Client | Database driver | Connect to Oracle database |
| System.ServiceProcess | .NET framework class | Register as Windows service |
| System.Threading | .NET framework class | Multi-threading support |
| WCF Services | .NET web services | Communication between web and batch |

---

## CONFIGURATION & SETTINGS

### Configuration File: `App.config`

Located at: `QXP.Batch.Core\App.config` (copied to deployment location)

### Core Settings Explained

```xml
<QXP.Batch.Core>
    <!-- LOGGING -->
    <add key="Display_Detail" value="False"/>
    <!-- Show detailed debug messages (slows down performance) -->
    
    <add key="Display_Info" value="True"/>
    <!-- Show informational messages (recommended: True) -->
    
    <!-- THREADING & PERFORMANCE -->
    <add key="Number_Of_Threads" value="2"/>
    <!-- How many tasks to process in parallel
         - Value of 2: Process 2 documents at same time
         - Higher = more resources used
         - Typical range: 1-4 (adjust based on server capacity) -->
    
    <add key="Worker_Thread_Wait_Seconds" value="2"/>
    <!-- How long worker thread waits before checking queue again
         - 2 seconds = Check every 2 seconds for new work
         - Lower = More responsive (uses more CPU)
         - Higher = Less responsive (uses less resources) -->
    
    <add key="Watcher_Wait_Seconds" value="2"/>
    <!-- How often main watcher checks database for new tasks
         - Same logic as Worker_Thread_Wait_Seconds -->
    
    <!-- TIMEOUTS -->
    <add key="Run_Execution_TimeOut_Seconds" value="600"/>
    <!-- Maximum time to wait for single document generation
         - 600 seconds = 10 minutes
         - If document takes longer, it's killed
         - For complex reports, increase this value -->
    
    <add key="ShutDown_TimeOut_Seconds" value="60"/>
    <!-- Maximum time to wait for worker threads to finish
         - When service stops, wait 60 seconds for current tasks
         - Then forcefully terminate -->
    
    <add key="Checker_Join_TimeOut_Seconds" value="30"/>
    <!-- Timeout for checker thread operations
         - Internal timing for checker threads -->
    
    <add key="Command_TimeOut" value="30"/>
    <!-- Timeout for command execution -->
    
    <!-- SCHEDULING -->
    <add key="Enabled_Watcher_Planning" value="True"/>
    <!-- Enable scheduling (respect working hours)
         - True: Only process during scheduled times
         - False: Process 24/7 -->
    
    <!-- PATHS & DIRECTORIES -->
    <add key="RunUploadPoolPath" value="C:\Documents\Upload\"/>
    <!-- Directory where upload files are stored
         - Must exist and be writable by service account
         - Service monitors this for new files -->
    
    <add key="Path_Run_Engine" value="...path to QXP.Engine.exe..."/>
    <!-- Full path to document generator executable
         - Used to launch actual report generation -->
    
    <add key="QXPServerLauncher" value="C:\Program Files\Quark\..."/>
    <!-- Path to QuarkXPress Server installation
         - Used by QXP.Engine for rendering -->
    
    <!-- UI OPTIONS -->
    <add key="Show_Run_Windows" value="False"/>
    <!-- Show console windows for launched processes
         - False: Hidden (cleaner, no UI popups)
         - True: Visible (useful for debugging) -->
    
    <add key="App_Prefixe" value="QXPB:"/>
    <!-- Prefix for logging messages
         - Used in trace output for identification -->
</QXP.Batch.Core>
```

### WCF Service Configuration

```xml
<system.serviceModel>
    <!-- Two services exposed for communication -->
    
    <!-- Service 1: Status Monitoring -->
    <service name="QXP.Batch.Core.Service">
        <endpoint address="http://localhost:8751/..." 
                  binding="wsDualHttpBinding" 
                  contract="IService"/>
        <!-- Port 8751: Monitor batch status, get logs -->
    </service>
    
    <!-- Service 2: Command Execution -->
    <service name="QXP.Batch.Core.ServiceCommand">
        <endpoint address="http://localhost:8761/..." 
                  binding="wsHttpBinding" 
                  contract="IServiceCommand"/>
        <!-- Port 8761: Send commands (pause, resume, etc.) -->
    </service>
</system.serviceModel>
```

### How to Modify Settings

**Step 1: Edit the config file**
- On UAT/Production: `C:\[Installation Path]\QXP.Batch.Core\App.config`
- On Development: `QXP.Batch.Core\App.config` in source code

**Step 2: Make changes** (example: increase threads)
```xml
<add key="Number_Of_Threads" value="2"/>
<!-- Change to: -->
<add key="Number_Of_Threads" value="4"/>
```

**Step 3: Restart service**
```powershell
# On server with the service
Stop-Service -Name "QXP_Batch_Program"
Start-Service -Name "QXP_Batch_Program"
```

**Step 4: Verify changes**
- Check logs to confirm new setting is loaded

---

## INSTALLATION & SETUP

### Prerequisites

- Windows Server 2012 R2 or later
- .NET Framework 4.6.1 installed
- Oracle Client 12.1.0.2+ installed
- QuarkXPress Server installed
- Administrative access to server
- 2+ GB free disk space

### Installation Steps

#### **Step 1: Build the Service**

In Visual Studio:

```
1. Open QXP.DEV_V3.5.sln
2. Build solution (Build → Build Solution)
3. Ensure QXP.Batch project builds successfully
4. Verify no errors in output
```

#### **Step 2: Prepare Installation Files**

```
Create deployment folder:
C:\QXPBatch\
  ├─ Assemblies\ (all .dll files)
  ├─ Config\
  │  └─ App.config
  ├─ QXP.Batch.exe
  └─ dependencies\ (Oracle client, etc.)
```

Copy from build output:
```
Source: QXP\QXP.Batch\bin\Release\
Files: *.exe, *.dll, App.config
Destination: C:\QXPBatch\
```

#### **Step 3: Install as Windows Service**

Open Command Prompt as Administrator:

```cmd
REM Navigate to batch folder
cd C:\QXPBatch\

REM Install service
QXP.Batch.exe install

REM Response: Service installed successfully

REM Verify installation
sc query QXP_Batch_Program
REM Should show: STATE: 1 (STOPPED)
```

#### **Step 4: Configure Service**

**Option A: Set Log On Account (Recommended)**

```
Services.msc → Right-click "QXP_Batch_Program" 
→ Properties → Log On tab → Set to:
- Local System
- OR Domain account with database rights
```

**Option B: Via PowerShell**

```powershell
# Set service to start automatically
Set-Service -Name "QXP_Batch_Program" -StartupType Automatic

# Set startup account to Local System
# (Usually default, but verify)
```

#### **Step 5: Start the Service**

```powershell
Start-Service -Name "QXP_Batch_Program"

# Wait 5 seconds for startup
Start-Sleep -Seconds 5

# Verify status
Get-Service -Name "QXP_Batch_Program" | Select-Object Status
# Should show: "Running"
```

#### **Step 6: Verify Installation**

```powershell
# Check service status
Get-Service QXP_Batch_Program

# Check for errors in Event Viewer
Get-EventLog -LogName Application -Source "QXP*" -Newest 10

# Verify WCF endpoints are listening
netstat -ano | findstr "8751 8761"
# Should show processes listening on these ports
```

### Uninstall Service

If needed to remove:

```powershell
# Stop service
Stop-Service -Name "QXP_Batch_Program"

# Uninstall
cd C:\QXPBatch\
QXP.Batch.exe uninstall

# Verify removal
sc query QXP_Batch_Program
# Should show: not found
```

---

## OPERATION & MONITORING

### Service Management

#### **Start Service**
```powershell
Start-Service -Name "QXP_Batch_Program"
```

#### **Stop Service**
```powershell
Stop-Service -Name "QXP_Batch_Program"

# Force stop after 30 seconds
Stop-Service -Name "QXP_Batch_Program" -Force
```

#### **Pause Processing**
```powershell
# Via PowerShell command (via WCF)
# Send pause command through service endpoint
```

#### **Resume Processing**
```powershell
# Via PowerShell command (via WCF)
# Send resume command through service endpoint
```

### Monitoring & Logging

#### **View Service Status**

```powershell
# Current status
Get-Service -Name "QXP_Batch_Program" | 
  Select-Object Name, Status, StartType

# Output example:
# Name                    Status StartType
# ----                    ------ ---------
# QXP_Batch_Program       Running Automatic
```

#### **View Logs**

Application logs stored in:
- **Windows Event Viewer**: `Event Viewer → Windows Logs → Application`
- **File logs**: `[Installation Path]\Logs\` (if configured)

Search for entries with Source: "QXP_Batch_Program"

#### **Monitor Performance**

```powershell
# Check thread count
Get-Process | Where-Object {$_.ProcessName -like "*Batch*"} |
  Select-Object ProcessName, Handles, Threads

# Check memory usage
Get-Process | Where-Object {$_.ProcessName -like "*Batch*"} |
  Select-Object ProcessName, WorkingSet
```

#### **View Queue Status**

Using QXP.Batch.Client (admin UI):
1. Launch QXP.Batch.Client
2. Connect to server: `localhost:8751`
3. View:
   - Current queue size
   - Running tasks
   - Thread status
   - Recent logs

#### **Database Monitoring**

Query database for pending tasks:

```sql
SELECT COUNT(*) as PendingTasks
FROM Run
WHERE Status = 'Pending'
  AND CreatedDate > SYSDATE - 1;

-- View task details
SELECT ID_Run, Status, CreatedDate, RequestedBy
FROM Run
WHERE Status IN ('Pending', 'Running')
ORDER BY CreatedDate;
```

### Health Checks

Perform these checks regularly:

```powershell
# 1. Service running?
Get-Service QXP_Batch_Program | Select-Object Status

# 2. WCF endpoints listening?
netstat -ano | findstr "8751"

# 3. Worker threads active?
Get-Process | Where-Object {$_.Name -like "QXP*"}

# 4. Recent errors in event log?
Get-EventLog -LogName Application -Newest 5 |
  Where-Object {$_.EntryType -eq "Error"} |
  Select-Object TimeGenerated, Source, Message

# 5. Database connectivity?
# (Run SQL query to count pending tasks)
```

---

## COMMON TASKS

### Task 1: Increase Worker Threads

**Scenario:** Service is processing too slowly, CPU not maxed out

**Solution:**

1. Edit `App.config`:
```xml
<add key="Number_Of_Threads" value="2"/>
<!-- Change to: -->
<add key="Number_Of_Threads" value="4"/>
```

2. Restart service:
```powershell
Restart-Service -Name "QXP_Batch_Program"
```

3. Verify:
```powershell
# Should see 4 threads active
Get-Process | Where-Object {$_.ProcessName -like "QXP*"}
```

### Task 2: Extend Processing Timeout

**Scenario:** Complex reports taking more than 10 minutes, getting killed

**Solution:**

1. Edit `App.config`:
```xml
<add key="Run_Execution_TimeOut_Seconds" value="600"/>
<!-- Change to 1800 seconds (30 minutes): -->
<add key="Run_Execution_TimeOut_Seconds" value="1800"/>
```

2. Restart service
3. Test with complex report

### Task 3: Change Processing Schedule

**Scenario:** Need to disable night-time processing

**Solution:**

1. Edit `App.config`:
```xml
<add key="Enabled_Watcher_Planning" value="True"/>
<!-- Disable scheduling: -->
<add key="Enabled_Watcher_Planning" value="False"/>
```

2. Or modify `Watcher_Planning.cs` to adjust hours:
```csharp
// Current schedule:
const string week_StartTime = "06:00:00";      // 6 AM
const string week_EndTime   = "23:59:59";      // 11:59 PM

// Change to (e.g., office hours only):
const string week_StartTime = "08:00:00";      // 8 AM
const string week_EndTime   = "18:00:00";      // 6 PM

// Rebuild and redeploy
```

3. Restart service

### Task 4: Enable Debug Mode

**Scenario:** Troubleshooting issues, need verbose logging

**Solution:**

1. Edit `App.config`:
```xml
<add key="Display_Detail" value="False"/>
<!-- Enable detailed logging: -->
<add key="Display_Detail" value="True"/>

<add key="Display_Info" value="True"/>
<!-- Ensure info logging also on: -->
<add key="Display_Info" value="True"/>
```

2. Show process windows for debugging:
```xml
<add key="Show_Run_Windows" value="False"/>
<!-- Change to: -->
<add key="Show_Run_Windows" value="True"/>
```

3. Restart service

4. Run in console mode for testing:
```cmd
# Stop service first
net stop "QXP_Batch_Program"

# Run in console/debug mode
cd C:\QXPBatch\
QXP.Batch.exe -debug

# Observe console output, press Enter to exit
```

### Task 5: Clear Upload Pool

**Scenario:** Upload directory full, need cleanup

**Solution:**

```powershell
# Backup files first
Copy-Item "C:\Documents\Upload\*" "C:\Documents\Upload\Backup" -Recurse

# Remove files (after confirming they were processed)
Remove-Item "C:\Documents\Upload\*" -Force

# Verify
Get-ChildItem "C:\Documents\Upload\" | Measure-Object
# Should show count: 0
```

### Task 6: Restart Service During High Load

**Scenario:** Need to restart without losing pending tasks

**Solution:**

```powershell
# 1. Graceful stop (waits for current tasks)
Stop-Service -Name "QXP_Batch_Program"

# 2. Wait for cleanup (30-60 seconds)
Start-Sleep -Seconds 60

# 3. Restart
Start-Service -Name "QXP_Batch_Program"

# 4. Monitor startup logs
Get-EventLog -LogName Application -Source "QXP*" -Newest 10
```

**Note:** Pending tasks remain in database and resume automatically

---

## TROUBLESHOOTING GUIDE

### Problem 1: Service Won't Start

**Symptoms:**
- Service starts then stops immediately
- No error visible

**Diagnosis:**

```powershell
# Check event viewer for errors
Get-EventLog -LogName Application -Source "QXP*" -Newest 20

# Check service status
Get-Service QXP_Batch_Program

# Try running in console mode
cd C:\QXPBatch\
QXP.Batch.exe -debug
```

**Common Causes & Fixes:**

| Cause | Fix |
|-------|-----|
| Missing `App.config` | Verify file exists at deployment location |
| Missing dependencies (.dll files) | Copy all .dll from build output |
| Database connection failed | Test connection string, verify Oracle client installed |
| File permissions | Run service as account with admin rights |
| Port 8751/8761 already in use | Kill existing process: `netstat -ano \| findstr "8751"` |
| Corrupted installation | Uninstall and reinstall |

**Detailed Fix:**

```powershell
# 1. Stop service
Stop-Service QXP_Batch_Program

# 2. Verify critical files
Test-Path "C:\QXPBatch\QXP.Batch.exe"
Test-Path "C:\QXPBatch\QXP.Batch.Core.dll"
Test-Path "C:\QXPBatch\App.config"

# 3. Check permissions
# Right-click folder → Properties → Security → ensure service account has Full Control

# 4. Start in debug mode to see errors
cd C:\QXPBatch\
.\QXP.Batch.exe -debug

# 5. Read console output for error messages
```

### Problem 2: Tasks Stuck in "Pending" Status

**Symptoms:**
- New tasks show but don't process
- Queue appears empty to service

**Diagnosis:**

```powershell
# Check if service is running
Get-Service QXP_Batch_Program

# Check if paused
# (Would show in logs or admin UI)

# Verify database connection
# Try connecting from server to Oracle

# Check if planning/schedule disabled processing
```

**Common Causes & Fixes:**

| Cause | Fix |
|-------|-----|
| Service stopped/paused | Start or resume service |
| Outside scheduled hours | Check planning hours or disable |
| Database connection broken | Verify Oracle connectivity |
| Queue full or corrupted | Restart service |
| Worker threads crashed | Check logs, restart service |

**Fix:**

```powershell
# 1. Check current pending count
# (Via SQL query against database)

# 2. Restart service
Restart-Service -Name "QXP_Batch_Program"

# 3. Verify threads are active
Get-Process | Where-Object {$_.ProcessName -like "QXP*"} | 
  Select-Object Name, Threads

# 4. Monitor logs
Get-EventLog -LogName Application -Source "QXP*" -Newest 5
```

### Problem 3: Service Consuming High Memory

**Symptoms:**
- Memory usage keeps increasing
- Task manager shows high RAM for service

**Diagnosis:**

```powershell
# Check memory usage
Get-Process | Where-Object {$_.ProcessName -like "QXP*"} |
  Select-Object ProcessName, WorkingSet

# Check for memory leaks in logs
Get-EventLog -LogName Application | Select-Object Source, Message
```

**Common Causes & Fixes:**

| Cause | Fix |
|-------|-----|
| Too many threads | Reduce `Number_Of_Threads` setting |
| Memory leaks in Engine | Update QXP.Engine to latest version |
| Infinite loop/hang | Restart service, check logs |
| Upload files too large | Reduce file sizes or increase memory |

**Fix:**

```powershell
# 1. Reduce thread count temporarily
# Edit App.config:
# Number_Of_Threads: 2 → 1

# 2. Restart
Restart-Service -Name "QXP_Batch_Program"

# 3. Monitor memory
# After 1 hour: memory should stabilize

# 4. If still high: investigate logs
```

### Problem 4: Tasks Taking Too Long

**Symptoms:**
- Single task taking 30+ minutes
- Other tasks blocked

**Diagnosis:**

```powershell
# Check queue status
# (Via admin UI or database query)

# Check if task is really running
Get-Process | Where-Object {$_.Name -like "Engine*"}

# Check logs for slowness patterns
Get-EventLog -LogName Application -Source "QXP*"
```

**Common Causes & Fixes:**

| Cause | Fix |
|-------|-----|
| Complex report | Increase `Run_Execution_TimeOut_Seconds` |
| Database slow query | Optimize SQL, add indexes |
| Server resources maxed | Reduce threads or increase resources |
| Network latency | Check network, move closer to DB |

**Fix:**

```powershell
# 1. Increase timeout for this execution
# App.config:
# Run_Execution_TimeOut_Seconds: 600 → 1800 (30 minutes)

# 2. Alternatively, split complex report into smaller parts

# 3. Increase number of threads if server has capacity
```

### Problem 5: WCF Service Communication Fails

**Symptoms:**
- Admin UI can't connect: "Connection refused"
- Port 8751/8761 errors in logs

**Diagnosis:**

```powershell
# Check if ports are open
netstat -ano | findstr "8751"
netstat -ano | findstr "8761"

# If no output: ports not listening

# Check firewall
netsh advfirewall show allprofiles
```

**Common Causes & Fixes:**

| Cause | Fix |
|-------|-----|
| Service not started | Start service |
| Firewall blocking | Open ports 8751, 8761 in firewall |
| Port already in use | Find process using port, kill it |
| WCF service crashed | Restart batch service |

**Fix:**

```powershell
# 1. Enable firewall exceptions
netsh advfirewall firewall add rule name="QXP Batch" dir=in 
  action=allow protocol=tcp localport=8751,8761

# 2. Restart service
Restart-Service -Name "QXP_Batch_Program"

# 3. Verify ports
netstat -ano | findstr "8751"
```

### Problem 6: "Path to QXP.Engine.exe not found"

**Symptoms:**
- Tasks fail to launch
- Log: "Cannot start engine: path not found"

**Diagnosis:**

```powershell
# Check configured path
# (In App.config or logs)

# Verify path exists
Test-Path "D:\Git\Gallery\...\QXP.Engine.exe"
```

**Fix:**

1. Verify QXP.Engine.exe exists at configured path
2. If moved, update `App.config`:
```xml
<add key="Path_Run_Engine" 
     value="C:\Correct\Path\QXP.Engine.exe"/>
```
3. Restart service

### Problem 7: Database Connection Errors

**Symptoms:**
- "ORA-12514: TNS:listener does not currently know of service requested"
- Service starts but can't communicate with database

**Diagnosis:**

```powershell
# Check tnsnames.ora
Test-Path "C:\oracle\product\12.1.0.2\client_1\network\admin\tnsnames.ora"

# Test connection from command line
sqlplus username/password@DBNAME

# Check if Oracle listener running
# (On database server)
lsnrctl status
```

**Fix:**

1. Verify `tnsnames.ora` entry for database alias
2. Ensure Oracle client installed correctly
3. Verify database listener is running
4. Restart service after fixes

---

## FAQ

### Q1: Can the batch service process multiple documents at once?

**A:** Yes! By default, it uses 2 worker threads, allowing 2 documents to be processed simultaneously. You can increase this in configuration:

```xml
<add key="Number_Of_Threads" value="4"/>  <!-- Process 4 at once -->
```

**Consideration:** Each additional thread uses more server resources (CPU, memory).

---

### Q2: What happens if the service crashes?

**A:** 

1. Incomplete tasks stay in database as "Pending" or "Running"
2. Windows can be configured to auto-restart the service
3. When restarted, Watcher automatically resets failed runs
4. Processing continues normally

**Auto-restart configuration:**
```powershell
# Set service to auto-restart on crash
sc failure "QXP_Batch_Program" actions= restart/5000 reset= 86400

# 5000ms = wait 5 seconds before restart
# 86400 = reset counter daily
```

---

### Q3: Does the batch service process outside business hours?

**A:** Default is NO. It respects a schedule:
- **Mon-Fri:** 6 AM - 11:59 PM
- **Saturday:** 6 AM - 12 PM  
- **Sunday:** 6 PM - 11:59 PM

To disable:
```xml
<add key="Enabled_Watcher_Planning" value="False"/>  <!-- Process 24/7 -->
```

---

### Q4: What if a task takes too long?

**A:** After 10 minutes (default), the task is killed. To increase:

```xml
<add key="Run_Execution_TimeOut_Seconds" value="1800"/>  <!-- 30 minutes -->
```

Or set to unlimited:
```xml
<add key="Run_Execution_TimeOut_Seconds" value="0"/>  <!-- No limit -->
```

---

### Q5: Can I pause the batch service without stopping it?

**A:** Yes, through the admin UI (QXP.Batch.Client):
- Click "Pause": Current tasks finish, new ones wait
- Click "Resume": Processing continues

Behind the scenes:
```csharp
Watcher.Paused = true;   // Pause
Watcher.Paused = false;  // Resume
```

---

### Q6: How do I monitor batch service from a different server?

**A:** Use the admin client or connect via WCF:

```powershell
# From remote machine
$serviceUrl = "http://[batch-server]:8751/..."
$proxy = New-WebServiceProxy -Uri $serviceUrl

# Connect and query status
$proxy.GetStatus()
```

---

### Q7: What database tables does batch service use?

**Main tables:**
- **Run** - Document generation requests
- **Run_Status** - Tracks processing progress
- **Run_Log** - Logs of each task execution
- **Upload** - File upload records

The service reads/writes these tables but doesn't delete them (preserves history).

---

### Q8: Can I run multiple batch services on different servers?

**A:** Yes, in a multi-server setup:
- Each server runs its own batch service
- All read from same database
- Database prevents duplicate processing
- Each service processes different tasks
- Provides load distribution and redundancy

**Configuration:**
```xml
<!-- Both servers connect to central database -->
<connectionString>
    Data Source=CentralDB;User Id=sa;Password=...
</connectionString>
```

---

### Q9: How do I backup batch service logs?

**A:** Logs stored in:
- Windows Event Viewer (automatic backup)
- File logs (if configured)

**Backup command:**
```powershell
# Export logs to CSV
Get-EventLog -LogName Application | 
  Export-Csv -Path "C:\Backup\BatchLogs_$(Get-Date -Format 'yyyyMMdd').csv"
```

---

### Q10: What's the difference between Run Queue and Database Queue?

**A:**
- **Database Queue:** All pending tasks in database (permanent storage)
- **Run_Queue:** In-memory queue of tasks ready to process (temporary)

**Flow:**
```
Database (1000 pending) 
    ↓
Watcher fetches next 5-10
    ↓
Adds to Run_Queue
    ↓
Worker threads process from Queue
    ↓
When empty, fetch next batch from Database
```

---

## APPENDIX: Common Commands Reference

### Service Management

```powershell
# Start
Start-Service -Name "QXP_Batch_Program"

# Stop
Stop-Service -Name "QXP_Batch_Program"

# Restart
Restart-Service -Name "QXP_Batch_Program"

# Status
Get-Service -Name "QXP_Batch_Program"

# Configure auto-start
Set-Service -Name "QXP_Batch_Program" -StartupType Automatic

# Set startup account
Set-Service -Name "QXP_Batch_Program" -StartupType Automatic -UserName "NT AUTHORITY\SYSTEM"
```

### Monitoring

```powershell
# View recent events
Get-EventLog -LogName Application -Source "QXP*" -Newest 20

# View last 1 hour
Get-EventLog -LogName Application -After (Get-Date).AddHours(-1)

# Export to file
Get-EventLog -LogName Application -Source "QXP*" | 
  Export-Csv "C:\Temp\BatchLogs.csv"

# Check process
Get-Process | Where-Object {$_.ProcessName -like "*Batch*"}

# Check ports
netstat -ano | findstr "8751"
```

### Troubleshooting

```powershell
# Run in console/debug mode
cd C:\QXPBatch\
.\QXP.Batch.exe -debug

# Stop service
net stop "QXP_Batch_Program"

# Install service
.\QXP.Batch.exe install

# Uninstall service
.\QXP.Batch.exe uninstall

# Reinstall
.\QXP.Batch.exe uninstall
Start-Sleep -Seconds 5
.\QXP.Batch.exe install
```

---

## CONCLUSION

The **QXP Batch Service** is a robust, background processing system that enables:
- ✅ Automated document generation
- ✅ Background task processing
- ✅ Multi-threaded scalability
- ✅ Scheduled operations
- ✅ 24/7 reliability

By understanding its architecture and operation, you can:
- Configure it for your environment
- Monitor its health
- Troubleshoot issues
- Scale for performance
- Maintain reliable operations

**Key Takeaway:** Think of it as a "postal system" - users drop letters (requests) in a mailbox, and the batch service ensures they're processed and delivered efficiently.

---

## DOCUMENT REVISION HISTORY

| Version | Date | Changes | Author |
|---------|------|---------|--------|
| 1.0 | 2026-03-12 | Initial comprehensive guide | Documentation Team |

---

**For Technical Support:** Contact your system administrator or refer to application documentation.


