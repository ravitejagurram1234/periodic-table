# Spring Boot SQL Task Implementation - Complete Example

## Project Structure
```
spring-boot-sql-task/
├── src/main/java/com/example/sqltask/
│   ├── controller/
│   │   └── RunController.java
│   ├── service/
│   │   ├── RunService.java
│   │   ├── ProcessSqlService.java
│   │   ├── InParamsService.java
│   │   ├── DataTypeHelperService.java
│   │   └── DatabaseService.java
│   ├── entity/
│   │   ├── Run.java
│   │   ├── TaskSql.java
│   │   ├── BlocBox.java
│   │   ├── BlocLigne.java
│   │   ├── BlocTable.java
│   │   ├── TaskException.java
│   │   └── InParam.java
│   ├── dto/
│   │   ├── RunDto.java
│   │   ├── BlocDto.java
│   │   └── DataNameValue.java
│   ├── enum/
│   │   ├── DataType.java
│   │   ├── BlocAction.java
│   │   └── TaskExceptionType.java
│   ├── repository/
│   │   ├── RunRepository.java
│   │   ├── TaskSqlRepository.java
│   │   └── TaskExceptionRepository.java
│   ├── exception/
│   │   └── TaskExecutionException.java
│   └── Application.java
├── src/main/resources/
│   ├── application.properties
│   └── schema.sql
└── pom.xml
```

---

## 1. Entity Classes

### TaskSql.java
```java
package com.example.sqltask.entity;

import com.example.sqltask.enum.DataType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.*;

@Entity
@Table(name = "task_sql")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskSql {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "run_id")
    private Run run;
    
    @Column(name = "sql", columnDefinition = "TEXT")
    private String sql;
    
    @Column(name = "show_zero")
    private boolean showZero;
    
    @Column(name = "nb_decimal")
    private int nbDecimal;
    
    @Column(name = "decimal_significative")
    private boolean decimalSignificative;
    
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "data_type")
    private DataType dataType;
    
    @Column(name = "store_data")
    private boolean storeData;
    
    @Column(name = "null_string")
    private String nullString;
    
    @Column(name = "todo")
    private boolean todo;
    
    @Column(name = "commentaire")
    private String commentaire;
    
    // Transient collections (not persisted)
    @Transient
    private Map<String, BlocBox> blocsUpdate = new HashMap<>();
    
    @Transient
    private Map<String, Object> blocsModify = new HashMap<>();
    
    @Transient
    private List<DataNameValue> dataNamesValues = new ArrayList<>();
    
    @OneToMany(mappedBy = "taskSql", fetch = FetchType.LAZY)
    private List<TaskException> exceptions = new ArrayList<>();
    
    @Transient
    private String destinationBlocName;
}
```

### Run.java
```java
package com.example.sqltask.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.*;

@Entity
@Table(name = "run")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Run {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "run_number")
    private int runNumber;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "completed_at")
    private LocalDateTime completedAt;
    
    @OneToMany(mappedBy = "run", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<TaskSql> tasks = new ArrayList<>();
    
    @Transient
    private List<String> errors = new ArrayList<>();
    
    @Transient
    private Map<String, Object> properties = new HashMap<>();
    
    @Transient
    private Map<String, Object> inParams = new HashMap<>();
    
    public void addError(String error) {
        if (errors == null) errors = new ArrayList<>();
        errors.add(error);
    }
}
```

### BlocBox.java
```java
package com.example.sqltask.entity;

import com.example.sqltask.enum.BlocAction;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "bloc_box")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BlocBox {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id")
    private TaskSql task;
    
    @Column(name = "name")
    private String name;
    
    @Column(name = "value", columnDefinition = "TEXT")
    private String value;
    
    @Column(name = "description")
    private String description;
    
    @Column(name = "info")
    private String info;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "action")
    private BlocAction action;
    
    public BlocBox(TaskSql task, String name, String value) {
        this.task = task;
        this.name = name;
        this.value = value;
        this.action = BlocAction.UPDATE;
    }
}
```

### BlocLigne.java
```java
package com.example.sqltask.entity;

import com.example.sqltask.enum.BlocAction;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "bloc_ligne")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BlocLigne extends BlocBox {
    
    @Column(name = "table_name")
    private String tableName;
    
    @Column(name = "line_index")
    private int lineIndex;
    
    @Column(name = "condition_name")
    private String conditionName;
    
    public BlocLigne(TaskSql task, String name, String tableName, int lineIndex) {
        super(task, name, "");
        this.tableName = tableName;
        this.lineIndex = lineIndex;
        this.setAction(BlocAction.REMOVE);
    }
}
```

### BlocTable.java
```java
package com.example.sqltask.entity;

import com.example.sqltask.enum.BlocAction;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "bloc_table")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BlocTable extends BlocBox {
    
    @Column(name = "table_name")
    private String tableName;
    
    @Column(name = "condition_name")
    private String conditionName;
    
    public BlocTable(TaskSql task, String tableName) {
        super(task, tableName, "");
        this.tableName = tableName;
        this.setAction(BlocAction.REMOVE);
    }
}
```

### TaskException.java
```java
package com.example.sqltask.entity;

import com.example.sqltask.enum.TaskExceptionType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "task_exception")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskException {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id")
    private TaskSql taskSql;
    
    @Column(name = "name")
    private String name;
    
    @Column(name = "table_name")
    private String tableName;
    
    @Column(name = "index_lines", columnDefinition = "TEXT")
    private String indexLinesStr; // Stored as "1|2|3"
    
    @Enumerated(EnumType.STRING)
    @Column(name = "exception_type")
    private TaskExceptionType type;
    
    @Transient
    private int[] indexLines;
    
    public int[] getIndexLines() {
        if (indexLinesStr == null || indexLinesStr.isEmpty()) {
            return new int[0];
        }
        String[] parts = indexLinesStr.split("\\|");
        int[] result = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            result[i] = Integer.parseInt(parts[i]);
        }
        return result;
    }
}
```

### DataNameValue.java
```java
package com.example.sqltask.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DataNameValue {
    private String name;
    private String value;
    private String description;
    private String info;
}
```

---

## 2. Enum Classes

### DataType.java
```java
package com.example.sqltask.enum;

public enum DataType {
    UNSPECIFIED(0),
    TEXT(1),
    INTEGER(2),
    DECIMAL(3),
    DATE(4);
    
    private final int value;
    
    DataType(int value) {
        this.value = value;
    }
    
    public int getValue() {
        return value;
    }
    
    public static DataType fromValue(int value) {
        for (DataType type : DataType.values()) {
            if (type.value == value) {
                return type;
            }
        }
        return UNSPECIFIED;
    }
}
```

### BlocAction.java
```java
package com.example.sqltask.enum;

public enum BlocAction {
    UPDATE,
    REMOVE,
    MODIFY
}
```

### TaskExceptionType.java
```java
package com.example.sqltask.enum;

public enum TaskExceptionType {
    NONE,
    LINE,      // Remove specific lines
    TABLE      // Remove entire table
}
```

---

## 3. Service Classes

### ProcessSqlService.java (THE MAIN LOGIC)
```java
package com.example.sqltask.service;

import com.example.sqltask.entity.*;
import com.example.sqltask.enum.BlocAction;
import com.example.sqltask.enum.TaskExceptionType;
import com.example.sqltask.exception.TaskExecutionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@Service
@Slf4j
public class ProcessSqlService {
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Autowired
    private DataTypeHelperService dataTypeHelper;
    
    private static final String NAME_BLOC_COL = "NOM_BLOC";
    private static final String VALUE_BLOC_COL = "VALEUR_BLOC";
    private static final String DESCRIPTION_BLOC_COL = "DESCRIPTION_BLOC";
    private static final String INFO_BLOC_COL = "INFO_BLOC";
    private static final String N1_END = "N1";
    
    /**
     * Main SQL processing method - equivalent to Process_SQL.Process()
     */
    public void process(TaskSql task, Run run) {
        try {
            log.info("Processing SQL Task {}", task.getId());
            
            // Step 1: Clone parameters from Run.InParams
            Map<String, Object> parameters = new HashMap<>(run.getInParams());
            
            // Step 2: Execute query
            List<Map<String, Object>> resultSet = queryDatabase(task.getSql(), parameters);
            
            // Step 3: Process results
            if (!resultSet.isEmpty()) {
                addBlocs(task, run, resultSet);
            } else {
                log.info("No data returned for task {}", task.getId());
            }
            
            // Step 4: Check exceptions
            checkTaskException(task, run);
            
            log.info("SQL Task {} processed successfully. Blocs: {}, Modifications: {}",
                    task.getId(), task.getBlocs_Update().size(), task.getBlocs_Modify().size());
            
        } catch (SQLException e) {
            throw new TaskExecutionException("SQL execution failed for task " + task.getId(), e);
        }
    }
    
    /**
     * Execute SQL query with parameters
     */
    private List<Map<String, Object>> queryDatabase(String sql, Map<String, Object> parameters) 
            throws SQLException {
        try {
            List<Object> paramValues = new ArrayList<>(parameters.values());
            List<Map<String, Object>> result = jdbcTemplate.queryForList(
                sql,
                paramValues.toArray()
            );
            return result;
        } catch (Exception e) {
            log.error("Database query failed: {}", sql, e);
            throw new SQLException("Query execution failed", e);
        }
    }
    
    /**
     * Convert result set rows to Bloc objects - equivalent to AddBlocs()
     */
    private void addBlocs(TaskSql task, Run run, List<Map<String, Object>> resultSet) 
            throws SQLException {
        
        boolean integrateN1 = (boolean) run.getProperties().getOrDefault("integrate_n1", true);
        boolean storeData = task.isStoreData();
        
        for (Map<String, Object> row : resultSet) {
            try {
                // Extract block name
                String blocName = toString(row.get(NAME_BLOC_COL));
                if (blocName == null || blocName.isEmpty()) {
                    log.warn("Block name is empty, skipping row");
                    continue;
                }
                
                // Check N1 filtering
                if (!integrateN1 && blocName.endsWith(N1_END)) {
                    log.debug("Skipping N1 block: {}", blocName);
                    continue;
                }
                
                // Extract and format block value
                Object rawValue = row.get(VALUE_BLOC_COL);
                String blocValue = dataTypeHelper.outputToString(
                    rawValue,
                    task.getDataType(),
                    task.getNbDecimal(),
                    task.isShowZero(),
                    task.getNullString(),
                    task.isDecimalSignificative()
                );
                
                // Create block
                BlocBox bloc = new BlocBox(task, blocName, blocValue);
                bloc.setAction(BlocAction.UPDATE);
                
                // Set optional fields
                if (row.containsKey(DESCRIPTION_BLOC_COL)) {
                    bloc.setDescription(toString(row.get(DESCRIPTION_BLOC_COL)));
                }
                if (row.containsKey(INFO_BLOC_COL)) {
                    bloc.setInfo(toString(row.get(INFO_BLOC_COL)));
                }
                
                // Add to task's update collection
                if (!task.getBlocs_Update().containsKey(blocName)) {
                    task.getBlocs_Update().put(blocName, bloc);
                    log.debug("Added block: {} = {}", blocName, blocValue);
                    
                    // Store data if required
                    if (storeData) {
                        task.getDataNamesValues().add(
                            new DataNameValue(
                                blocName,
                                blocValue,
                                bloc.getDescription(),
                                bloc.getInfo()
                            )
                        );
                    }
                } else {
                    run.addError(String.format("Duplicate block in task: %s", blocName));
                }
                
            } catch (Exception e) {
                String blocName = toString(row.get(NAME_BLOC_COL));
                log.error("Error adding block: {}", blocName, e);
                run.addError(String.format("Error processing block %s: %s", blocName, e.getMessage()));
            }
        }
    }
    
    /**
     * Validate exception rules and create removal blocks - equivalent to CheckTaskException()
     */
    private void checkTaskException(TaskSql task, Run run) {
        if (task.getExceptions().isEmpty()) {
            return;
        }
        
        for (TaskException exception : task.getExceptions()) {
            try {
                // Get the condition block
                BlocBox conditionBloc = task.getBlocs_Update().get(exception.getName());
                
                // Check if condition is met (block is null/empty)
                boolean shouldProcess = (conditionBloc == null) ||
                                       (conditionBloc.getValue() == null) ||
                                       (conditionBloc.getValue().isEmpty());
                
                if (shouldProcess) {
                    log.debug("Exception condition met for: {}", exception.getName());
                    
                    // Create removal blocks based on exception type
                    if (exception.getType() == TaskExceptionType.LINE) {
                        // Remove specific lines
                        int[] lineIndices = exception.getIndexLines();
                        for (int lineIdx : lineIndices) {
                            String lineId = exception.getTableName() + "_" + lineIdx;
                            
                            BlocLigne removeLine = new BlocLigne(
                                task,
                                lineId,
                                exception.getTableName(),
                                lineIdx
                            );
                            removeLine.setConditionName(exception.getName());
                            task.getBlocs_Modify().put(lineId, removeLine);
                            
                            log.debug("Marked for removal: line {} in table {}",
                                    lineIdx, exception.getTableName());
                        }
                    } else if (exception.getType() == TaskExceptionType.TABLE) {
                        // Remove entire table
                        BlocTable removeTable = new BlocTable(task, exception.getTableName());
                        removeTable.setConditionName(exception.getName());
                        task.getBlocs_Modify().put(exception.getTableName(), removeTable);
                        
                        log.debug("Marked for removal: table {}", exception.getTableName());
                    }
                    
                    task.setDestinationBlocName(exception.getTableName());
                }
                
            } catch (Exception e) {
                log.error("Error processing exception: {}", exception.getName(), e);
                run.addError(String.format("Exception processing failed for %s: %s",
                        exception.getName(), e.getMessage()));
            }
        }
    }
    
    /**
     * Safe object to string conversion
     */
    private String toString(Object obj) {
        if (obj == null) return null;
        return obj.toString();
    }
}
```

### InParamsService.java
```java
package com.example.sqltask.service;

import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

@Service
public class InParamsService {
    
    private final Map<String, Object> parameters = new HashMap<>();
    
    public void addParameter(String name, Object value) {
        parameters.put(name, value);
    }
    
    public Object getParameter(String name) {
        return parameters.get(name);
    }
    
    public Map<String, Object> cloneParameters() {
        return new HashMap<>(parameters);
    }
    
    public void clear() {
        parameters.clear();
    }
    
    public void loadFromMap(Map<String, Object> paramMap) {
        parameters.clear();
        parameters.putAll(paramMap);
    }
}
```

### DataTypeHelperService.java
```java
package com.example.sqltask.service;

import com.example.sqltask.enum.DataType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
@Slf4j
public class DataTypeHelperService {
    
    private static final String DEFAULT_DATE_PATTERN = "dd/MM/yyyy";
    private static final String DEFAULT_DECIMAL_SEPARATOR = ".";
    private static final String DEFAULT_GROUP_SEPARATOR = ",";
    
    /**
     * Convert and format output value based on data type
     * Equivalent to Data_Type_Helper.OutputToString()
     */
    public String outputToString(
            Object value,
            DataType dataType,
            int nbDecimal,
            boolean showZero,
            String nullString,
            boolean significative) {
        
        // Handle null values
        if (value == null) {
            return nullString != null ? nullString : "";
        }
        
        try {
            switch (dataType) {
                case TEXT:
                    return value.toString();
                    
                case INTEGER:
                    return formatInteger(value, showZero, nullString);
                    
                case DECIMAL:
                    return formatDecimal(value, nbDecimal, showZero, significative, nullString);
                    
                case DATE:
                    return formatDate(value);
                    
                case UNSPECIFIED:
                default:
                    return value.toString();
            }
        } catch (Exception e) {
            log.error("Error formatting value: {} as type: {}", value, dataType, e);
            return value.toString();
        }
    }
    
    /**
     * Format integer values
     */
    private String formatInteger(Object value, boolean showZero, String nullString) {
        if (value instanceof Number) {
            long intValue = ((Number) value).longValue();
            if (intValue == 0 && !showZero) {
                return nullString != null ? nullString : "";
            }
            return String.format("%,d", intValue)
                    .replace(",", DEFAULT_GROUP_SEPARATOR);
        }
        return value.toString();
    }
    
    /**
     * Format decimal values with specified precision
     */
    private String formatDecimal(
            Object value,
            int nbDecimal,
            boolean showZero,
            boolean significative,
            String nullString) {
        
        if (!(value instanceof Number)) {
            return value.toString();
        }
        
        BigDecimal bd = new BigDecimal(((Number) value).doubleValue());
        
        // Check for zero
        if (bd.compareTo(BigDecimal.ZERO) == 0 && !showZero) {
            return nullString != null ? nullString : "";
        }
        
        // Round to specified decimal places
        bd = bd.setScale(nbDecimal, RoundingMode.HALF_UP);
        String result = bd.toPlainString();
        
        // Remove trailing zeros if not significant
        if (!significative && nbDecimal > 0) {
            result = result.replaceAll("0+$", "").replaceAll("\\.$", "");
        }
        
        // Replace decimal separator
        result = result.replace(".", DEFAULT_DECIMAL_SEPARATOR);
        
        // Add thousands separator
        String[] parts = result.split("\\.");
        parts[0] = String.format("%,d", (long) Double.parseDouble(parts[0]))
                .replace(",", DEFAULT_GROUP_SEPARATOR);
        
        return parts.length > 1 ? parts[0] + DEFAULT_DECIMAL_SEPARATOR + parts[1] : parts[0];
    }
    
    /**
     * Format date values
     */
    private String formatDate(Object value) {
        if (value instanceof Date) {
            SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_DATE_PATTERN);
            return sdf.format((Date) value);
        } else if (value instanceof java.sql.Date) {
            SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_DATE_PATTERN);
            return sdf.format(new Date(((java.sql.Date) value).getTime()));
        } else if (value instanceof Integer) {
            // Assume format: YYYYMMDD
            return formatDateFromInt((Integer) value);
        }
        return value.toString();
    }
    
    /**
     * Format date from integer (YYYYMMDD)
     */
    private String formatDateFromInt(int dateInt) {
        try {
            String dateStr = String.format("%08d", dateInt);
            int year = Integer.parseInt(dateStr.substring(0, 4));
            int month = Integer.parseInt(dateStr.substring(4, 6));
            int day = Integer.parseInt(dateStr.substring(6, 8));
            
            return String.format("%02d/%02d/%04d", day, month, year);
        } catch (Exception e) {
            log.error("Error formatting date from int: {}", dateInt, e);
            return String.valueOf(dateInt);
        }
    }
}
```

### RunService.java
```java
package com.example.sqltask.service;

import com.example.sqltask.entity.Run;
import com.example.sqltask.entity.TaskSql;
import com.example.sqltask.repository.RunRepository;
import com.example.sqltask.repository.TaskSqlRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class RunService {
    
    @Autowired
    private RunRepository runRepository;
    
    @Autowired
    private TaskSqlRepository taskSqlRepository;
    
    @Autowired
    private ProcessSqlService processSqlService;
    
    @Autowired
    private InParamsService inParamsService;
    
    /**
     * Load a run and execute all SQL tasks
     */
    @Transactional
    public Run loadAndProcessRun(Long runId) {
        log.info("Loading and processing run: {}", runId);
        
        Optional<Run> runOpt = runRepository.findById(runId);
        if (!runOpt.isPresent()) {
            throw new RuntimeException("Run not found: " + runId);
        }
        
        Run run = runOpt.get();
        run.setCreatedAt(LocalDateTime.now());
        
        try {
            // Load all SQL tasks for this run
            List<TaskSql> tasks = taskSqlRepository.findByRunId(runId);
            run.setTasks(tasks);
            
            log.info("Found {} tasks for run {}", tasks.size(), runId);
            
            // Process each SQL task
            for (TaskSql task : tasks) {
                if (task.isTodo()) {
                    log.info("Processing task: {}", task.getId());
                    processSqlService.process(task, run);
                }
            }
            
            run.setCompletedAt(LocalDateTime.now());
            return runRepository.save(run);
            
        } catch (Exception e) {
            log.error("Error processing run: {}", runId, e);
            run.addError("Run processing failed: " + e.getMessage());
            run.setCompletedAt(LocalDateTime.now());
            return runRepository.save(run);
        }
    }
    
    /**
     * Get run details
     */
    public Optional<Run> getRun(Long runId) {
        return runRepository.findById(runId);
    }
}
```

---

## 4. Controller

### RunController.java
```java
package com.example.sqltask.controller;

import com.example.sqltask.dto.RunDto;
import com.example.sqltask.entity.Run;
import com.example.sqltask.service.RunService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/run")
@Slf4j
public class RunController {
    
    @Autowired
    private RunService runService;
    
    /**
     * Execute SQL tasks for a run
     */
    @PostMapping("/{runId}/process")
    public ResponseEntity<?> processRun(@PathVariable Long runId) {
        log.info("Received request to process run: {}", runId);
        
        try {
            Run run = runService.loadAndProcessRun(runId);
            
            return ResponseEntity.ok(new RunDto(
                run.getId(),
                run.getRunNumber(),
                run.getTasks().size(),
                run.getErrors().size(),
                run.getErrors()
            ));
        } catch (Exception e) {
            log.error("Error processing run: {}", runId, e);
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }
    
    /**
     * Get run details
     */
    @GetMapping("/{runId}")
    public ResponseEntity<?> getRun(@PathVariable Long runId) {
        Optional<Run> run = runService.getRun(runId);
        
        if (run.isPresent()) {
            return ResponseEntity.ok(run.get());
        }
        
        return ResponseEntity.notFound().build();
    }
}
```

---

## 5. Repository Interfaces

### RunRepository.java
```java
package com.example.sqltask.repository;

import com.example.sqltask.entity.Run;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RunRepository extends JpaRepository<Run, Long> {
}
```

### TaskSqlRepository.java
```java
package com.example.sqltask.repository;

import com.example.sqltask.entity.TaskSql;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskSqlRepository extends JpaRepository<TaskSql, Long> {
    List<TaskSql> findByRunId(Long runId);
}
```

---

## 6. Configuration Files

### application.properties
```properties
# Database Configuration
spring.datasource.url=jdbc:postgresql://localhost:5432/sqltask_db
spring.datasource.username=postgres
spring.datasource.password=password
spring.datasource.driver-class-name=org.postgresql.Driver

# JPA/Hibernate Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=false
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect
spring.jpa.properties.hibernate.format_sql=true

# Logging
logging.level.com.example.sqltask=DEBUG
logging.level.org.hibernate=INFO

# Server Configuration
server.port=8080
server.servlet.context-path=/api
```

### pom.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.1.0</version>
        <relativePath/>
    </parent>
    
    <groupId>com.example</groupId>
    <artifactId>sql-task-processor</artifactId>
    <version>1.0.0</version>
    <name>SQL Task Processor</name>
    
    <properties>
        <java.version>17</java.version>
    </properties>
    
    <dependencies>
        <!-- Spring Boot -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        
        <!-- Database -->
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <scope>runtime</scope>
        </dependency>
        
        <!-- Lombok -->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        
        <!-- Testing -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
    
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

---

## 7. Usage Example

### Step 1: Create a Run
```bash
POST /api/run
{
  "runNumber": 1,
  "tasks": [...]
}
```

### Step 2: Add SQL Task
```java
TaskSql sqlTask = new TaskSql();
sqlTask.setSql("SELECT NOM_BLOC, VALEUR_BLOC FROM my_table WHERE id_run = ?");
sqlTask.setShowZero(false);
sqlTask.setNbDecimal(2);
sqlTask.setDataType(DataType.DECIMAL);
sqlTask.setStoreData(true);
sqlTask.setTodo(true);
```

### Step 3: Process Run
```bash
POST /api/run/1/process
```

### Step 4: Result
```json
{
  "runId": 1,
  "runNumber": 1,
  "taskCount": 5,
  "errorCount": 0,
  "errors": []
}
```

---

## Key Implementation Points

1. **Parameter Binding** → Uses JDBC PreparedStatement (prevents SQL injection)
2. **Result Handling** → JdbcTemplate.queryForList() returns List<Map<String, Object>>
3. **Data Formatting** → DataTypeHelperService handles all transformations
4. **Exception Handling** → Custom TaskExecutionException for error management
5. **Transactional Support** → @Transactional ensures data consistency
6. **Logging** → SLF4J with Logback for comprehensive tracking

This Spring Boot implementation mirrors the .NET solution exactly, providing the same SQL execution flow, data transformation, and exception handling!

