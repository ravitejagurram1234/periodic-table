# SQL Task Execution - Complete Reference Guide

## Executive Summary

The Task_SQL class in the .NET solution executes SQL queries to populate document blocks (boxes) with data. The process involves **7 key steps**:

1. **Load Parameters** → Get substitution values from InParams
2. **Execute Query** → Run SQL via database proxy
3. **Iterate Results** → Read rows from result set
4. **Format Data** → Transform values based on data type
5. **Create Blocks** → Create Bloc_Box objects for updates
6. **Store Data** → Optionally persist data
7. **Handle Exceptions** → Create removal blocks based on conditions

---

## Architecture Overview

### .NET Components (7 Required Classes)

```
1. Task_SQL
   └─ Configuration holder for SQL task
   └─ Contains: SQL string, data type, formatting options
   
2. Process_SQL
   └─ Main business logic executor
   └─ Coordinates all steps of SQL execution
   
3. InParams (Dictionary<string, InParam>)
   └─ Manages query substitution parameters
   └─ CloneParameters() → returns bound parameters
   
4. Proxy_Generic
   └─ Database access layer
   └─ GetReader(sql, parameters) → executes query, returns result set
   
5. OraDataReader
   └─ Result set iterator
   └─ HasRows → check for results
   └─ Read() → move to next row
   
6. Data_Type_Helper
   └─ Format/transform values
   └─ OutputToString(value, type, format) → formatted string
   
7. Bloc_Box, Bloc_Ligne, Bloc_Table
   └─ Result data transfer objects
   └─ Represent blocks/rows/tables to update or remove
```

### Spring Boot Components (Java Equivalents)

```
1. TaskSql (Entity)
   └─ JPA entity with same properties as .NET Task_SQL
   
2. ProcessSqlService (Business Logic Service)
   └─ Same logic as Process_SQL class
   └─ Uses JdbcTemplate instead of ODP.NET
   
3. InParamsService
   └─ Manages parameters with HashMap<String, Object>
   
4. DatabaseService / JdbcTemplate
   └─ Spring Data JDBC abstraction
   └─ queryForList() → List<Map<String, Object>>
   
5. ResultSet (java.sql.ResultSet)
   └─ JDBC result set iterator
   
6. DataTypeHelperService
   └─ Same logic as .NET helper
   └─ Uses BigDecimal, SimpleDateFormat
   
7. BlocBox, BlocLigne, BlocTable (JPA Entities)
   └─ Same as .NET objects
   └─ Persisted to database
```

---

## Step-by-Step Execution Flow

### .NET Flow
```
Run.Launch()
  └─ for each Task_SQL task:
     └─ task.Process()
        └─ Process_SQL.Process(task)
           ├─ parameters = task.Run.InParams.CloneParameters()
           ├─ reader = Proxy_Generic.GetReader(task.SQL, parameters)
           ├─ if (reader.HasRows)
           │  └─ AddBlocs(task, reader)
           │     └─ while (reader.Read())
           │        ├─ blocName = reader["NOM_BLOC"]
           │        ├─ blocValue = reader["VALEUR_BLOC"]
           │        ├─ blocValue = Data_Type_Helper.OutputToString(...)
           │        ├─ bloc = new Bloc_Box(task, name, value)
           │        └─ task.Blocs_Update[name] = bloc
           └─ Check_Task_Exception(task)
              └─ for each exception:
                 ├─ if condition_met:
                 ├─  create Bloc_Ligne or Bloc_Table
                 └─  task.Blocs_Modify[name] = bloc

Result:
  task.Blocs_Update filled   → Document blocks to update
  task.Blocs_Modify filled   → Document rows/tables to remove
```

### Spring Boot Flow
```
RunService.loadAndProcessRun(runId)
  ├─ load Run from database
  ├─ load all TaskSql for this run
  └─ for each TaskSql task:
     └─ processSqlService.process(task, run)
        ├─ parameters = run.getInParams()
        ├─ resultSet = jdbcTemplate.queryForList(sql, params)
        ├─ if (!resultSet.isEmpty())
        │  └─ addBlocs(task, run, resultSet)
        │     └─ for each Map<String, Object> row:
        │        ├─ blocName = row.get("NOM_BLOC")
        │        ├─ blocValue = row.get("VALEUR_BLOC")
        │        ├─ blocValue = dataTypeHelper.outputToString(...)
        │        ├─ bloc = new BlocBox(task, name, value)
        │        └─ task.getBlocs_Update().put(name, bloc)
        └─ checkTaskException(task, run)
           └─ for each TaskException exception:
              ├─ if condition_met:
              ├─  create BlocLigne or BlocTable
              └─  task.getBlocs_Modify().put(name, bloc)

Result:
  task.getBlocs_Update() filled   → Document blocks to update
  task.getBlocs_Modify() filled   → Document rows/tables to remove
```

---

## Required Classes Comparison

| Function | .NET | Spring Boot | Purpose |
|----------|------|------------|---------|
| Configuration | Task_SQL | TaskSql (Entity) | Hold SQL task config |
| Business Logic | Process_SQL | ProcessSqlService | Execute SQL & process results |
| Parameters | InParams | InParamsService | Manage query parameters |
| Database Access | Proxy_Generic | JdbcTemplate | Execute queries |
| Result Reader | OraDataReader | ResultSet | Iterate result rows |
| Data Formatting | Data_Type_Helper | DataTypeHelperService | Format/transform values |
| Result Objects | Bloc_Box | BlocBox (Entity) | Store block update data |
| | Bloc_Ligne | BlocLigne (Entity) | Store row removal data |
| | Bloc_Table | BlocTable (Entity) | Store table removal data |
| Orchestration | Run_Base | RunService | Coordinate execution |
| Error Handling | Exception_Base | TaskExecutionException | Handle errors |

---

## Critical Methods/Functions

### .NET Key Methods
1. **Task_SQL.Process()** → Entry point
2. **Process_SQL.Process()** → Main executor
3. **Process_SQL.AddBlocs()** → Convert rows to blocks
4. **Process_SQL.CheckTaskException()** → Validate exceptions
5. **Proxy_Generic.GetReader()** → Execute query
6. **Data_Type_Helper.OutputToString()** → Format value
7. **Run.InParams.CloneParameters()** → Get parameters

### Spring Boot Equivalent Methods
1. **TaskSql.getSQL()** → Entry point
2. **ProcessSqlService.process()** → Main executor
3. **ProcessSqlService.addBlocs()** → Convert rows to blocks
4. **ProcessSqlService.checkTaskException()** → Validate exceptions
5. **JdbcTemplate.queryForList()** → Execute query
6. **DataTypeHelperService.outputToString()** → Format value
7. **Run.getInParams()** → Get parameters

---

## Data Structures

### Input Parameters Example
```
Run.InParams = {
  "p_id_run": 123,
  "p_id_suivi": 456,
  "p_langue": "FR"
}
```

### SQL Query Example
```sql
SELECT 
  NOM_BLOC,           -- Block/box name in document
  VALEUR_BLOC,        -- Block value to insert
  DESCRIPTION_BLOC,   -- (optional) Block description
  INFO_BLOC           -- (optional) Additional info
FROM my_data_table
WHERE id_run = :p_id_run
  AND id_suivi = :p_id_suivi
  AND langue = :p_langue
```

### Result Set Example
```
NOM_BLOC      | VALEUR_BLOC | DESCRIPTION      | INFO
──────────────┼─────────────┼──────────────────┼─────
TOTAL_AMOUNT  | 1234.5623   | Invoice Total    | USD
TAX_AMOUNT    | 123.4562    | Tax              | VAT
INV_DATE      | 20240325    | Invoice Date     |
DESCRIPTION   | Invoice #1  | Description      |
```

### Transformed Output
```
After Data_Type_Helper formatting:

TOTAL_AMOUNT  → "1,234.56"      (DECIMAL type, 2 decimals)
TAX_AMOUNT    → "123.46"        (DECIMAL type, 2 decimals)
INV_DATE      → "25/03/2024"    (DATE type, dd/MM/yyyy format)
DESCRIPTION   → "Invoice #1"    (TEXT type, no transformation)
```

### Created Blocks
```
task.Blocs_Update = {
  "TOTAL_AMOUNT": BlocBox {
    name: "TOTAL_AMOUNT",
    value: "1,234.56",
    action: UPDATE,
    description: "Invoice Total",
    info: "USD"
  },
  "TAX_AMOUNT": BlocBox {
    name: "TAX_AMOUNT",
    value: "123.46",
    action: UPDATE,
    description: "Tax",
    info: "VAT"
  },
  ...
}
```

---

## Exception Handling Example

### Exception Definition
```
TaskException {
  name: "APPROVAL_BOX",           // Condition block name
  tableName: "APPROVAL_TABLE",    // Table to remove rows from
  type: TaskExceptionType.LINE,   // Remove specific lines
  indexLines: [1, 2, 3]           // Line indices to remove
}
```

### Evaluation
```
1. Get block "APPROVAL_BOX" from Blocs_Update
2. Check if block is null or empty
3. If YES:
   └─ Create Bloc_Ligne for each index:
      ├─ "APPROVAL_TABLE_1" → Bloc_Ligne {action: REMOVE}
      ├─ "APPROVAL_TABLE_2" → Bloc_Ligne {action: REMOVE}
      └─ "APPROVAL_TABLE_3" → Bloc_Ligne {action: REMOVE}
   └─ Add to task.Blocs_Modify
4. If NO: Skip exception
```

### Result
```
task.Blocs_Modify = {
  "APPROVAL_TABLE_1": BlocLigne {
    name: "APPROVAL_TABLE_1",
    tableName: "APPROVAL_TABLE",
    lineIndex: 1,
    action: REMOVE,
    conditionName: "APPROVAL_BOX"
  },
  ...
}
```

---

## Performance Considerations

### .NET
- Uses ODP.NET (Oracle Data Provider) for direct database access
- OraDataReader streams results efficiently
- Parameter binding prevents SQL injection
- Uses Dictionary collections for O(1) lookups

### Spring Boot
- Uses JDBC / JdbcTemplate (works with any RDBMS)
- queryForList() loads all results into memory
- PreparedStatement prevents SQL injection
- Uses HashMap for O(1) lookups
- Better for smaller result sets; stream for large ones

### Recommendations
1. **Limit Result Set Size** → Add WHERE clauses to filter data
2. **Use Pagination** → For very large result sets
3. **Index Columns** → Ensure NOM_BLOC and WHERE columns are indexed
4. **Connection Pooling** → Use HikariCP (Spring Boot default)
5. **Caching** → Cache parameter values if they don't change
6. **Batch Processing** → Process multiple runs in parallel

---

## Error Handling

### Common Errors

1. **SQL Syntax Error**
   ```
   Message: "SQL execution failed"
   Cause: Invalid SQL in Task_SQL.SQL
   Solution: Validate SQL syntax, check parameter names
   ```

2. **Missing Parameter**
   ```
   Message: "Parameter p_id_run not found"
   Cause: InParams doesn't have required parameter
   Solution: Ensure all parameters are loaded from Run
   ```

3. **Duplicate Block Name**
   ```
   Message: "Duplicate block: TOTAL_AMOUNT"
   Cause: SQL returns multiple rows with same NOM_BLOC
   Solution: Add DISTINCT or GROUP BY to SQL
   ```

4. **Column Not Found**
   ```
   Message: "Column NOM_BLOC not found"
   Cause: Result set doesn't have required columns
   Solution: Check SQL SELECT clause, rename columns
   ```

5. **Invalid Exception Bloc**
   ```
   Message: "Invalid condition block"
   Cause: Exception references non-existent block
   Solution: Ensure exception.name matches actual blocks
   ```

---

## Spring Boot Implementation Checklist

- [x] Create TaskSql entity and repository
- [x] Create TaskException entity
- [x] Create BlocBox, BlocLigne, BlocTable entities
- [x] Create ProcessSqlService with main logic
- [x] Create InParamsService for parameter management
- [x] Create DataTypeHelperService for formatting
- [x] Create RunService for orchestration
- [x] Create RunController for API endpoints
- [x] Configure database connection (application.properties)
- [x] Add JPA/Hibernate configuration
- [x] Add JDBC/JdbcTemplate configuration
- [x] Add logging configuration
- [x] Add exception handling
- [x] Add transactional support
- [ ] Add unit tests
- [ ] Add integration tests
- [ ] Add API documentation (Swagger)
- [ ] Add database migration scripts (Flyway)
- [ ] Add performance monitoring
- [ ] Deploy to production

---

## Database Schema (Spring Boot)

```sql
-- Run table
CREATE TABLE run (
    id BIGSERIAL PRIMARY KEY,
    run_number INT,
    created_at TIMESTAMP,
    completed_at TIMESTAMP
);

-- Task_SQL table
CREATE TABLE task_sql (
    id BIGSERIAL PRIMARY KEY,
    run_id BIGINT REFERENCES run(id),
    sql TEXT,
    show_zero BOOLEAN DEFAULT false,
    nb_decimal INT DEFAULT 0,
    decimal_significative BOOLEAN DEFAULT true,
    data_type INT,
    store_data BOOLEAN DEFAULT false,
    null_string VARCHAR(255),
    todo BOOLEAN DEFAULT true,
    commentaire TEXT
);

-- TaskException table
CREATE TABLE task_exception (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT REFERENCES task_sql(id),
    name VARCHAR(255),
    table_name VARCHAR(255),
    index_lines TEXT,
    exception_type VARCHAR(50)
);

-- BlocBox table
CREATE TABLE bloc_box (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT REFERENCES task_sql(id),
    name VARCHAR(255),
    value TEXT,
    description TEXT,
    info TEXT,
    action VARCHAR(50)
);

-- BlocLigne table
CREATE TABLE bloc_ligne (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT REFERENCES task_sql(id),
    name VARCHAR(255),
    value TEXT,
    description TEXT,
    info TEXT,
    action VARCHAR(50),
    table_name VARCHAR(255),
    line_index INT,
    condition_name VARCHAR(255)
);

-- BlocTable table
CREATE TABLE bloc_table (
    id BIGSERIAL PRIMARY KEY,
    task_id BIGINT REFERENCES task_sql(id),
    name VARCHAR(255),
    value TEXT,
    description TEXT,
    info TEXT,
    action VARCHAR(50),
    table_name VARCHAR(255),
    condition_name VARCHAR(255)
);
```

---

## Testing Strategy

### Unit Tests
```java
@Test
public void testProcessSqlWithValidData() { }

@Test
public void testDataTypeHelperFormats() { }

@Test
public void testExceptionHandling() { }

@Test
public void testParameterCloning() { }
```

### Integration Tests
```java
@Test
public void testFullProcessingFlow() { }

@Test
public void testDatabaseExecution() { }

@Test
public void testTransactionRollback() { }
```

### Performance Tests
```java
@Test
public void testLargeResultSet() { }

@Test
public void testConcurrentProcessing() { }
```

---

## Deployment Notes

1. **Database Migration** → Use Flyway for schema management
2. **Connection Pooling** → HikariCP is default, tune pool size
3. **Logging** → SLF4J + Logback for comprehensive logging
4. **Monitoring** → Add Spring Boot Actuator for health checks
5. **Error Tracking** → Integrate with error tracking (Sentry, etc.)
6. **Performance** → Monitor slow queries, optimize SQL
7. **Security** → Use parameterized queries (already done)
8. **Backup** → Regular database backups of results

---

## Summary

The SQL task execution in the .NET QXP system is a well-designed 7-step process:

1. **Configuration** (Task_SQL) → Holds task settings
2. **Execution** (Process_SQL) → Orchestrates all steps
3. **Parameters** (InParams) → Provides substitution values
4. **Database** (Proxy_Generic) → Accesses database
5. **Results** (OraDataReader) → Iterates result rows
6. **Formatting** (Data_Type_Helper) → Transforms values
7. **Storage** (Bloc objects) → Stores for document updates

For Spring Boot, implement the exact same logic using:
- **Entity Classes** for data persistence
- **Service Classes** for business logic
- **JdbcTemplate** for database access
- **Repository Classes** for data access
- **Controller Classes** for API endpoints

The complete implementation is provided in the attached Spring Boot example, which can be directly used as a starting point for your migration!

