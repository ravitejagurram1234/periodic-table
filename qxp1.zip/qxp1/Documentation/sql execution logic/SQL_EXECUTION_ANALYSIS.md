# SQL Execution Flow Analysis: .NET to Spring Boot

## Overview
The Task_SQL class executes SQL queries to fetch data that populates document elements (blocks/boxes) in a Quark document. The process involves parameter substitution, query execution, data transformation, and result handling.

---

## Current .NET SQL Execution Flow

### 1. **Entry Point: Task_SQL.Process()**
```csharp
public override void Process()
{
    Business.Process_SQL.Process(this);  // Delegates to Process_SQL class
}
```

The Task_SQL class itself is just a configuration container. The actual execution happens in Process_SQL.

### 2. **SQL Execution in Process_SQL.Process()**

```csharp
public static void Process(Task_SQL task)
{
    // Step 1: Clone parameters from the Run's InParams collection
    QXPDataOracle.OraParameter[] __parameters = task.Run.InParams.CloneParameters();

    // Step 2: Execute the query
    Proxy_Generic __proxy = new Proxy_Generic();
    using(QXPDataOracle.OraDataReader __reader = __proxy.GetReader(task.SQL, __parameters))
    {
        // Step 3: Check if results exist
        if(__reader.HasRows)
        {
            // Step 4: Process results
            AddBlocs(task, __reader);  // Convert rows to blocks
        }
        else
        {
            Trace_Helper.Log_Message("No data returned");
        }
    }
    
    // Step 5: Validate against exceptions
    Check_Task_Exception(task);
}
```

---

## Component Architecture

### Required Classes & Their Responsibilities

```
┌──────────────────────────────────────────────────────────────────┐
│                          Run / Task_SQL                           │
│                                                                   │
│  - SQL: The SQL query string                                     │
│  - Store_Data: Whether to store results                          │
│  - Data_Type: Output data type (int, decimal, string, etc)       │
│  - NbDecimal: Number of decimal places                           │
│  - ShowZero: Display zero values                                 │
│  - Exceptions: Conditional removal rules                         │
└──────────────────────┬───────────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────┐
        │   Process_SQL (Business)     │
        │                              │
        │ - Process()                  │
        │ - AddBlocs()                 │
        │ - Check_Task_Exception()     │
        └──────────────────────────────┘
                       │
         ┌─────────────┼─────────────┐
         ▼             ▼             ▼
   ┌─────────────┐ ┌──────────────┐ ┌────────────────────┐
   │ InParams    │ │ Proxy_Generic│ │ Data_Type_Helper   │
   │             │ │              │ │                    │
   │ - Parameters│ │ - GetReader()│ │ - OutputToString() │
   │ - Clone()   │ │              │ │ - Format data      │
   └─────────────┘ └──────────────┘ └────────────────────┘
         │             │                      │
         ▼             ▼                      ▼
   ┌─────────────┐ ┌──────────────┐ ┌────────────────────┐
   │ OraParameter│ │ OraDataReader│ │  Bloc_Box          │
   │             │ │              │ │  Bloc_Ligne        │
   │ Database    │ │ Database     │ │  Bloc_Table        │
   │ Parameters  │ │ Result Set   │ │  (Result Objects)  │
   └─────────────┘ └──────────────┘ └────────────────────┘
```

---

## Detailed Component Descriptions

### 1. **Task_SQL** (Configuration Container)
**File:** `Task_SQL.cs` (138 lines)

**Responsibility:** Store SQL task configuration

**Key Members:**
```csharp
string _sql;                          // The SQL query to execute
bool _showZero;                       // Show zero values
int _nbDecimal;                       // Decimal precision
bool _decimal_significative;          // Show trailing zeros
Data_Type _dataType;                  // Output data type
bool _store_data;                     // Store results in database
```

**Key Methods:**
```csharp
public override void Prepare()        // Sets sub_task_type = SQL
public override void Process()        // Calls Process_SQL.Process(this)
public override void PostProcess()    // Cleanup (if needed)
```

---

### 2. **Process_SQL** (Business Logic)
**File:** `Process_SQL.cs` (246 lines)

**Responsibility:** Execute SQL and convert results to blocks

**Algorithm:**
1. Clone parameters from Run.InParams
2. Execute query via Proxy_Generic.GetReader()
3. Iterate over result set (OraDataReader)
4. For each row:
   - Read NOM_BLOC (block name) column
   - Read VALEUR_BLOC (block value) column
   - Convert value using Data_Type_Helper
   - Create Bloc_Box object
   - Add to task.Blocs_Update collection
   - Optionally store data if Store_Data=true
5. Check Task_Exception rules and handle removals

**Key Methods:**
```csharp
public static void Process(Task_SQL task)
// Main execution method

private static void AddBlocs(Task_SQL task, OraDataReader reader)
// Converts rows to blocks and populates task.Blocs_Update

private static void Check_Task_Exception(Task_SQL task)
// Removes blocks/rows based on exception conditions
```

**Expected Result Set Structure:**
```sql
NOM_BLOC (required)          -- Block/box name in document
VALEUR_BLOC (required)       -- Block value to insert
DESCRIPTION_BLOC (optional)  -- Block description
INFO_BLOC (optional)         -- Additional info
```

---

### 3. **InParams** (Parameters Collection)
**File:** `InParams.cs`

**Responsibility:** Manage query parameters (substitution values)

**Inheritance:** `Dictionary<string, InParam>`

**Key Methods:**
```csharp
public OraParameter[] CloneParameters()
// Returns array of Oracle parameters for query execution
// These are substituted in the SQL query
```

**Usage Example:**
If SQL has `:p_id_run`, InParams contains the value for it.

---

### 4. **Proxy_Generic** (Database Access)
**File:** `Proxy_Generic.cs`

**Responsibility:** Execute SQL queries and return result sets

**Key Methods:**
```csharp
public OraDataReader GetReader(string sql, OraParameter[] parameters)
// Executes parametrized query
// Returns OraDataReader for iterating results
```

**Flow:**
1. Creates Oracle command with SQL
2. Adds parameters to command
3. Executes query
4. Returns reader for result iteration

---

### 5. **Data_Type_Helper** (Data Formatting)
**File:** `Data_Type_Helper.cs`

**Responsibility:** Convert/format database values to strings

**Key Methods:**
```csharp
public string OutputToString(
    object value,           // Raw database value
    Data_Type dataType,     // Target type
    int nbDecimal,          // Decimal places
    bool showZero,          // Show zero values
    string nullString,      // String for null values
    bool significative)     // Show trailing zeros
```

**Handles:**
- Type conversion (int, decimal, string, date, etc.)
- Number formatting (decimal places, thousands separator)
- Null value replacement
- Trailing zero handling

---

### 6. **Bloc_Box** (Result Object)
**File:** `Bloc_Box.cs`

**Responsibility:** Represent a single document block/box to update

**Key Members:**
```csharp
string Name;        // Block name in document
string Value;       // Value to insert
Bloc_Action Action; // UPDATE, REMOVE, etc.
```

**Created For Each Row:**
```csharp
__bloc = new Bloc_Box(task, __bloc_Name, __bloc_Value);
__bloc.Action = Bloc_Action.UPDATE;
task.Blocs_Update.Add(__bloc.Name, __bloc);
```

---

### 7. **Bloc_Ligne & Bloc_Table** (Exception Handling)
**Responsibility:** Represent table rows/tables to remove based on conditions

**Created When:**
- Exception condition is met (block is empty/null)
- Block exists in exceptions list
- Table row/table removal is needed

---

## Spring Boot Implementation Architecture

### Required Java Classes

```
┌──────────────────────────────────────────────────────────┐
│ 1. TaskSql                (Configuration/DTO)             │
│    - sql: String                                         │
│    - showZero: boolean                                   │
│    - nbDecimal: int                                      │
│    - dataType: DataType (ENUM)                           │
│    - storeData: boolean                                  │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│ 2. ProcessSqlService       (Business Logic)              │
│    - process(taskSql)                                    │
│    - addBlocs(taskSql, resultSet)                        │
│    - checkTaskException(taskSql)                         │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│ 3. InParamsService         (Parameter Management)        │
│    - cloneParameters()                                   │
│    - addParameter(name, value)                           │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│ 4. DatabaseProxyService    (Database Access)            │
│    - executeQuery(sql, parameters)                       │
│    - getResultSet()                                      │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│ 5. DataTypeHelperService   (Data Formatting)            │
│    - convertToString(value, dataType, format)            │
│    - formatNumber(value, decimals, showZero)             │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│ 6. BlocBox               (Result DTO)                    │
│    - name: String                                        │
│    - value: String                                       │
│    - action: BlocAction (ENUM)                           │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│ 7. BlocLigne & BlocTable (Exception DTOs)               │
│    - name: String                                        │
│    - action: BlocAction                                  │
│    - conditionName: String                               │
└──────────────────────────────────────────────────────────┘
```

---

## Spring Boot Implementation Code Templates

### 1. TaskSql Configuration Class
```java
@Entity
@Table(name = "TBL_TASK")
public class TaskSql {
    
    @Id
    private int id;
    
    @Column(name = "SQL")
    private String sql;
    
    @Column(name = "AFFICHER_ZERO")
    private boolean showZero;
    
    @Column(name = "NB_DECIMAL")
    private int nbDecimal;
    
    @Column(name = "DECIMAL_SIGNIFICATIVE")
    private boolean decimalSignificative;
    
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "OUTPUT_DATA_TYPE")
    private DataType dataType;
    
    @Column(name = "STORE_DATA")
    private boolean storeData;
    
    // Getters & Setters
}

public enum DataType {
    UNSPECIFIED(0),
    TEXT(1),
    INTEGER(2),
    DECIMAL(3),
    DATE(4);
    
    private int value;
    DataType(int value) { this.value = value; }
}
```

### 2. ProcessSqlService (Business Logic)
```java
@Service
public class ProcessSqlService {
    
    @Autowired
    private DatabaseProxyService databaseProxy;
    
    @Autowired
    private DataTypeHelperService dataTypeHelper;
    
    @Autowired
    private InParamsService inParams;
    
    public void process(TaskSql task, Run run) {
        try {
            // Step 1: Clone parameters
            Map<String, Object> parameters = inParams.cloneParameters();
            
            // Step 2: Execute query
            ResultSet resultSet = databaseProxy.executeQuery(task.getSql(), parameters);
            
            // Step 3: Process results
            if (resultSet.next()) {
                addBlocs(task, run, resultSet);
            } else {
                log.info("No data returned for task {}", task.getId());
            }
            
            // Step 4: Check exceptions
            checkTaskException(task, run);
            
        } catch (SQLException e) {
            throw new TaskExecutionException("SQL execution failed", e);
        }
    }
    
    private void addBlocs(TaskSql task, Run run, ResultSet rs) throws SQLException {
        
        // Constants
        String NAME_BLOC_COL = "NOM_BLOC";
        String VALUE_BLOC_COL = "VALEUR_BLOC";
        String DESCRIPTION_BLOC_COL = "DESCRIPTION_BLOC";
        String INFO_BLOC_COL = "INFO_BLOC";
        String N1_END = "N1";
        
        boolean integrateN1 = run.getProperties().isIntegrerN1();
        DataTypeHelper helper = new DataTypeHelper(run.getProperties());
        boolean storeData = task.isStoreData() && 
                           (run.getProperties().getStoreType() & StoreDataType.SQL) == StoreDataType.SQL;
        
        // Check if optional columns exist
        boolean hasDescriptionCol = columnExists(rs, DESCRIPTION_BLOC_COL);
        boolean hasInfoCol = columnExists(rs, INFO_BLOC_COL);
        
        // Iterate through result set
        do {
            String blocName = rs.getString(NAME_BLOC_COL);
            
            // Check N1 filtering
            if (integrateN1 || !blocName.endsWith(N1_END)) {
                
                // Convert value
                String blocValue = helper.outputToString(
                    rs.getObject(VALUE_BLOC_COL),
                    task.getDataType(),
                    task.getNbDecimal(),
                    task.isShowZero(),
                    task.getNullString(),
                    task.isDecimalSignificative()
                );
                
                // Create block
                BlocBox bloc = new BlocBox(task, blocName, blocValue);
                bloc.setAction(BlocAction.UPDATE);
                
                // Add optional fields
                if (hasDescriptionCol) {
                    bloc.setDescription(rs.getString(DESCRIPTION_BLOC_COL));
                }
                if (hasInfoCol) {
                    bloc.setInfo(rs.getString(INFO_BLOC_COL));
                }
                
                // Store in task
                if (!task.getBlocs_Update().containsKey(blocName)) {
                    task.getBlocs_Update().put(blocName, bloc);
                    
                    // Store data if required
                    if (storeData) {
                        task.getDataNamesValues().add(
                            blocName, 
                            blocValue, 
                            bloc.getDescription(), 
                            bloc.getInfo()
                        );
                    }
                } else {
                    run.getErrors().add("Duplicate block: " + blocName);
                }
            }
        } while (rs.next());
    }
    
    private void checkTaskException(TaskSql task, Run run) {
        // Validate exceptions and remove blocks/rows based on conditions
        for (TaskException exception : task.getExceptions().values()) {
            BlocBox conditionBloc = task.getBlocs_Update().get(exception.getName());
            boolean shouldProcess = (conditionBloc == null) || 
                                   (conditionBloc.getValue() == null) || 
                                   (conditionBloc.getValue().isEmpty());
            
            if (shouldProcess) {
                // Perform removal logic
                if (exception.getType() == TaskExceptionType.LINE) {
                    // Remove specific rows
                    for (int lineIdx : exception.getIndexLines()) {
                        String lineId = exception.getTableName() + "_" + lineIdx;
                        BlocLigne removeLine = new BlocLigne(task, lineId, exception.getTableName(), lineIdx);
                        removeLine.setAction(BlocAction.REMOVE);
                        task.getBlocs_Modify().put(lineId, removeLine);
                    }
                } else {
                    // Remove entire table
                    BlocTable removeTable = new BlocTable(task, exception.getTableName());
                    removeTable.setAction(BlocAction.REMOVE);
                    task.getBlocs_Modify().put(exception.getTableName(), removeTable);
                }
            }
        }
    }
    
    private boolean columnExists(ResultSet rs, String columnName) throws SQLException {
        try {
            rs.findColumn(columnName);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}
```

### 3. InParamsService
```java
@Service
public class InParamsService {
    
    private Map<String, Object> parameters = new HashMap<>();
    
    public void addParameter(String name, Object value) {
        parameters.put(name, value);
    }
    
    public Map<String, Object> cloneParameters() {
        return new HashMap<>(parameters);
    }
    
    public void clear() {
        parameters.clear();
    }
    
    public Object getParameter(String name) {
        return parameters.get(name);
    }
}
```

### 4. DatabaseProxyService
```java
@Service
public class DatabaseProxyService {
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    public ResultSet executeQuery(String sql, Map<String, Object> parameters) throws SQLException {
        // Using prepared statement to prevent SQL injection
        Connection conn = jdbcTemplate.getDataSource().getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        
        // Bind parameters
        int paramIndex = 1;
        for (Object value : parameters.values()) {
            stmt.setObject(paramIndex++, value);
        }
        
        return stmt.executeQuery();
    }
    
    // Alternative using Spring Data JPA
    public List<Map<String, Object>> queryForList(String sql, Map<String, Object> parameters) {
        return jdbcTemplate.queryForList(sql, parameters);
    }
}
```

### 5. DataTypeHelperService
```java
@Service
public class DataTypeHelperService {
    
    private DecimalFormat decimalFormat;
    private RunProperties runProperties;
    
    public DataTypeHelperService(RunProperties properties) {
        this.runProperties = properties;
        setupDecimalFormat();
    }
    
    public String outputToString(
            Object value,
            DataType dataType,
            int nbDecimal,
            boolean showZero,
            String nullString,
            boolean significative) {
        
        if (value == null) {
            return nullString;
        }
        
        switch (dataType) {
            case TEXT:
                return value.toString();
                
            case INTEGER:
                if (value instanceof Number) {
                    long intValue = ((Number) value).longValue();
                    return (intValue == 0 && !showZero) ? nullString : String.valueOf(intValue);
                }
                return value.toString();
                
            case DECIMAL:
                if (value instanceof Number) {
                    return formatDecimal((Number) value, nbDecimal, showZero, significative);
                }
                return value.toString();
                
            case DATE:
                if (value instanceof java.util.Date) {
                    return formatDate((java.util.Date) value);
                }
                return value.toString();
                
            default:
                return value.toString();
        }
    }
    
    private String formatDecimal(Number value, int nbDecimal, boolean showZero, boolean significative) {
        BigDecimal bd = new BigDecimal(value.doubleValue());
        
        if (bd.compareTo(BigDecimal.ZERO) == 0 && !showZero) {
            return "";
        }
        
        // Set decimal places
        bd = bd.setScale(nbDecimal, RoundingMode.HALF_UP);
        
        return bd.toPlainString();
    }
    
    private String formatDate(java.util.Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat(runProperties.getDatePattern());
        return sdf.format(date);
    }
    
    private void setupDecimalFormat() {
        decimalFormat = new DecimalFormat();
        decimalFormat.setDecimalSeparator(runProperties.getDecimalSeparator().charAt(0));
        decimalFormat.setGroupingUsed(true);
    }
}
```

### 6. BlocBox & Related Classes
```java
@Entity
@Table(name = "TBL_BLOC")
public class BlocBox {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @ManyToOne
    private TaskSql task;
    
    @Column(name = "NAME")
    private String name;
    
    @Column(name = "VALUE")
    private String value;
    
    @Column(name = "DESCRIPTION")
    private String description;
    
    @Column(name = "INFO")
    private String info;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "ACTION")
    private BlocAction action;
    
    public BlocBox() {}
    
    public BlocBox(TaskSql task, String name, String value) {
        this.task = task;
        this.name = name;
        this.value = value;
    }
    
    // Getters & Setters
}

public enum BlocAction {
    UPDATE,
    REMOVE,
    MODIFY
}

@Entity
@Table(name = "TBL_BLOC_LIGNE")
public class BlocLigne extends BlocBox {
    
    @Column(name = "TABLE_NAME")
    private String tableName;
    
    @Column(name = "LINE_INDEX")
    private int lineIndex;
    
    @Column(name = "CONDITION_NAME")
    private String conditionName;
    
    public BlocLigne() {}
    
    public BlocLigne(TaskSql task, String name, String tableName, int lineIndex) {
        super(task, name, "");
        this.tableName = tableName;
        this.lineIndex = lineIndex;
    }
}

@Entity
@Table(name = "TBL_BLOC_TABLE")
public class BlocTable extends BlocBox {
    
    @Column(name = "TABLE_NAME")
    private String tableName;
    
    @Column(name = "CONDITION_NAME")
    private String conditionName;
    
    public BlocTable() {}
    
    public BlocTable(TaskSql task, String tableName) {
        super(task, tableName, "");
        this.tableName = tableName;
    }
}
```

---

## Execution Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│ 1. Run.LaunchProcess()                                      │
│    - Iterates through tasks                                 │
│    - Calls task.Process()                                   │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. Task_SQL.Process()                                       │
│    - Delegates to Process_SQL.Process(this)                 │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. Process_SQL.Process()                                    │
│    a. Clone parameters from Run.InParams                    │
│    b. Call Proxy_Generic.GetReader(sql, parameters)         │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. Proxy_Generic.GetReader()                                │
│    - Execute parametrized SQL query                         │
│    - Return OraDataReader                                   │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. OraDataReader (Result Set)                               │
│    - Contains query results                                 │
│    - Columns: NOM_BLOC, VALEUR_BLOC, [optional columns]     │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. AddBlocs()                                               │
│    - Iterate through result set                             │
│    - For each row:                                          │
│      a. Extract NOM_BLOC (name)                             │
│      b. Extract VALEUR_BLOC (value)                         │
│      c. Format value using Data_Type_Helper                 │
│      d. Create Bloc_Box object                              │
│      e. Add to task.Blocs_Update                            │
│      f. Optionally store in DataNamesValues                 │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 7. Check_Task_Exception()                                   │
│    - Validate exception rules                               │
│    - Create Bloc_Ligne/Bloc_Table for removals              │
│    - Add to task.Blocs_Modify                               │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ 8. Task State Updated                                       │
│    task.Blocs_Update   → Document blocks to update          │
│    task.Blocs_Modify   → Document rows/tables to remove     │
│    task.DataNamesValues → Stored data (if Store_Data=true)  │
└─────────────────────────────────────────────────────────────┘
```

---

## Spring Boot Equivalent Execution Flow

```java
@RestController
@RequestMapping("/api/run")
public class RunController {
    
    @Autowired
    private RunService runService;
    
    @PostMapping("/{runId}/process")
    public ResponseEntity<?> processRun(@PathVariable int runId) {
        Run run = runService.loadRun(runId);
        
        // For each Task_SQL in run
        for (TaskSql sqlTask : run.getTasks()) {
            processSqlTask(sqlTask, run);
        }
        
        return ResponseEntity.ok("Run processed successfully");
    }
    
    private void processSqlTask(TaskSql sqlTask, Run run) {
        try {
            // Step 1: Initialize parameters
            InParamsService inParams = new InParamsService();
            // ... load parameters from run ...
            
            // Step 2: Execute SQL
            ProcessSqlService processor = new ProcessSqlService();
            processor.process(sqlTask, run);
            
            // Step 3: Blocs are now populated
            // task.getBlocs_Update()  → Ready for document update
            // task.getBlocs_Modify()  → Ready for removals
            
        } catch (TaskExecutionException e) {
            run.getErrors().add("SQL Task failed: " + e.getMessage());
        }
    }
}
```

---

## Key Differences: .NET vs Spring Boot

| Aspect | .NET | Spring Boot |
|--------|------|------------|
| **DB Framework** | Oracle.DataAccess (ODP.NET) | JDBC / JdbcTemplate |
| **Parameter Binding** | OracleParameter[] | PreparedStatement / Named params |
| **Result Reading** | OraDataReader | ResultSet |
| **Data Formatting** | Custom Data_Type_Helper | DecimalFormat, SimpleDateFormat |
| **Collections** | Dictionary<K,V> | HashMap<K,V> |
| **Exception Handling** | Custom exception classes | Spring exceptions |
| **Data Access Pattern** | Proxy pattern | DAO/Repository pattern |
| **Dependency Injection** | Custom IOC | Spring IoC (@Autowired) |

---

## Required Components Summary for Spring Boot

### Core Services (7 main classes needed):
1. **TaskSqlService** - Configuration/DTO
2. **ProcessSqlService** - Business logic
3. **InParamsService** - Parameter management
4. **DatabaseProxyService** - Database access
5. **DataTypeHelperService** - Data formatting
6. **BlocBoxService** - Result management
7. **RunService** - Orchestration

### Supporting Classes:
- **RunProperties** - Configuration
- **TaskException** - Exception definition
- **StoreDataType** - Enum for data storage types
- **DataType** - Enum for data types
- **BlocAction** - Enum for bloc actions

### Database Access:
- **JdbcTemplate** (Spring Data)
- **PreparedStatement** (JDBC)
- **ResultSet** (JDBC)

---

## Implementation Checklist for Spring Boot

- [ ] Create TaskSql entity and repository
- [ ] Create InParamsService with parameter management
- [ ] Create DatabaseProxyService with JDBC/JdbcTemplate
- [ ] Create DataTypeHelperService for formatting
- [ ] Create ProcessSqlService with main logic
- [ ] Create BlocBox, BlocLigne, BlocTable entities
- [ ] Create TaskException entity
- [ ] Create RunService for orchestration
- [ ] Set up parameterized queries (prevent SQL injection)
- [ ] Add logging and error handling
- [ ] Add transactional support
- [ ] Create unit tests
- [ ] Create integration tests with actual database

---

## Summary

The SQL execution in Task_SQL follows this pattern:

1. **Configuration** → Task_SQL holds the SQL query and settings
2. **Parameter Preparation** → InParams provides substitution values
3. **Query Execution** → Proxy_Generic executes the SQL
4. **Data Processing** → AddBlocs iterates results and creates Bloc objects
5. **Data Formatting** → Data_Type_Helper formats values based on data type
6. **Result Storage** → Blocs are stored in task.Blocs_Update
7. **Exception Handling** → Check_Task_Exception validates rules and creates removals

For Spring Boot, you need these 7 key services to replicate this functionality. The architecture remains the same: separation of concerns between configuration, business logic, data access, and formatting.

