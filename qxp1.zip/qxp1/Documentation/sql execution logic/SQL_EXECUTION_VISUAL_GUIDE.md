# SQL Task Execution - Visual Architecture Guide

## High-Level Execution Flow

```
USER REQUEST
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│ Run Lifecycle                                           │
│ (Run_Base.Launch())                                     │
└─────┬───────────────────────────────────────────────────┘
      │
      ├─→ Start()           │ Database entry
      ├─→ Load()            │ Load run properties & tasks
      ├─→ Prepare()         │ Prepare all tasks
      ├─→ Process()         │ ← EXECUTE SQL TASKS HERE
      ├─→ Process_Steps()   │ Apply changes to document
      ├─→ Check()           │ Validate results
      ├─→ Render()          │ Generate output (PDF/QXP)
      └─→ End()             │ Database exit

                    ▼
        ┌──────────────────────────────┐
        │ FOR EACH Task_SQL:           │
        │ task.Process()               │
        └──────┬───────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────┐
│ Task_SQL.Process()                                       │
│ (Very simple - just delegates)                           │
│                                                          │
│ Business.Process_SQL.Process(this);                      │
└──────────┬───────────────────────────────────────────────┘
           │
           ▼
┌──────────────────────────────────────────────────────────┐
│ Process_SQL.Process(task_sql)                            │
│ (Main execution logic)                                   │
│                                                          │
│ 1. Clone parameters:                                     │
│    parameters = task.Run.InParams.CloneParameters()     │
│                                                          │
│ 2. Execute query:                                        │
│    reader = Proxy_Generic.GetReader(sql, params)        │
│                                                          │
│ 3. Check results:                                        │
│    if (reader.HasRows)                                   │
│       → AddBlocs(task, reader)                           │
│                                                          │
│ 4. Validate exceptions:                                  │
│    Check_Task_Exception(task)                            │
└──────────┬───────────────────────────────────────────────┘
           │
           ├─────────────────────────────────────┐
           │                                     │
           ▼                                     ▼
   ┌────────────────────┐        ┌────────────────────────┐
   │ InParams Service   │        │ Proxy_Generic Service  │
   │                    │        │                        │
   │ - Parameters: {}   │        │ - Connection pool      │
   │ - Clone()          │        │ - PreparedStatement    │
   │ - Add params       │        │ - GetReader()          │
   └────────────────────┘        │ - Execute query        │
                                 └────────┬───────────────┘
                                          │
                                          ▼
                                 ┌────────────────────┐
                                 │ Oracle Database    │
                                 │ (or any RDBMS)     │
                                 │                    │
                                 │ Executes SQL:      │
                                 │ SELECT NOM_BLOC,   │
                                 │        VALEUR_BLOC │
                                 │   FROM SOME_TABLE  │
                                 │  WHERE param=?     │
                                 └────────┬───────────┘
                                          │
                                          ▼
                                 ┌────────────────────┐
                                 │ Result Set         │
                                 │                    │
                                 │ ┌────────────────┐ │
                                 │ │ NOM_BLOC │VAL  │ │
                                 │ ├────────────────┤ │
                                 │ │ FIELD_1  │ 100 │ │
                                 │ │ FIELD_2  │ 200 │ │
                                 │ │ FIELD_3  │ 300 │ │
                                 │ └────────────────┘ │
                                 └────────┬───────────┘
                                          │
                                          ▼
                          ┌──────────────────────────────┐
                          │ OraDataReader (Result Set)   │
                          │                              │
                          │ Methods:                     │
                          │ - Read()    → next row       │
                          │ - HasRows   → any results?   │
                          │ - []        → get column     │
                          └──────────┬───────────────────┘
                                     │
                                     ▼
                     ┌─────────────────────────────────┐
                     │ AddBlocs(task, reader)          │
                     │                                 │
                     │ LOOP: while (reader.Read())    │
                     │   {                             │
                     │   blocName = read column        │
                     │   blocValue = read column       │
                     │   blocValue = format value      │
                     │                                 │
                     │   bloc = new Bloc_Box(...)     │
                     │   task.Blocs_Update[name]=bloc │
                     │   }                             │
                     └──────────┬──────────────────────┘
                                │
                                ▼
                     ┌─────────────────────────────────┐
                     │ Data_Type_Helper Service        │
                     │                                 │
                     │ - OutputToString()              │
                     │   • decimal formatting          │
                     │   • null handling               │
                     │   • zero handling               │
                     │   • type conversion             │
                     │   • date formatting             │
                     │                                 │
                     │ Returns: "100.50"               │
                     └─────────────────────────────────┘

                                │
                                ▼
                     ┌─────────────────────────────────┐
                     │ Bloc_Box Objects                │
                     │                                 │
                     │ Name: "FIELD_1"                 │
                     │ Value: "100.50"                 │
                     │ Action: UPDATE                  │
                     │ Description: "Invoice Total"    │
                     │ Info: "Currency: USD"           │
                     └─────────────────────────────────┘

                                │
                                ▼
                     ┌─────────────────────────────────┐
                     │ task.Blocs_Update               │
                     │ Dictionary<Name, Bloc>          │
                     │                                 │
                     │ "FIELD_1" → Bloc_Box            │
                     │ "FIELD_2" → Bloc_Box            │
                     │ "FIELD_3" → Bloc_Box            │
                     │                                 │
                     │ + Optional storage in:          │
                     │   task.DataNamesValues (if      │
                     │   Store_Data = true)            │
                     └─────────────────────────────────┘

                                │
                                ▼
                     ┌─────────────────────────────────┐
                     │ Check_Task_Exception(task)      │
                     │                                 │
                     │ - Validate exception rules      │
                     │ - Check if bloc is empty/null   │
                     │ - Create removal blocs:         │
                     │   • Bloc_Ligne (row removal)    │
                     │   • Bloc_Table (table removal)  │
                     │ - Add to task.Blocs_Modify      │
                     └─────────────────────────────────┘

                                │
                                ▼
                     ┌─────────────────────────────────┐
                     │ task.Blocs_Modify               │
                     │ Dictionary<Name, Bloc>          │
                     │                                 │
                     │ "TABLE_X_1" → Bloc_Ligne        │
                     │ "TABLE_X_2" → Bloc_Ligne        │
                     │ "TABLE_Y" → Bloc_Table          │
                     │ (Action: REMOVE)                │
                     └─────────────────────────────────┘

                                │
                                ▼
                     ┌─────────────────────────────────┐
                     │ SQL Task Processing COMPLETE    │
                     │                                 │
                     │ Result:                         │
                     │ ✓ Blocs_Update filled           │
                     │ ✓ Blocs_Modify filled           │
                     │ ✓ Data stored (if needed)       │
                     │ ✓ Ready for document update     │
                     └─────────────────────────────────┘

                                │
                                ▼
                     ┌─────────────────────────────────┐
                     │ Later: Apply Changes            │
                     │ Run.Launch_Process_Steps()      │
                     │                                 │
                     │ - For each Bloc_Box in          │
                     │   task.Blocs_Update:            │
                     │   UPDATE block in document      │
                     │                                 │
                     │ - For each bloc in              │
                     │   task.Blocs_Modify:            │
                     │   REMOVE row/table              │
                     └─────────────────────────────────┘
```

---

## Detailed Component Interactions

### 1. Parameter Flow

```
Run Object
│
├─ Properties
│  ├─ ID_Suivi
│  ├─ ID_Run
│  └─ Code_Langue
│
├─ InParams (Dictionary<string, InParam>)
│  │
│  ├─ "p_id_suivi" → 123
│  ├─ "p_id_run" → 45
│  ├─ "p_langue" → "FR"
│  └─ ... (other parameters)
│
│
└─ Tasks
   │
   └─ Task_SQL[1]
      │
      └─ Process()
         │
         ├─ InParams.CloneParameters()
         │  │
         │  └─→ Returns: Map<string, object>
         │     {
         │       "p_id_suivi": 123,
         │       "p_id_run": 45,
         │       "p_langue": "FR"
         │     }
         │
         └─ Proxy_Generic.GetReader(sql, params)
            │
            └─→ Binds parameters to SQL
               │
               SELECT NOM_BLOC, VALEUR_BLOC
               FROM my_table
               WHERE id_suivi = ?   ← 123
               AND id_run = ?       ← 45
               AND langue = ?       ← "FR"
```

### 2. Data Transformation Flow

```
Database Result
│
├─ Row 1: ["TOTAL_AMOUNT", 1500.2500]
├─ Row 2: ["INVOICE_DATE", 20240325]
├─ Row 3: ["DESCRIPTION", "Invoice"]
│
└─ Each row enters transformation:

   "TOTAL_AMOUNT" ──→ Data_Type_Helper ──→ "1,500.25"
   1500.2500         │
   (decimal)         ├─ Data_Type: DECIMAL
                     ├─ NbDecimal: 2
                     ├─ ShowZero: true
                     └─ Separator: "."

   "INVOICE_DATE" ──→ Data_Type_Helper ──→ "25/03/2024"
   20240325          │
   (integer)         ├─ Data_Type: DATE
                     ├─ Pattern: "dd/MM/yyyy"
                     └─ Convert integer to date

   "DESCRIPTION" ──→ Data_Type_Helper ──→ "Invoice"
   "Invoice"        │
   (string)         └─ Data_Type: TEXT
                       (no transformation)

   ↓↓↓

   Bloc_Box 1: {name: "TOTAL_AMOUNT", value: "1,500.25"}
   Bloc_Box 2: {name: "INVOICE_DATE", value: "25/03/2024"}
   Bloc_Box 3: {name: "DESCRIPTION", value: "Invoice"}

   ↓↓↓

   task.Blocs_Update:
   {
     "TOTAL_AMOUNT": Bloc_Box {...},
     "INVOICE_DATE": Bloc_Box {...},
     "DESCRIPTION": Bloc_Box {...}
   }
```

### 3. Exception Handling Flow

```
Task_SQL.Exceptions:
{
  "APPROVAL_BOX": TaskException {
    name: "APPROVAL_BOX",
    tableName: "APPROVAL_TABLE",
    type: LINE,
    indexLines: [1, 2, 3]
  }
}

Check_Task_Exception():
│
├─ Get bloc "APPROVAL_BOX" from Blocs_Update
│
├─ Is it null or empty?
│  │
│  ├─ YES → Process exception
│  │  │
│  │  ├─ Type = LINE? → Create Bloc_Ligne for each row
│  │  │  │
│  │  │  ├─ "APPROVAL_TABLE_1" → Bloc_Ligne {action: REMOVE}
│  │  │  ├─ "APPROVAL_TABLE_2" → Bloc_Ligne {action: REMOVE}
│  │  │  └─ "APPROVAL_TABLE_3" → Bloc_Ligne {action: REMOVE}
│  │  │
│  │  └─ Type = TABLE? → Create Bloc_Table
│  │     └─ "APPROVAL_TABLE" → Bloc_Table {action: REMOVE}
│  │
│  │  Add all to task.Blocs_Modify
│  │
│  └─ NO → Skip exception, keep bloc as-is
│
└─ Result: Blocks/rows marked for removal in Blocs_Modify
```

---

## Component Dependency Diagram

```
                    ┌──────────────────────────┐
                    │      Run_Base            │
                    │    (Orchestrator)        │
                    └────────────┬─────────────┘
                                 │
                    ┌────────────┴─────────────┐
                    │                          │
                    ▼                          ▼
            ┌──────────────────┐      ┌──────────────────┐
            │   Task_SQL       │      │   InParams       │
            │                  │      │                  │
            │ - sql: string    │      │ - parameters: {} │
            │ - Process()      │────→ │ - Clone()        │
            └──────────────────┘      └──────────────────┘
                    │
                    │ delegates to
                    ▼
            ┌──────────────────────────────┐
            │    Process_SQL               │
            │   (Business Logic)           │
            │                              │
            │ - Process()                  │
            │ - AddBlocs()                 │
            │ - CheckTaskException()       │
            └──────┬──────────┬────────────┘
                   │          │
         ┌─────────┘          └─────────┐
         │                              │
         ▼                              ▼
    ┌───────────────────┐     ┌──────────────────────────┐
    │ Proxy_Generic     │     │ Data_Type_Helper         │
    │ (Database Access) │     │ (Data Formatting)        │
    │                   │     │                          │
    │ - GetReader()     │     │ - OutputToString()       │
    │ - Execute SQL     │     │ - Format decimal         │
    │ - Return results  │     │ - Format date            │
    └───────────────────┘     │ - Handle nulls           │
         │                    └──────────────────────────┘
         │                              │
         ▼                              │
    ┌───────────────────┐              │
    │  OraDataReader    │              │
    │  (Result Set)     │              │
    │                   │              │
    │ - Read()          │              │
    │ - HasRows         │              │
    │ - []              │              │
    └───────────────────┘              │
         │                              │
         └──────────────┬───────────────┘
                        │
                        ▼
                ┌──────────────────┐
                │  Bloc_Box        │
                │  (Result Object) │
                │                  │
                │ - name: string   │
                │ - value: string  │
                │ - action: enum   │
                └──────────────────┘
                        │
                        ▼
                ┌──────────────────┐
                │ task.Blocs_Update│
                │ Dictionary<...>  │
                └──────────────────┘

Exception Handling:
                        │
         ┌──────────────┴──────────────┐
         │                             │
         ▼                             ▼
    ┌──────────────────┐      ┌──────────────────┐
    │  Bloc_Ligne      │      │  Bloc_Table      │
    │  (Row Removal)   │      │  (Table Removal) │
    │                  │      │                  │
    │ - lineIndex      │      │ - tableName      │
    │ - action: REMOVE │      │ - action: REMOVE │
    └──────────────────┘      └──────────────────┘
         │                             │
         └──────────────┬──────────────┘
                        │
                        ▼
                ┌──────────────────┐
                │task.Blocs_Modify │
                │ Dictionary<...>  │
                └──────────────────┘
```

---

## Data Structure Examples

### Before Process_SQL Execution

```csharp
Task_SQL task = new Task_SQL(1, run)
{
    SQL = "SELECT NOM_BLOC, VALEUR_BLOC FROM MY_TABLE WHERE id_run = :p_id_run",
    ShowZero = false,
    NbDecimal = 2,
    DataType = Data_Type.DECIMAL,
    StoreData = true,
    
    // Collections are empty
    Blocs_Update = new Dictionary<string, Bloc_Box>(),    // Empty {}
    Blocs_Modify = new Dictionary<string, Bloc>(),        // Empty {}
    DataNamesValues = new List<DataNameValue>(),          // Empty []
    Exceptions = new Dictionary<string, TaskException>()  // From DB
}
```

### After SQL Execution (AddBlocs)

```csharp
Task_SQL task:
{
    // ... same config as before ...
    
    Blocs_Update = {
        "TOTAL_AMOUNT": Bloc_Box {
            name: "TOTAL_AMOUNT",
            value: "1,234.56",
            action: UPDATE,
            description: "Invoice Total",
            info: "USD"
        },
        "TAX_AMOUNT": Bloc_Box {
            name: "TAX_AMOUNT",
            value: "123.46",
            action: UPDATE,
            description: "Tax",
            info: "VAT"
        },
        "INVOICE_DATE": Bloc_Box {
            name: "INVOICE_DATE",
            value: "25/03/2024",
            action: UPDATE,
            description: "Invoice Date",
            info: ""
        }
    },
    
    DataNamesValues = [
        DataNameValue { name: "TOTAL_AMOUNT", value: "1,234.56", description: "Invoice Total" },
        DataNameValue { name: "TAX_AMOUNT", value: "123.46", description: "Tax" },
        DataNameValue { name: "INVOICE_DATE", value: "25/03/2024", description: "Invoice Date" }
    ]
}
```

### After Exception Handling (CheckTaskException)

```csharp
Task_SQL task:
{
    // ... Blocs_Update unchanged ...
    
    Blocs_Modify = {
        "APPROVAL_TABLE_1": Bloc_Ligne {
            name: "APPROVAL_TABLE_1",
            value: "",
            action: REMOVE,
            tableName: "APPROVAL_TABLE",
            lineIndex: 1,
            conditionName: "APPROVAL_BOX"
        },
        "APPROVAL_TABLE_2": Bloc_Ligne {
            name: "APPROVAL_TABLE_2",
            value: "",
            action: REMOVE,
            tableName: "APPROVAL_TABLE",
            lineIndex: 2,
            conditionName: "APPROVAL_BOX"
        }
    }
}
```

---

## SQL Query Example

### Input SQL (in Task_SQL.SQL)
```sql
SELECT 
    NOM_BLOC,
    VALEUR_BLOC,
    DESCRIPTION_BLOC,
    INFO_BLOC
FROM QXP_BLOCS_DATA
WHERE ID_RUN = :p_id_run
  AND ID_SUIVI = :p_id_suivi
  AND LANGUE = :p_langue
ORDER BY NOM_BLOC
```

### After Parameter Binding
```sql
SELECT 
    NOM_BLOC,
    VALEUR_BLOC,
    DESCRIPTION_BLOC,
    INFO_BLOC
FROM QXP_BLOCS_DATA
WHERE ID_RUN = 123         -- bound from InParams
  AND ID_SUIVI = 456       -- bound from InParams
  AND LANGUE = 'FR'        -- bound from InParams
ORDER BY NOM_BLOC
```

### Execution Result
```
NOM_BLOC        | VALEUR_BLOC | DESCRIPTION_BLOC | INFO_BLOC
────────────────┼─────────────┼──────────────────┼──────────
TOTAL_AMOUNT    | 1234.5629   | Invoice Total    | USD
TAX_AMOUNT      | 123.4563    | Tax              | VAT
DESCRIPTION     | Invoice #1  | Description      | 
INVOICE_DATE    | 20240325    | Invoice Date     |
```

### After Data_Type_Helper Transformation
```
NOM_BLOC        | VALEUR_BLOC (Transformed)
────────────────┼────────────────────────────
TOTAL_AMOUNT    | 1,234.56        (2 decimals, formatted)
TAX_AMOUNT      | 123.46          (2 decimals, formatted)
DESCRIPTION     | Invoice #1      (no change)
INVOICE_DATE    | 25/03/2024      (date formatted)
```

---

## Process_SQL Method Call Sequence

```
Process_SQL.Process(task)
│
├─ step 1: task.Run.InParams.CloneParameters()
│  ├─ return: OraParameter[] { p_id_run=123, ... }
│  │
│  └─ status: ✓ Parameters ready
│
├─ step 2: new Proxy_Generic()
│  └─ status: ✓ Database proxy initialized
│
├─ step 3: __proxy.GetReader(task.SQL, __parameters)
│  ├─ Create PreparedStatement
│  ├─ Bind parameters
│  ├─ Execute query
│  └─ return: OraDataReader
│     └─ status: ✓ Results fetched from database
│
├─ step 4: __reader.HasRows
│  ├─ true → AddBlocs(task, __reader)
│  │  │
│  │  └─ while (__reader.Read())
│  │     ├─ Extract NOM_BLOC column
│  │     ├─ Extract VALEUR_BLOC column
│  │     ├─ Data_Type_Helper.OutputToString()
│  │     ├─ new Bloc_Box(task, name, value)
│  │     └─ task.Blocs_Update.Add(name, bloc)
│  │
│  └─ false → Log message
│     └─ status: ✓ No rows
│
├─ step 5: Check_Task_Exception(task)
│  ├─ for each exception in task.Exceptions
│  ├─ Check if condition bloc is empty
│  ├─ Create Bloc_Ligne or Bloc_Table
│  └─ Add to task.Blocs_Modify
│     └─ status: ✓ Exceptions processed
│
└─ status: ✓ SQL TASK COMPLETE
   Result:
   - task.Blocs_Update populated
   - task.Blocs_Modify populated
   - Ready for document modification
```

---

## Summary

The SQL execution in Task_SQL is a 5-step process:

1. **Parameter Preparation** → Get substitution values from InParams
2. **Query Execution** → Execute SQL via Proxy_Generic
3. **Result Iteration** → Loop through ResultSet rows
4. **Data Transformation** → Format values using Data_Type_Helper
5. **Block Creation** → Create Bloc objects and store in task.Blocs_Update
6. **Exception Handling** → Create removal blocks in task.Blocs_Modify

For Spring Boot, implement these exact same steps using JDBC/JdbcTemplate and you'll have the same functionality!

