# Quick Reference: Data Transformation Summary

## The Complete Picture

```
DATABASE LAYER (Raw Data Storage)
┌─────────────────────────────────────────┐
│ ID  | Libelle          | Meaning        │
├─────────────────────────────────────────┤
│ 11  | sc11             | Code/ID only   │
│ 12  | sc12             | Code/ID only   │
│ 17  | sc17             | Code/ID only   │
│ ... | ...              | ...            │
│ 323 | DICI             | Actual label   │
│ 63  | Prospectus       | Actual label   │
│ 297 | Rapport_Semi...  | Actual label   │
└─────────────────────────────────────────┘
                   ↓
         ProxyDocument.GetListeSousCategorie()
                   ↓
┌──────────────────────────────────────────────┐
│ LOCALIZATION LAYER (Translation Service)     │
│                                              │
│ For each row from DB:                        │
│   call Resources.GetLabel(section, code)     │
│                                              │
│   "sc11" → Oracle lookup → "Plaquette"       │
│   "sc12" → Oracle lookup → "Rapport annuel"  │
│   "sc17" → Oracle lookup → "Composition..."  │
│   "DICI" → Oracle lookup → "DICI" (unchanged)│
│   ...                                        │
└──────────────────────────────────────────────┘
                   ↓
┌──────────────────────────────────────────────┐
│ BUSINESS LAYER (SousCategorie Objects)       │
│                                              │
│ ┌────────────────────────────────────────┐   │
│ │ id: 11                                 │   │
│ │ libelle: "Plaquette" (TRANSLATED!)     │   │
│ └────────────────────────────────────────┘   │
│ ┌────────────────────────────────────────┐   │
│ │ id: 12                                 │   │
│ │ libelle: "Rapport annuel" (TRANSLATED!)│   │
│ └────────────────────────────────────────┘   │
│ ...                                          │
└──────────────────────────────────────────────┘
                   ↓
┌──────────────────────────────────────────────┐
│ UI BINDING LAYER (BasicDropDownList)         │
│                                              │
│ DataSource = SousCategorie collection        │
│ DataValueField = "idSousCategorie"           │
│ DataTextField = "libelleSousCategorie"       │
│                                              │
│ For each object, create ListItem:            │
│   ListItem(Value=11, Text="Plaquette")       │
│   ListItem(Value=12, Text="Rapport annuel")  │
│   ...                                        │
└──────────────────────────────────────────────┘
                   ↓
┌──────────────────────────────────────────────┐
│ SORTING LAYER (BasicDropDownList.Sort)       │
│                                              │
│ Sort by Text property (Alphabetically):      │
│   ListItem(17, "Composition d'actif") [A]    │
│   ListItem(323, "DICI") [D]                  │
│   ListItem(11, "Plaquette") [P]              │
│   ListItem(63, "Prospectus") [P]             │
│   ListItem(14, "Prospectus partie B") [P]    │
│   ListItem(12, "Rapport annuel") [R]         │
│   ListItem(13, "Rapport annuel simplifié")[R]│
│   ListItem(297, "Rapport semi-annuel") [R]   │
│   ListItem(16, "Statistiques Monaco") [S]    │
│   ListItem(15, "Statistiques Suisse") [S]    │
└──────────────────────────────────────────────┘
                   ↓
┌──────────────────────────────────────────────┐
│ HTML RENDERING LAYER (ASP.NET)               │
│                                              │
│ <select>                                     │
│   <option value="17">Composition d'actif</opt│
│   <option value="323">DICI</option>          │
│   <option value="11">Plaquette</option>      │
│   <option value="63">Prospectus</option>     │
│   ... (sorted alphabetically)                │
│ </select>                                    │
└──────────────────────────────────────────────┘
```

---

## Key Points

### Why the Order Changes
- **Database returns**: 323, 63, 297, 11, 12, 13, 14, 15, 16, 17 (query order)
- **UI displays**: 17, 323, 11, 63, 14, 12, 13, 297, 16, 15 (alphabetical by display text)

### Why the Text Changes
- **Database stores**: `sc11`, `sc12`, `sc13`, `sc14`, `sc15`, `sc16`, `sc17` (compact codes)
- **UI displays**: `Plaquette`, `Rapport annuel`, etc. (translated French labels)

### The Three Types of Values

| Type | Value | Example |
|------|-------|---------|
| **Storage** | Short codes for efficiency | `sc11`, `sc12`, `sc13` |
| **Database** | Compact English codes | `DICI`, `Prospectus`, `Rapport_Semi_Annuel` |
| **Display** | Full French labels (translated) | `Plaquette`, `Rapport annuel`, `Composition d'actif` |

---

## Flow Diagram: Single Item Example

```
DATABASE ROW
┌─────────────────────────────┐
│ id_sous_categorie: 11       │
│ libelle_sous_categorie: sc11│
└────────────┬────────────────┘
             │
             ↓
    Translation Service
    ┌────────────────────────────────┐
    │ GetLabel("SousCategorie","sc11")│
    │                                │
    │ Looks up in Oracle Localization│
    │ Table:                         │
    │ Marker: SOUSCATEGORIE.SC11.... │
    │ Value: Plaquette               │
    └────────────┬───────────────────┘
                 │
                 ↓
       SousCategorie Object
       ┌────────────────────────────┐
       │ idSousCategorie: 11        │
       │ libelleSousCategorie:      │
       │   "Plaquette"  (TRANSLATED)│
       └────────────┬───────────────┘
                    │
                    ↓
           ListItem Creation
           ┌────────────────────────┐
           │ Value: "11"            │
           │ Text: "Plaquette"      │
           └────────────┬───────────┘
                        │
                        ↓
           Sorting Position
           ┌──────────────────────────────┐
           │ Alphabetically:              │
           │ P - Plaquette (position 3)   │
           └────────────┬─────────────────┘
                        │
                        ↓
           HTML Option
           ┌──────────────────────────────┐
           │ <option value="11">          │
           │   Plaquette                  │
           │ </option>                    │
           └──────────────────────────────┘
```

---

## Code Path

1. **ProxyDocument.cs** (line 636)
   - Queries database
   - Calls `Resources.GetLabel()` for each row

2. **ResourceManager.cs** (line 618)
   - Receives section="SousCategorie", group="sc11"
   - Constructs pattern "SousCategorie.sc11.Label"
   - Loads translations from cache or database

3. **ResourcesProxy.cs** (line 82)
   - Executes Oracle `GetResources(cultureCode)` 
   - Returns Hashtable of marker → value pairs
   - Cached for performance

4. **CreationDocumentGabarit.cs** (line 104)
   - Binds translated collection to dropdown
   - Sets DataValueField and DataTextField

5. **BasicDropDownList.cs** (line 119-151)
   - Extracts properties via reflection
   - Sorts items alphabetically
   - Renders HTML

---

## Why This Design?

**Separation of Concerns:**
- **Database**: Stores compact codes (small storage)
- **Localization Service**: Handles translations (supports multiple languages)
- **UI Layer**: Displays formatted output (user-friendly)

**Benefits:**
- Add new categories without database changes
- Support multiple languages easily
- Change labels without affecting code
- Efficient data storage

This is a best-practice architecture pattern for multi-lingual, maintainable applications.

