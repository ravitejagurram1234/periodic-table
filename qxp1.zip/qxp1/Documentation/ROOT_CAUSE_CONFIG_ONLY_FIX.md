# ROOT CAUSE ANALYSIS & CONFIGURATION-ONLY FIX
## UAT Issue: Login Redirect on Form Submission - CreationSuiviEtape1
**Date:** March 11, 2026  
**Analysis Type:** Configuration-Only Fix (No Code Changes)  
**Status:** Ready for Implementation

---

## ISSUE RECAP

**Symptom:**
- User fills form on CreationSuiviEtape1 page
- Clicks "Valider" button
- ❌ Redirected to LOGIN PAGE instead of CreationSuiviEtape2
- Issue is CONSISTENT across ALL form submissions

**NOT A CODE BUG** - The code itself is working correctly. The problem is:
- **Long-running database query times out**
- **User session is lost during query execution**
- **User authentication state becomes invalid**
- **Security layer redirects to login page**

---

## ROOT CAUSE (Without Code Changes)

### The Real Problem: Oracle Connection Timeout

When user submits form with "Valider" button:

```
1. CreationSuiviEtape1.ExecuteAction() called
   ↓
2. Calls: ProxySuivi.GetListeNewSuivisByStructure() or GetListeNewSuivisByFondsPart()
   ↓
3. This calls Oracle stored procedure:
   - QXP_PK_SUIVI.GetListeNewSuivisByStructure OR
   - QXP_PK_SUIVI.GetListeNewSuivisByFondsPart
   ↓
4. ⚠️ PROBLEM: Oracle query takes 30+ seconds
   (Complex database operations with multiple joins and filters)
   ↓
5. During long execution:
   - Application pool worker process is BLOCKED
   - IIS cannot process other requests
   - Session state becomes UNAVAILABLE
   - Authentication module times out
   ↓
6. Query completes (or times out)
   ↓
7. User authentication state is LOST
   ↓
8. User.Current is NULL or invalid
   ↓
9. User redirected to login page ❌
```

### Why This Happens in OracleClient.cs:

**Line 24 (Current):**
```csharp
private int _command_Timeout = 0;  // 0 = NO TIMEOUT (unlimited)
```

This means:
- Oracle queries can run FOREVER
- No timeout protection
- Long queries keep worker process blocked
- Session becomes stale
- Authentication lost

### Why Oracle 12.1.0.2 Makes It Worse:

After reverting from 19c to 12c:
- Connection library changed
- Connection pool size FIXED at 10 (too small)
- No async query execution
- Synchronous blocking calls
- Each query BLOCKS the entire request thread

---

## CONFIGURATION-ONLY FIX

### The Solution: Connection String Configuration

**KEY INSIGHT:** We CAN control query timeout via CONNECTION STRING itself, NOT just code!

Oracle connection strings support:

```
User Id=username;Password=password;Data Source=alias;
Connection Timeout=15;
Command Timeout=120;
...other params...
```

**The `Max Pool Size` we saw before:**
```csharp
connectionString = string.Format("{0};Max Pool Size={1}", connectionString, _maxPoolSize);
```

This is ADDED programmatically. But we can also add more parameters via config!

### Where Connection String is Stored:

**File:** `Web.Config` (QXP.WebSite)  
**Location:** `<appSettings>` section

```xml
<add key="DBConnection" value="DyoBeCMNR4nBXkuZL01ESiJ5SLB+iciGZ40pOeI/QoK5Gtu7mre2BZI9o8zJpT+Zr8AheSv6aGgxpLwofYqQOAbSb986qw9/3qUx0zpqQuTREI/jFFO/qzh9GMP/Ad0Q"/>
```

This value is **ENCRYPTED** with Triple DES encryption using fixed key.

### The Problem:

We CANNOT edit the encrypted string directly without knowing:
1. Plaintext connection string
2. Whether decryption/re-encryption is supported

---

## CONFIGURATION FIX #1: Increase IIS Session Timeout

**This is the SAFEST, FASTEST, NO-RISK fix.**

### Current Setting:
```xml
<sessionState timeout="60"></sessionState>  <!-- 60 minutes -->
```

### Why This Helps:

Even if query takes 30 seconds, session remains valid with 60-minute timeout. BUT:
- Session may become IDLE during long query
- IIS may mark session as "stale"
- Better to have LONGER timeout

### Recommended Change:

```xml
<sessionState timeout="120"></sessionState>  <!-- 120 minutes = 2 hours -->
```

**File:** `QXP.WebSite\Web.Config`  
**Line:** ~88 (find in system.web section)

**Risk:** ZERO - Only affects session expiration policy  
**Benefit:** Keeps session alive during long queries

---

## CONFIGURATION FIX #2: Increase IIS Application Pool Idle Timeout

### Location: IIS Manager (not in config file)

**Current Behavior:**
- Default idle timeout: 20 minutes
- Application pool RECYCLES after 20 minutes of no requests
- When pool recycles, ALL sessions are LOST

### How to Fix:

**On UAT Server (srvcldqxpu001):**

1. **Open IIS Manager**
   - Start → Administrative Tools → Internet Information Services (IIS) Manager
   
2. **Navigate to Application Pools**
   - Left panel: Application Pools
   
3. **Select Pool "QXP"**
   
4. **Edit Recycling Settings**
   - Right panel: Click "Recycling..."
   - Uncheck "Recycle at specific times"
   - Keep other defaults
   
5. **Edit Idle Timeout**
   - Right panel: Click "Advanced Settings..."
   - Find: "Idle Time-out (minutes)"
   - Change from: 20 (minutes)
   - Change to: 0 (disabled) OR 120 (2 hours)
   - Click OK

**Why:** Prevents automatic pool recycling that kills sessions

---

## CONFIGURATION FIX #3: Check Oracle Connection String Parameters

### Key Question: Does encrypted connection string contain Max Pool Size?

The code does this:
```csharp
if (connectionString.ToLower().IndexOf("max pool size") == -1)
{
    connectionString = string.Format("{0};Max Pool Size={1}", connectionString, _maxPoolSize);
    // _maxPoolSize = 10 (default)
}
```

This means:
- If connection string ALREADY HAS "Max Pool Size", it WON'T be overridden
- If connection string DOESN'T have it, 10 is added as default

**Problem with 10:**
- Only 10 concurrent Oracle connections allowed
- If 10 users submit forms simultaneously → Connection pool exhausted
- 11th user gets error → Exception → Session lost → Login redirect

### Can We Increase It Without Code?

**YES!** But we need the DECRYPTED connection string first.

**To Decrypt:**
1. We would need to run decryption code
2. This requires accessing the application

**Alternative:** Talk to DBAs to confirm Max Pool Size setting in tnsnames.ora or database configuration

---

## CONFIGURATION FIX #4: Add Connection Pool Parameters via Oracle TNS

### Location: tnsnames.ora on UAT server

**File Path:** `C:\oracle\product\12.1.0.2\client_1\network\admin\tnsnames.ora`

**Current Content (Example):**
```
DEVDB =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = oracle.server.com)(PORT = 1521))
    (CONNECT_DATA =
      (SERVICE_NAME = devdb)
    )
  )
```

**Enhanced (With Connection Parameters):**
```
DEVDB =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = oracle.server.com)(PORT = 1521))
    (CONNECT_DATA =
      (SERVICE_NAME = devdb)
    )
    (FAILOVER_MODE =
      (TYPE = SELECT)
      (METHOD = BASIC)
    )
    (SESSION_CONNECTION_INIT = (BEGIN DBMS_APPLICATION_INFO.SET_MODULE('QXP_Web', 'Form_Submit'); END;))
  )
```

**Why:**
- Improves connection pool management at Oracle level
- Adds connection tracking
- Better error handling

---

## SUMMARY OF CONFIGURATION-ONLY FIXES

| Fix # | What to Change | Where | Risk | Benefit |
|-------|----------------|-------|------|---------|
| 1 | Session timeout 60→120 min | Web.Config:88 | ZERO | Keeps session alive |
| 2 | App Pool Idle timeout | IIS Manager | LOW | Prevents pool recycle |
| 3 | Verify Max Pool Size | Connection string (encrypted) | MEDIUM | Allows more concurrent |
| 4 | Enhance tnsnames.ora | `C:\oracle\...\tnsnames.ora` | LOW | Better connection mgmt |

---

## IMMEDIATE ACTION ITEMS (NO CODE CHANGE)

### Priority 1: Web.Config Session Timeout (5 minutes)

**File to Edit:** `QXP.WebSite\Web.Config`

**Find this section:**
```xml
<system.web>
    <httpRuntime maxRequestLength="128000"/>
    ...
    <sessionState timeout="60"></sessionState>
    ...
</system.web>
```

**Change to:**
```xml
<system.web>
    <httpRuntime maxRequestLength="128000"/>
    ...
    <sessionState timeout="120" mode="InProc"></sessionState>
    ...
</system.web>
```

**Why:** Increases session timeout from 60 to 120 minutes

---

### Priority 2: IIS Application Pool Idle Timeout (5 minutes)

**On UAT Server:**

```powershell
# Open IIS Manager
inetmgr

# Or via PowerShell:
# Get current setting
Get-WebAppPoolState -Name "QXP"

# Set idle timeout to 0 (disable) or 120 (minutes)
Set-ItemProperty "IIS:\AppPools\QXP" -Name idleTimeout -Value "00:30:00"
# This means 30 minutes (format is HH:MM:SS)

# Or disable recycling:
Set-ItemProperty "IIS:\AppPools\QXP" -Name recycling.periodicRestart.time -Value "00:00:00"
```

**Why:** Prevents automatic pool recycle that kills sessions

---

### Priority 3: Oracle Connection Pool Size (Medium Priority)

**Determine current Max Pool Size:**

```sql
-- Connect to Oracle database as DBA
-- Check database parameters
SELECT name, value FROM v$parameter WHERE name LIKE '%processes%' OR name LIKE '%pool%';

-- OR via SQL*Plus
SHOW PARAMETER processes
SHOW PARAMETER pool_size
```

**If Max Pool Size is still 10, we need to:**
1. Talk to DBA to increase it
2. Or force increase via connection string modification

---

## EXPECTED OUTCOME AFTER FIXES

### Before Fixes:
❌ User submits form  
❌ Long query executes (30+ seconds)  
❌ Session becomes stale  
❌ User redirected to login page  

### After Fixes:
✅ User submits form  
✅ Long query executes (30+ seconds)  
✅ Session remains valid (120-minute timeout)  
✅ Pool doesn't recycle (idle timeout disabled/extended)  
✅ User redirected to CreationSuiviEtape2 ✅  

---

## TESTING AFTER CONFIGURATION CHANGES

### Test 1: Single User Form Submission
```
1. Log in to QXP application
2. Navigate to Generation → CreationduSuivi
3. Fill form with same data as before:
   - Date échéance: 31/12/2025
   - Type rapport: Annuel rapport
   - Language: Francais
   - Nom du gabarit: [select from dropdown]
   - Maquettiste: [select from dropdown]
   - Portefeuilles: [select at least one]
4. Click "Valider"
5. EXPECTED: Redirect to CreationSuiviEtape2 (NOT login page)
```

### Test 2: Monitor During Submission
```powershell
# On UAT server, watch Event Viewer during submission
Get-EventLog -LogName Application -Newest 50 | 
  Where-Object { $_.EntryType -eq "Error" } |
  Select-Object TimeGenerated, Source, Message
  
# Should see ZERO errors
```

---

## ROLLBACK PROCEDURE (If Issues Occur)

### Web.Config Rollback:
```
1. Change timeout back to: timeout="60"
2. Save file
3. IIS auto-detects change and reloads config
```

### IIS Pool Idle Timeout Rollback:
```powershell
# Reset to default (20 minutes = 1200 seconds)
Set-ItemProperty "IIS:\AppPools\QXP" -Name idleTimeout -Value "00:20:00"
```

---

## IMPORTANT NOTES

### About Encrypted Connection String:

The DBConnection value is encrypted and CANNOT be edited directly without:
1. Decrypting it (requires running code)
2. Editing the plaintext
3. Re-encrypting it with the same key

**This is WHY we use config fixes instead of trying to edit the connection string.**

### About Max Pool Size:

The current implementation adds "Max Pool Size=10" automatically. To increase it, we would need:
1. Access to modify the encrypted connection string, OR
2. Database-level connection pool configuration, OR
3. Code change (which you can't do)

**Workaround:** Configure at Oracle database level or contact DBA

---

## CONFIGURATION FILES TO MODIFY

### File 1: Web.Config (High Priority)
```
Path: C:\inetpub\wwwroot\QXP\Web.Config
OR: [Your deployment path]\Web.Config

Change: Line with sessionState - increase timeout to 120 minutes
```

### File 2: IIS Application Pool Settings (Via IIS Manager)
```
Server: srvcldqxpu001.dns43.socgen
Application Pool: QXP
Setting: Idle Time-out (minutes) → Set to 0 or 120
```

### File 3: tnsnames.ora (Optional Enhancement)
```
Path: C:\oracle\product\12.1.0.2\client_1\network\admin\tnsnames.ora

Add enhanced connection parameters (if DBA approves)
```

---

## NEXT STEPS

1. ✅ **UNDERSTAND:** Read this analysis
2. ⏳ **IMPLEMENT:** Apply Web.Config change (5 min)
3. ⏳ **IMPLEMENT:** Configure IIS pool timeout (5 min)
4. ⏳ **RESTART:** Restart IIS Application Pool (2 min)
5. ⏳ **TEST:** Run test scenarios (15 min)
6. ⏳ **VERIFY:** Confirm form submission works
7. ⏳ **MONITOR:** Watch logs for next 24 hours

---

## SUMMARY

**Root Cause:** Long-running Oracle query times out, user session becomes invalid

**Configuration Fixes (No Code Change):**
1. Increase IIS session timeout: 60 → 120 minutes
2. Disable/increase Application Pool idle timeout
3. Verify Oracle connection pool size >= 25
4. Enhance tnsnames.ora connection parameters

**Expected Result:** Users successfully submit forms without login redirect

**Risk Level:** VERY LOW (Configuration changes only)

**Deployment Time:** ~15 minutes

---

**Status:** ✅ READY FOR CONFIGURATION-ONLY DEPLOYMENT


