# UploadManager.Check() Method - Complete Call Chain & Trace

**Document Version:** 1.0  
**Date:** March 12, 2026  
**Scope:** Complete trace from UploadManager.Check() to all leaf classes  

---

## EXECUTIVE SUMMARY

The `UploadManager.Check()` method is a **document upload processing and validation pipeline** that:

1. ✅ Monitors the database for new uploaded documents
2. ✅ Retrieves documents from upload storage
3. ✅ Validates and analyzes each document
4. ✅ Extracts document identity metadata
5. ✅ Converts to QuarkXPress server format
6. ✅ Creates batch execution tasks (runs)
7. ✅ Handles errors gracefully

**Purpose:** Convert raw uploaded files into executable batch tasks for the QXP system

---

## COMPLETE CALL HIERARCHY

```
UploadManager.Check()
│
├─ Watcher (monitors periodically)
│
├─ Check for thread-safety (Running flag)
│
├─ Trace_Helper.Log_UploadMessage() ← [LEAF CLASS: Logging]
│
├─ DocumentProxy.__ctor() 
│  └─ BaseProxy.__ctor() [Framework class]
│
├─ DocumentProxy.GetNewUploadDocuments()
│  └─ Calls Oracle Stored Procedure: QXP_PK_BATCH.Get_New_Upload
│     └─ Returns: List<int> (upload IDs)
│
├─ DocumentProxy.LoadUploadDocuments()
│  │
│  └─ DocumentProxy.GetUploadDocument() (for each ID)
│     ├─ Calls Oracle Stored Procedure: QXP_PK_BATCH.Get_Upload_Document
│     └─ Returns: Document object
│        └─ Document.__ctor() ← [LEAF CLASS: Business Object]
│
├─ QXPS_File_Manager.Addfile()
│  ├─ Saves binary file locally (if enabled)
│  ├─ QXPIO.FileHelper.SaveFile() [Framework IO]
│  └─ QXPInteropQuarkServer.QXPS_Helper.AddFile() [Interop]
│     └─ Uploads to QuarkXPress Server ← [EXTERNAL: Quark Server]
│
├─ Document_Identity_Helper.Get_Identity()
│  ├─ Document_Identity_Helper.Get_Identity_Value()
│  │  ├─ QXPInteropQuarkServer.QXPS_Helper.Get_Xml()
│  │  │  └─ Retrieves XML from QuarkXPress Server ← [EXTERNAL: Quark Server]
│  │  │
│  │  └─ QXP_XML.Create_From_XML()
│  │     └─ Parses XML metadata ← [LEAF CLASS: XML Parser]
│  │
│  └─ Document_Identity.__ctor() ← [LEAF CLASS: Business Object]
│     └─ Parses DID field and extracts metadata
│
├─ Document_Identity.Is_Defined (property check)
│
├─ RunProxy.__ctor()
│
├─ RunProxy.CreateRunUpload()
│  └─ Calls Oracle Stored Procedure: QXP_PK_BATCH.Create_Run_Upload
│     └─ Returns: int (run ID or error code)
│
├─ Run_Queue_Item.__ctor() ← [LEAF CLASS: Business Object]
│  └─ Stores run ID for execution
│
├─ Run_Queue.Enqueue()
│  └─ Adds item to thread-safe queue ← [LEAF CLASS: Collection]
│
├─ Worker_Thread.Set_Loop_Events()
│  └─ Wakes worker threads to process queued tasks ← [LEAF CLASS: Thread Management]
│
├─ DocumentProxy.UpdateUploadErrors()
│  └─ Calls Oracle Stored Procedure: QXP_PK_BATCH.Update_Upload_With_Errors
│
├─ Error_Helper.LogError() ← [LEAF CLASS: Error Handling]
│
└─ QXPS_File_Manager.PurgeAddedFiles()
   └─ Cleans up temporary files from QuarkXPress Server ← [EXTERNAL: Quark Server]
```

---

## DETAILED FLOW WITH CODE

### PHASE 1: INITIALIZATION

```csharp
public static void Check()
{
    // L'opération de chargement des fichiers d'upload pouvant être longue 
    // on décompose en plusieurs étapes.
    
    Trace_Helper.Log_UploadMessage("Début check upload");
    
    // Thread-safety check
    if(Running){
        Trace_Helper.Log_UploadMessage("Sortie du Check car running");
        return;  // Prevent concurrent execution
    }
    Running = true;  // Set flag to block other threads
    
    try{
        // All processing happens here
    }
    finally{
        Running = false;  // Always reset flag
    }
}
```

**Purpose:** Prevent multiple threads from executing upload logic simultaneously (thread-safety mechanism)

---

### PHASE 2: FETCH NEW UPLOADS FROM DATABASE

```csharp
Trace_Helper.Log_UploadMessage("Début GetNewUploadDocuments");

// Create proxy object to access data layer
Proxy.DocumentProxy __proxy = new Proxy.DocumentProxy();

// Get list of upload IDs waiting to be processed
List<int> __new_upload_ids = __proxy.GetNewUploadDocuments();

Trace_Helper.Log_UploadMessage("Fin GetNewUploadDocuments avec {0} new upload", 
                                __new_upload_ids.Count);
```

#### **LEAF CLASS 1: DocumentProxy.GetNewUploadDocuments()**

```csharp
// FILE: QXP.Batch.Core\Proxy\DocumentProxy.cs

public List<int> GetNewUploadDocuments()
{
    // Set timeout for database command
    this.Command_Timeout = BatchCoreSetting.Current.Command_TimeOut;
    
    // Define return parameter (cursor from stored procedure)
    QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter(
        "Cursor", 
        OracleDbType.RefCursor, 
        ParameterDirection.ReturnValue
    );
    
    // Name of Oracle stored procedure to execute
    string __sp_Name = string.Concat(PACKAGE, "Get_New_Upload");
    // Full name: "QXP_PK_BATCH.Get_New_Upload"
    
    List<int> __new_document_ids = new List<int>();
    
    // Execute stored procedure and read results
    using (QXPDataOracle.OraDataReader __odr = this.GetReader(
        CommandType.StoredProcedure, 
        __sp_Name, 
        __cursor))
    {
        while (__odr.Read())
        {
            // For each row, get ID_UPLOAD column
            __id_Upload = __odr["ID_UPLOAD"];
            __new_document_ids.Add(__id_Upload);
        }
    }
    
    return __new_document_ids;  // Return list of IDs to process
}
```

**What It Does:**
- Calls Oracle stored procedure `QXP_PK_BATCH.Get_New_Upload`
- Returns a list of upload IDs (integers) that are pending processing
- Uses OraDataReader to efficiently stream results

**Leaf Endpoint:** Oracle Database

---

### PHASE 3: EXIT IF NO UPLOADS

```csharp
if(__new_upload_ids.Count == 0) {
    // No new documents to load/analyze
    Trace_Helper.Log_UploadMessage("Sortie du Check car 0 upload");
    Running = false;
    return;  // Exit early - nothing to do
}
```

---

### PHASE 4: LOAD DOCUMENT DETAILS

```csharp
Trace_Helper.Log_UploadMessage("Début LoadUploadDocuments");

// Load full document data for each upload ID
List<Document> __documents = __proxy.LoadUploadDocuments(__new_upload_ids);

Trace_Helper.Log_UploadMessage("Fin LoadUploadDocuments avec {0}", __documents.Count);
```

#### **LEAF CLASS 2: DocumentProxy.LoadUploadDocuments()**

```csharp
public List<Document> LoadUploadDocuments(List<int> upload_document_ids)
{
    List<Document> __upload_documents = new List<Document>();
    Document __doc = null;
    
    // For each upload ID, get the full document
    foreach (int __id_Upload in upload_document_ids)
    {
        __doc = GetUploadDocument(__id_Upload);
        if (QXPFrk.Validation.IsNotNull(__doc)) 
            __upload_documents.Add(__doc);
    }
    
    return __upload_documents;
}

public Document GetUploadDocument(int id_Upload)
{
    Document __doc = null;
    
    // Define parameters for stored procedure
    QXPDataOracle.OraParameter __cursor = new QXPDataOracle.OraParameter(
        "Cursor", 
        OracleDbType.RefCursor, 
        ParameterDirection.ReturnValue
    );
    QXPDataOracle.OraParameter __id_Upload = new QXPDataOracle.OraParameter(
        "p_id_upload", 
        id_Upload
    );
    
    string __sp_Name = string.Concat(PACKAGE, "Get_Upload_Document");
    
    try
    {
        using (QXPDataOracle.OraDataReader __odr = this.GetReader(
            CommandType.StoredProcedure, 
            __sp_Name, 
            __cursor, 
            __id_Upload))
        {
            if (__odr.Read())
            {
                // Create Document object with retrieved data
                __doc = new Document(
                    id_Upload, 
                    "Upload",               // name
                    Constantes.Document_Format.QXP,
                    "UP",                   // prefix
                    __odr["contenu"]        // binary content
                );
            }
        }
    }
    catch (Exception ex)
    {
        Error_Helper.LogError(
            string.Format("Impossible de charger le fichier {0} de qxp_document_upload", 
                         id_Upload), 
            ex);
    }
    
    return __doc;
}
```

#### **LEAF CLASS 3: Document.__ctor()**

```csharp
// FILE: QXP.Engine.Core\BusinessObject\Document\Document.cs

public Document(int id, string name, string format, string prefix, byte[] data)
    : this(id, name, format, FileDocumentPrefix, data)
{
    // Constructor overload
}

public Document(int id, string name, string format, string prefix, byte[] data)
{
    _id             = id;           // Upload ID
    _name           = name;         // "Upload"
    _format         = format;       // Document format (QXP)
    _prefix         = prefix;       // "UP"
    _data           = data;         // Binary file content
    
    // Calculate filename with pattern
    _fileName = string.Format(FileNamePrefixePattern, prefix, id, format);
    // Example result: "UP_1234.QXP"
    
    _filePoolPath = GetPoolPath(_fileName);
    _fileFullPath = GetFileFullPath(_fileName);
}
```

**What It Does:**
- Creates business object representing uploaded document
- Stores ID, name, format, and binary content
- Calculates file paths for storage

**Leaf Endpoint:** Business object (Document)

---

### PHASE 5: ANALYZE EACH DOCUMENT

```csharp
List<int> __idRunToLaunch = new List<int>(); // IDs of runs to launch

Trace_Helper.Log_UploadMessage("Début Analyse Documents");

foreach(Document __doc in __documents){
    try{
        // Step 5a: Upload to QuarkXPress Server
        // Step 5b: Extract document identity
        // Step 5c: Create run task
        // Step 5d: Error handling
    }
}
```

#### **LEAF CLASS 4: QXPS_File_Manager.Addfile()**

```csharp
// FILE: QXP.Engine.Core\BusinessObject\QXPS\QXPS_File_Manager.cs

public static void Addfile(string MyDoc, byte[] MyFile) 
{
    // Check if already added
    if(_addedFiles.Contains(MyDoc)) return;
    
    string __file = string.Empty;
    
    try
    {
        // Save binary file locally (debugging/audit)
        if(_save_Used_Ressources)
        {
            __file = string.Concat(_save_Used_Ressources_Path, MyDoc);
            QXPIO.FileHelper.SaveFile(__file, MyFile, true);
            // FILE OPERATION: Saves to disk
        }
    }
    catch(Exception ex)
    {
        Trace_Helper.Log_Exception_Message(ex, 
            "Impossible de sauvegarder le fichier {0}", __file);
    }
    
    try
    {
        // CRITICAL: Upload to QuarkXPress Server
        QXPInteropQuarkServer.QXPS_Helper.AddFile(MyDoc, MyFile);
        // EXTERNAL SYSTEM CALL
        
        // Track that this file was added
        _addedFiles.Add(MyDoc);
    }
    catch (Exception ex)
    {
        throw ex;
    }
}
```

**What It Does:**
1. Saves file to local disk (optional)
2. **Uploads binary file to QuarkXPress Server** (this is where Quark processes it)
3. Tracks uploaded files for cleanup

**Leaf Endpoint 4a:** QXPIO.FileHelper.SaveFile() - Local disk I/O  
**Leaf Endpoint 4b:** QXPInteropQuarkServer.QXPS_Helper.AddFile() - External QuarkXPress Server

---

#### **LEAF CLASS 5: Document_Identity_Helper & Document_Identity**

```csharp
// Extract document identity (metadata from Quark)
Document_Identity __identity = Document_Identity_Helper.Get_Identity(__doc.FilePoolPath);

Trace_Helper.Log_UploadMessage("Analyse Documents DID:{0}", __identity.Value);
```

##### **Sub-Leaf 5a: Document_Identity_Helper.Get_Identity()**

```csharp
// FILE: QXP.Engine.Core\Helper\Document_Identity_Helper.cs

public static Document_Identity Get_Identity(string documentName)
{
    return new Document_Identity(Get_Identity_Value(documentName));
}

public static string Get_Identity_Value(string documentName)
{
    // Query QuarkXPress Server for XML containing metadata
    string __xmlDID = QXPInteropQuarkServer.QXPS_Helper.Get_Xml(
        documentName, 
        Document_Identity.DID
    );
    // EXTERNAL SYSTEM CALL to Quark
    
    // Parse XML and extract DID value
    string __didValue = QXP_XML.Create_From_XML(__xmlDID)
                              .GetValue(Document_Identity.DID);
    // LEAF: XML parsing
    
    return __didValue;
}
```

**What It Does:**
1. Queries QuarkXPress Server for document metadata (XML)
2. Parses XML to extract DID (Document Identity)
3. Returns the DID value string

**Leaf Endpoint 5a:** QXPInteropQuarkServer.QXPS_Helper.Get_Xml() - External Quark Server  
**Leaf Endpoint 5b:** QXP_XML.Create_From_XML() - XML Parser

##### **Sub-Leaf 5b: Document_Identity.__ctor()**

```csharp
// FILE: QXP.Engine.Core\BusinessObject\Document\Document_Identity.cs

public class Document_Identity
{
    // Members representing document metadata
    string  _id_Fnd_Code;       // Foundation code
    int     _id_Suivi;          // Follow-up ID
    int     _id_Run;            // Run ID
    int     _id_Langue;         // Language ID
    DateTime _date_Echeance;    // Deadline date
    DateTime _date_Last_Execution; // Last generation date
    string  _id_Unit_Code;      // Unit code
    string  _value;             // Raw DID string
    
    public Document_Identity(string valeur_champs)
    {
        _value = valeur_champs;
        
        // Split DID field by pipe delimiter
        // Format: "IdFndCode|IdSuivi|IdRun|IdLangue|DateEcheance|DateLastExecution|IdUnitCode"
        string[] __values = QXPFrk.Conversion.ToString(valeur_champs).Split('|');
        
        if (__values.Length >= 6)
        {
            // Parse each field
            _id_Fnd_Code           = __values[0];
            _id_Suivi              = QXPFrk.ConversionInvariante.ToInt(__values[1]);
            _id_Run                = QXPFrk.ConversionInvariante.ToInt(__values[2]);
            _id_Langue             = QXPFrk.ConversionInvariante.ToInt(__values[3]);
            _date_Echeance         = QXPFrk.ConversionInvariante.ToDateTime(__values[4]);
            _date_Last_Execution   = QXPFrk.ConversionInvariante.ToDateTime(__values[5]);
            
            // Optional 7th field
            if (__values.Length >= 7)
                _id_Unit_Code = __values[6];
        }
    }
    
    public bool Is_Defined
    {
        get 
        { 
            return (_id_Fnd_Code != null && _id_Suivi > 0);
        }
    }
}
```

**What It Does:**
- Parses DID string into individual metadata fields
- Validates that required fields are present
- Provides Is_Defined property to check validity

**Leaf Endpoint:** Business object (Document_Identity)

---

### PHASE 6: CREATE RUN (BATCH TASK)

```csharp
if(__identity.Is_Defined)  // Only if document has valid identity
{
    try
    {
        Trace_Helper.Log_UploadMessage(
            "Début Creation Run pour suivi {0} avec upload {1}", 
            __identity.Id_Suivi, 
            __doc.ID);
        
        // Create a run without task
        int __idRunCreated = CreateRunUpload(__identity.Id_Suivi, __doc.ID);
        
        Trace_Helper.Log_UploadMessage(
            "Fin Creation Run pour suivi {0} avec upload {1} avec Run: {2}", 
            __identity.Id_Suivi, 
            __doc.ID, 
            __idRunCreated);
        
        // Handle return codes
        switch (__idRunCreated)
        {
            case -2: 
                // Follow-up is locked
                __error_upload_ids.Add(__doc.ID, "Le suivi est locké");
                break;
            case -1: 
                // Run already being processed by batch
                __error_upload_ids.Add(__doc.ID, 
                    "Le run à MAJ est déjà pris en compte par batch");
                break;
            case 0: 
                // Error creating run
                __error_upload_ids.Add(__doc.ID, 
                    "Erreur lors de la création du RunUpload");
                break;
            default: 
                // Success: add to launch queue
                if (!__idRunToLaunch.Contains(__idRunCreated))
                    __idRunToLaunch.Add(__idRunCreated);
                break;
        }
    }
    catch (Exception ex)
    {
        Error_Helper.LogError(
            string.Format("Impossible de générer le PDF pour le fichier {0}", 
                         __doc.FilePoolPath), 
            ex);
        __error_upload_ids.Add(__doc.ID, 
            string.Format("Erreur lors de la génération du PDF à partir du document {0}", 
                         __doc.FilePoolPath));
    }
}
else
{
    // Document doesn't have valid identity
    __error_upload_ids.Add(__doc.ID, 
        string.Format("Erreur dans le champs DID du document {0}", 
                     __doc.FilePoolPath));
}
```

##### **LEAF CLASS 6a: UploadManager.CreateRunUpload()**

```csharp
// FILE: QXP.Batch.Core\Business\UploadManager.cs

private static int CreateRunUpload(int idSuivi, int idQxpUpload)
{
    Proxy.RunProxy __runProxy = new Proxy.RunProxy();
    
    int __idRunCreated;
    try
    {
        __idRunCreated = __runProxy.CreateRunUpload(idSuivi, idQxpUpload);
    }
    catch
    {
        __idRunCreated = 0;  // Error code
    }
    
    return __idRunCreated;
}
```

##### **LEAF CLASS 6b: RunProxy.CreateRunUpload()**

```csharp
// FILE: QXP.Batch.Core\Proxy\RunProxy.cs

public int CreateRunUpload(int idSuivi, int idQxpUpload)
{
    // Define parameters
    QXPDataOracle.OraParameter __idSuivi = new QXPDataOracle.OraParameter(
        "p_id_suivi", 
        idSuivi
    );
    QXPDataOracle.OraParameter __idQxpUpload = new QXPDataOracle.OraParameter(
        "p_id_qxp_upload", 
        idQxpUpload
    );
    
    // Stored procedure name
    string __sql = "QXP_PK_BATCH.Create_Run_Upload";
    
    int __idRunCreated;
    try
    {
        // Execute stored procedure
        __idRunCreated = this.ExecuteScalar(
            CommandType.StoredProcedure, 
            __sql, 
            __idSuivi, 
            __idQxpUpload
        );
        // Returns: 
        //   -2 = Follow-up locked
        //   -1 = Run already in batch
        //    0 = Error
        //   >0 = New run ID created
    }
    catch (Exception ex)
    {
        Error_Helper.LogError("Erreur pendant la création du run upload", ex);
        throw;
    }
    
    return __idRunCreated;
}
```

**What It Does:**
- Calls Oracle stored procedure to create a run record
- Returns status code (>0 means success with run ID)

**Leaf Endpoint:** Oracle Database

---

### PHASE 7: ADD TO PROCESSING QUEUE

```csharp
// Put runs in the queue to be generated
Trace_Helper.Log_UploadMessage("Début Ajout des {0} Run(s) créé(s) ", 
                                __idRunToLaunch.Count);

foreach(int __idRun in __idRunToLaunch){
    Trace_Helper.Log_UploadMessage(
        "Ajout du {0} Run(s) dans la file d'exécution ", 
        __idRun);
    
    // Create queue item and enqueue
    Run_Queue.Enqueue(new Run_Queue_Item(__idRun));
}

Trace_Helper.Log_UploadMessage("Fin Ajout des {0} Run(s) créé(s) ", 
                                __idRunToLaunch.Count);
```

#### **LEAF CLASS 7a: Run_Queue_Item.__ctor()**

```csharp
// FILE: QXP.Batch.Core\BusinessObject\Watcher\Run_Queue_Item.cs

public class Run_Queue_Item : IEquatable<Run_Queue_Item>
{
    private int _id_run;
    
    public Run_Queue_Item(int id_run)
    {
        _id_run = id_run;  // Store the run ID
    }
    
    public int ID_Run
    {
        get { return _id_run; }
        set { _id_run = value; }
    }
    
    // Equality check for duplicate prevention
    bool IEquatable<Run_Queue_Item>.Equals(Run_Queue_Item item)
    {
        return (_id_run == item.ID_Run);
    }
}
```

**What It Does:**
- Wraps run ID in a queue-able object
- Implements equality to detect duplicates

**Leaf Endpoint:** Business object (Run_Queue_Item)

---

#### **LEAF CLASS 7b: Run_Queue.Enqueue()**

```csharp
// FILE: QXP.Batch.Core\BusinessObject\Watcher\Run_Queue.cs

public class Run_Queue
{
    static object SyncRoot = new object();
    static Queue<Run_Queue_Item> _queue = new Queue<Run_Queue_Item>();
    
    public static void Enqueue(Run_Queue_Item item)
    {
        lock(SyncRoot)  // Thread-safe access
        {
            if (!_queue.Contains(item))  // Prevent duplicates
            {
                _queue.Enqueue(item);  // Add to queue
            }
        }
    }
    
    public static Run_Queue_Item Dequeue()
    {
        Run_Queue_Item __item = null;
        lock(SyncRoot)
        {
            if(_queue.Count > 0)
            {
                __item = _queue.Dequeue();
            }
        }
        return __item;
    }
}
```

**What It Does:**
- Thread-safe queue using lock mechanism
- Prevents duplicate items
- FIFO (First In, First Out) processing

**Leaf Endpoint:** Collection (Thread-safe Queue)

---

### PHASE 8: WAKE WORKER THREADS

```csharp
Trace_Helper.Log_UploadMessage("Ordre de réveil des WorkerThreads ");

// Wake up worker threads to process new tasks
Worker_Thread.Set_Loop_Events();
```

#### **LEAF CLASS 8: Worker_Thread.Set_Loop_Events()**

```csharp
// FILE: QXP.Batch.Core\BusinessObject\Watcher\Worker_Thread.cs

public static List<AutoResetEvent> Loops_Event = new List<AutoResetEvent>();

public static void Set_Loop_Events()
{
    // Signal all worker threads
    foreach(AutoResetEvent __event in Loops_Event)
    {
        __event.Set();  // Wake up the thread from waiting
    }
}
```

**What It Does:**
- Signals all worker threads that new work is available
- Prevents threads from sleeping unnecessarily
- Each worker thread has its own AutoResetEvent

**Leaf Endpoint:** Thread synchronization (AutoResetEvent)

---

### PHASE 9: HANDLE ERRORS

```csharp
// Update status (in error) of unrecognized documents 
// in QXP_Document_Upload
Trace_Helper.Log_UploadMessage("Début Mise à jour des uploads {0} en erreur ", 
                                __error_upload_ids.Count);

__proxy.UpdateUploadErrors(__error_upload_ids);

Trace_Helper.Log_UploadMessage("Fin Mise à jour des uploads {0} en erreur ", 
                                __error_upload_ids.Count);
```

#### **LEAF CLASS 9: DocumentProxy.UpdateUploadErrors()**

```csharp
public void UpdateUploadErrors(Dictionary<int, string> error_upload_ids)
{
    if (error_upload_ids.Count == 0) return;
    
    string __sp_Name = string.Concat(PACKAGE, "Update_Upload_With_Errors");
    
    // Convert dictionary to arrays for Oracle
    int[] __error_upload_ids = new int[error_upload_ids.Count];
    string[] __error_upload_msg = new string[error_upload_ids.Count];
    
    int __i = 0;
    foreach (int __id in error_upload_ids.Keys)
    {
        __error_upload_ids[__i] = __id;
        __i++;
    }
    
    __i = 0;
    foreach (string __msg in error_upload_ids.Values)
    {
        __error_upload_msg[__i] = __msg;
        __i++;
    }
    
    // Define Oracle parameters
    QXPDataOracle.OraParameter __error_ids = new QXPDataOracle.OraParameter(
        "p_error_ids", 
        __error_upload_ids
    );
    QXPDataOracle.OraParameter __error_msgs = new QXPDataOracle.OraParameter(
        "p_error_msgs", 
        __error_upload_msg
    );
    
    // Execute stored procedure
    int __affected = this.ExecuteScalar(
        CommandType.StoredProcedure, 
        __sp_Name, 
        __error_ids, 
        __error_msgs
    );
    
    // Verify all errors were recorded
    if (error_upload_ids.Count != __affected)
        Error_Helper.LogError(
            string.Format(
                "Le nombre d'éléments en erreur ({0}) ne correspond pas " +
                "au nombre d'éléments mis à jour dans qxp_document_upload ({1})", 
                error_upload_ids.Count, 
                __affected), 
            new InvalidOperationException());
}
```

**What It Does:**
- Updates database records for documents that failed processing
- Stores error messages for user review
- Verifies all updates succeeded

**Leaf Endpoint:** Oracle Database

---

### PHASE 10: CLEANUP

```csharp
finally{
    try{
        // Suppress deletion of quark server document pool directory
        // purge files from quark server without deleting temp upload directory
        Trace_Helper.Log_UploadMessage("Purge des fichiers ajoutés sur quark server");
        
        QXPS_File_Manager.PurgeAddedFiles(false);
    }
    catch(Exception ex){
        Error_Helper.LogError("impossible de purger les fichiers", ex);
    }
    
    Trace_Helper.Log_UploadMessage("Fin check upload");
    Running = false;  // Always reset flag
}
```

#### **LEAF CLASS 10: QXPS_File_Manager.PurgeAddedFiles()**

```csharp
public static void PurgeAddedFiles(bool delete_pool_directory)
{
    try
    {
        // For each file added to Quark server
        foreach(string __fileName in _addedFiles)
        {
            try
            {
                // Delete from Quark server
                QXPInteropQuarkServer.QXPS_Helper.DeleteFile(__fileName);
            }
            catch(Exception ex)
            {
                Trace_Helper.Log_Exception_Message(ex, 
                    "Impossible de supprimer le fichier {0}", __fileName);
            }
        }
        
        // Clear the tracking list
        _addedFiles.Clear();
        
        // Optionally delete upload pool directory
        if(delete_pool_directory)
        {
            // Delete temporary upload folder
        }
    }
    catch(Exception ex)
    {
        Trace_Helper.Log_Exception_Message(ex, "Error purging added files");
    }
}
```

**What It Does:**
- Removes temporary files from QuarkXPress Server
- Cleans up tracked files list
- Maintains system cleanliness

**Leaf Endpoint:** QXPInteropQuarkServer.QXPS_Helper - External Quark Server

---

## LEAF CLASSES SUMMARY

### All Leaf Classes Identified:

| # | Leaf Class | File Location | Purpose | Endpoint Type |
|----|-----------|---------------|---------|----------------|
| 1 | Trace_Helper | QXP.Framework | Logging service | .NET Framework |
| 2 | Document | QXP.Engine.Core | Business object representing document | Business Object |
| 3 | DocumentProxy | QXP.Batch.Core | Data access layer | Oracle Database |
| 4a | QXPIO.FileHelper | QXP.Framework | Local file I/O | File System |
| 4b | QXPS_Helper | QXP.Interop | QuarkXPress communication | External Quark Server |
| 5 | Document_Identity | QXP.Engine.Core | Metadata container | Business Object |
| 5b | QXP_XML | QXP.Engine.Core | XML parsing | Parser |
| 6 | RunProxy | QXP.Batch.Core | Data access layer | Oracle Database |
| 7a | Run_Queue_Item | QXP.Batch.Core | Queue item wrapper | Business Object |
| 7b | Run_Queue | QXP.Batch.Core | Thread-safe collection | In-memory Queue |
| 8 | Worker_Thread | QXP.Batch.Core | Thread management | Thread Synchronization |
| 9 | Error_Helper | QXP.Framework | Error handling | .NET Framework |
| 10 | OraDataReader | QXP.Framework | Data reader | Oracle Client |

---

## EXTERNAL SYSTEMS CALLED

```
QXP.Batch.Core
    │
    ├─ ORACLE DATABASE
    │  ├─ Stored Procedure: QXP_PK_BATCH.Get_New_Upload
    │  ├─ Stored Procedure: QXP_PK_BATCH.Get_Upload_Document
    │  ├─ Stored Procedure: QXP_PK_BATCH.Create_Run_Upload
    │  └─ Stored Procedure: QXP_PK_BATCH.Update_Upload_With_Errors
    │
    ├─ QUARKXPRESS SERVER
    │  ├─ QXPS_Helper.AddFile() - Upload document
    │  ├─ QXPS_Helper.Get_Xml() - Retrieve metadata
    │  └─ QXPS_Helper.DeleteFile() - Cleanup
    │
    ├─ FILE SYSTEM
    │  └─ QXPIO.FileHelper.SaveFile() - Local backup
    │
    └─ FRAMEWORK UTILITIES
       ├─ Trace_Helper - Logging
       ├─ Error_Helper - Error handling
       └─ QXP_XML - XML parsing
```

---

## DATA FLOW DIAGRAM

```
DATABASE
    ↓
[Upload IDs] → DocumentProxy.GetNewUploadDocuments()
    ↓
[Document Objects] ← DocumentProxy.LoadUploadDocuments()
    ↓
For Each Document:
    ├─ [Binary Data] → QXPS_File_Manager.Addfile()
    │                 → QXPS_Helper.AddFile() [QUARK SERVER]
    │
    ├─ [File Path] → Document_Identity_Helper.Get_Identity()
    │              → QXPS_Helper.Get_Xml() [QUARK SERVER]
    │              → QXP_XML Parser
    │              → Document_Identity Object
    │
    └─ [Metadata] → RunProxy.CreateRunUpload() [DATABASE]
                   → [Return: Run ID or Error Code]
                       ├─ If Success: Add to Run_Queue
                       └─ If Error: Add to error_upload_ids
    
[Successful Runs] → Run_Queue
    ↓
Worker_Thread.Set_Loop_Events() [Wake threads]
    ↓
[Failed Uploads] → DocumentProxy.UpdateUploadErrors() [DATABASE]
    ↓
Cleanup: QXPS_File_Manager.PurgeAddedFiles() [QUARK SERVER]
```

---

## KEY CONCEPTS

### 1. **Thread-Safety**
- `Running` flag prevents concurrent execution
- `Run_Queue` uses lock mechanism for thread-safe operations
- `Worker_Thread.Set_Loop_Events()` synchronizes multiple threads

### 2. **Error Handling**
- Try-catch blocks at each phase
- Specific error codes from RunProxy
- Error tracking dictionary for batch update

### 3. **Lazy Execution**
- Upload check is **non-blocking**
- Worker threads are signaled but execute independently
- Main Check() method returns immediately

### 4. **Integration Points**
- **Oracle**: Queries and updates (CRUD operations)
- **QuarkXPress**: Document upload and metadata extraction
- **File System**: Optional local backup
- **Logging**: Trace messages throughout

### 5. **Data Transformations**

```
Raw Upload (bytes) 
    → Document Object 
    → File added to Quark 
    → Metadata extracted 
    → Document_Identity parsed 
    → Run created in database 
    → Run_Queue_Item queued 
    → Worker thread processes it
```

---

## EXECUTION FLOW SUMMARY

```
┌─ Check() called by Watcher
│
├─ Thread-safety check (Running flag)
│
├─ Query DB for new uploads
│  └─ Returns: List<int> (upload IDs)
│
├─ Load full document data
│  └─ Returns: List<Document> (binary + metadata)
│
├─ For each document:
│  │
│  ├─ Upload to Quark Server
│  │
│  ├─ Extract DID metadata
│  │  └─ Returns: Document_Identity object
│  │
│  └─ Create run task
│     ├─ Success: Add to Run_Queue
│     └─ Error: Add to error dictionary
│
├─ Wake worker threads
│  └─ Threads pick up new runs from queue
│
├─ Update database with errors
│
└─ Cleanup Quark files
   └─ Return to Watcher
```

---

## CONCLUSION

**UploadManager.Check()** is a comprehensive **upload processing pipeline** that:

✅ Monitors database for pending uploads  
✅ Retrieves binary document data  
✅ Uploads documents to QuarkXPress Server  
✅ Extracts document metadata (DID)  
✅ Creates executable batch tasks  
✅ Handles errors gracefully  
✅ Cleans up temporary resources  

**Result:** Raw uploaded files become actionable batch processing tasks ready for worker threads to execute.

The method integrates multiple systems (Oracle, QuarkXPress, File System, Logging) while maintaining thread-safety and error resilience through careful exception handling and status tracking.


