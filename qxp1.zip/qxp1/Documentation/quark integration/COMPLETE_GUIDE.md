# WSDL Integration - Quark Engine Project

> Project: `quark-engine` | Package: `com.socgen.sgs.api.quark.engine` | Server: `srvcldvapd001.dns43.socgen`

---

## Part 1: How It Works (Your Specific Setup)

### Architecture

```
Cloud Platform (Your Java App)                Windows Server (srvcldvapd001.dns43.socgen)
┌─────────────────────────────────┐           ┌──────────────────────────────────────┐
│ quark-engine (Spring Boot)      │           │ QXPS  → port 8080                   │
│                                 │  SOAP/    │ QXPSM → port 8090                   │
│ Your code calls:                │  HTTP     │                                      │
│   qxpsmPort.openDoc(...)        │ ───────►  │ Receives SOAP XML                   │
│                                 │           │ Runs QuarkXPress engine              │
│ Generated proxy converts        │  ◄─────── │ Returns SOAP XML response           │
│ method call → SOAP XML          │           │                                      │
│ and SOAP XML → Java objects     │           │                                      │
└─────────────────────────────────┘           └──────────────────────────────────────┘
```

### How Your App "Knows" About Vendor Classes

Your application does NOT have the vendor's actual code. Here's what happens:

1. **WSDL file** (`qxpsmsdk.wsdl`) is an XML contract describing the vendor service — its methods, data types, and endpoint
2. **Maven plugin** (`jaxws-maven-plugin`) reads this WSDL during build
3. **Generates local Java classes** that mirror the vendor's remote types (e.g., `Box`, `TElement`, `QOpenDocData`)
4. **These generated classes are just data holders + a SOAP proxy** — they contain NO vendor business logic
5. **When you call a method** like `port.openDoc(...)`, the generated proxy:
   - Serializes your Java objects → SOAP XML
   - Sends HTTP POST to `srvcldvapd001.dns43.socgen:8090`
   - Receives SOAP XML response
   - Deserializes → Java objects back to you

**Bottom line:** Your app only has the **shape** of vendor classes (fields, method signatures). The **real implementation** runs on the Windows server. The generated proxy is just a network bridge.

### What the WSDL Describes

From your `qxpsmsdk.wsdl`:

| WSDL Element | What It Tells Us | Your Value |
|---|---|---|
| `<wsdl:service name>` | Service name | `QManagerSDKSvcService` |
| `<wsdl:port name>` | Port name | `qxpsmsdk` |
| `<wsdlsoap:address>` | Default endpoint | `http://localhost:8090/quark/services/qxpsmsdk` |
| `<wsdl:operation>` | Available methods | `openDoc`, `newDoc`, `getPreferences`, `setPreferences`, etc. |
| `<xsd:complexType>` | Data types | `Box`, `TElement`, `ConnectionFilterItemAddress`, etc. |

**Important:** The WSDL has `localhost:8090` as default endpoint. At runtime you override this to `srvcldvapd001.dns43.socgen:8090` via your `application.yaml`.

### Role of Helper Classes (ObjectFactory, etc.)

| Generated Class | Role |
|---|---|
| `QManagerSDKSvcService` | Java interface with all callable methods |
| `QManagerSDKSvcService_Service` | Factory that creates the SOAP proxy |
| `Box.java`, `TElement.java`, etc. | Data classes (getters/setters only) |
| `ObjectFactory.java` | JAXB factory for XML serialization — used internally, you never call it |

---

## Part 2: pom.xml Configuration (Fixed for Your Project)

Your current pom.xml plugin needs 2 critical fixes. Here's what to change in your `pom.xml`:

**REPLACE your current plugin configuration with this:**

```xml
<build>
  <plugins>
    <!-- WSDL to Java Code Generator -->
    <plugin>
      <groupId>org.jvnet.jax-ws-commons</groupId>
      <artifactId>jaxws-maven-plugin</artifactId>
      <version>2.3.2</version>
      <executions>
        <execution>
          <id>wsimport-qxpsmsdk</id>
          <phase>generate-sources</phase>
          <goals>
            <goal>wsimport</goal>
          </goals>
          <configuration>
            <!-- 
              CRITICAL FIX: Use classpath-relative path for cloud deployment
              Your current: file://${project.basedir}/src/main/resources/wsdl/qxpsmsdk.wsdl
              Problem: Breaks when deployed as JAR (no file:// access inside JAR)
              Solution: Use classpath resource path
            -->
            <wsdlLocation>/wsdl/qxpsmsdk.wsdl</wsdlLocation>

            <!-- OUTPUT: Generate to src/main/java (same as your current) -->
            <sourceDestDir>${project.build.sourceDirectory}</sourceDestDir>

            <!-- PACKAGE: Classes go to com.quark.qxpsm (same as your current) -->
            <packageName>com.quark.qxpsm</packageName>

            <!-- Keep generated .java files (same as your current) -->
            <keep>true</keep>
          </configuration>
        </execution>
      </executions>
    </plugin>
  </plugins>
</build>
```

### Critical Issues Fixed

| Issue | Your Current | Fixed Version | Impact |
|---|---|---|---|
| **Missing ID** | No `<id>` | `<id>wsimport-qxpsmsdk</id>` | Maven logs show clear execution identification |
| **Missing Phase** | No `<phase>` | `<phase>generate-sources</phase>` | **CRITICAL:** Ensures WSDL classes generate BEFORE compilation |
| **Cloud Deployment** | `file://${project.basedir}/...` | `/wsdl/qxpsmsdk.wsdl` | **CRITICAL:** Works inside JAR when deployed to cloud |

### Why This Matters for Cloud Deployment

With `file://${project.basedir}/...`, the generated `@WebServiceClient` annotation would contain an absolute file path like `file://C:/Users/.../qxpsmsdk.wsdl`. When you deploy your JAR to a cloud server, that path doesn't exist and the service fails to initialize.

With `/wsdl/qxpsmsdk.wsdl`, the annotation references a classpath resource. Since `src/main/resources/wsdl/qxpsmsdk.wsdl` gets packaged into the JAR at `/wsdl/qxpsmsdk.wsdl`, it works everywhere.

---

## Part 3: Where Generated Classes End Up

After running `mvn clean compile`:

```
quark-engine/
├── src/main/java/
│   ├── com/quark/qxpsm/                          ← GENERATED (WSDL classes)
│   │   ├── QManagerSDKSvcService.java
│   │   ├── QManagerSDKSvcService_Service.java
│   │   ├── Box.java
│   │   ├── ObjectFactory.java
│   │   └── ... (other generated types)
│   │
│   └── com/socgen/sgs/api/quark/engine/          ← YOUR CODE
│       ├── Application.java
│       ├── business/
│       ├── config/
│       ├── controller/
│       ├── domain/
│       ├── dto/
│       ├── enums/
│       ├── infra/
│       ├── listener/
│       ├── mapper/
│       ├── repository/
│       └── service/
│
├── src/main/resources/
│   ├── wsdl/
│   │   └── qxpsmsdk.wsdl                         ← INPUT WSDL
│   └── application.yaml
│
└── pom.xml
```

**Generated classes are in `src/main/java/com/quark/qxpsm/`** — same source tree as your `com/socgen/...` packages, so they compile together and are on the same classpath.

---

## Part 4: application.yaml — Endpoint Path Issue

**CRITICAL ISSUE:** Your `application.yaml` and WSDL have different service paths.

### Your Current application.yaml (CORRECT)

```yaml
qxpsm:
  soap:
    endpoint: http://srvcldvapd001.dns43.socgen:8090/qxpsm/services/RequestService
    namespace: http://webservice.manager.quark.com
    connection-timeout: 10000
    timeout: 30000
    max-retries: 3
    retry-backoff-interval: 1000
```

### Your WSDL Default Endpoint (DIFFERENT PATH)

```xml
<wsdlsoap:address location="http://localhost:8090/quark/services/qxpsmsdk" />
```

**The Problem:**
- WSDL says: `/quark/services/qxpsmsdk`
- Your yaml says: `/qxpsm/services/RequestService`

**The Solution:** Keep your yaml as-is if it's working. The `QuarkSoapConfig.java` will override the WSDL endpoint with your yaml configuration.

---

## Part 5: Using Generated Classes in Your Code

### Step 1: Spring Configuration Bean

Create `src/main/java/com/socgen/sgs/api/quark/engine/config/QuarkSoapConfig.java`:

```java
package com.socgen.sgs.api.quark.engine.config;

import com.quark.qxpsm.QManagerSDKSvcService;
import com.quark.qxpsm.QManagerSDKSvcService_Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.ws.BindingProvider;

@Configuration
public class QuarkSoapConfig {

    @Value("${qxpsm.soap.endpoint}")
    private String soapEndpoint;

    @Value("${qxpsm.soap.connection-timeout}")
    private int connectionTimeout;

    @Value("${qxpsm.soap.timeout}")
    private int readTimeout;

    @Bean
    public QManagerSDKSvcService qxpsmServicePort() {
        // 1. Create the service factory (generated from WSDL)
        QManagerSDKSvcService_Service serviceFactory = new QManagerSDKSvcService_Service();

        // 2. Get the SOAP port (proxy)
        QManagerSDKSvcService port = serviceFactory.getQxpsmsdk();

        // 3. Override the endpoint URL from application.yaml
        //    (WSDL has localhost:8090, we point to the real server)
        BindingProvider bp = (BindingProvider) port;
        bp.getRequestContext().put(
            BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
            soapEndpoint
        );

        // 4. Set timeouts
        bp.getRequestContext().put(
            "com.sun.xml.ws.connect.timeout", connectionTimeout
        );
        bp.getRequestContext().put(
            "com.sun.xml.ws.request.timeout", readTimeout
        );

        return port;
    }
}
```

### Step 2: Use in Your Service Classes

In any service under `com.socgen.sgs.api.quark.engine.service`:

```java
package com.socgen.sgs.api.quark.engine.service.impl;

import com.quark.qxpsm.QManagerSDKSvcService;    // Generated from WSDL
import org.springframework.stereotype.Service;

@Service
public class ProcessRunServiceImpl implements ProcessRunService {

    private final QManagerSDKSvcService qxpsmPort;

    public ProcessRunServiceImpl(QManagerSDKSvcService qxpsmPort) {
        this.qxpsmPort = qxpsmPort;  // Spring injects the bean from QuarkSoapConfig
    }

    public void processDocument(String docName, String sessionId) {
        // Call the vendor service — proxy handles SOAP over network
        qxpsmPort.openDoc(docName, "srvcldvapd001.dns43.socgen", 8090, sessionId);
    }
}
```

### Step 3: Use in Business Classes

In any business class under `com.socgen.sgs.api.quark.engine.business`:

```java
package com.socgen.sgs.api.quark.engine.business;

import com.quark.qxpsm.QManagerSDKSvcService;    // Generated
import org.springframework.stereotype.Component;

@Component
public class GetGabaritBusiness {

    private final QManagerSDKSvcService qxpsmPort;

    public GetGabaritBusiness(QManagerSDKSvcService qxpsmPort) {
        this.qxpsmPort = qxpsmPort;
    }

    // Use generated classes anywhere in your business logic
}
```

---

## Part 6: Complete Request Flow (Your Setup)

```
Your Code (cloud):
  qxpsmPort.openDoc("Document1.qxp", "srvcldvapd001.dns43.socgen", 8090, sessionId)
     ↓
Generated Proxy (com.quark.qxpsm):
  Serializes parameters → SOAP XML:
  <soap:Envelope>
    <soap:Body>
      <openDoc>
        <docName>Document1.qxp</docName>
        <host>srvcldvapd001.dns43.socgen</host>
        <port>8090</port>
        <sessionId>abc123</sessionId>
      </openDoc>
    </soap:Body>
  </soap:Envelope>
     ↓
HTTP POST to: http://srvcldvapd001.dns43.socgen:8090/qxpsm/services/RequestService
     ↓
Windows Server (srvcldvapd001.dns43.socgen):
  QXPSM service receives request
  Runs QuarkXPress engine internally
  Returns SOAP response
     ↓
Generated Proxy:
  Deserializes SOAP XML → Java objects
     ↓
Your Code:
  Receives result, continues business logic
```

---

## Part 7: Troubleshooting

| Problem | Fix |
|---|---|
| `package com.quark.qxpsm does not exist` | Run `mvn clean generate-sources` first |
| WSDL file not found during build | Verify `src/main/resources/wsdl/qxpsmsdk.wsdl` exists |
| IDE red lines on imports | IntelliJ: right-click → Maven → Reimport |
| `javax.xml.ws.WebServiceException` at runtime | Check `qxpsm.soap.endpoint` in `application.yaml` — is the server reachable? |
| Connection timeout to vendor service | Verify `srvcldvapd001.dns43.socgen:8090` is accessible from your deployment environment |
| Generated classes have wrong endpoint | Check `<wsdlLocation>` in pom.xml uses classpath path `/wsdl/qxpsmsdk.wsdl`, not `file://` |

---

## Part 8: Checklist

- [ ] WSDL file exists at `src/main/resources/wsdl/qxpsmsdk.wsdl`
- [ ] pom.xml has `jaxws-maven-plugin` with correct config (see Part 2)
- [ ] Run `mvn clean compile` — no errors
- [ ] Generated classes appear in `src/main/java/com/quark/qxpsm/`
- [ ] `application.yaml` has `qxpsm.soap.endpoint` pointing to real server
- [ ] `QuarkSoapConfig.java` created with endpoint override
- [ ] Service classes inject `QManagerSDKSvcService` bean
- [ ] Test connectivity to `srvcldvapd001.dns43.socgen:8090`

---

## Part 9: EXACT IMPLEMENTATION STEPS FOR YOUR PROJECT

### Step 1: Update pom.xml (Copy-Paste Ready)

Replace your current `jaxws-maven-plugin` configuration with this:

```xml
<plugin>
  <groupId>org.jvnet.jax-ws-commons</groupId>
  <artifactId>jaxws-maven-plugin</artifactId>
  <version>2.3.2</version>
  <executions>
    <execution>
      <id>wsimport-qxpsmsdk</id>
      <phase>generate-sources</phase>
      <goals>
        <goal>wsimport</goal>
      </goals>
      <configuration>
        <wsdlLocation>/wsdl/qxpsmsdk.wsdl</wsdlLocation>
        <packageName>com.quark.qxpsm</packageName>
        <sourceDestDir>${project.build.sourceDirectory}</sourceDestDir>
        <keep>true</keep>
      </configuration>
    </execution>
  </executions>
</plugin>
```

### Step 2: Generate Classes

```bash
mvn clean generate-sources
```

**Expected Result:** Classes appear in `src/main/java/com/quark/qxpsm/`

### Step 3: Create QuarkSoapConfig.java

File: `src/main/java/com/socgen/sgs/api/quark/engine/config/QuarkSoapConfig.java`

```java
package com.socgen.sgs.api.quark.engine.config;

import com.quark.qxpsm.QManagerSDKSvcService;
import com.quark.qxpsm.QManagerSDKSvcService_Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.ws.BindingProvider;

@Configuration
public class QuarkSoapConfig {

    @Value("${qxpsm.soap.endpoint}")
    private String soapEndpoint;

    @Value("${qxpsm.soap.connection-timeout}")
    private int connectionTimeout;

    @Value("${qxpsm.soap.timeout}")
    private int readTimeout;

    @Bean
    public QManagerSDKSvcService qxpsmServicePort() {
        QManagerSDKSvcService_Service serviceFactory = new QManagerSDKSvcService_Service();
        QManagerSDKSvcService port = serviceFactory.getQxpsmsdk();

        BindingProvider bp = (BindingProvider) port;
        bp.getRequestContext().put(
            BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
            soapEndpoint
        );

        bp.getRequestContext().put(
            "com.sun.xml.ws.connect.timeout", connectionTimeout
        );
        bp.getRequestContext().put(
            "com.sun.xml.ws.request.timeout", readTimeout
        );

        return port;
    }
}
```

### Step 4: Use in Your Existing Services

In `ProcessRunServiceImpl.java` (or any service):

```java
package com.socgen.sgs.api.quark.engine.service.impl;

import com.quark.qxpsm.QManagerSDKSvcService;
import org.springframework.stereotype.Service;

@Service
public class ProcessRunServiceImpl implements ProcessRunService {

    private final QManagerSDKSvcService qxpsmPort;

    public ProcessRunServiceImpl(QManagerSDKSvcService qxpsmPort) {
        this.qxpsmPort = qxpsmPort;
    }

    // Now you can use qxpsmPort.methodName() anywhere
    public void callQuarkService() {
        // Example: qxpsmPort.openDoc(...);
    }
}
```

### Step 5: Verify Configuration Match

Your `application.yaml` is already correctly configured:
- Server: `srvcldvapd001.dns43.socgen`
- Port: `8090`
- Path: `/qxpsm/services/RequestService`
- Dependencies: Already include `spring-boot-starter-web-services`, `jaxb-api`, `jaxws-rt`

### Step 6: Test

Run:
```bash
mvn clean compile
mvn spring-boot:run
```

Check logs for any SOAP connection errors.
