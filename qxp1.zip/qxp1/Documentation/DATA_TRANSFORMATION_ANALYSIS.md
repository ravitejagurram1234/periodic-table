# Data Transformation Flow Analysis: Database to HTML Dropdown

## Overview
This document explains **HOW** the data is being transformed from the database query result to the final HTML dropdown output.

---

## Data Source

**Database Query Result** from `QXP_PK_CHARGEMENT.GetListeSousCategorie(idCategorie=6)`:
```
323     DICI
63      Prospectus
297     Rapport_Semi_Annuel
11      sc11
12      sc12
13      sc13
14      sc14
15      sc15
16      sc16
17      sc17
```

**Actual HTML Output in UI**:
```html
<option selected="selected" value="-1"></option>
<option value="17">Composition d'actif</option>
<option value="323">DICI</option>
<option value="11">Plaquette</option>
<option value="63">Prospectus</option>
<option value="14">Prospectus partie B</option>
<option value="12">Rapport annuel</option>
<option value="13">Rapport annuel simplifié</option>
<option value="297">Rapport semi-annuel</option>
<option value="16">Statistiques Monaco</option>
<option value="15">Statistiques Suisse</option>
```

**Key Observation**: The display text is completely different from what the database returns:
- DB returns: `sc11`, `sc12`, `sc13`, `sc14`, `sc15`, `sc16`, `sc17`
- UI displays: `Plaquette`, `Rapport annuel`, `Rapport annuel simplifié`, `Prospectus partie B`, `Statistiques Suisse`, `Statistiques Monaco`, `Composition d'actif`

This transformation happens through a **localization/translation layer**.

---

## Step-by-Step Transformation

### Step 1: Data Retrieval from Oracle Database
**File**: `QXP.Web/Proxy/ProxyDocument.cs` → `GetListeSousCategorie(int idCategorie, bool checkAtLeastOneDocument)`

The database query fetches raw data with placeholder codes:
```
ID          Label
323         DICI
63          Prospectus
297         Rapport_Semi_Annuel
11          sc11
12          sc12
13          sc13
14          sc14
15          sc15
16          sc16
17          sc17
```

```csharp
// Line 626: Call to Oracle stored procedure
__sql = string.Concat(PACKAGE, "GetListeSousCategorie");
__sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

// Execute query and iterate through results
using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
{
    while (__odr.Read())
    {
        // KEY TRANSFORMATION STEP: Label Translation
        string __libelleSousCategorie = QXPAPP.Application.Resources.GetLabel(
            "SousCategorie", 
            __odr["libelle_sous_categorie"]   // Raw value from DB (e.g., "sc11", "sc12", etc.)
        );
```

**Transformation 1: Label Translation via Localization Service**
- **Input**: `libelle_sous_categorie` from database (e.g., `"sc11"`, `"sc12"`, `"sc13"`, etc.)
- **Process**: `QXPAPP.Application.Resources.GetLabel("SousCategorie", value)`
  - Section: `"SousCategorie"`
  - Group/Key: Raw database value (e.g., `"sc11"`, `"sc12"`)
  - Calls `ResourceManager.Get(section, group, Label_Key)` which constructs pattern: `"SousCategorie.sc11.Label"`
  - ResourceManager loads localization data from Oracle database via `ResourcesProxy.GetResources()`
  - Looks up the pattern in the localization table and returns the French translation
- **Output**: French localized labels:
  - `"sc11"` → `"Plaquette"`
  - `"sc12"` → `"Rapport annuel"`
  - `"sc13"` → `"Rapport annuel simplifié"`
  - `"sc14"` → `"Prospectus partie B"`
  - `"sc15"` → `"Statistiques Suisse"`
  - `"sc16"` → `"Statistiques Monaco"`
  - `"sc17"` → `"Composition d'actif"`

### Step 2: Business Object Creation
**File**: `QXP.Web/BusinessObject/SousCategorie.cs`

```csharp
QXPBusiness.SousCategorie __sousCategorie = new QXPBusiness.SousCategorie
(
      __odr["id_sous_categorie"]           // Numeric ID (e.g., 323)
    , __libelleSousCategorie                // Translated label (e.g., "DICI")
);
__listSousCategorie.Add(__sousCategorie);
```

**Result**: A `ListeSousCategorie` collection (List of SousCategorie objects)

Each `SousCategorie` object contains:
- `idSousCategorie`: ID from database (e.g., 323)
- `libelleSousCategorie`: Translated label (e.g., "DICI")

---

### Step 3: UI Control Binding
**File**: `QXP.WebSite/Chargement/Gabarit/CreationDocumentGabarit.cs` → `ComponentDataBind()`

```csharp
_ddlSousCategories.DataSource = this.ProxyDocument.GetListeSousCategorie(6);
_ddlSousCategories.DataValueField = "idSousCategorie";      // Maps to option value
_ddlSousCategories.DataTextField = "libelleSousCategorie";  // Maps to option display text
```

At this point:
- **DataSource**: List of SousCategorie objects (10 items from the database query)
- **DataValueField**: Property name to extract for HTML `value` attribute
- **DataTextField**: Property name to extract for HTML display text

---

### Step 4: Data Binding Engine Processes Items
**File**: `QXP.Framework.Web/UI/Controls/Basic/DropDownList/BasicDropDownList.cs` → `DataBind()`

```csharp
// Line 119-125: Extract ItemText using reflection
__itemText = GetDataTextField(__value);  // Gets value from libelleSousCategorie property

// Line 128-129: Extract ItemValue using DataBinder reflection
if (Validation.IsSet(this.DataValueField))
    __itemValue = Conversion.ToString(
        QXPData.DataBinder.Eval(__value, this.DataValueField, null)
    );  // Gets value from idSousCategorie property
```

**Transformation 2: Reflection-based Property Extraction**
- Iterates through each `SousCategorie` object in the DataSource
- Uses reflection to extract property values:
  - Value: `Eval(sousCategorie, "idSousCategorie")` → e.g., "323"
  - Text: `GetDataTextField(sousCategorie)` → e.g., "DICI"
- Creates a `ListItem` for each entry

---

### Step 5: Sorting
**File**: `QXP.Framework.Web/UI/Controls/Basic/DropDownList/BasicDropDownList.cs` → Line 151

```csharp
base.Sort(__listitems);
```

**Transformation 3: Items are Sorted**
- The `Sort()` method sorts the ListItems 
- **Default behavior**: Usually sorts by display text (alphabetically)
- This explains why the final HTML output is different from the database query order:
  - Database order: 323, 63, 297, 11, 12, 13, 14, 15, 16, 17
  - Sorted order: 17 (Composition d'actif), 323 (DICI), 11 (Plaquette), 63 (Prospectus), 14 (Prospectus partie B), 12 (Rapport annuel), 13 (Rapport annuel simplifié), 297 (Rapport semi-annuel), 16 (Statistiques Monaco), 15 (Statistiques Suisse)

---

### Step 6: HTML Rendering
**ASP.NET Standard**: The control renders as HTML `<select>` with `<option>` elements

```html
<select name="ctl16$ctl14$ctl07$_" id="ctl16_ctl14_ctl07__" ...>
    <option selected="selected" value="-1"></option>  <!-- Empty selection option -->
    <option value="17">Composition d'actif</option>
    <option value="323">DICI</option>
    <option value="11">Plaquette</option>
    <option value="63">Prospectus</option>
    <!-- ... etc ... sorted alphabetically by text -->
</select>
```

---

## Data Transformation Summary

```
┌─────────────────────────────────────────────────────────────────────────┐
│ 1. DATABASE QUERY                                                       │
│    (OrderBy: Query definition order)                                    │
│    323, 63, 297, 11, 12, 13, 14, 15, 16, 17                           │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│ 2. LABEL TRANSLATION (Resources.GetLabel)                              │
│    "Rapport_Semi_Annuel" → "Rapport semi-annuel"                       │
│    Converts DB codes to user-friendly labels                            │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│ 3. BUSINESS OBJECT CREATION (SousCategorie)                            │
│    Creates collection of objects with:                                  │
│    - idSousCategorie (for dropdown value)                               │
│    - libelleSousCategorie (for dropdown display text)                   │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│ 4. UI BINDING CONFIGURATION                                            │
│    DataValueField = "idSousCategorie"                                   │
│    DataTextField = "libelleSousCategorie"                               │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│ 5. REFLECTION-BASED PROPERTY EXTRACTION                                │
│    For each object, extract:                                            │
│    - Value: object.idSousCategorie                                      │
│    - Text: object.libelleSousCategorie                                  │
└────────────────────────────┬────────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│ 6. SORTING                                                              │
│    Sort ListItems alphabetically by display text                        │
│    17(A), 323(D), 11(P), 63(P), 14(P), 12(R), 13(R), 297(R), 16(S), 15(S)
└────────────────────────────┬────────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────────┐
│ 7. HTML RENDERING                                                       │
│    <option value="17">Composition d'actif</option>                      │
│    <option value="323">DICI</option>                                    │
│    ... (sorted alphabetically)                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Key Transformations

| # | Transformation | Input | Process | Output |
|---|---|---|---|---|
| 1 | **Localization Lookup** | `sc11` (DB code) | `Resources.GetLabel("SousCategorie", "sc11")` queries Oracle localization table | `Plaquette` (French label) |
| 2 | **Object Mapping** | Raw data rows with translated labels | Create SousCategorie objects | Object collection with translated labels |
| 3 | **Property Binding** | SousCategorie objects | Reflection to extract properties (idSousCategorie, libelleSousCategorie) | Distinct value/text pairs |
| 4 | **Sorting** | Unsorted ListItems | `Sort()` alphabetically by text | Sorted ListItems (Composition d'actif, DICI, Plaquette, Prospectus, ...) |
| 5 | **HTML Rendering** | Sorted ListItems | ASP.NET rendering | `<option>` HTML elements with sorted values |

---

## Why the Output Order is Different

The database returns data in one order:
```
323, 63, 297, 11, 12, 13, 14, 15, 16, 17
```

But the HTML output shows a different order:
```
17, 323, 11, 63, 14, 12, 13, 297, 16, 15
```

**Reason**: The `BasicDropDownList.DataBind()` method calls `base.Sort(__listitems)` (line 151), which **sorts the items alphabetically by their display text** before rendering them to HTML.

---

## Code Flow Diagram

```
ProxyDocument.GetListeSousCategorie()
    ↓
    → Query Oracle DB
    ↓
    → GetLabel() translation for each row
    ↓
    → Create SousCategorie objects
    ↓
    → Return ListeSousCategorie collection
    ↓
CreationDocumentGabarit.ComponentDataBind()
    ↓
    → Set _ddlSousCategories.DataSource
    ↓
    → Set DataValueField = "idSousCategorie"
    ↓
    → Set DataTextField = "libelleSousCategorie"
    ↓
BasicDropDownList.DataBind()
    ↓
    → Iterate through DataSource
    ↓
    → For each object:
       - Extract value via Eval("idSousCategorie")
       - Extract text via GetDataTextField()
       - Create ListItem
    ↓
    → Sort all ListItems alphabetically by text
    ↓
    → Render as HTML <option> elements
```

---

## Conclusion

The data transformation involves **6 main steps**:
1. **Database Query** - Retrieves raw data in query order
2. **Label Translation** - Converts DB codes to user-friendly labels
3. **Business Object Creation** - Wraps data in SousCategorie objects
4. **Binding Configuration** - Specifies which properties to use as value/text
5. **Reflection Property Extraction** - Extracts the configured properties
6. **Sorting** - Sorts items alphabetically before rendering to HTML

The final HTML dropdown order differs from the database order because the **Sort()** method automatically sorts items alphabetically by their display text.

---

## Detailed Localization Mechanism

### How Label Translation Works

When `Resources.GetLabel("SousCategorie", "sc11")` is called:

1. **ResourceManager** (`QXP.Framework/Resources/ResourceManager.cs`) handles the lookup
2. **Pattern Construction**: Builds lookup key as `"SousCategorie.sc11.Label"`
3. **Cache Check**: Checks if localization data for current culture (e.g., "FR" for French) is already loaded
4. **Data Loading**: If not cached, calls `ResourcesProxy.GetResources(cultureCode)` 
5. **ResourcesProxy** (`QXP.Framework/Resources/Proxy/ResourcesProxy.cs`) queries Oracle:
   ```csharp
   public Hashtable GetResources(string cultureCode)
   {
       // Calls Oracle stored procedure: GetResources
       // Parameters: p_culture_code (e.g., "FR")
       string __sql = string.Concat(this.Package, "GetResources");
       
       // Result set contains two columns:
       // marker (e.g., "SOUSCATEGORIE.SC11.LABEL")
       // value (e.g., "Plaquette")
       
       while (__odr.Read())
       {
           __marker = __odr["marker"];  // e.g., "SOUSCATEGORIE.SC11.LABEL"
           __value = __odr["value"];    // e.g., "Plaquette"
           __resources[__marker] = __value;
       }
       return __resources;  // Returns Hashtable indexed by marker
   }
   ```
6. **Lookup and Cache**: Stores all translations in a Hashtable, indexed by marker string (uppercase)
7. **Return**: Returns the translated value from the Hashtable

### Localization Table in Oracle Database

The localization data in the Oracle database is stored in resource tables with structure:

| Marker | Culture | Value |
|--------|---------|-------|
| SOUSCATEGORIE.SC11.LABEL | FR | Plaquette |
| SOUSCATEGORIE.SC12.LABEL | FR | Rapport annuel |
| SOUSCATEGORIE.SC13.LABEL | FR | Rapport annuel simplifié |
| SOUSCATEGORIE.SC14.LABEL | FR | Prospectus partie B |
| SOUSCATEGORIE.SC15.LABEL | FR | Statistiques Suisse |
| SOUSCATEGORIE.SC16.LABEL | FR | Statistiques Monaco |
| SOUSCATEGORIE.SC17.LABEL | FR | Composition d'actif |
| SOUSCATEGORIE.DICI.LABEL | FR | DICI |
| SOUSCATEGORIE.PROSPECTUS.LABEL | FR | Prospectus |
| SOUSCATEGORIE.RAPPORT_SEMI_ANNUEL.LABEL | FR | Rapport semi-annuel |

### Complete Translation Flow

```
Input DB value: "sc11"
    ↓
Call: GetLabel("SousCategorie", "sc11")
    ↓
ResourceManager.Get("SousCategorie", "sc11", Label_Key)
    ↓
Build pattern: "SousCategorie.sc11.Label"
    ↓
Check if FR culture data is loaded in cache
    ↓ [Not cached]
Call: ResourcesProxy.GetResources("FR")
    ↓
Execute Oracle: GetResources(p_culture_code="FR")
    ↓
Load all translation entries into Hashtable
    ↓
Cache Hashtable in ResourceManager._resources["FR"]
    ↓
Look up in Hashtable: _resources["FR"]["SOUSCATEGORIE.SC11.LABEL"]
    ↓
Return: "Plaquette"
```

---

## Complete End-to-End Example

**Starting with one database row:**

| id_sous_categorie | libelle_sous_categorie |
|---|---|
| 11 | sc11 |

**Step 1: Fetch and Translate**
```
→ Query returns: id_sous_categorie=11, libelle_sous_categorie="sc11"
→ Call: Resources.GetLabel("SousCategorie", "sc11")
→ Look up in Oracle localization table
→ Return: "Plaquette"
```

**Step 2: Create Business Object**
```csharp
new SousCategorie(
    idSousCategorie = 11,
    libelleSousCategorie = "Plaquette"  // Translated from "sc11"
)
```

**Step 3: Bind to UI Control**
- DataValueField extracts: `11`
- DataTextField extracts: `"Plaquette"`
- Creates ListItem: `<ListItem Value="11" Text="Plaquette" />`

**Step 4: Sorting**
- Among all 10 items, "Plaquette" sorts alphabetically as position 3
- Items starting with "C", "D", "P", "P", "P", "R", "R", "R", "S", "S"

**Step 5: HTML Output**
```html
<option value="11">Plaquette</option>
```

---

## Summary Table: Database to UI Transformation

| Step | Input | Transformation | Output |
|---|---|---|---|
| 1 (DB Query) | `(11, "sc11")` | Execute GetListeSousCategorie SP | 10 rows of ID + code pairs |
| 2 (Translate) | `"sc11"` | `Resources.GetLabel("SousCategorie", "sc11")` → Oracle lookup | `"Plaquette"` |
| 3 (Object) | `(11, "Plaquette")` | Create SousCategorie instance | SousCategorie object |
| 4 (Binding) | SousCategorie list | Reflection extract idSousCategorie, libelleSousCategorie | ListItem collection |
| 5 (Sort) | `(11, "Plaquette"), (12, "Rapport annuel"), ...` | Sort by Text (alphabetically) | Sorted ListItem collection |
| 6 (HTML) | Sorted ListItems | ASP.NET rendering engine | `<option value="11">Plaquette</option>` |

---

## Conclusion

The data transformation from database to HTML dropdown involves **7 key steps**:

1. **Oracle Query** - `GetListeSousCategorie()` returns raw ID + code pairs
2. **Localization Translation** - `Resources.GetLabel()` converts codes to French labels via Oracle resource tables
3. **Business Object Creation** - Wraps translated data in SousCategorie objects
4. **UI Binding Configuration** - Specifies DataValueField and DataTextField properties
5. **Reflection Property Extraction** - BasicDropDownList extracts object properties
6. **Alphabetical Sorting** - Items sorted by display text before rendering
7. **HTML Rendering** - ASP.NET renders sorted items as `<option>` elements

**Key Insight**: The dropdown appears to have different data than the database because:
- Database stores compact codes (`sc11`, `sc12`, etc.) for size efficiency
- Localization layer translates these codes to user-friendly French labels
- UI automatically sorts translated labels alphabetically
- Result: User sees sorted, translated labels rather than database codes

This design separates data storage (codes) from presentation (translated labels), making it easy to support multiple languages and add new categories without database schema changes.
