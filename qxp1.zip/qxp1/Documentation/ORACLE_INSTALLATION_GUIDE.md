# Oracle Connectivity - Quick Reference & Configuration Reconciliation Guide
## Oracle Client 12.1.0.2 Installation Checklist

---

## QUICK REFERENCE TABLES

### 1. All Projects Using Oracle.DataAccess

| Project Name | .csproj File | Oracle.DataAccess Line | Version |
|---|---|---|---|
| QXP.Audit | QXP.Audit.csproj | 70 | 4.121.2.0 |
| QXP.Batch.Core | QXP.Batch.Core.csproj | 72 | 4.121.2.0 |
| QXP.Engine | QXP.Engine.csproj | 65 | 4.121.2.0 |
| QXP.Engine.Core | QXP.Engine.Core.csproj | 59 | 4.121.2.0 |
| QXP.Fiscalite | QXP.Fiscalite.csproj | 58 | 4.121.2.0 |
| QXP.Framework | QXP.Framework.csproj | 232 | 4.121.2.0 |
| QXP.Framework.Web | QXP.Framework.Web.csproj | 67 | 4.121.2.0 |
| QXP.GP | QXP.GP.csproj | 59 | 4.121.2.0 |
| QXP.Import | QXP.Import.csproj | 62 | 4.121.2.0 |
| QXP.Interop | QXP.Interop.csproj | 59 | 4.121.2.0 |
| QXP.KII | QXP.KII.csproj | 58 | 4.121.2.0 |
| QXP.RessourcesManager | QXP.RessourcesManager.csproj | 60 | 4.121.2.0 |
| QXP.SQL | QXP.SQL.csproj | 47 | 4.121.2.0 |
| QXP.Structure | QXP.Structure.csproj | 58 | 4.121.2.0 |
| QXP.Upload | QXP.Upload.csproj | 91 | 4.121.2.0 |
| QXP.Web | QXP.Web.csproj | 53 | 4.121.2.0 |
| QXP.WebSite | QXP.WebSite.csproj | 67 | 4.121.2.0 |

### 2. All Config Files with DBConnection Encrypted Strings

| Config File | File Path | DBConnection Line | Environments |
|---|---|---|---|
| Web.Config | QXP.WebSite\Web.Config | 23 | DEV (active), HBB (comment), PROD (comment) |
| App.config | QXP.Batch\App.config | 67 | DEV (active), HBB (comment), PROD (comment) |
| App.config | QXP.Upload\App.config | 18 | DEV only |
| App.config | QXP.Cleaner\App.config | 21 | DEV (active), HBB (comment), PROD (comment) |
| app.config | QXP.Engine\app.config | 62 | DEV (active), HBB (comment), PROD (comment) |
| app.config | QXP.RessourcesManager\app.config | 11 | DEV only |
| AppConfigReleaseTemplate.config | QXP.Batch\AppConfigReleaseTemplate.config | 77 | Placeholder: {{DBConnection}} |
| AppConfigReleaseTemplate.config | QXP.Upload\AppConfigReleaseTemplate.config | 14 | Placeholder: {{DBConnection}} |
| AppConfigReleaseTemplate.config | QXP.Cleaner\AppConfigReleaseTemplate.config | 22 | Placeholder: {{DBConnection}} |

### 3. All Code Files Using Oracle.DataAccess.Client

| File Path | Line # | Type | Context |
|---|---|---|---|
| QXP.Framework\Data\DataBase\Oracle\OracleClient.cs | 6 | using | Core OraClient wrapper |
| QXP.Web\Proxy\ProxyMenus.cs | 3 | using | Habilitation/menu proxy |
| QXP.Web\Proxy\ProxyStructure.cs | 3 | using | Structure proxy |
| QXP.Web\Proxy\ProxyHabilitation.cs | 5 | using | Habilitation security proxy |
| QXP.Web\Proxy\ProxyDocument.cs | 5 | using | Document proxy |
| QXP.Web\Proxy\ProxySuivi.cs | 7 | using | Tracking proxy |
| QXP.Web\Proxy\ProxyPortefeuille.cs | 4 | using | Portfolio proxy |
| QXP.Web\Proxy\ProxyReference.cs | 5 | using | Reference proxy |
| QXP.Web\Proxy\ProxyGabarit.cs | 6 | using | Template proxy |
| QXP.Web\Proxy\ProxySociete.cs | 4 | using | Company proxy |
| QXP.Web\Instrument\Proxy\ProxyInstrument.cs | 3 | using | Instrument proxy |
| QXP.Web\Instrument\Classification\Proxy\ProxyClassification.cs | 4 | using | Classification proxy |
| QXP.Web\Instrument\TER\Proxy\ProxyTER.cs | 5 | using | TER proxy |
| QXP.Web\Instrument\SRRI\Proxy\ProxySRRI.cs | 4 | using | SRRI proxy |
| QXP.Structure\Proxy\ProxyStructure.cs | 3 | using | Structure tier proxy |
| QXP.TemplateAndSnippet\Proxy\QXPProxyClass.cs | 6 | using | Template proxy class |

---

## PRE-INSTALLATION VERIFICATION

### Windows Environment Prerequisites

```
[ ] Oracle 12.1.0.2 Client (12c Release 1) binaries available
[ ] 64-bit (x64) platform - AMD64 specified in all .csproj files
[ ] Windows Server 2008 R2 or later (for .NET Framework 4.6.1 support)
[ ] .NET Framework 4.6.1 installed on target server
[ ] IIS 7.5+ if hosting as ASP.NET application
```

### Oracle Installation Path

Standard install path (example - adjust as needed):
```
C:\oracle\product\12.1.0\client_1\
```

Expected after installation:
```
C:\oracle\product\12.1.0\client_1\bin\oci.dll          (OCI.dll)
C:\oracle\product\12.1.0\client_1\bin\ocijdbc12.dll
C:\oracle\product\12.1.0\client_1\bin\oracore12.dll
C:\oracle\product\12.1.0\client_1\network\admin\tnsnames.ora
```

### Registry Configuration Required

Windows Registry keys (Oracle 12c):
```
HKLM\SOFTWARE\ORACLE\
  KEY: ORACLE_HOME (type: REG_SZ)
  VALUE: C:\oracle\product\12.1.0\client_1

HKLM\SOFTWARE\Oracle\Key_OraClient12Home1\
  (Various Oracle configuration keys auto-created by installer)
```

Verify via:
```powershell
reg query "HKLM\SOFTWARE\ORACLE" /s
```

---

## POST-INSTALLATION VERIFICATION

### Step 1: Verify ODP.NET Assembly Version

```powershell
# Location of Oracle.DataAccess.dll
# Typically in application bin directory or GAC
gacutil /l Oracle.DataAccess

# Should show:
# Oracle.DataAccess, Version=4.121.2.0, Culture=neutral, PublicKeyToken=89b483f429c47342

# File properties
(Get-Item "C:\path\to\Oracle.DataAccess.dll").VersionInfo
# FileVersion should be 4.121.2.0
```

### Step 2: Verify OCI Client Libraries in PATH

```powershell
# Test if oci.dll can be found
where /R "C:\Windows\System32" oci.dll
where /R "C:\Oracle\product\12.1.0\client_1\bin" oci.dll

# Or check PATH environment variable
$env:PATH -split ';' | Select-String -Pattern oracle
```

Required libraries in PATH:
```
oci.dll
ocijdbc12.dll
oracore12.dll
oraocci12.dll
oraocciXX.dll (dependent on application needs)
```

### Step 3: Verify Registry Configuration

```powershell
$regPath = "HKLM:\SOFTWARE\ORACLE"
if (Test-Path $regPath) {
    Get-ItemProperty $regPath | Select-Object ORACLE_HOME
    Write-Host "✓ Oracle Home registered"
} else {
    Write-Host "✗ Oracle Home NOT registered"
}
```

### Step 4: Verify tnsnames.ora Configuration

```
Location: C:\oracle\product\12.1.0\client_1\network\admin\tnsnames.ora
          (or TNS_ADMIN environment variable location)
```

Expected format (example):
```
DEVDB =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = oracle.example.com)(PORT = 1521))
    (CONNECT_DATA =
      (SERVICE_NAME = devdb)
    )
  )

HBBDB =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = oracle.hbb.com)(PORT = 1521))
    (CONNECT_DATA =
      (SERVICE_NAME = hbbdb)
    )
  )

PRODDB =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = oracle.prod.com)(PORT = 1521))
    (CONNECT_DATA =
      (SERVICE_NAME = proddb)
    )
  )
```

Verify TNS connectivity:
```powershell
# Using tnsping utility (if available in PATH)
tnsping DEVDB
tnsping HBBDB
tnsping PRODDB
```

### Step 5: Verify .NET Environment

```powershell
# Check .NET Framework version
Get-ChildItem "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full"

# Should show .NET Framework 4.6.1 or later
reg query "HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" /v Release
# Value should be 394254 (.NET Framework 4.6.1)
```

### Step 6: Verify IIS Configuration (if ASP.NET)

```powershell
# Check Application Pool architecture
Get-WebAppPoolState "QXP" | Select-Object Name, Status
Get-ItemProperty "IIS:\AppPools\QXP" | Select-Object Name, Enable32BitAppOn

# Output should show:
# Enable32BitAppOn: False  (meaning 64-bit pool is enabled)

# If Enable32BitAppOn is True, change it:
Set-ItemProperty "IIS:\AppPools\QXP" -Name Enable32BitAppOn -Value $false
Restart-WebAppPool -Name "QXP"
```

---

## CONNECTION STRING DECRYPTION

### Decryption Tool (PowerShell)

```powershell
# Add reference to QXP.Framework.dll
[Reflection.Assembly]::LoadFile("C:\path\to\QXP.Framework.dll")

# Decrypt a connection string
$encryptedCS = "DyoBeCMNR4nBXkuZL01ESiJ5SLB+iciGZ40pOeI/QoK5Gtu7mre2BZI9o8zJpT+Zr8AheSv6aGgxpLwofYqQOAbSb986qw9/3qUx0zpqQuTREI/jFFO/qzh9GMP/Ad0Q"
$decrypted = [QXP.Framework.Security.Crypt]::DecryptStringFK($encryptedCS)
Write-Host "Decrypted: $decrypted"
```

### Expected Decrypted Format

```
User Id=<oracle_user>;Password=<oracle_password>;Data Source=<TNS_ALIAS>;Pooling=true;Max Pool Size=10;...
```

**Example (hypothetical):**
```
User Id=QXP_APP;Password=SecurePassword123;Data Source=DEVDB;Pooling=true;Max Pool Size=10
```

**Key Components:**
- `User Id=` - Oracle database username
- `Password=` - Oracle database password
- `Data Source=` - TNS alias name (references tnsnames.ora)
- `Pooling=true` - Connection pooling enabled
- `Max Pool Size=10` - Max connections in pool

---

## DEPLOYMENT CHECKLIST

### Pre-Deployment

- [ ] Oracle 12.1.0.2 client installed on target server
- [ ] Oracle.DataAccess.dll v4.121.2.0 available
- [ ] .NET Framework 4.6.1 installed on target server
- [ ] tnsnames.ora configured with all required TNS aliases
- [ ] Windows registry ORACLE_HOME key set correctly
- [ ] System PATH includes Oracle bin directory
- [ ] IIS Application Pool set to 64-bit (if ASP.NET)
- [ ] Firewall allows outbound connections on Oracle listener port (default 1521)

### Deployment

- [ ] Deploy all application binaries to target
- [ ] Deploy/update configuration files (.config)
- [ ] Verify Oracle.DataAccess.dll assembly version in deployed directory
- [ ] Verify tnsnames.ora contains all required TNS aliases

### Post-Deployment Validation

- [ ] Test each config environment (DEV, HBB, PROD) connection strings
- [ ] Verify IIS Application Pool starts without errors
- [ ] Check Windows Event Viewer for OracleException entries
- [ ] Test database connectivity from application:
  ```
  QXP.WebSite → OraClient → Oracle Database
  QXP.Batch → OraClient → Oracle Database
  QXP.Upload → OraClient → Oracle Database
  QXP.Engine → OraClient → Oracle Database
  ```
- [ ] Monitor initial requests for binding redirect errors
- [ ] Verify no "FileNotFoundException" for oci.dll in logs

---

## TROUBLESHOOTING GUIDE

### Error: "Failed to load Oracle.DataAccess version 4.121.2.0"

**Causes:**
- Oracle.DataAccess.dll is wrong version
- Assembly not in bin directory
- Binding redirect misconfigured

**Resolution:**
```powershell
# Verify installed version
Get-Item "bin\Oracle.DataAccess.dll" | % { $_.VersionInfo }

# Should show:
# FileVersion = 4.121.2.0
# ProductVersion = 4.121.2.0

# Remove binding redirects (none exist currently - correct)
# Ensure exact version 4.121.2.0 is deployed
```

### Error: "ORA-12514: TNS:listener does not know of service named"

**Causes:**
- tnsnames.ora missing or invalid
- TNS alias in connection string doesn't match tnsnames.ora
- TNS_ADMIN environment variable points to wrong location

**Resolution:**
```powershell
# Verify tnsnames.ora exists
Test-Path "C:\oracle\product\12.1.0\client_1\network\admin\tnsnames.ora"

# Verify TNS alias defined
Select-String -Path "tnsnames.ora" -Pattern "DEVDB ="

# Test TNS connectivity
tnsping DEVDB
```

### Error: "Cannot load oci.dll"

**Causes:**
- oci.dll not in PATH
- 32-bit process trying to load 64-bit DLL (or vice versa)
- Incorrect Oracle installation

**Resolution:**
```powershell
# Verify oci.dll location
where oci.dll

# Add to PATH if missing (permanent)
$env:PATH += ";C:\oracle\product\12.1.0\client_1\bin"
[Environment]::SetEnvironmentVariable("PATH", $env:PATH, "Machine")

# Verify 64-bit architecture
[Environment]::Is64BitProcess  # Should be $true
```

### Error: "ORA-12541: TNS:no listener"

**Causes:**
- Oracle database server not running or unreachable
- Network connectivity issues
- Firewall blocking port 1521

**Resolution:**
```powershell
# Test network connectivity to Oracle server
Test-NetConnection -ComputerName oracle.example.com -Port 1521

# Verify tnsnames.ora has correct host/port
Select-String -Path "tnsnames.ora" -Pattern "(HOST|PORT)" -Context 1

# Verify firewall allows outbound on 1521
netstat -an | Select-String -Pattern "1521"
```

### Error: "IIS Application Pool stops after 5 seconds"

**Causes:**
- 32-bit pool trying to load 64-bit assembly
- Oracle libraries not accessible to IIS identity
- Missing .NET Framework

**Resolution:**
```powershell
# Verify IIS pool is 64-bit
Get-ItemProperty "IIS:\AppPools\QXP" | Select-Object Enable32BitAppOn
# Should show: False

# If True, disable 32-bit:
Set-ItemProperty "IIS:\AppPools\QXP" -Name Enable32BitAppOn -Value $false
Restart-WebAppPool -Name "QXP"

# Verify IIS identity has read permissions on Oracle installation
icacls "C:\oracle" /grant "IIS APPPOOL\QXP:(OI)(CI)RX"
```

---

## ENVIRONMENT-SPECIFIC CONNECTION STRINGS

Based on config files, three environments are configured:

### DEV Environment (Active)
```
Key: DBConnection (appSettings)
Value: DyoBeCMNR4nBXkuZL01ESiJ5SLB+iciGZ40pOeI/QoK5Gtu7mre2BZI9o8zJpT+Zr8AheSv6aGgxpLwofYqQOAbSb986qw9/3qUx0zpqQuTREI/jFFO/qzh9GMP/Ad0Q
Status: Encrypted (requires decryption)
Expected TNS Alias: DEVDB (or similar)
```

### HBB Environment (Commented)
```
Key: DBConnection (appSettings)
Value: [Encrypted - commented in source]
Status: Available but inactive
Expected TNS Alias: HBBDB (or similar)
```

### PROD Environment (Commented)
```
Key: DBConnection (appSettings)
Value: [Encrypted - commented in source]
Status: Available but inactive
Expected TNS Alias: PRODDB (or similar)
```

### Release Templates
```
Files: AppConfigReleaseTemplate.config
Value: {{DBConnection}}
Purpose: Placeholder for CI/CD pipeline to inject environment-specific values
```

---

## FINAL VALIDATION TEST

Create a standalone test application to verify Oracle connectivity:

```csharp
using System;
using QXP.Framework.Data.Oracle;
using QXP.Framework.Configuration;

class OracleConnectivityTest
{
    static void Main()
    {
        try
        {
            // Test 1: Load configuration
            var dbSettings = QXP.Framework.Configuration.DBConnectionSettings.Current;
            var connStr = dbSettings.GetDefaultDBConnectionString();
            Console.WriteLine("✓ Connection string loaded and decrypted");
            
            // Test 2: Create OraClient
            var oraClient = new OraClient(connStr);
            Console.WriteLine("✓ OraClient instantiated");
            
            // Test 3: Execute simple query
            var result = oraClient.ExecuteScalar(
                System.Data.CommandType.Text,
                "SELECT COUNT(*) FROM USER_TABLES"
            );
            Console.WriteLine($"✓ Query executed: {result}");
            
            // Test 4: Close connection
            oraClient.Close();
            Console.WriteLine("✓ Connection closed successfully");
            
            Console.WriteLine("\n✓✓✓ ALL TESTS PASSED ✓✓✓");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ ERROR: {ex.Message}");
            Console.WriteLine($"   StackTrace: {ex.StackTrace}");
        }
    }
}
```

---

## REFERENCES

- **Oracle Data Provider for .NET Documentation:** https://docs.oracle.com/en/database/oracle/oracle-database/12.1/odpnt/
- **ODP.NET 12.1 Release Notes:** https://docs.oracle.com/en/database/oracle/oracle-database/12.1/odpnt/release_notes.html
- **TNS Configuration Guide:** https://docs.oracle.com/en/database/oracle/oracle-database/12.1/netag/
- **OracleClient class:** Microsoft.Data.OracleClient (deprecated - NOT used here)

---

**Last Updated:** 2026-03-10  
**Version:** 1.0

