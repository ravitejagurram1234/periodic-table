# QXPSM Complete Reference Documentation

**Complete Code Reference for QuarkXPress Server Manager Caller Classes**

**Author:** QXP Engine Development Team  
**Date:** May 29, 2026  
**Purpose:** Full documentation of QXPSM caller and request classes with complete source code

---

## Table of Contents

1. [QXPSM_Call - Complete Code](#qxpsm_call---complete-code)
2. [QXPSM_Request_Base - Complete Code](#qxpsm_request_base---complete-code)
3. [QXPSM_Request_ParamsValue - Complete Code](#qxpsm_request_paramvalue---complete-code)
4. [QXPSM_Request_Modifier - Complete Code](#qxpsm_request_modifier---complete-code)
5. [QXPSM_Request_SaveAs - Complete Code](#qxpsm_request_saveas---complete-code)
6. [QXPSM_Request_Addfile - Complete Code](#qxpsm_request_addfile---complete-code)
7. [Other QXPSM_Request Types](#other-qxpsm_request-types)
8. [Dynamique Geometry Classes](#dynamique-geometry-classes)
9. [QXPS_Caller.Execute() - Complete Code](#qxps_callerexecute---complete-code)
10. [Direct Call vs Web Service Flow](#direct-call-vs-web-service-flow)
11. [Request Chaining Architecture](#request-chaining-architecture)

---

## QXPSM_Call - Complete Code

**File Location:** `QXP/QXP.Interop/QuarkServer/BusinessObject/QXPS_SDK/QXPSM/QXPSM_Call.cs`

**Author:** doufarm  
**Date:** 16/03/2010 11:17:25

**Purpose:** Manages chained SOAP requests to QuarkXPress Manager. Accumulates multiple QXPSM_Request_Base objects and sends them as a single SOAP call.

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK = com.quark.qxpsm;

namespace QXP.Interop.QuarkServer
{
	/// <summary>
	/// Manages orchestration of chained SOAP requests to QuarkXPress Manager
	/// Multiple QXPSM_Request_Base objects are accumulated and sent as one SOAP call
	/// </summary>
	/// <author>doufarm</author>
	/// <date>16/03/2010 11:17:25</date>    
	public class QXPSM_Call
	{
		#region Members
		QXPS_Call_Info						_call_Info;         // Connection information
		QXPSMSDK.QRequestContext			_sdk_context	= null;     // SOAP request context
		QXPSMSDK.RequestService		        _sdk_service	= null;     // SOAP service instance
		QXPSMSDK.QContentData				_sdk_response	= null;     // SOAP response
		List<QXPSM_Request_Base>			_requests		= new List<QXPSM_Request_Base>();  // Accumulated requests
		#endregion Members

		#region Constants

		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructors

		/// <summary>
		/// Creates a QXPSM_Call instance
		/// </summary>
		/// <param name="call_Info">Connection and session information for QuarkXPress Manager</param>
		public QXPSM_Call(QXPS_Call_Info call_Info)
		{
			_call_Info      = call_Info;
		}

		#endregion Constructors

		#region Methods

		/// <summary>
		/// Initializes the SOAP context for communication with QuarkXPress Manager
		/// </summary>
		private void InitContext()
		{
			// Create the SOAP service instance
			_sdk_service = new QXPSMSDK.RequestService();

			// Create the SOAP request context
			_sdk_context = new QXPSMSDK.QRequestContext();

			// Set connection parameters from call_Info
			if (QXPFrk.Validation.IsNotNull(_call_Info))
			{
				_sdk_context.sessionID = _call_Info.SessionID;              // SOAP session ID
				_sdk_context.documentName = _call_Info.DocumentName;       // Current document
			}
		}

		/// <summary>
		/// Executes all accumulated QXPSM requests as a single chained SOAP call
		/// Chains requests together, sends to QuarkXPress Manager, handles response
		/// </summary>
		public void SDKCall()
		{
			try
			{
				// Exit if no requests to send
				if(_requests.Count == 0) 
					return;

				// Clear any previous response
				_sdk_response = null;

				// Initialize context if needed
				if(QXPFrk.Validation.IsNull(_sdk_context)) 
					this.InitContext();

				// ===== CHAIN ALL REQUESTS TOGETHER =====
				// This is the key to the SOAP call pattern:
				// Request 1 → Request 2 → Request 3 → ... → Server processes all in order
				
				QXPSMSDK.QRequest __first	= null;      // First request in chain
				QXPSMSDK.QRequest __last	= null;      // Last request (to append to)
				
				foreach(QXPSM_Request_Base __request in _requests)
				{
					if(QXPFrk.Validation.IsNull(__first))
					{
						// First request: set as head of chain
						__first = __last = __request.Request;
					}
					else
					{
						// Subsequent requests: append to chain
						// Set the current request's .next to the last request we added
						__last.request = __request.Request;     // Link: current.request = next
						__last = __last.request;                // Move pointer forward
					}
				}
				
				// Attach the request chain to the SOAP context
				_sdk_context.request	= __first;

				// ===== SEND CHAINED REQUESTS TO MANAGER =====
				// All requests are sent in one SOAP message
				_sdk_response = _sdk_service.processRequest(_sdk_context);
				
			}
			catch(Exception ex)
			{
				throw new QXPSM_Exception(_sdk_response, ex);
			}
			finally
			{
				// Clear requests after sending (whether success or failure)
				_requests.Clear();
			}
		}

		#endregion Methods

		#region Properties

		/// <summary>
		/// Collection of requests to send as chained SOAP call
		/// Add requests to this list before calling SDKCall()
		/// </summary>
		public List<QXPSM_Request_Base> Requests
		{
			get { return _requests; }
		}

		/// <summary>
		/// SOAP context containing connection parameters and request chain
		/// </summary>
		public QXPSMSDK.QRequestContext SDK_Context
		{
			get { return _sdk_context; }
		}

		/// <summary>
		/// SOAP response from QuarkXPress Manager after SDKCall()
		/// Contains result data and status information
		/// </summary>
		public QXPSMSDK.QContentData SDK_Response
		{
			get { return _sdk_response; }
		}

		#endregion Properties
	}
}
```

### How QXPSM_Call Works

**Request Accumulation:**
```csharp
// In QXPS_Caller:
qxpsm_call.Requests.Add(new QXPSM_Request_ParamsValue(values));
qxpsm_call.Requests.Add(new QXPSM_Request_Modifier(project));
qxpsm_call.Requests.Add(new QXPSM_Request_SaveAs(path, name, true, false));

// All requests accumulated in List<QXPSM_Request_Base>
```

**How Requests Are Sent (SDKCall Method):**
```csharp
// Step 1: Create SOAP service and context
_sdk_service = new QXPSMSDK.RequestService();
_sdk_context = new QXPSMSDK.QRequestContext();

// Step 2: Initialize with connection info
_sdk_context.sessionID = _call_Info.SessionID;
_sdk_context.documentName = _call_Info.DocumentName;

// Step 3: Chain all requests
foreach(request in _requests)
{
    if(__first == null)
        __first = __last = request.Request;
    else
    {
        __last.request = request.Request;
        __last = __last.request;
    }
}

// Step 4: Attach chain to context
_sdk_context.request = __first;

// Step 5: Send via SOAP
_sdk_response = _sdk_service.processRequest(_sdk_context);

// Step 6: Clear list for next batch
_requests.Clear();
```

**SOAP Communication Flow:**
```
QXPSM_Call
    ↓
List<QXPSM_Request_Base> → Loop through and chain
    ↓
QRequest linked list → Attach to QRequestContext
    ↓
RequestService.processRequest(context) → SOAP HTTP POST
    ↓
QuarkXPress Manager processes all chained requests sequentially
    ↓
QContentData response returned to QXPSM_Call.SDK_Response
```

---

## QXPSM_Request_Base - Complete Code

**File Location:** `QXP/QXP.Interop/QuarkServer/BusinessObject/QXPS_SDK/QXPSM/Request/QXPSM_Request_Base.cs`

**Author:** doufarm  
**Date:** 18/03/2010 16:11:28

**Purpose:** Abstract base class for all QXPSM request types. Supports both autonomous and chained SOAP requests.

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK = com.quark.qxpsm;

namespace QXP.Interop.QuarkServer
{
	/// <summary>
	/// Abstract base class for all QXPSM requests
	/// Supports two modes:
	/// 1. Autonomous: single request sent immediately (documentName required)
	/// 2. Chained: multiple requests accumulated and sent together (no documentName needed)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>18/03/2010 16:11:28</date>    
	public abstract class QXPSM_Request_Base
	{
		#region Members
		string _document_Name		= null;     // Document name for autonomous calls
		byte[] _binary_Response		= null;     // Binary response (images, files)
		string _text_Response		= null;     // Text response (XML, etc.)

		#endregion Members

		#region Constants

		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructors

		/// <summary>
		/// Autonomous call constructor (sends immediately with document name)
		/// IMPORTANT: Subclass must call SDKCall() in its constructor when using this
		/// </summary>
		/// <param name="document_Name">Document name in QuarkXPress Server pool</param>
		public QXPSM_Request_Base(string document_Name)
		{
			_document_Name = document_Name;
		}

		/// <summary>
		/// Chained call constructor (accumulates requests without sending)
		/// Used when adding request to QXPSM_Call.Requests collection
		/// </summary>
		public QXPSM_Request_Base()
		{
		}

		#endregion Constructors

		#region Methods

		/// <summary>
		/// Executes an autonomous SOAP call to QuarkXPress Manager
		/// Used for single request calls where documentName is known
		/// This method is called from subclass constructors in autonomous mode
		/// </summary>
		public void SDKCall()
		{
			// Create SOAP service and context
			QXPSMSDK.RequestService	        __svc			= new QXPSMSDK.RequestService();
			QXPSMSDK.QRequestContext		__sdk_context	= new QXPSMSDK.QRequestContext();
			QXPSMSDK.QContentData			__sdk_response;

			// Set up SOAP request
			__sdk_context.documentName	= _document_Name;       // Set document
			__sdk_context.request		= this.Request;         // Set request from subclass

			// Send SOAP request and get response
			__sdk_response = __svc.processRequest(__sdk_context);
			
			// Extract response data
			_binary_Response = __sdk_response.streamValue;       // Binary data (images, PDFs)
			_text_Response   = __sdk_response.stringValue;       // Text data (XML, etc.)
		}

		#endregion Methods

		#region Properties
		
		/// <summary>
		/// ABSTRACT: Subclasses must override to provide their specific QRequest type
		/// Each subclass defines what type of operation (ParamsValue, Modifier, etc.)
		/// </summary>
		public abstract QXPSMSDK.QRequest Request { get; }

		/// <summary>
		/// Document name (for autonomous calls or current document reference)
		/// </summary>
		public string Document_Name
		{
			get { return _document_Name; }
			set { _document_Name = value; }
		}

		/// <summary>
		/// Binary response (images, PDF files, etc.)
		/// Available after autonomous SOAP call
		/// </summary>
		public byte[] Binary_Response
		{
			get { return _binary_Response; }
			set { _binary_Response = value; }
		}

		/// <summary>
		/// Text response (XML, JSON, plain text)
		/// Available after autonomous SOAP call
		/// </summary>
		public string Text_Response
		{
			get { return _text_Response; }
			set { _text_Response = value; }
		}

		#endregion Properties
	}
}
```

### Two Modes of QXPSM_Request_Base

**Mode 1: Autonomous (Single Request - Sends Immediately)**
```csharp
// Constructor
public QXPSM_Request_JPEG(string documentName, int page) : base(documentName)
{
    _page = page;
    base.SDKCall();  // ← Sends immediately!
}

// Flow:
//   1. Constructor called
//   2. Set _document_Name
//   3. SDKCall() creates own service/context
//   4. Send single SOAP request
//   5. Store response in Binary_Response/Text_Response
//   6. Return from constructor
```

**Mode 2: Chained (Multiple Requests - Does NOT Send)**
```csharp
// Constructor
public QXPSM_Request_ParamsValue(QXPSMSDK.NameValueParam[] params) : base()
{
    _paramsValue = params;
    // NO base.SDKCall() here!
}

// Flow:
//   1. Constructor called
//   2. Set _paramsValue
//   3. Return without sending
//   4. Add to QXPSM_Call.Requests list
//   5. Wait for QXPSM_Call.SDKCall() to send all together
```

---

## QXPSM_Request_ParamsValue - Complete Code

**File Location:** `QXP/QXP.Interop/QuarkServer/BusinessObject/QXPS_SDK/QXPSM/Request/QXPSM_Request_ParamsValue.cs`

**Author:** doufarm  
**Date:** 18/03/2010 16:11:28

**Purpose:** Request type for updating block values via SOAP.

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK = com.quark.qxpsm;

namespace QXP.Interop.QuarkServer
{
	/// <summary>
	/// QXPSM request for updating block values in a QuarkXPress document
	/// Updates named blocks with new values (text, images, etc.)
	/// Can only be used in chained mode
	/// </summary>
	/// <author>doufarm</author>
	/// <date>18/03/2010 16:11:28</date>    
	public class QXPSM_Request_ParamsValue : QXPSM_Request_Base
	{
		#region Members
		QXPSMSDK.NameValueParam[] _paramsValue = null;         // Array of name/value pairs
		#endregion Members

		#region Constants
		const string NameValuePattern = "{0}={1}";             // Format for name=value
		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructors

		/// <summary>
		/// Creates a chained QXPSM_Request_ParamsValue (does not send immediately)
		/// </summary>
		/// <param name="paramsValue">Array of NameValueParam with block name/value pairs</param>
		public QXPSM_Request_ParamsValue(QXPSMSDK.NameValueParam[] paramsValue) : base()
		{
			_paramsValue = paramsValue;
		}

		#endregion Constructors

		#region Methods

		/// <summary>
		/// Creates a SOAP RequestParameters object for updating values
		/// This is sent as part of the request chain
		/// </summary>
		public override QXPSMSDK.QRequest Request
		{
			get 
			{ 
				// Create SOAP RequestParameters (for value updates)
				QXPSMSDK.RequestParameters __request = new QXPSMSDK.RequestParameters(); 
				
				// Set the name/value pairs to update
				__request.@params = _paramsValue;
				
				return __request;
			}
		}

		#endregion Methods

		#region Properties
		
		/// <summary>
		/// Array of name/value parameters to send
		/// </summary>
		public QXPSMSDK.NameValueParam[] ParamsValue
		{
			get { return _paramsValue; }
		}

		#endregion Properties
	}
}
```

### How NameValueParam[] Is Sent via SOAP

**Structure:**
```csharp
public class NameValueParam
{
    public string name;      // Block name (e.g., "CustomerName", "Amount")
    public string value;     // New value for the block
}
```

**Usage:**
```csharp
QXPSMSDK.NameValueParam[] nameValues = new QXPSMSDK.NameValueParam[2];

nameValues[0] = new QXPSMSDK.NameValueParam();
nameValues[0].name = "CustomerName";
nameValues[0].value = "John Smith";

nameValues[1] = new QXPSMSDK.NameValueParam();
nameValues[1].name = "Amount";
nameValues[1].value = "1000.00";

QXPSM_Request_ParamsValue request = new QXPSM_Request_ParamsValue(nameValues);
qxpsm_call.Requests.Add(request);
```

**SOAP XML (Auto-Generated):**
```xml
<soap:Body>
  <RequestParameters>
    <@params>
      <NameValueParam>
        <name>CustomerName</name>
        <value>John Smith</value>
      </NameValueParam>
      <NameValueParam>
        <name>Amount</name>
        <value>1000.00</value>
      </NameValueParam>
    </@params>
  </RequestParameters>
</soap:Body>
```

**SOAP Processing Flow:**
```
NameValueParam[] array
    ↓
QXPSM_Request_ParamsValue constructor
    ↓
Request property builds RequestParameters object
    ↓
RequestParameters.@params = array
    ↓
QXPSMSDK automatically serializes to SOAP XML
    ↓
Server deserializes NameValueParam[] from XML
    ↓
Server updates each block value:
    CustomerName = "John Smith"
    Amount = "1000.00"
```

---

## QXPSM_Request_Modifier - Complete Code

**File Location:** `QXP/QXP.Interop/QuarkServer/BusinessObject/QXPS_SDK/QXPSM/Request/QXPSM_Request_Modifier.cs`

**Author:** doufarm  
**Date:** 18/03/2010 16:11:28

**Purpose:** Request type for structural modifications to QuarkXPress documents.

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK = com.quark.qxpsm;

namespace QXP.Interop.QuarkServer
{
	/// <summary>
	/// QXPSM request for structural modifications to a QuarkXPress document
	/// Modifies the DOM (Document Object Model) of the document
	/// Can add/remove/modify boxes, text, images, etc.
	/// Can only be used in chained mode (not autonomous)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>18/03/2010 16:11:28</date>    
	public class QXPSM_Request_Modifier : QXPSM_Request_Base
	{
		#region Members
		QXPSMSDK.Project _project;                          // Modified document structure
		#endregion Members

		#region Constants

		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructors

		/// <summary>
		/// Creates a chained QXPSM_Request_Modifier (does not send immediately)
		/// </summary>
		/// <param name="project">QXPSMSDK.Project with structural modifications</param>
		public QXPSM_Request_Modifier(QXPSMSDK.Project project) : base()
		{
			_project = project;
			base.SDKCall();                                 // Send immediately for modifier
		}

		#endregion Constructors

		#region Methods

		/// <summary>
		/// Creates a SOAP ModifierRequest object for structural changes
		/// This is sent as part of the request chain
		/// </summary>
		public override QXPSMSDK.QRequest Request
		{
			get 
			{ 
				// Create SOAP ModifierRequest (for structural changes)
				QXPSMSDK.ModifierRequest __request = new QXPSMSDK.ModifierRequest(); 
				
				// Set the modified project structure
				__request.project = _project;
				
				return __request;
			}
		}

		#endregion Methods

		#region Properties
		
		/// <summary>
		/// The modified QXPSMSDK.Project structure
		/// Contains all DOM changes (added boxes, text, images, etc.)
		/// </summary>
		public QXPSMSDK.Project Project
		{
			get { return _project; }
		}

		#endregion Properties
	}
}
```

### How QXPSMSDK.Project Is Sent via SOAP

**Simplified Structure:**
```csharp
public class Project
{
    public Page[] pages;                        // Array of pages
}

public class Page
{
    public string name;                         // Page name
    public Box[] boxes;                         // Array of boxes on page
}

public class Box
{
    public string name;                         // Box identifier
    public Content content;                     // Text/image content
    public Geometry geometry;                   // Position and size
    public Picture picture;                     // Image properties
    public Box[] boxes;                         // Nested boxes (for groups)
}
```

**Usage:**
```csharp
// Create/load modified project
QXPSMSDK.Project modifiedProject = LoadProjectFromFile("modified.prj");

// Modify project structure
modifiedProject.pages[0].boxes[0].content.value = "New Text";

// Send via QXPSM
QXPSM_Request_Modifier requestModifier = 
    new QXPSM_Request_Modifier(modifiedProject);

qxpsm_call.Requests.Add(requestModifier);
```

**SOAP XML (Auto-Generated):**
```xml
<ModifierRequest>
  <project>
    <pages>
      <Page name="Page1">
        <boxes>
          <Box name="TextBox1">
            <content>
              <value>New Text</value>
            </content>
            <geometry>
              <position>
                <left>100</left>
                <top>200</top>
                <width>300</width>
                <height>50</height>
              </position>
            </geometry>
          </Box>
          <Box name="ImageBox1">
            <content>
              <value>file:///path/to/image.jpg</value>
            </content>
            <picture>
              <angle>0</angle>
            </picture>
          </Box>
        </boxes>
      </Page>
    </pages>
  </project>
</ModifierRequest>
```

**SOAP Processing Flow:**
```
QXPSMSDK.Project object
    ↓
ModifierRequest.project = project
    ↓
QXPSMSDK serializes object hierarchy to SOAP XML
    ↓
Server receives XML and deserializes to Project object
    ↓
Server applies modifications to document DOM:
    - Add/remove boxes
    - Change box properties
    - Update content references
    - Modify geometry
```

---

## QXPSM_Request_SaveAs - Complete Code

**File Location:** `QXP/QXP.Interop/QuarkServer/BusinessObject/QXPS_SDK/QXPSM/Request/QXPSM_Request_SaveAs.cs`

**Author:** doufarm  
**Date:** 18/03/2010 16:11:28

**Purpose:** Request type for saving QuarkXPress documents.

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK = com.quark.qxpsm;

namespace QXP.Interop.QuarkServer
{
	/// <summary>
	/// QXPSM request for saving a QuarkXPress document with a new name
	/// Saves current document to a new file path with specified options
	/// Can be autonomous or chained
	/// </summary>
	/// <author>doufarm</author>
	/// <date>18/03/2010 16:11:28</date>    
	public class QXPSM_Request_SaveAs : QXPSM_Request_Base
	{
		#region Members
		string  _path						= null;     // File path to save to
		string  _newName					= null;     // New file name
		bool    _replace					= false;    // Replace if exists?
		bool    _saveToPool					= false;    // Save to document pool?
		#endregion Members

		#region Constants

		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructors

		/// <summary>
		/// Creates a QXPSM_Request_SaveAs (can be autonomous or chained)
		/// </summary>
		/// <param name="path">Directory path to save file to</param>
		/// <param name="newName">New file name</param>
		/// <param name="replace">Replace existing file if it exists?</param>
		/// <param name="saveToPool">Save to QuarkXPress server document pool?</param>
		public QXPSM_Request_SaveAs(string path, string newName, bool replace, bool saveToPool) : base()
		{
			_path = path;
			_newName = newName;
			_replace = replace;
			_saveToPool = saveToPool;
		}

		/// <summary>
		/// Creates a QXPSM_Request_SaveAs with document name (autonomous)
		/// </summary>
		/// <param name="documentName">Document name to save</param>
		/// <param name="path">Directory path</param>
		/// <param name="newName">New file name</param>
		/// <param name="replace">Replace existing?</param>
		public QXPSM_Request_SaveAs(string documentName, string path, string newName, bool replace) 
			: base(documentName)
		{
			_path = path;
			_newName = newName;
			_replace = replace;
			_saveToPool = false;
			base.SDKCall();
		}

		#endregion Constructors

		#region Methods

		/// <summary>
		/// Creates a SOAP SaveAsRequest object for saving document
		/// </summary>
		public override QXPSMSDK.QRequest Request
		{
			get 
			{ 
				// Create SOAP SaveAsRequest
				QXPSMSDK.SaveAsRequest __request = new QXPSMSDK.SaveAsRequest(); 
				
				// Set save parameters
				__request.path = _path;
				__request.newFileName = _newName;
				__request.replace = _replace;
				__request.saveToPool = _saveToPool;
				
				return __request;
			}
		}

		#endregion Methods

		#region Properties
		
		/// <summary>
		/// File path to save to
		/// </summary>
		public string Path
		{
			get { return _path; }
			set { _path = value; }
		}

		/// <summary>
		/// New file name
		/// </summary>
		public string NewName
		{
			get { return _newName; }
			set { _newName = value; }
		}

		/// <summary>
		/// Replace existing file?
		/// </summary>
		public bool Replace
		{
			get { return _replace; }
			set { _replace = value; }
		}

		/// <summary>
		/// Save to QuarkXPress server document pool?
		/// </summary>
		public bool SaveToPool
		{
			get { return _saveToPool; }
			set { _saveToPool = value; }
		}

		#endregion Properties
	}
}
```

---

## QXPSM_Request_Addfile - Complete Code

**File Location:** `QXP/QXP.Interop/QuarkServer/BusinessObject/QXPS_SDK/QXPSM/Request/QXPSM_Request_Addfile.cs`

**Author:** doufarm  
**Date:** 18/03/2010 16:11:28

**Purpose:** Request type for uploading binary files to document pool.

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK = com.quark.qxpsm;

namespace QXP.Interop.QuarkServer
{
	/// <summary>
	/// QXPSM request for adding files to the QuarkXPress server document pool
	/// Uploads binary data (images, PDFs, etc.) to server document pool
	/// Can be autonomous or chained
	/// </summary>
	/// <author>doufarm</author>
	/// <date>18/03/2010 16:11:28</date>    
	public class QXPSM_Request_Addfile : QXPSM_Request_Base
	{
		#region Members
		string  _documentName           = null;     // Document pool name
		byte[]  _data                   = null;     // Binary file data
		#endregion Members

		#region Constants

		#endregion Constants

		#region Enums

		#endregion Enums

		#region Constructors

		/// <summary>
		/// Creates a QXPSM_Request_Addfile (chained mode)
		/// </summary>
		/// <param name="documentName">Name in document pool</param>
		/// <param name="data">Binary file data to add</param>
		public QXPSM_Request_Addfile(string documentName, byte[] data) : base()
		{
			_documentName = documentName;
			_data = data;
		}

		/// <summary>
		/// Creates a QXPSM_Request_Addfile (autonomous mode)
		/// Sends immediately
		/// </summary>
		/// <param name="qxpPoolName">QXP document pool name</param>
		/// <param name="documentName">Name in pool for this file</param>
		/// <param name="data">Binary file data</param>
		public QXPSM_Request_Addfile(string qxpPoolName, string documentName, byte[] data) 
			: base(qxpPoolName)
		{
			_documentName = documentName;
			_data = data;
			base.SDKCall();
		}

		#endregion Constructors

		#region Methods

		/// <summary>
		/// Creates a SOAP AddFileRequest object for uploading file data
		/// </summary>
		public override QXPSMSDK.QRequest Request
		{
			get 
			{ 
				// Create SOAP AddFileRequest
				QXPSMSDK.AddFileRequest __request = new QXPSMSDK.AddFileRequest(); 
				
				// Set file parameters
				__request.fileName = _documentName;     // Document pool name
				__request.fileData = _data;             // Binary content
				
				return __request;
			}
		}

		#endregion Methods

		#region Properties
		
		/// <summary>
		/// Document pool name for this file
		/// </summary>
		public string DocumentName
		{
			get { return _documentName; }
			set { _documentName = value; }
		}

		/// <summary>
		/// Binary file data
		/// </summary>
		public byte[] Data
		{
			get { return _data; }
			set { _data = value; }
		}

		#endregion Properties
	}
}
```

---

## Other QXPSM_Request Types

### QXPSM_Request_QXP

Render document as QuarkXPress file

```csharp
public class QXPSM_Request_QXP : QXPSM_Request_Base
{
    public QXPSM_Request_QXP(string documentName) : base(documentName)
    {
        base.SDKCall();
    }

    public QXPSM_Request_QXP() : base() { }

    public override QXPSMSDK.QRequest Request
    {
        get 
        { 
            QXPSMSDK.QuarkXPressRenderRequest __request = 
                new QXPSMSDK.QuarkXPressRenderRequest();
            return __request; 
        }
    }
}
```

### QXPSM_Request_PDF

Render document as PDF

```csharp
public class QXPSM_Request_PDF : QXPSM_Request_Base
{
    string _colorImageDownSample;
    string _grayscaleImageDownSample;
    
    public QXPSM_Request_PDF(string documentName) : base(documentName)
    {
        base.SDKCall();
    }

    public QXPSM_Request_PDF() : base() { }

    public override QXPSMSDK.QRequest Request
    {
        get 
        { 
            QXPSMSDK.PDFRenderRequest __request = 
                new QXPSMSDK.PDFRenderRequest();
            if(QXPFrk.Validation.IsSet(_colorImageDownSample))
                __request.colorImageDownSample = _colorImageDownSample;
            return __request;
        }
    }
}
```

### QXPSM_Request_JPEG

Render document page as JPEG

```csharp
public class QXPSM_Request_JPEG : QXPSM_Request_Base
{
    int _page = int.MinValue;
    
    public QXPSM_Request_JPEG(string documentName, int page) : base(documentName)
    {
        _page = page;
        base.SDKCall();
    }

    public override QXPSMSDK.QRequest Request
    {
        get 
        { 
            QXPSMSDK.JPEGRenderRequest __request = 
                new QXPSMSDK.JPEGRenderRequest();
            __request.pageNumber = _page;
            return __request;
        }
    }
}
```

### QXPSM_Request_XML

Export document as XML

```csharp
public class QXPSM_Request_XML : QXPSM_Request_Base
{
    string _boxName = null;
    
    public QXPSM_Request_XML(string documentName, string boxName) 
        : base(documentName)
    {
        _boxName = boxName;
        base.SDKCall();
    }

    public override QXPSMSDK.QRequest Request
    {
        get 
        { 
            QXPSMSDK.DeconstructRequest __request = 
                new QXPSMSDK.DeconstructRequest();
            if(QXPFrk.Validation.IsSet(_boxName))
                __request.boxName = _boxName;
            return __request;
        }
    }
}
```

---

## Dynamique Geometry Classes

### Dynamique_Geometry_Helper — Complete Class

**File Location:** `QXP/QXP.Engine.Core/Helper/Dynamique_Geometry_Helper.cs`

```csharp
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

using QXPSMSDK = com.quark.qxpsm;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Permet de repositionner des éléments d'un rapport dynamique
	/// </summary>
	/// <author>doufarm</author>
	/// <date>01/04/2010 11:39:30</date>    
	public class Dynamique_Geometry_Helper
	{
		#region Membres
        
		#endregion Membres

		#region Constantes
        
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static Dynamique_Geometry_Helper
		/// </summary>
		static Dynamique_Geometry_Helper()
		{
		}

		#endregion Constructeur

		#region Méthodes

		/// <summary>
		/// Calcul d'une DZone en fonction d'une position et des paramètres d'une DCell (avec mise à jour de la position). 
		/// </summary>
		/// <remarks>
		/// Cette méthode calcule la zone géométrique d'une cellule et met à jour le curseur de position
		/// pour refléter l'avancement dans le tableau. Le curseur est incrémenté de la largeur de la cellule
		/// plus le left offset du template.
		/// </remarks>
		/// <param name="cursor">position actuelle du curseur</param>
		/// <param name="cell">la cellule qui permet de déduire la nouvelle zone </param>
		/// <returns>une nouvelle DZone</returns>
		public static DZone Get_Zone_And_Update_Cursor(DPoint cursor, DCell cell)
		{
			// 1. Calculer la zone sans mise à jour du curseur
			DZone __zone = Get_Zone(cursor, cell);

			// 2. Mettre à jour le curseur avec la largeur de la cellule
			if(QXP.Framework.Validation.IsNotNull(cursor))
			{
				// Incrémenter le curseur Left de la largeur de la cellule + left offset
				cursor.Left = cursor.Left + __zone.Width + cell.Template.Left;
			}

			return __zone;
		}
		
		/// <summary>
		/// Calcule d'une DZone en fonction d'une position et des paramètres d'une DCell (sans mise à jour de la position). 
		/// </summary>
		/// <remarks>
		/// Cette méthode calcule uniquement la zone géométrique sans modifier le curseur passé en paramètre.
		/// La zone est calculée en fonction:
		/// - De la position du curseur (relative positioning)
		/// - Des paramètres du template (left, top, width, height)
		/// </remarks>
		/// <param name="cursor">position actuelle du curseur</param>
		/// <param name="cell">la cellule qui permet de déduire la nouvelle zone </param>
		/// <returns>une nouvelle DZone</returns>
		public static DZone Get_Zone(DPoint cursor, DCell cell)
		{
			DZone		__zone;
			Template	__style = cell.Template;
			decimal		__left, __top, __width, __height;

			// 1. Extraire les dimensions du template
			__left		= cell.Template.Left;
			__top		= cell.Template.Top;
			__width		= Get_CellWidth_WithoutLeft(cell);
			__height	= Get_CellHeight_WithoutTop(cell);

			// 2. Créer la zone en considérant le curseur
			if(QXP.Framework.Validation.IsNull(cursor))
			{
				// Position absolue (sans curseur)
				__zone = new DZone(
					__left
					, __top
					, __width
					, __height);
			}
			else
			{
				// Position relative au curseur
				__zone = new DZone(
					__left + cursor.Left 
					, __top + cursor.Top
					, __width
					, __height);
			}

			return __zone;
		}

		/// <summary>
		/// Calcule de la hauteur absolue d'une DCell (en tenant compte du marging top)
		/// </summary>
		/// <remarks>
		/// La hauteur totale inclut:
		/// - La hauteur du template (si définie) ou la hauteur du TElement
		/// - Le top offset (si c'est une cellule relative)
		/// </remarks>
		/// <param name="cell">la cellule qui permet de déduire la hauteur </param>
		/// <returns>la hauteur de la cellule</returns>
		public static decimal Get_CellHeight_WithTop(DCell cell)
		{
			decimal __height = 0;

			// 1. Déterminer la hauteur de base
			if(QXPFrk.Validation.IsSet(cell.Template.Height, false))
			{
				// Utiliser la hauteur du template si définie
				__height = cell.Template.Height;
			}
			else
			{
				// Utiliser la hauteur du TElement
				__height = cell.TElement.Height;
			}

			// 2. Ajouter le top offset si cellule relative
			if(!cell.Template.Absolute) 
				__height += cell.Template.Top;

			return __height;
		}

		/// <summary>
		/// Calcul de la hauteur d'une DCell (sans tenir compte du marging top)
		/// </summary>
		/// <remarks>
		/// Retourne uniquement la hauteur de base de la cellule, sans le top offset.
		/// </remarks>
		/// <param name="cell">la cellule qui permet de déduire la hauteur </param>
		/// <returns>la hauteur de la cellule</returns>
		public static decimal Get_CellHeight_WithoutTop(DCell cell)
		{
			decimal __height = 0;

			// 1. Déterminer la hauteur de base
			if(QXPFrk.Validation.IsSet(cell.Template.Height, false))
			{
				__height = cell.Template.Height;
			}
			else
			{
				__height = cell.TElement.Height;
			}

			return __height;
		}

		/// <summary>
		/// Calcul de la largeur Absolue d'une DCell (en tenant compte du marging left)
		/// </summary>
		/// <remarks>
		/// La largeur totale inclut:
		/// - La largeur du template (si définie) ou la largeur du TElement
		/// - Le left offset (si c'est une cellule relative)
		/// </remarks>
		/// <param name="cell">la cellule qui permet de déduire la largeur </param>
		/// <returns>la largeur de la cellule</returns>
		public static decimal Get_CellWidth_WithLeft(DCell cell)
		{
			decimal __width = 0;

			// 1. Déterminer la largeur de base
			if(QXPFrk.Validation.IsSet(cell.Template.Width, false))
			{
				__width = cell.Template.Width;
			}
			else
			{
				__width = cell.TElement.Width;
			}

			// 2. Ajouter le left offset si cellule relative
			if(!cell.Template.Absolute) 
				__width += cell.Template.Left;

			return __width;
		}

		/// <summary>
		/// Calcul de la largeur Absolue d'une DCell (sans tenir compte du marging left)
		/// </summary>
		/// <remarks>
		/// Retourne uniquement la largeur de base de la cellule, sans le left offset.
		/// </remarks>
		/// <param name="cell">la cellule qui permet de déduire la largeur </param>
		/// <returns>la largeur de la cellule</returns>
		public static decimal Get_CellWidth_WithoutLeft(DCell cell)
		{
			decimal __width = 0;

			// 1. Déterminer la largeur de base
			if(QXPFrk.Validation.IsSet(cell.Template.Width, false))
			{
				__width = cell.Template.Width;
			}
			else
			{
				__width = cell.TElement.Width;
			}

			return __width;
		}

		/// <summary>
		/// Récupère la zone géométrique calculée à partir du template d'une cellule
		/// </summary>
		/// <remarks>
		/// Cette méthode est utilisée pendant la phase de préparation du rapport
		/// pour calculer et stocker les zones absolues références dans cell.Info.Zone
		/// </remarks>
		/// <param name="cursor">position du curseur (peut être null pour positions absolues)</param>
		/// <param name="cell">la cellule contenant le template</param>
		/// <returns>une DZone avec les coordonnées calculées</returns>
		public static DZone Get_Zone_Reference(DPoint cursor, DCell cell)
		{
			return Get_Zone(cursor, cell);
		}

		#endregion Méthodes
	}
}
```

### DPoint — Complete Class

**File Location:** `QXP/QXP.Engine.Core/BusinessObject/Dynamique/Report/DPoint.cs`

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Représente une position (left,top) dans le document dynamique
	/// </summary>
	/// <remarks>
	/// Cette classe est utilisée comme curseur de position lors du calcul de la géométrie
	/// du rapport dynamique. Elle suit la position actuelle lors du positionnement des cellules
	/// dans le tableau.
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:58:53</date>    
	public class DPoint
	{
		#region Membres
		decimal _left		= 0;
		decimal _top		= 0;

		/// <summary>
		/// Point d'origine 0,0
		/// </summary>
		public static DPoint Default = new DPoint();

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Crée une instance de DPoint à l'origine (0, 0)
		/// </summary>
		public DPoint()
		{
			_left = 0;
			_top = 0;
		}

		/// <summary>
		/// Crée une instance de DPoint à partir d'un autre DPoint
		/// Effectue une copie des coordonnées
		/// </summary>
		/// <param name="start">Point de départ à copier</param>
		public DPoint(DPoint start)
		{
			if(QXPFrk.Validation.IsNotNull(start))
			{
				_left	= start.Left;
				_top	= start.Top;
			}
			else
			{
				_left = 0;
				_top = 0;
			}
		}

		/// <summary>
		/// Crée une instance de DPoint avec des coordonnées spécifiques
		/// </summary>
		/// <param name="left">position gauche</param>
		/// <param name="top">position haute</param>
		public DPoint(decimal left, decimal top)
		{
			_left	= left;
			_top	= top;
		}
		
		#endregion Constructeur

		#region Méthodes

		/// <summary>
		/// Réinitialise les positions du point
		/// </summary>
		/// <param name="left">position gauche</param>
		/// <param name="top">position haute</param>
		public void Reset(decimal left, decimal top)
		{
			_left	= left;
			_top	= top;
		}

		/// <summary>
		/// Réinitialise le point à l'origine (0, 0)
		/// </summary>
		public void Reset()
		{
			_left = 0;
			_top = 0;
		}

		/// <summary>
		/// Crée une copie du point courant
		/// </summary>
		/// <returns>Un nouveau DPoint avec les mêmes coordonnées</returns>
		public DPoint Clone()
		{
			return new DPoint(_left, _top);
		}

		/// <summary>
		/// Retourne une représentation texte du point
		/// </summary>
		/// <returns>Format: "Left=X, Top=Y"</returns>
		public override string ToString()
		{
			return string.Format("Left={0}, Top={1}", _left, _top);
		}
	
		#endregion Méthodes

		#region Propriétés

		/// <summary>
		/// Position Gauche du point
		/// </summary>
		/// <remarks>
		/// Représente l'offset horizontal dans le document dynamique.
		/// Utilisé lors du calcul de positionnement relatif des cellules.
		/// </remarks>
		public decimal Left
		{
			get { return _left; }
			set { _left = value; }
		}

		/// <summary>
		/// Position Haute du point
		/// </summary>
		/// <remarks>
		/// Représente l'offset vertical dans le document dynamique.
		/// Utilisé lors du calcul de positionnement relatif des cellules.
		/// </remarks>
		public decimal Top
		{
			get { return _top; }
			set { _top = value; }
		}

		#endregion Propriétés
	}
}
```

### DZone — Complete Class

**File Location:** `QXP/QXP.Engine.Core/BusinessObject/Dynamique/Report/DZone.cs`

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Représente une zone visuelle dans un document dynamique
	/// </summary>
	/// <remarks>
	/// Une DZone encapsule les coordonnées géométriques d'une cellule:
	/// - Left: position horizontale
	/// - Top: position verticale
	/// - Width: largeur
	/// - Height: hauteur
	/// 
	/// Les DZones sont calculées pendant Prepare_Report() et stockées dans DCell_Info.Zone
	/// pour être utilisées lors du rendering des blocs (Render_Boxes).
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:50:15</date>    
	public class DZone
	{
		#region Membres
		decimal _left		= 10;
		decimal _top		= 10;
		decimal _width		= 50;
		decimal _height		= 50;
		
		/// <summary>
		/// Définit une zone par défaut left:10 top:10 width:50 height:50
		/// </summary>
		public static DZone Default = new DZone();

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Permet la creation d'une DZone par Default
		/// Initialise à: left:10, top:10, width:50, height:50
		/// </summary>
		private DZone()
		{
			_left = 10;
			_top = 10;
			_width = 50;
			_height = 50;
		}

		/// <summary>
		/// Crée une instance de DZone
		/// </summary>
		/// <param name="left">position gauche</param>
		/// <param name="top">position haute</param>
		/// <param name="width">largeur</param>
		/// <param name="height">hauteur</param>
		public DZone(decimal left, decimal top, decimal width, decimal height)
		{
			_left	= left;
			_top	= top;
			_width	= width;
			_height = height;
		}

		#endregion Constructeur

		#region Méthodes

		/// <summary>
		/// Permet de dupliquer une zone afin de créer une nouvelle zone sans modifier les paramètres de la zone originale
		/// </summary>
		/// <remarks>
		/// Le clonage est effectué par valeur, pas par référence.
		/// Modifications de la zone clonée n'affectent pas l'originale.
		/// </remarks>
		/// <returns>la nouvelle zone identique à la zone originale</returns>
		public DZone Clone()
		{
			return new DZone(this._left, this._top, this._width, this._height);
		}

		/// <summary>
		/// Retourne une représentation texte de la zone
		/// </summary>
		/// <returns>Format: "Left=X, Top=Y, Width=W, Height=H"</returns>
		public override string ToString()
		{
			return string.Format(
				"Left={0}, Top={1}, Width={2}, Height={3}", 
				_left, _top, _width, _height
			);
		}

		#endregion Méthodes

		#region Propriétés

		/// <summary>
		/// Position gauche de la Zone
		/// </summary>
		/// <remarks>
		/// Coordonnée X du coin supérieur gauche de la zone.
		/// Utilisée lors du rendu des boîtes dans TElement_Helper.
		/// </remarks>
		public decimal Left
		{
			get { return _left; }
			set { _left = value; }
		}

		/// <summary>
		/// Position haute de la Zone
		/// </summary>
		/// <remarks>
		/// Coordonnée Y du coin supérieur gauche de la zone.
		/// Utilisée lors du rendu des boîtes dans TElement_Helper.
		/// </remarks>
		public decimal Top
		{
			get { return _top; }
			set { _top = value; }
		}

		/// <summary>
		/// Largeur de la Zone
		/// </summary>
		/// <remarks>
		/// Dimension horizontale de la zone.
		/// </remarks>
		public decimal Width
		{
			get { return _width; }
			set { _width = value; }
		}

		/// <summary>
		/// Hauteur de la Zone
		/// </summary>
		/// <remarks>
		/// Dimension verticale de la zone.
		/// </remarks>
		public decimal Height
		{
			get { return _height; }
			set { _height = value; }
		}

		#endregion Propriétés
	}
}
```

### DCell_Info — Complete Class

**File Location:** `QXP/QXP.Engine.Core/BusinessObject/Dynamique/Report/DCell_Info.cs`

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les informations de géométrie d'une DCell
	/// </summary>
	/// <remarks>
	/// DCell_Info encapsule les informations de positionnement et de rendu d'une cellule:
	/// - Zone: la géométrie (left, top, width, height) calculée pendant Prepare_Report
	/// - Page: le numéro de page où la cellule doit être rendue
	/// - Column: le numéro de colonne où la cellule doit être rendue
	/// - LogicalId: identifiant logique unique de la cellule
	/// 
	/// Ces informations sont utilisées lors de Render_Boxes pour créer les boîtes finales.
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:47:37</date>    
	public class DCell_Info
	{
		#region Membres
		int			_page;
		int			_column;
		DZone		_zone;
		int			_logicalId;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Crée une instance de DCell_Info
		/// Initialise avec valeurs par défaut
		/// </summary>
		public DCell_Info()
		{
			_page = 1;
			_column = 1;
			_zone = DZone.Default;
			_logicalId = 0;
		}

		#endregion Constructeur

		#region Méthodes

		/// <summary>
		/// Clonage des informations de la cellule
		/// </summary>
		/// <remarks>
		/// Effectue une copie profonde (deep copy) des informations.
		/// La DZone est clonée pour éviter les modifications ultérieures d'affecter l'original.
		/// </remarks>
		/// <returns>Une nouvelle DCell_Info avec les mêmes valeurs</returns>
		public DCell_Info Clone()
		{
			DCell_Info __new_Cell_Info = new DCell_Info();
			__new_Cell_Info.Zone		= this.Zone != null ? this.Zone.Clone() : DZone.Default;
			__new_Cell_Info.Page		= this.Page;
			__new_Cell_Info.Column		= this.Column;
			__new_Cell_Info.LogicalId	= this.LogicalId;
			return __new_Cell_Info;
		}

		/// <summary>
		/// Retourne une représentation texte des informations
		/// </summary>
		/// <returns>Format: "Page=X, Column=Y, Zone=[...]"</returns>
		public override string ToString()
		{
			return string.Format(
				"Page={0}, Column={1}, Zone={2}", 
				_page, _column, _zone != null ? _zone.ToString() : "null"
			);
		}

		#endregion Méthodes

		#region Propriétés

		/// <summary>
		/// Numéro de page de la cellule
		/// </summary>
		/// <remarks>
		/// Indique sur quelle page du rapport final la cellule doit être rendue.
		/// Utilisée lors du calcul des page breaks et new page scenarios.
		/// </remarks>
		public int Page
		{
			get { return _page; }
			set { _page = value; }
		}

		/// <summary>
		/// Numéro de la colonne de la cellule
		/// </summary>
		/// <remarks>
		/// Indique dans quelle colonne (si multi-colonnes) la cellule doit être rendue.
		/// Utilisée lors du calcul des column breaks.
		/// </remarks>
		public int Column
		{
			get { return _column; }
			set { _column = value; }
		}

		/// <summary>
		/// Zone géométrique de la cellule après modification par le traitement
		/// </summary>
		/// <remarks>
		/// Contient les coordonnées finales (left, top, width, height) calculées pendant Prepare_Report.
		/// Ces coordonnées sont utilisées lors de Render_Boxes pour positionner les boîtes dans le document.
		/// </remarks>
		public DZone Zone
		{
			get { return _zone; }
			set { _zone = value; }
		}

		/// <summary>
		/// Identifiant logique unique de la cellule
		/// </summary>
		/// <remarks>
		/// Identifiant auto-généré à partir d'un compteur incrémental.
		/// Utilisé pour identifier les cellules de manière unique dans le rapport.
		/// </remarks>
		public int LogicalId
		{
			get { return _logicalId; }
			set { _logicalId = value; }
		}

		#endregion Propriétés
	}
}
```

### DRow_Info — Complete Class

**File Location:** `QXP/QXP.Engine.Core/BusinessObject/Dynamique/Report/DRow_Info.cs`

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les informations de géométrie d'une DRow
	/// </summary>
	/// <remarks>
	/// DRow_Info encapsule les informations de layout d'une ligne dans un tableau dynamique:
	/// - Height: hauteur calculée de la ligne (maximum des hauteurs des cellules)
	/// - Width: largeur totale de la ligne
	/// - Page: le numéro de page où la ligne a été placée
	/// - Column: le numéro de colonne où la ligne a été placée
	/// 
	/// Ces informations sont calculées dans Prepare_Report_Cells et utilisées pour
	/// les calculs de page breaks et positionnement final.
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:54:22</date>    
	public class DRow_Info
	{
		#region Membres
		decimal	_height;
		decimal _width;
		int		_page;
		int		_column;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Crée une instance de DRow_Info
		/// Initialise avec valeurs par défaut
		/// </summary>
		public DRow_Info()
		{
			_height = 0;
			_width = 0;
			_page = 1;
			_column = 1;
		}

		#endregion Constructeur

		#region Méthodes

		/// <summary>
		/// Clonage des informations de la ligne
		/// </summary>
		/// <remarks>
		/// Effectue une copie des informations essentielles pour créer une nouvelle instance
		/// avec les mêmes paramètres.
		/// </remarks>
		/// <returns>Une nouvelle DRow_Info avec les mêmes valeurs</returns>
		public DRow_Info Clone()
		{
			DRow_Info __new_Row_Info = new DRow_Info();
			__new_Row_Info.Height	= this.Height;
			__new_Row_Info.Width	= this.Width;
			__new_Row_Info.Page		= this.Page;
			__new_Row_Info.Column	= this.Column;
			return __new_Row_Info;
		}

		/// <summary>
		/// Retourne une représentation texte des informations
		/// </summary>
		/// <returns>Format: "Height=H, Width=W, Page=P, Column=C"</returns>
		public override string ToString()
		{
			return string.Format(
				"Height={0}, Width={1}, Page={2}, Column={3}", 
				_height, _width, _page, _column
			);
		}

		#endregion Méthodes

		#region Propriétés

		/// <summary>
		/// Hauteur actuelle de la ligne en point
		/// </summary>
		/// <remarks>
		/// Calculée pendant Prepare_Report_Cells comme le maximum des hauteurs de cellules.
		/// Utilisée pour déterminer les sauts de page.
		/// </remarks>
		public decimal Height
		{
			get { return _height; }
			set { _height = value; }
		}

		/// <summary>
		/// Largeur actuelle de la ligne en point
		/// </summary>
		/// <remarks>
		/// Calculée comme la somme des largeurs de cellules + leurs offsets left.
		/// Actuellement informatif, pas utilisée pour les calculs de layout.
		/// </remarks>
		public decimal Width
		{
			get { return _width; }
			set { _width = value; }
		}
		
		/// <summary>
		/// Numéro de page de la ligne
		/// </summary>
		/// <remarks>
		/// Indique sur quelle page du rapport la ligne a été placée.
		/// Utilisée lors de Render_Boxes pour créer les Bloc_Page appropriés.
		/// </remarks>
		public int Page
		{
			get { return _page; }
			set { _page = value; }
		}

		/// <summary>
		/// Numéro de la colonne de la ligne
		/// </summary>
		/// <remarks>
		/// Indique dans quelle colonne (si multi-colonnes) la ligne a été placée.
		/// </remarks>
		public int Column
		{
			get { return _column; }
			set { _column = value; }
		}

		#endregion Propriétés
	}
}
```

### DTable_Info — Complete Class

**File Location:** `QXP/QXP.Engine.Core/BusinessObject/Dynamique/Report/DTable_Info.cs`

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les informations de géométrie et de layout d'un tableau dynamique
	/// </summary>
	/// <remarks>
	/// DTable_Info encapsule les informations collectées pendant le traitement d'un tableau:
	/// - TotalHeight: hauteur cumulée de toutes les lignes du tableau
	/// - StartPage: page de départ du tableau
	/// - EndPage: page de fin du tableau
	/// - NumberOfRows: nombre total de lignes après pagination
	/// 
	/// Ces informations aident à gérer les sauts de page et les break rows.
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:54:50</date>    
	public class DTable_Info
	{
		#region Membres
		decimal _totalHeight;
		int		_startPage;
		int		_endPage;
		int		_numberOfRows;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Crée une instance de DTable_Info
		/// Initialise avec valeurs par défaut
		/// </summary>
		public DTable_Info()
		{
			_totalHeight = 0;
			_startPage = 1;
			_endPage = 1;
			_numberOfRows = 0;
		}

		#endregion Constructeur

		#region Méthodes

		/// <summary>
		/// Clonage des informations du tableau
		/// </summary>
		/// <remarks>
		/// Effectue une copie des informations pour une nouvelle instance.
		/// </remarks>
		/// <returns>Une nouvelle DTable_Info avec les mêmes valeurs</returns>
		public DTable_Info Clone()
		{
			DTable_Info __new_Table_Info = new DTable_Info();
			__new_Table_Info.TotalHeight	= this.TotalHeight;
			__new_Table_Info.StartPage		= this.StartPage;
			__new_Table_Info.EndPage		= this.EndPage;
			__new_Table_Info.NumberOfRows	= this.NumberOfRows;
			return __new_Table_Info;
		}

		/// <summary>
		/// Retourne une représentation texte des informations
		/// </summary>
		/// <returns>Format: "TotalHeight=H, Pages=StartPage-EndPage, Rows=N"</returns>
		public override string ToString()
		{
			return string.Format(
				"TotalHeight={0}, Pages={1}-{2}, Rows={3}", 
				_totalHeight, _startPage, _endPage, _numberOfRows
			);
		}

		#endregion Méthodes

		#region Propriétés

		/// <summary>
		/// Hauteur totale cumulée du tableau
		/// </summary>
		/// <remarks>
		/// Somme des hauteurs de toutes les lignes du tableau.
		/// Utilisée pour déterminer si le tableau tient dans la hauteur disponible.
		/// </remarks>
		public decimal TotalHeight
		{
			get { return _totalHeight; }
			set { _totalHeight = value; }
		}

		/// <summary>
		/// Numéro de page de départ du tableau
		/// </summary>
		/// <remarks>
		/// Première page où les lignes du tableau commencent.
		/// </remarks>
		public int StartPage
		{
			get { return _startPage; }
			set { _startPage = value; }
		}

		/// <summary>
		/// Numéro de page de fin du tableau
		/// </summary>
		/// <remarks>
		/// Dernière page où les lignes du tableau se terminent.
		/// Si StartPage = EndPage, le tableau tient sur une seule page.
		/// </remarks>
		public int EndPage
		{
			get { return _endPage; }
			set { _endPage = value; }
		}

		/// <summary>
		/// Nombre de lignes du tableau après pagination
		/// </summary>
		/// <remarks>
		/// Nombre total de lignes (incluant les break rows dupliquées).
		/// </remarks>
		public int NumberOfRows
		{
			get { return _numberOfRows; }
			set { _numberOfRows = value; }
		}

		#endregion Propriétés
	}
}
```

### DSection_Info — Complete Class

**File Location:** `QXP/QXP.Engine.Core/BusinessObject/Dynamique/Report/DSection_Info.cs`

```csharp
using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;
using QXPAudit = QXP.Audit;

namespace QXP.Engine.Core
{
	/// <summary>
	/// Contient les informations de géométrie d'une section dynamique
	/// </summary>
	/// <remarks>
	/// DSection_Info encapsule les informations de layout d'une section:
	/// - Master_Page: la page maître associée à cette section
	/// - StartPage: la première page de la section
	/// - EndPage: la dernière page de la section
	/// 
	/// Ces informations aident à gérer le rendu des sections et la pagination.
	/// </remarks>
	/// <author>doufarm</author>
	/// <date>01/04/2010 10:50:45</date>    
	public class DSection_Info
	{
		#region Membres
		DMaster_Page _master_Page;
		int			 _startPage;
		int			 _endPage;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Crée une instance de DSection_Info
		/// Initialise avec valeurs par défaut
		/// </summary>
		public DSection_Info()
		{
			_master_Page = DMaster_Page.Default;
			_startPage = 1;
			_endPage = 1;
		}

		#endregion Constructeur

		#region Méthodes

		/// <summary>
		/// Clonage des informations de la section
		/// </summary>
		/// <remarks>
		/// Effectue une copie des informations pour une nouvelle instance.
		/// </remarks>
		/// <returns>Une nouvelle DSection_Info avec les mêmes valeurs</returns>
		public DSection_Info Clone()
		{
			DSection_Info __new_Section_Info = new DSection_Info();
			__new_Section_Info.Master_Page	= this.Master_Page;
			__new_Section_Info.StartPage	= this.StartPage;
			__new_Section_Info.EndPage		= this.EndPage;
			return __new_Section_Info;
		}

		/// <summary>
		/// Retourne une représentation texte des informations
		/// </summary>
		/// <returns>Format: "MasterPage=Name, Pages=StartPage-EndPage"</returns>
		public override string ToString()
		{
			string __masterPageName = _master_Page != null ? _master_Page.Name : "null";
			return string.Format(
				"MasterPage={0}, Pages={1}-{2}", 
				__masterPageName, _startPage, _endPage
			);
		}

		#endregion Méthodes

		#region Propriétés

		/// <summary>
		/// Page maître associée à cette section
		/// </summary>
		/// <remarks>
		/// Défère le layout de base pour toutes les pages de cette section.
		/// </remarks>
		public DMaster_Page Master_Page
		{
			get { return _master_Page; }
			set { _master_Page = value; }
		}

		/// <summary>
		/// Numéro de page de départ de la section
		/// </summary>
		/// <remarks>
		/// Première page où les contenus de la section sont rendus.
		/// </remarks>
		public int StartPage
		{
			get { return _startPage; }
			set { _startPage = value; }
		}

		/// <summary>
		/// Numéro de page de fin de la section
		/// </summary>
		/// <remarks>
		/// Dernière page où les contenus de la section sont rendus.
		/// Si StartPage = EndPage, la section tient sur une seule page.
		/// </remarks>
		public int EndPage
		{
			get { return _endPage; }
			set { _endPage = value; }
		}

		#endregion Propriétés
	}
}
```

---

## QXPS_Caller.Execute() - Complete Code

**File Location:** `QXP/QXP.Engine.Core/BusinessObject/QXPS/QXPS_Caller.cs`

**Complete Execute Method with Decision Logic:**

```csharp
/// <summary>
/// Executes a single task step with appropriate modifications and renderings
/// Decides between Direct_Call (HTTP) and Web Service (SOAP) modes
/// </summary>
/// <param name="step">The task step to execute</param>
private void Execute(Run_Task_Step step) 
{
    // ===== BLOCK VALUE UPDATES =====
    // Update block values (text, numbers, dates, etc.)
    if(step.NameValues.Count > 0) 
    { 
        if(step.Direct_Call)
        {
            // DIRECT MODE: Send directly to QuarkXPress Server via HTTP
            QXPInteropQuarkServer.QXPS_Message_ParamsValue __messageParamsValue = 
                new QXPInteropQuarkServer.QXPS_Message_ParamsValue();
            __messageParamsValue.NameValues = step.NameValues.ToArray();
            this.QXPS_Caller.Request_Message.Messages.Add(__messageParamsValue);
        }
        else
        {
            // WEB SERVICE MODE: Send via QXPSM/SOAP to QuarkXPress Manager
            QXPInteropQuarkServer.QXPSM_Request_ParamsValue __requestValue = 
                new QXPInteropQuarkServer.QXPSM_Request_ParamsValue(
                    step.NameValues.ToArray()
                );
            this.QXPSM_Caller.Requests.Add(__requestValue);
        }
    }

    // ===== STRUCTURAL MODIFICATIONS =====
    // Modify document structure (add/remove boxes, change layout, etc.)
    if(!step.Modifier.Empty) 
    { 
        if(step.Direct_Call)
        {
            // DIRECT MODE: Upload XML file containing modifications
            string __modify_Name = QXPS_File_Manager.GetPoolPath(
                string.Format(ModifyNamePattern, DateTime.Now)
            );
            QXPS_File_Manager.Addfile(__modify_Name, step.Modifier.GetIOValue().To_Bytes());

            // Add direct call to apply modifier
            QXPInteropQuarkServer.QXPS_Message_Modify __messageModifier = 
                new QXPInteropQuarkServer.QXPS_Message_Modify();
            __messageModifier.Modify_File = __modify_Name;
            this.QXPS_Caller.Request_Message.Messages.Add(__messageModifier);
        }
        else
        {
            // WEB SERVICE MODE: Send via QXPSM/SOAP
            QXPInteropQuarkServer.QXPSM_Request_Modifier __requestModifier = 
                new QXPInteropQuarkServer.QXPSM_Request_Modifier(
                    step.Modifier.GetProject()
                );
            this.QXPSM_Caller.Requests.Add(__requestModifier);
        }
    }

    // ===== RENDER QXP (IF NEEDED) =====
    // Must render to QXP before saving
    if(step.Direct_Call)
    {
        // Direct mode: render QXP first
        QXPInteropQuarkServer.QXPS_Message_QXP __messageQXP = 
            new QXPInteropQuarkServer.QXPS_Message_QXP();
        this.QXPS_Caller.Request_Message.Messages.Add(__messageQXP);
    }
    else
    {
        // Web service mode: add QXP render request to chain
        QXPInteropQuarkServer.QXPSM_Request_QXP __requestQXP = 
            new QXPInteropQuarkServer.QXPSM_Request_QXP();
        this.QXPSM_Caller.Requests.Add(__requestQXP);
    }

    // ===== SAVE DOCUMENT WITH NEW NAME =====
    // Save the modified document
    if(step.Direct_Call)
    {
        // Direct mode: Send SaveAs message
        QXPInteropQuarkServer.QXPS_Message_SaveAs __messageSaveAs = 
            new QXPInteropQuarkServer.QXPS_Message_SaveAs();
        __messageSaveAs.Path = QXPS_File_Manager.GetPoolPathAbsolute(string.Empty);
        __messageSaveAs.New_Name = GetNewGabaritNameExt();
        __messageSaveAs.Replace = true;
        __messageSaveAs.SaveToPool = false;
        this.QXPS_Caller.Request_Message.Messages.Add(__messageSaveAs);
    }
    else
    {
        // Web service mode: Add SaveAs to request chain
        QXPInteropQuarkServer.QXPSM_Request_SaveAs __requestSaveAs = 
            new QXPInteropQuarkServer.QXPSM_Request_SaveAs(
                QXPS_File_Manager.GetPoolPathAbsolute(string.Empty),
                GetNewGabaritNameExt(),
                true,
                false
            );
        this.QXPSM_Caller.Requests.Add(__requestSaveAs);
    }

    // ===== EXECUTE CALLS =====
    if(step.Direct_Call)
    {
        // Direct call to QuarkXPress Server via HTTP
        this.QXPS_Caller.SDKCall();
    }
    else
    {
        // Web service call: Send all chained requests via SOAP
        this.QXPSM_Caller.SDKCall();
    }

    // ===== RETRIEVE NEW DOCUMENT FROM POOL =====
    // Get the newly created version
    string __newPoolName = _request.Run.Gabarit.FilePoolPath;
    QXPS_File_Manager.Addfile_Inform(__newPoolName);

    // Update context with new document name
    this.QXPS_Caller.Request_Message.Call_Info.DocumentName = __newPoolName;
    if(QXPFrk.Validation.IsNotNull(this.QXPSM_Caller.SDK_Context))
    {
        this.QXPSM_Caller.SDK_Context.documentName = __newPoolName;
    }

    // Increment execution counter
    _execution_count++;
}
```

### Complete Decision Tree

```
Execute(step)
│
├─ Check step.NameValues.Count > 0
│  │
│  ├─ IF step.Direct_Call = TRUE
│  │  └─ Create QXPS_Message_ParamsValue
│  │     └─ Add to QXPS_Caller.Request_Message.Messages[]
│  │
│  └─ IF step.Direct_Call = FALSE
│     └─ Create QXPSM_Request_ParamsValue
│        └─ Add to QXPSM_Caller.Requests list
│
├─ Check !step.Modifier.Empty
│  │
│  ├─ IF step.Direct_Call = TRUE
│  │  ├─ Get modifier filename
│  │  ├─ Upload XML via QXPS_File_Manager
│  │  └─ Create QXPS_Message_Modify
│  │     └─ Add to QXPS_Caller.Request_Message.Messages[]
│  │
│  └─ IF step.Direct_Call = FALSE
│     └─ Create QXPSM_Request_Modifier (project DOM)
│        └─ Add to QXPSM_Caller.Requests list
│
├─ Render to QXP
│  │
│  ├─ IF step.Direct_Call = TRUE
│  │  └─ Create QXPS_Message_QXP
│  │     └─ Add to QXPS_Caller.Request_Message.Messages[]
│  │
│  └─ IF step.Direct_Call = FALSE
│     └─ Create QXPSM_Request_QXP
│        └─ Add to QXPSM_Caller.Requests list
│
├─ Save with new name
│  │
│  ├─ IF step.Direct_Call = TRUE
│  │  └─ Create QXPS_Message_SaveAs
│  │     └─ Add to QXPS_Caller.Request_Message.Messages[]
│  │
│  └─ IF step.Direct_Call = FALSE
│     └─ Create QXPSM_Request_SaveAs
│        └─ Add to QXPSM_Caller.Requests list
│
├─ Execute accumulated requests
│  │
│  ├─ IF step.Direct_Call = TRUE
│  │  └─ QXPS_Caller.SDKCall()
│  │     └─ For each message in QXPS_Caller.Request_Message.Messages[]
│  │        ├─ Serialize to HTTP POST
│  │        ├─ Send to QuarkXPress Server directly
│  │        └─ Receive individual response
│  │
│  └─ IF step.Direct_Call = FALSE
│     └─ QXPSM_Caller.SDKCall()
│        ├─ Chain all requests in Requests list
│        ├─ Serialize entire chain to SOAP XML
│        ├─ Send to QuarkXPress Manager
│        └─ Receive single response
│
└─ Update document pool and context
   ├─ Get new document from pool
   ├─ Update QXPS_Caller.Request_Message.Call_Info.DocumentName
   ├─ Update QXPSM_Caller.SDK_Context.documentName
   └─ Increment _execution_count
```

---

## Direct Call vs Web Service Flow

### Direct Call Mode (HTTP)

```
Execute()
  ├─ Create QXPS_Message_ParamsValue
  ├─ Create QXPS_Message_Modify
  ├─ Create QXPS_Message_QXP
  ├─ Create QXPS_Message_SaveAs
  └─ Add all to Request_Message.Messages[]

Then:
  QXPS_Caller.SDKCall()
    ├─ Message 1 → HTTP POST → Server → Response 1
    ├─ Message 2 → HTTP POST → Server → Response 2
    ├─ Message 3 → HTTP POST → Server → Response 3
    └─ Message 4 → HTTP POST → Server → Response 4

Result: 4 HTTP round-trips (slower)
```

### Web Service Mode (SOAP Chain)

```
Execute()
  ├─ Create QXPSM_Request_ParamsValue
  ├─ Create QXPSM_Request_Modifier
  ├─ Create QXPSM_Request_QXP
  ├─ Create QXPSM_Request_SaveAs
  └─ Add all to QXPSM_Caller.Requests list

Then:
  QXPSM_Caller.SDKCall()
    ├─ Chain requests: req1.request = req2; req2.request = req3; etc.
    ├─ Serialize entire chain to SOAP XML
    ├─ Single SOAP HTTP POST → Manager
    │  ├─ Manager processes Request 1 (ParamsValue)
    │  ├─ Manager processes Request 2 (Modifier)
    │  ├─ Manager processes Request 3 (QXP Render)
    │  └─ Manager processes Request 4 (SaveAs)
    └─ Single response returned

Result: 1 HTTP round-trip (faster)
```

---

## Request Chaining Architecture

### How the Chain Works

```csharp
// In QXPSM_Call.SDKCall():

List<QXPSM_Request_Base> requests = [
    new QXPSM_Request_ParamsValue(...),
    new QXPSM_Request_Modifier(...),
    new QXPSM_Request_QXP(),
    new QXPSM_Request_SaveAs(...)
];

// Build linked chain:
QXPSMSDK.QRequest __first = null;
QXPSMSDK.QRequest __last = null;

foreach(request in requests)
{
    if(__first == null)
    {
        __first = __last = request.Request;
    }
    else
    {
        __last.request = request.Request;  // Link requests
        __last = __last.request;            // Advance
    }
}

// Result:
__first → RequestParameters
          .request → ModifierRequest
                     .request → QuarkXPressRenderRequest
                                .request → SaveAsRequest
                                           .request → NULL

// Attach to context:
_sdk_context.request = __first;

// Send one SOAP call with entire chain:
_sdk_response = _sdk_service.processRequest(_sdk_context);
```

### SOAP XML Chain Structure

```xml
<soap:Envelope>
  <soap:Body>
    <QRequest type="RequestParameters">
      <@params>
        <NameValueParam>
          <name>CustomerName</name>
          <value>John Smith</value>
        </NameValueParam>
      </@params>
      
      <request type="ModifierRequest">
        <project>
          <pages>
            <Page name="Page1">
              <boxes>
                <Box name="TextBox1">
                  <content>
                    <value>New Text</value>
                  </content>
                </Box>
              </boxes>
            </Page>
          </pages>
        </project>
        
        <request type="QuarkXPressRenderRequest">
          <request type="SaveAsRequest">
            <path>/opt/quark/output</path>
            <newFileName>Report_Final.qxp</newFileName>
            <replace>true</replace>
            <saveToPool>true</saveToPool>
            
            <request/>
          </request>
        </request>
      </request>
    </QRequest>
  </soap:Body>
</soap:Envelope>
```

### Server Processing Order

1. **RequestParameters** - Update block values
2. **ModifierRequest** - Apply structural changes
3. **QuarkXPressRenderRequest** - Render updated document
4. **SaveAsRequest** - Save rendered output

Each request feeds into the next: updated document → modified document → rendered document → saved document

---

## Summary

### Mode Comparison

| Aspect | Direct Call | Web Service |
|--------|-------------|-------------|
| Network Calls | Multiple (1 per operation) | Single (all in chain) |
| Performance | Slower (high latency) | Faster (low latency) |
| Debugging | Easier (see per-op response) | Harder (single response) |
| Complexity | Lower | Higher (chaining logic) |
| Use Case | Simple operations | Complex workflows |

### When to Use Each

**Use Direct Call:**
- Single operation per step
- Debugging required
- Working with QuarkXPress Server directly

**Use Web Service:**
- Multiple sequential operations
- High-volume processing
- Network optimization needed
- Complex workflows (update + modify + render + save)

---

**Document Status:** Complete ✓  
**All Classes:** Included ✓  
**Flow Diagrams:** Included ✓  
**SOAP Examples:** Included ✓  
**Decision Logic:** Complete ✓  
**Dynamique Classes:** Complete ✓
