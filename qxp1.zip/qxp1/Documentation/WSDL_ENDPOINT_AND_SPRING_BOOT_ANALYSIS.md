# WSDL Endpoint Analysis & Spring Boot Integration Guide
**File analysed:** `QXP.Interop/Web References/QXPSMSDK/qxpsmsdk.wsdl`

---

## 1. Is the WSDL Bound to Localhost Only?

**Short answer: No — `localhost` is a default, not a hard restriction. It can and should be changed for any real deployment.**

---

## 2. What the WSDL Says

At the very bottom of `qxpsmsdk.wsdl` (line 3402):

```xml
<wsdl:service name="QManagerSDKSvcService">
  <wsdl:port name="qxpsmsdk" binding="intf:qxpsmsdkSoapBinding">
    <wsdlsoap:address location="http://localhost:8090/quark/services/qxpsmsdk" />
  </wsdl:port>
</wsdl:service>
```

This `<wsdlsoap:address location="..."/>` is the **default endpoint** that was baked in when the WSDL was originally captured from the Quark server running on the developer's machine.
It is **not a security lock** — it is simply the address the WSDL was discovered from.

Also confirmed in `Reference.map`:
```xml
<DiscoveryClientResult
  url="http://localhost:8090/quark/services/qxpsmsdk?wsdl"
  filename="qxpsmsdk.wsdl" />
```
This means the WSDL was originally downloaded from a local Quark instance running on port `8090`.

---

## 3. How This Project Actually Overrides the URL (C# Side)

The generated proxy class `Reference.cs` does **not** hardcode `localhost`. Instead:

```csharp
// Reference.cs — QManagerSDKSvcService constructor
public QManagerSDKSvcService() {
    // Reads the URL from App.config / applicationSettings at runtime
    this.Url = global::QXP.Interop.Properties.Settings.Default
                   .QXP_Interop_QXPSMSDK_QManagerSDKSvcService;
}
```

In `App.config` (development):
```xml
<setting name="QXP_Interop_QXPSMSDK_QManagerSDKSvcService" serializeAs="String">
  <value>http://localhost:8090/qxpsm/services/RequestService</value>
</setting>
```

In `AppConfigReleaseTemplate.config` (production/CI — placeholder replaced at deploy time):
```xml
<setting name="QXP_Interop_QXPSMSDK_QManagerSDKSvcService" serializeAs="String">
  <value>{{QXP_Interop_QXPSMSDK_QManagerSDKSvcService}}</value>
</setting>
```

> **Key insight:** The URL is fully externalised via config. To point at a remote Quark server,
> you simply change the config value — no code or WSDL regeneration needed.

---

## 4. Understanding the URL Structure

```
http://localhost:8090/quark/services/qxpsmsdk
│        │        │    │               │
│        │        │    │               └── Specific SOAP service name (the endpoint)
│        │        │    └── Quark servlet path
│        │        └── Port where Quark Server Manager listens
│        └── Host — replace with actual server IP/hostname for remote calls
└── Protocol — can be changed to https for secure remote access
```

The two services configured in `App.config`:

| Setting Key | Default Value | Purpose |
|---|---|---|
| `QXP_Interop_QXPSMSDK_QManagerSDKSvcService` | `http://localhost:8090/qxpsm/services/RequestService` | Main SDK service (document processing) |
| `QXP_Interop_QXPSMSDK_QServerSDKSvcService` | `http://localhost:8080/qxpsm/services/RequestService` | Server SDK service |

---

## 5. Exposed SOAP Operations (from the WSDL)

The WSDL exposes these callable operations on `QManagerSDKSvcService`:

| Operation | Purpose |
|---|---|
| `createSession` | Open a session with the Quark server |
| `closeSession` | Close an existing session |
| `openDoc` | Open a Quark document |
| `newDoc` | Create a new document |
| `closeDoc` / `closeAllDocs` | Close open documents |
| `processRequest` / `processRequestEx` | Send XML commands to Quark (main workhorse) |
| `getXPressDOM` / `getXPressDOMEx` | Fetch the document object model |
| `getXPressDOMFromXML` | Build DOM from XML |
| `getXMLFromXPressDOM` | Export DOM as XML |
| `getOpenDocs` | List currently open documents |
| `getOpenSessions` | List active sessions |
| `getPreferences` / `setPreferences` | Read/write server preferences |
| `saveDoc` / `saveAllDocs` | Save documents |
| `getErrorObject` | Retrieve error details |

---

## 6. Spring Boot Equivalent Flow

This section explains how the exact same WSDL would be integrated in a **Java Spring Boot** application.

### Step 1 — Generate Java Classes from the WSDL

Using Maven `jaxws-maven-plugin` (equivalent to Visual Studio "Add Web Reference"):

```xml
<!-- pom.xml -->
<plugin>
  <groupId>com.sun.xml.ws</groupId>
  <artifactId>jaxws-maven-plugin</artifactId>
  <configuration>
    <wsdlUrls>
      <!-- Point directly at the live server OR use the local file -->
      <wsdlUrl>http://QUARK_SERVER_HOST:8090/quark/services/qxpsmsdk?wsdl</wsdlUrl>
    </wsdlUrls>
    <packageName>com.quark.qxpsm</packageName>
  </configuration>
</plugin>
```

This generates the same classes that `Reference.cs` contains, but as Java:
- `QManagerSDKSvcService.java` — the interface (all SOAP operations)
- `QManagerSDKSvcService_Service.java` — the factory that creates the proxy
- `QException.java`, `QOpenDocData.java`, `QContentData.java`, etc.

---

### Step 2 — Externalise the URL in `application.properties`

This is the Spring Boot equivalent of overriding the URL in `App.config`:

```properties
# application.properties (development)
quark.soap.url=http://localhost:8090/quark/services/qxpsmsdk

# application-prod.properties (production — different host/port)
quark.soap.url=http://quark-server.internal.company.com:8090/quark/services/qxpsmsdk
```

Spring Boot automatically picks the right profile (`-Dspring.profiles.active=prod`),
exactly like the `AppConfigReleaseTemplate.config` placeholder mechanism does at CI/CD time.

---

### Step 3 — Spring `@Configuration` Bean (Equivalent of the C# Constructor)

In `Reference.cs`, the constructor reads the URL from settings and sets `this.Url`.
In Spring Boot, a `@Configuration` class does the same job:

```java
// QuarkSoapConfig.java
@Configuration
public class QuarkSoapConfig {

    // Reads from application.properties — NOT hardcoded
    @Value("${quark.soap.url}")
    private String quarkSoapUrl;

    @Bean
    public QManagerSDKSvcService qxpsmServicePort() {
        // The WSDL default says localhost:8090 — we override it here
        QManagerSDKSvcService_Service serviceFactory = new QManagerSDKSvcService_Service();
        QManagerSDKSvcService port = serviceFactory.getQxpsmsdk();

        // This is the critical override — same concept as setting this.Url in C#
        ((BindingProvider) port)
            .getRequestContext()
            .put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, quarkSoapUrl);

        return port;
    }
}
```

> **This single line is the answer to your question:**
> ```java
> .put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, quarkSoapUrl);
> ```
> It overrides whatever `localhost` URL the WSDL declared, pointing the client at any host.

---

### Step 4 — Injection and Usage in a Service

```java
// QuarkDocumentService.java
@Service
public class QuarkDocumentService {

    private final QManagerSDKSvcService qxpsmPort;

    // Spring injects the bean configured above
    public QuarkDocumentService(QManagerSDKSvcService qxpsmPort) {
        this.qxpsmPort = qxpsmPort;
    }

    public String openSession(String username, String password) {
        // Calls the SOAP operation defined in the WSDL
        QResponseHeader response = qxpsmPort.createSession(username, password);
        return response.getSessionId();
    }

    public void processQuarkRequest(String sessionId, String xmlRequest) {
        // processRequest / processRequestEx — main workhorse operation
        qxpsmPort.processRequest(sessionId, xmlRequest);
    }
}
```

---

### Step 5 — Full Call Flow Diagram

```
Spring Boot Application
│
├── application.properties
│     quark.soap.url=http://QUARK_HOST:8090/quark/services/qxpsmsdk
│
├── QuarkSoapConfig (@Configuration)
│     reads quark.soap.url  ──────────────────────────────────────────┐
│     creates QManagerSDKSvcService_Service (factory)                 │
│     overrides endpoint via BindingProvider  ◄────────────────────────┘
│     exposes QManagerSDKSvcService as @Bean
│
├── QuarkDocumentService (@Service)
│     injects QManagerSDKSvcService @Bean
│     calls: createSession(), openDoc(), processRequest(), etc.
│
└── HTTP/SOAP Wire
      POST http://QUARK_HOST:8090/quark/services/qxpsmsdk
      Content-Type: text/xml
      SOAPAction: ""
      <soap:Envelope>...</soap:Envelope>
                │
                ▼
      Quark Server Manager (Java-based, Apache Axis)
      Processes the request, returns SOAP response
```

---

## 7. Summary — Key Takeaways

| Question | Answer |
|---|---|
| Is the WSDL locked to localhost? | **No.** `localhost:8090` is only the default discovery address |
| Can it call a remote server? | **Yes.** Change the URL in config — no WSDL change needed |
| How does this project change it? | Via `App.config` → `applicationSettings` → `QXP_Interop_QXPSMSDK_QManagerSDKSvcService` |
| In Spring Boot, how to change it? | Via `application.properties` + `BindingProvider.ENDPOINT_ADDRESS_PROPERTY` |
| Is port 8090 fixed? | **No.** It is the Quark Server Manager default port — configurable on the server side |
| Protocol fixed to HTTP? | **No.** Can be changed to `https://` for secure remote access |

---

## 8. Recommended Configuration for Different Environments

```properties
# Local development (matches WSDL default)
quark.soap.url=http://localhost:8090/quark/services/qxpsmsdk

# UAT / staging
quark.soap.url=http://quark-uat.company.com:8090/quark/services/qxpsmsdk

# Production
quark.soap.url=https://quark-prod.company.com:8090/quark/services/qxpsmsdk
```

No WSDL regeneration. No code change. **Config change only.**

