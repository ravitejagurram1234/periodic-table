# UploadManager.Check() - Visual Process Map

**Version:** 1.0  
**Date:** March 12, 2026  

---

## QUICK VISUAL OVERVIEW

### What Does Check() Do?

```
              ┌─────────────────────────┐
              │  UploadManager.Check()  │
              │   (Main Method)         │
              └────────────┬────────────┘
                           │
           ┌───────────────┼───────────────┐
           │               │               │
           ▼               ▼               ▼
    Thread-Safety    Database    Initialize
    Flag Check      Query         Logging
           │               │               │
           └───────────────┼───────────────┘
                           │
                    ┌──────▼──────┐
                    │ New Uploads │
                    │ Found?      │
                    └──────┬──────┘
                        NO │ ───→ Exit Early
                           │
                          YES
                           │
                    ┌──────▼──────────────────┐
                    │ For Each Upload:        │
                    │ 1. Load document       │
                    │ 2. Upload to Quark     │
                    │ 3. Extract metadata    │
                    │ 4. Create run task     │
                    │ 5. Queue for execution │
                    └──────┬─────────────────┘
                           │
                           ▼
                    ┌──────────────────┐
                    │ Wake Worker      │
                    │ Threads          │
                    └──────┬───────────┘
                           │
                    ┌──────▼──────────┐
                    │ Handle Errors   │
                    │ & Cleanup       │
                    └──────┬──────────┘
                           │
                           ▼
                    ┌──────────────────┐
                    │ Reset & Return   │
                    └──────────────────┘
```

---

## DETAILED PROCESS FLOW

### Step 1: Thread-Safety Check
```
if(Running == true)
  → Another thread already executing
  → Log "Running"
  → EXIT (return immediately)

else
  → Set Running = true
  → Proceed to Step 2
```

**Prevents:** Multiple simultaneous executions

---

### Step 2: Query Database for Uploads
```
┌──────────────────────────────────────┐
│ DocumentProxy.GetNewUploadDocuments()│
└──────────────────────────────────────┘
              │
              ▼
    ┌─────────────────────┐
    │ Oracle Stored Proc  │
    │ Get_New_Upload      │
    └─────────────────────┘
              │
              ▼
    List<int> uploadIds
    [1001, 1002, 1003]
```

**Returns:** Upload IDs waiting to process

---

### Step 3: Check if Empty
```
uploadIds.Count == 0 ?
    │
    ├─→ YES → Log "No uploads" → Set Running=false → RETURN
    │
    └─→ NO → Continue to Step 4
```

---

### Step 4: Load Document Details
```
For Each ID in uploadIds:

┌──────────────────────────────────────┐
│ DocumentProxy.GetUploadDocument(id)  │
└──────────────────────────────────────┘
              │
              ▼
    ┌─────────────────────┐
    │ Oracle Stored Proc  │
    │ Get_Upload_Document │
    └─────────────────────┘
              │
              ▼
    ┌───────────────────────┐
    │ Document Object       │
    │ - ID: 1001            │
    │ - Name: "Upload"      │
    │ - Format: "QXP"       │
    │ - Data: [bytes...]    │
    └───────────────────────┘
```

**Returns:** Full document objects with binary data

---

### Step 5a: Upload to QuarkXPress Server
```
┌─────────────────────────────────────┐
│ QXPS_File_Manager.Addfile()         │
│ (For each document)                 │
└─────────────────────────────────────┘
              │
    ┌─────────┼─────────┐
    │         │         │
    ▼         ▼         ▼
Save Local  Upload to  Track
  Backup    Quark      Added
            Server     Files


[Local Disk]  [Quark Server]  [Memory]
```

**Purpose:** Store document on Quark for processing

---

### Step 5b: Extract Document Metadata (DID)
```
┌──────────────────────────────────────────────┐
│ Document_Identity_Helper.Get_Identity()      │
└──────────────────────────────────────────────┘
              │
              ▼
┌──────────────────────────────────────────────┐
│ Query Quark Server for document XML          │
│ QXPS_Helper.Get_Xml()                        │
└──────────────────────────────────────────────┘
              │
              ▼
    ┌───────────────────────────┐
    │ XML Response (from Quark) │
    │ <DID>                     │
    │   FND001|5001|100|1|...   │
    │ </DID>                    │
    └───────────────────────────┘
              │
              ▼
    ┌───────────────────────────┐
    │ QXP_XML Parser            │
    └───────────────────────────┘
              │
              ▼
    ┌───────────────────────────┐
    │ Document_Identity Object  │
    │ - Fnd_Code: "FND001"      │
    │ - Id_Suivi: 5001          │
    │ - Id_Run: 100             │
    │ - Id_Langue: 1            │
    │ - Date_Echeance: ...      │
    │ - Is_Defined: true        │
    └───────────────────────────┘
```

**Extracts:** Document metadata from XML

---

### Step 5c: Validate Metadata
```
Document_Identity.Is_Defined ?
    │
    ├─→ FALSE
    │   └─→ Add to error list
    │       "DID field missing or invalid"
    │
    └─→ TRUE
        └─→ Continue to Step 5d
```

---

### Step 5d: Create Run Task
```
┌──────────────────────────────────────┐
│ RunProxy.CreateRunUpload()           │
│ (Parameters: Id_Suivi, Upload_ID)    │
└──────────────────────────────────────┘
              │
              ▼
    ┌─────────────────────┐
    │ Oracle Stored Proc  │
    │ Create_Run_Upload   │
    └─────────────────────┘
              │
              ▼
    ┌─────────────────────┐
    │ Return Code:        │
    │ -2 = Locked         │
    │ -1 = Already there  │
    │  0 = Error          │
    │ >0 = Success (ID)   │
    └─────────────────────┘
              │
    ┌─────────┼─────────┬─────────┐
    │         │         │         │
    ▼         ▼         ▼         ▼
  ERROR    ERROR    ERROR    SUCCESS
   (-2)     (-1)      (0)    (e.g. 500)
    │         │         │         │
    └─────────┼─────────┴────┬────┘
              │              │
        Add to Error    Continue
        Dictionary      to Step 6
```

---

### Step 6: Queue for Processing
```
For Each Successful Run (ID > 0):

┌────────────────────────────────────────┐
│ Run_Queue_Item(run_id)                 │
│ Wraps: run_id = 500                    │
└────────────────────────────────────────┘
              │
              ▼
┌────────────────────────────────────────┐
│ Run_Queue.Enqueue(item)                │
│ Thread-safe queue operation            │
│ Uses: lock(SyncRoot)                   │
└────────────────────────────────────────┘
              │
              ▼
    ┌─────────────────────────┐
    │ IN-MEMORY QUEUE         │
    │ ┌─────┐                 │
    │ │ 498 │◄──              │
    │ ├─────┤   Add Item      │
    │ │ 499 │  (if not        │
    │ ├─────┤   duplicate)    │
    │ │ 500 │◄──              │
    │ ├─────┤                 │
    │ │ 501 │                 │
    │ └─────┘                 │
    └─────────────────────────┘
         (FIFO Order)
```

---

### Step 7: Wake Worker Threads
```
┌────────────────────────────────────────┐
│ Worker_Thread.Set_Loop_Events()        │
│ For each AutoResetEvent in Loops_Event:│
│   └─ event.Set()                       │
└────────────────────────────────────────┘
              │
    ┌─────────┼─────────┬─────────┐
    │         │         │         │
    ▼         ▼         ▼         ▼
  Thread    Thread    Thread   Thread
  #1        #2        #3       #N
  WAITING   WAITING   WAITING  WAITING
    │         │         │         │
    └─────────┴─────────┴─────────┘
              │
    Woken by event.Set()
              │
              ▼
         ┌─────────┐
         │ AWAKE   │
         │ Start   │
         │ Processing
         └─────────┘
```

---

### Step 8: Handle Errors
```
┌─────────────────────────────────────────┐
│ For All Failed Uploads:                 │
│ Dictionary<int, string>                 │
│ {                                       │
│   1001: "DID field missing",            │
│   1003: "Suivi is locked"               │
│ }                                       │
└─────────────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────┐
│ DocumentProxy.UpdateUploadErrors()      │
└─────────────────────────────────────────┘
              │
              ▼
    ┌─────────────────────┐
    │ Oracle Stored Proc  │
    │ Update_Upload_With_ │
    │ Errors              │
    └─────────────────────┘
              │
              ▼
    ┌─────────────────────────┐
    │ DATABASE UPDATED        │
    │ Error messages recorded │
    └─────────────────────────┘
```

---

### Step 9: Cleanup
```
┌──────────────────────────────────┐
│ QXPS_File_Manager                │
│ .PurgeAddedFiles(false)          │
└──────────────────────────────────┘
        │          │         │
        ▼          ▼         ▼
    For Each   Quark      Clear
    File      Server      Tracking
    Added     DeleteFile  List
        │          │         │
        └──────────┼─────────┘
                   ▼
        ┌──────────────────────┐
        │ Quark Files Removed  │
        │ Memory Cleared       │
        └──────────────────────┘
```

---

### Step 10: Reset & Return
```
┌─────────────────────────────────┐
│ Finally Block (Always Executes) │
└─────────────────────────────────┘
              │
              ▼
    ┌─────────────────────┐
    │ Running = false     │
    │ (Reset Flag)        │
    └─────────────────────┘
              │
              ▼
    ┌─────────────────────┐
    │ Log "End check"     │
    └─────────────────────┘
              │
              ▼
    ┌─────────────────────┐
    │ Return to Watcher   │
    └─────────────────────┘
```

---

## COMPLETE PROCESS MAP

```
                        ┌─────────────────────┐
                        │ Watcher Main Loop   │
                        │ (Every 2 seconds)   │
                        └────────────┬────────┘
                                     │
                                     ▼
                        ┌─────────────────────┐
                        │ Check Running Flag  │
                        │ (Thread-Safe)       │
                        └────────────┬────────┘
                                     │
                        ┌────────────┴────────────┐
                        │                         │
                     Already             Not Running
                    Running                    │
                        │                      ▼
                      EXIT            ┌────────────────────────┐
                                      │ DocumentProxy.GetNew   │
                                      │ UploadDocuments()      │
                                      │ [Oracle Query]         │
                                      └────────────┬───────────┘
                                                   │
                                          ┌────────▼────────┐
                                          │ Uploads Found?  │
                                          └────────┬────────┘
                                                   │
                                        ┌──────────┴──────────┐
                                        │                     │
                                       NO                    YES
                                        │                     │
                                      EXIT            ┌──────▼────────────┐
                                                      │ DocumentProxy     │
                                                      │ LoadUploadDocuments
                                                      │ [Oracle Query]    │
                                                      └──────┬────────────┘
                                                             │
                                                    ┌────────▼────────────┐
                                                    │ For Each Document:  │
                                                    │ 1. QXPS_File_Mgr   │
                                                    │    .Addfile()       │
                                                    │    [Upload to      │
                                                    │     Quark Server]  │
                                                    │                    │
                                                    │ 2. Document_       │
                                                    │    Identity_Helper │
                                                    │    .Get_Identity() │
                                                    │    [Query Quark]   │
                                                    │                    │
                                                    │ 3. RunProxy        │
                                                    │    .Create_        │
                                                    │    RunUpload()     │
                                                    │    [Oracle Insert] │
                                                    │                    │
                                                    │ 4. Run_Queue       │
                                                    │    .Enqueue()      │
                                                    │    [Queue Task]    │
                                                    │                    │
                                                    │ 5. Error handling  │
                                                    └────────┬───────────┘
                                                             │
                                                    ┌────────▼───────────┐
                                                    │ Worker_Thread      │
                                                    │ .Set_Loop_Events() │
                                                    │ [Signal threads]   │
                                                    └────────┬───────────┘
                                                             │
                                                    ┌────────▼───────────┐
                                                    │ DocumentProxy      │
                                                    │ .UpdateUploadErrors
                                                    │ [Oracle Update]    │
                                                    └────────┬───────────┘
                                                             │
                                                    ┌────────▼───────────┐
                                                    │ QXPS_File_Mgr      │
                                                    │ .PurgeAddedFiles() │
                                                    │ [Cleanup]          │
                                                    └────────┬───────────┘
                                                             │
                                                    ┌────────▼───────────┐
                                                    │ Set Running=false  │
                                                    │ [Reset Flag]       │
                                                    └────────┬───────────┘
                                                             │
                                                    ┌────────▼───────────┐
                                                    │ Return to Watcher  │
                                                    │ Loop               │
                                                    └───────────────────┘
```

---

## ERROR HANDLING PATHS

```
        ┌──────────────────────┐
        │ Processing Document  │
        └──────────────┬───────┘
                       │
        ┌──────────────┴──────────────┐
        │                             │
        ▼                             ▼
    ┌─────────────┐         ┌──────────────────┐
    │ Try Block   │         │ Catch Block      │
    │ SUCCESS     │         │ (Exception)      │
    └─────┬───────┘         └────────┬─────────┘
          │                          │
          ▼                          ▼
    ┌──────────────────────────────────────┐
    │ Error_Helper.LogError()              │
    │ Add to error_upload_ids dictionary   │
    │ Store error message                  │
    └────────────┬─────────────────────────┘
                 │
                 ▼
    ┌────────────────────────────┐
    │ Continue with Next Document│
    │ (Don't break loop)         │
    └────────────────────────────┘
                 │
                 ▼
    ┌────────────────────────────┐
    │ Batch Update All Errors    │
    │ To Database At End         │
    └────────────────────────────┘
```

---

## KEY SYNCHRONIZATION POINTS

### Thread-Safety Mechanisms

1. **Running Flag**
   - Single boolean: prevents concurrent execution
   - Set at start, reset in finally block

2. **Run_Queue Locking**
   ```csharp
   lock(SyncRoot)
   {
       // Only one thread at a time
   }
   ```

3. **AutoResetEvent Signaling**
   - Wakes sleeping threads
   - Allows efficient wait-based processing

---

## DATA TRANSFORMATIONS

```
Raw Upload Bytes
    ↓
[QXPS_File_Manager.Addfile()]
    ↓
Quark Server File
    ↓
[Document_Identity_Helper.Get_Identity()]
    ↓
Document_Identity Object
    ↓
[RunProxy.CreateRunUpload()]
    ↓
Run Record (ID)
    ↓
[Run_Queue_Item]
    ↓
Run_Queue (In-Memory)
    ↓
Worker Thread picks it up
    ↓
[QXP.Engine.exe launched]
    ↓
Document Generated
    ↓
Result stored in Database
```

---

## PERFORMANCE CHARACTERISTICS

| Operation | Type | Time | Blocking |
|-----------|------|------|----------|
| Query uploads | DB | ~100ms | Yes |
| Load document | DB + IO | ~200ms | Yes |
| Upload to Quark | Network | ~500ms | Yes |
| Extract metadata | Network | ~300ms | Yes |
| Create run | DB | ~100ms | Yes |
| Queue item | Memory | <1ms | No |
| Wake threads | Event | <1ms | No |
| Cleanup | Network | ~200ms | Yes |

**Total Time:** 1.5-2 seconds per document (varies with network)

---

## CONCLUSION

The `UploadManager.Check()` method orchestrates a complex multi-system workflow that safely transforms user uploads into executable batch tasks, with comprehensive error handling and thread-safe operations throughout.


