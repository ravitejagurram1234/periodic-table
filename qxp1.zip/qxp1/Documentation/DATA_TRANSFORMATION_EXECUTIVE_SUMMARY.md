# Data Transformation Analysis - Executive Summary

## Question
How is the data modified from what the database returns to what appears in the HTML dropdown?

## Answer

The data transformation happens through **7 sequential layers**, with the most significant transformation being the **localization/translation layer**:

### Layer 1: Database Query ✓
```
Returns: (11, "sc11"), (12, "sc12"), (17, "sc17"), ...
Source: QXP_PK_CHARGEMENT.GetListeSousCategorie() stored procedure
```

### Layer 2: Label Translation ★ KEY TRANSFORMATION ★
```
Process: Resources.GetLabel("SousCategorie", value)
- For each database value, looks up translation in Oracle localization table
- "sc11"  → "Plaquette"
- "sc12"  → "Rapport annuel"
- "sc17"  → "Composition d'actif"
- "DICI"  → "DICI" (unchanged - already a label)
- etc.

Files Involved:
- ResourceManager.cs: Pattern construction & caching
- ResourcesProxy.cs: Oracle query execution
- Oracle Database: Translation lookup table
```

### Layer 3: Business Object Creation
```
Creates SousCategorie objects with:
- idSousCategorie (numeric ID)
- libelleSousCategorie (TRANSLATED label)
```

### Layer 4: UI Binding Configuration
```
_ddlSousCategories.DataValueField = "idSousCategorie"
_ddlSousCategories.DataTextField = "libelleSousCategorie"
```

### Layer 5: Reflection-Based Property Extraction
```
BasicDropDownList iterates through objects and extracts:
- Value from idSousCategorie property → 11, 12, 17, ...
- Text from libelleSousCategorie property → "Plaquette", "Rapport annuel", ...
Creates ListItem collection
```

### Layer 6: Sorting ★ CHANGES ORDER ★
```
base.Sort(__listitems) sorts alphabetically by display text:

Input order:   323, 63, 297, 11, 12, 13, 14, 15, 16, 17
Output order:  17, 323, 11, 63, 14, 12, 13, 297, 16, 15

Sorted by:
- Composition d'actif (C)
- DICI (D)
- Plaquette (P)
- Prospectus (P)
- Prospectus partie B (P)
- Rapport annuel (R)
- Rapport annuel simplifié (R)
- Rapport semi-annuel (R)
- Statistiques Monaco (S)
- Statistiques Suisse (S)
```

### Layer 7: HTML Rendering
```
<option value="11">Plaquette</option>
<option value="12">Rapport annuel</option>
... (sorted alphabetically)
```

---

## Two Major Transformations

### Transformation #1: Label Translation
**WHERE**: ProxyDocument.GetListeSousCategorie() → during data retrieval
```
sc11 ─────────→ Resources.GetLabel() ─────────→ Plaquette
                     │
                     ↓ (queries Oracle)
              SOUSCATEGORIE.SC11.LABEL = Plaquette
```

**HOW**: 
1. ResourceManager constructs lookup pattern: `"SousCategorie.sc11.Label"`
2. Checks if FR culture data is cached
3. If not, ResourcesProxy queries Oracle: `GetResources(p_culture_code='FR')`
4. Returns Hashtable with all translations
5. Looks up value and returns "Plaquette"

### Transformation #2: Alphabetical Sorting
**WHERE**: BasicDropDownList.DataBind() → line 151
```
Order changes from database order → alphabetical order by display text
323, 63, 297, 11, ... → 17, 323, 11, 63, ...
```

**HOW**: 
1. After extracting all values/text pairs from objects
2. Call Sort() on the ListItem collection
3. Sort compares by Text property (display text)
4. Items reorganized alphabetically

---

## Architecture Insight

This is a **multi-layer translation architecture**:

```
STORAGE LAYER    │  TRANSLATION LAYER        │  PRESENTATION LAYER
─────────────────┼──────────────────────────┼─────────────────────
Database codes   │  Localization Service    │  Translated labels
(sc11, sc12, ...) │  (Resources layer)      │  (Plaquette, Rapport...)
Compact storage  │  Supports multi-language │  User-friendly display
─────────────────┼──────────────────────────┼─────────────────────
Efficient        │  Flexible                │  Usable
```

---

## Configuration Files & Tables

### Oracle Localization Table Structure
```
Column: marker              | culture | value
─────────────────────────────────────────────────
SOUSCATEGORIE.SC11.LABEL    | FR      | Plaquette
SOUSCATEGORIE.SC12.LABEL    | FR      | Rapport annuel
SOUSCATEGORIE.SC13.LABEL    | FR      | Rapport annuel simplifié
SOUSCATEGORIE.SC14.LABEL    | FR      | Prospectus partie B
SOUSCATEGORIE.SC15.LABEL    | FR      | Statistiques Suisse
SOUSCATEGORIE.SC16.LABEL    | FR      | Statistiques Monaco
SOUSCATEGORIE.SC17.LABEL    | FR      | Composition d'actif
```

### Code Files Involved
```
QXP.Web/Proxy/ProxyDocument.cs (line 636)
  → Calls Resources.GetLabel() for each row

QXP.Framework/Resources/ResourceManager.cs (line 618)
  → Manages localization lookup & caching

QXP.Framework/Resources/Proxy/ResourcesProxy.cs (line 82)
  → Queries Oracle for translations

QXP.WebSite/Chargement/Gabarit/CreationDocumentGabarit.cs (line 104)
  → Binds to UI control

QXP.Framework.Web/UI/Controls/Basic/DropDownList/BasicDropDownList.cs (line 119-151)
  → Renders dropdown with sorting
```

---

## Answer to Your Question

**"How is the output different for loading categorie dropdown list?"**

1. **Database returns**: Raw codes (sc11, sc12, ...) with IDs
2. **Localization layer translates**: Codes to French labels via Oracle lookup table
3. **UI binding extracts**: ID as value, translated label as display text
4. **Sorting reorders**: Items alphabetically by translated label
5. **HTML renders**: Sorted, translated items

**Result**: User sees friendly French labels sorted alphabetically, not raw database codes in query order.

---

## Key Files to Review

If you want to understand the complete flow, read in this order:

1. **ProxyDocument.cs** (line 630-645)
   - Shows GetLabel() call during data retrieval

2. **ResourceManager.cs** (line 75-140)
   - Shows public GetLabel() methods

3. **ResourcesProxy.cs** (line 82-110)
   - Shows Oracle query for translations

4. **BasicDropDownList.cs** (line 40-151)
   - Shows DataBind() with reflection and sorting

5. **CreationDocumentGabarit.cs** (line 104-106)
   - Shows UI binding configuration

---

## Conclusion

The dropdown data is modified through a sophisticated multi-layer architecture:
- **Storage layer** (database) stores compact codes
- **Translation layer** (localization service) converts to user-friendly labels
- **Presentation layer** (UI controls) displays sorted, formatted output

This design enables:
✓ Multi-language support
✓ Efficient data storage
✓ Easy maintenance
✓ User-friendly interface
✓ Separation of concerns

