using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration.Install;
using System.ComponentModel;
using System.Text;
using System.ServiceProcess;
using System.Threading;

using QXP.Batch.Core;

namespace QXP.Batch
{
    [RunInstaller(true)]
    public class ProgramInstaller : Installer
    {
        #region Constants
        const string SVCName = "QXP_Batch_Program";
		const string SVCDesc = "Utilitaire de lancement des rapports Quark";
        #endregion

         public ProgramInstaller(){
             // Instantiate installers for process and services.

             ServiceProcessInstaller processInstaller = new ServiceProcessInstaller();

             ServiceInstaller       serviceInstaller1 = new ServiceInstaller();

             // The services run under the system account.

             processInstaller.Account = ServiceAccount.LocalSystem;

             // The services are started manually.

             serviceInstaller1.StartType = ServiceStartMode.Automatic;

             // ServiceName must equal those on ServiceBase derived classes.

             serviceInstaller1.ServiceName = SVCName;
             
             serviceInstaller1.DisplayName = SVCName;

             serviceInstaller1.Description = SVCDesc;


            //definition des services dependants
            //Attention c'est normal qu'il y � une faute sur "QuarkXPressServerManger2015" il faut la laisser (Le service de quark s'appel comme �a) !!
            serviceInstaller1.ServicesDependedOn = new string[] { "QuarkXPressServer2017", "QuarkXPressServerManger2015" };

            // Add installers to collection. Order is not important.

            Installers.Add(serviceInstaller1);

             Installers.Add(processInstaller);


         }


         // Override the 'Install' method.

         public override void Install(IDictionary savedState)

         {

            base.Install(savedState);

         }

         // Override the 'Commit' method.

         public override void Commit(IDictionary savedState)

         {

            base.Commit(savedState);

         }

        //Permet de d�marrer le service une fois l'installation termin�e
		protected override void OnCommitted(System.Collections.IDictionary savedState)
		{
			base.OnCommitted(savedState);
			ServiceController sc = new ServiceController(SVCName);
			sc.Start();
		}

         // Override the 'Rollback' method.

         public override void Rollback(IDictionary savedState)

         {

            base.Rollback(savedState);

         }        
    }

    [RunInstaller(true)]    
    class QXP_Batch_Program : ServiceBase
    {
        static void Main(){
            //Petite astuce si l'argument -debug est pr�sent au lancement alors on fonction en mode application console sinonn c'est un service
            if (System.Environment.CommandLine.ToLower().Contains("-debug"))
            {
                Console.WriteLine("Thread " + Thread.CurrentThread.ManagedThreadId + " : Batch.exe : Thread principal");
                Start();                
                Console.ReadLine();
                End();
            }
            else
            {
                System.ServiceProcess.ServiceBase[] _servicesToRun;
                _servicesToRun      = new System.ServiceProcess.ServiceBase[] { new QXP_Batch_Program() };
                System.ServiceProcess.ServiceBase.Run(_servicesToRun);            
            }
        } 
        
        static void Start(){
            ThreadStart __ts    = new ThreadStart(Watcher.Start);
            Thread      __t     = new Thread(__ts);
			__t.Name	= "Watcher_Thread";
            __t.Start();
        }
        static void End(){
            Watcher.End();
        }
        
        /// <param name="args">Data passed by the start command.</param>
        protected override void OnStart(string[] args)
        {
            Start();
        }

        protected override void OnContinue()
        {
            Watcher.Paused = false;
        }

        protected override void OnPause()
        {
            Watcher.Paused = true;
        }

        protected override void OnStop()
        {
            End();
        }
    }
}
