using System;
using System.Collections.Generic;
using System.Text;
using QXPFrk = QXP.Framework;

using QXP.Engine.Core;

namespace QXP.Engine
{
    class Program
    {
        [STAThread]
        static int Main(string[] args)
        {
			//Contrainte Solid FrameWork, la licence doit etre activ�e dans les premi�res instructions
            //Un bug se produit si cette instruction est appel� apr�s l'utilisation de la dll Oracle.DataAccess.
            //A supprimer quand le nouveau build sera disponible
            //SolidFramework.LicenseCollection collection = SolidFramework.LicenseCollection.Instance;                  


            int			__id_Run = 0;
			Run_Base	__run	 = null;
            switch(args.Length)
            {
                case 1:
                    __id_Run = QXPFrk.Conversion.ToInt(args[0]);
					__run = new Run(__id_Run);
					__run.Launch();
                    break;
                case 2:
					Console.WriteLine("Invalid arguments");
                    break;
            }

            if(QXPFrk.Validation.IsNotNull(__run))
			{
				return __run.Status == Run_Status.Generated?0:1;
			}
			else
			{
				return 1;
			}
            
        }
    }
}
