using System.ServiceModel;

/* 
 * Code g�n�r� avec le template : QXPInterface
*/
namespace QXP.Batch.Interop
{
    /// <summary>
    /// Interface IEventMessageCallback : Interface permettant la transmission d'information en appel callback
    /// </summary>
    /// <author>doufarm</author>
    /// <date>26/10/2012 14:58:25</date>    
    [ServiceContract]
    public interface IEventMessageCallback
    {
        #region M�thodes
        /// <summary>
        /// Cette interface permet de retourner un message au client WCF
        /// </summary>
        /// <param name="message"></param>
        [OperationContract(IsOneWay = true)]
        void OnReceiveMessage(Message_Type message_type, string message);

        /// <summary>
        /// Cette interface permet de prevenir le client WCF que le server se deconnect
        /// </summary>
        /// <param name="message"></param>
        [OperationContract(IsOneWay = true)]
        void ServerClosed();

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
