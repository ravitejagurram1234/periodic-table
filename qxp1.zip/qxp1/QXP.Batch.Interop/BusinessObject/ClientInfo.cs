using System;
using System.Collections.Generic;
using System.Text;

using System.Runtime.Serialization;
using System.ServiceModel;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Batch.Interop
{
    /// <summary>
    /// Class ClientInfo : Fournit les informations d'un client WCF connect� � batch
    /// </summary>
    /// <author>doufarm</author>
    /// <date>26/10/2012 14:52:14</date>    
    [DataContract]
    public class ClientInfo
    {
        #region Membres
        Guid    _guid = Guid.NewGuid();
        string  _computerName = "unknown";
        string  _userName = "unknown";
        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s
        /// <summary>
        /// Identifiant unique du client
        /// </summary>
        [DataMember]
        public Guid Guid
        {
            get { return _guid; }
            set { _guid = value; }
        }

        /// <summary>
        /// Nom de l'ordinateur du client
        /// </summary>
        [DataMember]
        public string ComputerName
        {
            get { return _computerName; }
            set { _computerName = value; }
        }

        /// <summary>
        /// Nom de l'utilisateur du client
        /// </summary>
        [DataMember]
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        /// <summary>
        /// Permet d'obtenir une chaine unique contenant les infos cliente
        /// </summary>
        /// <returns></returns>
        public string GetFullInfo()
        {
            return string.Format("id:{0} name:{1} from:{2}", this.Guid, this.UserName, this.ComputerName);
        }
        #endregion Propri�t�s
    }
}
