using System.ServiceModel;

/* 
 * Code g�n�r� avec le template : QXPInterface
*/
namespace QXP.Batch.Interop
{
    /// <summary>
    /// Interface IService : Repr�sent le contract qui pourra �tre utilis� par le site web pour communiquer avec Batch
    /// </summary>
    /// <author>doufarm</author>
    /// <date>26/10/2012 14:54:29</date>    
    [ServiceContract]
    public interface IServiceCommand
    {
        #region M�thodes
        
        /// <summary>
        /// Permet de demander � batch de lancer une liste de run. Cette methode est appel�e par QXP.WebSite pour le lancement manuel des run depuis le site
        /// </summary>
        /// <param name="ids">liste des identifiants de run � lancer</param>
        /// <returns>true s'il n'y � pas eu de pb sinon false</returns>
        [OperationContract]
        bool ExecuteRuns(int[] ids);

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
