using System.ServiceModel;

/* 
 * Code g�n�r� avec le template : QXPInterface
*/
namespace QXP.Batch.Interop
{
    /// <summary>
    /// Interface IService : Repr�sent le contract qui pourra �tre utilis� entre le client WCF et le Server WCF
    /// </summary>
    /// <author>doufarm</author>
    /// <date>26/10/2012 14:54:29</date>    
    [ServiceContract(CallbackContract = typeof(IEventMessageCallback), SessionMode = SessionMode.Required)]
    public interface IService
    {
        #region M�thodes
        /// <summary>
        /// Envoi d'un message texte au serveur afin qu'il soit envoy� � tout les clients s'il y en a d'autre.
        /// </summary>
        /// <param name="message"></param>
        [OperationContract(IsOneWay = true)]
        void ReceiveMessage(string message);


        /// <summary>
        /// Informe le serveur que qu'un nouveau client c'est connect�
        /// </summary>
        [OperationContract(IsOneWay = true)]
        void Subscribe(ClientInfo clientInfo);

        /// <summary>
        /// Informe le serveur que le client � quitter la session
        /// </summary>
        [OperationContract(IsOneWay = true)]
        void UnSubscribe();

        /// <summary>
        /// Permet de r�cup�rer la liste des clients actuellement connect�s sur le server Batch
        /// </summary>
        [OperationContract]
        string[] GetListClients();

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
