using System;

namespace QXP.Batch.Interop
{
    /// <summary>
    /// Ensembles des types de message qui peuvent �tre retourn� aux clients par le serveur.
    /// </summary>
    /// <author>doufarm</author>
    /// <date>26/10/2012 15:04:08</date>    
    public enum Message_Type
    {
        Information /* Envoyer par le serveur pour les clients */
        , Message /* Envoyer par les clients pour les clients */
        , Run /* Envoyer par le serveur pour les clients */
        , Upload /* Envoyer par le serveur pour les clients */
    }
}
