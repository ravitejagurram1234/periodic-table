using System;
using System.Web;

namespace QXP.Framework.Web
{    
    /// <summary>
    /// Class Cookie : Provides a set of properties and methods used to manage cookies.
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class Cookie
    {
        #region Membres

        /// <summary>Defines the life time of the cookie. </summary>
        public static readonly double DefaultLifetimeDays = 30.0;
        private HttpCookie _cookie;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Initializes a new instance of the <see cref="Cookie"/> class with the provided <paramref name="name"/>. </summary>
        /// <param name="name">The <see cref="String"/> representing the cookie name. </param>
        public Cookie(string name)
        {
            _cookie = HttpContext.Current.Request.Cookies.Get(name);
            if (_cookie == null) _cookie = new HttpCookie(name);
            _cookie.Expires = DateTime.Now.AddDays(DefaultLifetimeDays);
        }

        /// <summary>Initializes a new instance of the <see cref="Cookie"/> class with the provided <paramref name="name"/> and <paramref name="expirationDays"/>. </summary>
        /// <param name="name">The <see cref="String"/> representing the name of the cookie. </param>
        /// <param name="expirationDays">The expiration date and time for the cookie. </param>
        public Cookie(string name, double expirationDays)
            : this(name)
        {
            _cookie.Expires = DateTime.Now.AddDays(expirationDays);
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>Adds the current object to the cookie collection. </summary>
        public void Save()
        {
            HttpContext.Current.Response.Cookies.Add(_cookie);
        }
        /// <summary>Remove the current object to the cookie collection. </summary>
        public void Clear()
        {
            _cookie.Values.Clear();
            this.Save();
        }
        
        /// <summary>Removes the cookie with the specified <paramref name="name"/>. </summary>
        /// <param name="name">The <see cref="String"/> representing the name of the cookie. </param>
        public void Remove(string name)
        {
            _cookie.Values.Remove(name);
        }
        
        /// <summary>Removes a cookie with the specified <paramref name="index"/>. </summary>
        /// <param name="index">The <see cref="int"/> representing a cookie index in a cookie collection. </param>
        public void Remove(int index)
        {
            this.Remove(_cookie.Values.GetKey(index));
        }
        
        #endregion M�thodes

        #region Propri�t�s

        /// <summary>Gets or sets the expiration date and time for the cookie. </summary>
        public DateTime Expires
        {
            get { return _cookie.Expires; }
            set { _cookie.Expires = value; }
        }

        /// <summary>Gets or sets value of the specified <paramref name="name"/> cookie element. </summary>
        /// <param name="name">The <see cref="String"/> representing the name of the element in the cookie. </param>
        public string this[string name]
        {
            get
            {
                if (Validation.IsSet(_cookie.Values[name]))
                    return (_cookie.Values[name]);
                else
                    return string.Empty;
            }
            set { _cookie.Values[name] = value; }
        }

        /// <summary>Gets the value at specified <paramref name="index"/> position. </summary>
        /// <param name="index">The <see cref="int"/> representing the index position of the element in the cookie. </param>
        public string this[int index]
        {
            get
            {
                if (Validation.IsSet(_cookie.Values[index]))
                    return (_cookie.Values[index]);
                else
                    return string.Empty;
            }
        }

        #endregion Propri�t�s
    }
}
