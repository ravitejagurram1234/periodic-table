using System.Web;

namespace QXP.Framework.Web
{
    /// <summary>
    /// Class HttpUtilities : 
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class HttpUtilities
    {
        #region Membres

        static string _absoluteRootSite = null;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de HttpUtilities
        /// </summary>
        public HttpUtilities()
        {
        }

        #endregion Constructeur

        #region M�thodes

        public static string GetAbsolutePath(string url)
        {
            if (Validation.IsSet(url))
            {
                string __url = url;
                int __startPos = 0;
                int __length = __url.Length;
                if (__url.StartsWith("/"))
                {
                    __startPos = 1;
                    __length = __length - 1;
                }
                else if (__url.StartsWith("~/"))
                {
                    __startPos = 2;
                    __length = __length - 2;
                }
                __url = __url.Substring(__startPos, __length);
                return string.Concat(AbsoluteRootSite, __url);
            }
            else
            {
                return AbsoluteRootSite;
            }
        }

        #endregion M�thodes

        #region Propri�t�s

        public static string AbsoluteRootSite
        {
            get
            {
                try
                {
                    HttpContext __context = HttpContext.Current;
                    HttpRequest __request = __context.Request;

                    if (__request.ApplicationPath.Equals("/"))
                        return __request.ApplicationPath;
                    else
                        return string.Concat(__request.ApplicationPath, "/");
                }
                catch
                {
                    //INFO: set absolute path to empty if not in httpcontext request!
                    _absoluteRootSite = string.Empty;
                }
                return _absoluteRootSite;
            }
        }

        #endregion Propri�t�s
    }


}
