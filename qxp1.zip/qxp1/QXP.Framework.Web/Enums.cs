using System;

/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/
namespace QXP.Framework.Web
{
    //INFO: not used !! use instead noscript html tag
    public enum ScriptCapability
    {
        Unknown,
        Enabled,
        Disabled,
    }

    /// <summary>
    /// Ensembles des �num�rations communes au module
    /// </summary>
    /// <author>touxb</author>
    /// <date>28/03/2011 15:37:38</date>    
    public class Enums
    {
        /// <summary>
        /// Ressources groupes
        /// </summary>
        public enum RG
        {
            ERROR_OBJECT_IN_SESSION_EXPIRED
        }
    }
}
