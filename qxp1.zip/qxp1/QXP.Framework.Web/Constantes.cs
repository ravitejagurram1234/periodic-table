using System;

/* 
 * Code g�n�r� avec le template web : QXPWebConstantesClass
*/
namespace QXP.Framework.Web
{
    /// <summary>
    /// Ensembles des Constantes communes au module
    /// </summary>
    /// <author>cueffl</author>
    /// <date>25/02/2011 13:59:16</date>    
    public class Constantes
    {
        #region CSS

        #endregion CSS

        public const string DefaultPage = "Default.aspx";
		public const string NoSessionPage = "NoSession.htm";
    }

    /// <summary>Provides Message/Pattern used by QXP web framework. </summary>
    public class WebConstant
    {
        /// <summary>Represents the invalid listitem object type message. </summary>
        public const string InvalidObjectTypeListItemAB = "Invalid object type 'listItema' and 'listItemb' must be inherited from 'System.Web.UI.WebControls.ListItem'";
        /// <summary>Represents an invalid repeat value parameter message. </summary>
        public const string InvalidRepeatValue = "Invalid repeat parameter value.";
        /// <summary>Represents an invalid repeat value parameter message. </summary>
        public const string InvalidColArgument = "Invalid col argument.";
        /// <summary>Represents an invalid control reference message. </summary>
        public const string InvalidControlReference = "Invalid Control Reference.";
        /// <summary>Represents an invalid composite feature type message. </summary>
        public const string InvalidFeatureType = "Invalid 'featureType' must be d�rived from 'System.Web.UI.WebControls.WebControl'";
        /// <summary>Represents the invalid row argument message. </summary>
        public const string InvalidRowArgument = "Invalid row argument";
        /// <summary>Represents the invalid column or row argument message. </summary>
        public const string InvalidRowOrColArgument = "Invalid row or col argument";
        /// <summary>Represents the invalid validator addition message. </summary>
        public const string ForbiddenValidatorAddition = "is it forbidden to add validation control on this control";
        /// <summary>Specifies a bad template type error message. </summary>
        public const string BadTemplateType = "Bad template type: must inherit from System.Web.UI.Control";

        public const string ImgPlaceHolder = "Images/cmd.gif";

        public const string StandardScriptFilePattern = "<script language=\"javascript\" src=\"{0}\"></script>";

        private WebConstant() { }
    }

    /// <summary>
    /// Contient les fichiers js utilis�s par le framework
    /// </summary>
    public class ScriptRessource 
    {
        public const string CoreScriptRes = "Core.js";
        public const string AjaxNetScriptRes = "AjaxNet.js";
        public const string AnthemScriptRes = "Anthem.js";

        public const string JQueryJSScript = "scripts/jquery.js";
        public const string JQueryMinJSScript = "scripts/jquery_min.js";
        public const string SystemJSScript = "scripts/system.js";
    }
}
