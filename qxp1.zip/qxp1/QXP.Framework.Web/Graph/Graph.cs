using System.Xml.Serialization;

namespace QXP.Framework.Web.Graph
{
    /// <summary>
    /// D�finit un graphique "g�n�rique" QXP
    /// </summary>
    public class Graph : QXP.Framework.Graph.Graph
    {
        #region Membres


        private string _source;

        #endregion

        #region Constantes

        private const string URLHandler = "Graph_Image.aspx";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Graph
        /// </summary>
        public Graph()
            : base()
        {
            this._source = string.Format("{0}?{1}={2}", URLHandler, GraphHandler.GraphIDKey, this.ID);
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Properties

        /// <summary>
        /// Source du graphique (chargement via les handlers)
        /// </summary>
        [XmlAttribute]
        public string Source
        {
            get { return this._source; }
            set { this._source = value; }
        }

        #endregion
    }
}
