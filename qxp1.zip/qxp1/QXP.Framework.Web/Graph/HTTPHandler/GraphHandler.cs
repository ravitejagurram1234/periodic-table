using System;
using System.Drawing;
using System.IO;
using System.Web;
using System.Web.SessionState;
using QXPFrkWebUser = QXP.Framework.Web.User;

namespace QXP.Framework.Web.Graph
{
    /// <summary>
    /// Class GraphHandler : Provides base methods to process Report Handler <see cref="HttpRequest"/>. 
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class GraphHandler : IHttpHandler, IReadOnlySessionState
    {
        #region Membres

        #endregion Membres

        #region Constantes

        public const string GraphIDKey = "GraphID";

        //Last generated GraphId key
        private const string LastGraphId = "LastGraphId";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de GraphHandler
        /// </summary>
        public GraphHandler() { }

        #endregion Constructeur

        #region M�thodes

        /// <summary>Process an <see cref="HttpRequest"/> from the specified <see cref="HttpContext"/> (<paramref name="context"/>). </summary>
        /// <param name="context">The <see cref="HttpContext"/> used the retrieve <see cref="HttpRequest"/> send by a web client. </param>
        public void ProcessRequest(HttpContext context)
        {
            HttpRequest __httpRequest = context.Request;
            string __graphID = context.Request[GraphIDKey];
            System.Diagnostics.Debug.WriteLine("Processe Request");
            //this code was writen for performance test issues !! 2006/02/24
            if (Validation.IsNotSet(__graphID))
            {
                string __lastGraphId = QXPFrkWebUser.User.Current.GetObject(LastGraphId) as string;
                if (Validation.IsNotSet(__lastGraphId))
                {
                    context.Response.End();
                    return;
                }
                else
                {
                    __graphID = __lastGraphId;
                }
            }
            Bitmap __outputImage = null;

            __outputImage = QXPFrkWebUser.User.Current.GetObject(Object_Category.Graph_Image, __graphID) as Bitmap;

            //INFO: one shoot use of reportoutput
            QXPFrkWebUser.User.Current.RemoveObject(Object_Category.Graph_Image, __graphID);
            System.Diagnostics.Debug.WriteLine(string.Format("Remove GraphImage with ID:{0}", __graphID));

            if (Validation.IsNotNull(__outputImage))
            {
                try
                {
                    MemoryStream __memoryStream = QXP.Framework.Graph.GraphHelper.GetStream(__outputImage);
                    context.Response.ClearHeaders();
                    context.Response.ClearContent();
                    context.Response.Clear();
                    //INFO: cette ligne permet de corriger un bug de IE qui effectue 2 Gets sur la m�me page dans le cas d'un contenu.
                    //INFO: grace � l'expiration fixer � 1 (UNE) minute le client ne rappel plus ReportHandler.
                    context.Response.Cache.SetMaxAge(TimeSpan.FromMinutes(1));
                    context.Response.Expires = 1;
                    context.Response.ContentType = "Image/png";
                    __memoryStream.WriteTo(context.Response.OutputStream);
                    __memoryStream.Close();
                    context.Response.End();
                }
                catch (System.Threading.ThreadAbortException)
                {
                }
                catch (Exception ex)
                {
                    string __error = ex.ToString();
                }
            }
            else
            {
                //TODO : display eror message.
            }

        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>Gets an <see cref="IHttpHandler"/> object for the current <see cref="HttpRequest"/>. </summary>
        protected virtual IHttpHandler Handler
        {
            get { return null; }
        }

        /// <summary>Gets a value indicating whether another request can use the <see cref="IHttpHandler"/> instance. </summary>
        public bool IsReusable
        {
            get { return true; }
        }

        #endregion Propri�t�s
    }
}
