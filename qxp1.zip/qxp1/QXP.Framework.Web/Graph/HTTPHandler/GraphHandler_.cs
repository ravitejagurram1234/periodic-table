namespace QXP.Framework.Web.Graph
{
    public enum Object_Category
    {
        Graph_Image,
    }
}
