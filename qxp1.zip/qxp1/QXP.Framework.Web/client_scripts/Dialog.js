﻿/* Permet de corriger un bug d'affichage entre le grid et le dialog */
function AfterShowDialog(dialog) 
{
    if (dialog.OffsetX != 0)
    {
        dialog.OffsetX = 0;
        dialog.Render();
    }
}

/* Permet d'afficher ou de masquer une boite de dialog en fonction de sa visibilité */
function ToggleDialog(dialog)
{
    if (dialog.get_isShowing()) 
    {
        dialog.Close();
    }
    else 
    {
        dialog.Show();
    }
}