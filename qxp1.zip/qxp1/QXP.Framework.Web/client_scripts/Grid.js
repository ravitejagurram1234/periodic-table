﻿/* Permet de desactiver la selection par click sur un grid */
function Grid_DisableItemSelection(sender, eventArgs) {
    eventArgs._cancel = true;
}