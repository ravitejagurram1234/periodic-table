var strSeparatorArray	= new Array("-"," ","/",".");
var strFormatFrench1	= "dd/MM/yyyy";
var strFormatFrench2	= "d/M/yyyy";
var strFormatEnglish1	= "MM/dd/yyyy";
var strFormatEnglish2	= "M/d/yyyy";

function GetDateObj(source, format){
	var __value			= source.value;
	var __parts			= GetArrayDate(__value);
	var __partsLength	= __parts.length;
	var __date			= null;
	
	//alert('nb parts = ' + __partsLength);
	if(__partsLength == 0)	__date = '';
	if(__partsLength == 1)	__date = GetDateFromOne(__parts[0], format);
	if(__partsLength == 2)	__date = GetDateFromTwo(__parts[0], __parts[1], format);
	if(__partsLength == 3)	__date = GetDateFromThree(__parts[0], __parts[1], __parts[2], format);
    return __date    
}
// Complete la date saisie par l'utilisateur
function CompleteDate(source, format)
{	

	var __date			= GetDateObj(source, format);
	var __borderColor	= '';
	
	if(__date == null || isNaN(__date))
	{
		__borderColor = 'Red';
	}
	else
	{
		FillDate(source, __date, format);
	}
	if(source != null) source.style.borderColor = __borderColor;
} // CompleteDate

//Retrouve la collection de valeurs saisies par l'utilisateur � l'aide des s�parateurs autoris�s
function GetArrayDate(value, format){
	var __parts = new Array;
	var __match	= false;
	if(value == null || value.length == 0)	return __parts;
	for (__intElementNr = 0; __intElementNr < strSeparatorArray.length; __intElementNr++) {
		if (value.indexOf(strSeparatorArray[__intElementNr]) != -1) {
			__parts = value.split(strSeparatorArray[__intElementNr]);
			__match = true;
			break;
		}
	}
	if(__match == false) __parts[0] = value;
	return __parts
}
//Evalue la date � partir d'un seul param�tre en tenant compte du format
function GetDateFromOne(val, format){
	if(val.length == 0)					return null;
	if(val.length > 0 && val.length <3)	return GetDate(val, null, null, 1, format);
	if(val.length == 4)					return GetDate(val.substring(0,2), val.substring(2,4), null, 2,  format);
	if(val.length == 6)					return GetDate(val.substring(0,2), val.substring(2,4), "20" + val.substring(4,6), 3,  format);
	if(val.length == 8)					return GetDate(val.substring(0,2), val.substring(2,4), val.substring(4,8), 3, format);
	return null;
}
//Evalue la date � partir de 2 param�tres en tenant compte du format
function GetDateFromTwo(val1, val2, format){
	return GetDate(val1, val2, null, 2, format);
}
//Evalue la date � partir de 3 param�tres en tenant compte du format
function GetDateFromThree(val1, val2, val3, format){
	return GetDate(val1, val2, val3, 3, format);
}
//Evalue la date en tenant compte du format
function GetDate(part1, part2, part3, partCount, format){
	var __date = new Date();
	var __day	= -1;
	var __month = -1;
	var __year	= -1;
	try{
		if(format == strFormatFrench1 || format == strFormatFrench2)
		{
		    if (partCount >= 1) {
		        //test sp�cial si 0 est saisi alors la date reste la date du jour !!
				if(part1 != null && part1.length > 0)
				{

				    var __num = GetNumeric(part1);
				    //On v�rifie que le jour saisi est inf�rieur � 31
				    if (__num > 31) return null;
					else if(__num != 0)	__day = __num;
				}
			}
			if (partCount >= 2) {
			    if (part2 != null && part2.length > 0) {
			        __month = GetNumeric(part2);
			        //On v�rifie que le mois saisi est inf�rieur � 12
			        if (__month > 12) return null;
			        else __month = __month - 1; //-1 par que moi est base 0 :(( 0 = janv, 1 = fevr etc..
			    }
			}
			if(partCount == 3){
			    if (part3 != null & part3.length > 0) {
					var __num = GetNumeric(part3);
					switch(part3.length)
					{
						case 1:
						case 2:
							__num = 2000 + __num;
							break;
						case 4:
						default:
							break;	
					}
					__year = __num;
				}
			}
		}
		else if(format == strFormatEnglish1 || format == strFormatEnglish2)
		{
			if(partCount == 1){
				if(part1 != null && part1.length > 0)
				{
					//teste speciale si 0 est saisie alors la date reste la date du jour !!
					var __num = GetNumeric(part1);
					if(__num != 0)	__day = __num;
				}
			}
			//Inversion date et mois pour format anglais
			if(partCount >= 2){
				if(part1 != null && part1.length > 0) __month	= part1 - 1;  //-1 par que moi est base 0 :(( 0 = janv, 1 = fevr etc..
				if(part2 != null && part2.length > 0) __day		= part2;
				if(part3 != null && part3.length > 0) __year	= part3;
			}
			if(partCount == 3){
				if(part3 != null){
					var __num = GetNumeric(part3);
					switch(part3.length)
					{
						case 1:
						case 2:
							__num = 2000 + __num;
							break;
						case 4:
						default:
							break;	
					}
					__year = __num;
				}
			}			
		}
		//met la date au premier pour prevenir erreur genre 31/01/2005 si on ajoute 1 mois devient 31/02/2005 comme le mois de fevrier ne possede que 28-29 la date devient 02-03/03/2005 !!
		if(__day != -1)		__date.setDate(1);
		if(__year != -1)	__date.setFullYear(__year);
		if(__month != -1)	__date.setMonth(__month);
		if(__day != -1)		__date.setDate(__day);
	}
	catch(e)
	{
		return null;
	}
	return __date;
}
//Evalue la valeur numerique d'un texte
function GetNumeric(val){
	//var		__n = parseInt(val);
	var		__n = Number(val);
	return	__n;
}
//Remplit le controle avec la nouvelle date evalu�e
function FillDate(source, date, format){
	if(source == null || date == null || isNaN(date) || date.length == 0){
	 return;
	}
	var		__strDate	= "";
	var		__day		= date.getDate(); 
	var		__month		= date.getMonth() + 1;  //+1 par que moi est base 0 :(( 0 = janv, 1 = fevr etc..
	var		__year		= date.getFullYear(); 
	var		__strDay	= ((parseInt(__day) < 10 )? "0" : "" ) + __day;
	var		__strMonth	= ((parseInt(__month) < 10 )? "0" : "" ) + __month;
	var		__strYear	= __year;
	
	if(format == strFormatFrench1 || format == strFormatFrench2)
	{
		__strDate = __strDay + "/" + __strMonth + "/" + __strYear; 
	}
	else if(format == strFormatEnglish1 || format == strFormatEnglish2)
	{
		__strDate = __strMonth + "/" + __strDay + "/" + __strYear; 
	}
	
	source.value = __strDate;
}

/* ARTUI Calendar extra function */
function OpenDefaultCalendar(id_tbx, dateFormat, autoCallBack){
    var __tbx           = document.getElementById(id_tbx);
    var __date          = GetDateObj(__tbx, dateFormat);
    var __offSetValue   = 0;
    var __inputObj      = __tbx;

    //Date invalid
    if(__date == null || isNaN(__date)){
        return;
    }
    
    //La date de r�f�rence est la date du jour
    calendar.SetVisibleDate(new Date());
    //Date vide ont prend aujourd'ui
    if (__date != '') {
        calendar.SetSelectedDate(__date);
    }
    else {
        calendar.ClearSelectedDate();
    }
    
    //prise en compte du decalage du au fait que le controle puisse etre present dans un contole avec scollbar actif
    while (__inputObj.offsetParent) {
        if (__inputObj.scrollTop != undefined) {
            __offSetValue += __inputObj.scrollTop;
        };
        __inputObj = __inputObj.offsetParent;
    };

    //Permet de compenser le d�calage par offset
    calendar.PopUpExpandOffsetY         = -__offSetValue;
    calendar.PopUpObject.ExpandOffsetY  = calendar.PopUpExpandOffsetY;
    calendar.PopUpExpandControlId       = id_tbx;
    
    calendar.Caller                     = __tbx;
    calendar.DateFormat                 = dateFormat;
    calendar.AutoCallBack               = autoCallBack; 
    calendar.Show(__tbx);
}

function Calendar_onSelectionChanged(sender, eventArgs) {
    FillDate(sender.Caller, sender.getSelectedDate(), sender.DateFormat);
    if (sender.AutoCallBack) calendar.Caller.onchange();
}