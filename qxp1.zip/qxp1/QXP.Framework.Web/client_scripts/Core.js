var QXP = {
    Browser: {
        isIE: (navigator.userAgent.toLowerCase().indexOf("msie") != -1) ? true : false
    }
    ,
    UI: {
        addCssClass: function(element, cssClass) {
            if (element) {
                if (element.className.indexOf(cssClass) == -1) {
                    element.className = element.className + ' ' + cssClass;
                }
            }
        }
        ,
        removeCssClass: function(element, cssClass) {
            if (element) {
                if (element.className.indexOf(cssClass) != -1) {
                    element.className = element.className.replace(cssClass, '');
                }
            }
        }
        ,
        getMouse: function(evt) {
            var left, top;
            if (evt.pageX) {
                left = evt.pageX;
                top = evt.pageY;
            }
            else if (evt.clientX) {
                left = evt.clientX + (document.documentElement.scrollLeft ?
               document.documentElement.scrollLeft :
               document.body.scrollLeft);
                top = evt.clientY + (document.documentElement.scrollTop ?
               document.documentElement.scrollTop :
               document.body.scrollTop);
            }
            else {
                return null;
            }
            return { x: left, y: top };
        }
          ,
        getParentPosition: function(e) {
            var left = 0;
            var top = 0;

            while (e.offsetParent) {
                left += e.offsetLeft;
                top += e.offsetTop;
                e = e.offsetParent;
            }

            left += e.offsetLeft;
            top += e.offsetTop;

            return { x: left, y: top };
        }
    }
}
String.prototype.trim = function(){return (this.replace(/^[\s\xA0]+/, "").replace(/[\s\xA0]+$/, ""))}
String.prototype.startsWith = function(str) {return (this.match("^"+str)==str)}
String.prototype.endsWith = function(str) {return (this.match(str+"$")==str)}