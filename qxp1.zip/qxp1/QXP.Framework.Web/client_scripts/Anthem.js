﻿function Anthem_Error(result) {
    alert(result.error);
}