function ToolTip(id_window, id_body)
{
    this.id_window      = id_window;
    this.id_body        = id_body;
    this.CTRL           = document.getElementById(id_window);
    this.CTRL_Body      = document.getElementById(id_body);
    this.isShowing      = false;
    this.XYoffSetParent = QXP.UI.getParentPosition(this.CTRL);
    this.TimerID        = 0;

}

ToolTip.prototype.Disable_Timer = function() 
{
    //s'il y � d�j� un autre timer il faut l'arreter
    if (this.TimerID != 0) {
        window.clearTimeout(this.TimerID);
        this.TimerID = 0;
    }
}

ToolTip.prototype.Show = function(innerHTML) 
{
    //s'il y � d�j� un autre timer il faut l'arreter
    this.Disable_Timer();
    var mouse = QXP.UI.getMouse(event);

    this.CTRL_Body.innerHTML    = innerHTML;
    this.CTRL.style.left        = mouse.x - this.XYoffSetParent.x + 10;
    this.CTRL.style.top         = mouse.y - this.XYoffSetParent.y;
    this.CTRL.style.display     = 'block';
    
    this.isShowing              = true;

}

ToolTip.prototype.Hide = function(delay) {
    //debugger;
    
    var __delay = Number(delay);
    
    //s'il y � d�j� un autre timer il faut l'arreter
    this.Disable_Timer();
    
    if (__delay == 0) {
        this.Hide_Internal();
    }
    else
    {
        var __self = this;

        this.TimerID = window.setTimeout(
                    function() { __self.Hide_Delay(); }
                    , __delay);
    }
}

ToolTip.prototype.Hide_Delay = function() {
    if (this.TimerID != 0) 
    {
        this.TimerID == 0;
        this.Hide_Internal();
    }
}

ToolTip.prototype.Hide_Internal = function() {
    this.CTRL.style.display = 'none';
    this.isShowing          = false;
}