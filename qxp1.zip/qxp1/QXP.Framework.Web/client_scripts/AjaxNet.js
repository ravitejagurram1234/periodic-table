﻿/*Script ajouté automatiquement par le Frk pour initialiser les fonctions et variables disponibles en AJAX .NET*/
function InitializeAjaxNet()
{
    var prm = Sys.WebForms.PageRequestManager.getInstance();

    function CancelAsyncPostBack() 
    {
        if (prm.get_isInAsyncPostBack()) 
        {
            prm.abortPostBack();
        }
    }

    prm.add_initializeRequest(InitializeRequest);

    prm.add_endRequest(EndRequest);

    var postBackElement;

    function InitializeRequest(sender, args) {
        if (prm.get_isInAsyncPostBack()) 
        {
            args.set_cancel(true);
        }
        postBackElement = args.get_postBackElement();
        if (postBackElement)
            //Peut etre null si le contrôle n'est pas présent dans le dom html (ex : ctrl timer)
            postBackElement.disabled = true;
        if(typeof DefaultPreCallBack == 'function') 
        {
            DefaultPreCallBack();
        }
    }

    function EndRequest(sender, args) {

        if (args.get_error() != undefined) {
            var errorMessage;
            if (args.get_response().get_statusCode() == '200') {
                errorMessage = args.get_error().message;
            }
            else {
                // Error occurred somewhere other than the server page.
                errorMessage = 'Sorry, unhandled error occured !!';
            }

            args.set_errorHandled(true);            
            var htmlEl = document.getElementsByTagName("html")[0];
            htmlEl.removeChild(document.getElementsByTagName("head")[0])
            var el = document.createElement("head");
            htmlEl.appendChild(el);
            document.body.innerHTML = errorMessage.replace(/Sys\.WebForms\..+\:\s/, "");
            
        }
        else {
            if (typeof DefaultPostCallBack == 'function') {
                DefaultPostCallBack();
            }
            if (postBackElement)
                //Peut etre null si le contrôle n'est pas présent dans le dom html (ex : ctrl timer)
                postBackElement.disabled = false;
        }
    }
}