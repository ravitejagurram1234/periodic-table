﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("QXP.Framework.Web")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("QXP.Framework.Web")]
[assembly: AssemblyCopyright("Copyright ©  2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c40f4ea4-2c80-4d67-aa56-5bb1dbcae6a1")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]


#if !DEBUG
[assembly: WebResource("QXP.Framework.Web.client_scripts.Core.js", "text/javascript")]
[assembly: WebResource("QXP.Framework.Web.client_scripts.Date.js", "text/javascript")]
[assembly: WebResource("QXP.Framework.Web.client_scripts.ToolTip.js", "text/javascript")]
[assembly: WebResource("QXP.Framework.Web.client_scripts.AjaxNet.js", "text/javascript")]
[assembly: WebResource("QXP.Framework.Web.client_scripts.Anthem.js", "text/javascript")]
[assembly: WebResource("QXP.Framework.Web.client_scripts.Dialog.js", "text/javascript")]
[assembly: WebResource("QXP.Framework.Web.client_scripts.Grid.js", "text/javascript")]
#endif