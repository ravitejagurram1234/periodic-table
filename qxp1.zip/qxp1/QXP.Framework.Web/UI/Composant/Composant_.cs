namespace QXP.Framework.Web.UI.Component
{
    public enum CssClassComposant
    {
        composant,
        defaultcomposant,
        lookupcomposant,
    }
    public enum CssClassControles
    {
        LigneBoutons,
        HeaderGroup,
        HeaderGroupCell,
        ContentGroup,
        Bouton,
    }

    public enum ResourceGroupe
    {
        Title,
        ValidationHeader,
    }

    public enum ActionType
    {
        Creation,
        Modification,
        Suppression,
        Creation_Modification,
        CustomAction,
        UnDefined

    }
}
