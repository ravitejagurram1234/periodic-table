using System;
using System.Web.UI;

using QXPFrk					= QXP.Framework;
using QXPApplication			= QXP.Framework.Application;
using QXPWUIControls			= QXP.Framework.Web.UI.Controls;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUI					= QXP.Framework.Web.UI;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;
using QXPFrkWebUser				= QXP.Framework.Web.User;
using QXPResources				= QXP.Framework.Resources;

namespace QXP.Framework.Web.UI.Component
{
	public class			LookupHelpComposant : LookupComponent
	{
		#region internal variables
		QXPWUIBasic.Label		_message;
		bool					_customHelpMessage	= false;
		private const string	Css_Title			= "help_title";
		private const string	Css_Message			= "help_message";
		public  string			URLHelpSectionKey	= "Help_Section";
		#endregion
		internal enum CRG
		{
			Aucune_Aide,
			Help_Title,
			Help_Message
		}
		public LookupHelpComposant()
		{
			this.CssClass		= "LookupHelpComposant";
			this.ComponentInit	+= new QXPFrk.BasicHandler(this.CreateConstituantControls);
			this.ShowTitle		= false;
		}
		protected	virtual void	CreateConstituantControls()
		{
			if(_customHelpMessage) return;
			_message			= new QXPWUIBasic.Label();
			_message.CssClass	= Css_Message;
			this.Body.Add(_message);
			if(QXPFrk.Validation.IsNotSet(this.Help_Section))
			{
				this.ShowTitle	= true;
				this.Title		= QXPApplication.Application.Resources.GetLabel(this.Help_Section, CRG.Aucune_Aide);
			}
			else
			{
				if(QXPApplication.Application.Resources.ExistLabel(this.Help_Section, CRG.Help_Title))
				{
					this.ShowTitle	= true;
					this.Title		= QXPApplication.Application.Resources.GetLabel(this.Help_Section, CRG.Help_Title);
				}
				if(QXPApplication.Application.Resources.ExistLabel(this.Help_Section, CRG.Help_Message))
				{
					_message.Text = QXPApplication.Application.Resources.GetLabel(this.Help_Section, CRG.Help_Message);
				}
			}
		}
		private				bool	CustomHelpMessage{
			get{return _customHelpMessage;}
			set{_customHelpMessage = value;}
		}
		private				string	Help_Section
		{
			get{return QXPFrk.Conversion.ToString(this.Page.Request[URLHelpSectionKey]);}
		}
	}
    //ATTENTION CETTE CLASSE DEVRA ETRE DEPLACER DANS UN FICHIER A PART !!!!!
    public class			LookupInputComposant : LookupComponent
	{
		#region internal variables
        QXPWUIBasic.TextBox		_input;
        QXPWUIBasic.Button	    _ok;

		private const string	Css_Text			= "input_text";
		public  string			URLHelpSectionKey	= "Input_Section";
		#endregion
		internal enum CRG
		{
			Input_Text,
		}
		public LookupInputComposant()
		{
			this.CssClass		= "LookupInputComposant";
			this.ComponentInit	+= new QXPFrk.BasicHandler(this.CreateConstituantControls);
		}
		protected	virtual void	CreateConstituantControls()
		{
			bool __maxSizeDefined = QXPFrk.Validation.IsSet(this.MaxInputLength);
            _input  			= new QXPWUIBasic.TextBox();
			_input.CssClass	    = Css_Text;
            if(__maxSizeDefined) _input.MaxLength    = this.MaxInputLength;
			this.Body.Add(_input);

            _ok			        = new QXPWUIBasic.Button();
            //A CHANGER ! EN DURE POUR L'instant
			_ok.Text		    = "OK"; //QXPApplication.Application.Resources.GetLabel(this.RS, ResourceGroupe.Rechercher);
			_ok.Click           += this.GetEventHandler(new EventHandler(OnOkClick));
            _ok.CssClass        = BoutonCssClass;

            this.AddToZoneButton(_ok);
            string __title      = this.Request["Prompt_Text"];
            string __def_Input  = this.Request["Def_Input"];
            if(QXPFrk.Validation.IsSet(__title)){
            {
                this.Title      = __title;
            }
            if(QXPFrk.Validation.IsSet(__def_Input))
            {
                if(__maxSizeDefined) __def_Input = QXPFrk.StringHelper.StartString(__def_Input, this.MaxInputLength);
                _input.Text = __def_Input;
            }
            //    this.ShowTitle	= true;
            //this.Title		= QXPApplication.Application.Resources.GetLabel(this.Help_Section, CRG.Aucune_Aide);
            //}
            //else
            //{
            //    if(QXPApplication.Application.Resources.ExistLabel(this.Help_Section, CRG.Help_Title))
            //    {
            //        this.ShowTitle	= true;
            //        this.Title		= QXPApplication.Application.Resources.GetLabel(this.Help_Section, CRG.Help_Title);
            //    }
            //    if(QXPApplication.Application.Resources.ExistLabel(this.Help_Section, CRG.Help_Message))
            //    {
            //        _message.Text = QXPApplication.Application.Resources.GetLabel(this.Help_Section, CRG.Help_Message);
            //    }
            //}
            }
		}
        private     void            OnOkClick(object sender, EventArgs ea)
        {
            

            this.ReturnAndCloseLookup(_input.Text);
            //string __postScript     = (QXPFrk.Validation.IsSet(this.Request["postid"])) ? string.Format("window.opener.window.__doPostBack('{0}', '');", this.Request["postid"]) : "";
            //string __closeScript    = string.Concat("try{", string.Format("window.opener.document.forms['{0}'].elements['{1}'].value = \"{2}\";{3}window.close();", this.Page.Request["FormName"], this.Page.Request["CtrlName"], _input.Text, __postScript), "}catch(e){}");
            //__closeScript = string.Format("<script language=\"javascript\">{0}</script>", __closeScript);
            //this.Page.RegisterStartupScript("CloseScript", __closeScript);
        }
        /// <summary>
        /// Permet de d�finir le nombre maximum de carcat�res autoris� dans la zone de saisie. (par d�fault int.MinValue c'est � dire pas de limite !!).
        /// </summary>
        protected   virtual int     MaxInputLength{
            get{return int.MinValue;}
        }
        //private				bool	CustomHelpMessage{
        //    get{return _customHelpMessage;}
        //    set{_customHelpMessage = value;}
        //}
        //private				string	Help_Section
        //{
        //    get{return QXPFrk.Conversion.ToString(this.Page.Request[URLHelpSectionKey]);}
        //}
	}

}
