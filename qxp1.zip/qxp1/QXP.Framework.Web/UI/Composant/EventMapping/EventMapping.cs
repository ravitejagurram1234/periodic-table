using System;
using System.Collections;
using System.Threading;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXPApplication = QXP.Framework.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPFrkWebUser = QXP.Framework.Web.User;
using QXPResources = QXP.Framework.Resources;
using QXPWUI = QXP.Framework.Web.UI;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIControls = QXP.Framework.Web.UI.Controls;
using QXPWUIValidator = QXP.Framework.Web.UI.Controls.Validator;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Web.UI.Component
{

    public delegate void EventDelegate(EventMapping eventHandlerMapping);

    /// <summary>
    /// Objet EventMapping
    /// </summary>
    /// <author>cueffl</author>
    /// <date>06/12/2010 14:41:15</date>    
    public class EventMapping
    {
        #region Membres

        EventDelegate _mappedEventHandler;
        BasicHandler _originalBasicHandler;
        BasicHandler _destinationBasicHandler;
        EventHandler _originalEventHandler;
        EventHandler _destinationEventHandler;
        DataListCommandEventHandler _originalDataListEventHandler;
        DataListCommandEventHandler _destinationDataListEventHandler;
        ServerValidateEventHandler _originalServerValidateHandler;
        ServerValidateEventHandler _destinationServerValidateHandler;
        CommandEventHandler _originalCommandEventHandler;
        CommandEventHandler _destinationCommandEventHandler;
        object _sender;
        EventArgs _ea;
        DataListCommandEventArgs _dlcea;
        ServerValidateEventArgs _svea;
        CommandEventArgs _cea;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        public EventMapping(BasicHandler original, EventDelegate mappedDelegate)
        {
            _originalBasicHandler = original;
            _mappedEventHandler = mappedDelegate;
            _destinationBasicHandler += new BasicHandler(this.OnBasicEvent);
        }

        public EventMapping(EventHandler original, EventDelegate mappedDelegate)
        {
            _originalEventHandler = original;
            _mappedEventHandler = mappedDelegate;
            _destinationEventHandler += new EventHandler(this.OnEvent);
        }

        public EventMapping(DataListCommandEventHandler original, EventDelegate mappedDelegate)
        {
            _originalDataListEventHandler = original;
            _mappedEventHandler = mappedDelegate;
            _destinationDataListEventHandler += new DataListCommandEventHandler(this.OnDateListEvent);
        }

        public EventMapping(ServerValidateEventHandler original, EventDelegate mappedDelegate)
        {
            _originalServerValidateHandler = original;
            _mappedEventHandler = mappedDelegate;
            _destinationServerValidateHandler += new ServerValidateEventHandler(this.OnServerValidateEvent);
        }

        public EventMapping(CommandEventHandler original, EventDelegate mappedDelegate)
        {
            _originalCommandEventHandler = original;
            _mappedEventHandler = mappedDelegate;
            _destinationCommandEventHandler += new CommandEventHandler(this.OnCommandEvent);
        }


        #endregion Constructeur

        #region M�thodes

        public void RaiseEvent()
        {
            if (QXPFrk.Validation.IsNotNull(_originalEventHandler))
            {
                _originalEventHandler(_sender, _ea);
            }
            if (QXPFrk.Validation.IsNotNull(_originalBasicHandler))
            {
                _originalBasicHandler();
            }
            if (QXPFrk.Validation.IsNotNull(_originalDataListEventHandler))
            {
                _originalDataListEventHandler(_sender, _dlcea);
            }
            if (QXPFrk.Validation.IsNotNull(_originalServerValidateHandler))
            {
                _originalServerValidateHandler(_sender, _svea);
            }
            if (QXPFrk.Validation.IsNotNull(_originalCommandEventHandler))
            {
                _originalCommandEventHandler(_sender, _cea);
            }
        }

        private void OnBasicEvent()
        {
            if (QXPFrk.Validation.IsNotNull(_mappedEventHandler))
            {
                try
                {
                    _mappedEventHandler(this);
                }
                catch (ThreadAbortException)
                {
                }
                catch (Exception ex)
                {
                    QXPDiagnostic.Log.LogError("EventMapping.OnBasicEvent", ex);
                }
            }
        }

        #endregion M�thodes

        #region Evenements

        private void OnEvent(object sender, EventArgs ea)
        {
            _sender = sender;
            _ea = ea;
            if (QXPFrk.Validation.IsNotNull(_mappedEventHandler))
            {
                try
                {
                    _mappedEventHandler(this);
                }
                catch (ThreadAbortException)
                {
                }
                catch (Exception ex)
                {
                    QXPDiagnostic.Log.LogError("EventMapping.OnEvent", ex);
                }
            }
        }

        private void OnDateListEvent(object sender, DataListCommandEventArgs dlcea)
        {
            _sender = sender;
            _dlcea = dlcea;
            if (QXPFrk.Validation.IsNotNull(_mappedEventHandler))
            {
                try
                {
                    _mappedEventHandler(this);
                }
                catch (ThreadAbortException)
                {
                }
                catch (Exception ex)
                {
                    QXPDiagnostic.Log.LogError("EventMapping.OnEvent", ex);
                }
            }
        }

        private void OnServerValidateEvent(object sender, ServerValidateEventArgs svea)
        {
            _sender = sender;
            _svea = svea;
            if (QXPFrk.Validation.IsNotNull(_mappedEventHandler))
            {
                try
                {
                    _mappedEventHandler(this);
                }
                catch (ThreadAbortException)
                {
                }
                catch (Exception ex)
                {
                    QXPDiagnostic.Log.LogError("EventMapping.OnEvent", ex);
                }
            }
        }

        private void OnCommandEvent(object sender, CommandEventArgs cea)
        {
            _sender = sender;
            _cea = cea;
            if (QXPFrk.Validation.IsNotNull(_mappedEventHandler))
            {
                try
                {
                    _mappedEventHandler(this);
                }
                catch (ThreadAbortException)
                {
                }
                catch (Exception ex)
                {
                    QXPDiagnostic.Log.LogError("EventMapping.OnEvent", ex);
                }
            }
        }

        #endregion Evenements

        #region Propri�t�s

        public BasicHandler MappedBasicHandler
        {
            get { return _destinationBasicHandler; }
        }

        public EventHandler MappedEventHandler
        {
            get { return _destinationEventHandler; }
        }

        public DataListCommandEventHandler MappedDataListEventHandler
        {
            get { return _destinationDataListEventHandler; }
        }

        public ServerValidateEventHandler MappedServerValidateEventHandler
        {
            get { return _destinationServerValidateHandler; }
        }

        public CommandEventHandler MappedCommandEventHandler
        {
            get { return _destinationCommandEventHandler; }
        }

        #endregion Propri�t�s
    }
}
