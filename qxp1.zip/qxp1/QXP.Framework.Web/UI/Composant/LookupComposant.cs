using QXPFrk                = QXP.Framework;
using QXPWUI                = QXP.Framework.Web.UI;

namespace QXP.Framework.Web.UI.Component
{
    public class LookupComponent : BaseComponent
    {        
        #region Membres

        private int _maxRows = 100;

        #endregion Membres

        #region Constantes

        protected const string TableLigneBoutonCssClass = "TableLigneBoutons";
        protected const string LigneBoutonCssClass = "LigneBoutons";
        protected const string BoutonCssClass = "Bouton";
        private const string WaitControlCss = "waitctrl_lookup";

        #endregion Constantes

        #region Enums

        protected enum ResourceSection
        {
            LookupComponent,
        }

        protected enum ResourceGroupe
        {
            Rechercher,
            Zero_Enregistrement,
            Max_Enregistrement,
            Min_Caractere,
        }

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de LookupComponent
        /// </summary>
        protected LookupComponent()
        {
            this.CssClass = CssClassComposant.lookupcomposant.ToString();
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Ferme la Lookup et retourne la valeur donn�e
        /// Attention : doit �tre diff�rente de l'appel pr�c�dent pour que l'EventChange soit d�clench� !
        /// </summary>
        /// <param name="returnValue">Valeur retourn�e</param>
        protected void ReturnAndCloseLookup(string returnValue)
        {
            string __callScript = string.Empty;
            string __postScript = string.Empty;
            string __returnValue = string.Empty;

            if (Validation.IsSet(returnValue))
                __returnValue = QXPFrk.StringHelper.ConvertTextToJavascript(returnValue);
            else
                __returnValue = " ";

            if (QXPFrk.Validation.IsSet(this.Request["callid"]))
                __callScript = string.Concat(QXPWUI.RenderUtility.GetCallFireEventReferenceFromOpenerSansJS(this.Request["callid"]), ";");
            else
            {
                if (QXPFrk.Validation.IsSet(this.Request["postid"]))
                    __postScript = string.Format("window.opener.window.__doPostBack('{0}', '');", this.Request["postid"]);
            }

            string __closeScript = string.Format("try{{window.opener.document.forms['{0}'].elements['{1}'].value = \"{2}\";{3}{4};}}catch(e) {{}};window.close();", "MainForm", this.Page.Request["CtrlName"], __returnValue, __callScript, __postScript);

            QXPWUI.ClientScript __script = new QXPWUI.ClientScript(this, "CloseWindows", __closeScript);

            __script.RegisterForClientSideEval();

            this.UpdateAfterCallBack = false;
        }

        /// <summary>
        /// Ferme la Lookup
        /// </summary>
        protected void CloseLookup()
        {
            string __closeScript = "window.close();";

            QXPWUI.ClientScript __script = new QXPWUI.ClientScript(this, "CloseWindows", __closeScript);

            __script.RegisterForClientSideEval();

            this.UpdateAfterCallBack = false;
        }

        /// <summary>
        /// Ferme la Lookup et lance un postback sur la page parente
        /// </summary>
        protected void CloseLookupAndPostBackParent()
        {
            string __closeScript = "window.opener.__doPostBack('', '');window.close();";

            QXPWUI.ClientScript __script = new QXPWUI.ClientScript(this, "CloseWindows", __closeScript);

            __script.RegisterForClientSideEval();

            this.UpdateAfterCallBack = false;
        }

        #endregion M�thodes

        #region Propri�t�s

        protected int MaxRows
        {
            get { return _maxRows; }
            set { _maxRows = value; }
        }

        #endregion Propri�t�s
    }
}