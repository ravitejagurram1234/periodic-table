using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXPApplication = QXP.Framework.Application;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPFrkWebUser = QXP.Framework.Web.User;
using QXPResources = QXP.Framework.Resources;
using QXPWUI = QXP.Framework.Web.UI;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIControls = QXP.Framework.Web.UI.Controls;
using QXPWUIValidator = QXP.Framework.Web.UI.Controls.Validator;

namespace QXP.Framework.Web.UI.Component
{

    /// <summary>
    /// Class BaseComponent : Composant de base des composants du portail web
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class BaseComponent : UserControl, QXPResources.IResource
    {
        #region Membres

        QXPWUIBasic.AutoScroll _autoScroll;
        QXPWUIBasic.Label _title;
        QXPWUIControls.WebControl _container;
        QXPWUIBasic.VerticalTableSection _sections;
        QXPWUIControls.WebControlSection _body;
        QXPWUIBasic.Panel _panelButtons;
        ContentMessage _contentMessage;
        bool _autoBindchildren = true;
        string _rs;
        QXPResources.ResourceInfo _resourceInfo;
        bool _authentified = false;
        bool _showTitle = true;
        ArrayList _eventHandlers = null;
        bool _authorized = true;
        PerfControl _perfControl;
        BasePage _qxpPage = null;
        bool _isSetQXPPage = false;
        List<Control> _controls = new List<Control>();
        ControlStatePersister _statePersister = new ControlStatePersister();


        public event BasicHandler ComponentInit;
        public event BasicHandler ComponentLoad;
        public event BasicHandler ComponentBind;
        public event BasicHandler ComponentBindComplete;
        public event BasicHandler ComponentPrerender;

        #endregion Membres

        #region Constantes

        const string pnl_btns = "pnl_btns";
        const string ComposantAnchor = "ComposantAnchor";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de BaseComponent
        /// </summary>
        protected BaseComponent()
        {
            _eventHandlers = new ArrayList();
            this.TrackViewState();
            this.Init += this.GetEventHandler(new EventHandler(this.OnComponentInit));
            this.Load += this.GetEventHandler(new EventHandler(this.OnComponentLoad));
            this.PreRender += this.GetEventHandler(new EventHandler(this.OnComponentPrerender));
            _container = new QXPWUIControls.WebControl();
            _container.CssClass = CssClassComposant.composant.ToString();
            _rs = this.GetType().Name;
            _resourceInfo = new QXPResources.ResourceInfo();
            _resourceInfo.SetInfo(null, _rs);

            _sections = new QXPWUIBasic.VerticalTableSection();
            _sections.CssClass = "tblcontent";
            _sections.AutoUpdateAfterCallBack = true;

            _perfControl = new PerfControl(true);
        }

        #endregion Constructeur

        #region M�thodes

        #region Controles � d�sactiver pendant le call back anthem
        /// <summary>
        /// Permet d'ajouter un control comment �tant un control � d�sactiver (disabled) lors d'un appel callback anthem (precallback), ce control sera � nouveau activ� � la fin de l'appel (postcallback) 
        /// Le control ne sera pas ajout� s'il est d�j� pr�sent dans la liste des controles � d�sactiver.
        /// </summary>
        /// <param name="control">le control � d�sactiver.</param>
        public void AddControlToDisabledDuringCallBack(Control control)
        {
            //ont ajoute que une fois
            if (!_controls.Contains(control)) _controls.Add(control);
        }

        /// <summary>
        /// Permet d'obtenir le script d�finissant la liste des controls � d�sactiv�.
        /// S'il n'y � aucun control � d�sactiv� le script est vide.
        /// </summary>
        /// <returns>je javascript contenant la collection des controles � d�sactiver.</returns>
        private string GetDisabledControlDuringCallBackScript()
        {
            string __result = string.Empty;
            if (_controls.Count > 0)
            {
                __result = string.Format("var controlsToDisabledDuringCallBack = new Array({0});", string.Join(",", _controls.Select(ctrl => "\"" + ctrl.ClientID + "\"").ToArray()));
            }
            return __result;
        }

        /// <summary>
        /// Gestion par d�fault des controls � d�sactiver, cette propri�t� est appel� durant le pr�render du composant et peut �tre overrid�
        /// </summary>
        /// <remarks>
        /// Par d�faut tous les elements du composant sont d�sactiv� pendant les call back anthem
        /// </remarks>
        protected virtual void AddControlsToDisabledDuringCallBack()
        {
            this.AddControlToDisabledDuringCallBack(this.SectionsContainer);
        }

        #endregion Controles � d�sactiver pendant le call back anthem


        public void SetDefaultButton(QXPWUIBasic.Button button)
        {
            if (QXPFrk.Validation.IsNotNull(button))
            {
                button.MonitorEnterKey(this.Page.Form);
            }
        }

        /// <summary>
        /// Ajoute le fichier de script donn� � la page
        /// </summary>
		/// <param name="scriptName">nom du fichier JS, sans le chemin absolu</param>
		/// <param name="startup">true il faut ajouter le script au d�but du body, false � la fin du body</param>
        protected void AddJSFile(string scriptName, bool startup)
        {
            string __script = string.Format("<script language=\"javascript\" src=\"{0}\" type=\"text/javascript\"></script>", QXPWUI.Utils.GetAbsoluteUrl("scripts/" + scriptName));
            QXPWUI.ClientScript __scriptJS = new QXPWUI.ClientScript(this, string.Concat("ScriptsJS_",scriptName), __script);
            __scriptJS.StartupScript = startup;
            __scriptJS.Register();
        }

		/// <summary>
		/// Ajoute le script donn� � la page
		/// </summary>
		/// <param name="scriptName">optionnel, nom du script, si null il est g�n�r� al�atoirement.</param>
		/// <param name="script">le script � ajouter � la page</param>
		/// <param name="startup">true il faut ajouter le script au d�but du body, false � la fin du body</param>
		protected void AddJSScript(string scriptName, string script, bool startup)
		{
		    string __script = string.Format("<script language=\"javascript\" type=\"text/javascript\">{0}</script>", script);
		    string __scriptName = scriptName;
			if (Validation.IsNotSet(__scriptName))
			{
				__scriptName = string.Concat("ScriptsJS_",Guid.NewGuid().ToString().Replace("-", "_"));
			}
			QXPWUI.ClientScript __scriptJS = new QXPWUI.ClientScript(this, __scriptName, __script);
		    __scriptJS.StartupScript = startup;
		    __scriptJS.Register();
		}

        #region Creation de Controles
        
        public void AddToZoneButton(Control control)
        {
            if (Validation.IsNull(control)) return;
            _panelButtons.Visible = true;
            _panelButtons.Body.Add(control);
        }
        
        public QXPWUIBasic.Panel CreatePanel(int backgroundIndexColor, Enum title)
        {
            QXPWUIBasic.Panel __panel = new QXPWUIBasic.Panel();
            __panel.BackColorIndex = backgroundIndexColor;
            __panel.Title = this.ResourceInfo.GetLabel(title);
            return __panel;
        }
        
        public QXPWUIBasic.Panel CreatePanel(int backgroundIndexColor, bool hasHeader)
        {
            QXPWUIBasic.Panel __panel = new QXPWUIBasic.Panel();
            __panel.BackColorIndex = backgroundIndexColor;
            __panel.HasHeader = hasHeader;
            return __panel;
        }
        
        public QXPWUIBasic.Panel CreatePanel(int backgroundIndexColor, Enum title, string cssClass)
        {
            QXPWUIBasic.Panel __panel = new QXPWUIBasic.Panel();
            __panel.BackColorIndex = backgroundIndexColor;
            __panel.Title = this.ResourceInfo.GetLabel(title);
            __panel.CssClass = cssClass;
            return __panel;
        }
        
        public QXPWUIBasic.Panel CreatePanel(int backgroundIndexColor, string title)
        {
            QXPWUIBasic.Panel __panel = new QXPWUIBasic.Panel();
            __panel.BackColorIndex = backgroundIndexColor;
            __panel.Title = title;
            return __panel;
        }

        public QXPWUIBasic.UpdatePanel CreateUpdatePanel(int backgroundIndexColor, Enum title)
        {
            QXPWUIBasic.UpdatePanel __upanel = new QXPWUIBasic.UpdatePanel();
            __upanel.BackColorIndex = backgroundIndexColor;
            __upanel.Title = this.ResourceInfo.GetLabel(title);
            return __upanel;
        }

        public QXPWUIBasic.View CreateView(Enum title)
        {
            QXPWUIBasic.View __view = new QXPWUIBasic.View();
            __view.Title = this.ResourceInfo.GetLabel(title);
            return __view;
        }
        
        public QXPWUIBasic.View CreateView(string title)
        {
            QXPWUIBasic.View __view = new QXPWUIBasic.View();
            __view.Title = title;
            return __view;
        }
        
        public QXPWUIBasic.TableSection CreationHeaderGroup(string title)
        {
            QXPWUIBasic.TableSection __tbl = this.CreationTableSection(1, 1, CssClassControles.HeaderGroup);
            QXPWUIBasic.Label __lbl = this.CreationLabel(title);

            __tbl[0, 0].Add(__lbl);
            __tbl[0, 0].CssClass = CssClassControles.HeaderGroupCell.ToString();
            return __tbl;

        }
        
        public QXPWUIBasic.TableSection CreationHeaderGroup(Enum title)
        {
            return this.CreationHeaderGroup(this.ResourceInfo.GetLabel(title));

        }
        
        public QXPWUIBasic.Label CreationLabel(string texte)
        {
            QXPWUIBasic.Label __ctrl = new QXPWUIBasic.Label();
            __ctrl.Text = texte;

            return __ctrl;
        } 
        
        public QXPWUIBasic.TableSection CreationTableSection(int colCount, int rowCount, object cssClass)
        {
            QXPWUIBasic.TableSection __tbl = new QXPWUIBasic.TableSection(colCount, rowCount);
            __tbl.CssClass = cssClass.ToString();
            return __tbl;
        }
        
        public QXPWUIBasic.TableSection CreationTableSection(int colCount, int rowCount)
        {
            QXPWUIBasic.TableSection __tbl = new QXPWUIBasic.TableSection(colCount, rowCount);
            return __tbl;
        }
        
        #endregion

        #region resource

        protected void SetResourceInfo(params object[] rs)
        {
            this.ResourceInfo.SetInfo(null, rs);
        }

        protected virtual void SetResource()
        {
            if (Validation.IsSet(this.ResourceInfo.Sections))
            {
                if (Validation.IsNotSet(this.Title))
                {
                    this.Title = this.ResourceInfo.GetLabel(ResourceGroupe.Title);
                }
                if (Validation.IsNotSet(this.ValidationHeader))
                {
                    this.ValidationHeader = this.ResourceInfo.GetLabel(ResourceGroupe.ValidationHeader);
                }
                if (QXPFrk.Validation.IsNotSet(this.ValidationHeaderCustom))
                {
                    this.ValidationHeaderCustom = this.ResourceInfo.GetLabel(ResourceGroupe.ValidationHeader);
                }

            }
        }

        #endregion

        #region Custom State Persister

        /// <summary>
        /// Chargement du viewstate sauvegarder dans la session de l'utilisateur
        /// </summary>
        public void LoadPersisterState()
        {
            if (!this.Page.IsPostBack)
            {
                if (_statePersister.Actif && _statePersister.HaveViewState && _statePersister.Enable_Loading)
                {
                    //this.TrackViewState();
                    base.LoadViewState(_statePersister.ViewState);
                }
            }
        }

        /// <summary>
        /// Sauvegarde du viewstate en cours dans la session de l'utilisateur
        /// </summary>
        /// <returns></returns>
        protected override object SaveViewState()
        {
            object __vs = base.SaveViewState();
            if (_statePersister.Actif && _statePersister.Enabled_Saving) _statePersister.ViewState = __vs;
            return __vs;
        }

        #endregion

        #region CustomValidator

        public void AddPageValidation(QXPWUIValidator.CustomValidator customValidator)
        {
            customValidator.ControlToValidate = this.ID;
            this.Controls.Add(customValidator);
        }

        #endregion CustomValidator

        #endregion M�thodes

        #region Evenements

        /// <summary>
        /// Overrider cette m�thode si vous devez effectuer des actions avant ou apr�s la mise en place de la g�om�trie du composant
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="ea"></param>
        protected virtual void OnComponentPreInit(object sender, EventArgs ea)
        {
            //abonnement � Page_Load complete pour d�clencher les databinding
            this.Page.LoadComplete += this.GetEventHandler(new EventHandler(this.OnComponentDataBind));

            // Abonnement au delegu� de validation
            if (Validation.IsNotNull(this.QXPPage))
            {
                this.QXPPage.PageValidation += this.GetBasicHandler(this.OnPageValidation);
            }

            this.Controls.Add(_container);
            //AJOUT d'UN POINT D'ancrage javascript pour aide au positionnement !!
            _container.Controls.Add(new LiteralControl(string.Format("<div id='{0}'/>", ComposantAnchor)));

            this.OnComponentResource();

            _container.Controls.Add(_sections);
            _body = new QXPWUIControls.WebControlSection();
            _body.CssClass = "body";
            _sections.Body.Add(_body);

            _sections.Header.CssClass = "hdr";
            _sections.Body.CssClass = "bdy";
            _sections.Footer.CssClass = "ftr";

            _title = new QXPWUIBasic.Label();
            _title.CssClass = "title";
            if (_showTitle) this.Header.Add(_title);

            UpdatePanel _updatePanelContentMessage = new UpdatePanel();
            _updatePanelContentMessage.UpdateMode = UpdatePanelUpdateMode.Always;
            _contentMessage = new ContentMessage();
            _updatePanelContentMessage.ContentTemplate = new Template(_contentMessage);
            this.Body.Add(_updatePanelContentMessage);


            _panelButtons = new QXPWUIBasic.Panel();
            _panelButtons.CssClass = pnl_btns;
            _panelButtons.Visible = false; // by default _panels button is hidden
            this.Footer.Add(_panelButtons);

            _autoScroll = new QXPWUIBasic.AutoScroll(_body);
            _autoScroll.Enabled = false; //Par defaut l'autoscroll sur composant est d�sactiv�

        }

        protected virtual void OnComponentInit(object sender, EventArgs ea)
        {
            //Permet de d�finir les controles de base du composant
            this.OnComponentPreInit(sender, ea);

            if (QXPFrk.Validation.IsNotNull(this.ComponentInit))
            {
                try
                {
                    this.ComponentInit();
                    this.LoadPersisterState();
                }
                catch (ThreadAbortException)
                {

                }
                catch (Exception ex)
                {
                    QXPDiagnostic.Log.LogError("OnComponentInit", ex);
                    this.ErrorMessage = QXPApplication.Application.Resources.GetGlobalErrorMessage();
                }
            }

            ////autoscroll doit �tre d�finit ici de cette mani�re les modif enable/disabled 
            ////fait dans le composant Init sont correctmeent prise en compte
            //this.Controls.Add(_autoScroll); 
            this.SetResource();

        }
        
        protected virtual void OnComponentResource()
        {

        }
        
        protected virtual void OnPageValidation()
        {
            if (!this.Page.IsValid)
            {
                this.UpdateAfterCallBack = false;
            }
        }
        
        private void OnComponentLoad(object sender, EventArgs ea)
        {
            try
            {
                if (QXPFrk.Validation.IsNotNull(this.ComponentLoad))
                {
                    this.ComponentLoad();
                }
            }
            catch (ThreadAbortException)
            {

            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("OnComponentLoad", ex);
                this.ErrorMessage = QXPApplication.Application.Resources.GetGlobalErrorMessage();
            }


        }
        
        private void OnComponentDataBind(object sender, EventArgs ea)
        {
            try
            {
                if (!this.Page.IsPostBack)
                {
                    if (QXPFrk.Validation.IsNotNull(this.ComponentBind))
                    {
                        this.ComponentBind();
                    }
                    if (this.AutoBindChildren) 
                        this.DataBind();
                    
                    if (QXPFrk.Validation.IsNotNull(this.ComponentBindComplete))
                    {
                        this.ComponentBindComplete();
                    }
                }
            }
            catch (ThreadAbortException)
            {

            }
            catch (Exception ex)
            {
                //_body.Add(string.Format("Error {0}: {1}", this.GetType().Name, ex));
                QXPDiagnostic.Log.LogError("ComponentBind", ex);
                this.ErrorMessage = QXPApplication.Application.Resources.GetGlobalErrorMessage();
            }
        }
        
        private void OnComponentPrerender(object sender, EventArgs ea)
        {
            if (QXPFrk.Validation.IsNotNull(this.ComponentPrerender))
            {
                try
                {
                    this.ComponentPrerender();
                }
                catch (ThreadAbortException)
                {

                }
                catch (Exception ex)
                {
                    QXPDiagnostic.Log.LogError("OnComponentPrerender", ex);
                    this.ErrorMessage = QXPApplication.Application.Resources.GetGlobalErrorMessage();
                }
            }
            if (Validation.IsSet(QXPFrkWebUser.User.Current.InfoMessage))
            {
                if (Validation.IsSet(this.InfoMessage))
                {
                    this.InfoMessage += "<br>" + QXPFrkWebUser.User.Current.InfoMessage;
                }
                else
                {
                    this.InfoMessage = QXPFrkWebUser.User.Current.InfoMessage;
                }
                QXPFrkWebUser.User.Current.InfoMessage = "";
            }
            if (Validation.IsSet(QXPFrkWebUser.User.Current.ErrorMessage))
            {
                if (Validation.IsSet(this.ErrorMessage))
                {
                    this.ErrorMessage += "<br>" + QXPFrkWebUser.User.Current.ErrorMessage;
                }
                else
                {
                    this.ErrorMessage = QXPFrkWebUser.User.Current.ErrorMessage;
                }
                QXPFrkWebUser.User.Current.ErrorMessage = "";
            }

            //Gestion des controls � d�sactiver pendant le call back
            this.AddControlsToDisabledDuringCallBack();

            string __disabledControlsArray = this.GetDisabledControlDuringCallBackScript();
            if (Validation.IsSet(__disabledControlsArray))
            {
                ClientScript __disabledControlsScript = new ClientScript(this, "DisabledControlDuringCallBack", __disabledControlsArray, true);
                __disabledControlsScript.Register();
            }
 
        }


        #region Events Errors Catching

        public BasicHandler GetBasicHandler(BasicHandler basiceventHandler)
        {
            EventMapping __eventMapping = new EventMapping(basiceventHandler, new EventDelegate(this.OnEventHandlerMapping));
            _eventHandlers.Add(__eventMapping);
            return __eventMapping.MappedBasicHandler;
        }

        public EventHandler GetEventHandler(EventHandler eventHandler)
        {
            EventMapping __eventMapping = new EventMapping(eventHandler, new EventDelegate(this.OnEventHandlerMapping));
            _eventHandlers.Add(__eventMapping);
            return __eventMapping.MappedEventHandler;
        }

        public DataListCommandEventHandler GetDataListEventHandler(DataListCommandEventHandler dataListEventHandler)
        {
            EventMapping __eventMapping = new EventMapping(dataListEventHandler, new EventDelegate(this.OnEventHandlerMapping));
            _eventHandlers.Add(__eventMapping);
            return __eventMapping.MappedDataListEventHandler;
        }

        public ServerValidateEventHandler GetServerValidateEventHandler(ServerValidateEventHandler serverValidateEventHandler)
        {
            EventMapping __eventMapping = new EventMapping(serverValidateEventHandler, new EventDelegate(this.OnEventHandlerMapping));
            _eventHandlers.Add(__eventMapping);
            return __eventMapping.MappedServerValidateEventHandler;
        }

        public CommandEventHandler GetCommandEventHandler(CommandEventHandler commandEventHandler)
        {
            EventMapping __eventMapping = new EventMapping(commandEventHandler, new EventDelegate(this.OnEventHandlerMapping));
            _eventHandlers.Add(__eventMapping);
            return __eventMapping.MappedCommandEventHandler;
        }

        public void OnEventHandlerMapping(EventMapping ehm)
        {
            try
            {
                ehm.RaiseEvent();
            }
            catch (ThreadAbortException)
            {
                //nothing to catch Response.redirect is probably in progress !!!
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("OnEventHandlerMapping", ex);
                this.ErrorMessage = QXPApplication.Application.Resources.GetGlobalErrorMessage();
            }
        }

        #endregion







        #endregion Evenements

        #region Propri�t�s

        public bool DisplayValidationSummary
        {
            get { return _contentMessage.DisplayValidationSummary; }
            set { _contentMessage.DisplayValidationSummary = value; }
        }
        
        public bool ValidationShowMessageBox
        {
            get { return _contentMessage.ValidationShowMessageBox; }
            set { _contentMessage.ValidationShowMessageBox = value; }
        }
        
        public bool ValidationShowSummary
        {
            get { return _contentMessage.ValidationShowSummary; }
            set { _contentMessage.ValidationShowSummary = value; }
        }

        public QXPWUI.BasePage QXPPage
        {
            get
            {
                if (!_isSetQXPPage)
                {
                    _qxpPage = this.Page as QXPWUI.BasePage;
                }
                return _qxpPage;
            }
        }
        
        public bool AutoBindChildren
        {
            get { return _autoBindchildren; }
            set { _autoBindchildren = value; }
        }
        
        public QXPWUIBasic.ItemSection Header
        {
            get { return _sections.Header; }
        }
        
        public QXPWUIControls.WebControlSection Body
        {
            get { return _body; }
        }
        
        public QXPWUIBasic.ItemSection Footer
        {
            get { return _sections.Footer; }
        }
        
        public QXPWUIBasic.VerticalTableSection Sections
        {
            get { return _sections; }
        }

        /// <summary>
        /// Repr�sente le container des section(header, body et footer)
        /// </summary>        
        public QXPWUIControls.WebControl SectionsContainer
        {
            get { return _container; }
        }
        
        public string CssClass
        {
            get { return _container.CssClass; }
            set { _container.CssClass = string.Concat(_container.CssClass, QXPFrk.Constantes.Space, value).Trim(); }
        }
        
        public string Title
        {
            get { return _title.Text; }
            set { _title.Text = value; }
        }
        
        public string InfoMessage
        {
            get { return _contentMessage.InfoMessage; }
            set { _contentMessage.InfoMessage = value; }
        }
        
        public string ErrorMessage
        {
            get { return _contentMessage.ErrorMessage; }
            set { _contentMessage.ErrorMessage = value; }
        }
        
        public string ValidationHeader
        {
            get { return _contentMessage.ValidationHeader; }
            set { _contentMessage.ValidationHeader = value; }
        }
        
        public string ValidationHeaderCustom
        {
            get { return _contentMessage.ValidationHeaderCustom; }
            set { _contentMessage.ValidationHeaderCustom = value; }
        }
        
        public bool Authentified
        {
            get { return _authentified; }
            set { _authentified = value; }
        }
        
        protected bool ShowTitle
        {
            get { return _showTitle; }
            set { _showTitle = value; }
        }
        
        /// <summary>
        /// Permet de d�finir si un composant rempli les conditions d'affichage.
        /// </summary>
        public virtual bool Authorized
        {
            get { return _authorized; }
            set { _authorized = value; }
        }

        public QXPWUIBasic.Panel ZoneButton
        {
            get { return _panelButtons; }
        }

        public bool AutoUpdateAfterCallBack
        {
            get { return _sections.AutoUpdateAfterCallBack; }
            set { _sections.AutoUpdateAfterCallBack = value; }
        }

        public bool UpdateAfterCallBack
        {
            get { return _sections.UpdateAfterCallBack; }
            set { _sections.UpdateAfterCallBack = value; }
        }

        public string RS
        {
            get { return _rs; }
        }

        public QXPResources.ResourceInfo ResourceInfo
        {
            get { return _resourceInfo; }
        }

        /// <summary>
        /// Repr�sente l'objet permet la gestion du viewstate en session
        /// peut �tre activ� en donnant un nom au statepersister par la methode Register
        /// </summary>
        public ControlStatePersister StatePersister
        {
            get { return _statePersister; }
        }

        public string ValidationGroupCustom
        {
            get { return _contentMessage.CustomValidationGroup; }
            set { _contentMessage.CustomValidationGroup = value; }
        }

        /// <summary>
        /// ScriptManager AjaxNet (utilis� pour l'ajax .net)
        /// </summary>
        public ScriptManager ScriptManager
        {
            get { return ScriptManager.GetCurrent(Page); }
        }

        #endregion Propri�t�s
    }

    /// <summary>
    /// Class ContentMessage : Description
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class ContentMessage : QXPWUIBasic.TableSection
    {
        #region Membres

        QXPWUIBasic.Label _infoMessage;
        QXPWUIBasic.Label _errorMessage;
        QXPWUIValidator.CustomValidator _content_Validator;
        QXPWUIValidator.ValidationSummary _validationSummary;
        QXPWUIValidator.ValidationSummary _validationSummaryCustom;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ContentMessage
        /// </summary>
        public ContentMessage()
            : base(1, 3)
        {
            this.AutoUpdateAfterCallBack = true;
            this.CssClass = "contentmessage";
            this[0, 0].CssClass = "contentmessageerror";
            this[1, 0].CssClass = "contentmessageinfo";
            this[2, 0].CssClass = "contentmessagesummary";
            _errorMessage = new QXPWUIBasic.Label();
            _errorMessage.CssClass = "errorMsg";
            _errorMessage.EnableViewState = false;
            _infoMessage = new QXPWUIBasic.Label();
            _infoMessage.CssClass = "infoMsg";
            _infoMessage.EnableViewState = false;
            _validationSummary = new QXPWUIValidator.ValidationSummary();
            _validationSummary.CssClass = "vldsum";
            _validationSummaryCustom = new QXPWUIValidator.ValidationSummary();
            _validationSummaryCustom.CssClass = "vldsum";

            this[0, 0].Add(_errorMessage);
            this[1, 0].Add(_infoMessage);
            this[2, 0].Add(_validationSummary);
            this[2, 0].Add(_validationSummaryCustom);
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Evenements

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            this[0].Visible = Validation.IsSet(this.ErrorMessage);
            this[1].Visible = Validation.IsSet(this.InfoMessage);
            _validationSummaryCustom.Visible = Validation.IsSet(_validationSummaryCustom.ValidationGroup);
        }

        #endregion Evenements

        #region Propri�t�s

        public string InfoMessage
        {
            get { return _infoMessage.Text; }
            set { _infoMessage.Text = value; }
        }
        
        public string ErrorMessage
        {
            get { return _errorMessage.Text; }
            set { _errorMessage.Text = value; }
        }
        
        public string ValidationHeader
        {
            get { return _validationSummary.HeaderText; }
            set { _validationSummary.HeaderText = value; }
        }
        
        public string ValidationHeaderCustom
        {
            get { return _validationSummaryCustom.HeaderText; }
            set { _validationSummaryCustom.HeaderText = value; }
        }
        
        public string CustomValidationGroup
        {
            get { return _validationSummaryCustom.ValidationGroup; }
            set { _validationSummaryCustom.ValidationGroup = value; }
        }
        
        public bool DisplayValidationSummary
        {
            get { return _validationSummary.Visible; }
            set { _validationSummary.Visible = value; }
        }
        
        public bool ValidationShowMessageBox
        {
            get { return _validationSummary.ShowMessageBox; }
            set { _validationSummary.ShowMessageBox = value; }
        }
        
        public bool ValidationShowSummary
        {
            get { return _validationSummary.ShowSummary; }
            set { _validationSummary.ShowSummary = value; }
        }

        #endregion Propri�t�s
    }

    public class DefaultComponent : BaseComponent
    {
        protected DefaultComponent()
        {
            this.CssClass = CssClassComposant.defaultcomposant.ToString();
        }
    }
}
