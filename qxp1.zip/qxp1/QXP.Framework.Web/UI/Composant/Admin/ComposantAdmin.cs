using QXPFrk = QXP.Framework;
using QXPFrkUser = QXP.Framework.User;
using QXPFrkWebUser = QXP.Framework.Web.User;

namespace QXP.Framework.Web.UI.Component
{
    /// <summary>
    /// Class ComposantAdmin : ComposantAdmin
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class ComposantAdmin : DefaultComponent
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ComposantAdmin
        /// </summary>
        public ComposantAdmin()
        {
            this.ComponentInit += new QXPFrk.BasicHandler(this.CreateConstituantControls);
            this.ComponentBind += new BasicHandler(this.ComponentDataBind);
#if (!DEBUG)
				this.Authentified	= true;
#endif
        }

        #endregion Constructeur

        #region M�thodes

        private void CreateConstituantControls()
        {
            if (QXPFrk.Validation.IsNotSet(this.Title)) this.Title = ":: Admin Composant";
            this.CssClass = "Admin_Composant";
        }

        private void ComponentDataBind()
        {
        }

        protected virtual bool HaveEnoughRights
        {
            get { return QXPFrkWebUser.User.Current.UserType == QXPFrkUser.UserType.Admin; }
        }

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
