using System;
using System.Collections;
using System.Data;
using System.Management;
using System.Reflection;
using System.Text;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPFrkUser = QXP.Framework.User;
using QXPFrkWebUser = QXP.Framework.Web.User;
using QXPProxy = QXP.Framework.Proxy;
using QXPSecurity = QXP.Framework.Security;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIComposite = QXP.Framework.Web.UI.Controls.Composite;

namespace QXP.Framework.Web.UI.Component
{

    /// <summary>
    /// Class Debug : Composant Debug
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class Debug : DefaultComponent
    {
        #region Membres

        System.Web.UI.WebControls.DataGrid _dataGrid;
        QXPWUIComposite.Label _processIdentity;
        QXPWUIComposite.Label _requestIdentity;
        QXPWUIComposite.Label _dbCheck;
        QXPWUIComposite.DropDownList _logFrom;
        QXPWUIBasic.TextBox _sql;
        QXPWUIBasic.Button _gc;
        QXPWUIBasic.Button _execute;
        QXPWUIBasic.Button _downloadLog;
        QXPWUIBasic.Button _assemblyInfos;
        QXPWUIBasic.Button _processInfo;

        #endregion Membres

        #region Constantes

        const string Caption = "Caption";
        const string VirtualSize = "VirtualSize";
        const string WorkingSetSize = "WorkingSetSize";
        const string UserModeTime = "UserModeTime";
        const string WriteOperationCount = "WriteOperationCount";
        const string WriteTransferCount = "WriteTransferCount";
        const string PageFaults = "PageFaults";
        const string PageFileUsage = "PageFileUsage";
        const string Priority = "Priority";

        #endregion Constantes

        #region Enums

        enum LogFromEnum
        {
            LastDay = 0,
            LastTwoDays = 1,
            LastWeek = 2,
            LastMonth = 3
        }

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Debug
        /// </summary>
        public Debug()
        {
            this.ComponentInit += new QXPFrk.BasicHandler(this.CreateConstituantControls);
            this.ComponentBind += new BasicHandler(this.ComponentDataBind);
            this.Authentified = true;
#if (!DEBUG)
            this.Authorized = (QXPFrkWebUser.User.Current.UserType == QXPFrkUser.UserType.Admin);
#endif
        }

        #endregion Constructeur

        #region M�thodes

        private void CreateConstituantControls()
        {
            this.Title = ":: Debug Composant";
            this.CssClass = "Debug_Composant";

            _processIdentity = new QXPWUIComposite.Label(QXPFrk.ValueType.CLSstring);
            _processIdentity.Label = "Process Identity";

            _requestIdentity = new QXPWUIComposite.Label(QXPFrk.ValueType.CLSstring);
            _requestIdentity.Label = "Request Identity";

            _dbCheck = new QXPWUIComposite.Label(QXPFrk.ValueType.CLSstring);
            _dbCheck.Label = "DB check";

            _sql = new QXPWUIBasic.TextBox();
            _sql.Columns = 100;
            _sql.Rows = 5;
            _sql.IsMultiLineText = true;

            _dataGrid = new System.Web.UI.WebControls.DataGrid();
            _dataGrid.DataMember = "Table";

            _gc = new QXPWUIBasic.Button();
            _gc.Text = "Garbage Collect";
            _gc.Click += this.GetEventHandler(new EventHandler(GCClicked));
            _gc.ConfirmMessage = "Vous �tes sur le point de vider la m�moire des objets inutiles, continuer ?";

            _execute = new QXPWUIBasic.Button();
            _execute.Text = "Execute";
            _execute.Click += this.GetEventHandler(new EventHandler(ButtonClicked));

            _downloadLog = new QXPWUIBasic.Button();
            _downloadLog.EnableCallBack = false;
            _downloadLog.Text = "Download Log";
            _downloadLog.Click += this.GetEventHandler(new EventHandler(DownloadLogClicked));

            _assemblyInfos = new QXPWUIBasic.Button();
            _assemblyInfos.Text = "Show Assemblies Informations";
            _assemblyInfos.Click += this.GetEventHandler(new EventHandler(AssemblyInfosClicked));

            _processInfo = new QXPWUIBasic.Button();
            _processInfo.Text = "Show Process Info";
            _processInfo.Click += this.GetEventHandler(new EventHandler(ProcessInfosClicked));

            _logFrom = new QXPWUIComposite.DropDownList(ValueType.CLSint32);
            _logFrom.DefaultValue = LogFromEnum.LastDay;
            _logFrom.Label = "Log Erreur";

            this.Body.Add(_processIdentity);
            this.Body.Add(_requestIdentity);
            this.Body.Add(_dbCheck);
            this.Body.Add(_logFrom);
            this.Body.Add(_sql);
            this.Body.Add(_dataGrid);

            this.Sections.Footer.Add(_execute);
            _logFrom.AddToZoneValidator(_downloadLog);
            this.Sections.Footer.Add(_assemblyInfos);
            this.Sections.Footer.Add(_processInfo);
            this.Sections.Footer.Add(_gc);
            _execute.Enabled = _downloadLog.Enabled = _assemblyInfos.Enabled = _processInfo.Enabled = this.HaveEnoughRights;
        }

        private void ComponentDataBind()
        {
            _processIdentity.Data = QXPSecurity.Identity.GetProcessIdentityName();
            _requestIdentity.Data = QXPSecurity.Identity.GetRequestIdentityName();
            Hashtable _logFromData = new Hashtable();
            _logFromData.Add((int)LogFromEnum.LastDay, "Aujourdhui");
            _logFromData.Add((int)LogFromEnum.LastTwoDays, "Depuis Hier");
            _logFromData.Add((int)LogFromEnum.LastWeek, "7 derniers jours");
            _logFromData.Add((int)LogFromEnum.LastMonth, "30 derniers jours");
            _logFrom.DataSource = _logFromData;

            try
            {
                if (DBCheck()) _dbCheck.Data = "Database connection operational !";
                else _dbCheck.Data = "Database problem !";
            }
            catch (Exception ex)
            {
                _dbCheck.Data = "Database connection fail !";
                this.ErrorMessage = ex.ToString();
            }
        }

        static bool DBCheck()
        {
            TestDBConnection __proxy = new TestDBConnection();
            try
            {
                if (__proxy.CheckDBConnection()) return true;
            }
            catch (Exception)
            {
                throw;
            }
            return false;
        }

        protected virtual bool HaveEnoughRights
        {
            get { return QXPFrkWebUser.User.Current.UserType == QXPFrkUser.UserType.Admin; }
        }

        private void Execute()
        {
            TestDBConnection __proxy = new TestDBConnection();
            object __dataSource = null;
            try
            {
                __dataSource = __proxy.GetDataSet(_sql.Text);
            }
            catch (Exception ex)
            {
                this.ErrorMessage = ex.ToString();
            }
            _dataGrid.DataSource = __dataSource;
            _dataGrid.DataBind();
        }

        #endregion M�thodes

        #region Evenements

        private void ButtonClicked(object sender, EventArgs ea)
        {
            if (this.HaveEnoughRights)
            {
                this.Execute();
            }
            else
            {
                this.ErrorMessage = "Vous ne poss�dez pas les droits suffisants pour ex�cuter une requ�te !";
            }

        }

        private void GCClicked(object sender, EventArgs ea)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        private void DownloadLogClicked(object sender, EventArgs ea)
        {

            string __logs = string.Empty;
            LogFromEnum __logFrom = (LogFromEnum)((int)_logFrom.Data);
            switch (__logFrom)
            {
                case LogFromEnum.LastDay:
                    __logs = QXPDiagnostic.Log.GetErrorLogFromToday();
                    break;
                case LogFromEnum.LastTwoDays:
                    __logs = QXPDiagnostic.Log.GetErrorLogFromYesterday();
                    break;
                case LogFromEnum.LastWeek:
                    __logs = QXPDiagnostic.Log.GetErrorLogFromLastWeek();
                    break;
                case LogFromEnum.LastMonth:
                    __logs = QXPDiagnostic.Log.GetErrorLogFromLastMonth();
                    break;
            }

            if (Validation.IsSet(__logs))
            {
                this.Response.ClearHeaders();
                this.Response.ClearContent();
                this.Response.Clear();
                this.Response.ContentType = "binary/octet";
                this.Response.AddHeader("content-disposition", String.Format("attachment;filename={0}", "Logs.txt"));
                this.Response.Write(__logs);
                this.Response.End();
            }
            else
            {
                this.InfoMessage = "empty log !!";
            }
        }

        private void AssemblyInfosClicked(object sender, EventArgs ea)
        {
            Assembly[] __assemblies = AppDomain.CurrentDomain.GetAssemblies();
            StringBuilder __assemblyInfos = new StringBuilder();
            SortableArrayList __infos = new SortableArrayList();
            foreach (Assembly __assembly in __assemblies)
            {
                __infos.Add(__assembly.FullName);
            }
            __infos.Sort();
            foreach (string __info in __infos)
            {
                __assemblyInfos.AppendFormat("{0}<br>", __info);
            }

            this.InfoMessage = __assemblyInfos.ToString();
        }

        private void ProcessInfosClicked(object sender, EventArgs ea)
        {
            try
            {
                if (this.HaveEnoughRights)
                {
                    StringBuilder __processInfos = new StringBuilder();
                    QXPWUIBasic.TableSection __tableProcess;//			= new QXPWUIBasic.TableSection(
                    //ArrayList			__infos			= new ArrayList();
                    ManagementClass __management = new ManagementClass("Win32_process");
                    ManagementObjectCollection __processes = __management.GetInstances();
                    __tableProcess = new QXPWUIBasic.TableSection(9, __processes.Count + 1);
                    __tableProcess.CssClass = "debugTable";
                    this.Body.Add(__tableProcess);

                    int __i = 1;
                    __tableProcess[0, 0].Add(Caption);
                    __tableProcess[0, 1].Add(VirtualSize);
                    __tableProcess[0, 2].Add(UserModeTime);
                    __tableProcess[0, 3].Add(WorkingSetSize);
                    __tableProcess[0, 4].Add(WriteOperationCount);
                    __tableProcess[0, 5].Add(WriteTransferCount);
                    __tableProcess[0, 6].Add(PageFaults);
                    __tableProcess[0, 7].Add(PageFileUsage);
                    __tableProcess[0, 8].Add(Priority);
                    foreach (ManagementObject __process in __processes)
                    {
                        __tableProcess[__i, 0].Add(__process.GetPropertyValue(Caption).ToString());
                        __tableProcess[__i, 1].Add(__process.GetPropertyValue(VirtualSize).ToString());
                        __tableProcess[__i, 2].Add(__process.GetPropertyValue(UserModeTime).ToString());
                        __tableProcess[__i, 3].Add(__process.GetPropertyValue(WorkingSetSize).ToString());
                        __tableProcess[__i, 4].Add(__process.GetPropertyValue(WriteOperationCount).ToString());
                        __tableProcess[__i, 5].Add(__process.GetPropertyValue(WriteTransferCount).ToString());
                        __tableProcess[__i, 6].Add(__process.GetPropertyValue(PageFaults).ToString());
                        __tableProcess[__i, 7].Add(__process.GetPropertyValue(PageFileUsage).ToString());
                        __tableProcess[__i, 8].Add(__process.GetPropertyValue(Priority).ToString());
                        __i++;
                    }
                }
                else
                {
                    this.ErrorMessage = "Vous ne poss�dez pas les droits suffisants pour afficher les informations !";
                }
            }
            catch (Exception ex)
            {
                this.ErrorMessage = "Impossible d'afficher les informations !";
                QXPDiagnostic.Log.LogError("ComposantDebug.ProcessInfosClicked", ex);
            }
        }

        #endregion Evenements

        #region Propri�t�s

        #endregion Propri�t�s
    }


    /// <summary>
    /// Class TestDBConnection : TestDBConnection
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class TestDBConnection : QXPProxy.BaseProxy
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de TestDBConnection
        /// </summary>
        public TestDBConnection()
        {
        }

        #endregion Constructeur

        #region M�thodes

        public bool CheckDBConnection()
        {
            try
            {
                int __id = this.ExecuteScalar(CommandType.Text, "select 1 from dual");
                return true;
            }
            catch
            {
                throw;
            }

        }

        public DataSet GetDataSet(string sql)
        {
            return base.GetDataSet(CommandType.Text, sql);
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
