using System;
using System.Collections;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPFrk					= QXP.Framework;
using QXPApplication			= QXP.Framework.Application;
using QXPDiagnostic				= QXP.Framework.Diagnostic;
using QXPIO						= QXP.Framework.IO;
using QXPProxy					= QXP.Framework.Proxy;
using QXPWUIControls			= QXP.Framework.Web.UI.Controls;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIComposite			= QXP.Framework.Web.UI.Controls.Composite;
using QXPWUIExtended			= QXP.Framework.Web.UI.Controls.Extended;
using QXPWUIList				= QXP.Framework.Web.UI.Controls.List;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;
using QXPWUIHtml				= QXP.Framework.Web.UI.Controls.Html;
using QXPSecurity				= QXP.Framework.Security;
using QXPFrkWebUser				= QXP.Framework.Web.User;

using QXPResources				= QXP.Framework.Resources;

namespace QXP.Framework.Web.UI.Component.Admin
{
	public abstract class Composant_Admin_Ressource: DefaultComponent
	{
		#region internal variables
		QXPWUIComposite.DropDownList		_list_rs;
		QXPWUIComposite.DropDownList		_list_rg;
		QXPWUIComposite.ListBox				_list_rk;
		QXPWUIComposite.DropDownList		_list_new_rs;
		QXPWUIComposite.DropDownList		_list_new_rg;
		QXPWUIComposite.ListBox				_list_new_rk;
		protected const	int				AllSectionValue			= 0;
		protected const	int				NewSectionValue			= 0;
		protected const	int				NewGroupValue			= 0;
		protected const	int				NewKeyValue				= 0;
		protected const	int				UngroupedRGValue		= int.MinValue;
		protected const	int				UngroupedRKValue		= int.MinValue;

		#endregion
		public		Composant_Admin_Ressource()
		{
			this.Authentified		    = true;
            this.UpdateAfterCallBack    = false;
		}
		private		void			CreateConstituantControls()
		{
		}
		#region control creation
		protected QXPWUIComposite.DropDownList	CreationListRS()
		{
			QXPWUIComposite.DropDownList __ctrl = new QXPWUIComposite.DropDownList();
			__ctrl.SelectedIndexChanged		+= this.GetEventHandler(new EventHandler(this.SelectedRSChanged));
			__ctrl.CssClass					= "list_rs";
			__ctrl.AutoCallBack				= true;
			__ctrl.EmptyText				= "selectionner une section";
			__ctrl.EnableEmptySelection		= true;
			__ctrl.IsSorted					= true;
			__ctrl.Label					= "Section";
			_list_rs = __ctrl;
			return __ctrl;
		}
		protected QXPWUIComposite.DropDownList	CreationListRG()
		{
			QXPWUIComposite.DropDownList __ctrl	= new QXPWUIComposite.DropDownList(ValueType.CLSint32);
			__ctrl.SelectedIndexChanged		+= this.GetEventHandler(new EventHandler(this.SelectedRGChanged));
			__ctrl.CssClass					= "list_rg";
			__ctrl.AutoCallBack				= true;
			__ctrl.EmptyText				= "selectionner un groupe";
			__ctrl.EnableEmptySelection		= true;
			__ctrl.IsSorted					= true;
			__ctrl.Label					= "Groupe";
			_list_rg = __ctrl;
			return __ctrl;
		}
		protected QXPWUIComposite.ListBox		CreationListRK()
		{
			QXPWUIComposite.ListBox __ctrl	= new QXPWUIComposite.ListBox(ValueType.ArrayOfInt);
			__ctrl.EnableMultiSelection		= true;
			__ctrl.CssClass					= "list_rk";
			__ctrl.IsSorted					= true;
			__ctrl.Rows						= 8;
			__ctrl.Label					= "Clef";
			_list_rk = __ctrl;
			return __ctrl;
		}
		protected QXPWUIComposite.DropDownList	CreationListNewRS()
		{
			QXPWUIComposite.DropDownList 		__ctrl	= new QXPWUIComposite.DropDownList(ValueType.CLSint32);
			__ctrl.SelectedIndexChanged		+= this.GetEventHandler(new EventHandler(this.SelectedNewRSChanged));
			__ctrl.CssClass					= "list_new_rg";
			__ctrl.AutoCallBack				= true;
			__ctrl.EmptyText				= "selectionner une section";
			__ctrl.EnableEmptySelection		= true;
			__ctrl.IsSorted					= true;
			__ctrl.Label					= "Section";
			_list_new_rs = __ctrl;
			return __ctrl;
		}
		protected QXPWUIComposite.DropDownList	CreationListNewRG()
		{
			QXPWUIComposite.DropDownList 	__ctrl	= new QXPWUIComposite.DropDownList(ValueType.CLSint32);
			__ctrl.SelectedIndexChanged	+= this.GetEventHandler(new EventHandler(this.SelectedNewRGChanged));
			__ctrl.CssClass				= "list_new_rg";
			__ctrl.AutoCallBack			= true;
			__ctrl.EmptyText			= "selectionner un groupe";
			__ctrl.EnableEmptySelection	= true;
			__ctrl.IsSorted				= true;
			__ctrl.Label					= "Groupe";

			_list_new_rg = __ctrl;
			return __ctrl;
		}

		protected QXPWUIComposite.ListBox		CreationListNewRK()
		{
			QXPWUIComposite.ListBox __ctrl = new QXPWUIComposite.ListBox(ValueType.ArrayOfInt);
			__ctrl.EnableMultiSelection		= true;
			__ctrl.CssClass					= "list_new_rk";
			__ctrl.IsSorted					= true;
			__ctrl.Rows						= 8;
			__ctrl.Label					= "Clef";
			_list_new_rk = __ctrl;
			return __ctrl;
		}
		protected TextRecherche					CreationRechercheGroup()
		{
			TextRecherche __ctrl		= new TextRecherche();
			__ctrl.CssClass				= "txtrecherchegroup";
			__ctrl.Label				= "Recherche par nom";
			__ctrl.ToolTip				= "Recherche un groupe par son nom";
			return __ctrl;
		}
		protected TextRecherche					CreationRechercheKey()
		{
			TextRecherche __ctrl		= new TextRecherche();
			__ctrl.CssClass				= "txtrecherchekey";
			__ctrl.Label				= "Recherche par nom";
			__ctrl.ToolTip				= "Recherche une clef par son nom";
			return __ctrl;
		}
		
		protected TextRecherche					CreationRechercheTrad()
		{
			TextRecherche __ctrl		= new TextRecherche();
			__ctrl.CssClass				= "txtrecherchetrad";
			__ctrl.Label				= "Recherche par trad";
			__ctrl.ToolTip				= "Recherche une clef par sa traduction";
			return __ctrl;
		}
		protected QXPWUIBasic.Panel				CreatePanel(int backgroundIndexColor, string title)
		{
			QXPWUIBasic.Panel __panel = new QXPWUIBasic.Panel();
			__panel.BackColorIndex	= backgroundIndexColor;
			__panel.Title			= title;
			return __panel;
		}
		#endregion
		#region events
		protected	virtual	void	SelectedRSChanged(object sender, EventArgs ea)
		{
			this.BindListRG(true);
		}
		protected	virtual	void	SelectedRGChanged(object sender, EventArgs ea)
		{
			this.BindListRK(true);
		}
		protected	virtual	void	SelectedNewRSChanged(object sender, EventArgs ea)
		{
			this.BindListNewRG(true);
		}
		protected	virtual	void	SelectedNewRGChanged(object sender, EventArgs ea)
		{
			this.BindListNewRK(true);
		}
		#endregion
		#region DataBinding
		protected	virtual	void	BindListRS(bool withBinding)
		{
			_list_rs.DataSource             = this.GetListRS(false);
            _list_rs.UpdateAfterCallBack    = true;
			if(withBinding) _list_rs.DataBind();
		}
		protected	virtual	void	BindListNewRS(bool withBinding)
		{
			_list_new_rs.DataSource             = this.GetListRS(true);
            _list_new_rs.UpdateAfterCallBack    = true;
			if(withBinding) _list_new_rs.DataBind();
		}
		protected	virtual	void	BindListRG(bool withBinding)
		{
			_list_rg.DataSource             = this.GetListRG(_list_rs, false);
            _list_rg.UpdateAfterCallBack    = true;
			if(withBinding)     _list_rg.DataBind();
		}
		protected	virtual	void	BindListNewRG(bool withBinding)
		{
			_list_new_rg.DataSource             = this.GetListRG(_list_new_rs, true);
            _list_new_rg.UpdateAfterCallBack    = true;
			if(withBinding) _list_new_rg.DataBind();
		}
		protected	virtual	void	BindListNewRG_By_Name(bool withBinding, TextRecherche textboxRecherche)
		{
			_list_new_rg.DataSource             = this.GetListRG_By_Name(textboxRecherche);
            _list_new_rg.UpdateAfterCallBack    = true;
			if(withBinding) _list_new_rg.DataBind();
		}
		protected	virtual	void	BindListRK(bool withBinding)
		{
			_list_rk.DataSource             = this.GetListRK(_list_rg);
            _list_rk.UpdateAfterCallBack    = true;
			if(withBinding) _list_rk.DataBind();
		}
		protected	virtual	void	BindListNewRK(bool withBinding)
		{
			_list_new_rk.DataSource             = this.GetListRK(_list_new_rg);
            _list_new_rk.UpdateAfterCallBack    = true;
			if(withBinding) _list_new_rk.DataBind();
		}
		#endregion
		#region DataGeneration
		protected	virtual	Hashtable	GetListRS(bool addUngroupedGroup)
		{
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			Hashtable					__rs;
			__rs	= __proxy.GetAllRS();
			if(addUngroupedGroup) __rs.Add(UngroupedRGValue, " [Groupes non associ�s]");
			return __rs;
		}
		protected	virtual	Hashtable	GetListRG(QXPWUIComposite.DropDownList control, bool addUngroupedKey)
		{
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			Hashtable		__rg;
			int				__rs = Conversion.ToInt(control.Data);
			if(control.IsEmptySelected)
			{
				__rg = new Hashtable();
			}
			else if(__rs == 0)
			{
				__rg = __proxy.GetAllRG();
			}
			else
			{
				__rg = __proxy.GetRG_Asso_RS(__rs);
			}
			if(addUngroupedKey) __rg.Add(UngroupedRKValue, " [Clefs non associ�s]");
			return __rg;
		}
		protected	virtual	Hashtable	GetListRG_By_Name(TextRecherche controlRecherche)
		{
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			Hashtable					__list_rg;
			string						__recherche = controlRecherche.Value;
			if(Validation.IsNotSet(__recherche))
			{
				__list_rg =  new Hashtable();
			}
			else
			{
				__list_rg = __proxy.GetRG_By_Nom(__recherche);
			}
			return __list_rg;
		}
		protected	virtual	Hashtable	GetListRK_By_Name(TextRecherche controlRecherche)
		{
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			Hashtable					__list_rk;
			string						__recherche = controlRecherche.Value;
			if(Validation.IsNotSet(__recherche))
			{
				__list_rk =  null;
			}
			else
			{
				__list_rk = __proxy.GetRK_By_Nom(__recherche);
			}
			return __list_rk;
		}
		protected	virtual	Hashtable	GetListRK_By_Trad(TextRecherche controlRecherche)
		{
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			Hashtable					__list_rk;
			string						__recherche = controlRecherche.Value;
			if(Validation.IsNotSet(__recherche))
			{
				__list_rk =  null;
			}
			else
			{
                string __langueUtiliseePourLaRecherche = QXPFrkWebUser.User.Current.Culture.TwoLetterISOLanguageName.ToUpper();
                __list_rk = __proxy.GetRK_By_Trad(__recherche, __langueUtiliseePourLaRecherche);
			}
			return __list_rk;
		}
		protected	virtual	Hashtable	GetListRK(QXPWUIComposite.DropDownList control)
		{
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			Hashtable		__rk;
			int				__rg = Conversion.ToInt(control.Data);
			if(control.IsEmptySelected)
			{
				__rk = null;
			}
			else
			{
				__rk	= __proxy.GetRK_Asso_RG(__rg);
			}
			return __rk;
		}

		protected	string				GetRG_Markers(int id_rg){
			QXPResources.ResourcesProxy		__proxy		= new QXPResources.ResourcesProxy();
			ArrayList						__marqueurs = __proxy.GetAllMarkerUsed_By_RG(id_rg);
			string							__result	= this.FormatMarkers(__marqueurs);
			return __result;
		}
		protected	string				GetRK_Markers(int id_rk)
		{
			QXPResources.ResourcesProxy		__proxy		= new QXPResources.ResourcesProxy();
			ArrayList						__marqueurs = __proxy.GetAllMarkerUsed_By_RK(id_rk);
			string							__result	= this.FormatMarkers(__marqueurs);
			return __result;
		}
		private		string				FormatMarkers(ArrayList marqueurs)
		{
			string[] __marqueurs	= (string[])marqueurs.ToArray(ValueType.CLSstring);
			string	 __result		= string.Join("\n", __marqueurs);
			return __result;
		}
		#endregion
	}
	public class TextRecherche: QXPWUIComposite.TextBox{
		#region internal variables
		QXPWUIBasic.Button	_recherche;
		public event BasicHandler Recherche;
		#endregion
		public TextRecherche(): base(ValueType.CLSstring)
		{
			_recherche						= new QXPWUIBasic.Button();
			_recherche.CausesValidation		= false;
			_recherche.Text					= "Rechercher";
			_recherche.Click				+= new EventHandler(this.OnClick);
			this.AddToZoneValidator(_recherche);
		}
		protected	virtual void	OnClick(object sender, EventArgs ea){
			if(Validation.IsNotNull(Recherche)){
				this.Recherche();
			}
		} 
		public		string			Value{
			get{return Conversion.ToString(this.Data);}
			set{this.Data = value;}
		}
	}
}
