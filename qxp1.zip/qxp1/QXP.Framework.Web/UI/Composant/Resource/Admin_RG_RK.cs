using System;
using System.Collections;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPFrk					= QXP.Framework;
using QXPApplication			= QXP.Framework.Application;
using QXPDiagnostic				= QXP.Framework.Diagnostic;
using QXPIO						= QXP.Framework.IO;
using QXPProxy					= QXP.Framework.Proxy;
using QXPWUIControls			= QXP.Framework.Web.UI.Controls;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIComposite			= QXP.Framework.Web.UI.Controls.Composite;
using QXPWUIExtended			= QXP.Framework.Web.UI.Controls.Extended;
using QXPWUIList				= QXP.Framework.Web.UI.Controls.List;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;
using QXPWUIHtml				= QXP.Framework.Web.UI.Controls.Html;
using QXPSecurity				= QXP.Framework.Security;
using QXPFrkWebUser				= QXP.Framework.Web.User;

using QXPResources				= QXP.Framework.Resources;

namespace QXP.Framework.Web.UI.Component.Admin
{
	public class Update_RG_RK: Composant_Admin_Ressource
	{
		#region internal variables
		QXPWUIComposite.DropDownList		_list_rs;
		QXPWUIComposite.DropDownList		_list_rg;
		QXPWUIComposite.ListBox				_list_rk;
		QXPWUIComposite.DropDownList		_list_new_rs;
		TextRecherche						_rechercheGroup;
		QXPWUIComposite.DropDownList		_list_new_rg;
		QXPWUIComposite.ListBox				_list_new_rk;
		QXPWUIBasic.Button					_supprimer;
		QXPWUIBasic.Button					_ajouter;
		QXPWUIBasic.TableSection			_tableSection;
		#endregion
		public		Update_RG_RK()
		{
			this.ComponentInit		+= new QXPFrk.BasicHandler(this.CreateConstituantControls);
			this.ComponentBind		+= new BasicHandler(this.ComponentDataBind);
			this.ComponentPrerender	+= new BasicHandler(this.OnComponentPrerender);
			this.Authentified		= true;
		}
		private		void			CreateConstituantControls()
		{
			this.Title							= ":: Traductions Statiques - Mise a jour Liaison Groupe-Clef";
			this.CssClass						= "Update_RG_RK";

            QXPWUIBasic.Panel   __pnlAll        = this.CreatePanel(0, false);

            this.Body.Add(__pnlAll);

            _tableSection						= new QXPWUIBasic.TableSection(2, 8);
			
			_list_rs							= this.CreationListRS();

			_list_rg							= this.CreationListRG();

			_list_rk							= this.CreationListRK();

			_list_new_rs						= this.CreationListNewRS();

			_rechercheGroup						= this.CreationRechercheGroup();
			_rechercheGroup.Recherche			+= this.GetBasicHandler(new BasicHandler(this.RechercheClick));

			_list_new_rg						= this.CreationListNewRG();

			_list_new_rk						= this.CreationListNewRK();

			_ajouter							= new QXPWUIBasic.Button();
			_ajouter.Text						=  "Ajouter la/les clef(s) selectionn�e(s)";
			_ajouter.Click						+= this.GetEventHandler(new EventHandler(this.AjouterClick));

			_supprimer							= new QXPWUIBasic.Button();
			_supprimer.CausesValidation			= false;
			_supprimer.Text						= "Supprimer la/les clef(s) selectionn�e(s)";
			_supprimer.Click					+= this.GetEventHandler(new EventHandler(this.SupprimerClick));

			_tableSection.CssClass		= "table_rg_rk";
			_tableSection[0,0].CssClass = "col_rs_rg_rk";
			_tableSection[0,1].CssClass = "col_new_rs_rg_rk";
			//this.Body.Add(this.CreationHeaderGroup("Selectionner une section"));
			__pnlAll.Body.Add(_tableSection);

			_tableSection[0,0].Add(this.CreationHeaderGroup("Section-Groupes-Clef associ�s"));
			_tableSection[0,1].Add(this.CreationHeaderGroup("Section-Groupes-Clef disponibles"));

			_tableSection[1,0].Add("Section � modifier");
			_tableSection[1,1].Add("Section � selectionner");
			_tableSection[2,0].Add(_list_rs);
			_tableSection[2,1].Add(_list_new_rs);
			
			_tableSection[3,0].Add("Groupe � modifier");
			_tableSection[3,1].Add("Groupe � selectionner");
			_tableSection[4,0].Add(_list_rg);
			_tableSection[4,1].Add(_rechercheGroup);
			_tableSection[4,1].Add(_list_new_rg);

			_tableSection[5,0].Add("Association de clef � modifier");
			_tableSection[5,1].Add("Association de clef � utiliser");
			_tableSection[6,0].Add(_list_rk);
			_tableSection[6,1].Add(_list_new_rk);

			//this.Body.Add(this.CreationHeaderGroup("Info section"));
			_tableSection[7,0].Add(_supprimer);
			_tableSection[7,1].Add(_ajouter);
		}
		private		void			ComponentDataBind()
		{
			this.BindListRS(false);
			this.BindListNewRS(false);
			this.BindListRG(false); //INITIALISATION
			this.BindListNewRG(false); //INITIALISATION
		}
		private		void			OnComponentPrerender()
		{
			int		__id_supprimer		= Conversion.ToInt(_list_rg.Data);
			int		__id_ajouter		= Conversion.ToInt(_list_new_rg.Data);
			bool	__enabled_supprimer	= (!_list_rg.IsEmptySelected && __id_supprimer != 0); 
			bool	__enabled_ajouter	= (!_list_new_rg.IsEmptySelected && __id_ajouter != 0); 
			_supprimer.Enabled              = __enabled_supprimer;
            _supprimer.UpdateAfterCallBack  = true;
			_ajouter.Enabled                = __enabled_ajouter;
            _ajouter.UpdateAfterCallBack    = true;
		}
		#region Events
		private		void			AjouterClick(object sender, EventArgs ea)
		{
			this.AddRK();
		}
		private		void			SupprimerClick(object sender, EventArgs ea)
		{
			this.RemoveRK();
		}
		private void				RechercheClick()
		{
			//this.InfoMessage = "Recherche click";
			this.BindListNewRG_By_Name(true, _rechercheGroup);
		}
		#endregion
		#region Save/Delete Section
		private void RemoveRK()
		{
			try
			{
				int		__id_rg			= Conversion.ToInt(_list_rg.Data);
				int[]	__list_id_rk	= Conversion.ToIntArray(_list_rk.Data);
				if(Validation.IsNotSet(__list_id_rk)) return;
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				__proxy.Remove_Asso_RG_RK(__id_rg, __list_id_rk);
				this.InfoMessage = "Suppression effectu�e !";
				this.BindListRK(true);
			}
			catch(Exception ex)
			{
				this.ErrorMessage = "Erreur de Suppression !";
				QXPDiagnostic.Log.LogError("Update_RG_RK.RemoveRK", ex);
			}
		}
		private void AddRK()
		{
			try
			{
				int		__id_rg			= Conversion.ToInt(_list_rg.Data);
				int[]	__list_id_rk	= Conversion.ToIntArray(_list_new_rk.Data);
				if(_list_rg.IsEmptySelected)
				{
					this.InfoMessage = "Vous devez s�lectionner un groupe � modifier";
					return;
				}
				else if(Validation.IsNotSet(__list_id_rk)){
					this.InfoMessage = "Vous devez s�lectionner au moins une clef � utiliser";
					return;
				}
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				__proxy.Insert_Asso_RG_RK(__id_rg, __list_id_rk);
				this.InfoMessage = "Ajout effectu�e !";
				this.BindListRK(true);
			}
			catch(Exception ex)
			{
				this.ErrorMessage = "Erreur d'ajout !";
				QXPDiagnostic.Log.LogError("Update_RG_RK.AddRK", ex);
			}

		}
		#endregion
	}
}
