using System;
using System.Collections;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPFrk					= QXP.Framework;
using QXPApplication			= QXP.Framework.Application;
using QXPDiagnostic				= QXP.Framework.Diagnostic;
using QXPIO						= QXP.Framework.IO;
using QXPProxy					= QXP.Framework.Proxy;
using QXPWUIControls			= QXP.Framework.Web.UI.Controls;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIComposite			= QXP.Framework.Web.UI.Controls.Composite;
using QXPWUIExtended			= QXP.Framework.Web.UI.Controls.Extended;
using QXPWUIList				= QXP.Framework.Web.UI.Controls.List;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;
using QXPWUIHtml				= QXP.Framework.Web.UI.Controls.Html;
using QXPSecurity				= QXP.Framework.Security;
using QXPFrkWebUser				= QXP.Framework.Web.User;

using QXPResources				= QXP.Framework.Resources;

namespace QXP.Framework.Web.UI.Component.Admin
{
	public class Update_RG: Composant_Admin_Ressource
	{
		#region internal variables
		QXPWUIComposite.DropDownList		_list_rs;
		QXPWUIComposite.DropDownList		_list_rg;
		TextRecherche						_rechercheGroup;
		QXPWUIComposite.TextBox				_rg;
		QXPWUIBasic.Button					_valider;
		QXPWUIBasic.Button					_supprimer;
		#endregion
		public		Update_RG()
		{
			this.ComponentInit		    += new QXPFrk.BasicHandler(this.CreateConstituantControls);
			this.ComponentBind		    += new BasicHandler(this.ComponentDataBind);
			this.ComponentPrerender	    += new BasicHandler(this.OnComponentPrerender);
            this.UpdateAfterCallBack    = false;
		}
		private		void			CreateConstituantControls()
		{
			this.Title							= ":: Traductions Statiques - Mise a jour Groupe";
			this.CssClass						= "Update_RG";

            QXPWUIBasic.Panel   __pnlSection        = this.CreatePanel(0, true);
            QXPWUIBasic.Panel   __pnlGroup          = this.CreatePanel(1, true);
            QXPWUIBasic.Panel   __pnlGroupInfo      = this.CreatePanel(0, true);


            __pnlSection.Title      = "Selectionner une section";
            __pnlGroup.Title        = "Selectionner un groupe";
			__pnlGroupInfo.Title    = "Info group";

            this.Body.Add(__pnlSection);
            this.Body.Add(__pnlGroup);
            this.Body.Add(__pnlGroupInfo);

			_list_rs							= this.CreationListRS();

			_list_rg							= this.CreationListRG();

			_rechercheGroup						= this.CreationRechercheGroup();
			_rechercheGroup.Recherche			+= this.GetBasicHandler(new BasicHandler(this.RechercheGroupClick));

			_rg									= new QXPWUIComposite.TextBox();
			_rg.IsRequired						= true;
			_rg.CssClass						= "rg";
			_rg.Label							= "Groupe";

			_valider							= new QXPWUIBasic.Button();
            _valider.CssClass                   = "bouton";
			_valider.Text						= "Valider";
			_valider.Click						+= this.GetEventHandler(new EventHandler(this.ValiderClick));

			_supprimer							= new QXPWUIBasic.Button();
			_supprimer.CausesValidation			= false;
			_supprimer.Enabled					= false;
			_supprimer.Text						= "Supprimer";
			_supprimer.Click					+= this.GetEventHandler(new EventHandler(this.SupprimerClick));

			__pnlSection.Body.Add(_list_rs);
			__pnlGroup.Body.Add(_rechercheGroup);
			__pnlGroup.Body.Add(_list_rg);
			__pnlGroupInfo.Body.Add(_rg);

			_list_rg.AddToZoneValidator(_supprimer);

			this.AddToZoneButton(_valider);
			//this.Footer.Add(_supprimer);

		}
		private		void			ComponentDataBind()
		{
			this.BindListRS(false);
			/*this.BindListRG(false);*/
		}
		private		void			OnComponentPrerender()
		{
			int		__id		= Conversion.ToInt(_list_rg.Data);
			bool	__enabled	= (!_list_rg.IsEmptySelected && __id != 0); 
			_supprimer.Enabled              = __enabled;
            _supprimer.UpdateAfterCallBack  = true;
			//_supprimer.Text = "supprimer changer";
		}
		#region Events
		private		void			ValiderClick(object sender, EventArgs ea)
		{
			this.SaveRG();
		}
		private		void			SupprimerClick(object sender, EventArgs ea)
		{
			this.DeleteRG();
		}
		protected override	void	SelectedRGChanged(object sender, EventArgs ea)
		{
			this.LoadGroup();
		}
		private void				RechercheGroupClick()
		{
			//this.InfoMessage = "Recherche click";
			_list_rs.Data                   = null;
            _list_rs.UpdateAfterCallBack    = true;
			this.BindListRG_By_Name(true);
		}
		#endregion
		#region DataBinding
        protected override	        void	        SelectedRSChanged(object sender, EventArgs ea)
		{
            this.ResetGroup();
			base.SelectedRSChanged(sender, ea);
		}
		protected override Hashtable		GetListRG(QXP.Framework.Web.UI.Controls.Composite.DropDownList control, bool addUngroupedKey)
		{
			Hashtable __data = base.GetListRG (control, addUngroupedKey);
			//INFO: add new group Item
			__data.Add(NewGroupValue, " [Nouveau Groupe]");
			return __data;
		}
		protected override Hashtable		GetListRS(bool addUngroupedGroup)
		{
			Hashtable __data = base.GetListRS (false);
			//INFO: add new section Item
			__data.Add(AllSectionValue, " [Toutes les sections]");
			return __data;
		}
		private		void					BindListRG_By_Name(bool withBinding)
		{
            _list_rg.DataSource             = this.GetListRG_By_Name(_rechercheGroup);
            _list_rg.UpdateAfterCallBack    = true;
			if(withBinding) _list_rg.DataBind();
		}


//		private		void			BindListRS(bool withBinding)
//		{
//			_list_rs.DataSource = this.GetListRS();
//			if(withBinding) _list_rs.DataBind();
//		}
//		private		Hashtable		GetListRS()
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable					__rs;
//			__rs = __proxy.GetAllRS();
//			//INFO: add new section Item
//			__rs.Add("0", " Toutes les sections");
//			return __rs;
//		}
//		private		void			BindListRG(bool withBinding)
//		{
//			_list_rg.DataSource = this.GetListRG();
//			if(withBinding) _list_rg.DataBind();
//		}
//		private		Hashtable		GetListRG()
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable					__rg;
//			int							__id_rs = Conversion.ToInt(_list_rs.Data);
//			if(_list_rs.IsEmptySelected)
//			{
//				__rg = new Hashtable(); //Empty table
//			}
//			else if(__id_rs == 0)
//			{
//				__rg = __proxy.GetAllRG();
//			}
//			else
//			{
//				__rg = __proxy.GetRG_By_Section(__id_rs);
//			}
//			//INFO: add new section Item
//			__rg.Add("0", " Nouveau Groupe");
//			return __rg;
//		}
		private		void			ResetGroup()
		{
			_rg.Data                = null;
            _rg.ToolTip             = null;
            _rg.UpdateAfterCallBack = true;
		}
		private		void			LoadGroup(){
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			int							__id_rg = Conversion.ToInt(_list_rg.Data);
			if(_list_rg.IsEmptySelected || __id_rg == 0)
			{
				_rg.Data	            = null;
				_rg.ToolTip             = null;
                _rg.UpdateAfterCallBack = true;
			}
			else
			{
				QXPResources.Admin.Res_RG	__rg	= __proxy.GetRG(__id_rg);
				_rg.Data	            = __rg.Name;
				_rg.ToolTip             = this.GetRG_Markers(__id_rg);
                _rg.UpdateAfterCallBack = true;
			}
			
		}
		#endregion
		#region Save/Delete Group
		private void SaveRG()
		{
			try
			{
				int		__id_rs			= Conversion.ToInt(_list_rs.Data);
				int		__id_rg			= Conversion.ToInt(_list_rg.Data);
				string	__nom			= Conversion.ToString(_rg.Data);
				bool	__addasso		= false;
				if(_list_rg.IsEmptySelected) return;
				__addasso = (__id_rs != 0);
				//INFO la clef 0 represente une nouvelle section mais la base de donn�e test valeur nul cad int.minvalue
				if(__id_rg == 0 ) __id_rg = int.MinValue; 
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				if(__addasso)
				{
					if(__proxy.SaveRG_And_Asso(__id_rg, __nom, __id_rs))
					{
						this.InfoMessage = "Sauvegarde effectu�e !";
						this.BindListRG(true);
						this.ResetGroup();
					}
					else
					{
						this.ErrorMessage = "Ce groupe existe d�j� !";	//Pour plus tard actuellement les doublons dans les groupes sont autoris�s !!			
					}
				}
				else{
					if(__proxy.SaveRG(__id_rg, __nom))
					{
						this.InfoMessage = "Sauvegarde effectu�e !";
						this.BindListRG(true);
						this.ResetGroup();
					}
					else
					{
						this.ErrorMessage = "Ce groupe existe d�j� !";	//Pour plus tard actuellement les doublons dans les groupes sont autoris�s !!			
					}
				}
				
			}
			catch(Exception ex){
				this.ErrorMessage = "Erreur de sauvegarde !";
				QXPDiagnostic.Log.LogError("Update_RG.SaveRG", ex);
			}
		}
		private void DeleteRG(){
			try
			{
				int		__id_rg			= Conversion.ToInt(_list_rg.Data);
				//INFO la clef 0 represente une nouvelle section mais la base de donn�e test valeur nul cad int.minvalue
				if(__id_rg == 0 )
				{
					this.ErrorMessage = "impossible de supprimer un nouveau group";
					return;
				}
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				if(__proxy.DeleteRG(__id_rg))
				{
					this.InfoMessage = "Suppression effectu�e !";
					this.BindListRG(true);
					this.ResetGroup();
				}
				else
				{
					this.ErrorMessage = "Impossible de supprimer ce groupe, il est utilis�e par un/des clef(s) !";				
				}
			}
			catch(Exception ex)
			{
				this.ErrorMessage = "Erreur de suppression !";
				QXPDiagnostic.Log.LogError("Update_RG.DeleteRG", ex);
			}			
		}
		#endregion
	}
}
