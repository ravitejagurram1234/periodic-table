 using System;
using System.Collections;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPFrk					= QXP.Framework;
using QXPApplication			= QXP.Framework.Application;
using QXPDiagnostic				= QXP.Framework.Diagnostic;
using QXPIO						= QXP.Framework.IO;
using QXPProxy					= QXP.Framework.Proxy;
using QXPWUIControls			= QXP.Framework.Web.UI.Controls;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIComposite			= QXP.Framework.Web.UI.Controls.Composite;
using QXPWUIExtended			= QXP.Framework.Web.UI.Controls.Extended;
using QXPWUIList				= QXP.Framework.Web.UI.Controls.List;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;
using QXPWUIHtml				= QXP.Framework.Web.UI.Controls.Html;
using QXPSecurity				= QXP.Framework.Security;
using QXPFrkWebUser				= QXP.Framework.Web.User;

using QXPResources				= QXP.Framework.Resources;

namespace QXP.Framework.Web.UI.Component.Admin
{
	public class Update_RS: Composant_Admin_Ressource
	{
		#region internal variables
		QXPWUIComposite.DropDownList		_list_rs;
		QXPWUIComposite.TextBox				_rs;
		QXPWUIBasic.Button					_valider;
		QXPWUIBasic.Button					_supprimer;
		#endregion
		public		Update_RS()
		{
			this.ComponentInit		+= new QXPFrk.BasicHandler(this.CreateConstituantControls);
			this.ComponentBind		+= new BasicHandler(this.ComponentDataBind);
			this.ComponentPrerender	+= new BasicHandler(this.OnComponentPrerender);
		}
		private		void			CreateConstituantControls()
		{
			this.Title						= ":: Traductions Statiques - Mise a jour Section";
			this.CssClass					= "Update_RS";

            QXPWUIBasic.Panel   __pnlSection        = this.CreatePanel(0, true);
            QXPWUIBasic.Panel   __pnlSectionInfo    = this.CreatePanel(1, true);

            __pnlSection.Title      = "Selectionner une section";
			__pnlSectionInfo.Title  = "Info section";

            this.Body.Add(__pnlSection);
            this.Body.Add(__pnlSectionInfo);

			_list_rs							= this.CreationListRS();
//			_list_rs.SelectedIndexChanged		+= this.GetEventHandler(new EventHandler(this.SelectedSectionChanged));
//			_list_rs.AutoPostBack				= true;
//			_list_rs.EmptyText					= "selectionner une section";
//			_list_rs.EnableEmptySelection		= true;
//			_list_rs.IsSorted					= true;
//			_list_rs.Label						= "Sections";

			_rs									= new QXPWUIComposite.TextBox();
			_rs.IsRequired						= true;
			_rs.CssClass						= "rs";
			_rs.Label							= "Section";

			_valider							= new QXPWUIBasic.Button();
            _valider.CssClass                   = "bouton";
			_valider.Text						= "Valider";
			_valider.Click						+= this.GetEventHandler(new EventHandler(this.ValiderClick));

			_supprimer							= new QXPWUIBasic.Button();
			_supprimer.CausesValidation			= false;
			_supprimer.Enabled					= false;
			_supprimer.Text						= "Supprimer";
			_supprimer.Click					+= this.GetEventHandler(new EventHandler(this.SupprimerClick));

			__pnlSection.Body.Add(_list_rs);
			__pnlSectionInfo.Body.Add(_rs);

			_list_rs.AddToZoneValidator(_supprimer);

			this.AddToZoneButton(_valider);
			//this.Footer.Add(_supprimer);

		}
		private		void			ComponentDataBind()
		{
			this.BindListRS(false);
		}
		private		void			OnComponentPrerender()
		{
			int		__id		= Conversion.ToInt(_list_rs.Data);
			bool	__enabled	= (!_list_rs.IsEmptySelected && __id != 0); 
			_supprimer.Enabled              = __enabled;
            _supprimer.UpdateAfterCallBack  = true;
			//_supprimer.Text = "supprimer changer";
		}
		#region Events
		protected override		void		SelectedRSChanged(object sender, EventArgs ea)
		{
			//this.InfoMessage = "Selected section changed ! ";
			this.LoadSection();
		}
		private		void			ValiderClick(object sender, EventArgs ea)
		{
			this.SaveRS();
		}
		private		void			SupprimerClick(object sender, EventArgs ea)
		{
			this.DeleteRS();
		}
		#endregion
		#region DataBinding
//		private		void			BindListRS(bool withBinding)
//		{
//			_list_rs.DataSource = this.GetListRS();
//			if(withBinding) _list_rs.DataBind();
//		}
		protected override			Hashtable		GetListRS(bool addUngroupedGroup)
		{
			Hashtable					__data = base.GetListRS(false);
			//INFO: add new section Item
			__data.Add(NewSectionValue, " [Nouvelle Section]");
			return __data;
		}
		private		void			ResetSection(){
			_rs.Data                = null;
            _rs.UpdateAfterCallBack = true;
		}
		private		void			LoadSection(){
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			int							__id_rs = Conversion.ToInt(_list_rs.Data);
			if(_list_rs.IsEmptySelected || __id_rs == 0)
			{
				this.ResetSection();
			}
			else
			{
				QXPResources.Admin.Res_RS	__rs	= __proxy.GetRS(__id_rs);
				_rs.Data                = __rs.Name;
                _rs.UpdateAfterCallBack = true;
			}
			
		}
		#endregion
		#region Save/Delete Section
		private void SaveRS()
		{
			try
			{
				int		__id_rs			= Conversion.ToInt(_list_rs.Data);
				string	__nom			= Conversion.ToString(_rs.Data);
				if(_list_rs.IsEmptySelected) return;
				//INFO la clef 0 represente une nouvelle section mais la base de donn�e test valeur nul cad int.minvalue
				if(__id_rs == 0 ) __id_rs = int.MinValue; 
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				if(__proxy.SaveRS(__id_rs, __nom)){
					this.InfoMessage = "Sauvegarde effectu�e !";
					this.BindListRS(true);
					this.ResetSection();
				}
				else
				{
					this.ErrorMessage = "Cette section existe d�j� !";				
				}
			}
			catch(Exception ex){
				this.ErrorMessage = "Erreur de sauvegarde !";
				QXPDiagnostic.Log.LogError("Update_RS.SaveRS", ex);
			}
		}
		private void DeleteRS(){
			try
			{
				int		__id_rs			= Conversion.ToInt(_list_rs.Data);
				//INFO la clef 0 represente une nouvelle section mais la base de donn�e test valeur nul cad int.minvalue
				if(__id_rs == 0 )
				{
					this.ErrorMessage = "impossible de supprimer une nouvelle section";
					return;
				}
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				if(__proxy.DeleteRS(__id_rs))
				{
					this.InfoMessage = "Suppression effectu�e !";
					this.BindListRS(true);
					this.ResetSection();
				}
				else
				{
					this.ErrorMessage = "Impossible de supprimer cette section, elle est utilis�e par un/des groupe(s) !";				
				}
			}
			catch(Exception ex)
			{
				this.ErrorMessage = "Erreur de suppression !";
				QXPDiagnostic.Log.LogError("Update_RS.DeleteRS", ex);
			}			
		}
		#endregion
	}
}
