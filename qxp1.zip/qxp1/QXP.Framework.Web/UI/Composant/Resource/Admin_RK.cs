using System;
using System.Collections;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPFrk					= QXP.Framework;
using QXPApplication			= QXP.Framework.Application;
using QXPDiagnostic				= QXP.Framework.Diagnostic;
using QXPIO						= QXP.Framework.IO;
using QXPProxy					= QXP.Framework.Proxy;
using QXPWUIControls			= QXP.Framework.Web.UI.Controls;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIComposite			= QXP.Framework.Web.UI.Controls.Composite;
using QXPWUIExtended			= QXP.Framework.Web.UI.Controls.Extended;
using QXPWUIList				= QXP.Framework.Web.UI.Controls.List;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;
using QXPWUIHtml				= QXP.Framework.Web.UI.Controls.Html;
using QXPSecurity				= QXP.Framework.Security;
using QXPFrkWebUser				= QXP.Framework.Web.User;

using QXPResources				= QXP.Framework.Resources;

namespace QXP.Framework.Web.UI.Component.Admin
{
	public class Update_RK: Composant_Admin_Ressource
	{
		#region internal variables
		QXPWUIComposite.DropDownList		_list_rs;
		QXPWUIComposite.DropDownList		_list_rg;
		QXPWUIComposite.DropDownList		_list_rk;
		TextRecherche						_rechercheGroup;
		TextRecherche						_rechercheKey;
		QXPWUIComposite.TextBox				_code;
		QXPWUIComposite.TextBox				_commentaire;
		QXPWUIBasic.Button					_valider;
		QXPWUIBasic.Button					_supprimer;
		#endregion
		public		Update_RK()
		{
			this.ComponentInit		+= new QXPFrk.BasicHandler(this.CreateConstituantControls);
			this.ComponentBind		+= new BasicHandler(this.ComponentDataBind);
			this.ComponentPrerender	+= new BasicHandler(this.OnComponentPrerender);
		}
		private		void				CreateConstituantControls()
		{
			this.Title							= ":: Traductions Statiques - Mise a jour Clef";
			this.CssClass						= "Update_RK";

            QXPWUIBasic.Panel   __pnlSection        = this.CreatePanel(0, true);
            QXPWUIBasic.Panel   __pnlGroup          = this.CreatePanel(1, true);
            QXPWUIBasic.Panel   __pnlClef           = this.CreatePanel(0, true);
            QXPWUIBasic.Panel   __pnlClefInfo       = this.CreatePanel(1, true);


            __pnlSection.Title      = "Selectionner une section";
            __pnlGroup.Title        = "Selectionner un groupe";
            __pnlClef.Title         = "Selectionner une clef";
			__pnlClefInfo.Title     = "Info Clef";

            this.Body.Add(__pnlSection);
            this.Body.Add(__pnlGroup);
            this.Body.Add(__pnlClef);
            this.Body.Add(__pnlClefInfo);

			_list_rs							= this.CreationListRS();

			_rechercheGroup						= this.CreationRechercheGroup();
			_rechercheGroup.Recherche			+= this.GetBasicHandler(new BasicHandler(this.RechercheGroupClick));
			
			_rechercheKey						= this.CreationRechercheKey();
			_rechercheKey.Recherche				+= this.GetBasicHandler(new BasicHandler(this.RechercheKeyClick));

			_list_rg							= this.CreationListRG();
			
			_list_rk							= new QXPWUIComposite.DropDownList();
			_list_rk.SelectedIndexChanged		+= this.GetEventHandler(new EventHandler(this.SelectedKeyChanged));
			_list_rk.AutoCallBack				= true;
			_list_rk.EmptyText					= "selectionner une clef";
			_list_rk.EnableEmptySelection		= true;
			_list_rk.IsSorted					= true;
			_list_rk.Label						= "Clef";

			_code								= new QXPWUIComposite.TextBox();
			_code.IsRequired					= true;
			_code.CssClass						= "rk";
			_code.Label							= "Clef";

			_commentaire						= new QXPWUIComposite.TextBox();
			_commentaire.IsRequired				= true;
			_commentaire.IsMultiLineText		= true;
			//_commentaire.MaxLength				= 100; //Helas ne fonctionne pas pour les Controls Multi-lignes.
			_commentaire.Rows					= 5;
			_commentaire.CssClass				= "rk_comment";
			_commentaire.Label					= "Commentaire";

			_valider							= new QXPWUIBasic.Button();
            _valider.CssClass                   = "bouton";
			_valider.Text						= "Valider";
			_valider.Click						+= this.GetEventHandler(new EventHandler(this.ValiderClick));

			_supprimer							= new QXPWUIBasic.Button();
			_supprimer.CausesValidation			= false;
			_supprimer.Enabled					= false;
			_supprimer.Text						= "Supprimer";
			_supprimer.Click					+= this.GetEventHandler(new EventHandler(this.SupprimerClick));

			__pnlSection.Body.Add(_list_rs);
			__pnlGroup.Body.Add(_rechercheGroup);
			__pnlGroup.Body.Add(_list_rg);
			__pnlClef.Body.Add(_rechercheKey);
			__pnlClef.Body.Add(_list_rk);
			__pnlClefInfo.Body.Add(_code);
			__pnlClefInfo.Body.Add(_commentaire);
			
            _list_rk.AddToZoneValidator(_supprimer);

			this.AddToZoneButton(_valider);
			//this.Footer.Add(_supprimer);

		}
		private		void				ComponentDataBind()
		{
			this.BindListRS(false);
			/*this.BindListRG(false);*/
		}
		private		void				OnComponentPrerender()
		{
			int		__id		= Conversion.ToInt(_list_rk.Data);
			bool	__enabled	= (!_list_rk.IsEmptySelected && __id != 0 && Validation.IsSet(__id)); 
			_supprimer.Enabled              = __enabled;
            _supprimer.UpdateAfterCallBack  = true;
			//_supprimer.Text = "supprimer changer";
		}
		#region Events
		protected override		void			SelectedRSChanged(object sender, EventArgs ea)
		{
			//this.ResetListRG();
			this.ResetListRK();
			this.ResetRecherche();
            this.ResetRK();
			base.SelectedRSChanged(sender, ea);
//			//this.InfoMessage = "Selected section changed ! ";
//			this.ResetListRG();
//			this.ResetListRK();
//			this.BindListRG(true);
		}
		protected override		void			SelectedRGChanged(object sender, EventArgs ea)
		{
			this.ResetRecherche();
            this.ResetRK();
			this.InternalBindListRK(true);
		}
//		private		void			SelectedGroupChanged(object sender, EventArgs ea)
//		{
//			//this.InfoMessage = "Selected section changed ! ";
//			this.BindListRK(true);
//		}
		private		void			SelectedKeyChanged(object sender, EventArgs ea)
		{
			//this.InfoMessage = "Selected section changed ! ";
			this.LoadRK();
		}
		private		void			ValiderClick(object sender, EventArgs ea)
		{
			this.SaveRK();
		}
		private		void			SupprimerClick(object sender, EventArgs ea)
		{
			this.DeleteRK();
		}
		private void				RechercheGroupClick(){
			//this.InfoMessage = "Recherche click";
			_list_rs.Data			            = null;
            _list_rs.UpdateAfterCallBack        = true;
			_rechercheKey.Value		            = null;
            _rechercheKey.UpdateAfterCallBack   = true;
			this.BindListRG_By_Name(true);
		}
		private void				RechercheKeyClick()
		{
			//this.InfoMessage = "Recherche click";
			_list_rs.Data			            = null;
            _list_rs.UpdateAfterCallBack        = true;
			_list_rg.Data			            = null;
            _list_rg.UpdateAfterCallBack        = true;
			_rechercheGroup.Value	            = null;
            _rechercheGroup.UpdateAfterCallBack = true;
			this.BindListRK_By_Name(true);
		}
		#endregion
		#region DataBinding
//		private		void			BindListRS(bool withBinding)
//		{
//			_list_rs.DataSource		= this.GetListRS();
//			_rechercheGroup.Value	= null;
//			if(withBinding) _list_rs.DataBind();
//		}
//		private		void			BindListRG(bool withBinding)
//		{
//			_list_rg.DataSource = this.GetListRG();
//			if(withBinding) _list_rg.DataBind();
//		}
		private		void				BindListRG_By_Name(bool withBinding)
		{
			_list_rg.DataSource             = this.GetListRG_By_Name(_rechercheGroup);
			_list_rg.UpdateAfterCallBack    = true;
            if(withBinding) _list_rg.DataBind();
		}
		private		void				BindListRK_By_Name(bool withBinding)
		{
			_list_rk.DataSource             = this.GetListRK_By_Name(_rechercheKey);
            _list_rk.UpdateAfterCallBack    = true;
			if(withBinding) _list_rk.DataBind();
		}
		private		void				InternalBindListRK(bool withBinding)
		{
			_list_rk.DataSource             = this.GetListRK(_list_rg);
            _list_rk.UpdateAfterCallBack    = true;
			if(withBinding) _list_rk.DataBind();
		}
		protected override Hashtable	GetListRK(QXP.Framework.Web.UI.Controls.Composite.DropDownList control)
		{
			Hashtable	__data = base.GetListRK (control);
			int			__id_rg = Conversion.ToInt(_list_rg.Data);
			if(Validation.IsSet(__id_rg)) __data.Add(NewKeyValue, " [Nouvelle Clef]");
			return __data;
		}

//		private		Hashtable		GetListRS()
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable					__list_rs;
//			__list_rs = __proxy.GetAllRS();
//			//INFO: add new section Item
//			__list_rs.Add("0", " Toutes les sections");
//			return __list_rs;
//		}
//		private		Hashtable		GetListRG()
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable					__list_rg;
//			int							__rs = Conversion.ToInt(_list_rs.Data);
//			if(_list_rs.IsEmptySelected || Validation.IsNotSet(__rs))
//			{
//				__list_rg =  new Hashtable();
//			}
//			else{
//				__list_rg = __proxy.GetRG_By_Section(__rs);
//			}
//			return __list_rg;
//		}
//		private		Hashtable		GetListRG_By_Name()
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable					__list_rg;
//			string						__recherche = _rechercheGroup.Value;
//			if(Validation.IsNotSet(__recherche))
//			{
//				__list_rg =  new Hashtable();
//			}
//			else
//			{
//				__list_rg = __proxy.GetRG_By_Nom(__recherche);
//			}
//			return __list_rg;
//		}
//		private		Hashtable		GetListRK()
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable					__list_rk;
//			int							__rg = Conversion.ToInt(_list_rg.Data);
//			if(_list_rg.IsEmptySelected || Validation.IsNotSet(__rg))
//			{
//				__list_rk =  new Hashtable();
//			}
//			else
//			{
//				__list_rk = __proxy.GetRK_By_Group(__rg);
//			}
//			//INFO: add new key Item
//			__list_rk.Add("0", " Nouvelle Clef");
//			return __list_rk;
//		}
		private		void				ResetListRG()
		{
			_list_rg.DataSource             = null;
            _list_rg.UpdateAfterCallBack    = true;
			_list_rg.DataBind();
		}
		private		void				ResetListRK()
		{
			_list_rk.DataSource                 = null;
            _list_rk.UpdateAfterCallBack        = true;
			_list_rk.DataBind();
		}
		private		void				ResetRK()
		{
			_code.Data			                = null;
			_code.ToolTip		                = null;
            _code.UpdateAfterCallBack           = true;
			_commentaire.Data	                = null;
            _commentaire.UpdateAfterCallBack    = true;
		}
		private		void				ResetRecherche(){
			_rechercheGroup.Value	            = null;
            _rechercheGroup.UpdateAfterCallBack = true;
			_rechercheKey.Value		            = null;
            _rechercheKey.UpdateAfterCallBack   = true;
		}
		private		void				LoadRK()
		{
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			int							__id_rk = Conversion.ToInt(_list_rk.Data);
			if(_list_rk.IsEmptySelected || __id_rk == 0)
			{
				_code.Data				            = null;
				_code.ToolTip			            = null;
                _code.UpdateAfterCallBack           = true;
				_commentaire.Data		            = null;
                _commentaire.UpdateAfterCallBack    = true;
			}
			else
			{
				QXPResources.Admin.Res_RK	__rk	= __proxy.GetRK(__id_rk);
				_code.Data				            = __rk.Code;
				_code.ToolTip			            = this.GetRK_Markers(__id_rk);
                _code.UpdateAfterCallBack           = true;
				_commentaire.Data		            = __rk.Commentaire;
                _commentaire.UpdateAfterCallBack    = true;
			}
		}
		#endregion
		#region Save/Delete Group
		private void SaveRK()
		{
			try
			{
				int		__id_rg			= Conversion.ToInt(_list_rg.Data);
				int		__id_rk			= Conversion.ToInt(_list_rk.Data);
				string	__code			= Conversion.ToString(_code.Data);
				string	__commentaire	= QXPFrk.StringHelper.StartString(Conversion.ToString(_commentaire.Data), 90); //100 - 10 (pour les 3 . et pour les eventuelles apostrophes) ex toto...
				if(_list_rk.IsEmptySelected) return;
				//INFO la clef 0 represente une nouvelle clef mais la base de donn�e test valeur nul cad int.minvalue
				if(__id_rk == 0 ) __id_rk = int.MinValue; 
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				if(__proxy.SaveRK_And_Asso(__id_rk, __code, __commentaire, __id_rg))
				{
					this.InfoMessage = "Sauvegarde effectu�e !";
					this.InternalBindListRK(true);
					this.ResetRK();
				}
				else
				{
					this.ErrorMessage = "Cette clef existe d�j� !";	//Pour plus tard actuellement les doublons dans les clefs sont autoris�s !!			
				}
			}
			catch(Exception ex){
				this.ErrorMessage = "Erreur de sauvegarde !";
				QXPDiagnostic.Log.LogError("Update_RK.SaveRK", ex);
			}
		}
		private void DeleteRK(){
			try
			{
				int		__id_rk			= Conversion.ToInt(_list_rk.Data);
				//INFO la clef 0 represente une nouvelle section mais la base de donn�e test valeur nul cad int.minvalue
				if(__id_rk == 0 )
				{
					this.ErrorMessage = "impossible de supprimer une nouveau clef";
					return;
				}
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				if(__proxy.DeleteRK(__id_rk))
				{
					this.InfoMessage = "Suppression effectu�e !";
					this.InternalBindListRK(true);
					this.ResetRK();
				}
				else
				{
					this.ErrorMessage = "Impossible de supprimer cette clef !";				
				}
			}
			catch(Exception ex)
			{
				this.ErrorMessage = "Erreur de suppression !";
				QXPDiagnostic.Log.LogError("Update_RK.DeleteRK", ex);
			}			
		}
		#endregion
	}
}
