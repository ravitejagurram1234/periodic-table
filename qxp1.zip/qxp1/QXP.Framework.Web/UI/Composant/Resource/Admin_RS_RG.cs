using System;
using System.Collections;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPFrk					= QXP.Framework;
using QXPApplication			= QXP.Framework.Application;
using QXPDiagnostic				= QXP.Framework.Diagnostic;
using QXPIO						= QXP.Framework.IO;
using QXPProxy					= QXP.Framework.Proxy;
using QXPWUIControls			= QXP.Framework.Web.UI.Controls;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIComposite			= QXP.Framework.Web.UI.Controls.Composite;
using QXPWUIExtended			= QXP.Framework.Web.UI.Controls.Extended;
using QXPWUIList				= QXP.Framework.Web.UI.Controls.List;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;
using QXPWUIHtml				= QXP.Framework.Web.UI.Controls.Html;
using QXPSecurity				= QXP.Framework.Security;
using QXPFrkWebUser				= QXP.Framework.Web.User;

using QXPResources				= QXP.Framework.Resources;

namespace QXP.Framework.Web.UI.Component.Admin
{
	public class Update_RS_RG: Composant_Admin_Ressource
	{
		#region internal variables
		QXPWUIComposite.DropDownList		_list_rs;
		QXPWUIComposite.ListBox				_list_rg;
		QXPWUIComposite.DropDownList		_list_new_rs;
		QXPWUIComposite.ListBox				_list_new_rg;
		TextRecherche						_rechercheGroup;
		QXPWUIBasic.Button					_supprimer;
		QXPWUIBasic.Button					_ajouter;
		QXPWUIBasic.TableSection			_tableSection;
		//const	int				UngroupedRGValue		= int.MinValue;
		#endregion
		public		Update_RS_RG()
		{
			this.ComponentInit		+= new QXPFrk.BasicHandler(this.CreateConstituantControls);
			this.ComponentBind		+= new BasicHandler(this.ComponentDataBind);
			this.ComponentPrerender	+= new BasicHandler(this.OnComponentPrerender);
		}
		private		void			CreateConstituantControls()
		{
			this.Title							= ":: Traductions Statiques - Mise a jour Liaison Section-Groupe";
			this.CssClass						= "Update_RS_RG";

            QXPWUIBasic.Panel   __pnlAll        = this.CreatePanel(0, false);

            this.Body.Add(__pnlAll);

			_tableSection						= new QXPWUIBasic.TableSection(2, 6);
			
			_list_rs							= this.CreationListRS();
//			_list_rs.SelectedIndexChanged		+= this.GetEventHandler(new EventHandler(this.SelectedSectionChanged));
//			_list_rs.CssClass					= "list_rs";
//			_list_rs.AutoPostBack				= true;
//			_list_rs.EmptyText					= "selectionner une section";
//			_list_rs.EnableEmptySelection		= true;
//			_list_rs.IsSorted					= true;
			//_list_rs.Label						= "Sections";

			_list_rg							= new QXPWUIComposite.ListBox(ValueType.ArrayOfInt); 
			_list_rg.EnableMultiSelection		= true;
			_list_rg.CssClass					= "list_rg";
			_list_rg.IsSorted					= true;
			_list_rg.Rows						= 8;
			//_list_rg.Label						= "Groupe";

			_list_new_rs						= this.CreationListNewRS();
//			_list_new_rs.SelectedIndexChanged	+= this.GetEventHandler(new EventHandler(this.SelectedNewSectionChanged));
//			_list_new_rs.CssClass				= "list_new_rs";
//			_list_new_rs.AutoPostBack			= true;
//			_list_new_rs.EmptyText				= "selectionner une section";
//			_list_new_rs.EnableEmptySelection	= true;
//			_list_new_rs.IsSorted				= true;
			//_list_new_rs.Label					= "Filtre Sections";

			_rechercheGroup						= this.CreationRechercheGroup();
			_rechercheGroup.Recherche			+= this.GetBasicHandler(new BasicHandler(this.RechercheClick));

			_list_new_rg						= new QXPWUIComposite.ListBox(ValueType.ArrayOfInt); 
			_list_new_rg.EnableMultiSelection	= true;
			_list_new_rg.CssClass				= "list_new_rg";
			_list_new_rg.IsSorted				= true;
			_list_new_rg.Rows					= 8;
			//_list_new_rg.Label					= "Nouveau Groupe";

			_ajouter							= new QXPWUIBasic.Button();
			_ajouter.Text						= "Ajouter le(s) groupe(s) selectionn�(s)";
			_ajouter.Click						+= this.GetEventHandler(new EventHandler(this.AjouterClick));

			_supprimer							= new QXPWUIBasic.Button();
			_supprimer.CausesValidation			= false;
			_supprimer.Text						= "Supprimer le(s) groupe(s) selectionn�(s)";
			_supprimer.Click					+= this.GetEventHandler(new EventHandler(this.SupprimerClick));

			_tableSection.CssClass				= "table_rs_rg";
			_tableSection[0,0].CssClass			= "col_rs_rg";
			_tableSection[0,1].CssClass			= "col_new_rs_rg";
			//this.Body.Add(this.CreationHeaderGroup("Selectionner une section"));
			__pnlAll.Body.Add(_tableSection);

			_tableSection[0,0].Add(this.CreationHeaderGroup("Section-Groupes associ�s"));
			_tableSection[0,1].Add(this.CreationHeaderGroup("Section-Groupes disponibles"));

			_tableSection[1,0].Add("Section � modifier");
			_tableSection[1,1].Add("Section � selectionner");
			_tableSection[2,0].Add(_list_rs);
			_tableSection[2,1].Add(_list_new_rs);
			
			_tableSection[3,0].Add("Association de groupe � modifier");
			_tableSection[3,1].Add("Association de groupe � utiliser");
			_tableSection[4,0].Add(_list_rg);
			_tableSection[4,1].Add(_rechercheGroup);
			_tableSection[4,1].Add(_list_new_rg);

			//this.Body.Add(this.CreationHeaderGroup("Info section"));
			_tableSection[5,0].Add(_supprimer);
			_tableSection[5,1].Add(_ajouter);
		}
		private		void			ComponentDataBind()
		{
			this.BindListRS(false);
			this.BindListNewRS(false);
		}
		private		void			OnComponentPrerender()
		{
			int		__id_sup		    = Conversion.ToInt(_list_rs.Data);
			int		__id_add		    = Conversion.ToInt(_list_new_rs.Data);
			bool	__enabledSupprimer	= (!_list_rs.IsEmptySelected && __id_sup != 0); 
			bool	__enabledAjouter	= (!_list_new_rs.IsEmptySelected && __id_add != 0); 
			_supprimer.Enabled              = __enabledSupprimer;
            _supprimer.UpdateAfterCallBack  = true;
			_ajouter.Enabled                = __enabledAjouter;
            _ajouter.UpdateAfterCallBack    = true;
			//_supprimer.Text = "supprimer changer";
		}
		#region Events
//		private		void			SelectedSectionChanged(object sender, EventArgs ea)
//		{
//			this.BindListRG(true);
//		}
//		private		void			SelectedNewSectionChanged(object sender, EventArgs ea)
//		{
//			//this.InfoMessage = "Selected section changed ! ";
//			//this.LoadSection();
//			this.BindListNewRG(true);
//		}
		private		void			AjouterClick(object sender, EventArgs ea)
		{
			this.AddRG();
		}
		private		void			SupprimerClick(object sender, EventArgs ea)
		{
			this.RemoveRG();
		}
		private void				RechercheClick()
		{
			//this.InfoMessage = "Recherche click";
			this.BindListNewRG_By_Name(true);
		}
		#endregion
		#region DataBinding
		protected override	void		BindListRG(bool withBinding)
		{
			_list_rg.DataSource                 = this.GetListRG(_list_rs, false);
            _list_rg.UpdateAfterCallBack        = true;
			if(withBinding) _list_rg.DataBind();
		}
		protected override	void		BindListNewRG(bool withBinding)
		{
			_list_new_rg.DataSource             = this.GetListRG(_list_new_rs, false);
            _list_new_rg.UpdateAfterCallBack    = true;
			if(withBinding) _list_new_rg.DataBind();
			_rechercheGroup.Value               = null;
            _rechercheGroup.UpdateAfterCallBack = true;
		}
		private void					BindListNewRG_By_Name(bool withBinding)
		{
			//this.InfoMessage = "Recherche click";
			_list_new_rg.DataSource             = this.GetListRG_By_Name(_rechercheGroup);
            _list_new_rg.UpdateAfterCallBack    = true;
			if(withBinding) _list_new_rg.DataBind();
		}
//		private		void			BindListRS(bool withBinding)
//		{
//			_list_rs.DataSource = this.GetListRS(false);
//			if(withBinding) _list_rs.DataBind();
//		}
//		private		void			BindListNewRS(bool withBinding)
//		{
//			_list_new_rs.DataSource = this.GetListRS(true);
//			if(withBinding) _list_new_rs.DataBind();
//		}
//		private		void			BindListRG(bool withBinding)
//		{
//			_list_rg.DataSource = this.GetListRG(_list_rs);
//			if(withBinding) _list_rg.DataBind();
//		}
//		private		void			BindListNewRG(bool withBinding)
//		{
//			_list_new_rg.DataSource = this.GetListRG(_list_new_rs);
//			if(withBinding) _list_new_rg.DataBind();
//		}
//		private		Hashtable		GetListRS(bool addUngroupedKey)
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable					__rs;
//			__rs	= __proxy.GetAllRS();
//			if(addUngroupedKey) __rs.Add(UngroupedRGValue, " [Groupes non associ�s]");
//			return __rs;
//		}
//		private		Hashtable		GetListRG(QXPWUIComposite.DropDownList control)
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable		__rg;
//			int				__rs = Conversion.ToInt(control.Data);
//			if(control.IsEmptySelected)
//			{
//				__rg = new Hashtable();
//			}
//			else
//			{
//				__rg	= __proxy.GetRG_Asso_RS(__rs);
//			}
//			return __rg;
//		}
		#endregion
		#region Save/Delete Section
		private void RemoveRG()
		{
			try
			{
				int		__id_rs			= Conversion.ToInt(_list_rs.Data);
				int[]	__list_id_rg	= Conversion.ToIntArray(_list_rg.Data);
				if(Validation.IsNotSet(__list_id_rg)) return;
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				__proxy.Remove_Asso_RS_RG(__id_rs, __list_id_rg);
				this.InfoMessage = "Suppression effectu�e !";
				this.BindListRG(true);
//				if(__id_rs == 0){
//					this.BindListNewRG(true);			
//				}
			}
			catch(Exception ex){
				this.ErrorMessage = "Erreur de Suppression !";
				QXPDiagnostic.Log.LogError("Update_RS_RG.RemoveRG", ex);
			}
		}
		private void AddRG(){
			try
			{
				int		__id_rs			= Conversion.ToInt(_list_rs.Data);
				int[]	__list_id_rg	= Conversion.ToIntArray(_list_new_rg.Data);
				if(Validation.IsNotSet(__list_id_rg) || _list_rs.IsEmptySelected) return;
				QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
				__proxy.Insert_Asso_RS_RG(__id_rs, __list_id_rg);
				this.InfoMessage = "Ajout effectu�e !";
				this.BindListRG(true);
			}
			catch(Exception ex)
			{
				this.ErrorMessage = "Erreur d'ajout !";
				QXPDiagnostic.Log.LogError("Update_RS_RG.AddRG", ex);
			}

		}
		#endregion
	}
}
