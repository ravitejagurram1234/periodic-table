using System;
using System.Collections;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPFrk					= QXP.Framework;
using QXPApplication			= QXP.Framework.Application;
using QXPDiagnostic				= QXP.Framework.Diagnostic;
using QXPIO						= QXP.Framework.IO;
using QXPProxy					= QXP.Framework.Proxy;
using QXPWUIControls			= QXP.Framework.Web.UI.Controls;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIComposite			= QXP.Framework.Web.UI.Controls.Composite;
using QXPWUIExtended			= QXP.Framework.Web.UI.Controls.Extended;
using QXPWUIList				= QXP.Framework.Web.UI.Controls.List;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;
using QXPWUIHtml				= QXP.Framework.Web.UI.Controls.Html;
using QXPSecurity				= QXP.Framework.Security;
using QXPFrkWebUser				= QXP.Framework.Web.User;

using QXPResources				= QXP.Framework.Resources;

namespace QXP.Framework.Web.UI.Component.Admin
{
	public class Update_RK_Trad: Composant_Admin_Ressource
	{
		#region internal variables
		QXPWUIComposite.DropDownList		_rs;
		QXPWUIComposite.DropDownList		_rg;
		QXPWUIComposite.ListBox				_list_rk;
		TextRecherche						_rechercheGroup;
		TextRecherche						_rechercheKey;
		TextRecherche						_rechercheTrad;
		QXPWUIComposite.Label				_commentaire;
		QXPWUIBasic.Button					_valider;
		ArrayList							_controls = new ArrayList();

        QXPWUIBasic.Panel                   _pnlTrad;

		const string			VSLanguesKey	= "VSLangues";
		const	int				AllRGValue		= 0;
		#endregion
		public		Update_RK_Trad()
		{
			this.ComponentInit		+= new QXPFrk.BasicHandler(this.CreateConstituantControls);
			this.ComponentLoad		+= new QXPFrk.BasicHandler(this.OnComponentLoad);
			this.ComponentBind		+= new BasicHandler(this.ComponentDataBind);
			this.ComponentPrerender	+= new BasicHandler(this.OnComponentPrerender);
		}
		private		void			CreateConstituantControls()
		{
			this.Title						= ":: Traductions Statiques - Mise a jour Traduction";
			this.CssClass					= "Update_RK_Trad";

            QXPWUIBasic.Panel   __pnlSection        = this.CreatePanel(0, true);
            QXPWUIBasic.Panel   __pnlGroup          = this.CreatePanel(1, true);
            QXPWUIBasic.Panel   __pnlClef           = this.CreatePanel(0, true);
            _pnlTrad           = this.CreatePanel(1, true);

            __pnlSection.Title      = "Selectionner une section";
            __pnlGroup.Title        = "Selectionner un groupe";
            __pnlClef.Title         = "Selectionner une clef";
			_pnlTrad.Title         = "Traduction";

            this.Body.Add(__pnlSection);
            this.Body.Add(__pnlGroup);
            this.Body.Add(__pnlClef);
            this.Body.Add(_pnlTrad);


			_rs								= this.CreationListRS();

			_rg								= this.CreationListRG(); new QXPWUIComposite.DropDownList(ValueType.CLSint32);

			_rechercheGroup					= this.CreationRechercheGroup();
			_rechercheGroup.Recherche		+= this.GetBasicHandler(new BasicHandler(this.RechercheGroupClick));
			
			_rechercheKey					= this.CreationRechercheKey();
			_rechercheKey.Recherche			+= this.GetBasicHandler(new BasicHandler(this.RechercheKeyClick));

			_rechercheTrad					= this.CreationRechercheTrad();
			_rechercheTrad.Recherche		+= this.GetBasicHandler(new BasicHandler(this.RechercheTradClick));

            _list_rk						= new QXPWUIComposite.ListBox(ValueType.CLSint32);
			_list_rk.SelectedIndexChanged	+= this.GetEventHandler(new EventHandler(this.SelectedRKChanged));
			_list_rk.AutoCallBack			= true;
			_list_rk.MaxTextLength			= 100;
			_list_rk.IsSorted				= true;
			_list_rk.Rows					= 8;
			_list_rk.Label					= "Clef";

			_commentaire					= new QXPWUIComposite.Label();
			_commentaire.CssClass			= "rk_comment";
			_commentaire.Label				= "Commentaire";

			_valider						= new QXPWUIBasic.Button();
			_valider.Text					= "Valider";
			_valider.Click					+= this.GetEventHandler(new EventHandler(this.ValiderClick));

			_valider						= new QXPWUIBasic.Button();
            _valider.CssClass               = "bouton";
			_valider.Text					= "Valider";
			_valider.Click					+= this.GetEventHandler(new EventHandler(this.ValiderClick));

			QXPWUIBasic.Button __unload = new QXPWUIBasic.Button();
            __unload.CssClass   = "bouton";
			__unload.Click		+= this.GetEventHandler(new EventHandler(this.UnloadClick));
			__unload.Text		= "vider le cache des ressources";
			__unload.ToolTip	= "Permet de d�charger toutes les ressources du cache m�moire (rechargement au premier appel)";

            QXPWUIBasic.TableSection    __tableRK = new QXPWUIBasic.TableSection(2,1);
            __tableRK[0,0].CssClass = "rk_list";
            __tableRK[0,1].CssClass = "rk_comment";

			__pnlSection.Body.Add(_rs);
			__pnlGroup.Body.Add(_rechercheGroup);
			__pnlGroup.Body.Add(_rg);
			__pnlClef.Body.Add(_rechercheKey);
			__pnlClef.Body.Add(_rechercheTrad);
            __pnlClef.Body.Add(__tableRK);

			__tableRK[0,0].Add(_list_rk);
			__tableRK[0,1].Add(_commentaire);

            this.AddToZoneButton(_valider);
            this.AddToZoneButton(__unload);
            //this.Footer.Add(_valider, QXPWUIControls.Separator.Space, QXPWUIControls.RelativePosition.Post, 3);
            //this.Footer.Add(__unload);
			//this.CreationControlsTraduction();

		}
		private		void			CreationControlsTraduction(){
			ArrayList __langues = new ArrayList();
			if(!this.Page.IsPostBack)
			{
				QXPResources.ResourcesProxy __proxy			= new QXPResources.ResourcesProxy();
				Hashtable					__list_langues	= __proxy.GetListeLangue();
				foreach(DictionaryEntry __langue in __list_langues)
				{
					int		__id	= Conversion.ToInt(__langue.Key);
					string __code	= Conversion.ToString(__langue.Value);
					string __value	= string.Format("{0}:{1}", __id, __code);
					__langues.Add(__value);
				}
				string __result = string.Join(";", (string[])__langues.ToArray(ValueType.CLSstring));
				this.ViewState[VSLanguesKey] = __result;
			}
			else{
				string __result = Conversion.ToString(this.ViewState[VSLanguesKey]);
				__langues = new ArrayList(__result.Split(';'));
			}
			foreach(string __langue in __langues){
				string[]	__info	= __langue.Split(':');
				int			__id	= Conversion.ToInt(__info[0]);
				string		__code	= __info[1];
				QXPWUIComposite.TextBox __ctrl = new QXPWUIComposite.TextBox(ValueType.CLSstring, __code);
				__ctrl.CssClass			= "rk_trad";
				__ctrl.Tag				= __id;
				__ctrl.IsMultiLineText	= true;
				__ctrl.Columns			= 150;
				__ctrl.Rows				= 4;
				_controls.Add(__ctrl);
				_pnlTrad.Body.Add(__ctrl);
			}

		}
		private		void			OnComponentLoad()
		{
			this.CreationControlsTraduction();
		}
		private		void			ComponentDataBind()
		{
			this.BindListRS(false);
			this.BindListRG(false);
		}
		private		void			OnComponentPrerender()
		{
			//_list_rk.Visible = (_list_rk.ItemsCount > 0);
		}
		#region Events
		protected override		void		SelectedRSChanged(object sender, EventArgs ea)
		{
			//this.InfoMessage = "Selected section changed ! ";
			base.BindListRG(true);
			this.ResetListRK();
            this.ResetRK();
		}
		protected override		void		SelectedRGChanged(object sender, EventArgs ea)
		{
			//this.InfoMessage = "Selected section changed ! ";
			this.InternalBindListRK(true);
			this.ResetRK();
		}
		private		void			SelectedRKChanged(object sender, EventArgs ea)
		{
			this.BindRK();
		}
		private		void			ValiderClick(object sender, EventArgs ea)
		{
			this.SaveTrads();
		}
		private void				RechercheGroupClick()
		{
			_rs.Data                = null;
            _rs.UpdateAfterCallBack = true;
			this.BindListRG_By_Name(true);
		}
		private void				RechercheKeyClick()
		{
			_rs.Data                = null;
            _rs.UpdateAfterCallBack = true;
			_rg.Data                = null;
            _rg.UpdateAfterCallBack = true;
			this.BindListRK_By_Name(true);
			this.BindRK();
		}
		private void				RechercheTradClick()
		{
			_rs.Data                = null;
            _rs.UpdateAfterCallBack = true;
			_rg.Data                = null;
            _rg.UpdateAfterCallBack = true;
			this.BindListRK_By_Trad(true);
		}
		private void UnloadClick(object sender, EventArgs ea)
		{
			//
			QXPApplication.Application.Resources.Reset();
			this.InfoMessage = "Cache d�charg� !";
		}
		#endregion
		#region DataBinding
//		private		void			BindListRS(bool withBinding)
//		{
//			_rs.DataSource = this.GetListRS();
//			if(withBinding) _rs.DataBind();
//		}
//		private		void			BindListRG(bool withBinding)
//		{
//			_rg.DataSource = this.GetListRG();
//			if(withBinding) _rg.DataBind();
//		}
		private		void			InternalBindListRK(bool withBinding)
		{
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			int							__id_rs =  Conversion.ToInt(_rs.Data);
			int							__id_rg;
			__id_rg	= Conversion.ToInt(_rg.Data);
			_list_rk.DataSource             = this.GetListRK(__id_rs, __id_rg);
            _list_rk.UpdateAfterCallBack    = true;
			
			if(withBinding) _list_rk.DataBind();
		}
		private		void			BindListRG_By_Name(bool withBinding)
		{
			_rg.DataSource              = this.GetListRG_By_Name(_rechercheGroup);
            _rg.UpdateAfterCallBack     = true;
			if(withBinding) _rg.DataBind();
		}
		private		void			BindListRK_By_Name(bool withBinding)
		{
			_list_rk.DataSource             = this.GetListRK_By_Name(_rechercheKey);
            _list_rk.UpdateAfterCallBack    = true;
			if(withBinding) _list_rk.DataBind();
		}
		private		void			BindListRK_By_Trad(bool withBinding)
		{
			_list_rk.DataSource             = this.GetListRK_By_Trad(_rechercheTrad);
            _list_rk.UpdateAfterCallBack    = true;
			if(withBinding) _list_rk.DataBind();
		}
		private		void			BindRK()
		{
			int __idrk = QXPFrk.Conversion.ToInt(_list_rk.Data);
			if(Validation.IsSet(__idrk))
			{
				QXPResources.ResourcesProxy		__proxy = new QXPResources.ResourcesProxy();
				QXPResources.Admin.Res_RK		__rk	= __proxy.GetRK_Trads(__idrk);
				_commentaire.Data		            = __rk.Commentaire;
				_commentaire.ToolTip	            = this.GetRK_Markers(__idrk);
                _commentaire.UpdateAfterCallBack    = true;

				foreach(QXPWUIComposite.TextBox __textBox in _controls){
					string __value = null;
					if(__rk.Trads.ContainsKey(__textBox.Tag))
					{
						QXPResources.Admin.Res_RK_Trad __trad = __rk.Trads[__textBox.Tag] as QXPResources.Admin.Res_RK_Trad;
						__value = __trad.Value;
					}
					__textBox.Data                  = __value;
                    __textBox.UpdateAfterCallBack   = true;
				}
			}
			else
			{
				this.ResetRK();
			}
		}
		private		void			ResetListRG(){
			_rg.DataSource          = null;
            _rg.UpdateAfterCallBack = true;
			_rg.DataBind();
		}
		private		void			ResetListRK()
		{
			_list_rk.DataSource             = null;
            _list_rk.UpdateAfterCallBack    = true;
			_list_rk.DataBind();
		}
//		private		Hashtable		GetListRS()
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable					__rs;
//			__rs				= __proxy.GetAllRS();
//			return __rs;
//		}
//		private		Hashtable		GetListRG()
//		{
//			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
//			Hashtable					__rg;
//			int							__id_section;
//			__id_section = Conversion.ToInt(_rs.Data);
//			if(_rs.IsEmptySelected) __id_section = int.MinValue;
//
//			if(Validation.IsNotSet(__id_section))
//			{
//				__rg = new Hashtable();
//			}
//			else
//			{
//				__rg				= __proxy.GetRG_By_Section(__id_section);
//				//INFO: add all groupe !!
//				if(__rg.Count > 1)	__rg.Add(AllRGValue, " [Tous les groupes]");
//			}
//			return __rg;
//		}
		private		Hashtable		GetListRK(int id_section, int id_groupe){
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			Hashtable					__list_rk;
			if(Validation.IsNotSet(id_groupe))
			{
				__list_rk = new Hashtable();
			}
			else
			{
				if(Validation.IsSet(id_section) && id_groupe == 0)
				{
					__list_rk = __proxy.GetRK_By_Section_Group(id_section, int.MinValue);
				}
				else
				{
					__list_rk = __proxy.GetRK_By_Group(id_groupe);
				}
			}
			//if(Validation.IsNotSet(id_section) && Validation.IsNotSet(id_groupe))
			
			return __list_rk;
		}
		private		QXPResources.Admin.Res_RK_Trad GetRK_Trad{
			get{return null;}
		}
		private		void			ResetRK(){
			_commentaire.Data	                = null;
            _commentaire.ToolTip                = string.Empty;
            _commentaire.UpdateAfterCallBack    = true;
			this.ResetTraduction();
		}
		private		void			ResetTraduction(){
			foreach(QXPWUIComposite.TextBox __textBox in _controls){
				__textBox.Data                  = null;
                __textBox.UpdateAfterCallBack   = true;
			}
		}
		#endregion
		#region Save Trad
		private void SaveTrads(){
			try
			{
				int		__id_rk			= Conversion.ToInt(_list_rk.Data);
				if(Validation.IsNotSet(__id_rk)) return;
				foreach(QXPWUIComposite.TextBox __textBox in _controls)
				{
					int		__id_langue		= Conversion.ToInt(__textBox.Tag);
					string	__value			= Conversion.ToString(__textBox.Data);
					this.SaveTrad(__id_rk, __id_langue, __value);

				}
				this.InfoMessage = "Sauvegarde effectu�e !";
			}
			catch(Exception ex){
				this.ErrorMessage = "Erreur de sauvegarde !";
				QXPDiagnostic.Log.LogError("Update_RK_Trad.SaveTrads", ex);
			}
		}
		private void	SaveTrad(int id_rk, int id_langue, string value){
			QXPResources.ResourcesProxy __proxy = new QXPResources.ResourcesProxy();
			__proxy.SaveTrad(id_rk, id_langue, value);
		}
		#endregion
	}
}
