using System;

namespace QXP.Framework.Web.UI.Controls.Helpers
{
    /// <summary>
    /// Helper g�n�rique permettant la cr�ation de controles 
    /// </summary>
    public class ControlFactory<T> where T:System.Web.UI.Control
    {
        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <returns>Le Control de Type T</returns>
        public static T Create()
        {
            //Rien pour le moment, m�thode appel�e par toutes les Factory
            return Activator.CreateInstance<T>();
        }
        
        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <param name="isVisible">D�finit la visibilit� du Control</param>
        /// <returns>Le Control de Type T</returns>
        public static T Create(bool isVisible)
        {
            return SetIsVisible(Create(), isVisible);
        }   

        #region Set Methodes 
        
        /// <summary>
        /// Affecte une valeur � la propri�t� Visible du Control
        /// </summary>
        /// <param name="control">Control</param>
        /// <param name="isVisible">Valeur de la propri�t� Visible</param>
        /// <returns>Control</returns>
        internal static T SetIsVisible(T control, bool isVisible)
        {
            control.Visible = isVisible;
            return control;
        }

        #endregion Set Methodes 
                    
    }

    public partial class ControlFactory
    {
        /// <summary>
        /// Helper g�n�rique permettant la cr�ation de controles 
        /// </summary>
        public class Control<T> : ControlFactory<T> where T : System.Web.UI.Control
        {
        }

    }
}
