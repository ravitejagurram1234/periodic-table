using System;
using System.Collections.Generic;
using System.Text;
using Basic = QXP.Framework.Web.UI.Controls.Basic;
using QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Helpers
{

    /// <summary>
	/// Helper permettant la cr�ation de controles web anthem de type ListBox/ou dropdownlist
	/// </summary>
	public class ListControlFactory<T> : AnthemControlFactory<T> 
		where T : System.Web.UI.WebControls.ListControl,Anthem.IUpdatableControl
	{
		/// <summary>
        /// Cr�ation d'une ListBox Anthem
		/// </summary>
        /// <param name="cssClass">Nom de la classe css</param>
        /// <param name="dataTextField">Field of the data source that provides the text content of the list items.</param>
        /// <param name="dataValueField">Field of the data source that provides the value of each list item.</param>
        /// <returns>ListBox</returns>
		public static T Create(string cssClass, string dataTextField, string dataValueField){
		    return SetAllValues(Create(cssClass), dataTextField, dataValueField);
		}
		#region Set Methodes
		internal static T SetAllValues(T control, string dataTextField, string dataValueField){
		    control.DataTextField	= dataTextField;
		    control.DataValueField	= dataValueField;
			return control;
		}
		#endregion Set Methodes

	}
        
    public partial class ControlFactory
    {
        
		/// <summary>
        /// Helper permettant la cr�ation d'une ListBox Anthem
        /// </summary>
        public class ListBox 
        {
            
            /// <summary>
            /// Fournit un acc�s sur l'ensembles des factory disponibles pour la cr�ation de contr�les
            /// </summary>
            public class Factory : ListControlFactory<Basic.ListBox> {}

            /// <summary>
            /// Permet la cr�ation de ListBox
            /// </summary>
            /// <param name="dataTextField">Field of the data source that provides the text content of the list items.</param>
            /// <param name="dataValueField">Field of the data source that provides the value of each list item.</param>
            /// <param name="rows">Nombre de ligne affich� du listBox</param>
            /// <returns>ListBox</returns>
            public static Basic.ListBox Create(string dataTextField, string dataValueField, int rows)
            {
                return SetAllValues(Factory.Create(null, dataTextField, dataValueField), false, rows, false);
            }

			/// <summary>
			/// Permet la cr�ation de ListBox
			/// </summary>
			/// <param name="cssClass">Nom de la classe css</param>
			/// <param name="isSorted">List tri�e</param>
            /// <param name="dataTextField">Field of the data source that provides the text content of the list items.</param>
            /// <param name="dataValueField">Field of the data source that provides the value of each list item.</param>
			/// <param name="rows">Nombre de ligne affich� du listBox</param>
			/// <param name="enableMultiSelection">multiselection autoris� (par d�faut false)</param>
            /// <returns>ListBox</returns>
			public static Basic.ListBox Create(string cssClass, bool isSorted, string dataTextField, string dataValueField, int rows, bool enableMultiSelection ){
				return SetAllValues(Factory.Create(cssClass, dataTextField, dataValueField), isSorted, rows , enableMultiSelection);
			}

			/// <summary>
            /// Permet la cr�ation de ListBox
			/// </summary>
			/// <param name="cssClass">Nom de la classe css</param>
			/// <param name="isSorted">List tri�e</param>
            /// <param name="dataTextField">Field of the data source that provides the text content of the list items.</param>
            /// <param name="dataValueField">Field of the data source that provides the value of each list item.</param>
			/// <param name="rows">Nombre de ligne affich� du listBox</param>
			/// <param name="enableMultiSelection">multiselection autoris� (par d�faut false)</param>
			/// <param name="autoCallBack">Auto callback lorsqu'un �l�ment est selectionn�. </param>
            /// <returns>ListBox</returns>
			public static Basic.ListBox Create(string cssClass, bool isSorted, string dataTextField, string dataValueField, int rows, bool enableMultiSelection, bool autoCallBack){
				return SetAllValues(Factory.Create(cssClass, dataTextField, dataValueField), isSorted, rows , enableMultiSelection, autoCallBack);
			}

			#region Set Methodes

			internal static Basic.ListBox  SetAllValues(Basic.ListBox listBox, bool isSorted, int rows, bool enableMultiSelection){
				SetIsSorted(listBox, isSorted);
				SetRows(listBox, rows);
				SetMultiSelection(listBox, enableMultiSelection);
				return listBox;
			}
			internal static Basic.ListBox  SetAllValues(Basic.ListBox listBox, bool isSorted, int rows, bool enableMultiSelection, bool autoCallBack){
				SetAllValues(listBox, isSorted, rows, enableMultiSelection);
				SetAutoCallBack(listBox, autoCallBack);
				return listBox;
			}
			internal static Basic.ListBox  SetMultiSelection(Basic.ListBox listBox, bool enableMultiSelection){
				listBox.EnableMultiSelection = enableMultiSelection;
				return listBox;
			}
			internal static Basic.ListBox  SetRows(Basic.ListBox listBox, int rows){
				listBox.Rows = rows;
				return listBox;
			}
			internal static Basic.ListBox  SetIsSorted(Basic.ListBox listBox, bool isSorted){
				listBox.IsSorted = isSorted;
				return listBox;
			}
			internal static Basic.ListBox  SetAutoCallBack(Basic.ListBox listBox, bool autoCallBack){
				listBox.AutoCallBack = autoCallBack;
				return listBox;
			}

			#endregion
		}
	}    
}
    
	