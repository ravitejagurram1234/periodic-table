using System;
using System.Collections.Generic;
using System.Text;
using List = QXP.Framework.Web.UI.Controls.List;
using QXP.Framework.Web.UI.Controls.List;

namespace QXP.Framework.Web.UI.Controls.Helpers
{

    /// <summary>
	/// Helper permettant la cr�ation de controles web anthem de type Repeater
	/// </summary>
	public class RepeaterControlFactory<T>
		where T : System.Web.UI.WebControls.Repeater,Anthem.IUpdatableControl
	{
		/// <summary>
		/// Permet la cr�ation de Repeater
		/// </summary>
        /// <param name="itemTemplate">ItemTemplate du repeater</param>
        /// <param name="args">Liste des arguments � transmettre � l'itemtemplate</param>
		/// <returns>Repeater</returns>
		public static T Create(Type itemTemplate, params object[] args)
        {
			return SetItemTemplate(ControlFactory<T>.Create(), itemTemplate, args);
		}

		/// <summary>
		/// Permet la cr�ation de Repeater
		/// </summary>
        /// <param name="itemTemplate">ItemTemplate du repeater</param>
        /// <param name="separatorTemplate">SeparatorTemplate du repeater</param>
        /// <param name="args">Liste des arguments � transmettre � l'itemtemplate</param>
		/// <returns>Repeater</returns>
		public static T Create(Type itemTemplate, Type separatorTemplate, params object[] args)
        {
			return SetseparatorTemplate(Create(itemTemplate, args), separatorTemplate);
		}

		#region Set Methodes

        /// <summary>
        /// Affecte l'ItemTemplate du Repeater Control
        /// </summary>
        /// <param name="repeaterControl">Repeater</param>
        /// <param name="itemTemplate">ItemTemplate du repeater</param>
        /// <param name="args">Liste des arguments � transmettre � l'itemtemplate</param>
        /// <returns>Repeater</returns>
        internal static T SetItemTemplate(T repeaterControl, Type itemTemplate,  params object[] args)
        {
            repeaterControl.ItemTemplate = new List.Template(itemTemplate, args);
            return repeaterControl;
        }

        /// <summary>
        /// Affecte le SeparatorTemplate du Repeater Control
        /// </summary>
        /// <param name="repeaterControl">Repeater</param>
        /// <param name="separatorTemplate">SeparatorTemplate du repeater</param>
        /// <returns>Repeater</returns>
        internal static T SetseparatorTemplate(T repeaterControl, Type separatorTemplate)
        {
            repeaterControl.SeparatorTemplate = new List.Template(separatorTemplate);
            return repeaterControl;
        }
        #endregion Set Methodes

	}
        
    public partial class ControlFactory
    {
        
		/// <summary>
        /// Permet la cr�ation de Repeater
        /// </summary>
        public class Repeater : RepeaterControlFactory<List.Repeater>
        {
        }
	      
		/// <summary>
        /// Permet la cr�ation de Repeater
        /// </summary>
        public class Repeater<T> : RepeaterControlFactory<T>
            where T : System.Web.UI.WebControls.Repeater,Anthem.IUpdatableControl
        {
        }
	}    
}
    
	