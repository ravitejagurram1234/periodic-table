using System;
using System.Collections.Generic;
using System.Text;
using Basic = QXP.Framework.Web.UI.Controls.Basic;
using QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Helpers
{

    public partial class ControlFactory
    {
        /// <summary>
        /// Permet la cr�ation de Panel
        /// </summary>
        public class Panel//: TableSectionControlFactory<Basic.Panel>
        {
            /// <summary>
            /// Cr�e un Panel   
            /// </summary>
            /// <param name="titre">Titre du panel</param>
            /// <param name="indexBackColor">Index de la couleur du fond</param>
            /// <param name="isVisible">Valeur de la propri�t� Visible</param>
            /// <returns>Panel</returns>
            public static Basic.Panel Create(string titre, int indexBackColor, bool isVisible)
            {
                return SetValues(TableSectionControlFactory<Basic.Panel>.Create(isVisible), titre, indexBackColor);
            }

            /// <summary>
            /// Cr�e un Panel
            /// </summary>
            /// <param name="titre">Titre du panel</param>
            /// <param name="indexBackColor">Index de la couleur du fond</param>
            /// <returns>Panel</returns>
            public static Basic.Panel Create(string titre, int indexBackColor)
            {
                return SetValues(TableSectionControlFactory<Basic.Panel>.Create(), titre, indexBackColor);
            }
            
            /// <summary>
            /// Cr�e un Panel   
            /// </summary>
            /// <param name="titre">Titre du panel</param>
            /// <param name="indexBackColor">Index de la couleur du fond</param>
            /// <returns>Panel</returns>
            public static Basic.Panel Create(Enum titre, int indexBackColor)
            {
                return Create(titre.ToString(), indexBackColor);
            }

            #region Set Methodes

            /// <summary>
            /// Affecte les valeurs des propri�t�s title, et BackColorIndex du Panel
            /// </summary>
            /// <param name="panel">Panel</param>
            /// <param name="title">Titre du panel</param>
            /// <param name="indexBackColor">Index de la couleur du fond</param>
            /// <returns>Panel</returns>
            internal static Basic.Panel SetValues(Basic.Panel panel, string title, int indexBackColor )
            {
                panel.Title             = title;
                panel.BackColorIndex	= indexBackColor;
                return panel;
            }

            #endregion Set Methodes
        }
    }
}
