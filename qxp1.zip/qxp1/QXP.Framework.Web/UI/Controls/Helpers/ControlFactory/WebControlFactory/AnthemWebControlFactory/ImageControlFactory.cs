using System;
using System.Collections.Generic;
using System.Text;
using Basic = QXP.Framework.Web.UI.Controls.Basic;
using QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Helpers
{

    /// <summary>
	/// Helper g�n�rique permettant la cr�ation de controles web anthem de type Image
	/// </summary>
	public class ImageControlFactory<T> : AnthemControlFactory<T> 
		where T : System.Web.UI.WebControls.Image,Anthem.IUpdatableControl
	{
	
		/// <summary>
		/// Cr�e un ImageButton
		/// </summary>
		/// <param name="url">ImageUrl du Control</param>			
		/// <returns>ImageButton</returns>
		public static new T Create(string url)
		{				
			return SetUrl(AnthemControlFactory<T>.Create(), url);
		}

		#region Set Methodes

		/// <summary>
		/// Affecte une valeur � la propri�t� ImageUrl du Control
		/// </summary>
		/// <param name="control">Control</param>
		/// <param name="url">ImageUrl du Control</param>
		/// <returns></returns>
		internal static T SetUrl(T control, string url)
		{
			control.ImageUrl = url;
			return control;
		}
		
		#endregion Set Methodes

	}
        
    public partial class ControlFactory
    {
        /// <summary>
        /// Helper g�n�rique permettant la cr�ation d'Images Anthem
        /// </summary>
        public class Image: ImageControlFactory<Basic.Image> 
        {
        }

    }    
}
    
	