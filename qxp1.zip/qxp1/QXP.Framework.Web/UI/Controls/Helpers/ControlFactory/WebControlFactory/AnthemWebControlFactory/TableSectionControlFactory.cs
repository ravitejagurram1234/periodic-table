using System;
using Basic = QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Helpers
{
    /// <summary>
    /// Permet la cr�ation de Control
    /// </summary>
    public partial class ControlFactory
    {
        /// <summary>
        /// Permet la cr�ation de WebControl
        /// </summary>
        public class TableSectionControlFactory<T> : AnthemControlFactory<T> where T:Basic.TableSection
        {
            /// <summary>
            /// Cr�e un WebControl
            /// </summary>
            /// <param name="rowCount">Nombre de ligne</param>
            /// <param name="colCount">Nombre de colonne</param>             
            /// <returns>Le WebControl</returns>              
            public static T Create(int rowCount, int colCount)
            {
                //On utilise un helper puisque cette m�thode est aussi utilis�e par le constructeur du WebControl
                return (T)WebControlHelpers.TableSection.SetRowAndColCount(AnthemControlFactory<T>.Create(), rowCount, colCount);
            }

            /// <summary>
            /// Cr�e un WebControl
            /// </summary>
            /// <param name="rowCount">Nombre de ligne</param>
            /// <param name="colCount">Nombre de colonne</param>
            /// <param name="cssClass">Nom de la classe css</param>
            /// <returns>Le WebControl</returns>
            public static T Create(int rowCount, int colCount, string cssClass)
            {
                T __tableSection = (T)WebControlHelpers.TableSection.SetRowAndColCount(AnthemControlFactory<T>.Create(), rowCount, colCount);
                return (T)WebControlHelpers.TableSection.SetCssClass(__tableSection, cssClass);
            }

            /// <summary>
            /// Cr�e un WebControl
            /// </summary>
            /// <param name="rowCount">Nombre de ligne</param>
            /// <param name="colCount">Nombre de colonne</param>
            /// <param name="cssClass">Nom de la classe css</param>
            /// <returns>Le WebControl</returns>
            public static T Create(int rowCount, int colCount, Enum cssClass)
            {
                return Create(rowCount, colCount, cssClass.ToString());
            }
            
            /// <summary>
            /// Cr�e un WebControl
            /// </summary>
            /// <param name="rowCount">Nombre de ligne</param>
            /// <param name="colCount">Nombre de colonne</param>
            /// <param name="isVisible">D�finit la visibilit� du WebControl</param>
            /// <returns>Le WebControl</returns>
            public static T Create(int rowCount, int colCount, bool isVisible)
            {
                return (T)WebControlHelpers.TableSection.SetRowAndColCount(AnthemControlFactory<T>.Create(isVisible), rowCount, colCount);
            }
            
            /// <summary>
            /// Cr�e un WebControl
            /// </summary>
            /// <param name="rowCount">Nombre de ligne</param>
            /// <param name="colCount">Nombre de colonne</param>
            /// <param name="cssClass">Nom de la classe css</param>
            /// <param name="isVisible">D�finit la visibilit� du WebControl</param>
            /// <returns>Le WebControl</returns>
            public static T Create(int rowCount, int colCount, string cssClass, bool isVisible)
            {
                T __tableSection =
                    (T)WebControlHelpers.TableSection.SetRowAndColCount
                    (
                        AnthemControlFactory<T>.Create(cssClass,isVisible), rowCount, colCount
                    );
                return (T)WebControlHelpers.TableSection.SetCssClass(__tableSection, cssClass);
            }

            /// <summary>
            /// Cr�e un WebControl
            /// </summary>
            /// <param name="rowCount">Nombre de ligne</param>
            /// <param name="colCount">Nombre de colonne</param>
            /// <param name="cssClass">Nom de la classe css</param>
            /// <param name="isVisible">D�finit la visibilit� du WebControl</param>
            /// <returns>Le WebControl</returns>
            public static T Create(int rowCount, int colCount, Enum cssClass, bool isVisible)
            {
                return Create(rowCount, colCount, cssClass.ToString(), isVisible);
            }

            /// <summary>
            /// Cr�e un WebControl
            /// </summary>
            /// <param name="rowCount">Nombre de ligne</param>
            /// <param name="colCount">Nombre de colonne</param>
            /// <param name="cssClass">Nom de la classe css</param>
            /// <param name="cssRowClass">Nom de la classe css de chaque ligne</param>
            /// <param name="cssCellClass">Nom de la classe css de chaque cellule</param>
            /// <returns>Le WebControl</returns>
            public static T Create(int rowCount, int colCount, string cssClass, string cssRowClass, string cssCellClass)
            {
                T __tableSection = 
                    (T)WebControlHelpers.TableSection.SetRowAndColCount
                    (
                        AnthemControlFactory<T>.Create(), rowCount, colCount
                    );
                return (T)WebControlHelpers.TableSection.SetCssClass(__tableSection, cssClass, cssRowClass, cssCellClass);
            }           

            /// <summary>
            /// Cr�e un WebControl
            /// </summary>
            /// <param name="rowCount">Nombre de ligne</param>
            /// <param name="colCount">Nombre de colonne</param>
            /// <param name="cssClass">Nom de la classe css</param>
            /// <param name="cssRowClass">Nom de la classe css de chaque ligne</param>
            /// <param name="cssCellClass">Nom de la classe css de chaque cellule</param>
            /// <param name="isVisible">D�finit la visibilit� du WebControl</param>
            /// <returns>Le WebControl</returns>
            public static T Create(int rowCount, int colCount, string cssClass, string cssRowClass, string cssCellClass, bool isVisible)
            {
                T __tableSection = 
                    (T)WebControlHelpers.TableSection.SetRowAndColCount
                    (
                        AnthemControlFactory<T>.Create(cssClass,isVisible), rowCount, colCount
                    );
                return (T)WebControlHelpers.TableSection.SetCssClass(__tableSection, cssClass, cssRowClass, cssCellClass);
            }

        }
    }
}
