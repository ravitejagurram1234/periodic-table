using System;
using System.Collections.Generic;
using System.Text;

using Basic = QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Helpers
{
    /// <summary>
    /// Permet la cr�ation de Control
    /// </summary>
    public partial class ControlFactory
    {
        /// <summary>
        /// Permet la cr�ation de TableSection
        /// </summary>
        public class TableSection : TableSectionControlFactory<Basic.TableSection>
        {

        }
    }
}
