using System;
using Basic = QXP.Framework.Web.UI.Controls.Basic;
using Composite = QXP.Framework.Web.UI.Controls.Composite;

namespace QXP.Framework.Web.UI.Controls.Helpers
{
    /// <summary>
    /// Helper g�n�rique permettant la cr�ation de controles web anthem
    /// </summary>
    public partial class AnthemControlFactory<T> : WebControlFactory<T>
        where T:System.Web.UI.WebControls.WebControl, Anthem.IUpdatableControl
    {
        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <param name="isVisible">D�finit la visibilit� du Control</param>
        /// <param name="autoUpdateAfterCallBack">D�finit si le contr�le doit �tre auotmatiquement mis � jour apr�s chaque Callback</param>
        /// <returns>Control</returns>  
        public static T Create(bool isVisible, bool autoUpdateAfterCallBack)
        {
            return SetAutoUpdateAfterCallBack(WebControlFactory<T>.Create(isVisible), autoUpdateAfterCallBack);
        }
        
        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <param name="cssClass">Nom de la classe css</param>
        /// <param name="isVisible">D�finit la visibilit� du Control</param>
        /// <param name="autoUpdateAfterCallBack">D�finit si le contr�le doit �tre auotmatiquement mis � jour apr�s chaque Callback</param>
        /// <returns>Control</returns>  
        public static T Create(string cssClass, bool isVisible, bool autoUpdateAfterCallBack)
        {
            return SetAutoUpdateAfterCallBack(WebControlFactory<T>.Create(cssClass, isVisible), autoUpdateAfterCallBack);
        }

        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <param name="isVisible">D�finit la visibilit� du Control</param>
        /// <param name="autoUpdateAfterCallBack">D�finit si le contr�le doit �tre auotmatiquement mis � jour apr�s chaque Callback</param>
        /// <param name="enabled">D�finit si le contr�le est actif ou non</param>
        /// <returns>Control</returns>  
        public static T Create(bool isVisible, bool autoUpdateAfterCallBack, bool enabled)
        {
            return SetEnabled(Create(isVisible, autoUpdateAfterCallBack), enabled);
        }

        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <param name="cssClass">Nom de la classe css</param>
        /// <param name="isVisible">D�finit la visibilit� du Control</param>
        /// <param name="autoUpdateAfterCallBack">D�finit si le contr�le doit �tre auotmatiquement mis � jour apr�s chaque Callback</param>
        /// <returns>Control</returns>  
        public static T Create(Enum cssClass, bool isVisible, bool autoUpdateAfterCallBack)
        {
            return Create(cssClass.ToString(), isVisible, autoUpdateAfterCallBack);
        }

        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <param name="cssClass">Nom de la classe css</param>
        /// <param name="isVisible">D�finit la visibilit� du Control</param>
        /// <param name="toolTip">ToolTip du Control</param>
        /// <param name="autoUpdateAfterCallBack">D�finit si le contr�le doit �tre auotmatiquement mis � jour apr�s chaque Callback</param>
        /// <returns>Control</returns>  
        public static T Create(string cssClass, bool isVisible, string toolTip, bool autoUpdateAfterCallBack)
        {
            return SetAutoUpdateAfterCallBack(WebControlFactory<T>.Create(cssClass, isVisible, toolTip), autoUpdateAfterCallBack);
        }

        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <param name="cssClass">Nom de la classe css</param>
        /// <param name="isVisible">D�finit la visibilit� du Control</param>
        /// <param name="toolTip">ToolTip du Control</param>
        /// <param name="autoUpdateAfterCallBack">D�finit si le contr�le doit �tre auotmatiquement mis � jour apr�s chaque Callback</param>
        /// <returns>Control</returns>  
        public static T Create(Enum cssClass, bool isVisible, string toolTip, bool autoUpdateAfterCallBack)
        {
            return Create(cssClass.ToString(), isVisible, toolTip, autoUpdateAfterCallBack);
        }

        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <param name="cssClass">Nom de la classe css</param>
        /// <param name="isVisible">D�finit la visibilit� du Control</param>
        /// <param name="autoUpdateAfterCallBack">D�finit si le contr�le doit �tre auotmatiquement mis � jour apr�s chaque Callback</param>
        /// <param name="enabled">D�finit si le contr�le est actif ou non</param>
        /// <returns>Control</returns>  
        public static T Create(string cssClass, bool isVisible, bool autoUpdateAfterCallBack, bool enabled)
        {
            return SetEnabled(Create(cssClass, isVisible, autoUpdateAfterCallBack), enabled);
        }

        /// <summary>
        /// Cr�e un Control
        /// </summary>
        /// <param name="cssClass">Nom de la classe css</param>
        /// <param name="isVisible">D�finit la visibilit� du Control</param>
        /// <param name="autoUpdateAfterCallBack">D�finit si le contr�le doit �tre auotmatiquement mis � jour apr�s chaque Callback</param>
        /// <param name="enabled">D�finit si le contr�le est actif ou non</param>
        /// <returns>Control</returns>  
        public static T Create(Enum cssClass, bool isVisible, bool autoUpdateAfterCallBack, bool enabled)
        {
            return Create(cssClass.ToString(), isVisible, autoUpdateAfterCallBack, enabled);
        }

        #region Set Methodes 

        /// <summary>
        /// Affecte une valeur � la propri�t� AutoUpdateAfterCallBack du Control
        /// </summary>
        /// <param name="webControl">Control</param>
        /// <param name="autoUpdateAfterCallBack">Valeur de la propri�t� AutoUpdateAfterCallBack</param>
        /// <returns>Control</returns>
        internal static T SetAutoUpdateAfterCallBack(T webControl, bool autoUpdateAfterCallBack)
        {
            webControl.AutoUpdateAfterCallBack = autoUpdateAfterCallBack;
            return webControl;
        }

        /// <summary>
        /// Affecte une valeur � la propri�t� Enabled du Control
        /// </summary>
        /// <param name="webControl">Control</param>
        /// <param name="enabled">Valeur de la propri�t� Enabled</param>
        /// <returns>Control</returns>
        internal static T SetEnabled(T webControl, bool enabled)
        {
            webControl.Enabled = enabled;
            return webControl;
        }  

        #endregion Set Methodes 

    }

    /// <summary>
    /// Permet la cr�ation de Control
    /// </summary>
    public partial class ControlFactory
    {
        /// <summary>
        /// Helper g�n�rique permettant la cr�ation de controles web anthem
        /// </summary>
        public class AnthemControl<T> : AnthemControlFactory<T> where T:System.Web.UI.WebControls.WebControl, Anthem.IUpdatableControl
        {
        }

    }
}
