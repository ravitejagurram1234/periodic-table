using System;
using System.Collections.Generic;
using System.Text;
using List = QXP.Framework.Web.UI.Controls.List;
using QXP.Framework.Web.UI.Controls.List;

namespace QXP.Framework.Web.UI.Controls.Helpers
{

    /// <summary>
	/// Helper permettant la cr�ation de controles web anthem de type DataList
	/// </summary>
	public class DataListControlFactory<T>
		where T : System.Web.UI.WebControls.DataList,Anthem.IUpdatableControl
	{
		/// <summary>
		/// Permet la cr�ation de DataList
		/// </summary>
        /// <param name="itemTemplate">ItemTemplate du dataList</param>
        /// <param name="args">Liste des arguments � transmettre � l'itemtemplate</param>
		/// <returns>DataList</returns>
		public static T Create(Type itemTemplate, params object[] args)
        {
			return SetItemTemplate(ControlFactory<T>.Create(), itemTemplate, args);
		}

		/// <summary>
		/// Permet la cr�ation de DataList
		/// </summary>
        /// <param name="itemTemplate">ItemTemplate du dataList</param>
        /// <param name="separatorTemplate">SeparatorTemplate du dataList</param>
        /// <param name="args">Liste des arguments � transmettre � l'itemtemplate</param>
		/// <returns>DataList</returns>
		public static T Create(Type itemTemplate, Type separatorTemplate, params object[] args)
        {
			return SetseparatorTemplate(Create(itemTemplate, args), separatorTemplate);
		}

		#region Set Methodes

        /// <summary>
        /// Affecte l'ItemTemplate du DataList Control
        /// </summary>
        /// <param name="dataListControl">DataList</param>
        /// <param name="itemTemplate">ItemTemplate du dataList</param>
        /// <param name="args">Liste des arguments � transmettre � l'itemtemplate</param>
        /// <returns>DataList</returns>
        internal static T SetItemTemplate(T dataListControl, Type itemTemplate,  params object[] args)
        {
            dataListControl.ItemTemplate = new List.Template(itemTemplate, args);
            return dataListControl;
        }

        /// <summary>
        /// Affecte le SeparatorTemplate du DataList Control
        /// </summary>
        /// <param name="dataListControl">DataList</param>
        /// <param name="separatorTemplate">SeparatorTemplate du dataList</param>
        /// <returns>DataList</returns>
        internal static T SetseparatorTemplate(T dataListControl, Type separatorTemplate)
        {
            dataListControl.SeparatorTemplate = new List.Template(separatorTemplate);
            return dataListControl;
        }
        #endregion Set Methodes

	}
        
    public partial class ControlFactory
    {
        
		/// <summary>
        /// Permet la cr�ation de DataList
        /// </summary>
        public class DataList : DataListControlFactory<List.DataList>
        {
        }
	      
		/// <summary>
        /// Permet la cr�ation de DataList
        /// </summary>
        public class DataList<T> : DataListControlFactory<T>
            where T : System.Web.UI.WebControls.DataList,Anthem.IUpdatableControl
        {
        }
	}    
}
    
	