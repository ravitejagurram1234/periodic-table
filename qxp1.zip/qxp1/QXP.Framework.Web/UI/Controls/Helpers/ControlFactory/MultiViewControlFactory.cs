using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Web.UI.Controls.Helpers
{
    /// <summary>
    /// Permet la cr�ation de Control
    /// </summary>
    public partial class ControlFactory
    {
        /// <summary>
        /// Permet la cr�ation de MultiView
        /// </summary>
        public class MultiView : ControlFactory<Basic.MultiView>
        {
            /// <summary>
            /// Cr�e un MultiView
            /// </summary>
            /// <param name="activeViewIndex">ActiveViewIndex du MultiView</param>
            /// <returns>Un MultiView</returns>  
            public static Basic.MultiView Create(int activeViewIndex)
            {
                return SetActiveViewIndex(ControlFactory<Basic.MultiView>.Create(), activeViewIndex);
            }

            #region Set Methodes 

            /// <summary>
            /// Affecte une valeur � la propri�t� Title du MultiView
            /// </summary>
            /// <param name="multiview">MultiView</param>
            /// <param name="activeViewIndex">ActiveViewIndex du MultiView</param>
            /// <returns>Control</returns>
            internal static Basic.MultiView SetActiveViewIndex(Basic.MultiView multiview, int activeViewIndex)
            {
                multiview.ActiveViewIndex = activeViewIndex;
                return multiview;
            }  

            #endregion Set Methodes 
        }
    }
}
