using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Web.UI.Controls.Helpers
{
    /// <summary>
    /// Permet la cr�ation de Control
    /// </summary>
    public partial class ControlFactory
    {
        /// <summary>
        /// Permet la cr�ation de View
        /// </summary>
        public class View : ControlFactory<Basic.View>
        {
            
            /// <summary>
            ///Cr�e une View
            /// </summary>
            /// <param name="title">Title de la View</param>
            /// <returns>Une View</returns>  
            public static Basic.View Create(string title)
            {
                return SetTitle(ControlFactory<Basic.View>.Create(), title);
            }

            #region Set Methodes 

            /// <summary>
            /// Affecte une valeur � la propri�t� Title de la View
            /// </summary>
            /// <param name="view">View</param>
            /// <param name="title">Title de la View</param>
            /// <returns>Control</returns>
            internal static Basic.View SetTitle(Basic.View view, string title)
            {
                view.Title = title;
                return view;
            }  

            #endregion Set Methodes 
        }
    }
}
