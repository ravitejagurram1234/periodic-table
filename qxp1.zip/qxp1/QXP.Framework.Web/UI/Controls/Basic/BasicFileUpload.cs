
namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>Provides methods and properties of a upload file control. </summary>
	public class FileUpload: Anthem.FileUpload
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de FileUplaod
        /// </summary>
		public FileUpload()
        {
            // N�cessaire pour la persistence correcte des �v�nements de la page
            this.AutoUpdateAfterCallBack = true;
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}

