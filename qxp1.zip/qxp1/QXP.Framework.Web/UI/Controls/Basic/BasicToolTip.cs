using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Text;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	
	/// <summary>
	/// Class Tooltip permettant d'afficher des informations en passant la souris sur un control
	/// Ce controle est un simple container qui � la possibilit� d'�tre automatiquement affich�/masqu� lorsque l'utilisateur pass la souris sur 1 ou N controle 
	/// l'association entre le tooltip et le/les controle(s) s'effectue par la methode AddShowScript/AddHideScript du controle tooltip
	/// </summary>
	/// <author> </author>
	/// <date> </date>    
	public class Tooltip : WebControlSection
	{
		#region Membres
		string				_toolTipControl = string.Empty;
		int					_hide_Delay		= 0;
		#endregion Membres

		#region Constantes
		const	string	ToolTipScriptRes	= "ToolTip.js";
		//const	string	ToolTipJSScript		= "scripts/ToolTip.js";
		const	string	Css_ToolTip			= "tooltip";
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Creation d'un control toolTip
		/// </summary>
		public Tooltip(): base(HtmlTextWriterTag.Div)
		{
			this.CssClass = Css_ToolTip;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Ajoute au controle 'webcontrol' un code javascript permettant d'afficher le tooltip lorsque la souris pass au dessus de ce controle
		/// une mise � jour du contenu HTML du tooltip et effectuer �galement.
		/// </summary>
		/// <param name="control"></param>
		/// <param name="message"></param>
		public virtual void AddShowScript(System.Web.UI.WebControls.WebControl webControl, string innerHTML)
		{
			webControl.Attributes["onmouseover"] = string.Format("javascript:{0}.Show('{1}');", this.ToolTipControl, innerHTML);
		}

		/// <summary>
		/// Ajoute au controle 'webcontrol' un code javascript permettant de masquer le tooltip lorsque la souris ne survole plus le 'webcontrol'
		/// </summary>
		/// <param name="control"></param>
		public virtual void AddHideScript(System.Web.UI.WebControls.WebControl webControl)
		{
			webControl.Attributes["onmouseout"] = string.Format("javascript:{0};", this.GetHideScript());
		}

		public void AddShowHideScript(System.Web.UI.WebControls.WebControl webControl, string innerHTML)
		{
			this.AddShowScript(webControl, innerHTML);
			this.AddHideScript(webControl);
		}

		protected override void OnPreRender(EventArgs e)
		{
			//onmousehover est bugger sur ie dommage il est pr�sent sur tout les navigateur
			//Pour les autres navigateurs
			this.Attributes["onmouseover"] = string.Format("if(!QXP.Browser.isIE){{{0}.Disable_Timer();}}", this.ToolTipControl);
			//this.Attributes["onmouseover"] = string.Format("if(!QXP.UI.IE){{alert('mouseover');}}", this.ToolTipControl);
			//this.Attributes["onmouseover"] = "alert(QXP.UI.IE());";
			
			//onmouseenter est sp�cifique � IE est n'existe pas sur les autres browser
			this.Attributes["onmouseenter"] = string.Format("{0}.Disable_Timer();", this.ToolTipControl);
			
			//Le fait de quitter le tooltip entraine une fermeture imm�diate de celui �i
			//onmouseleave est sp�cifique � IE est n'existe pas sur les autres browser
			this.Attributes["onmouseleave"]	= string.Format("{0}.Hide(0);", this.ToolTipControl);
			
			//onmouseout est bugger sur ie dommage il est pr�sent sur tout les navigateur
			//Pour les autres navigateurs
			this.Attributes["onmouseout"]	= string.Format("if(!QXP.Browser.isIE){{{0}.Hide(200);}}", this.ToolTipControl);
			
			//Inscription du fichier JS contenant les fonctions javascript n�cessaires au controle tooltip cot� client (IE)
            WebResource.RegisterPageScript(this.Page, ToolTipScriptRes);
            
			////Inscription du fichier JS contenant les fonctions javascript n�cessaires au controle tooltip cot� client (IE)
			//string		        __jsScript		= string.Format("<script language=\"javascript\" src=\"{0}\" type=\"text/javascript\"></script>", Utils.GetAbsoluteUrl(ToolTipJSScript));
			//ClientScript		__CS_jsScript	= new ClientScript(this, "ToolTip", __jsScript);
			//__CS_jsScript.StartupScript = true;
			//__CS_jsScript.Register();

			//Creation de l'instance javascript du controle ToolTip
			string		        __newScript		= string.Format("var {0} = new ToolTip('{1}', '{2}');", this.ToolTipControl, this.ToolTipWindowID, this.ToolTipBodyID);
			ClientScript		__CS_newScript = new ClientScript(this, this.ToolTipControl, __newScript, true);
			__CS_newScript.Register();

			base.OnPreRender(e);
		}
		/// <summary>
		/// R�cup�ration du nom technique de l'instance du controle tooltip sur le client IE
		/// </summary>
		/// <returns></returns>
		private string GetToolTipControl()
		{
			return string.Format("Tooltip_{0}_CTRL", this.ClientID);
		}

		/// <summary>
		/// Permet d'obtenir le script (javascript) pour masquer le tooltip
		/// � utliser afin de masquee le controle sur des �v�nements custom ^^
		/// </summary>
		/// <returns></returns>
		public string GetHideScript()
		{
			return string.Format("{0}.Hide({1})", this.ToolTipControl, this.Hide_Delay);
		}

		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// repr�sente le nom technique de l'instance du controle tooltip sur le client IE
		/// </summary>
		public string ToolTipControl
		{
			get
			{
				if(Validation.IsNotSet(_toolTipControl))
				{
					_toolTipControl = GetToolTipControl();
				}
				return _toolTipControl;
			}
		}
		
		/// <summary>
		/// Repr�sente l'identifiant du controle web tooltip
		/// </summary>
		public virtual string ToolTipWindowID
		{
			get
			{
				return this.ClientID;
			}
		}
		/// <summary>
		/// repr�sente l'identifiant du controle dont le contenu sera mise � jour au moment de l'affichage
		/// par d�faut cet identifiant est le m�me que le controle tooltip
		/// </summary>
		public virtual string ToolTipBodyID
		{
			get
			{
				return this.ClientID;
			}
		}

		/// <summary>
		/// Permet de d�finir une temporisation � la fermeture du tooltip
		/// Cette fonctionnalit� laisse le temps � l'utilisateur de passer le curseur sur le tooltip qui reste ouvert et permet donc au tooltip de devenir interactif 
		/// La valeur par d�faut � 0 sous entend qu'il n'y � aucune temporisation
		/// une autre valeur exprim�e en milliseconde d�fini le temp avant la fermeture une valeur convenable semble �tre situ�e entre 300 et 500
		/// </summary>
		public int Hide_Delay
		{
			get
			{
				return _hide_Delay;
			}
			set
			{
				_hide_Delay = value;
			}
		}
		#endregion Propri�t�s
	}

			
}
