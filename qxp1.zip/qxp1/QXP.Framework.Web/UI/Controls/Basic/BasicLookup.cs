using System;
using System.Collections;
using System.Collections.Specialized;
using System.Globalization;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using MSWebControls = System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>Provides methods and properties of a Lookup control. </summary>
	public class Lookup: WebControl{
		#region Internal variables
			private const		string	TxtCss					= "txt_lkp";	
			private const		string	LkpCss					= "img_lkp";
			internal    TextBox				_txtBox;
			private	    ImageButton			_imgLkp;
			private    	bool				_addButton			= true;
			private    	bool				_showTextBox		= true;
            private    	bool                _blocked            = false;
			private    	string				_module;
			private    	string				_page;
			private    	string				_lookupWindowName	= DefaultWindowName;
            const       string              VSCausesValidation  = "CauseValidation";
			const       string				WindowWidthKey		= "WindowWidth";
			const       string				WindowHeightKey		= "WindowHeight";
			const       string				WindowResizableKey	= "WindowResizable";
			const       string				WindowScrollableKey	= "WindowScrollable";
			const       string				DefaultWindowName	= "PopUpLookup";
			Hashtable						_extraParameters	= new Hashtable();

		#endregion
		/// <summary>Occurs when the lookup control is initializing. </summary>
		protected	event EventHandler LookupInit;
		public		event EventHandler TextChanged;
		/// <summary>Creates a new instance of <see cref="Lookup"/> control. </summary>
		public Lookup(){
			this.Init					+= new EventHandler(Init_Control);
			_txtBox						= new TextBox();
			_txtBox.CssClass			= TxtCss;
			_txtBox.TextChanged			+= new EventHandler(this.OnTextChange);
			_imgLkp						= new ImageButton(AbsoluteFilesPath.PlaceHolderImg);
			_imgLkp.CausesValidation	= false;
			_imgLkp.CssClass			= LkpCss;
		}
		private							void		Init_Control(object sender, EventArgs ea){
			_txtBox.ID = _txtBox.ID;
			this.Controls.Add(_txtBox);
			this.Controls.Add(_imgLkp);
			if(Validation.IsNotNull(LookupInit))
			{
				this.LookupInit(this, EventArgs.Empty);
			}
		}
		private							void		OnTextChange(object sender, EventArgs ea){
            if(this.CausesValidation && !this.Page.IsValid) return;
			if(Validation.IsNotNull(this.TextChanged)) this.TextChanged(this, EventArgs.Empty);
		}
		/// <summary>Occurs when the control is about to render to its containing control. </summary>
		/// <param name="args">The <see cref="EventArgs"/> that contains event data. </param>
		/// <remarks>This method generate client script used by the calendar control if <see cref="AddButton"/> is set to <see langword="true"/>. </remarks>
		protected	override			void		OnPreRender(EventArgs args) {
			base.OnPreRender(args);
			if(_addButton)
			{
				StringBuilder __sb = new StringBuilder();
				__sb.AppendFormat("window.open('{0}?FormName=MainForm&CtrlName={1}", AbsoluteFilesPath.LookupPage, _txtBox.UniqueID);
				if(Validation.IsSet(_module))	__sb.AppendFormat("&m={0}", _module);
				if(Validation.IsSet(_page))		__sb.AppendFormat("&p={0}", _page);
			    if(this.AutoPostBack)			__sb.AppendFormat("&postid={0}", this.UniqueID);
			    if(this.AutoCallBack)			__sb.AppendFormat("&callid={0}", this.UniqueID);
				
				if(_showTextBox)				__sb.AppendFormat("&value=' + document.getElementById('{0}').value", _txtBox.ClientID);
				else							__sb.AppendFormat("'");

				NameValueCollection __staticParameters = this.StaticParameters;
				if(__staticParameters.Count > 0)
				{
					foreach(string __key in __staticParameters)
					{
						__sb.AppendFormat(" + '&{0}={1}'", __key, __staticParameters[__key]);
					}
				}

				if(_extraParameters.Count > 0){
					foreach(DictionaryEntry __entry in _extraParameters){
						__sb.AppendFormat(" + '&{0}=' + document.getElementById('{1}').value", __entry.Key, __entry.Value);
					}
				}
				__sb.AppendFormat(", '{0}', 'width={1},height={2},top=200,left=200,toolbars=no,scrollbars={3},status=no,resizable={4}');return false;", _lookupWindowName, this.WindowWidth, this.WindowHeight, this.WindowScrollable?"yes":"no", this.WindowResizable?"yes":"no");
				string __openScript = __sb.ToString();    
				_imgLkp.Attributes["onclick"] = __openScript;
			}
			this._imgLkp.Visible = _addButton;
			this._txtBox.Visible = _showTextBox;
            this._txtBox.Enabled = !_blocked;
		}
		/// <summary>Gets or sets if the BaseCalendar is enable or not. </summary>
		public		override			bool		Enabled {
			get {return base.Enabled;}
			set {
				this.AddButton	= value;
				_txtBox.Enabled = value;
			}
		}
		/// <summary>Gets or sets the current selected/entered text. </summary>
		public							string		Text
		{
			get{return _txtBox.Text;}
			set{_txtBox.Text = value;}
		}
		/// <summary>Gets or sets textbox ToolTip. </summary>
		public							string		ToolTip
		{
			get{return _txtBox.ToolTip;}
			set{_txtBox.ToolTip = value;}
		}
		public							string		Button_Tooltip
		{
			get{return _imgLkp.ToolTip;}
			set{_imgLkp.ToolTip = value;}
		}
		/// <summary>Gets or sets if control display it's button. </summary>
		public							bool		AddButton
		{
			get{return _addButton;}
			set{_addButton = value;}
		}
		/// <summary>Gets or sets if control display it's TextBox. </summary>
		public							bool		ShowTextBox
		{
			get{return _showTextBox;}
			set{_showTextBox = value;}
		}
		public							int			Columns
		{
			get{return _txtBox.Columns;}
			set{_txtBox.Columns = value;}
		}
		public							int			Rows{
			get{return _txtBox.Rows;}
			set{_txtBox.Rows = value;}
		}
		public							int			MaxLength{
			get{return _txtBox.MaxLength;}
			set{_txtBox.MaxLength = value;}
		}
		public							bool		AutoPostBack{
			get{return _txtBox.AutoPostBack;}
			set{_txtBox.AutoPostBack = value;}
		}
		public							bool		AutoCallBack{
			get{return _txtBox.AutoCallBack;}
			set{_txtBox.AutoCallBack = value;}
		}
        /// <summary>Gets or sets if the control raise callback event (otherwise it raise postback event). </summary>
		public bool								    EnableCallBack{
			get{return _txtBox.EnableCallBack;}
			set{_txtBox.EnableCallBack = value;}
		}
        public                          bool        CausesValidation{
            get{return Conversion.ToBool(this.ViewState[VSCausesValidation]);}
            set{this.ViewState[VSCausesValidation] = value;}
        }
		public							string		M{
			get{return _module;}
			set{_module = value;}
		}
		public							string		P
		{
			get{return _page;}
			set{_page = value;}
		}
		public							int			WindowWidth{
			get{
				int __windowWidth = Conversion.ToInt(this.ViewState[WindowWidthKey]);
				if(Validation.IsSet(__windowWidth)) return __windowWidth;
				else								return 400;
			}
			set{this.ViewState[WindowWidthKey] = value;}
		}
        public							bool		TextBoxBlocked{
			set{_blocked = value;}
		}
		public							int			WindowHeight
		{
			get
			{
				int __windowHeight = Conversion.ToInt(this.ViewState[WindowHeightKey]);
				if(Validation.IsSet(__windowHeight))	return __windowHeight;
				else									return 400;
			}
			set{this.ViewState[WindowHeightKey] = value;}
		}
		public							bool		WindowResizable{
			get{return Conversion.ToBool(this.ViewState[WindowResizableKey]);}
			set{this.ViewState[WindowResizableKey] = value;}
		}
		public							bool		WindowScrollable{
			get{return Conversion.ToBool(this.ViewState[WindowScrollableKey]);}
			set{this.ViewState[WindowScrollableKey] = value;}
		}
		public							Hashtable			ExtraParameters{
			get{return _extraParameters;}
		}
		public							NameValueCollection StaticParameters{
			get{
				NameValueCollection __parameters = this.ViewState["StaticParams"] as NameValueCollection;
				if(Validation.IsNull(__parameters))
				{
					__parameters					= new NameValueCollection();
					this.ViewState["StaticParams"]	= __parameters;
				} 
				return __parameters;
			}
		}
		public							string		LookupWindowName{
			get{return _lookupWindowName;}
			set{_lookupWindowName = value;}
		}
	}

    	/// <summary>Provides methods and properties of a Lookup Hidden Button control. </summary>
	public class LookupButtonHidden: WebControl{
		#region Internal variables
			//private const		string	TxtCss					= "txt_lkp";	
			//private const		string	LkpCss					= "img_lkp";
			//internal	TextBox				_txtBox;
            private     Html.Hidden         _hidden;
			private		Button			    _btn;
			private		string				_module;
			private		string				_page;
			private		string				_lookupWindowName	= DefaultWindowName;
			const string					WindowWidthKey		= "WindowWidth";
			const string					WindowHeightKey		= "WindowHeight";
			const string					WindowResizableKey	= "WindowResizable";
			const string					WindowScrollableKey	= "WindowScrollable";
			const string					DefaultWindowName	= "PopUpLookup";
			Hashtable						_extraParameters	= new Hashtable();

		#endregion
		/// <summary>Occurs when the lookup control is initializing. </summary>
		protected	event EventHandler LookupInit;
		public		event EventHandler TextChanged;
		
        const string VSEnabledCallBack = "EnabledCallBack";

        /// <summary>Creates a new instance of <see cref="Lookup"/> control. </summary>
		public LookupButtonHidden(){
			this.Init					+= new EventHandler(Init_Control);
            _hidden                     = new Html.Hidden();
            _hidden.ServerChange        += new EventHandler(this.OnTextChange);
            //_txtBox						= new TextBox();
            //_txtBox.CssClass			= TxtCss;
            //_txtBox.TextChanged			+= new EventHandler(this.OnTextChange);
			_btn						= new Button();
			_btn.CausesValidation	    = false;
			//_btn.CssClass			    = LkpCss;
		}
		private							void		Init_Control(object sender, EventArgs ea){
			//_txtBox.ID = _txtBox.ID;
            _hidden.ID = _hidden.ID;
			this.Controls.Add(_hidden);
			this.Controls.Add(_btn);
			if(Validation.IsNotNull(LookupInit))
			{
				this.LookupInit(this, EventArgs.Empty);
			}
		}
		private							void		OnTextChange(object sender, EventArgs ea){
			if(Validation.IsNotNull(this.TextChanged)) this.TextChanged(this, EventArgs.Empty);
		}
		/// <summary>Occurs when the control is about to render to its containing control. </summary>
		/// <param name="args">The <see cref="EventArgs"/> that contains event data. </param>
		/// <remarks>This method generate client script used by the calendar control if <see cref="AddButton"/> is set to <see langword="true"/>. </remarks>
		protected	override			void		OnPreRender(EventArgs args) {
			base.OnPreRender(args);
			StringBuilder __sb = new StringBuilder();
			__sb.AppendFormat("window.open('{0}?FormName=MainForm&CtrlName={1}", AbsoluteFilesPath.LookupPage, _hidden.UniqueID);
			if(Validation.IsSet(_module))	__sb.AppendFormat("&m={0}", _module);
			if(Validation.IsSet(_page))		__sb.AppendFormat("&p={0}", _page);
		    if(this.EnabledCallBack)		__sb.AppendFormat("&callid={0}", _btn.UniqueID);
		    else			                __sb.AppendFormat("&postid={0}", _btn.UniqueID);

			__sb.AppendFormat("&value=' + document.getElementById('{0}').value", _hidden.ClientID);

			NameValueCollection __staticParameters = this.StaticParameters;
			if(__staticParameters.Count > 0)
			{
				foreach(string __key in __staticParameters)
				{
					__sb.AppendFormat(" + '&{0}={1}'", __key, __staticParameters[__key]);
				}
			}

			if(_extraParameters.Count > 0){
				foreach(DictionaryEntry __entry in _extraParameters){
					__sb.AppendFormat(" + '&{0}=' + document.getElementById('{1}').value", __entry.Key, __entry.Value);
				}
			}
			__sb.AppendFormat(", '{0}', 'width={1},height={2},top=200,left=200,toolbars=no,scrollbars={3},status=no,resizable={4}');return false;", _lookupWindowName, this.WindowWidth, this.WindowHeight, this.WindowScrollable?"yes":"no", this.WindowResizable?"yes":"no");
			string __openScript = __sb.ToString();    
			_btn.Attributes["onclick"] = __openScript;
		}
        /// <summary>Returned when a command occurs on the return lookup. </summary>
		public event		CommandEventHandler	    Command
		{
			add{_btn.Command += value;}
			remove{_btn.Command -= value;}
		}
		public		        bool				    EnabledCallBack
		{
			get{if(Validation.IsNotSet(this.ViewState[VSEnabledCallBack]))  return true;
                else                                                        return Conversion.ToBool(this.ViewState[VSEnabledCallBack]);}
			set{this.ViewState[VSEnabledCallBack] = value;}
		}
        /// <summary>Gets or sets the current selected/entered text. </summary>
		public							string		Value
		{
			get{return _hidden.Value;}
			set{_hidden.Value = value;}
        }
        #region Button
        public                          string      CommandName{
            get{return _btn.CommandName;}
            set{_btn.CommandName = value;}
        }
        public                          string      CommandArgument{
            get{return _btn.CommandArgument;}
            set{_btn.CommandArgument = value;}
        }
		/// <summary>Gets or sets the current text button. </summary>
		public							string		Text
		{
			get{return _btn.Text;}
			set{_btn.Text = value;}
        }
        public							string		Tooltip
		{
			get{return _btn.ToolTip;}
			set{_btn.ToolTip = value;}
		}
        #endregion
        #region hidden

        #endregion
        #region lookup Windows
        public							string		M{
			get{return _module;}
			set{_module = value;}
		}
		public							string		P
		{
			get{return _page;}
			set{_page = value;}
		}
		public							int			WindowWidth{
			get{
				int __windowWidth = Conversion.ToInt(this.ViewState[WindowWidthKey]);
				if(Validation.IsSet(__windowWidth)) return __windowWidth;
				else								return 400;
			}
			set{this.ViewState[WindowWidthKey] = value;}
		}
		public							int			WindowHeight
		{
			get
			{
				int __windowHeight = Conversion.ToInt(this.ViewState[WindowHeightKey]);
				if(Validation.IsSet(__windowHeight))	return __windowHeight;
				else									return 400;
			}
			set{this.ViewState[WindowHeightKey] = value;}
		}
		public							bool		WindowResizable{
			get{return Conversion.ToBool(this.ViewState[WindowResizableKey]);}
			set{this.ViewState[WindowResizableKey] = value;}
		}
		public							bool		WindowScrollable{
			get{return Conversion.ToBool(this.ViewState[WindowScrollableKey]);}
			set{this.ViewState[WindowScrollableKey] = value;}
		}
		public							Hashtable			ExtraParameters{
			get{return _extraParameters;}
		}
		public							NameValueCollection StaticParameters{
			get{
				NameValueCollection __parameters = this.ViewState["StaticParams"] as NameValueCollection;
				if(Validation.IsNull(__parameters))
				{
					__parameters					= new NameValueCollection();
					this.ViewState["StaticParams"]	= __parameters;
				} 
				return __parameters;
			}
		}
		public							string		LookupWindowName{
			get{return _lookupWindowName;}
			set{_lookupWindowName = value;}
		}
    #endregion
	}
}

