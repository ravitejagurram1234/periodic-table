using System.Web.UI;
using System.Web.UI.WebControls;

//Used By Timer
using System;
using System.Text;


namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>Constructs a text box and defines its properties. <seealso cref="System.Web.UI.WebControls.TextBox"/></summary>
	public class TextBox: Anthem.TextBox, ITextable
    {
		#region internal variables
		private static readonly string DefaultCss = Basic.CssClass.tbx.ToString();
		#endregion
		/// <summary>Initializes a new instance of <see cref="TextBox"/> control. </summary>
		public TextBox() {
			base.CssClass               = DefaultCss;
            this.EnabledDuringCallBack  = false;
		}
		/// <summary>Initializes a new instance of <see cref="TextBox"/> control with the text box content. </summary>
		/// <param name="text">The text content of the text box. </param>
		public TextBox(string text): this(){
			if(Validation.IsSet(text)) this.Text = text;
		}
		/// <summary>Initializes a new instance of <see cref="TextBox"/> control. </summary>
		/// <param name="text">The text content of the text box. </param>
		/// <param name="cssClass">The Cascading Style Sheet (CSS) class that will be rendered by the control. </param>
		public TextBox(string text, string cssClass): this(text){
			if(Validation.IsSet(cssClass)) this.CssClass = cssClass;
		}
		/// <summary>Initializes a new instance of <see cref="TextBox"/> control. </summary>
		/// <param name="text">The text content of the text box. </param>
		/// <param name="cssClass">The Cascading Style Sheet (CSS) class that will be rendered by the control. </param>
		/// <param name="columns">The display width of the text box in characters. </param>
		public TextBox(string text, string cssClass, int columns): this(text, cssClass){
			this.Columns = columns;
		}
		/// <summary>Initializes a new instance of <see cref="TextBox"/> control. </summary>
		/// <param name="text">The text content of the text box. </param>
		/// <param name="cssClass">The Cascading Style Sheet (CSS) class that will be rendered by the control. </param>
		/// <param name="columns">The display width of the text box in characters. </param>
		/// <param name="maxLength">The maximum number of characters allowed in the text box. </param>
		public TextBox(string text, string cssClass, int columns, int maxLength): this(text, cssClass, columns){
			this.MaxLength = maxLength;
		}
		/// <summary>Initializes a new instance of <see cref="TextBox"/> control. </summary>
		/// <param name="text">The text content of the text box. </param>
		/// <param name="cssClass">The Cascading Style Sheet (CSS) class that will be rendered by the control. </param>
		/// <param name="columns">The display width of the text box in characters. </param>
		/// <param name="maxLength">The maximum number of characters allowed in the text box. </param>
		/// <param name="width">The text box width. </param>
		public TextBox(string text, string cssClass, int columns, int maxLength, Unit width): this(text, cssClass, columns, maxLength){
			this.Width = width;
		}
		/// <summary>Gets or sets the behavior mode of the text box to password. </summary>
		public                  bool IsTextHidden{
			get{return(this.TextMode == TextBoxMode.Password);}
			set{this.TextMode = value?TextBoxMode.Password:TextBoxMode.SingleLine;}
		}
		/// <summary>Gets or sets the behavior mode of the text box to multiline. </summary>
		public                  bool IsMultiLineText{
			get{return(this.TextMode == TextBoxMode.MultiLine);}
			set{this.TextMode = value?TextBoxMode.MultiLine:TextBoxMode.SingleLine;}
		}
		/// <summary>Gets whether the text of the text box is empty. </summary>
		public                  bool IsEmpty{
			get{return (this.Text == string.Empty);}
		}
		/// <summary>Clears the text box content. </summary>
		public                  void Clear(){
			this.Text = string.Empty;
		}
        protected   override    void OnTextChanged(EventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnTextChanged(e);
        }
 	}
}
