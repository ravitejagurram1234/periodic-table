using System;

namespace QXP.Framework.Web.UI.Controls.Basic{
	/// <summary>Displays an image on a Web page. <seealso cref="System.Web.UI.WebControls.Image"/></summary>
	public class Image : Anthem.Image{
		#region internal variables
		private static readonly string DefaultCss = Basic.CssClass.img.ToString();
		#endregion
		/// <summary>Initializes a new instance of <see cref="Image"/> control. </summary>
		public Image() {
			base.CssClass = DefaultCss;
		}
		/// <summary>Initializes a new instance of <see cref="Image"/> control. </summary>
		/// <param name="imageUrl">The location of an image to display in the Image control. </param>
		public Image(string imageUrl): this(){
			if(Validation.IsSet(imageUrl)) this.ImageUrl	= imageUrl;
		}
		/// <summary>Initializes a new instance of <see cref="Image"/> control. </summary>
		/// <param name="imageUrl">The location of an image to display in the Image control. </param>
		/// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
		public Image(string imageUrl, string cssClass): this(imageUrl){
			if(Validation.IsSet(cssClass)) this.CssClass = cssClass;
		}
	}
}