using System;
using System.Globalization;
using System.Web.UI;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>
    /// Class Date : Contr�le Date avec calendrier
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class Date : WebControl
    {
        #region Membres

        internal TextBox _txtBox;
        private ImageButton _imgCal;
        private bool _addButton = true;

        /// <summary>Occurs when the calendar control is initializing. </summary>
        protected event EventHandler CalendarInit;

        public event EventHandler DateChanged;

        #endregion Membres

        #region Constantes

        private const string TxtCss = "txt_cldr";
        private const string CldrCss = "img_cldr";
        public const string DateScriptRes = "Date.js";
        private const string DateStyleFile = "Styles/calendarStyle.css";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new instance of <see cref="BaseCalendar"/> control. </summary>
        public Date()
        {
            this.Init += new EventHandler(Init_Control);
            _txtBox = new TextBox();
            _txtBox.CssClass = TxtCss;
            _txtBox.TextChanged += new EventHandler(this.OnDateChange);
            _imgCal = new ImageButton(AbsoluteFilesPath.PlaceHolderImg);
            _imgCal.CausesValidation = false;
            _imgCal.CssClass = CldrCss;
        }

        #endregion Constructeur

        #region M�thodes

        private void Init_Control(object sender, EventArgs ea)
        {
            this.Controls.Add(_txtBox);
            this.Controls.Add(_imgCal);
            if (Validation.IsNotNull(CalendarInit))
            {
                this.CalendarInit(this, EventArgs.Empty);
            }
            WebResource.RegisterPageScript(this.Page, DateScriptRes);

            ClientScript __styleScript = new ClientScript(this, AbsoluteFilesPath.DateStyle, string.Format("<link href=\"{0}\" type=\"text/css\" rel=\"stylesheet\">", AbsoluteFilesPath.DateStyle));
            __styleScript.StartupScript = true;
            __styleScript.Register();
        }

        private string GetOnClientClick()
        {
            return string.Format("OpenDefaultCalendar('{0}', '{1}', {2});return false;", _txtBox.ClientID, CultureInfo.CurrentUICulture.DateTimeFormat.ShortDatePattern, this.AutoCallBack ? "true" : "false");
        }

        #endregion M�thodes

        #region Evenements

        /// <summary>Occurs when the control is about to render to its containing control. </summary>
        /// <param name="args">The <see cref="EventArgs"/> that contains event data. </param>
        /// <remarks>This method generate client script used by the calendar control if <see cref="AddButton"/> is set to <see langword="true"/>. </remarks>
        protected override void OnPreRender(EventArgs args)
        {
            base.OnPreRender(args);
            if (_addButton)
            {
                //string __openScript = string.Format("window.open('{0}?FormName=MainForm&CtrlName={1}&value=' + document.getElementById('{2}').value + '&postid={3}&callid={4}', 'PopUpCalendar', 'width=280,height=230,top=200,left=200,toolbars=no,scrollbars=no,status=no,resizable=no');return false;", AbsoluteFilesPath.CalendarPage , _txtBox.UniqueID, _txtBox.ClientID, this.AutoPostBack?_txtBox.ClientID:"", this.AutoCallBack?_txtBox.ClientID:"");    
                string __openScript = GetOnClientClick();
                _imgCal.Attributes.Add("onclick", __openScript);
            }
            string __completeDate = string.Format("CompleteDate(this, '{0}');", CultureInfo.CurrentUICulture.DateTimeFormat.ShortDatePattern); //'dd/MM/yyyy'
            if (this.AutoPostBack || this.AutoCallBack)
            {
                _txtBox.Attributes["onchange"] = __completeDate;
            }
            else
            {
                _txtBox.Attributes["onblur"] = __completeDate;
            }
            this._imgCal.Visible = _addButton;
        }

        private void OnDateChange(object sender, EventArgs ea)
        {
            if (Validation.IsNotNull(this.DateChanged)) this.DateChanged(this, EventArgs.Empty);
        }

        #endregion Evenements

        #region Propri�t�s

        /// <summary>Gets or sets if the BaseCalendar is enable or not. </summary>
        public override bool Enabled
        {
            get { return base.Enabled; }
            set
            {
                this.AddButton = value;
                _txtBox.Enabled = value;
            }
        }

        /// <summary>Gets or sets the current selected/entered date. </summary>
        public string SelectedDate
        {
            get { return _txtBox.Text; }
            set { _txtBox.Text = value; }
        }

        /// <summary>Gets or sets if calendar control display it's button. </summary>
        public bool AddButton
        {
            get { return _addButton; }
            set { _addButton = value; }
        }

        public bool AutoPostBack
        {
            get { return _txtBox.AutoPostBack; }
            set { _txtBox.AutoPostBack = value; }
        }

        public bool AutoCallBack
        {
            get { return _txtBox.AutoCallBack; }
            set { _txtBox.AutoCallBack = value; }
        }

        public bool EnableCallBack
        {
            get { return _txtBox.EnableCallBack; }
            set { _txtBox.EnableCallBack = value; }
        }

        /// <summary>
        /// Type d'ajaxisation
        /// </summary>
        public Anthem.AjaxMode AjaxMode
        {
            get { return this._txtBox.AjaxMode; }
            set { this._txtBox.AjaxMode = value; }
        }

        /// <summary>
        /// Attribut de la textbox contenu dans le control
        /// </summary>
        public AttributeCollection TextBoxAttributes
        {
            get
            {
                return _txtBox.Attributes;
            }

        }
        /// <summary>
        /// ClientID de la textbox contenu dans le control
        /// </summary>
        public string TextBoxClientID
        {
            get
            {
                return _txtBox.ClientID;
            }

        }

        /// <summary>
        /// Gets or sets if the textbox is enable or not
        /// </summary>
        public bool EnabledTextbox
        {
            get { return _txtBox.Enabled; }
            set { _txtBox.Enabled = value; }
        }

        #endregion Propri�t�s
    }


}

