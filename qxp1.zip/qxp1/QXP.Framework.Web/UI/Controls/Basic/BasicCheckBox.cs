using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace QXP.Framework.Web.UI.Controls.Basic{
	/// <summary>Displays a check box that allows the user to select a true or false condition. </summary>
	[ValidationProperty("Checked")]
	public class CheckBox : Anthem.CheckBox, ICausesValidation
    {
		#region internal variables
		private static readonly string DefaultCss = Basic.CssClass.chk.ToString();
		private const string KeyArg = "Arg";
		#endregion
		/// <summary>Initializes a new instance of <see cref="CheckBox"/> control. </summary>
		public CheckBox(){
			base.CssClass               = DefaultCss;
            this.EnabledDuringCallBack  = false;
		}
		/// <summary>Initializes a new instance of <see cref="CheckBox"/> control. </summary>
		/// <param name="text">The text label associated with the CheckBox. </param>
		public CheckBox(string text): this(){
			if(Validation.IsSet(text))	this.Text = text;
		}
		/// <summary>Initializes a new instance of <see cref="CheckBox"/> control. </summary>
		/// <param name="text">The text label associated with the CheckBox. </param>
		/// <param name="cssClass">The Cascading Style Sheet used for rendering the control. </param>
		public CheckBox(string text, string cssClass): this(text){
			if(Validation.IsSet(cssClass))	this.CssClass = cssClass;
		}
		/// <summary>Initializes a new instance of <see cref="CheckBox"/> control. </summary>
		/// <param name="text">The text label associated with the CheckBox. </param>
		/// <param name="cssClass">The Cascading Style Sheet used for rendering the control. </param>
		/// <param name="checked">A value indicating whether the CheckBox control is checked. </param>
		public CheckBox(string text, string cssClass, bool @checked): this(text, cssClass){
			this.Checked = @checked; 
		}
		/// <summary>Initializes a new instance of <see cref="CheckBox"/> control. </summary>
		/// <param name="text">The text label associated with the CheckBox. </param>
		/// <param name="cssClass">The Cascading Style Sheet used for rendering the control. </param>
		/// <param name="checked">A value indicating whether the CheckBox control is checked. </param>
		/// <param name="enabled">A value indicating whether the CheckBox control is enabled. </param>
		public CheckBox(string text, string cssClass, bool @checked, bool enabled): this(text, cssClass, @checked){
			this.Enabled = enabled; 
		}
		/// <summary>Gets the <see cref="Object"/> argument of the <see cref="CheckBox"/>. </summary>
		public object						Argument{
			get{return this.ViewState[KeyArg];}
			set{this.ViewState[KeyArg] = value;}
		}
        protected override void OnCheckedChanged(EventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnCheckedChanged(e);
        }
 	}
}