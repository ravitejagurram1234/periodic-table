using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using QXPResources = QXP.Framework.Resources;
using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls.Basic
{

    /// <summary>
    /// Basic View � ajouter dans un basic multiview
    /// </summary>
    /// <author> MDO </author>
    /// <date> </date>    
    public class View : Anthem.View, QXPResources.IResource
    {
        #region Membres
        private WebControl _container = new WebControl();
        private WebControlSection _body = new WebControlSection();
        private List<BaseValidator> _list = new List<BaseValidator>();
        private Component.BaseComponent _hostComponent;
        //Nom (Type) du controle en cours
        private string _rs;
        protected QXPResources.ResourceInfo _resourceInfo;
        #endregion Membres

        #region Constantes
        private const string VSTitle = "Title";
        private const string VSEnabled = "Enabled";
        private const string VSEnabledCallBack = "EnableCallBack";
        private const string VSCausesValidation = "CausesValidation";
        private const string VSValidationGroup = "ValidationGroup";

        private const string Css_View = "Css_view";
        private const string Css_Body = "Css_view_body";
        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de View: Anthem.View, QXPResources.IResource{
        /// </summary>
        public View()
        {
            VisibleInTab = true;
            this.InitRessourceInfo();
            this.Controls.Add(_container);
            _container.Controls.Add(_body);
            _container.CssClass = Css_View;
            _body.CssClass = Css_Body;
        }

        #endregion Constructeur

        #region M�thodes

        protected virtual void InitRessourceInfo()
        {
            _rs = this.GetType().Name;
            _resourceInfo = new QXPResources.ResourceInfo();
            _resourceInfo.SetInfo(null, _rs);
        }
        protected override void OnInit(EventArgs e)
        {
            _hostComponent = new HostNamingFinder<Component.BaseComponent>().GetHost(this);
            base.OnInit(e);
        }

        /// <summary>
        /// Ajoute une CssClass � la vue sans �craser celles deja pr�sentes
        /// </summary>
        /// <param name="cssClass">Nom de la class cass</param>
        protected void AddCssClass(string cssClass)
        {
            _container.CssClass = string.Concat(_container.CssClass, QXPFrk.Constantes.Space, cssClass).Trim();
        }

        #endregion M�thodes

        #region Propri�t�s

        public WebControlSection Body
        {
            get { return _body; }
        }
        
        public WebControl Container
        {
            get { return _container; }
        }
        
        public string CssClass
        {
            get { return _container.CssClass; }
            set { _container.CssClass = value; }
        }
        
        public string Title
        {
            get { return Conversion.ToString(this.ViewState[VSTitle]); }
            set { this.ViewState[VSTitle] = value; }
        }
        
        public virtual bool Enabled
        {
            get
            {
                if (Validation.IsNotSet(this.ViewState[VSEnabled])) return true;
                else return Conversion.ToBool(this.ViewState[VSEnabled]);
            }
            set { this.ViewState[VSEnabled] = value; }
        }

        public bool CausesValidation
        {
            get { return Conversion.ToBool(this.ViewState[VSCausesValidation]); }
            set { this.ViewState[VSCausesValidation] = value; }
        }
        
        public string ValidationGroup
        {
            get { return Conversion.ToString(this.ViewState[VSValidationGroup]); }
            set { this.ViewState[VSValidationGroup] = value; }
        }
        
        /// <summary>
        /// Indique si la vue doit �tre visible dans le MultiView
        /// </summary>
        public bool VisibleInTab
        {
            get;
            set;
        }

        public Component.BaseComponent HostComponent
        {
            get { return _hostComponent; }
        }

        #region IResource
        public QXPResources.ResourceInfo ResourceInfo
        {
            get { return _resourceInfo; }
        }

        /// <summary>
        /// Resource Section de la View
        /// </summary>
        protected string RS
        {
            get { return this._rs; }
        }
        #endregion

        #endregion Propri�t�s

        #region Ajax Stuff
        public bool EnabledCallBack
        {
            get
            {
                if (Validation.IsNotSet(this.ViewState[VSEnabledCallBack])) return true;
                else return Conversion.ToBool(this.ViewState[VSEnabledCallBack])
;
            }
            set { this.ViewState[VSEnabledCallBack] = value; }
        }
        #endregion
    }


}