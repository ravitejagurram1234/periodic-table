using System;
using System.Collections.Specialized;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace QXP.Framework.Web.UI.Controls.Basic{
	/// <summary>Displays a check box that allows the user to select a true or false condition. </summary>
	[ValidationProperty("Checked")]
	public class CheckButtonImage : WebControl, System.Web.UI.IPostBackDataHandler{
		#region internal variables
		private const				string KeyArg				= "Arg";
		private const				string VSTextChecked		= "CheckedText";
		private const				string VSToolTipChecked	    = "CheckedToolTip";
		private const				string VSCssChecked		    = "CheckedCss";
		private const				string VSTextUnChecked		= "UnCheckedText";
		private const				string VSToolTipUnChecked	= "UnCheckedToolTip";
		private const				string VSCssUnChecked		= "UnCheckedCss";
		private const				string VSDataID				= "DataID";
		private const				string VSAutoPostBack		= "AutoPostBack";
		private const				string VSAutoCallBack		= "AutoCallBack";
		private const				string VSValidationGroup    = "ValidationGroup";
		private const				string KeyChecked			= "Checked";
		private const				string KeyCausesValidation	= "CausesValidation";
		private const				string DataIDTemplate		= "{0}_data";
		private						string						_dataID;
		private						string						_onToggleClickScript = string.Empty;

		/// <summary>Occured when the Checked property change. </summary>
		public event EventHandler			CheckedChanged;

		#endregion
		/// <summary>Initializes a new instance of <see cref="CheckButtonImage"/> control. </summary>
		public CheckButtonImage(): base("A"){

		}
		/// <summary>Initializes a new instance of <see cref="CheckButtonImage"/> control. </summary>
		/// <param name="checkedText">The text label displayed when the control is checked. </param>
		/// <param name="uncheckedText">The text label displayed when the control is not checked.. </param>
		public CheckButtonImage(string checkedText, string uncheckedText): this(){
			if(Validation.IsSet(checkedText))		this.CheckedText	= checkedText;
			if(Validation.IsSet(uncheckedText))		this.UnCheckedText	= uncheckedText;
		}
		/// <summary>Initializes a new instance of <see cref="CheckButtonImage"/> control. </summary>
		/// <param name="checkedText">The text label displayed when the control is checked. </param>
		/// <param name="uncheckedText">The text label displayed when the control is not checked.  </param>
		/// <param name="checkedCssClass">The Cascading Style Sheet used when the control is not checked. </param>
		/// <param name="uncheckedCssClass">The Cascading Style Sheet used when the control is not checked. </param>
		public CheckButtonImage(string checkedText, string uncheckedText, string checkedCssClass, string uncheckedCssClass): this(checkedText, uncheckedText){
			if(Validation.IsSet(checkedCssClass))		this.CheckedCssClass	= checkedCssClass;
			if(Validation.IsSet(uncheckedCssClass))		this.UnCheckedCssClass	= uncheckedCssClass;
		}
		/// <summary>Initializes a new instance of <see cref="CheckButtonImage"/> control. </summary>
		/// <param name="checkedText">The text label displayed when the control is checked. </param>
		/// <param name="uncheckedText">The text label displayed when the control is not checked.  </param>
		/// <param name="checkedCssClass">The Cascading Style Sheet used when the control is not checked. </param>
		/// <param name="uncheckedCssClass">The Cascading Style Sheet used when the control is not checked. </param>
		/// <param name="checked">A value indicating whether the CheckButtonImage control is checked. </param>
		public CheckButtonImage(string checkedText, string uncheckedText, string checkedCssClass, string uncheckedCssClass, bool @checked): this(checkedText, uncheckedText, checkedCssClass, uncheckedCssClass){
			this.Checked = @checked; 
		}
		/// <summary>Initializes a new instance of <see cref="CheckButtonImage"/> control. </summary>
		/// <param name="checkedText">The text label displayed when the control is checked. </param>
		/// <param name="uncheckedText">The text label displayed when the control is not checked.  </param>
		/// <param name="checkedCssClass">The Cascading Style Sheet used when the control is not checked. </param>
		/// <param name="uncheckedCssClass">The Cascading Style Sheet used when the control is not checked. </param>
		/// <param name="checked">A value indicating whether the CheckButtonImage control is checked. </param>
		/// <param name="enabled">A value indicating whether the CheckButtonImage control is enabled. </param>
		public CheckButtonImage(string checkedText, string uncheckedText, string checkedCssClass, string uncheckedCssClass, bool @checked, bool enabled): this(checkedText, uncheckedText, checkedCssClass, uncheckedCssClass, @checked){
			this.Enabled = enabled; 
		}
		/// <summary>Occurs when the <see cref="CheckButtonImage"/> is initializing. </summary>
		/// <param name="ea">The <see cref="EventArgs"/> that contains event data. </param>
		protected override	void					OnInit(EventArgs ea){
			base.OnInit(ea);
			this.ID							= this.ID;
			_dataID							= string.Format(DataIDTemplate, this.ClientID);
			this.ViewState[VSDataID]		= _dataID;
		}
		/// <summary>Gets or sets a value indicating whether the <see cref="CheckButtonImage"/> control is checked. </summary>
		public bool									Checked{
			get{return Conversion.ToBool(this.ViewState[KeyChecked]);}
			set{this.ViewState[KeyChecked] = value;}
		}
		/// <summary>Gets or sets the cascading style sheet (Css) when the control is checked. </summary>
		public string								CheckedCssClass{
			get{return Conversion.ToString(this.ViewState[VSCssChecked]);}
			set{this.ViewState[VSCssChecked] = value;}
		}
		/// <summary>Gets or sets the displayed text when the control is checked. </summary>
		public string								CheckedText{
			get{return Conversion.ToString(this.ViewState[VSTextChecked]);}
			set{this.ViewState[VSTextChecked] = value;}
		}
		/// <summary>Gets or sets the tooltip text when the control is checked. </summary>
		public string								CheckedToolTip{
			get{return Conversion.ToString(this.ViewState[VSToolTipChecked]);}
			set{this.ViewState[VSToolTipChecked] = value;}
		}
		/// <summary>Gets or sets the cascading style sheet (Css) when the control is not checked. </summary>
		public string								UnCheckedCssClass{
			get{return Conversion.ToString(this.ViewState[VSCssUnChecked]);}
			set{this.ViewState[VSCssUnChecked] = value;}
		}
		/// <summary>Gets or sets the displayed text when the control is unchecked. </summary>
		public string								UnCheckedText{
			get{return Conversion.ToString(this.ViewState[VSTextUnChecked]);}
			set{this.ViewState[VSTextUnChecked] = value;}
		}
		/// <summary>Gets or sets the tooltip text when the control is unchecked. </summary>
		public string								UnCheckedToolTip{
			get{return Conversion.ToString(this.ViewState[VSToolTipUnChecked]);}
			set{this.ViewState[VSToolTipUnChecked] = value;}
		}
		/// <summary>Gets the <see cref="Object"/> argument of the <see cref="CheckButtonImage"/>. </summary>
		public object								Argument{
			get{return this.ViewState[KeyArg];}
			set{this.ViewState[KeyArg] = value;}
		}
		/// <summary>Gets or sets if CheckButtonImage raise a post back event when it's state changed. </summary>
		public bool									AutoPostBack{
			get{return Conversion.ToBool(this.ViewState[VSAutoPostBack]);}
			set{this.ViewState[VSAutoPostBack] = Conversion.ToString(value);}
		}
		/// <summary>Gets or sets if CheckButtonImage raise a call back event when it's state changed. </summary>
		public bool									AutoCallBack{
			get{return Conversion.ToBool(this.ViewState[VSAutoCallBack]);}
			set{this.ViewState[VSAutoCallBack] = Conversion.ToString(value);}
		}
		/// <summary>Gets or sets the Validation Group. </summary>
		public string							    ValidationGroup{
			get{return Conversion.ToString(this.ViewState[VSValidationGroup]);}
			set{this.ViewState[VSValidationGroup] = Conversion.ToString(value);}
		}
		/// <summary>Gets or sets if CheckButtonImage Cause Form validation on postback. </summary>
		/// <remarks>AutoPostBack must be set to true, if CausesValidation is set to true. </remarks>
		public bool									CausesValidation{
			get{return Conversion.ToBool(this.ViewState[KeyCausesValidation]);}
			set{this.ViewState[KeyCausesValidation] = value;}
		}
		public string								OnToggleClickScript{
			get{return _onToggleClickScript;}
			set{_onToggleClickScript = value;}
		}
		public string								DataID{
			get{return _dataID;}
		}
		/// <summary>Occurs when the <see cref="CheckButtonImage"/> is about to render to its containing control. </summary>
		/// <param name="ea">The <see cref="EventArgs"/> that contains event data. </param>
		protected override	void					OnPreRender(EventArgs ea){
			base.OnPreRender(ea);
			string __dataValue;
			if (this.Checked)	__dataValue = bool.TrueString;
			else				__dataValue = bool.FalseString;

			this.Page.ClientScript.RegisterHiddenField(_dataID, __dataValue);
            if(this.Page.IsPostBack){
                ClientScript _updateScript = new ClientScript(this, "Update" + this.ClientID, string.Format("document.getElementById('{0}').value = '{1}'", _dataID, __dataValue), true);

                //ClientScript _updateScript = new ClientScript(this, "Update" + this.ClientID, string.Format("alert(document.getElementById('{0}').value);", _dataID, __dataValue));
                _updateScript.RegisterForClientSideEval();
            }

			ClientScript __styles			= new ClientScript(this,"CSS_CheckbuttonImage",  string.Format("<link href=\"{0}\" type=\"text/css\" rel=\"stylesheet\">", AbsoluteFilesPath.CheckedButtonImageStyle));
			__styles.Register();
			if (Validation.IsNotNull(this.Page) && this.Enabled && this.Visible) 
			{
				this.Page.RegisterRequiresPostBack(this);
				this.Page.RegisterClientScriptBlock("checkButtonImage", string.Format("<script language=\"javascript\" src=\"{0}\"></script>", AbsoluteFilesPath.CheckedButtonImageScript));
			}
			if(this.Checked)	this.CssClass = this.CheckedCssClass;
			else				this.CssClass = this.UnCheckedCssClass;
		}

		bool System.Web.UI.IPostBackDataHandler.LoadPostData(string postDataKey, NameValueCollection postCollection) {
			bool		__newChecked	= Conversion.ToBool(postCollection[_dataID]);
			bool		__oldChecked	= this.Checked;
			
			if (!__oldChecked.Equals(__newChecked)) {
				this.Checked = __newChecked;
				return true; 
			}
			return false; 
		}
		void System.Web.UI.IPostBackDataHandler.RaisePostDataChangedEvent() {
			this.OnCheckedChanged(this, EventArgs.Empty);
		}
		/// <summary>Occured when the checked property changed. </summary>
		/// <param name="sender">the <see cref="CheckButtonImage"/> on which occured change. </param>
		/// <param name="ea">The <see cref="EventArgs"/> associated with the modification. </param>
		protected virtual void						OnCheckedChanged(object sender, EventArgs ea){
			if(Validation.IsNotNull(CheckedChanged)){
				this.CheckedChanged(this, ea);
			}
		}
		/// <summary>Occurs when the control need to render it's attributes. </summary>
		/// <param name="writer">The <see cref="HtmlTextWriter"/> to write in. </param>
		protected override void						AddAttributesToRender(HtmlTextWriter writer) {
				if (Validation.IsNotNull(this.Page)) {
					this.Page.VerifyRenderingInServerForm(this);
				}
				base.AddAttributesToRender(writer);
				writer.AddAttribute(HtmlTextWriterAttribute.Name, this.UniqueID);
				string	__hRefScript				= string.Empty;
				string	__callName					= string.Empty;
				string	__onClickScript;
				string	__fullOnScriptScript;
				if(Validation.IsSet(_onToggleClickScript))
				{
					__callName				= "ToggleReturn";	
					__fullOnScriptScript	= _onToggleClickScript;
				}
				else
				{
					__callName				= "ToggleNoReturn";	
					__fullOnScriptScript	= "{0}";
				}
				__onClickScript = string.Format("{0}('{1}', '{2}', '{3}', '{4}', '{5}', '{6}')", __callName, this.ClientID, _dataID, this.CheckedCssClass, this.UnCheckedCssClass, this.CheckedText, this.UnCheckedText);//  , this.CheckedText, this.UnCheckedText //   , this.ClientID);
				__onClickScript = string.Format(__fullOnScriptScript, __onClickScript);
				
				if (this.Enabled){
					if(Validation.IsNotNull(this.Page) && (this.AutoCallBack || this.AutoPostBack)) {
                        if(this.AutoCallBack){
                            __onClickScript		= string.Format("javascript:{0};{1};", __onClickScript, RenderUtility.GetCallFireEventReferenceSansJS(this.ClientID));//, null, this.CausesValidation, this.ValidationGroup, null, null, true, null, null, null));
                        }else if(this.AutoPostBack){
						    if (this.CausesValidation && this.Page.Validators.Count > 0) {
							    __onClickScript		= string.Format("{{{0};{1};}}", __onClickScript, this.Page.GetPostBackEventReference(this));
							    __onClickScript		= String.Concat("javascript:", RenderUtility.GetClientValidatedPostback(this, __onClickScript));
						    }else{
							    __onClickScript		= String.Concat("javascript:", __onClickScript, ";", this.Page.GetPostBackEventReference(this), ";");
						    }
                        }
					}else{
						__onClickScript = String.Concat("javascript:", __onClickScript, ";");
					}
				}else{
					__onClickScript = "javascript:void(0);";
				}
				writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0);", false);
				writer.AddAttribute(HtmlTextWriterAttribute.Onclick, __onClickScript, false);
				//writer.AddAttribute(HtmlTextWriterAttribute.Href, __onClickScript, false);
		}
		/// <summary>Occurs when the CheckButtonImage need to render it's content. </summary>
		/// <param name="writer"></param>
  		protected override void						RenderContents(HtmlTextWriter writer) {
			if(this.Checked){
				if(Validation.IsSet(this.CheckedText))		writer.Write(this.CheckedText);
			}else{
				if(Validation.IsSet(this.UnCheckedText))	writer.Write(this.UnCheckedText);
			}
		}
	}
}