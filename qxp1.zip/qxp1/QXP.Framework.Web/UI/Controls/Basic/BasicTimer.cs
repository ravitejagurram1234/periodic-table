using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;



namespace QXP.Framework.Web.UI.Controls.Basic
{
    ///<summary>Provides methods and properties to generate a client script timer that can raise server side event. </summary>
    public class Timer : Control, IPostBackEventHandler 
    {
        #region internal variables
        private int				_interval			= 0;
		private Anthem.AjaxMode _ajaxMode			= Anthem.AjaxMode.Anthem;
        private const	string	VSEnable	        = "Enabled";
        private const	string	VSEnableCallBack	= "EnabledCallBack";
        #endregion
        /// <summary>Occurs when the <see cref="Interval"/> elapses. </summary>
        public event EventHandler Tick;

        /// <summary>Creates a new instance of <see cref="Timer"/> control. </summary>
        public Timer(){}

        /// <summary>Creates a new instance of <see cref="Timer"/> control with the specified <paramref name="interval"/>. </summary>
        /// <param name="interval">The <see cref="Int32"/> value of the <see cref="Interval"/> in milliseconds. </param>
        public Timer(int interval)
        {
            _interval = interval;
        }

		/// <summary>
		/// D�finit le mode Ajax utilis� (Def Anthem)
		/// </summary>
		public Anthem.AjaxMode AjaxMode
		{
			get
			{
				return _ajaxMode;
			}
			set
			{
				_ajaxMode = value;
			}
		}

        /// <summary>
		/// Gets or sets the interval in  milliseconds at which to raise the <see cref="Elapsed"/> event. 
		/// </summary>
        public int								Interval 
        {
            get {return _interval;}
            set {_interval = value;}
        }
        /// <summary>
        /// Gets or sets if the current control timer raise event.
        /// </summary>

        public bool								Enabled 
        {
            get {return Conversion.ToBool(this.ViewState[VSEnable]);}
            set {this.ViewState[VSEnable] = value;}
        }

		/// <summary>
		/// Les callbacks Anthem ajax sont-ils autoris�s
		/// </summary>
        public bool                             EnableCallBack {
            get {
                if (ViewState[VSEnableCallBack] == null)
                    return true;
                else
                    return (bool)ViewState[VSEnableCallBack];
            }
            set {
                ViewState[VSEnableCallBack] = value;
            }
        }
        /// <summary>
        /// Raises the <see cref="System.Web.UI.Control.Load"/> event and registers the control
        /// with <see cref="Anthem.Manager"/>.
        /// </summary>
        /// <param name="e">A <see cref="System.EventArgs"/>.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            
			if (AjaxMode == Anthem.AjaxMode.Anthem)
                Anthem.Manager.Register(this);
            else if (AjaxMode == Anthem.AjaxMode.AjaxNet)
            {
                if (Validation.IsNotNull(ScriptManager))
                {
                    //�valuation de clientId pour que l'id soit valu� par .Net
                    this.EnsureID();
                    if (EnableCallBack)
                        ScriptManager.RegisterAsyncPostBackControl(this);
                    else
                        ScriptManager.RegisterPostBackControl(this);
                }
                else if (EnableCallBack)
                    throw new Exception("ScriptManager manquant � la page, l'ajaxisation .NET ne peut �tre utilis�.");
            }
        }

        /// <summary>Occurs when the timer is about to render to its containing control. </summary>
        /// <param name="ea">The <see cref="EventArgs"/> that contains event data. </param>
        /// <remarks>This method add client script to the page. </remarks>
        protected override void		            OnPreRender(EventArgs ea) 
        {
            if (_interval > 0) 
            {
				if (_ajaxMode == Anthem.AjaxMode.Anthem)
				{
					if (EnableCallBack)
					{
						if (!Anthem.Manager.IsCallBack)
						{
							// Always register the var that will track the timer.
							string script = string.Format("<script type=\"text/javascript\">var {0}_timer = null;</script>", this.ClientID);
							Page.ClientScript.RegisterStartupScript(this.GetType(), script, script, false);

							// For the initial page load, register the timer script so that it loads after
							// the page is finished loading.
							if (Enabled)
							{
								script = string.Format("<script type=\"text/javascript\">{0}</script>", GetCallSetTimeoutScript());
								Page.ClientScript.RegisterStartupScript(this.GetType(), script, script, false);
							}
						}
						else
						{
							// If this is a callback, add a script to call the timer again or to stop the timer.
							if (Enabled)
							{
								Anthem.Manager.AddScriptForClientSideEval(GetCallSetTimeoutScript());
							}
							else
							{
								Anthem.Manager.AddScriptForClientSideEval(GetCallClearTimeoutScript());
							}

						}
					}
					else
					{
						if (this.Enabled)
						{
							StringBuilder __sb = new StringBuilder();
							__sb.Append("\n<script language=\"javascript\"> \n <!-- \n setTimeout(function(){ ");
							__sb.Append(this.Page.ClientScript.GetPostBackEventReference(this, ""));
							__sb.Append("}, ");
							__sb.Append(_interval.ToString());
							__sb.Append("); \n // --> \n </script>");
							string __script = __sb.ToString();
							//INFO mettre le script dans la clef et le script permet d'avoir plusieur timer sur la page !
							this.Page.ClientScript.RegisterStartupScript(this.GetType(), __script, __script);
						}
					}
				}
				else
				{
					if (this.Enabled)
					{
						StringBuilder __sb = new StringBuilder();
						__sb.Append("setTimeout(function(){");
						__sb.Append(this.Page.ClientScript.GetPostBackEventReference(this, string.Empty));
						__sb.Append("}, ");
						__sb.Append(_interval.ToString());
						__sb.Append(")");
						string __script = __sb.ToString();
						if (ScriptManager.IsInAsyncPostBack)
						{
							ScriptManager.RegisterStartupScript(this, this.GetType(), "OnTick", __script, true);
						}
						else
						{
							ClientScript __clientScript = new ClientScript(this, "OnTick", __script, true);
							__clientScript.Register();
						}
					}
				}
            }
        }

        /// <summary>Notifies the server control that caused the postback that it should handle an incoming post back event.  </summary>
        /// <param name="eventArgument">The post-back argument. </param>
        public void								RaisePostBackEvent(string eventArgument) 
        {
            OnTick(new EventArgs());
        }

        /// <summary>Raises the <see cref="Elapsed"/> event. </summary>
        /// <param name="ea">The <see cref="EventArgs"/> argument of the event. </param>
        public void								OnTick(EventArgs ea) 
        {
            if (Enabled && (Tick != null))
            {
                Tick(this, ea);
            }
        }

        /// <summary>
        /// Permet de r�cup�rer le script pour d�finir le timer client associ� au control
        /// </summary>
        /// <returns></returns>
        private string                          GetCallSetTimeoutScript()
        {
            return string.Format("{0} {1}_timer = setTimeout(function() {{ try{{ Anthem_FireEvent('{2}', '', function() {{ }}, '' , true, true)}}catch(e){{}} }}, {3})",
                GetCallClearTimeoutScript(),
                ClientID,
                UniqueID,                
                Interval
            );
        }

        /// <summary>
        /// Permet de r�cup�rer le script pour annuler le timer client associ� au control
        /// </summary>
        /// <returns></returns>
		private string                          GetCallClearTimeoutScript()
        {
            return string.Format("if (typeof({0}_timer) != 'undefined' && {0}_timer != null) {{ clearTimeout({0}_timer); {0}_timer = null; }}", ClientID);
        }
                /// <summary>
        /// Visible is inherited from Control, but ignored by Timer.
        /// </summary>
        public override     bool                Visible
        {
            get { return true; }
            set {}
        }

        /// <summary>
        /// ScriptManager AjaxNet (utilis� pour l'ajax .net)
        /// </summary>
        private ScriptManager					ScriptManager
        {
            get { return ScriptManager.GetCurrent(Page); }
        }

     }
}