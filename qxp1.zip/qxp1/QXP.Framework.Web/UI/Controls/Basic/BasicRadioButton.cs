using System;
using System.Collections;
using System.Globalization;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPFrk											= QXP.Framework;
using QXPData											= QXP.Framework.Data;

namespace QXP.Framework.Web.UI.Controls.Basic{
	/// <summary>Represents a control that allows the user to select a single item from a RadioButton List.	</summary>
	//INFO: we had to repimplement IRepeatInfoUser to customize IRepeatInfoUser.RenderItem method then add onclick script.
	public class RadioButton: Anthem.RadioButton, ICausesValidation
	{
		#region internal variables
		private static readonly string	DefaultCss				= Basic.CssClass.rdbtn.ToString();
		private object _value;
		#endregion
		/// <summary>Creates a new instance of <see cref="RadioButtonList"/> control. </summary>
		public RadioButton()
		{
			base.CssClass               = DefaultCss;
            this.EnabledDuringCallBack  = false;
		}
		/// <summary>Gets or sets the cascading style sheet (CSS) used to render control. </summary>
		public		override	string	CssClass
		{
			get{return base.CssClass;}
			set{base.CssClass = string.Concat(base.CssClass, QXPFrk.Constantes.Space, value).Trim();}		 
		}
		public                  object  Value
		{
			get{return _value;}
			set{_value = value;}
		}
        protected   override    void    OnCheckedChanged(EventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnCheckedChanged(e);
        }
	}
}
