using System;
using System.Globalization;
using System.Text;
using System.Web;
using System.Web.UI;
using MSWebControls = System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	// PROTOTYPE ! VRAIMENT MAIS VRAIMENT PAS TERMINE !!!
    /// <summary>Provides methods and properties of a popup control. </summary>
	public class Popup: WebControl{
		#region Internal variables
        WebControlSection _body;
        private const string VSShow = "Show";
        private bool    _visibilityChanged = false;
		#endregion
		/// <summary>Creates a new instance of <see cref="Popup"/> control. </summary>
		public Popup(){
            _body           = new WebControlSection();
            _body.CssClass  = "Css_Popup_Body";
		}
        protected override void OnInit(EventArgs e) {
            //((QXPPage)this.Page).Headers.AddScript("scripts/popup.js");
            base.OnInit(e);
            this.CssClass   = "Css_Popup";
            this.Controls.Add(_body);
        }
        public WebControlSection Body{
            get{return _body;}
        }
        public      bool        Show{
            get{
                return Conversion.ToBool(this.ViewState[VSShow]);
            }
            set{
                //if(value && Conversion.ToBool(this.ViewState[VSShow]) != value ) _visibilityChanged = true;
                this.ViewState[VSShow]      = value;
                this.UpdateAfterCallBack    = true;
            }
        }
        protected override void OnPreRender(EventArgs e) {
            base.OnPreRender(e);
            if(this.Show)   this.Style[HtmlTextWriterStyle.Display] = "block";
            else            this.Style[HtmlTextWriterStyle.Display] = "none";
            ClientScript __script = new ClientScript(this, "InitPopup" + this.ClientID, string.Format("QXP.UI.Popup.create('{0}');", this.ClientID), true);
            __script.RegisterForClientSideEval();
        }
	}
}

