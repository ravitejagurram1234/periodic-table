using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace QXP.Framework.Web.UI.Controls.Basic{
    public class TabsControl: WebControl{
        List<Tab> _tabs = new List<Tab>();
        public TabsControl(): base(HtmlTextWriterTag.Div){}
        public List<Tab> Tabs{
            get{return _tabs;}
        }
        protected override void OnInit(EventArgs e) {
            base.OnInit(e);
            foreach(Tab __tab in _tabs){
                this.Controls.Add(__tab);
            }
        }
    }
    public class Tab: WebControl, IPostBackEventHandler{
            private const string VSActive               = "Active";
            private const string VSEnabledCallBack      = "EnabledCallBack";
            private const string VSCausesValidation     = "VSCausesValidation";
            private const string VSValidationGroup      = "VSValidationGroup";
            private const string VSCommand              = "CommandName";
            private const string VSArgument             = "CommandArgument";
            private const string VSText                 = "Text";
            private const string DefaultCss             = "tab";
            private const string ActiveCss              = "tab_active";
            private const string HoverCss               = "tab_hover";
            private const string InnerCss               = "tab_inner";
            private const string OuterCss               = "tab_outer";
            private const string TabCss                 = "tab_tab";
            public event EventHandler         Click;
            public event CommandEventHandler  Command;
            WebControl __outer  = new WebControl();
            WebControl __inner  = new WebControl();
            WebControl __tab    = new WebControl();

        public Tab(){}
        public      bool                    CausesValidation{
            get{return Conversion.ToBool(this.ViewState[VSCausesValidation]);}
            set{this.ViewState[VSCausesValidation] = value;}
        }
        public      string                  ValidationGroup{
            get{return Conversion.ToString(this.ViewState[VSValidationGroup]);}
            set{this.ViewState[VSValidationGroup] = value;}
        }
        protected   override void           OnInit(EventArgs e) {
            base.OnInit(e);
            __outer.CssClass = OuterCss;
            __inner.CssClass = InnerCss;
            __tab.CssClass   = TabCss;
            this.Controls.Add(__outer);
            __outer.Controls.Add(__inner);
            __inner.Controls.Add(__tab);
        }
        public      bool                    Active{
            get{return Conversion.ToBool(this.ViewState[VSActive]);}
            set{this.ViewState[VSActive] = value;}
        }
        public      bool                    EnabledCallBack{
            get{
                if(Validation.IsSet(this.ViewState[VSEnabledCallBack]))     return Conversion.ToBool(this.ViewState[VSEnabledCallBack]);
                else                                                        return true;
            }
            set{this.ViewState[VSEnabledCallBack] = value;}
        }
        public      string                  Text{
            get{return Conversion.ToString(this.ViewState[VSText]);}
            set{this.ViewState[VSText] = value;}
        }
        public      string                  CommandName{
            get{return Conversion.ToString(this.ViewState[VSCommand]);}
            set{this.ViewState[VSCommand] = value;}
        }
        public      string                  Argument{
            get{return Conversion.ToString(this.ViewState[VSArgument]);}
            set{this.ViewState[VSArgument] = value;}
        }
        protected   override void           OnPreRender(EventArgs e) {
            base.OnPreRender(e);
            __tab.Controls.Add(new LiteralControl(this.Text));
        }
        public      override void           RenderBeginTag(HtmlTextWriter writer) {
            //INFO: �crire �a ici permet de modifier le rendu de la css sans sa valeur !
            if(this.Active){
                this.CssClass = ActiveCss;
            }else{
                if(this.Enabled){
                    if(this.EnabledCallBack){
                        this.Attributes["onclick"]      = RenderUtility.GetCallFireEventReferenceSansJS(this.UniqueID, this.Argument);
                    }else{
                        this.Attributes["onclick"]      = RenderUtility.GetPostBackEventReference(this, this.Argument);
                    }
                    this.Attributes["onmouseover"]  = string.Format("QXP.UI.addCssClass(this, '{0}')", HoverCss);
                    this.Attributes["onmouseout"]   = string.Format("QXP.UI.removeCssClass(this, '{0}')", HoverCss);
                }
                this.CssClass = string.Empty;
            }
            base.RenderBeginTag(writer);
        }
        void                                IPostBackEventHandler.RaisePostBackEvent(string eventArgument)
		{
		    this.RaisePostBackEvent(eventArgument);
        }
        protected virtual void              RaisePostBackEvent(string eventArgument){
            if (this.CausesValidation)
            {
                this.Page.Validate(this.ValidationGroup);
                if(!this.Page.IsValid) return;
            }
            this.OnClick(EventArgs.Empty);
            this.OnCommand(this, new CommandEventArgs(this.CommandName, this.Argument));
        }
		protected	virtual		void		OnClick(EventArgs ea)
		{
			if(Validation.IsNotNull(this.Click))
			{
				this.Click(this, ea);
			}
		}
		protected	virtual		void		OnCommand(object sender, CommandEventArgs cmea)
		{
			if(Validation.IsNotNull(this.Command))
			{
				this.Command(sender, cmea);
			}
		}
    }
}