using System;
using System.Collections;
using System.Text;
using System.Web.UI;
using QXPFrk = QXP.Framework;
using QXPApplication = QXP.Framework.Application;
using QXPResources = QXP.Framework.Resources;
using QXPWUIValidator = QXP.Framework.Web.UI.Controls.Validator;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>
    /// Class Panel : Description
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class Panel : TableSection, INamingContainer
    {
        #region Membres

        TableSection _pnl;
        Label _title = new Label();
        WebControlSection _body = null;
        CheckButtonImage _toggle = null;
        bool _showToggle = false;
        bool _hasHeader = true;
        bool _hasTitle = true;
        int _backColorIndex = int.MinValue;
        //Toggle Validation
        Anthem.HiddenField _hidden_toggle_validator;
        static string ShowHideScript;
        PanelValidator _panelValidator;
        Component.BaseComponent _hostComposant = null;

        #endregion Membres

        #region Constantes

        const string pnl_master = "pnl_master";
        const string pnl = "pnl";

        const string pnl_ttl = "pnl_ttl";

        const string pnl_hdr = "pnl_hdr";
        const string pnl_content = "pnl_content";

        const string pnl_clt = "pnl_clt";
        const string pnl_crt = "pnl_crt";
        const string pnl_clb = "pnl_clb";
        const string pnl_crb = "pnl_crb";

        const string pnl_lt = "pnl_lt";
        const string pnl_rt = "pnl_rt";

        const string pnl_l = "pnl_l";
        const string pnl_m = "pnl_m";
        const string pnl_r = "pnl_r";

        const string pnl_lb = "pnl_lb";
        const string pnl_rb = "pnl_rb";

        const string pnl_body = "pnl_body";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        static Panel()
        {
            StringBuilder __script = new StringBuilder();
            __script.Append("<script language=\"javascript\">")
                    .Append("function Show_Hide_Panel_Body(show_hide, id_body, css_show, css_hide ){")
                    .Append(" var bdy = document.getElementById(id_body);")
                    .Append(" if(show_hide) bdy.className = css_show;")
                    .Append(" else			bdy.className = css_hide;")
                    .Append("}")
                    .Append("</script>");
            ShowHideScript = __script.ToString();
        }
        public Panel()
            : base(1, 2)
        {
            _pnl = new TableSection(4, 3);
            _pnl.CssClass = pnl;
            _pnl.ID = _pnl.ID;
            _pnl.AjaxMode = this.AjaxMode;

            this.CssClass = pnl_master;
            this[0, 0].CssClass = pnl_hdr;
            this[1, 0].CssClass = pnl_content;

            _pnl[0, 0].CssClass = pnl_clt;
            _pnl[0, 1].CssClass = pnl_lt;
            _pnl[0, 2].CssClass = pnl_rt;
            _pnl[0, 3].CssClass = pnl_crt;

            _pnl[1, 0].CssClass = pnl_l;
            _pnl[1, 1].CssClass = pnl_m; // 2 cellules fusionn�es
            _pnl[1, 3].CssClass = pnl_r;
            _pnl[1, 1].ColumnSpan = 2;
            _pnl[1].Cells.RemoveAt(2);

            _pnl[2, 0].CssClass = pnl_clb;
            _pnl[2, 1].CssClass = pnl_lb;
            _pnl[2, 2].CssClass = pnl_rb;
            _pnl[2, 3].CssClass = pnl_crb;

            _body = new WebControlSection(System.Web.UI.HtmlTextWriterTag.Div) { AjaxMode = this.AjaxMode };

            _body.CssClass = pnl_body;
            _pnl[1, 1].Add(_body);

            _title.CssClass = pnl_ttl;

            _toggle = new CheckButtonImage(QXPApplication.Application.Resources.GetGlobal(QXPResources.ResourceParams.Group.Expand, QXPResources.ResourceParams.Key.Label)
                                                            , QXPApplication.Application.Resources.GetGlobal(QXPResources.ResourceParams.Group.Collapse, QXPResources.ResourceParams.Key.Label)
                                                            , "pnl_collapse"
                                                            , "pnl_expand"
                                                            , false);
            //"Ouvrir...", "Reduire...", "pnl_collapse", "pnl_expand", false);
            //_toggle.Checked			= true;
            _toggle.Visible = false;
            //_toggle.CausesValidation	= false;
            this[0, 0].Add(_title);
            this[0, 0].Add(_toggle);
            this[1, 0].Add(_pnl);

        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Evenements

        protected override void OnInit(EventArgs e)
        {
            _hostComposant = new HostNamingFinder<Component.BaseComponent>().GetHost(this);
            _panelValidator = new PanelValidator(this);
            this.Body.Add(_panelValidator);
            base.OnInit(e);
            if (Validation.IsSet(_backColorIndex) && !_body.CssClass.Contains(string.Concat("pnl_color_", _backColorIndex)))
            {
                    _body.CssClass = string.Concat(_body.CssClass, " ", "pnl_color_", _backColorIndex);
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            this[0].Visible = _hasHeader;
            _title.Visible = _hasTitle && Validation.IsSet(_title.Text);
            //if(Validation.IsSet(_backColorIndex) && !this.Page.IsPostBack) _body.CssClass = string.Concat(_body.CssClass, " " , "pnl_color_", _backColorIndex);
            ItemSection __item = _pnl[1, 1];
            __item.ID = __item.ID;
            string _css_show = string.Concat(pnl_m, QXPFrk.Constantes.Space, "pnl_body_visible");
            string _css_hide = string.Concat(pnl_m, QXPFrk.Constantes.Space, "pnl_body_hidden");
            string _item_Css = string.Empty;
            if (_toggle.Checked)
            {
                _item_Css = _css_hide;
            }
            else
            {
                _item_Css = _css_show;
            }
            __item.CssClass = _item_Css;
            if (_showToggle)
            {
                _toggle.OnToggleClickScript = string.Concat("Show_Hide_Panel_Body({0}, '", __item.ClientID, "', '", _css_hide, "', '", _css_show, "')");
                this.Page.RegisterClientScriptBlock("Show_Hide_Panel_Body", ShowHideScript);
            }
            _toggle.Visible = _showToggle;

            _hidden_toggle_validator = new Anthem.HiddenField();
            _hidden_toggle_validator.ID = _hidden_toggle_validator.ID; //FORCE CLient id generation;

            this.Header.Add(_hidden_toggle_validator);

            //string __errorMessage = string.Empty;

            //if(Validation.IsSet(this.Title)){
            //    __errorMessage = QXPApplication.Application.Resources.GetGlobalMessage(QXPResources.ResourceParams.Group.InvalidPanel, this.Title); // string.Format("Le panneau '{0}' est incomplet !", this.Title);
            //}

            //_panelValidator.ErrorMessage = __errorMessage;

            ArrayList __params = new ArrayList();
            string __params_Value = string.Empty;

            __params.Add(__item.ClientID);
            __params.Add(_toggle.DataID);
            __params.Add(_css_show);

            //            //Evaluate Contained validators.
            //            ArrayList	__containedValidators			= new ArrayList();
            //            string		__bdy_clientID					= this.ClientID;
            ////			string		__customValidatorClientID		= _toggle_Validator.ClientID;
            //            foreach(Control __control in this.Page.Validators)
            //            {
            //                string __clientID = __control.ClientID;
            //                if(__clientID.IndexOf(__bdy_clientID)!=-1 && !__clientID.Equals(__bdy_clientID))
            //                {
            //                    __containedValidators.Add(__clientID);
            //                }
            //            }
            //            if(this.ShowToggle && __containedValidators.Count>0)
            //            {
            //                string __concatenedIDs = string.Join("|", (String[])__containedValidators.ToArray(ValueType.CLSstring));
            //                __params.Add(__concatenedIDs);
            //                _toggle_Validator						= new QXPWUIValidator.CustomValidator(__errorMessage, string.Empty, string.Empty, "validate_panel"); //"pnl validator error"
            //                //_toggle_Validator.ServerValidate		+= new ServerValidateEventHandler(this.OnToggleValidate);
            //                _toggle_Validator.ControlToValidate		= _hidden_toggle_validator.ID;
            //                this.Header.Add(_toggle_Validator);
            //                //_toggle_Validator.Visible = true;
            //            }
            //            else
            //            {
            //                __params.Add(string.Empty);
            //                //_toggle_Validator.Visible = false;
            //            }
            __params_Value = string.Join(";", (String[])__params.ToArray(ValueType.CLSstring));
            _hidden_toggle_validator.Value = __params_Value;

        }

        //		private void OnToggleValidate(object sender, ServerValidateEventArgs svea){
        //			//svea.IsValid = false;
        //			this.IsCollapse = false;
        //		}

        #endregion Evenements

        #region Propri�t�s

        public BasePage QXPPage
        {
            get { return this.Page as BasePage; }
        }

        public bool HasHeader
        {
            get { return _hasHeader; }
            set { _hasHeader = value; }
        }

        public bool HasTitle
        {
            get { return _hasTitle; }
            set { _hasTitle = value; }
        }

        public bool ShowToggle
        {
            get { return _showToggle; }
            set { _showToggle = value; }
        }

        public bool IsCollapse
        {
            get { return _toggle.Checked; }
            set { _toggle.Checked = value; }
        }

        /// <summary>
        /// R�f�rence sur le control du titre
        /// </summary>
        public Label Control_Title
        {
            get { return _title; }
        }

        public string Title
        {
            get { return _title.Text; }
            set { _title.Text = value; }
        }

        public string Title_ToolTip
        {
            get { return _title.ToolTip; }
            set { _title.ToolTip = value; }
        }

        public int BackColorIndex
        {
            get { return _backColorIndex; }
            set { _backColorIndex = value; }
        }

        public bool IsValid
        {
            get { return _panelValidator.IsValid; }
        }

        #region Contained Objects

        public ItemSection Header
        {
            get { return this[0, 0]; }
        }

        public ItemSection Content
        {
            get { return this[1, 0]; }
        }

        public TableSection Content_Panel
        {
            get { return _pnl; }
        }

        /// <summary>
        /// You Must used this property to add controls inside !!
        /// </summary>
        public WebControlSection Body
        {
            get { return _body; }
        }

        #endregion

        #region Css Mapping
        public string CssClass_Title
        {
            get { return _title.CssClass; }
            set { _title.CssClass = string.Concat(_title.CssClass, QXPFrk.Constantes.Space, value); }
        }
        public string CssClass_Header
        {
            get { return this[0, 0].CssClass; }
            set { this[0, 0].CssClass = string.Concat(this[0, 0].CssClass, QXPFrk.Constantes.Space, value); }
        }
        public string CssClass_Content
        {
            get { return this[1, 0].CssClass; }
            set { this[1, 0].CssClass = string.Concat(this[1, 0].CssClass, QXPFrk.Constantes.Space, value); }
        }
        public string CssClass_Body
        {
            get { return _body.CssClass; }
            set { _body.CssClass = string.Concat(_body.CssClass, QXPFrk.Constantes.Space, value); }
        }
        public override string CssClass
        {
            get { return base.CssClass; }
            set { base.CssClass = string.Concat(base.CssClass, QXPFrk.Constantes.Space, value); }
        }
        #endregion

        #region BaseComposant Mapping
        public Component.BaseComponent HostComponent
        {
            get { return _hostComposant; }
        }
        #endregion


        #endregion Propri�t�s
    }

    /// <summary>
    /// Class PanelValidator
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class PanelValidator : QXPWUIValidator.ContainerValidator
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de PanelValidator
        /// </summary>
        public PanelValidator(Panel panel) : base(panel) { }

        #endregion Constructeur

        #region M�thodes

        public override bool EvaluateIsValid(string validationGroup)
        {
            bool __isValid = base.EvaluateIsValid(validationGroup);
            Panel __panel = (Panel)this.Container;
            if (!__isValid)
            {
                __panel.IsCollapse = false;
                //PENSER A METTRE A JOUR LE RAFRAICHISSEMENT A L'ECRAN
                __panel.UpdateAfterCallBack = true;
            }
            return __isValid;
        }

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
