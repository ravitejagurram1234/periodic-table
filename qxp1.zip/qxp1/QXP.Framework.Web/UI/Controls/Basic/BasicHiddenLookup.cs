using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;

using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>Provides methods and properties of a calendar control. </summary>
	public class HiddenLookup: Anthem.HiddenField
	{
        #region Membres

		private string _module;
		private string _page;
		private string _preShowScript = string.Empty;

		Hashtable _extraParameters	= new Hashtable();
		public event Lookup_EventHandler LookupChanged;

        #endregion Membres

        #region Constantes

        private const string HdnCss = "hdn_lkp";	
		const string VSAutoPostBack = "AutoPostBack";
		const string VSAutoCallBack = "AutoCallBack";
		const string WindowWidthKey = "WindowWidth";
		const string WindowHeightKey = "WindowHeight";
		const string WindowResizableKey	= "WindowResizable";
		const string WindowScrollableKey = "WindowScrollable";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de HiddenLookup
        /// </summary>
		public HiddenLookup()
		{
			this.ValueChanged		+= new EventHandler(this.InternalChanged);
		}

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Affiche la Lookup
        /// </summary>
        public void ShowLookup()
		{
			StringBuilder __script = new StringBuilder();

			//ajout du script custom preShowScript s'il existe
			if(Validation.IsSet(_preShowScript)) 
                __script.Append(_preShowScript);

			__script.AppendFormat("var win = open('{0}?FormName=MainForm&CtrlName={1}", AbsoluteFilesPath.LookupPage ,this.UniqueID);
			if(Validation.IsSet(_module))	__script.AppendFormat("&m={0}", _module);
			if(Validation.IsSet(_page))		__script.AppendFormat("&p={0}", _page);
			if(this.AutoPostBack)			__script.AppendFormat("&postid={0}", this.UniqueID);
			if(this.AutoCallBack)			__script.AppendFormat("&callid={0}", this.UniqueID);
			
            NameValueCollection __staticParameters = this.StaticParameters;
			if(__staticParameters.Count > 0)
			{
				foreach(string __key in __staticParameters)
				{
					__script.AppendFormat("&{0}={1}", __key, __staticParameters[__key]);
				}
			}

			if(_extraParameters.Count > 0)
			{
				foreach(DictionaryEntry __entry in _extraParameters)
				{
					__script.AppendFormat(" + '&{0}=' + document.getElementById('{1}').value", __entry.Key, __entry.Value);
				}
			}

			__script.AppendFormat("', 'PopUpLookupHidden', 'width={0},height={1},top=200,left=200,toolbars=no,scrollbars={2},status=no,resizable={3}');win.document.close();", this.WindowWidth, this.WindowHeight, this.WindowScrollable?"yes":"no", this.WindowResizable?"yes":"no");
			ClientScript __openScript = new ClientScript(this, "CreationParamVariante", __script.ToString());
			__openScript.RegisterForClientSideEval();
		}

        /// <summary>
        /// Ajoute un StaticParameter
        /// </summary>
        /// <param name="name">Nom du StaticParameter</param>
        /// <param name="value">Valeur du StaticParameter</param>
        /// <param name="deleteIfExist">D�termine si le param�tre est supprim� de la liste lorsqu'il est d�j� pr�sent</param>
        public void AddStaticParameter(string name, string value, bool deleteIfExist)
        {
            if (deleteIfExist && QXPFrk.Validation.IsNotNull(this.StaticParameters[name]))
                this.StaticParameters.Remove(name);

            this.StaticParameters.Add(name, value);
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Module
        /// </summary>
		public string M
		{
			get{ return _module; }
			set{ _module = value; }
		}

        /// <summary>
        /// Page
        /// </summary>
		public string P
		{
			get{ return _page; }
			set{ _page = value; }
		}

        		public int WindowWidth
		{
			get
			{
				int __windowWidth = Conversion.ToInt(this.ViewState[WindowWidthKey]);
				if(Validation.IsSet(__windowWidth)) return __windowWidth;
				else								return 400;
			}
			set{this.ViewState[WindowWidthKey] = value;}
		}
		public int WindowHeight
		{
			get
			{
				int __windowHeight = Conversion.ToInt(this.ViewState[WindowHeightKey]);
				if(Validation.IsSet(__windowHeight))	return __windowHeight;
				else									return 400;
			}
			set{this.ViewState[WindowHeightKey] = value;}
		}

		public bool WindowResizable
		{
			get{return Conversion.ToBool(this.ViewState[WindowResizableKey]);}
			set{this.ViewState[WindowResizableKey] = value;}
		}

		public bool WindowScrollable
		{
			get{return Conversion.ToBool(this.ViewState[WindowScrollableKey]);}
			set{this.ViewState[WindowScrollableKey] = value;}
		}

		/// <summary>
		/// contient une liste KEY/VALUE permettant des g�n�rer des variables javascript � partir du contenu de certains controles
		/// la KEY correspond au nom de la variable, la VALUE correspond au nom technique du controle ou doit �tre extrait la valeur
		/// Attention Ces param�tres ne sont pas m�moris�s dans le viewstate du controle hidden
		/// </summary>
		public Hashtable ExtraParameters
		{
			get{return _extraParameters;}
		}

		/// <summary>
		/// Contient une liste KEY/VALUE des param�tres envoy�e � la fen�tre de lookup
		/// Attention Ces param�tres sont m�moris� dans le viewstate du controle hidden
		/// </summary>
		public NameValueCollection StaticParameters
		{
			get
			{
				NameValueCollection __parameters = this.ViewState["StaticParams"] as NameValueCollection;
				if(Validation.IsNull(__parameters))
				{
					__parameters					= new NameValueCollection();
					this.ViewState["StaticParams"]	= __parameters;
				} 
				return __parameters;
			}
		}

		public bool AutoPostBack
		{
			get{return Conversion.ToBool(this.ViewState[VSAutoPostBack]);}
			set{this.ViewState[VSAutoPostBack] = value;}
		}

		public bool AutoCallBack
		{
			get{return Conversion.ToBool(this.ViewState[VSAutoCallBack]);}
			set{this.ViewState[VSAutoCallBack] = value;}
		}

		private void InternalChanged(object sender, EventArgs ea)
        {
			this.OnLookupChanged(new Lookup_EventArg(this.Value));	
		}

		protected virtual void OnLookupChanged(Lookup_EventArg lkpea)
		{
			if(Validation.IsNotNull(this.LookupChanged))
				this.LookupChanged(this, lkpea);
		}

		/// <summary>
		/// Permet d'ins�rer un script � �x�cuter avant d'ouvrir le lookup
		/// cette variable n'est pas sauvegard� dans le ViewState
		/// </summary>
		public string PreShowScript
		{
			get { return _preShowScript; }
			set { _preShowScript = value; }
		}

        #endregion Propri�t�s
	}

	public delegate void Lookup_EventHandler(object sender, Lookup_EventArg lkpea);

	public class Lookup_EventArg
    {
        #region Membres

		string _value;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Lookup_EventArg
        /// </summary>
        /// <param name="value"></param>
        public Lookup_EventArg(string value)
        {
			this._value = value;
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        public string Value
        {
			get{ return _value; }
        }

        #endregion Propri�t�s
    }
}

