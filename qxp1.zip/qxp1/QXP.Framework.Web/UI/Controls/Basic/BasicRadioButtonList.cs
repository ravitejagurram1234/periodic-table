using System;
using System.Collections;
using System.Globalization;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPFrk											= QXP.Framework;
using QXPData											= QXP.Framework.Data;

namespace QXP.Framework.Web.UI.Controls.Basic{
	/// <summary>Represents a control that allows the user to select a single item from a RadioButton List.	</summary>
	//INFO: we had to repimplement IRepeatInfoUser to customize IRepeatInfoUser.RenderItem method then add onclick script.
	public class RadioButtonList: Anthem.RadioButtonList //, IRepeatInfoUser
	{
		#region internal variables
		private static readonly string	DefaultCss				= Basic.CssClass.rdlst.ToString();
		private string					_selectedValue			= null;
		private object					_defaultValue			= null;
		private	int						_maxTextLength			= 40;
		private bool					_isSorted				= false;
		private string					_onRadioClickScript		= null;
		private ArrayList				_listitems;
		private	DataSourceType	        _dataSourceType;
        private int                     _renderedItemIndex = 0;
		private const string			VSEnableEmptySelectionKey	= "VSEnableEmptySelection";

		#endregion
		/// <summary>Creates a new instance of <see cref="RadioButtonList"/> control. </summary>
		public RadioButtonList()
		{
			base.CssClass		        = DefaultCss;
			this.CellPadding	        = 0;
			this.CellSpacing	        = 0;
            this.EnabledDuringCallBack  = false;
		}
		/// <summary>Binds a data source to the invoked RadioButton list. </summary>
		public		override	void		DataBind()
		{
			object					__dataSource;
			if(Validation.IsSet(this.DataMember))
			{
				__dataSource	=  QXPData.DataSourceResolver.GetResolvedDataSource(this.DataSource, this.DataMember);
			}
			else
			{
				__dataSource	= DataSource;
			}
			IEnumerable			__iEnumerable										= __dataSource as IEnumerable;
			this.Items.Clear();
			this.ClearSelection();
			if(Validation.IsNull(__iEnumerable)) return ; //INFO: Nothing Interesting to bind. 
			string					__dataTextField									= this.DataTextField;
			string					__dataValueField								= this.DataValueField;
			string					__dataTextFormatString					= this.DataTextFormatString;
			string					__itemValue, __itemText, __key;
			object					__value;
			bool						__alreadySelected								= false;
			PropertyInfo		__indexer												= null;
			int							__arrayRank											=	1;
			string					__selectedValue									= string.Empty;
			if(Validation.IsSet(_selectedValue))
			{
				__selectedValue = _selectedValue;
			}
			else
			{
				if(Validation.IsNotNull(this.DefaultValue))
				{
					__selectedValue = Conversion.ToString(this.DefaultValue);
				}
			}
			_listitems = new ArrayList();
			ICollection		__iCollection = __iEnumerable as ICollection;
			if (Validation.IsNotNull(__iCollection))	Items.Capacity = __iCollection.Count;

			IEnumerator		__iEnumerator						= __iEnumerable.GetEnumerator();
			try
			{
				//INFO: First Test
				if(__dataSource is System.Collections.Specialized.NameObjectCollectionBase)
				{
					_dataSourceType = DataSourceType.NameValueCollection;
					__indexer				= __dataSource.GetType().GetProperty("Item", ValueType.ArrayOf1String);
				}
				else if(__dataSource is System.Collections.IDictionary)
				{
					_dataSourceType = DataSourceType.Dictionary;
				}
				else if(__dataSource is System.Array)
				{
					_dataSourceType = DataSourceType.Array;
					__arrayRank = ((Array)__dataSource).Rank;
				}
				else
				{
					//INFO: Second chance
					if(__iEnumerator is IDictionaryEnumerator) _dataSourceType = DataSourceType.Dictionary;
				}
				while (__iEnumerator.MoveNext())
				{
					object	__entry = __iEnumerator.Current;
					switch(_dataSourceType)
					{
						case DataSourceType.NameValueCollection:
							__key		= Conversion.ToString(__entry);
							__value	= QXPData.DataBinder.GetIndexedValue(__indexer, __dataSource, __key);
							break;
						case DataSourceType.Dictionary:
							DictionaryEntry	__dictionaryEntry = (DictionaryEntry)__entry;
							__key		= Conversion.ToString(__dictionaryEntry.Key);
							__value = __dictionaryEntry.Value;
							break;
						case DataSourceType.Array:
							__key		= Conversion.ToString(__entry);
							for(int __i = 1; __i < __arrayRank; __i++) __iEnumerator.MoveNext();
							__value = __iEnumerator.Current;
							break;
						default:
							__key		= Conversion.ToString(__entry);
							__value = __entry;
							break;
					}
					//DataTextField
					if (Validation.IsSet(__dataTextField))
					{
						__itemText		= Conversion.ToString(QXPData.DataBinder.Eval(__value, __dataTextField, __dataTextFormatString));
					}
					else
					{
						if (Validation.IsSet(__dataTextFormatString))	__itemText		= string.Format(__dataTextFormatString, __value);
						else																					__itemText		= Conversion.ToString(__value);
					}
					//DataValueField
					if (Validation.IsSet(__dataValueField))					__itemValue		= Conversion.ToString(QXPData.DataBinder.Eval(__value, __dataValueField, null));
					else																						__itemValue		= __key;
							
					__alreadySelected = __alreadySelected || (__itemValue == __selectedValue);
					this.AddItem(__itemValue, __itemText,  __itemValue == __selectedValue);
				}
				//INFO: Sort List
				if(this.IsSorted)
				{
					_listitems.Sort(ListItemComparer.Default);
					foreach(ListItem __item in _listitems)
					{
						__item.Text				= StringHelper.StartString(__item.Text, _maxTextLength); 
					}
				}
				ListItem[] __items = (ListItem[])_listitems.ToArray(typeof(ListItem));
					
				this.Items.AddRange(__items);
				if(!__alreadySelected && __items.Length>0 && !this.EnableEmptySelection) this.SelectedIndex = 0;
			}
			catch(Exception)
			{
				//TODO: log error !!
			}
			finally
			{
				IDisposable __iDisposable = __iEnumerator as IDisposable;
				if (Validation.IsNotNull(__iDisposable))		__iDisposable.Dispose();
			}
		}
		private					void		AddItem(string @value, string text, bool selected)
		{
			this.AddItem(_listitems.Count, value, text, selected);
		}
		private					void		AddItem(int index, string @value, string text, bool selected)
		{
			ListItem __listItem = new ListItem();
			__listItem.Value			= value;
			__listItem.Text				= text;
			__listItem.Selected		= selected;
			_listitems.Insert(index, __listItem);
		}
		/// <summary>Gets or sets the maximum number of item text length. </summary>
		public					int			MaxTextLength
		{
			get{return(_maxTextLength);}
			set{_maxTextLength = value;}
		}
		/// <summary>Gets or sets whether the items in the list are sorted. </summary>
		public					bool		IsSorted
		{
			get{return(_isSorted);}
			set{_isSorted = value;}
		}
		/// <summary>Gets or sets the value of default selected item. </summary>
		public					object		DefaultValue
		{
			get{return _defaultValue;}
			set{_defaultValue = value;}
		}
		private					bool		SelectValue(string value)
		{
			ListItem	__item = this.Items.FindByValue(value);
			if(Validation.IsNotNull(__item))
			{
				this.ClearSelection();
				__item.Selected = true;
				return true;
			}
			return false;
		}
		/// <summary>Gets or sets if an empty item will be added to the list. </summary>
		/// <remarks>This empty item will be used to enable empty selection in a RadioButton list control. </remarks>
		public					string		SelectedText
		{
			get
			{
				if(QXPFrk.Validation.IsNotNull(this.SelectedItem))
				{
					return this.SelectedItem.Text;
				}
				return string.Empty;
			}
		}
		public override			string		SelectedValue
		{
			get
			{
				if(QXPFrk.Validation.IsNotNull(this.SelectedItem))
				{
					return this.SelectedItem.Value;
				}
				return string.Empty;
			}
			set
			{
				ListItem	__item = this.Items.FindByValue(value);
				this.ClearSelection();
				if(Validation.IsNotNull(__item))
				{
					__item.Selected = true;
				}
			}
		}
		/// <summary>Gets or sets if an empty item will be added to the list. </summary>
		/// <remarks>This empty item will be used to enable empty selection in a radiobutton-list control. </remarks>
		public					bool		EnableEmptySelection{
			get{return Conversion.ToBool(this.ViewState[VSEnableEmptySelectionKey], true);}
			set{this.ViewState[VSEnableEmptySelectionKey] = value;}
		}
        public                  bool        IsEmptySelected{
            get{return this.SelectedIndex == -1;}
        }
		public					string		OnRadioClickScript{
			get{return _onRadioClickScript;}
			set{_onRadioClickScript = value;}
		}
        protected override void OnSelectedIndexChanged(EventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnSelectedIndexChanged(e);
        }
        protected override void RenderItem(ListItemType itemType, int repeatIndex, RepeatInfo repeatInfo, HtmlTextWriter writer) {
            if(Validation.IsSet(_onRadioClickScript)){
                ListItem __item = this.Items[_renderedItemIndex];
                __item.Attributes["onclick"] = _onRadioClickScript;
                _renderedItemIndex += 1;
            }

            base.RenderItem(itemType, repeatIndex, repeatInfo, writer);
        }
        //#region IRepeatInfoUser
        //Style IRepeatInfoUser.GetItemStyle(ListItemType itemType, int repeatIndex)
        //{
        //    return null;
        //}
        //void	IRepeatInfoUser.RenderItem(ListItemType itemType, int repeatIndex, RepeatInfo repeatInfo, HtmlTextWriter writer){
        //    if(Validation.IsSet(_onRadioClickScript)){
        //        ListItem __item = this.Items[_renderedItemIndex];
        //        __item.Attributes["onclick"] = _onRadioClickScript;
        //        _renderedItemIndex += 1;
        //    }

        //    base.RenderItem(itemType, repeatIndex, repeatInfo, writer);
            
        //    //RadioButton _btn			= new RadioButton();
        //    //_btn.Page					= this.Page;
        //    //_btn.GroupName				= this.UniqueID;
        //    //_btn.ID						= this.ClientID + "_" + repeatIndex.ToString(NumberFormatInfo.InvariantInfo);
        //    //_btn.Text					= this.Items[repeatIndex].Text;
        //    //_btn.Attributes["value"]	= this.Items[repeatIndex].Value;
        //    //if(Validation.IsSet(_onRadioClickScript)) _btn.Attributes["onclick"] = _onRadioClickScript;
        //    //_btn.Checked				= this.Items[repeatIndex].Selected;
        //    //_btn.TextAlign				= this.TextAlign;
        //    //_btn.AutoPostBack			= this.AutoPostBack;
        //    //_btn.AutoCallBack			= this.AutoCallBack;
        //    //_btn.Enabled				= this.Enabled;
        //    //_btn.RenderControl(writer);
        //}

        //// Properties
        //bool	IRepeatInfoUser.HasFooter {
        //    get{return false;}
        //}
        //bool	IRepeatInfoUser.HasHeader {
        //    get{return false;}
        //}
        //bool	IRepeatInfoUser.HasSeparators {
        //    get{return  false;}
        //}
        //int		IRepeatInfoUser.RepeatedItemCount {
        //    get{return this.Items.Count;}
        //}
        //#endregion
	}
}
