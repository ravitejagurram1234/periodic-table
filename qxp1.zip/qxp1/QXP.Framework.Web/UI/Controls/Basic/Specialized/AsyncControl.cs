using System;
using System.Collections.Specialized;
using System.Text;
using System.Web.UI;
using QXPW = QXP.Framework.Web;
using QXPWHandler = QXP.Framework.Web.Handler;
using QXPWUIControls = QXP.Framework.Web.UI.Controls;
using QXPWUIHtml = QXP.Framework.Web.UI.Controls.Html;
using QXPWUser = QXP.Framework.Web.User;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>
	/// D�fini un control contenant un IFrame, l'iFrame peut lever un �v�nement sur le parent (c'est � dire l'IFrameControl)
	/// </summary>
	/// <author>doufarm</author>
	/// <date>21/09/2011 09:05:41</date>    
	public class AsyncControl: QXPWUIControls.WebControl, IPostBackEventHandler 
	{
		#region Membres
		QXPWUIHtml.IFrame		_iFrameGenerator;		

		/// <summary>survient lorsque l'iframe contenu d�clenche l'�v�nement. </summary>
		public event EventHandler			Signal;

		#endregion Membres

		#region Constantes
		private const string VSCausesValidation     = "VSCausesValidation";
		private const string VSValidationGroup      = "VSValidationGroup";
		private const string VSIFramePage			= "VSIFramePage";
		private const string VSIDResponse			= "VSIDResponse";
		private const string VSTaskID				= "VSTaskID";
		private const string VSInternalParams		= "VSInternalParams"; 
		private const string VSExternalParams		= "VSExternalParams"; 
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de AsyncControl
		/// </summary>
		public AsyncControl()
		{

		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>Initialization du control. </summary>
		/// <param name="ea">arguments de l'initialisation</param>
		protected override	void			OnInit(EventArgs ea)
		{
		    base.OnInit(ea);

		    //INFO: force ID definition !!
		    this.ID = this.ID;

			_iFrameGenerator = new QXPWUIHtml.IFrame();
			this.Controls.Add(_iFrameGenerator);
			_iFrameGenerator.CssClass = "hidden_iframe";
			_iFrameGenerator.Scrolling = false;
			_iFrameGenerator.Source = "blank.html";
			
		    if(this.Enabled)
		    {
		        //INFO: add __EventTarget hidden field to prevent autopostback js script error !!!
		        this.Page.GetPostBackEventReference(this);
		    }
		}

		/// <summary>
		/// Impl�mentation de l'interface IPostBackEventHandler
		/// </summary>
		/// <param name="eventArgument">argument de l'�v�nement</param>
		void                                IPostBackEventHandler.RaisePostBackEvent(string eventArgument)
		{
		    this.RaisePostBackEvent(eventArgument);
		}

		/// <summary>
		/// Impl�mentation de l'interface IPostBackEventHandler
		/// </summary>
		/// <param name="eventArgument">argument de l'�v�nement</param>
		protected virtual void              RaisePostBackEvent(string eventArgument){
		    if (this.CausesValidation)
		    {
		        this.Page.Validate(this.ValidationGroup);
		        if(!this.Page.IsValid) return;
		    }
		    this.OnSignal(this, EventArgs.Empty);
		}

		/// <summary>
		/// D�bute l'appel sur l'iframe sous jascent
		/// </summary>
		/// <param name="taskid">identifiant de la tache � lancer</param>
		/// <returns>true l'appel � commenc�, false l'appel n'a pas �t� effectu�. </returns>
		public bool StartAsyncCall(string taskid)
		{
			
			QXPWHandler.AsyncTask __task = QXPWUser.User.Current.GetObject(QXPWHandler.Enums.ObjectCategory.AsyncTask, taskid) as QXPWHandler.AsyncTask;

			if (Validation.IsNotNull(__task))
			{
				//Tache en cours d'�x�cution
				if (__task.TaskState == QXPWHandler.Enums.AsyncTaskState.Started)
					return false;

				//Ces param�tres sont toujours r�initialis�s
				this.InternalParameters.Clear();
				this.InternalParameters.Add(QXPWHandler.AsyncHandlerConfig.TaskIDKey, taskid);

				_iFrameGenerator.Source = GetIFrameSource();

				this.UpdateAfterCallBack = true;
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>survient lorsque l'iframe contenu d�clenche l'�v�nement. </summary>
		/// <param name="sender">source de l'�v��nement</param>
		/// <param name="ea">arguments </param>
		protected virtual void				OnSignal(object sender, EventArgs ea)
		{
		    if(Validation.IsNotNull(Signal))
		    {
		        this.Signal(this, ea);
		    }
		}

		/// <summary>
		/// Permet d'obtenir l'url de l'appel de l'iframe
		/// </summary>
		/// <returns>url de la source du controle iframe</returns>
		private string GetIFrameSource()
		{
			StringBuilder __url = new StringBuilder();
			
			//toujours pr�sent
			__url.Append(QXPW.HttpUtilities.GetAbsolutePath(this.IFramePage))
				.AppendFormat("?callid={0}", this.UniqueID);
			
			NameValueCollection __parameters;
			
			//param�tre interne
			this.AddParameters(__url, this.InternalParameters);
			this.AddParameters(__url, this.ExternalParameters);

			return __url.ToString();
		}

		/// <summary>
		/// Permet d'ajouter une serie de valeur dans une url
		/// </summary>
		/// <param name="sb">le StringBuilder dans lequel il faut ajouter les param�tres</param>
		/// <param name="values">Liste de valeurs</param>
		private void AddParameters(StringBuilder sb, NameValueCollection values)
		{
			if(values.Count > 0)
			{
				foreach(string __key in values)
				{
					sb.AppendFormat("&{0}={1}", __key, values[__key]);
				}
			}
		}

		#endregion M�thodes

		#region Propri�t�s
		

		/// <summary>
		/// Ce controle doit-il tenir compte de la validation de la page
		/// </summary>
		public      bool                    CausesValidation{
		    get{return Conversion.ToBool(this.ViewState[VSCausesValidation]);}
		    set{this.ViewState[VSCausesValidation] = value;}
		}

		/// <summary>
		/// Nom du groupe de validation
		/// </summary>
		public      string                  ValidationGroup{
		    get{return Conversion.ToString(this.ViewState[VSValidationGroup]);}
		    set{this.ViewState[VSValidationGroup] = value;}
		}

		/// <summary>
		/// Nom de la page de l'appel de l'iframe
		/// </summary>
		public      string                  IFramePage{
		    get{return Conversion.ToString(this.ViewState[VSIFramePage]);}
		    set{this.ViewState[VSIFramePage] = value;}
		}

		/// <summary>
		/// Param�tres interne ajout� dans l'url d'appel de l'iframe.
		/// Ces param�tres sont g�r� par le control
		/// </summary>
		NameValueCollection					InternalParameters{
			get{
				NameValueCollection __parameters = this.ViewState[VSInternalParams] as NameValueCollection;
				if(Validation.IsNull(__parameters))
				{
					__parameters					= new NameValueCollection();
					this.ViewState[VSInternalParams]	= __parameters;
				} 
				return __parameters;
			}
		}

		/// <summary>
		/// Param�tres externe ajout� dans l'url d'appel de l'iframe.
		/// Ces param�tres doivent �tre g�r� par le developpeur en fonction des besoins
		/// </summary>
		public		NameValueCollection		ExternalParameters{
			get{
				NameValueCollection __parameters = this.ViewState[VSExternalParams] as NameValueCollection;
				if(Validation.IsNull(__parameters))
				{
					__parameters					= new NameValueCollection();
					this.ViewState[VSExternalParams]	= __parameters;
				} 
				return __parameters;
			}
		}

		#endregion Propri�t�s
	}
}
