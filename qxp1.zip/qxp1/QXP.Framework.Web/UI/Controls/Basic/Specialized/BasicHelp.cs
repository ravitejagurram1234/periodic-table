using System;
using System.Collections;
using System.Collections.Specialized;
using System.Globalization;
using System.Text;
using System.Web;
using System.Web.UI;
using MSWebControls = System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>Provides methods and properties of a Help control. </summary>
	public class Help: ImageButton{
		#region Internal variables
			private	const	string		LkpCss				= "img_help";
			private	const	string		WindowWidthKey		= "WindowWidth";
			private const	string		WindowHeightKey		= "WindowHeight";
			private const	string		WindowResizableKey	= "WindowResizable";
			private const	string		WindowScrollableKey	= "WindowScrollable";
			private			string		URLHelpSectionKey	= "Help_Section";
			private			string		VSHelpSectionKey	= "Help_Section";
			private const	string		DefaultModule		= "Help";
			private			string		_module;
			private			string		_page;
		#endregion
		/// <summary>Creates a new instance of <see cref="Lookup"/> control. </summary>
		public Help(){
			this.CausesValidation	= false;
			this.CssClass			= LkpCss;
			this._module			= DefaultModule;
		}
		
		protected override void OnInit(EventArgs e)
		{
			base.OnInit (e);
			this.ImageUrl = AbsoluteFilesPath.PlaceHolderImg;
		}
		/// <summary>Occurs when the control is about to render to its containing control. </summary>
		/// <param name="args">The <see cref="EventArgs"/> that contains event data. </param>
		/// <remarks>This method generate client script used by the calendar control if <see cref="AddButton"/> is set to <see langword="true"/>. </remarks>
		protected	override	void				OnPreRender(EventArgs args) 
		{
			base.OnPreRender(args);
			StringBuilder __sb = new StringBuilder();
			__sb.AppendFormat("window.open('{0}?m={1}", AbsoluteFilesPath.LookupPage,_module);
			if(Validation.IsSet(_page))		__sb.AppendFormat("&p={0}", _page);
			
			NameValueCollection __staticParameters = this.StaticParameters;
			if(__staticParameters.Count > 0)
			{
				foreach(string __key in __staticParameters)
				{
					__sb.AppendFormat("&{0}={1}", __key, __staticParameters[__key]);
				}
			}
			if(Validation.IsSet(this.HelpSection))
			{
				__sb.AppendFormat("&{0}={1}", URLHelpSectionKey, HelpSection);
			}
			__sb.AppendFormat("', 'PopUpLookupHelp', 'width={0},height={1},top=200,left=200,toolbars=no,scrollbars={2},status=no,resizable={3}');return false;", this.WindowWidth, this.WindowHeight, this.WindowScrollable?"yes":"no", this.WindowResizable?"yes":"no");
			string __openScript = __sb.ToString();    
			this.Attributes["onclick"] = __openScript;
		}
		public					string				M
		{
			get{return _module;}
			set{_module = value;}
		}
		public					string				P
		{
			get{return _page;}
			set{_page = value;}
		}
		public					int					WindowWidth{
			get{
				int __windowWidth = Conversion.ToInt(this.ViewState[WindowWidthKey]);
				if(Validation.IsSet(__windowWidth)) return __windowWidth;
				else								return 400;
			}
			set{this.ViewState[WindowWidthKey] = value;}
		}

		public					int					WindowHeight
		{
			get
			{
				int __windowHeight = Conversion.ToInt(this.ViewState[WindowHeightKey]);
				if(Validation.IsSet(__windowHeight))	return __windowHeight;
				else									return 400;
			}
			set{this.ViewState[WindowHeightKey] = value;}
		}
		public					bool				WindowResizable{
			get{return Conversion.ToBool(this.ViewState[WindowResizableKey]);}
			set{this.ViewState[WindowResizableKey] = value;}
		}
		public					bool				WindowScrollable{
			get{return Conversion.ToBool(this.ViewState[WindowScrollableKey]);}
			set{this.ViewState[WindowScrollableKey] = value;}
		}
		public					NameValueCollection StaticParameters{
			get{
				NameValueCollection __parameters = this.ViewState["StaticParams"] as NameValueCollection;
				if(Validation.IsNull(__parameters))
				{
					__parameters					= new NameValueCollection();
					this.ViewState["StaticParams"]	= __parameters;
				} 
				return __parameters;
			}
		}
		public					string				HelpSection{
			get{return Conversion.ToString(this.ViewState[VSHelpSectionKey]);}
			set{this.ViewState[VSHelpSectionKey] = value;}
		}
	}
}

