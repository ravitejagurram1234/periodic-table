using System;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>Represents the cascading style sheet of the basic control.</summary>
	public enum CssClass
	{
		/// <summary>Dropdown list CSS class.</summary>
		ddl,
		/// <summary>List Box CSS class.</summary>
		lstbx,
		/// <summary>Label CSS class.</summary>
		lbl,
		/// <summary>TextBox CSS class.</summary>
		tbx,
		/// <summary>CheckBox CSS class.</summary>
		chk,
        /// <summary>CheckBoxList CSS class.</summary>
        chklst,
		/// <summary>Button CSS class.</summary>
		btn,
		/// <summary>Input Button CSS class.</summary>
		btninput,
		/// <summary>LinkButton CSS class.</summary>
		lnkbtn,
		/// <summary>Image CSS class.</summary>
		img,
		/// <summary>ImageButton CSS class.</summary>
		imgbtn,
		/// <summary>RadioButtonList list CSS class.</summary>
		rdlst,
		/// <summary>RadioButton CSS class. </summary>
		rdbtn,
		/// <summary>CheckButtonImage  CSS class. </summary>
		chkbtnimg,
		/// <summary>AutoScroll  CSS class. </summary>
		atscrll,
		/// <summary>ToolTipHelp  CSS class. </summary>
		tthelp,
		/// <summary>UpDown CSS class. </summary>
        updown,
		/// <summary>Table Calendar CSS class. </summary>
		dtarea,
		/// <summary>TableCell Calendar Data CSS class. </summary>
		dtdata,
		/// <summary>TableCell Calendar Commands CSS class. </summary>
		dtcmds,
	}

	/// <summary>Contains the <see cref="Type"/> of the basic controls. </summary>
	public class BasicType
	{
        ///// <summary>Represents a <see cref="Button"/> type. </summary>
        //public static readonly Type Button				= typeof(Basic.Button);
		/// <summary>Represents a <see cref="CheckBox"/> type. </summary>
		public static readonly Type CheckBox			= typeof(Basic.CheckBox);
		/// <summary>Represents a <see cref="DropDownList"/> type. </summary>
		public static readonly Type DropDownList		= typeof(Basic.DropDownList);
		/// <summary>Represents a <see cref="Label"/> type. </summary>
		public static readonly Type Label				= typeof(Basic.Label);
        ///// <summary>Represents a <see cref="LinkButton"/> type. </summary>
        //public static readonly Type LinkButton			= typeof(Basic.LinkButton);
		/// <summary>Represents a <see cref="TableSection"/> type. </summary>
		public static readonly Type TableSection		= typeof(Basic.TableSection);
		/// <summary>Represents a <see cref="TableRowSection"/> type. </summary>
		public static readonly Type TableRowSection		= typeof(Basic.TableRowSection);
		/// <summary>Represents a <see cref="TextBox"/> type. </summary>
		public static readonly Type TextBox				= typeof(Basic.TextBox);
		/// <summary>Represents a <see cref="Lookup"/> type. </summary>
		public static readonly Type Lookup				= typeof(Basic.Lookup);
		/// <summary>Represents a <see cref="Date"/> type. </summary>
		public static readonly Type Date				= typeof(Basic.Date);
		/// <summary>Represents a <see cref="RadioButtonList"/> type. </summary>
		public static readonly Type RadioButtonList		= typeof(Basic.RadioButtonList);
		/// <summary>Represents a <see cref="ListBox"/> type. </summary>
		public static readonly Type ListBox				= typeof(Basic.ListBox);
        /// <summary>Represents a <see cref="CheckBoxList"/> type. </summary>
        public static readonly Type CheckBoxList        = typeof(Basic.CheckBoxList);
        /// <summary>Represents a <see cref="FileUpload"/> type. </summary>
        public static readonly Type FileUpload = typeof(Basic.FileUpload);
		private BasicType(){}
	}

	public class BasicConst
    {
		public const string		MonitorEnterKeyScriptKey		= "MonitorEnterKey";
		public const string		MonitorPageEnterKeyScriptKey	= "MonitorPageEnterKey";
		//public const string		MonitorEnterKeyScriptName		= "Scripts/MonitorEnterKey.js";
		//public static string	MonitorEnterKeyScript			= string.Format("<script language=\"javascript\" src=\"{0}\"></script>", Utils.GetAbsoluteUrl(MonitorEnterKeyScriptName));
        //public static string	MonitorPageEnterKeyScript		= "<script language=\"javascript\">PageButton = '{0}';document.body.onkeydown = TrapPageKB;</script>";
		public static string	MonitorPageEnterKeyScript		= "<script language=\"javascript\">PageButton = '{0}';document.onkeypress = TrapPageKB;</script>";
		public const string		ListBoxScriptKeyName			= "Listboxscript";
		//public const string		ListBoxScriptFileName			= "Scripts/ListBox.js";
		//public static string	PlaceHolderImgPath			    = Utils.GetAbsoluteUrl(WebConstant.ImgPlaceHolder);
	}
}
