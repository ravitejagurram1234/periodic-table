using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Web.UI.WebControls;
using QXPData = QXP.Framework.Data;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>
    /// Class DropDownList : Contr�le de base des basic dropdownlist
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class DropDownList : BaseDropDownList
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de DropDownList
        /// </summary>
        /// <summary>Creates a new instance of <see cref="DropDownList"/> control. </summary>
        public DropDownList()
            : base()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Binds a data source to the invoked dropdown-list.
        /// </summary>
        public override void DataBind()
        {
            base.DataBind();

            object __dataSource;

            if (Validation.IsSet(this.DataMember))
            {
                __dataSource = QXPData.DataSourceResolver.GetResolvedDataSource(this.DataSource, this.DataMember);
            }
            else
            {
                __dataSource = DataSource;
            }

            IEnumerable __iEnumerable = __dataSource as IEnumerable;

            if (Validation.IsNull(__iEnumerable))
                return;

            DataSourceType __dataSourceType = DataSourceType.Unknown;
            PropertyInfo __indexer = null;
            int __arrayRank = 1;
            string __selectedValue = string.Empty;
            bool __alreadySelected = false;

            if (Validation.IsSet(SelectedValue))
            {
                __selectedValue = SelectedValue;
            }
            else
            {
                if (Validation.IsNotNull(this.DefaultValue))
                {
                    __selectedValue = Conversion.ToString(this.DefaultValue);
                }
            }

            List<ListItem> __listitems = new List<ListItem>();

            ICollection __iCollection = __iEnumerable as ICollection;

            if (Validation.IsNotNull(__iCollection))
                Items.Capacity = __iCollection.Count;


            IEnumerator __iEnumerator = __iEnumerable.GetEnumerator();
            try
            {
                if (__dataSource is System.Collections.Specialized.NameObjectCollectionBase)
                {
                    __dataSourceType = DataSourceType.NameValueCollection;
                    __indexer = __dataSource.GetType().GetProperty("Item", ValueType.ArrayOf1String);
                }
                else if (__dataSource is System.Collections.IDictionary)
                {
                    __dataSourceType = DataSourceType.Dictionary;
                }
                else if (__dataSource is System.Array)
                {
                    __dataSourceType = DataSourceType.Array;
                    __arrayRank = ((Array)__dataSource).Rank;
                }
                else
                {
                    if (__iEnumerator is IDictionaryEnumerator)
                        __dataSourceType = DataSourceType.Dictionary;
                }

                while (__iEnumerator.MoveNext())
                {
                    string __itemValue, __itemText, __key;
                    object __value;
                    object __entry = __iEnumerator.Current;

                    switch (__dataSourceType)
                    {
                        case DataSourceType.NameValueCollection:
                            __key = Conversion.ToString(__entry);
                            __value = QXPData.DataBinder.GetIndexedValue(__indexer, __dataSource, __key);
                            break;
                        case DataSourceType.Dictionary:
                            DictionaryEntry __dictionaryEntry = (DictionaryEntry)__entry;
                            __key = Conversion.ToString(__dictionaryEntry.Key);
                            __value = __dictionaryEntry.Value;
                            break;
                        case DataSourceType.Array:
                            __key = Conversion.ToString(__entry);
                            for (int __i = 1; __i < __arrayRank; __i++) __iEnumerator.MoveNext();
                            __value = __iEnumerator.Current;
                            break;
                        default:
                            __key = Conversion.ToString(__entry);
                            __value = __entry;
                            break;
                    }

                    __itemText = GetDataTextField(__value);

                    //DataValueField
                    if (Validation.IsSet(this.DataValueField))
                        __itemValue = Conversion.ToString(QXPData.DataBinder.Eval(__value, this.DataValueField, null));
                    else
                        __itemValue = __key;

                    __alreadySelected = __alreadySelected || (__itemValue == __selectedValue);

                    this.AddItem(__listitems, __itemValue, __itemText, __itemValue == __selectedValue);
                }

                base.Sort(__listitems);
                base.FinalizeCommonDataBind(__listitems, __alreadySelected);
            }
            catch (Exception)
            {
            }
            finally
            {
                IDisposable __iDisposable = __iEnumerator as IDisposable;
                if (Validation.IsNotNull(__iDisposable))
                    __iDisposable.Dispose();
            }
        }

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        /// <summary>
        /// Gets or sets the value of default selected item.
        /// </summary>
        public object DefaultValue
        {
            get { return base.DefaultValue; }
            set { base.DefaultValue = value; }
        }

        #endregion Propri�t�s
    }
}
