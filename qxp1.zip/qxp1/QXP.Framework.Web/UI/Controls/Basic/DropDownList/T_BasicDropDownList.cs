using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.UI.WebControls;
using QXP.Framework.Extensions;
using QXPData = QXP.Framework.Data;
using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>
    /// Class T_DropDownList : Control web dropdownlist
    /// </summary>
    /// <author>LCU</author>
    /// <date>10/01/2011</date>  
    public class DropDownList<T> : BaseDropDownList
        where T : new()
    {
        #region Membres

        T _defaultObjectValue = default(T);
        T _selectedValueObject = default(T);

        #endregion Membres

        #region Constantes

        protected const Char ValueSeparator = '�';
        protected const String TextSeparator = ", ";
        private const string VSIndexSelectedValueField = "VSIndexSelectedValueField";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de DropDownList
        /// </summary>
        /// <summary>Creates a new instance of <see cref="DropDownList"/> control. </summary>
        public DropDownList()
            : base()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Lors de la cr�ations des contr�les
        /// </summary>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            if (Validation.IsNotSet(this.DataValueFields))
            {
                this.DataValueFields =
                    from property in typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                    where Validation.IsPrimitiveValueType(property.PropertyType) && property.CanWrite && property.CanRead
                    select property.Name;
            }
        }

        /// <summary>Binds a data source to the invoked dropdown-list. </summary>
        public override void DataBind()
        {
            base.DataBind();

            if (Validation.IsNull(this.DataSource))
                return;

            string __selectedValue = string.Empty;
            bool __alreadySelected = false;

            if (Validation.IsSet(SelectedValue))
            {
                __selectedValue = base.SelectedValue;
            }
            else if (Validation.IsNotNull(this.DefaultValue))
            {
                __selectedValue = ConversionInvariante.ToString(base.DefaultValue);
            }

            List<ListItem> __listitems = new List<ListItem>();

            Items.Capacity = this.DataSource.Count();

            if (Validation.IsSet(DataValueFields))
            {
                int __index = 0;
                DataValueFields.ForEach
                (
                    dataValue =>
                    {
                        if (Validation.IsSet(DataSelectedValueField) && dataValue == DataSelectedValueField)
                            this.IndexSelectedValueField = __index;
                        __index++;
                    }
                );
            }

            foreach (T __entry in this.DataSource)
            {
                string __itemValue, __itemText;
                T __value = __entry;
                string __key = Conversion.ToString(__entry);


                __itemText = GetDataTextField(__value);

                if (Validation.IsSet(DataValueFields))
                {
                    IEnumerable<string> __itemValues = DataValueFields.Select
                        (
                            dataValue =>
                            {
                                return ConversionInvariante.ToString(QXPData.DataBinder.Eval(__value, dataValue));
                            }
                        );
                    __itemValue = string.Join(ValueSeparator.ToString(), __itemValues.ToArray());
                }
                else
                {
                    __itemValue = __key;
                }

                bool __isSelectedValue = Validation.IsSet(DataSelectedValueField) && (ConversionInvariante.ToString(QXPData.DataBinder.Eval(__value, DataSelectedValueField)) == __selectedValue);

                __alreadySelected = __alreadySelected || __isSelectedValue;
                this.AddItem(__listitems, __itemValue, __itemText, __isSelectedValue);
            }

            base.Sort(__listitems);
            base.FinalizeCommonDataBind(__listitems, __alreadySelected);
        }

        /// <summary>
        /// D�finit l'�l�ment s�lectionn� dans la liste des items
        /// </summary>
        /// <param name="selectedValue">selectedValue</param>
        private void SetSelectedItem(string selectedValue)
        {
            //Dans le cas ou il n'y � aucun index de selection il n'y a rien � selectionner !
            if(QXPFrk.Validation.IsNotSet(this.IndexSelectedValueField)) return;

            foreach (ListItem __item in this.Items)
            {
                string[] __values = __item.Value.Split(ValueSeparator);
                if (this.IndexSelectedValueField >= __values.Length)
                {
                    break;
                }
                if (__values[this.IndexSelectedValueField] == selectedValue)
                {
                    __item.Selected = true;
                    break;
                }
            }
        }

        /// <summary>
        /// Retourne l'itemtext associ� � l'objet bind� en fonction de la propri�t� DataTextFields et DataTextFormatString
        /// </summary>
        /// <param name="value">Objet</param>
        /// <returns>Valeur de l'itemtext</returns>
        protected override string GetDataTextField(object value)
        {
            string __itemText = null;
            if (Validation.IsSet(DataTextFields))
            {
                IEnumerable<string> __itemTexts = DataTextFields.Select
                    (
                        dataText =>
                            Validation.IsSet(this.DataTextFormatString) ? string.Format(this.DataTextFormatString, QXPData.DataBinder.Eval(value, dataText))
                                                                        : Conversion.ToString(QXPData.DataBinder.Eval(value, dataText))
                    );
                if (Validation.IsSet(__itemTexts))
                    __itemText = string.Join(TextSeparator.ToString(), __itemTexts.Where(__item => Validation.IsSet(__item)).ToArray());                
            }
            else
                __itemText = base.GetDataTextField(value);
            return __itemText;
        }

        /// <summary>
        /// Retourne l'object correspondant aux valeurs stock�es dans la selectedValue
        /// selectedValues contient un la liste des valeurs des membres connues dans DataValueFields
        /// </summary>
        /// <param name="selectedValues">Liste des valeurs de chaque membre</param>
        /// <returns>Objet de type T</returns>
        private T GetObject(IEnumerable<string> selectedValues)
        {
            T __object = new T();
            var __properties = from property in typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                    where Validation.IsPrimitiveValueType(property.PropertyType) && property.CanWrite && property.CanRead
                    select property;

            int __i = 0;
            selectedValues.ForEach
            (
                selectedValue => { SetValue(__object, __properties.First(p => p.Name == DataValueFields.ToList()[__i] && p.CanWrite), selectedValue); __i++; }
            );
            return __object;
        }

        /// <summary>
        /// D�finit la valeur de la propri�t� de l'objet
        /// </summary>
        /// <param name="object">Objet mis � jour</param>
        /// <param name="propertyInfo">Propri�t� � mettre � jour</param>
        /// <param name="selectedValue">Valeur de la propri�t�</param>
        private void SetValue(T Object, PropertyInfo propertyInfo, string selectedValue)
        {
            if (propertyInfo.PropertyType.IsEnum)
                propertyInfo.SetValue(Object, Conversion.ToEnum(propertyInfo.PropertyType, selectedValue), null);
            else
                propertyInfo.SetValue(Object, ConversionInvariante.ToObject(selectedValue, propertyInfo.PropertyType), null);
        }

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        /// <summary>
        /// Nom de la prori�t� d�finissant la cl� primaire de l'objet
        /// (Utilis� notamment pour reselectionner un �l�ment du dropdownlist)
        /// </summary>
        public string DataSelectedValueField
        {
            get;
            set;
        }

        /// <summary>
        /// Liste des DataTextField � utiliser lors du binding (chaque DataTextField sera affich�e)
        /// </summary>
        public IEnumerable<string> DataTextFields
        {
            get;
            set;
        }

        /// <summary>
        /// Liste des datavaluefield � utiliser lors du binding (chaque datavaluefield sera m�moris�e dans la valeur de l'item)
        /// </summary>
        public IEnumerable<string> DataValueFields
        {
            get;
            set;
        }

        /// <summary>
        /// DataSource
        /// </summary>
        public new IEnumerable<T> DataSource
        {
            get;
            set;
        }

        /// <summary>
        /// Valeur par d�faut
        /// </summary>
        public T DefaultValueObject
        {
            get
            {
                return _defaultObjectValue;
            }
            set
            {
                _defaultObjectValue = value;
                if (Validation.IsSet(DataSelectedValueField))
                    base.DefaultValue = ConversionInvariante.ToString(QXPData.DataBinder.Eval(value, DataSelectedValueField));
            }
        }

        /// <summary>
        /// Element s�lectionn�
        /// </summary>
        public T SelectedValueObject
        {
            get
            {
                if (QXPFrk.Validation.IsNull(_selectedValueObject))
                {
                    _selectedValueObject = default(T);
                    if (QXPFrk.Validation.IsNotNull(this.SelectedItem) && Validation.IsSet(DataValueFields))
                    {
                        if (base.SelectedValue.Split(ValueSeparator).Count() == DataValueFields.Count())
                        {
                            _selectedValueObject = GetObject(base.SelectedValue.Split(ValueSeparator).ToList());
                        }
                    }
                }
                return _selectedValueObject;
            }
            set
            {
                _selectedValueObject = value;
                this.ClearSelection();
                if (Validation.IsSet(DataSelectedValueField))
                    SetSelectedItem(ConversionInvariante.ToString(QXPData.DataBinder.Eval(value, DataSelectedValueField)));
            }
        }


        /// <summary>
        /// Valeur en string de l'�lement s�lectionn�
        /// </summary>
        public override string SelectedValue
        {
            get
            {
                if (Validation.IsSet(DataSelectedValueField) && Validation.IsSet(base.SelectedValue) && Validation.IsSet(this.IndexSelectedValueField))
                {
                    string[] __values = base.SelectedValue.Split(ValueSeparator);
                    if (this.IndexSelectedValueField >= __values.Length)
                    {
                        return base.SelectedValue;
                    }
                    return __values[this.IndexSelectedValueField];
                }
                else
                    return base.SelectedValue;
            }
            set
            {
                this.ClearSelection();
                if (Validation.IsSet(DataSelectedValueField))
                    SetSelectedItem(value);
            }
        }

        /// <summary>
        /// Position dans la value des items de la valeur correspondante � la propri�t� stock� dans DataSelectedValueField
        /// </summary>
        private int IndexSelectedValueField
        {
            get
            {
                return Conversion.ToInt(this.ViewState[VSIndexSelectedValueField]);
            }
            set
            {
                this.ViewState[VSIndexSelectedValueField] = value;
            }
        }

        #endregion Propri�t�s
    }
}
