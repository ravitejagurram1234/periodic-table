using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using QXPData = QXP.Framework.Data;
using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>
    /// Class BaseDropDownList : Contr�le de base des basic dropdownlist
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class BaseDropDownList : Anthem.DropDownList, ICausesValidation
    {
        #region Membres

        private static readonly string DefaultCss = Basic.CssClass.ddl.ToString();

        private string _selectedValue = null;
        private object _defaultValue = null;
        protected int _maxItemsCount = 20000;
        protected int _maxTextLength = 40;
        private bool _isSorted = false;
        protected string _emptyValue = DefaultEmptyValue;
        protected string _emptyText = null;

        #endregion Membres

        #region Constantes

        internal const string DefaultEmptyValue = "-1";
        private const string VSEnableEmptySelectionKey = "VSEnableEmptySelection";
        private const string VSDisableAutoComplete = "VSDisableAutoComplete";
        private const string VSAutoComplete_OnChange = "VSAutoComplete_OnChange";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de BaseDropDownList
        /// </summary>
        /// <summary>Creates a new instance of <see cref="DropDownList"/> control. </summary>
        public BaseDropDownList()
        {
            base.CssClass = DefaultCss;
            this.EnabledDuringCallBack = false;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Binds a data source to the invoked dropdown-list.
        /// </summary>
        public override void DataBind()
        {
            this.Items.Clear();
            this.ClearSelection();
        }

        /// <summary>
        /// Termine les actions communues du DataBind
        /// </summary>
        /// <param name="listitems">Elements qui seront contenus dans la dropdownlist</param>
        /// <param name="alreadySelected">Indique si un �l�ment est d�j� s�lectionn�</param>
        protected virtual void FinalizeCommonDataBind(List<ListItem> listitems, bool alreadySelected)
        {
            if (Validation.IsSet(_maxTextLength, false))
            {
                foreach (ListItem __item in listitems)
                {
                    __item.Text = StringHelper.StartString(__item.Text, _maxTextLength);
                }
            }

            if (this.EnableEmptySelection)
            {
                if (Validation.IsNull(_emptyText))
                    _emptyText = string.Empty;

                this.AddItem(listitems, 0, _emptyValue, _emptyText, !alreadySelected);
                alreadySelected = true;
            }

            ListItem[] __items = listitems.ToArray();

            //INFO: Limit Items count to maxItemsCount.
            if (__items.Length > _maxItemsCount)
            {
                ListItem[] __dimmedItems = new ListItem[_maxItemsCount];
                Array.Copy(__items, __dimmedItems, _maxItemsCount);
                __items = __dimmedItems;
            }

            this.Items.AddRange(__items);

            if (!alreadySelected && __items.Length > 0)
                this.SelectedIndex = 0;
        }

        /// <summary>
        /// Retourne l'itemtext associ� � l'objet bind� en fonction de la propri�t� DataTextField et DataTextFormatString
        /// </summary>
        /// <param name="value">Objet</param>
        /// <returns>Valeur de l'itemtext</returns>
        protected virtual string GetDataTextField(object value)
        {
            string __itemText = string.Empty;

            if (Validation.IsSet(DataTextField))
            {
                __itemText = Conversion.ToString(QXPData.DataBinder.Eval(value, DataTextField, DataTextFormatString));
            }
            else
            {
                if (Validation.IsSet(DataTextFormatString))
                    __itemText = string.Format(DataTextFormatString, value);
                else
                    __itemText = Conversion.ToString(value);
            }
            return __itemText;
        }

        /// <summary>
        /// Effectue un tri sur les �l�ments de la liste
        /// </summary>
        /// <param name="listitems">Elements de la liste</param>
        protected void Sort(List<ListItem> listitems)
        {
            if (this.IsSorted)
            {
                ArrayHelper.Sort(listitems, new Comparers.ListItemComparer());
            }
        }

        protected void AddItem(List<ListItem> listitems, string @value, string text, bool selected)
        {
            this.AddItem(listitems, listitems.Count, value, text, selected);
        }

        protected void AddItem(List<ListItem> listitems, int index, string @value, string text, bool selected)
        {
            ListItem __listItem = new ListItem();
            __listItem.Value = value;
            __listItem.Text = text;
            __listItem.Selected = selected;
            listitems.Insert(index, __listItem);
        }

        protected override object SaveViewState()
        {
            object VS = base.SaveViewState();
            return VS;
        }

        protected override void LoadViewState(object savedState)
        {
            base.LoadViewState(savedState);
        }

        #endregion M�thodes

        #region Evenements

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            this.Page.RegisterClientScriptBlock(BasicConst.ListBoxScriptKeyName, string.Format("<script language=\"javascript\" src=\"{0}\"></script>", AbsoluteFilesPath.ListBoxScript));
        }

        protected override void OnSelectedIndexChanged(EventArgs e)
        {
            if (this.CausesValidation && !this.Page.IsValid) return;
            base.OnSelectedIndexChanged(e);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            if (!this.DisableAutoComplete)
            {
                this.Attributes["onkeypress"] = "return LookupElement_onkeypress(this,false,event);";
                this.Attributes["onkeyup"] = "LookupElement_onkeyup(this, event);";
                string __mychange = "LookupElement_onchange(this);";
                string __userchange = AutoComplete_OnChange;
                if (Validation.IsSet(__userchange))
                {
                    __mychange = __userchange + __mychange;
                }

                this.Attributes["onfocus"] = "LookupElement_onfocus(this);";


                if (Validation.IsNotNull(this.Attributes["onchange"]))
                {
                    this.Attributes["onchange"] = this.Attributes["onchange"].Replace(__mychange, string.Empty);
                    this.Attributes["onchange"] = string.Concat(__mychange, this.Attributes["onchange"]);
                }
                else
                    this.Attributes["onchange"] = __mychange;

                this.Attributes["onblur"] = "LookupElement_onblur(this);";
            }
        }

        #endregion Evenements

        #region Propri�t�s

        /// <summary>Gets or sets the maximum number of items displayed in the list. </summary>
        public int MaxItemsCount
        {
            get { return _maxItemsCount; }
            set { _maxItemsCount = value; }
        }

        /// <summary>Gets or sets the maximum number of item text length. </summary>
        public int MaxTextLength
        {
            get { return (_maxTextLength); }
            set { _maxTextLength = value; }
        }

        /// <summary>Gets or sets whether the items in the list are sorted. </summary>
        public bool IsSorted
        {
            get { return (_isSorted); }
            set { _isSorted = value; }
        }

        /// <summary>Gets or sets the value of default selected item. </summary>
        public object DefaultValue
        {
            get { return _defaultValue; }
            set { _defaultValue = value; }
        }

        /// <summary>Gets or sets if an empty item will be added to the list. </summary>
        /// <remarks>This empty item will be used to enable empty selection in a dropdown-list control. </remarks>
        public bool EnableEmptySelection
        {
            get { return Conversion.ToBool(this.ViewState[VSEnableEmptySelectionKey]); }
            set { this.ViewState[VSEnableEmptySelectionKey] = value; }
        }

        /// <summary>
        /// Disable AutoComplete functionnality
        /// </summary>
        public bool DisableAutoComplete
        {
            get { return Conversion.ToBool(this.ViewState[VSDisableAutoComplete]); }
            set { this.ViewState[VSDisableAutoComplete] = value; }
        }

        /// <summary>
        /// Definir code javascript de l'evenement onchange sur un controle avec autocomplete activ�
        /// </summary>
        public string AutoComplete_OnChange
        {
            get { return Conversion.ToString(this.ViewState[VSAutoComplete_OnChange]); }
            set { this.ViewState[VSAutoComplete_OnChange] = value; }
        }

        /// <summary>Gets or sets the value of the empty item. </summary>
        public string EmptyValue
        {
            get { return _emptyValue; }
            set { _emptyValue = value; }
        }

        /// <summary>Gets or sets the text of the empty item. </summary>
        public string EmptyText
        {
            get { return _emptyText; }
            set { _emptyText = value; }
        }

        public string SelectedText
        {
            get
            {
                if (QXPFrk.Validation.IsNotNull(this.SelectedItem))
                {
                    return this.SelectedItem.Text;
                }
                return string.Empty;
            }
        }

        public override string SelectedValue
        {
            get
            {
                if (QXPFrk.Validation.IsNotNull(this.SelectedItem))
                {
                    return this.SelectedItem.Value;
                }
                return string.Empty;
            }
            set
            {
                this.ClearSelection();
                ListItem __item = this.Items.FindByValue(value);
                if (Validation.IsNotNull(__item))
                {
                    __item.Selected = true;
                }
            }
        }

        /// <summary>Determines whether the current selected item corresponding to the empty element. </summary>
        public bool IsEmptySelected
        {
            get { return Validation.IsNotSet(this.SelectedValue) || (this.EnableEmptySelection && this.SelectedValue == _emptyValue); }
        }

        #endregion Propri�t�s
    }
}
