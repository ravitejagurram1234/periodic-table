using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    public interface ITextable
    {
        string Text { get; set;}
    }
}
