using System;

namespace QXP.Framework.Web.UI.Controls.Basic{
	/// <summary>Displays an image on a Web page. <seealso cref="System.Web.UI.WebControls.Image"/></summary>
	public class ImageButton : Anthem.ImageButton, ICausesValidation
    {
		#region internal variables
		private static readonly string DefaultCss = Basic.CssClass.imgbtn.ToString();
		#endregion
		/// <summary>Initializes a new instance of <see cref="Image"/> control. </summary>
		public ImageButton() {
			base.CssClass               = DefaultCss;
            this.EnabledDuringCallBack  = false;
		}
		/// <summary>Initializes a new instance of <see cref="Image"/> control. </summary>
		/// <param name="imageUrl">The location of an image to display in the Image control. </param>
		public ImageButton(string imageUrl): this(){
			if(Validation.IsSet(imageUrl)) this.ImageUrl	= imageUrl;
		}
		/// <summary>Initializes a new instance of <see cref="Image"/> control. </summary>
		/// <param name="imageUrl">The location of an image to display in the Image control. </param>
		/// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
		public ImageButton(string imageUrl, string cssClass): this(imageUrl){
			if(Validation.IsSet(cssClass)) this.CssClass = cssClass;
		}
		/// <summary>Initializes a new instance of <see cref="Image"/> control. </summary>
		/// <param name="imageUrl">The location of an image to display in the Image control. </param>
		/// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
		public ImageButton(string imageUrl, string cssClass, string tooltip, string command): this(imageUrl, cssClass)
		{
			this.ToolTip		= tooltip;
			this.CommandName	= command;
		}
		public ImageButton(string imageUrl, Enum cssClass, string tooltip, Enum command): this(imageUrl, Conversion.ToString(cssClass), tooltip, Conversion.ToString(command))
		{
		}
		public ImageButton(string imageUrl, Enum cssClass, string tooltip, Enum command, object arg): this(imageUrl, cssClass, tooltip, command)
		{
			this.CommandArgument = Conversion.ToString(arg);
		}
        protected override void OnClick(System.Web.UI.ImageClickEventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnClick(e);
        }
        protected override void OnCommand(System.Web.UI.WebControls.CommandEventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnCommand(e);
        }

        public new string Text
        {
            get { return this.ToolTip; }
            set { this.ToolTip = value; }
        }
	}
}