using System;

namespace QXP.Framework.Web.UI.Controls.Basic{
	/// <summary>Displays an image on a Web page. <seealso cref="System.Web.UI.WebControls.Button"/></summary>
	public class Button : Anthem.Button, ICausesValidation
    {
		#region internal variables
		private static  readonly    string DefaultCss           = Basic.CssClass.btn.ToString();
        private const               string VSConfirmMessage     = "ConfirmMessage";
        private const               string ConfirmScriptPattern = "if(!confirm('{0}')) return false;";
		#endregion
		/// <summary>Initializes a new instance of <see cref="Button"/> control. </summary>
		public Button() {
			base.CssClass               = DefaultCss;
            this.EnabledDuringCallBack  = false;
		}
		/// <summary>Initializes a new instance of <see cref="Button"/> control. </summary>
		/// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
		public Button(string cssClass): this(){
			if(Validation.IsSet(cssClass)) this.CssClass = cssClass;
		}
		public void MonitorEnterKey(System.Web.UI.Control control){
			MonitorEnterKeyTools.MonitorEnterKey(this.Page, control, this);
		}
		public void MonitorEnterKey(System.Web.UI.Control[] controls)
		{
			MonitorEnterKeyTools.MonitorEnterKey(this.Page, controls, this);
		}
        protected override void OnClick(EventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnClick(e);
        }
        protected override void OnCommand(System.Web.UI.WebControls.CommandEventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnCommand(e);
        }
        protected override void AddAttributesToRender(System.Web.UI.HtmlTextWriter writer) {
            if(Validation.IsSet(ConfirmMessage)){
                string __confirmScript = string.Format(ConfirmScriptPattern, this.ConfirmMessage);
                ControlUtility.AddScriptAttribute(this, "onclick", __confirmScript);
            }
            base.AddAttributesToRender(writer);
        }
        public string ConfirmMessage{
            get{return Conversion.ToString(this.ViewState[VSConfirmMessage]);}
            set{this.ViewState[VSConfirmMessage] = value;}
        }
	}
}