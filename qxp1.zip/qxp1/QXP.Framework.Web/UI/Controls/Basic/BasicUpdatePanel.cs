using System;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>
    /// Class UpdatePanel : UpdatePanel encapsulant un Panel du Framework
    /// A utiliser pour la MAJ AJAX NET des panels
    /// </summary>
    /// <author>LCU</author>
    /// <date>07/03/2011</date>    
    public class UpdatePanel : Extensions.UpdatePanel
    {
        #region Membres

        Panel _pnl;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr��e une instance d'UpdatePanel
        /// </summary>
        public UpdatePanel()
        {
            _pnl = new Panel();
            _pnl.AjaxMode = Anthem.AjaxMode.AjaxNet;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Lors de la cr�ations des contr�les
        /// </summary>        
        protected override void CreateConstituantControls(object sender, EventArgs ea)
        {
            base.CreateConstituantControls(sender, ea);
            this.ContentTemplate = new Template(_pnl);
        }

        /// <summary>
        /// Lors du binding du controle
        /// </summary>
        protected override void ControlDataBind(object sender, EventArgs ea)
        {
            base.ControlDataBind(sender, ea);
        }

        /// <summary>
        /// Lors du PreRender du controle
        /// </summary>
        protected override void ControlPreRender(object sender, EventArgs ea)
        {
            base.ControlPreRender(sender, ea);
        }

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        public BasePage QXPPage
        {
            get { return this.Page as BasePage; }
        }

        public bool HasHeader
        {
            get { return _pnl.HasHeader; }
            set { _pnl.HasHeader = value; }
        }

        public bool HasTitle
        {
            get { return _pnl.HasTitle; }
            set { _pnl.HasTitle = value; }
        }

        public bool ShowToggle
        {
            get { return _pnl.ShowToggle; }
            set { _pnl.ShowToggle = value; }
        }

        public bool IsCollapse
        {
            get { return _pnl.IsCollapse; }
            set { _pnl.IsCollapse = value; }
        }

        /// <summary>
        /// R�f�rence sur le control du titre
        /// </summary>
        public Label Control_Title
        {
            get { return _pnl.Control_Title; }
        }

        public string Title
        {
            get { return _pnl.Title; }
            set { _pnl.Title = value; }
        }

        public string Title_ToolTip
        {
            get { return _pnl.Title_ToolTip; }
            set { _pnl.Title_ToolTip = value; }
        }

        public int BackColorIndex
        {
            get { return _pnl.BackColorIndex; }
            set { _pnl.BackColorIndex = value; }
        }

        public bool IsValid
        {
            get { return _pnl.IsValid; }
        }

        #region Contained Objects

        public ItemSection Header
        {
            get { return _pnl.Header; }
        }

        public ItemSection Content
        {
            get { return _pnl.Content; }
        }

        public TableSection Content_Panel
        {
            get { return _pnl.Content_Panel; }
        }

        /// <summary>
        /// You Must used this property to add controls inside !!
        /// </summary>
        public WebControlSection Body
        {
            get { return _pnl.Body; }
        }

        /// <summary>
        /// Visibilit� du Panel contenu dans l'UpdatePanel
        /// </summary>
        public new bool Visible
        {
            get { return _pnl.Visible; }
            set { _pnl.Visible = value; }
        }

        /// <summary>
        /// Visibilit� du Panel contenu dans l'UpdatePanel
        /// </summary>
        public bool UpdatePanelVisible
        {
            get { return base.Visible; }
            set { base.Visible = value; }
        }

        #endregion

        #region Css Mapping

        public string CssClass_Title
        {
            get { return _pnl.CssClass_Title; }
            set { _pnl.CssClass_Title = value; }
        }

        public string CssClass_Header
        {
            get { return _pnl.CssClass_Header; }
            set { _pnl.CssClass_Header = value; }
        }

        public string CssClass_Content
        {
            get { return _pnl.CssClass_Content; }
            set { _pnl.CssClass_Content = value; }
        }

        public string CssClass_Body
        {
            get { return _pnl.CssClass_Body; }
            set { _pnl.CssClass_Body = value; }
        }

        public string CssClass
        {
            get { return _pnl.CssClass; }
            set { _pnl.CssClass = value; }
        }

        #endregion Css Mapping

        #region BaseComposant Mapping

        public Component.BaseComponent HostComponent
        {
            get { return _pnl.HostComponent; }
        }

        #endregion BaseComposant Mapping

        /// <summary>
        /// Type d'ajaxisation
        /// </summary>
        public Anthem.AjaxMode AjaxMode
        {
            get { return _pnl.AjaxMode; }
            set { _pnl.AjaxMode = value; }
        }

        #endregion Propri�t�s
    }
}
