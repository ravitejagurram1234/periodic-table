using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>Provides functionality to save/retrieves the scrolling browser position between postback. </summary>
	public		class AutoScroll : WebControl, IPostBackDataHandler 
	{
		#region internal variables
		private static readonly string	DefaultCss				= Basic.CssClass.atscrll.ToString();
		private static readonly string	AutoScrollTag			= HtmlTextWriterTag.Input.ToString();
		private const	string			KeyYPos					= "KeyYPos";
		private const	string			ControlToMonitorAtt		= "controltomonitor";
		private	WebControl				_controlToMonitor;
		#endregion
		/// <summary>Occurs when the scrolling position of the monitored control changed. </summary>
		public event EventHandler			ScrollChanged;
	
		/// <summary>Creates a new instance of <see cref="AutoScroll"/> control. </summary>
		public AutoScroll(): base(AutoScrollTag)
		{
			base.CssClass = DefaultCss;
		}
		/// <summary>Creates a new instance of <see cref="AutoScroll"/> control which monitor specified <see cref="controlToMonitor"/> scrooling values. </summary>
		/// <param name="controlToMonitor">The <see cref="Control"/> to monitor. </param>
		public AutoScroll(WebControl controlToMonitor): this()
		{
			this.ControlToMonitor = controlToMonitor;
		}
		/// <summary>Occurs when the control need to initialize. </summary>
		/// <param name="ea"></param>
		protected override	void		OnInit(EventArgs ea)
		{
			base.OnInit(ea);

			//INFO: force ID definition !!
			this.ID = this.ID;
			
			if(this.Enabled)
			{
				//INFO: add __EventTarget hidden field to prevent autopostback js script error !!!
				this.Page.GetPostBackEventReference(this);
			}
		}
		/// <summary>Gets or sets the scrolling position of the element. </summary>
		public				int			Position
		{
			get{return Conversion.ToInt(this.ViewState[KeyYPos]);}
			set{this.ViewState[KeyYPos] = value;}
		}
		bool System.Web.UI.IPostBackDataHandler.LoadPostData(string postDataKey, NameValueCollection postCollection) 
		{
			int __newpos		= Conversion.ToInt(postCollection[postDataKey]);
			int __oldpos		= this.Position;
				
			if (!__oldpos.Equals(__newpos)) 
			{
				this.Position = __newpos;
				return true; 
			}
			return false; 
		}
		void System.Web.UI.IPostBackDataHandler.RaisePostDataChangedEvent() 
		{
			this.OnScrollChanged(this, EventArgs.Empty);
		}
		/// <summary>Occurs when the scrolling position of the client control changed. </summary>
		/// <param name="sender"></param>
		/// <param name="ea"></param>
		protected virtual void			OnScrollChanged(object sender, EventArgs ea)
		{
			if(Validation.IsNotNull(ScrollChanged))
			{
				this.ScrollChanged(this, ea);
			}
		}
		/// <summary>Gets or sets the Control to monitor scrolling position. </summary>
		/// <remarks>If ControlToMonitor is null then the entire page is monitored. </remarks>
		public WebControl				ControlToMonitor
		{
			get{return _controlToMonitor;}
			set
			{
				_controlToMonitor = value;
				if(Validation.IsNotNull(value))
				{
					//FORCE ID control to rendering !!
					if(!Validation.IsSet(_controlToMonitor.ID))
					{
						_controlToMonitor.ID = _controlToMonitor.ID;
					}
				}
			}
		}
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender (e);
			if(this.Enabled){

				ClientScript __clientScript = new ClientScript(this, "AutoScrollJS", string.Format("<script language=\"javascript\" src=\"{0}\" type=\"text/javascript\"></script>", AbsoluteFilesPath.AutoScrollScript));
				__clientScript.Register();

				//La methode setTimeout permet de supprimer un bug de rafraichissement sous IE ^^
				ClientScript __initClientScript = new ClientScript(this, "InitScroll" + this.ClientID, string.Format("<script language=\"javascript\">window.setTimeout(\"InitScrollPos('{0}', '{1}')\", 0);</script>", _controlToMonitor.ClientID, this.ClientID));
				__initClientScript.Register();

				_controlToMonitor.Attributes["onscroll"] = string.Concat("try{", string.Format("UpdateScrollPos(this, '{0}')", this.ClientID), "}catch(e){};");
			}
		}

		/// <summary>See <see cref="System.Web.UI.WebControls.WebControl.CssClass"/>. </summary>
		public override string			CssClass
		{
			get{return base.CssClass;}
            set { base.CssClass = string.Concat(base.CssClass, QXPFrk.Constantes.Space, value).Trim(); }		 
		}
		#region Render Zone
		/// <summary>Occurs when the control need to add it's attributes to the render. </summary>
		/// <param name="writer">The <see cref="HtmlTextWriter"/> to write in. </param>
		protected override void			AddAttributesToRender(HtmlTextWriter writer) 
		{
			base.AddAttributesToRender (writer);
			writer.AddAttribute(HtmlTextWriterAttribute.Name, this.UniqueID);
			writer.AddAttribute(HtmlTextWriterAttribute.Type , "hidden");
			writer.AddAttribute(HtmlTextWriterAttribute.Value, Conversion.ToString(this.Position));
			if(Validation.IsNotNull(_controlToMonitor))
			{
				writer.AddAttribute(ControlToMonitorAtt, this.ControlToMonitor.ClientID);
			}
		}
		#endregion
	}
}