using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>
    /// Class InternalMultiView : D�finit une View Anthem enrichit
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class InternalMultiView : Anthem.MultiView
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de InternalMultiView
        /// </summary>
        public InternalMultiView()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// D�place la vue active de <paramref name="move"/> (sauts)
        /// Sur la vue finale calcul�e n'existe pas, le d�placement n'a pas lieu
        /// </summary>
        /// <param name="currentIndex">Index en cours de la vue</param>
        /// <param name="move">Nombre de sauts � effectuer</param>
        public void SetViewIndex(int currentIndex, int move)
        {
            View __view;
            int __newViewIndex = currentIndex + move;
            while (__newViewIndex > -1 && __newViewIndex < this.Views.Count)
            {
                __view = this.Views[__newViewIndex] as View;
                //Found enable view !!
                if (Validation.IsNotNull(__view) && __view.Enabled && __view.VisibleInTab)
                {
                    this.ActiveViewIndex = __newViewIndex;
                    break;
                }
                __newViewIndex += move;
            }
        }

        /// <summary>
        /// Red�finit la vue active
        /// </summary>
        /// <param name="newViewIndex">Nouvel index</param>
        private void SetViewIndex(int newViewIndex)
        {
            View __view = this.Views[newViewIndex] as View;
            if (Validation.IsNotNull(__view) && __view.Enabled && __view.VisibleInTab)
            {
                this.ActiveViewIndex = newViewIndex;
            }
        }

        #endregion M�thodes

        #region Evenements

        /// <summary>
        /// Se produit lors d'un �venement d'un control sous jacent.
        /// </summary>
        /// <param name="source">Control �metteur</param>
        /// <param name="e">EventArgs</param>
        /// <returns></returns>
        protected override bool OnBubbleEvent(object source, EventArgs e)
        {
            if (e is CommandEventArgs)
            {
                CommandEventArgs args = (CommandEventArgs)e;
                string commandName = args.CommandName;
                if (commandName == NextViewCommandName)
                {
                    this.SetViewIndex(this.ActiveViewIndex, +1);
                    return true;
                }
                if (commandName == PreviousViewCommandName)
                {
                    this.SetViewIndex(this.ActiveViewIndex, -1);
                    return true;
                }
                if (commandName == SwitchViewByIDCommandName)
                {
                    View __view = this.FindControl((string)args.CommandArgument) as View;
                    if (Validation.IsNull(__view) || (__view.Parent != this))
                    {
                        throw new Exception("View Problems");
                    }
                    if (__view.Enabled) this.SetActiveView(__view);
                    return true;
                }
                if (commandName == SwitchViewByIndexCommandName)
                {
                    int num;
                    try
                    {
                        num = int.Parse((string)args.CommandArgument, System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch (FormatException)
                    {
                        throw new FormatException();
                    }
                    this.SetViewIndex(num);
                    return true;
                }
            }
            return false;
        }

        #endregion Evenements

        #region Propri�t�s

        #endregion Propri�t�s
    }


    /// <summary>
    /// Class MultiView : MultiView GLASS
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class MultiView : WebControlSection
    {
        #region Membres

        InternalMultiView _multiView = new InternalMultiView();
        bool _showTitle;
        ITemplate _multiviewHeaderTemplate;
        WebControlSection _multiviewBody;
        public event EventHandler ActiveViewChanged;
        public event MultiViewTabs.ViewTabChangedHandler ViewTabChanged;
        bool _updateAfterCallBackTabs = false;

        #endregion Membres

        #region Constantes

        public const string NextViewCommandName = "NextView";
        public const string PreviousViewCommandName = "PrevView";
        public const string SwitchViewByIDCommandName = "SwitchViewByID";
        public const string SwitchViewByIndexCommandName = "SwitchViewByIndex";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de MultiView
        /// </summary>
        public MultiView()
            : base(HtmlTextWriterTag.Div)
        {
            _multiviewHeaderTemplate = new Template(typeof(MultiViewTabs), this);// new DefaultMultiViewHeader(this);
            _multiviewBody = new WebControlSection(HtmlTextWriterTag.Div);
            _multiView.ActiveViewChanged += new EventHandler(OnActiveViewChanged);
        }

        #endregion Constructeur

        #region M�thodes

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Validation.IsNotNull(_multiviewHeaderTemplate))
            {
                _multiviewHeaderTemplate.InstantiateIn(this);
            }
            this.Add(_multiviewBody);
            _multiviewBody.CssClass = "tab_body";
            this.CssClass = "tab_container";
            _multiviewBody.Add(_multiView);
        }

        public void SetActiveView(View view)
        {
            _multiView.SetActiveView(view);
        }

        public void GoToNextView()
        {
            _multiView.SetViewIndex(this.ActiveViewIndex, 1);
        }

        public void GoToPreviousView()
        {
            _multiView.SetViewIndex(this.ActiveViewIndex, -1);
        }

        /// <summary>
        /// Retourne l'index de la prochaine vue Enabled � partir de la vue active
        /// </summary>        
        /// <returns>int</returns>
        public int GetNextEnabledViewIndex()
        {
            return GetNextEnabledViewIndex(_multiView.ActiveViewIndex);
        }

        /// <summary>
        /// Retourne l'index de la prochaine vue Enabled � partir de l'index pass� en param�tre
        /// </summary>
        /// <param name="index">index de la vue courante</param>
        /// <returns>int</returns>
        public int GetNextEnabledViewIndex(int index)
        {
            index++;
            if (index >= _multiView.Views.Count)
                return int.MinValue;
            else
            {
                View __view = _multiView.Views[index] as View;
                if (__view.Enabled && __view.VisibleInTab)
                    return index;
                else
                    return GetNextEnabledViewIndex(index);
            }
        }

        /// <summary>
        /// Retourne l'index de la pr�c�dente vue Enabled � partir de la vue active
        /// </summary>        
        /// <returns>int</returns>
        public int GetPreviousEnabledViewIndex()
        {
            return GetPreviousEnabledViewIndex(_multiView.ActiveViewIndex);
        }

        /// <summary>
        /// Retourne l'index de la pr�c�dente vue Enabled � partir de l'index pass� en param�tre
        /// </summary>
        /// <param name="index">index de la vue courante</param>
        /// <returns>int</returns>
        public int GetPreviousEnabledViewIndex(int index)
        {
            index--;
            if (index < 0)
                return int.MinValue;
            else
            {
                View __view = _multiView.Views[index] as View;
                if (__view.Enabled && __view.VisibleInTab)
                    return index;
                else
                    return GetPreviousEnabledViewIndex(index);
            }
        }

        /// <summary>
        /// D�finit automatiquement la vue active � partir de l'index
        /// Si la vue active � d�finir n'est pas visible in tab, on active la suivante
        /// </summary>
        /// <param name="index">index</param>
        public void SetAutoActiveViewIndex(int index)
        {
            if (index == this.Views.Count)
                throw new Exception("Impossible de d�finir la vue active, tous les tabs du MultiView ne sont pas visibles");
            if (!((View)this.Views[index]).VisibleInTab)
                SetAutoActiveViewIndex(index + 1);
            else
                this.ActiveViewIndex = index;
        }

        #endregion M�thodes

        #region Evenements

        /// <summary>
        /// Lors d'un changement d'index de la vue
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="ea"></param>
        protected virtual void OnActiveViewChanged(object sender, EventArgs ea)
        {
            if (Validation.IsNotNull(this.ActiveViewChanged))
            {
                this.ActiveViewChanged(sender, ea);
            }
        }

        /// <summary>
        /// Lors d'un evenement remont� par l'un de ses controles enfants
        /// </summary>
        protected override bool OnBubbleEvent(object source, EventArgs args)
        {
            MultiViewTabsEventsArgs __mvTabsEventsArgs = args as MultiViewTabsEventsArgs;
            if (Validation.IsNotNull(__mvTabsEventsArgs))
            {
                if (Validation.IsNotNull(ViewTabChanged))
                {
                    ViewTabChanged(__mvTabsEventsArgs.SrcView, __mvTabsEventsArgs.DstView);
                    return false;
                }
            }

            return true;
        }

        #endregion Evenements

        #region Propri�t�s

        /// <summary>
        /// Vue Active
        /// </summary>
        public View ActiveView
        {
            get
            {
                if (ActiveViewIndex >= 0)
                    return (View)_multiView.Views[ActiveViewIndex];
                else
                    return null;
            }
        }

        public int ActiveViewIndex
        {
            get { return _multiView.ActiveViewIndex; }
            set { _multiView.ActiveViewIndex = value; }
        }

        public ViewCollection Views
        {
            get { return _multiView.Views; }
        }

        public bool ShowTitle
        {
            get { return _showTitle; }
            set { _showTitle = true; }
        }

        public ITemplate MultiviewHeaderTemplate
        {
            get { return _multiviewHeaderTemplate; }
            set { _multiviewHeaderTemplate = value; }
        }

        public bool UpdateAfterCallBackTabs
        {
            get { return _updateAfterCallBackTabs; }
            set { _updateAfterCallBackTabs = value; }
        }

        public bool UpdateAfterCallBackMultiView
        {
            get { return _multiView.UpdateAfterCallBack; }
            set { _multiView.UpdateAfterCallBack = value; }
        }

        #endregion Propri�t�s
    }


    /// <summary>
    /// Class MultiViewTabs : D�crit le template par d�faut de l'affichage du multiview (avec des onglets)
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class MultiViewTabs : TabsControl
    {
        #region Membres

        MultiView _host;

        public delegate void ViewTabChangedHandler(View srcView, View dstView);
        public event ViewTabChangedHandler ViewTabChanged;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de MultiViewTabs
        /// </summary>
        public MultiViewTabs(MultiView multiView)
        {
            _host = multiView;
            this.CssClass = "tab_header";
        }

        #endregion Constructeur

        #region M�thodes

        protected override void OnInit(EventArgs e)
        {
            this.BuildTabs();
            base.OnInit(e);
        }

        private void BuildTabs()
        {
            Tab __tab;
            int __index = 0;
            foreach (View __view in this.MultiView.Views)
            {
                __tab = new Tab();
                __tab.EnabledCallBack = __view.EnabledCallBack;
                __tab.Command += new CommandEventHandler(this.OnTabChanged);
                __tab.CommandName = MultiView.SwitchViewByIndexCommandName;
                __tab.Argument = Conversion.ToString(__index++);
                __tab.Text = __view.Title;                
                this.Tabs.Add(__tab);
            }
        }

        #endregion M�thodes

        #region Evenements

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            
            this.UpdateAfterCallBack |= this.MultiView.UpdateAfterCallBackTabs;

            for (int __index = 0; __index < this.Tabs.Count; __index++)
            {
                View __view = this.MultiView.Views[__index] as View;
                Tab __tab = this.Tabs[__index];
                //Enabled or not Modification
                if (Validation.IsNotNull(__view))
                {
                    __tab.Enabled = __view.Enabled;
                    __tab.CausesValidation = __view.CausesValidation;
                    __tab.ValidationGroup = __view.ValidationGroup;
                    __tab.Visible = __view.VisibleInTab;
                }

                __tab.Active = (__index == this.MultiView.ActiveViewIndex);
            }
            
            if (this.Visible)
            {
                if (this.MultiView.Views.Count > 0 && !this.MultiView.ActiveView.VisibleInTab)
                {
                    this.Tabs[this.MultiView.ActiveViewIndex].Active = false;
                    this.MultiView.SetAutoActiveViewIndex(0);
                    this.Tabs[this.MultiView.ActiveViewIndex].Active = true;
                }
            }
        }

        /// <summary>
        /// Lors d'un changement d'onglet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="cmea"></param>
        protected void OnTabChanged(object sender, CommandEventArgs cmea)
        {
            int __viewIndex = Conversion.ToInt(cmea.CommandArgument);
            View __originalView = this.MultiView.ActiveView;
            this.UpdateAfterCallBack = true;
            switch (cmea.CommandName)
            {
                case MultiView.SwitchViewByIDCommandName:
                    View __view = _host.FindControl((string)cmea.CommandArgument) as View;
                    if ((__view == null) || (__view.Parent != _host)) return;
                    _host.SetActiveView(__view);
                    RaiseBubbleEvent(this, new MultiViewTabsEventsArgs(__originalView, _host.ActiveView));
                    break;
                case MultiView.SwitchViewByIndexCommandName:
                    _host.ActiveViewIndex = __viewIndex;
                    RaiseBubbleEvent(this, new MultiViewTabsEventsArgs(__originalView, _host.ActiveView));
                    break;
            }
        }

        #endregion Evenements

        #region Propri�t�s

        public MultiView MultiView
        {
            get { return _host; }
        }

        #endregion Propri�t�s
    }


    /// <summary>
    /// Class MultiViewTabsEventsArgs : Arguments des evenements lev�s sur un changement d'onglet
    /// </summary>
    /// <author>LCU</author>
    /// <date>09/12/2010</date>    
    public class MultiViewTabsEventsArgs : EventArgs
    {
        #region Membres

        View _srcView;
        View _dstView;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de MultiViewTabsEventsArgs
        /// </summary>
        /// <param name="srcView">Vue d'origine</param>
        /// <param name="dstView">Vue destination</param>
        public MultiViewTabsEventsArgs(View srcView, View dstView)
        {
            _srcView = srcView;
            _dstView = dstView;
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Vue d'origine
        /// </summary>
        public View SrcView
        {
            get { return _srcView; }
            set { _srcView = value; }
        }

        /// <summary>
        /// Vue destination
        /// </summary>
        public View DstView
        {
            get { return _dstView; }
            set { _dstView = value; }
        }

        #endregion Propri�t�s
    }


}