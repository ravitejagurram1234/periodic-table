using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>Represents a label control, which displays text on a Web page. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
	[ValidationProperty("Text")]
    public class Label: Anthem.Label, ITextable
    {
		#region internal variables
		private const						string	NoWrapAttribute = "nowrap";						
		private									bool		_forceClientID	= false;
		private static readonly string	DefaultCss = Basic.CssClass.lbl.ToString();
		#endregion
		/// <summary>Initializes a new instance of <see cref="Label"/> control. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
		public Label(){
			base.CssClass = DefaultCss;
		}
		/// <summary>Initializes a new instance of <see cref="Label"/> control. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
		/// <param name="text">The text content of the Label control. </param>
		public Label(string text): this(){
			if(Validation.IsSet(text)) this.Text = text;
		}
		/// <summary>Initializes a new instance of <see cref="Label"/> control. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
		/// <param name="text">The text content of the Label control. </param>
		/// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
		public Label(string text, string cssClass): this(text){
			if(Validation.IsSet(cssClass)) this.CssClass = cssClass;
		}
		/// <summary>Initializes a new instance of <see cref="Label"/> control. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
		/// <param name="text">The text content of the Label control. </param>
		/// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
		public Label(string text, Enum cssClass): this(text, Conversion.ToString(cssClass))
		{
		}
		/// <summary>Adds custom html attributes during the render process. </summary>
		/// <param name="writer">The <see cref="HtmlTextWriter"/> object that receives the server control attribute content. </param>
		/// <remarks><see cref="Label"/> control use this method to force id attribute to <c>ClientID</c>. </remarks>
		protected override void AddAttributesToRender(HtmlTextWriter writer)
		{
			if(_forceClientID && Validation.IsNull(this.ID)) writer.AddAttribute(HtmlTextWriterAttribute.Id, base.ClientID);
			base.AddAttributesToRender(writer);
		}
		/// <summary>Gets or sets if control must display <c>ClientID</c> id on current <see cref="Label"/>. </summary>
		public bool							ForceClientID
		{
			get{return _forceClientID;}
			set{_forceClientID = value;}
		}
		/// <summary>Gets or sets whether the text in the control is displayed on a single line. </summary>
		public bool							NoWrap
		{
			get{return Conversion.ToBool(this.Attributes[Label.NoWrapAttribute]);}
			set{this.Attributes[Label.NoWrapAttribute] = value.ToString();}
		}
	}
}
