using System;
using System.Diagnostics;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXP.Framework.Web.UI.Controls.Helpers;
using QXPWUIHtml	= QXP.Framework.Web.UI.Controls.Html;


namespace QXP.Framework.Web.UI.Controls.Basic
{
	public class Table: Anthem.Table{}
	/// <summary>Represents a horizontal sections structure of three <see cref="ItemSection"/>. </summary>
	public class HorizontalTableSection: TableSection
	{
		/// <summary>Creates a new instance of <see cref="HorizontalTableSection"/> class. </summary>
		public HorizontalTableSection(): base(3,1){}
		/// <summary>Gets the left most item section. </summary>
		public ItemSection		Left
		{
			get{return this.Rows[0].Cells[0] as ItemSection;}
		}
		/// <summary>Gets the middle item section. </summary>
		public ItemSection		Middle
		{
			get{return this.Rows[0].Cells[1] as ItemSection;}
		}
		/// <summary>Gets the right most item section. </summary>
		public ItemSection		Right
		{
			get{return this.Rows[0].Cells[2] as ItemSection;;}
		}
	}
	/// <summary>Represents a vertical sections structure of three <see cref="ItemSection"/>. </summary>
	public class VerticalTableSection: TableSection
	{
		/// <summary>Creates a new instance of <see cref="VerticalTableSection"/> class. </summary>
		public VerticalTableSection(): base(1,3){}
		/// <summary>Gets the header section of the vertical section. </summary>
		public ItemSection		Header
		{
			get{return this.Rows[0].Cells[0] as ItemSection;}
		}
		/// <summary>Gets the body section of the vertical section. </summary>
		public ItemSection		Body
		{
			get{return this.Rows[1].Cells[0] as ItemSection;}
		}
		/// <summary>Gets the footer section of the vertical section. </summary>
		public ItemSection		Footer
		{
			get{return this.Rows[2].Cells[0] as ItemSection;;}
		}
		//INFO: this accessor hide base inherited indexer
		private new ItemSection			this[int row, int col]
		{
			get{return null;}
		}
		//INFO: this accessor hide base inherited indexer
		private new TableRowSection this[int row]
		{
			get{return null;}
		}
	}
	/// <summary>Provides methods to manage item section element. </summary>
	public class ItemSection: TableCell
	{
		/// <summary>Creates a new instance of <see cref="ItemSection"/> control. </summary>
		public ItemSection(){}
		private	System.Web.UI.Control CreateSeparator(Separator separator)
		{
			return this.CreateSeparator(separator, 1);
		}
		private	System.Web.UI.Control CreateSeparator(Separator separator, int repeat)
		{
			Debug.Assert(repeat > 0, WebConstant.InvalidRepeatValue);
			if(repeat <= 0) repeat = 1;
			switch(separator)
			{
				case Separator.Break:
					return (new QXPWUIHtml.Break(repeat));
				case Separator.Line:
					return (new QXPWUIHtml.HorizontalRule(repeat));
				case Separator.Space:
					return (new QXPWUIHtml.Space(repeat));
				default:
					return new LiteralControl();
			}
		}
		private	System.Web.UI.Control CreateSeparator(char separatorChar, int repeat)
		{
			Debug.Assert(repeat > 0, WebConstant.InvalidRepeatValue);
			if(repeat <= 0) repeat = 1;
			System.Web.UI.Control __c = new System.Web.UI.Control();
			__c.Controls.Add(new QXPWUIHtml.Break());
			__c.Controls.Add(new LiteralControl(new string(separatorChar, repeat)));
			__c.Controls.Add(new QXPWUIHtml.Break());
			return __c;
		}
		#region Add
		/// <summary>Adds the specified <paramref name="control"/> to section item. </summary>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		public	void									Add(System.Web.UI.Control control)
		{
			this.Add(control, Separator.None);
		}
		/// <summary>Adds the specified <paramref name="control"/> to section item completed with a <paramref name="separator"/>. </summary>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		public	void									Add(System.Web.UI.Control control, Separator separator)
		{
			this.Add(control, separator, RelativePosition.Post);		
		}
		/// <summary>Adds the specified <paramref name="control"/> to section item completed with a <paramref name="separator"/> at a specified  <paramref name="separatorPosition"/> position. </summary>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		public	void									Add(System.Web.UI.Control control, Separator separator, RelativePosition separatorPosition)
		{
			this.Add(control, separator, separatorPosition, 1);		
		}
		/// <summary>Adds the specified <paramref name="control"/> to section item completed with a repeated (<paramref name="repeat"/>) <paramref name="separator"/> at a specified <paramref name="separatorPosition"/> position. </summary>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		/// <param name="repeat">The <see cref="Int32"/> number that specify how many separator will be placed. </param>
		public	void									Add(System.Web.UI.Control control, Separator separator, RelativePosition separatorPosition, int repeat)
		{
			this.AddAt(int.MinValue, control, separator, separatorPosition, repeat);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item. </summary>
		/// <param name="content">The <see cref="String"/> content. </param>
		public	void									Add(string content)
		{
			this.Add(content, Separator.None);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item with a specified <paramref name="separator"/> after them. </summary>
		/// <param name="content">The <see cref="String"/> content. </param>
		/// <param name="separator">The <see cref="Separator"/> type to add after content. </param>
		public	void									Add(string content, Separator separator)
		{
			this.Add(content, separator, RelativePosition.Post);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item completed with a <paramref name="separator"/> at a specified  <paramref name="separatorPosition"/> position. </summary>
		/// <param name="content">The <see cref="String"/> content. </param>
		/// <param name="separator">The <see cref="Separator"/> type to add after content. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		public	void									Add(string content, Separator separator, RelativePosition separatorPosition)
		{
			this.Add(content, separator, separatorPosition, 1);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item completed with a repeated (<paramref name="repeat"/>) <paramref name="separator"/> at a specified <paramref name="separatorPosition"/> position. </summary>
		/// <param name="content">The <see cref="String"/> content. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		/// <param name="repeat">The <see cref="Int32"/> number that specify how many separator will be placed. </param>
		public	void									Add(string content, Separator separator, RelativePosition separatorPosition, int repeat)
		{
			this.Add(new LiteralControl(content), separator, separatorPosition, repeat);
		}
		#endregion
		#region AddAt
		/// <summary>Adds the specified <paramref name="control"/> to section item. </summary>
		/// <param name="index">the int position to add the control. </param>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		public	void									AddAt(int index, System.Web.UI.Control control)
		{
			this.AddAt(index, control, Separator.None);
		}
		/// <summary>Adds the specified <paramref name="control"/> to section item completed with a <paramref name="separator"/>. </summary>
		/// <param name="index">the int position to add the control. </param>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		public	void									AddAt(int index, System.Web.UI.Control control, Separator separator)
		{
			this.AddAt(index, control, separator, RelativePosition.Post);		
		}
		/// <summary>Adds the specified <paramref name="control"/> to section item completed with a <paramref name="separator"/> at a specified  <paramref name="separatorPosition"/> position. </summary>
		/// <param name="index">the int position to add the control. </param>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		public	void									AddAt(int index, System.Web.UI.Control control, Separator separator, RelativePosition separatorPosition)
		{
			this.AddAt(index, control, separator, separatorPosition, 1);		
		}
		/// <summary>Adds the specified <paramref name="control"/> to section item completed with a repeated (<paramref name="repeat"/>) <paramref name="separator"/> at a specified <paramref name="separatorPosition"/> position. </summary>
		/// <param name="index">the int position to add the control. </param>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		/// <param name="repeat">The <see cref="Int32"/> number that specify how many separator will be placed. </param>
		public	void									AddAt(int index, System.Web.UI.Control control, Separator separator, RelativePosition separatorPosition, int repeat)
		{
			Debug.Assert(control != null, WebConstant.InvalidControlReference);
			if(Validation.IsSet(index))
			{
				if((separatorPosition == RelativePosition.Pre) || (separatorPosition == RelativePosition.Both)) this.Controls.AddAt(index, CreateSeparator(separator, repeat));
				if(Validation.IsNotNull(control))		this.Controls.AddAt(index, control);
				if((separatorPosition == RelativePosition.Post) || (separatorPosition == RelativePosition.Both)) this.Controls.AddAt(index, CreateSeparator(separator, repeat));
			}
			else
			{
				if((separatorPosition == RelativePosition.Pre) || (separatorPosition == RelativePosition.Both)) this.Controls.Add(CreateSeparator(separator, repeat));
				if(Validation.IsNotNull(control))		this.Controls.Add(control);
				if((separatorPosition == RelativePosition.Post) || (separatorPosition == RelativePosition.Both)) this.Controls.Add(CreateSeparator(separator, repeat));
			}
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item. </summary>
		/// <param name="index">the int position to add the text. </param>
		/// <param name="content">The <see cref="String"/> content. </param>
		public	void									AddAt(int index, string content)
		{
			this.AddAt(index, content, Separator.None);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item with a specified <paramref name="separator"/> after them. </summary>
		/// <param name="index">the int position to add the text. </param>
		/// <param name="content">The <see cref="String"/> content. </param>
		/// <param name="separator">The <see cref="Separator"/> type to add after content. </param>
		public	void									AddAt(int index, string content, Separator separator)
		{
			this.AddAt(index, content, separator, RelativePosition.Post);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item completed with a <paramref name="separator"/> at a specified  <paramref name="separatorPosition"/> position. </summary>
		/// <param name="index">the int position to add the text. </param>
		/// <param name="content">The <see cref="String"/> content. </param>
		/// <param name="separator">The <see cref="Separator"/> type to add after content. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		public	void									AddAt(int index, string content, Separator separator, RelativePosition separatorPosition)
		{
			this.AddAt(index, content, separator, separatorPosition, 1);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item completed with a repeated (<paramref name="repeat"/>) <paramref name="separator"/> at a specified <paramref name="separatorPosition"/> position. </summary>
		/// <param name="index">the int position to add the text. </param>
		/// <param name="content">The <see cref="String"/> content. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		/// <param name="repeat">The <see cref="Int32"/> number that specify how many separator will be placed. </param>
		public	void									AddAt(int index, string content, Separator separator, RelativePosition separatorPosition, int repeat)
		{
			this.AddAt(index, new LiteralControl(content), separator, separatorPosition, repeat);
		}
		
		#endregion
		#region Remove/RemoveAt
		/// <summary>Removes specified <paramref name="control"/> from the current <see cref="ItemSection"/>. </summary>
		/// <param name="control">the <see cref="System.Web.UI.Control"/> to remove. </param>
		public	void									Remove(System.Web.UI.Control control)
		{
			if(Validation.IsNotNull(control))		this.Controls.Remove(control);
		}
		/// <summary>Removes control at specified <paramref name="index"/> position. </summary>
		/// <param name="index">The <see cref="Int32"/> index position of the control to removes. </param>
		public	void									RemoveAt(int index)
		{
			this.Controls.RemoveAt(index);
		}
		#endregion
	}
	/// <summary>Provides functionality to generate and manage a control with multiple rows and columns sections. </summary>
	public class TableSection: Table
	{
		/// <summary>Creates a new Instance of <see cref="TableSection"/> class. </summary>
		public TableSection(): base()
		{
			this.CellPadding = 0;
			this.CellSpacing = 0;
		}
		/// <summary>Creates a new instance of <see cref="TableSection"/> control with the specified number of <paramref name="rowCount"/> and <paramref name="colCount"/>. </summary>
		/// <param name="colCount">The <see cref="Int32"/> number of columns. </param>
		/// <param name="rowCount">the <see cref="Int32"/> number of rows. </param>
		public TableSection(int colCount, int rowCount): this()
		{
			WebControlHelpers.TableSection.SetRowAndColCount(this, rowCount, colCount);
		}
		/// <summary>Gets a specific <see cref="ItemSection"/> specified by <paramref name="row"/> and <paramref name="col"/>. </summary>
		/// <returns>The <see cref="ItemSection"/> that correspond to the <paramref name="row"/> and <paramref name="col"/>. </returns>
		/// <exception cref="ArgumentOutOfRangeException">If parameters <paramref name="row"/> or <paramref name="col"/> are out of range. </exception>
		public ItemSection		this[int row, int col]
		{
			get
			{
				try
				{
					return((ItemSection)this.Rows[row].Cells[col]);
				}
				catch
				{
					throw new ArgumentOutOfRangeException(WebConstant.InvalidRowOrColArgument);
				}
			}
		}
		/// <summary>Gets a specific <see cref="TableRowSection"/> specified by <paramref name="row"/>. </summary>
		/// <param name="row">The <see cref="Int32"/> row index to retrieve. </param>
		/// <returns>The <see cref="TableRowSection"/> corresponding to the index <paramref name="row"/>. </returns>
		/// <exception cref="ArgumentOutOfRangeException">If parameters <paramref name="row"/> is out of range. </exception>
		public TableRowSection	this[int row]
		{
			get
			{
				try
				{
					return((TableRowSection)this.Rows[row]);
				}
				catch
				{
					throw new ArgumentOutOfRangeException(WebConstant.InvalidRowArgument);
				}
			}
		}
		//INFO: this method is due to an intellisense bug of VS 2003
		public ItemSection		GetCell(int row, int col){
			return this[row, col];
		}
		//INFO: this method is due to an intellisense bug of VS 2003
		public TableRowSection	GetRow(int row)
		{
			return this[row];
		}
		#region Add
		/// <summary>Adds the specified <paramref name="control"/> to section item. </summary>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		public	void					Add(int rowIndex, int colIndex, System.Web.UI.Control control)
		{
			this[rowIndex, colIndex].Add(control, Separator.None);
		}
		/// <summary>Adds the specified <paramref name="control"/> to section item completed with a <paramref name="separator"/>. </summary>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		public	void					Add(int rowIndex, int colIndex, System.Web.UI.Control control, Separator separator)
		{
			this[rowIndex, colIndex].Add(control, separator, RelativePosition.Post);		
		}
		/// <summary>Adds the specified <paramref name="control"/> to section item completed with a <paramref name="separator"/> at a specified  <paramref name="separatorPosition"/> position. </summary>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		public	void					Add(int rowIndex, int colIndex, System.Web.UI.Control control, Separator separator, RelativePosition separatorPosition)
		{
			this[rowIndex, colIndex].Add(control, separator, separatorPosition, 1);		
		}
		/// <summary>Adds the specified <paramref name="control"/> to section item completed with a repeated (<paramref name="repeat"/>) <paramref name="separator"/> at a specified <paramref name="separatorPosition"/> position. </summary>
		/// <param name="control">The <see cref="System.Web.UI.Control"/> to add. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		/// <param name="repeat">The <see cref="Int32"/> number that specify how many separator will be placed. </param>
		public	void					Add(int rowIndex, int colIndex, System.Web.UI.Control control, Separator separator, RelativePosition separatorPosition, int repeat)
		{
			this[rowIndex, colIndex].AddAt(int.MinValue, control, separator, separatorPosition, repeat);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item. </summary>
		/// <param name="content">The <see cref="String"/> content. </param>
		public	void					Add(int rowIndex, int colIndex, string content)
		{
			this[rowIndex, colIndex].Add(content, Separator.None);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item with a specified <paramref name="separator"/> after them. </summary>
		/// <param name="content">The <see cref="String"/> content. </param>
		/// <param name="separator">The <see cref="Separator"/> type to add after content. </param>
		public	void					Add(int rowIndex, int colIndex, string content, Separator separator)
		{
			this[rowIndex, colIndex].Add(content, separator, RelativePosition.Post);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item completed with a <paramref name="separator"/> at a specified  <paramref name="separatorPosition"/> position. </summary>
		/// <param name="content">The <see cref="String"/> content. </param>
		/// <param name="separator">The <see cref="Separator"/> type to add after content. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		public	void					Add(int rowIndex, int colIndex, string content, Separator separator, RelativePosition separatorPosition)
		{
			this[rowIndex, colIndex].Add(content, separator, separatorPosition, 1);
		}
		/// <summary>Adds the specified <paramref name="content"/> in section item completed with a repeated (<paramref name="repeat"/>) <paramref name="separator"/> at a specified <paramref name="separatorPosition"/> position. </summary>
		/// <param name="content">The <see cref="String"/> content. </param>
		/// <param name="separator">The <see cref="Separator"/> placed after this <paramref name="control"/>. </param>
		/// <param name="separatorPosition">The <see cref="RelativePosition"/> position of the <paramref name="separator"/>. </param>
		/// <param name="repeat">The <see cref="Int32"/> number that specify how many separator will be placed. </param>
		public	void					Add(int rowIndex, int colIndex, string content, Separator separator, RelativePosition separatorPosition, int repeat)
		{
			this[rowIndex, colIndex].Add(new LiteralControl(content), separator, separatorPosition, repeat);
		}
		#endregion
	}
	/// <summary>Provides functionality to generate and manage a control with multiple columns sections. </summary>
	public class TableRowSection: System.Web.UI.WebControls.TableRow
	{
		/// <summary>Creates a new instance of <see cref="TableRowSection"/> control. </summary>
		public TableRowSection(): base(){}
		/// <summary>Gets a specific <see cref="ItemSection"/> from the specified <paramref name="col"/> index. </summary>
		/// <param name="col">The <see cref="Int32"/> index position of the column section to retrieve. </param>
		/// <returns>The <see cref="ItemSection"/> reference of the section at the <paramref name="col"/> index position. </returns>
		/// <exception cref="ArgumentOutOfRangeException">If <paramref name="col"/> is out of range. </exception>
		public ItemSection	this[int col]
		{
			get
			{
				try
				{
					return((ItemSection)this.Cells[col]);
				}
				catch
				{
					throw new ArgumentOutOfRangeException(WebConstant.InvalidColArgument);
				}
			}
		}
	}
}