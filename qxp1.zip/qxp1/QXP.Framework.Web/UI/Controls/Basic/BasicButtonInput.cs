using System;

namespace QXP.Framework.Web.UI.Controls.Basic{
	/// <summary>Displays an image on a Web page. <seealso cref="System.Web.UI.WebControls.Button"/></summary>
	public class ButtonInput : Anthem.Button{
		#region internal variables
        bool            _unique_Hidden  = true;
		private static readonly string DefaultCss = Basic.CssClass.btn.ToString();
        const string VSDisableInput     = "DisableInput";
        const string VSPromptText       = "PromptText";
        const string VSDefaultPrompt    = "DefaultPrompt";
		#endregion
		/// <summary>Initializes a new instance of <see cref="ButtonInput"/> control. </summary>
		public ButtonInput() {
			base.CssClass = DefaultCss;
		}
		/// <summary>Initializes a new instance of <see cref="ButtonInput"/> control. </summary>
		/// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
		public ButtonInput(string cssClass): this(){
			if(Validation.IsSet(cssClass)) this.CssClass = cssClass;
		}
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            string __input_Hidden_Name = this.Hidden_Name;
            this.Page.ClientScript.RegisterHiddenField(__input_Hidden_Name, this.InputText);
        }
		public void MonitorEnterKey(System.Web.UI.Control control){
			MonitorEnterKeyTools.MonitorEnterKey(this.Page, control, this);
		}
		public void MonitorEnterKey(System.Web.UI.Control[] controls)
		{
			MonitorEnterKeyTools.MonitorEnterKey(this.Page, controls, this);
		}
        public bool     EnableInput{
            get{return !Conversion.ToBool(this.ViewState[VSDisableInput]);}
            set{this.ViewState[VSDisableInput] = value;}
        }
        public string   PromptText{
            get{return Conversion.ToString(this.ViewState[VSPromptText]);}
            set{this.ViewState[VSPromptText] = value;}
        }
        public string   DefaultPrompt{
            get{return Conversion.ToString(this.ViewState[VSDefaultPrompt]);}
            set{this.ViewState[VSDefaultPrompt] = value;}
        }
        private string  Hidden_Name{
            get{return string.Format("input_{0}_Hidden", _unique_Hidden?"btn":this.ClientID);}
        }
        private string  Input_Var_Text{
            get{return string.Format("input_{0}", this.ClientID);}
        }
        private bool    UniqueHidden{
            get{return _unique_Hidden;}
            set{_unique_Hidden = value;}
        }
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            if(this.EnableInput){
               this.OnClientClick = string.Format("var {0} = prompt('{1}', '{2}'); if (!{0}) return false; document.getElementById('{3}').value = {0};", this.Input_Var_Text, this.PromptText, this.DefaultPrompt, this.Hidden_Name);
            }
        }
        public      string      InputText{
            get{return this.Page.Request.Form[this.Hidden_Name];}
        }
        protected override void OnClick(EventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnClick(e);
        }
        protected override void OnCommand(System.Web.UI.WebControls.CommandEventArgs e) {
            if(this.CausesValidation && !this.Page.IsValid) return;
            base.OnCommand(e);
        }
	}
}