using System;
using System.Collections;
using System.Reflection;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXPData = QXP.Framework.Data;
using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>Represents a control that allows the user to select a single item from a drop-down list.	</summary>
    public class ListBox : Anthem.ListBox, IPostBackEventHandler
    {
        #region internal variables
        private static readonly string DefaultCss = Basic.CssClass.lstbx.ToString();
        private const string SplitValuesString = "|";
        private string _selectedValue = null;
        private object _defaultValue = null;
        private int _maxItemsCount = 20000;
        private int _maxTextLength = 40;
        //private	int						_defaultRows			= 8;
        private bool _isSorted = false;
        private ArrayList _listitems;
        private DataSourceType _dataSourceType;

        private const string VSAlreadyChecked = "AlreadyChecked";
        private const string VSDefaultChecked = "DefaultChecked";
        private Char[] CheckedSeparators = new char[] { ']', '[' };
        private string _checkedString = "(+)";
        private string _uncheckedString = "(-)";
        private bool _checkable;

        private const string VSDisableAutoComplete = "VSDisableAutoComplete";
        private const string VSAutoComplete_OnChange = "VSAutoComplete_OnChange";

        private const string ArgDoubleClick = "dblclick";

        Html.Hidden _checks;
        public event EventHandler ChecksChanged;
        public event EventHandler Doubleclick;
        #endregion
        /// <summary>Creates a new instance of <see cref="DropDownList"/> control. </summary>
        public ListBox()
        {
            base.CssClass = DefaultCss;
            //Afin d'�liminer la double g�n�rations d'�v�nements cette propri�t� doit �tre d�finit � false comme sur les autres controles anthem qui poss�de la propri�t� autocallback
            this.EnabledDuringCallBack = false;
        }
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            //			this.Attributes["onkeypress"]	= "typeAhead(this)";
            //			this.Attributes["onblur"]		= "typeAhead_onblur(this)";
            this.Page.RegisterClientScriptBlock(BasicConst.ListBoxScriptKeyName, string.Format("<script language=\"javascript\" src=\"{0}\"></script>", AbsoluteFilesPath.ListBoxScript));
            if (_checkable)
            {
                _checks = new Html.Hidden();
                _checks.ServerChange += new EventHandler(this.OnChecksChanged);
                this.Parent.Controls.Add(_checks);
                //_checks.ID						= "_checks";
                _checks.ID = _checks.ID;
            }
        }
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            if (!this.DisableAutoComplete)
            {
                this.Attributes["onkeypress"] = "return LookupElement_onkeypress(this,false,event);";
                this.Attributes["onkeyup"] = "LookupElement_onkeyup(this, event);";
                string __mychange = "LookupElement_onchange(this);";
                string __userchange = AutoComplete_OnChange;
                if (Validation.IsSet(__userchange))
                {
                    __mychange = __userchange + __mychange;
                }

                this.Attributes["onfocus"] = "LookupElement_onfocus(this);";


                if (Validation.IsNotNull(this.Attributes["onchange"]))
                    this.Attributes["onchange"] = string.Concat(__mychange, this.Attributes["onchange"]);
                else
                    this.Attributes["onchange"] = __mychange;


                if (this.AutoPostBack)
                {
                    this.Attributes["onblur"] = string.Concat("if(LookupElement_onblur(this) == true){", this.AutoComplete_OnChange, this.Page.GetPostBackClientEvent(this, ""), "};");
                }
                else
                {
                    this.Attributes["onblur"] = "LookupElement_onblur(this);";
                }
            }
            if (Validation.IsNotNull(this.Doubleclick))
            {
                //this.Attributes["ondblclick"] = string.Format("if(this.selectedIndex != -1) {0}", RenderUtility.GetCallFireEventReferenceSansJS(this.ClientID, ArgDoubleClick));// this.Page.GetPostBackEventReference(this, ArgDoubleClick));			//}
                this.Attributes["ondblclick"] = string.Format("if(this.selectedIndex != -1) {0}", Anthem.Manager.GetCallbackEventReference(this, ArgDoubleClick, this.CausesValidation, this.ValidationGroup));// this.Page.GetPostBackEventReference(this, ArgDoubleClick));			//}
            }
            //			this.Attributes["onkeypress"]				= "return LookupElement_onkeypress(this,false,event);";
            //			this.Attributes["onkeyup"]					= "LookupElement_onkeyup(this, event);";
            //			this.Attributes["onmousedown"]				= "LookupElement_onmousedown(this);";
            //			if(this.AutoPostBack)
            //			{
            //				this.Attributes["onchange"]				= "LookupElement_onchange(this);";
            //				this.Attributes["onblur"]				= string.Concat("if(this.size <= 1 && this.lastindex != null && !this.disablepost){this.selectedIndex	= this.lastindex;", this.Page.GetPostBackClientEvent(this, ""), ";}else{this.disablepost = false;this.lastindex = null;};");
            //			}
            //			else
            //			{
            //				this.Attributes["onblur"]				= "LookupElement_onblur(this);";
            //			}
            //			this.Attributes["onpropertychange"]			= "LookupElement_onpropertychange(this);";
            if (_checkable)
            {
                this.Attributes["onmouseup"] = string.Format("LookupElement_onmouseup(this, '{0}', '{1}', '{2}');", _checks.ClientID, _checkedString, _uncheckedString);
            }
        }
        /// <summary>Binds a data source to the invoked dropdown-list. </summary>
        public override void DataBind()
        {
            object __dataSource;
            if (Validation.IsSet(this.DataMember))
            {
                __dataSource = QXPData.DataSourceResolver.GetResolvedDataSource(this.DataSource, this.DataMember);
            }
            else
            {
                __dataSource = DataSource;
            }
            IEnumerable __iEnumerable = __dataSource as IEnumerable;
            this.Items.Clear();
            this.ClearSelection();
            if (Validation.IsNull(__iEnumerable)) return; //INFO: Nothing Interesting to bind. 
            string __dataTextField = this.DataTextField;
            string __dataValueField = this.DataValueField;
            string __dataTextFormatString = this.DataTextFormatString;
            string __itemValue, __itemText, __key;
            object __value;
            bool __alreadySelected = false;
            PropertyInfo __indexer = null;
            int __arrayRank = 1;
            string __selectedValue = string.Empty;
            ArrayList __checkValues = new ArrayList();
            ArrayList __selectedCheckedValues = new ArrayList();
            bool __checked = false;
            if (Validation.IsSet(_selectedValue))
            {
                __selectedValue = _selectedValue;
            }
            else
            {
                if (Validation.IsNotNull(this.DefaultValue))
                {
                    __selectedValue = Conversion.ToString(this.DefaultValue);
                }
            }
            if (_checkable)
            {
                if (Validation.IsSet(this.AlreadyChecked))
                {
                    __checkValues.AddRange(this.AlreadyChecked);
                }
                else
                {
                    if (Validation.IsNotNull(this.DefaultChecked))
                    {
                        __checkValues.AddRange(this.DefaultChecked);
                    }
                }
            }
            _listitems = new ArrayList();
            ICollection __iCollection = __iEnumerable as ICollection;
            if (Validation.IsNotNull(__iCollection)) Items.Capacity = __iCollection.Count;

            IEnumerator __iEnumerator = __iEnumerable.GetEnumerator();
            try
            {
                //INFO: First Test
                if (__dataSource is System.Collections.Specialized.NameObjectCollectionBase)
                {
                    _dataSourceType = DataSourceType.NameValueCollection;
                    __indexer = __dataSource.GetType().GetProperty("Item", ValueType.ArrayOf1String);
                }
                else if (__dataSource is System.Collections.IDictionary)
                {
                    _dataSourceType = DataSourceType.Dictionary;
                }
                else if (__dataSource is System.Array)
                {
                    _dataSourceType = DataSourceType.Array;
                    __arrayRank = ((Array)__dataSource).Rank;
                }
                else
                {
                    //INFO: Second chance
                    if (__iEnumerator is IDictionaryEnumerator) _dataSourceType = DataSourceType.Dictionary;
                }
                while (__iEnumerator.MoveNext())
                {
                    object __entry = __iEnumerator.Current;
                    switch (_dataSourceType)
                    {
                        case DataSourceType.NameValueCollection:
                            __key = Conversion.ToString(__entry);
                            __value = QXPData.DataBinder.GetIndexedValue(__indexer, __dataSource, __key);
                            break;
                        case DataSourceType.Dictionary:
                            DictionaryEntry __dictionaryEntry = (DictionaryEntry)__entry;
                            __key = Conversion.ToString(__dictionaryEntry.Key);
                            __value = __dictionaryEntry.Value;
                            break;
                        case DataSourceType.Array:
                            __key = Conversion.ToString(__entry);
                            for (int __i = 1; __i < __arrayRank; __i++) __iEnumerator.MoveNext();
                            __value = __iEnumerator.Current;
                            break;
                        default:
                            __key = Conversion.ToString(__entry);
                            __value = __entry;
                            break;
                    }
                    //DataTextField
                    if (Validation.IsSet(__dataTextField))
                    {
                        __itemText = Conversion.ToString(QXPData.DataBinder.Eval(__value, __dataTextField, __dataTextFormatString));
                    }
                    else
                    {
                        if (Validation.IsSet(__dataTextFormatString)) __itemText = string.Format(__dataTextFormatString, __value);
                        else __itemText = Conversion.ToString(__value);
                    }
                    //DataValueField
                    if (Validation.IsSet(__dataValueField)) __itemValue = Conversion.ToString(QXPData.DataBinder.Eval(__value, __dataValueField, null));
                    else __itemValue = __key;

                    __alreadySelected = __alreadySelected || (__itemValue == __selectedValue);

                    if (this._checkable)
                    {
                        __checked = __checkValues.Contains(__itemValue);
                        if (__checked) __selectedCheckedValues.Add(__itemValue);
                    }

                    this.AddItem(__itemValue, __itemText, __itemValue == __selectedValue, __checked);
                }
                //INFO: Sort List
                if (this.IsSorted)
                {
                    ArrayHelper.Sort(_listitems, new Comparers.ListItemComparer());
                    //_listitems.Sort(ListItemComparer.Default);
                    foreach (ListItem __item in _listitems)
                    {
                        __item.Text = StringHelper.StartString(__item.Text, _maxTextLength);
                    }
                }
                ListItem[] __items = (ListItem[])_listitems.ToArray(typeof(ListItem));
                _listitems.Clear();

                //INFO: Limit Items count to maxItemsCount.
                if (__items.Length > _maxItemsCount)
                {
                    ListItem[] __dimmedItems = new ListItem[_maxItemsCount];
                    Array.Copy(__items, __dimmedItems, _maxItemsCount);
                    __items = __dimmedItems;
                }
                this.Items.AddRange(__items);
                if (this.Checkable) this.UpdateHiddenChecked(__selectedCheckedValues);
            }
            catch (Exception)
            {
                //TODO: log error !!
            }
            finally
            {
                IDisposable __iDisposable = __iEnumerator as IDisposable;
                if (Validation.IsNotNull(__iDisposable)) __iDisposable.Dispose();
            }
        }
        private void AddItem(string @value, string text, bool selected)
        {
            this.AddItem(_listitems.Count, value, text, selected, false);
        }
        private void AddItem(string @value, string text, bool selected, bool @checked)
        {
            this.AddItem(_listitems.Count, value, text, selected, @checked);
        }
        private void AddItem(int index, string @value, string text, bool selected)
        {
            this.AddItem(index, @value, text, selected, false);
        }
        private void AddItem(int index, string @value, string text, bool selected, bool @checked)
        {
            ListItem __listItem = new ListItem();
            __listItem.Value = value;
            if (_checkable)
            {
                if (@checked) __listItem.Text = string.Concat(_checkedString, text);
                else __listItem.Text = string.Concat(_uncheckedString, text);
            }
            else
            {
                __listItem.Text = text;
            }
            __listItem.Selected = selected;
            _listitems.Insert(index, __listItem);
        }
        /// <summary>Gets or sets the maximum number of items displayed in the list. </summary>
        public int MaxItemsCount
        {
            get { return _maxItemsCount; }
            set { _maxItemsCount = value; }
        }
        /// <summary>Gets or sets the maximum number of item text length. </summary>
        public int MaxTextLength
        {
            get { return (_maxTextLength); }
            set { _maxTextLength = value; }
        }
        /// <summary>
        /// Disable AutoComplete functionnality
        /// </summary>
        public bool DisableAutoComplete
        {
            get { return Conversion.ToBool(this.ViewState[VSDisableAutoComplete]); }
            set { this.ViewState[VSDisableAutoComplete] = value; }
        }
        /// <summary>
        /// Definir code javascript de l'evenement onchange sur un controle avec autocomplete activ�
        /// </summary>
        public string AutoComplete_OnChange
        {
            get { return Conversion.ToString(this.ViewState[VSAutoComplete_OnChange]); }
            set { this.ViewState[VSAutoComplete_OnChange] = value; }
        }
        /// <summary>Gets or sets whether the items in the list are sorted. </summary>
        public bool IsSorted
        {
            get { return (_isSorted); }
            set { _isSorted = value; }
        }
        /// <summary>Gets or sets the value of default selected item. </summary>
        public object DefaultValue
        {
            get { return _defaultValue; }
            set { _defaultValue = value; }
        }
        public string[] SelectedText
        {
            get
            {
                ArrayList __selectedTexts = new ArrayList();
                foreach (ListItem __item in this.Items)
                {
                    if (__item.Selected)
                    {
                        __selectedTexts.Add(__item.Text);
                    }
                }
                return (string[])__selectedTexts.ToArray(ValueType.CLSstring);
            }
        }
        public string[] SelectedValues
        {
            get
            {
                ArrayList __selectedValues = new ArrayList();
                foreach (ListItem __item in this.Items)
                {
                    if (__item.Selected)
                    {
                        __selectedValues.Add(__item.Value);
                    }
                }
                return (string[])__selectedValues.ToArray(ValueType.CLSstring);
            }
            set
            {
                this.ClearSelection();
                if (Validation.IsNotSet(value)) return;
                foreach (string __value in value)
                {
                    ListItem __item = this.Items.FindByValue(__value);
                    if (Validation.IsNotNull(__item))
                    {
                        __item.Selected = true;
                    }
                }
            }
        }

        public override string SelectedValue
        {
            get
            {
                if (this.SelectionMode == System.Web.UI.WebControls.ListSelectionMode.Multiple)
                {
                    string[] __selectedValues = this.SelectedValues;
                    if (QXPFrk.Validation.IsSet(__selectedValues))
                    {
                        return string.Join(SplitValuesString, __selectedValues);// this.SelectedItem.Value;
                    }
                    return string.Empty;
                }
                else
                {
                    return base.SelectedValue;
                }
            }
            set
            {
                this.ClearSelection();
                if (Validation.IsSet(value))
                {
                    if (this.SelectionMode == System.Web.UI.WebControls.ListSelectionMode.Multiple)
                    {
                        string[] __values = value.Split(SplitValuesString.ToCharArray());
                        foreach (string __value in __values)
                        {
                            ListItem __item = this.Items.FindByValue(__value);
                            if (Validation.IsNotNull(__item))
                            {
                                __item.Selected = true;
                            }
                        }
                    }
                    else
                    {
                        ListItem __item = this.Items.FindByValue(value);
                        if (Validation.IsNotNull(__item))
                        {
                            __item.Selected = true;
                        }
                    }
                }
            }
        }
        public bool EnableMultiSelection
        {
            get { return (this.SelectionMode == System.Web.UI.WebControls.ListSelectionMode.Multiple); }
            set
            {
                if (value) this.SelectionMode = System.Web.UI.WebControls.ListSelectionMode.Multiple;
                else this.SelectionMode = System.Web.UI.WebControls.ListSelectionMode.Single;
            }
        }
        protected override void RenderContents(HtmlTextWriter writer)
        {
            bool __flag1 = false;
            bool __flag2 = this.SelectionMode == ListSelectionMode.Single;
            ListItemCollection collection1 = this.Items;
            int __num1 = collection1.Count;
            if (__num1 > 0)
            {
                for (int __num2 = 0; __num2 < __num1; __num2++)
                {
                    ListItem __item1 = collection1[__num2];
                    writer.WriteBeginTag("option");
                    if (__item1.Selected)
                    {
                        if (__flag2)
                        {
                            if (__flag1)
                            {
                                throw new Exception("Cant_Multiselect_In_Single_Mode");
                            }
                            __flag1 = true;
                        }
                        writer.WriteAttribute("selected", "selected");
                    }
                    writer.WriteAttribute("value", __item1.Value, true);
                    foreach (string __attKey in __item1.Attributes.Keys)
                    {
                        writer.WriteAttribute(__attKey, __item1.Attributes[__attKey]);
                    }
                    writer.Write('>');
                    System.Web.HttpUtility.HtmlEncode(__item1.Text, writer);
                    writer.WriteEndTag("option");
                    writer.WriteLine();
                }
            }
        }
        public void ClearChecked()
        {
            if (!_checkable) return;
            _checks.Value = null;
            UpdateChecks();
            AlreadyChecked = new string[0];

        }
        public bool Checkable
        {
            get { return _checkable; }
            set { _checkable = value; }
        }
        internal string[] AlreadyChecked
        {
            get
            {
                string __vs = Conversion.ToString(this.ViewState[VSAlreadyChecked]);
                if (Validation.IsNotSet(__vs)) return new string[0];
                return __vs.Split('|');
            }
            set
            {
                this.ViewState[VSAlreadyChecked] = string.Join("|", value);
            }
        }
        internal string[] DefaultChecked
        {
            get
            {
                string __vs = Conversion.ToString(this.ViewState[VSDefaultChecked]);
                if (Validation.IsNotSet(__vs)) return new string[0];
                return __vs.Split('|');
            }
            set
            {
                if (Validation.IsSet(value)) this.ViewState[VSDefaultChecked] = string.Join("|", value);
                else this.ViewState[VSDefaultChecked] = string.Empty;
            }
        }
        internal void UpdateChecks()
        {
            ArrayList __checked = new ArrayList(this.CheckedValues);
            ArrayList __alreadyChecked = new ArrayList(this.AlreadyChecked);
            foreach (ListItem __item in this.Items)
            {
                if (__checked.Contains(__item.Value))
                {
                    if (!__alreadyChecked.Contains(__item.Value))
                    {
                        __item.Text = _checkedString + __item.Text.Substring(_uncheckedString.Length);
                    }
                }
                else
                {
                    if (__alreadyChecked.Contains(__item.Value))
                    {
                        __item.Text = _uncheckedString + __item.Text.Substring(_checkedString.Length);
                    }
                }
            }
            this.AlreadyChecked = (string[])__checked.ToArray(ValueType.CLSstring);
        }
        public string[] CheckedValues
        {
            get
            {
                if (!_checkable) return new string[0];
                if (Validation.IsSet(_checks.Value))
                {
                    ArrayList __checked = new ArrayList();
                    foreach (string __value in _checks.Value.Split(CheckedSeparators))
                    {
                        if (Validation.IsSet(__value))
                        {
                            __checked.Add(__value);
                        }
                    }
                    return (string[])__checked.ToArray(ValueType.CLSstring);
                }
                else
                {
                    return new string[0];
                }
            }
            set
            {
                this.UpdateHiddenChecked(value);
                this.UpdateChecks();
            }
        } // CheckedValues
        internal void UpdateHiddenChecked(ArrayList checkedValues)
        {
            string[] __checkedValues = null;
            if (Validation.IsNotNull(checkedValues)) __checkedValues = (string[])checkedValues.ToArray(ValueType.CLSstring);
            this.UpdateHiddenChecked(__checkedValues);
        }
        internal void UpdateHiddenChecked(string[] values)
        {
            string __newValue = string.Empty;
            if (Validation.IsSet(values))
            {
                ArrayList __checkedKeys = new ArrayList();
                foreach (string __value in values)
                {
                    __checkedKeys.Add(StringHelper.HookString(__value));
                }
                __newValue = string.Join("", (string[])__checkedKeys.ToArray(ValueType.CLSstring));
            }
            _checks.Value = __newValue;
        }
        public string GetSwapCheckedScript()
        {
            string __script = string.Empty;
            if (_checkable) __script = string.Format("SwapSelected(document.getElementById('{0}'), '{1}', '{2}', '{3}');return false;", this.ClientID, _checks.ClientID, _checkedString, _uncheckedString);
            return __script;
        }
        public string HiddenClientID
        {
            get
            {
                if (Validation.IsNotNull(_checks))
                {
                    return _checks.ClientID;
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        public string CheckedString
        {
            get { return _checkedString; }
            set { _checkedString = value; }
        }
        public string UnCheckedString
        {
            get { return _uncheckedString; }
            set { _uncheckedString = value; }
        }
        public void SortListItems()
        {
            ListItem[] __listItems = new ListItem[this.Items.Count];
            this.Items.CopyTo(__listItems, 0);
            Array.Sort(__listItems, ListItemComparer.Default);
            this.Items.Clear();
            this.Items.AddRange(__listItems);
        }
        void IPostBackEventHandler.RaisePostBackEvent(string eventArgument)
        {
            if (eventArgument == ArgDoubleClick) this.OnDblClick(new EventArgs());
        }
        protected virtual void OnChecksChanged(object sender, EventArgs ea)
        {
            this.UpdateChecks();
            if (this.CausesValidation && !this.Page.IsValid) return;
            if (Validation.IsNotNull(this.ChecksChanged))
            {
                this.ChecksChanged(sender, ea);
            }
        }
        protected override void OnSelectedIndexChanged(EventArgs e)
        {
            if (this.CausesValidation && !this.Page.IsValid) return;
            base.OnSelectedIndexChanged(e);
        }
        private void OnDblClick(EventArgs ea)
        {
            if (this.CausesValidation && !this.Page.IsValid) return;
            if (Validation.IsNotNull(this.Doubleclick))
            {
                this.Doubleclick(this, ea);
            }
        }
    }
}
