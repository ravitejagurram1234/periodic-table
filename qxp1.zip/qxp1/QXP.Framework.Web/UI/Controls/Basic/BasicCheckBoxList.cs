using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Web.UI.WebControls;

using QXPFrk                = QXP.Framework;
using QXPData               = QXP.Framework.Data;
using QXPDiagnostic         = QXP.Framework.Diagnostic;
using System.Web.UI;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>
    /// Objet BasicCheckBoxList
    /// </summary>
    /// <author>lippensl</author>
    /// <date>08/07/2010 17:40:36</date>    
    [ValidationProperty("SelectedItem")]
    public class CheckBoxList : Anthem.CheckBoxList
    {
        #region Membres

        private string[] _selectedValues = null;
        private string[] _defaultValues = null;
        private ArrayList _listeItems;
        private int _maxItemsCount = 20000;
        private int _maxTextLength = 40;
        private bool _isSorted = false;
        private DataSourceType _dataSourceType;

        #endregion Membres

        #region Constantes

        private static readonly string DefaultCss = Basic.CssClass.chklst.ToString();

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de CheckBoxList
        /// </summary>
        public CheckBoxList()
        {
            base.CssClass = DefaultCss;
            // Afin d'�liminer la double g�n�ration d'�v�nements cette propri�t� doit �tre d�finit � false 
            // comme sur les autres controles anthem qui poss�de la propri�t� autocallback
            this.EnabledDuringCallBack = false;
        }

        #endregion Constructeur

        #region M�thodes

        public override void DataBind()
        {
            // R�cup�ration des donn�es
            object __dataSource;
            if (Validation.IsSet(this.DataMember))
                __dataSource = QXPData.DataSourceResolver.GetResolvedDataSource(this.DataSource, this.DataMember);
            else
                __dataSource = DataSource;

            IEnumerable __iEnumerable = __dataSource as IEnumerable;

            // Suppression des donn�es et des donn�es s�lectionn�es du contr�le
            this.Items.Clear();
            this.ClearSelection();

            // Aucune donn�e � bind
            if (Validation.IsNull(__iEnumerable)) 
                return;

            string __itemValue, __itemText, __key;
            object __value;
            PropertyInfo __indexer = null;
            int __arrayRank = 1;
            string __selectedValue = string.Empty;
            bool __checked = false;

            // Valeur � s�lectionner
            BaseList<string> __selectedValues = new BaseList<string>();

            if (Validation.IsSet(this.DefaultValues))
                __selectedValues.AddRange(this.DefaultValues);

            _listeItems = new ArrayList();

            // Traitement des donn�es
            IEnumerator __iEnumerator = __iEnumerable.GetEnumerator();
            try
            {
                // Identification du type de la source de donn�es
                if (__dataSource is System.Collections.Specialized.NameObjectCollectionBase)
                {
                    _dataSourceType = DataSourceType.NameValueCollection;
                    __indexer       = __dataSource.GetType().GetProperty("Item", ValueType.ArrayOf1String);
                }
                else if (__dataSource is System.Collections.IDictionary)
                {
                    _dataSourceType = DataSourceType.Dictionary;
                }
                else if (__dataSource is System.Array)
                {
                    _dataSourceType = DataSourceType.Array;
                    __arrayRank     = ((Array)__dataSource).Rank;
                }
                else
                {
                    if (__iEnumerator is IDictionaryEnumerator) 
                        _dataSourceType = DataSourceType.Dictionary;
                }

                while (__iEnumerator.MoveNext())
                {
                    object __entry = __iEnumerator.Current;

                    switch (_dataSourceType)
                    {
                        case DataSourceType.NameValueCollection:
                            __key   = Conversion.ToString(__entry);
                            __value = QXPData.DataBinder.GetIndexedValue(__indexer, __dataSource, __key);
                            break;
                        case DataSourceType.Dictionary:
                            DictionaryEntry __dictionaryEntry = (DictionaryEntry)__entry;
                            __key   = Conversion.ToString(__dictionaryEntry.Key);
                            __value = __dictionaryEntry.Value;
                            break;
                        case DataSourceType.Array:
                            __key   = Conversion.ToString(__entry);
                            for (int __i = 1; __i < __arrayRank; __i++) 
                                __iEnumerator.MoveNext();
                            __value = __iEnumerator.Current;
                            break;
                        default:
                            __key   = Conversion.ToString(__entry);
                            __value = __entry;
                            break;
                    }

                    // DataTextField
                    if (Validation.IsSet(this.DataTextField))
                        __itemText = Conversion.ToString(QXPData.DataBinder.Eval(__value, this.DataTextField, this.DataTextFormatString));
                    else if (Validation.IsSet(this.DataTextFormatString)) 
                        __itemText = string.Format(this.DataTextFormatString, __value);
                    else
                        __itemText = Conversion.ToString(__value);

                    // DataValueField
                    if (Validation.IsSet(this.DataValueField)) 
                        __itemValue = Conversion.ToString(QXPData.DataBinder.Eval(__value, this.DataValueField, null));
                    else 
                        __itemValue = __key;

                    // L'item est s�lectionn� ?
                    __checked = __selectedValues.Contains(__itemValue);

                    // Ajout de l'item � la liste
                    this.AddItem(__itemValue, __itemText, __checked);
                }

                // Tri de la liste
                if (this.IsSorted)
                {
                    ArrayHelper.Sort(_listeItems, new Comparers.ListItemComparer());
                    foreach (ListItem __item in _listeItems)
                        __item.Text = StringHelper.StartString(__item.Text, _maxTextLength);
                }

                ListItem[] __items = (ListItem[])_listeItems.ToArray(typeof(ListItem));
                _listeItems.Clear();

                // Limitation au nombre max d'�l�ments autoris�s dans la liste
                if (__items.Length > _maxItemsCount)
                {
                    ListItem[] __dimmedItems = new ListItem[_maxItemsCount];
                    Array.Copy(__items, __dimmedItems, _maxItemsCount);
                    __items = __dimmedItems;
                }

                // Ajout des items au contr�le
                this.Items.AddRange(__items);
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur DataBind du controle CheckBoxList", ex);
            }
            finally
            {
                IDisposable __iDisposable = __iEnumerator as IDisposable;
                if (Validation.IsNotNull(__iDisposable)) 
                    __iDisposable.Dispose();
            }
        }

        /// <summary>
        /// Ajoute un �l�ment � la liste
        /// </summary>
        /// <param name="value">Valeur de l'�l�ment</param>
        /// <param name="text">Texte de l'�l�ment</param>
        /// <param name="selected">Indique si l'�l�ment est s�lectionn�</param>
        private void AddItem(string @value, string text, bool selected)
        {
            this.AddItem(_listeItems.Count, value, text, selected);
        }

        /// <summary>
        /// Ajoute un �l�ment � la liste � la position donn�e
        /// </summary>
        /// <param name="index">Position � laquelle l'�l�ment doit �tre ajout�</param>
        /// <param name="value">Valeur de l'�l�ment</param>
        /// <param name="text">Texte de l'�l�ment</param>
        /// <param name="selected">Indique si l'�l�ment est s�lectionn�</param>
        private void AddItem(int index, string @value, string text, bool selected)
        {
            ListItem __listItem = new ListItem();

            __listItem.Value    = value;
            __listItem.Text     = text;
            __listItem.Selected = selected;            
            _listeItems.Insert(index, __listItem);
        }

        #endregion M�thodes

        #region Ev�nements

        protected override void OnSelectedIndexChanged(EventArgs e)
        {
            if (this.CausesValidation && !this.Page.IsValid)
                return;

            base.OnSelectedIndexChanged(e);
        }

        #endregion Ev�nements

        #region Propri�t�s

        /// <summary>
        /// Liste des valeurs s�lectionn�es par d�faut
        /// </summary>
        public string[] DefaultValues
        {
            get { return _defaultValues; }
            set { _defaultValues = value; }
        }

        /// <summary>
        /// Liste des valeurs des �l�ments s�lectionn�s
        /// </summary>
        public string[] SelectedValues
        {
            get
            {
                if (Items.Count > 0)
                {
                    BaseList<string> __selectedItems = new BaseList<string>();

                    foreach (ListItem item in Items)
                    {
                        if (item.Selected)
                            __selectedItems.Add(item.Value);
                    }

                    return __selectedItems.ToArray();
                }
                return new string[0];
            }
            set
            {
                this.ClearSelection();

                if (Validation.IsNotSet(value)) 
                    return;

                foreach (string __value in value)
                {
                    ListItem __item = this.Items.FindByValue(__value);

                    if (Validation.IsNotNull(__item))
                        __item.Selected = true;
                }
            }
        }

        /// <summary>
        /// Liste des libell�s des �l�ments s�lectionn�s
        /// </summary>
        public string[] SelectedText
        {
            get
            {
                if (Items.Count > 0)
                {
                    BaseList<string> __selectedItems = new BaseList<string>();

                    foreach (ListItem item in Items)
                    {
                        if (item.Selected)
                            __selectedItems.Add(item.Text);
                    }

                    return __selectedItems.ToArray();
                }
                return new string[0];
            }
        }

        /// <summary>
        /// D�termine si un tri doit �tre appliqu� sur les �l�ments de la liste.
        /// </summary>
        public bool IsSorted
        {
            get { return (_isSorted); }
            set { _isSorted = value; }
        }

        /// <summary>
        /// D�termine le nombre maximum d'�l�ments affich�s dans la liste.
        /// </summary>
        public int MaxItemsCount
        {
            get { return _maxItemsCount; }
            set { _maxItemsCount = value; }
        }
        
        /// <summary>
        /// D�termine le nombre maximum de caract�res affich�s par �l�ment de la liste.
        /// </summary>
        public int MaxTextLength
        {
            get { return _maxTextLength; }
            set { _maxTextLength = value; }
        }

        #endregion Propri�t�s
    }
}
