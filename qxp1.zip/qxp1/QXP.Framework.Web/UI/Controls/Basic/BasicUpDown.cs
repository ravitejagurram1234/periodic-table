using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	public delegate void UpDownEventHandler(UpDown updown_control, UpDown_Command command);

    public enum UpDown_Command{
        Haut,
        Monter,
        Baisser,
        Bas,
	}

    /// <summary>Provides functionality to display top/up/down/bottom command buttons. </summary>
	public		class UpDown : TableSection
	{
		#region internal variables
		private static readonly string	DefaultCss				= Basic.CssClass.updown.ToString();
		LinkButton			_btn_move_top;
		LinkButton			_btn_move_up;
		LinkButton			_btn_move_down;
		LinkButton			_btn_move_bottom;

        enum Css
		{
			sel_move_top,
			sel_move_up,
			sel_move_down,
			sel_move_bottom,
		}

        public event UpDownEventHandler UpDownCommand;

		#endregion
	
		/// <summary>Creates a new instance of <see cref="UpDown"/> control. </summary>
		public UpDown(): base(1,4)
		{
			base.CssClass = DefaultCss;
		}
		/// <summary>Occurs when the control need to initialize. </summary>
		/// <param name="ea"></param>
		protected override	void		OnInit(EventArgs ea)
		{
			base.OnInit(ea);
			
            _btn_move_top				=   new LinkButton(null, Css.sel_move_top, UpDown_Command.Haut);
			_btn_move_top.Command		+=  new CommandEventHandler(this.OnCommand);
			
			_btn_move_up				=   new LinkButton(null, Css.sel_move_up, UpDown_Command.Monter);
			_btn_move_up.Command		+=  new CommandEventHandler(this.OnCommand);
			
			_btn_move_down				=   new LinkButton(null, Css.sel_move_down, UpDown_Command.Baisser);
			_btn_move_down.Command		+=  new CommandEventHandler(this.OnCommand);

			_btn_move_bottom			=   new LinkButton(null, Css.sel_move_bottom, UpDown_Command.Bas);
			_btn_move_bottom.Command	+=  new CommandEventHandler(this.OnCommand);

            this[0,0].Add(_btn_move_top);
            this[1,0].Add(_btn_move_up);
            this[2,0].Add(_btn_move_down);
            this[3,0].Add(_btn_move_bottom);
		}
        private void OnCommand(object sender, CommandEventArgs cmea)
        {
            if(Validation.IsNotNull(UpDownCommand)){
                UpDown_Command __command = (UpDown_Command)Enum.Parse(typeof(UpDown_Command), cmea.CommandName);
                this.UpDownCommand(this, __command);
            }
        }
		/// <summary>See <see cref="System.Web.UI.WebControls.WebControl.CssClass"/>. </summary>
		public override string			CssClass
		{
			get{return base.CssClass;}
			set{base.CssClass = string.Concat(base.CssClass, QXPFrk.Constantes.Space, value).Trim();}		 
		}
	}
}