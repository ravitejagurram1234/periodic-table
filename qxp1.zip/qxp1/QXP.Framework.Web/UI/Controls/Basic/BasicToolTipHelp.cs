using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace QXP.Framework.Web.UI.Controls.Basic
{
	/// <summary>Represents a label control, which displays text on a Web page. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
	public class ToolTipHelp: System.Web.UI.WebControls.Image{
		#region internal variables
		private static readonly string	DefaultCss = Basic.CssClass.tthelp.ToString();
		#endregion
		/// <summary>Initializes a new instance of <see cref="Label"/> control. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
		public ToolTipHelp(){
			base.CssClass           = DefaultCss;
            this.ImageUrl           = AbsoluteFilesPath.PlaceHolderImg;
            this.EnableViewState    = false;
		}
		/// <summary>Initializes a new instance of <see cref="Label"/> control. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
		/// <param name="help">The text content of the Label control. </param>
		public ToolTipHelp(string help): this(){
			if(Validation.IsSet(help)) this.ToolTip = help;
		}
		/// <summary>Initializes a new instance of <see cref="Label"/> control. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
		/// <param name="help">The text content of the Label control. </param>
		/// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
		public ToolTipHelp(string help, string cssClass): this(help){
			if(Validation.IsSet(cssClass)) this.CssClass = cssClass;
		}
		/// <summary>Initializes a new instance of <see cref="Label"/> control. <seealso cref="System.Web.UI.WebControls.Label"/></summary>
		/// <param name="help">The text content of the Label control. </param>
		/// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
		public ToolTipHelp(string help, Enum cssClass): this(help, Conversion.ToString(cssClass))
		{
		}
        protected override void OnPreRender(EventArgs e)
        {
            this.Visible = Validation.IsSet(this.ToolTip);
            this.Attributes["onclick"] = "alert(this.title);";
            base.OnPreRender(e);
        }
	}
}
