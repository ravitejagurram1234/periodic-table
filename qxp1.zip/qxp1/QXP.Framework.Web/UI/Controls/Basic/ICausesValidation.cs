using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    public interface ICausesValidation : ITextable
    {
        bool CausesValidation { get; set;}
    }
}
