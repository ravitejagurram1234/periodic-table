using System;
using System.Web.UI.WebControls;

namespace QXP.Framework.Web.UI.Controls.Basic
{
    /// <summary>Displays a hyperlink style button control on a Web page. <seealso cref="System.Web.UI.WebControls.LinkButton"/></summary>
    public class LinkButton : Anthem.LinkButton, ICausesValidation
    {
        #region internal variables
        private string _customScript = string.Empty;
        private string _prePostBackScript = string.Empty;
        private string _eventArgument = null;
        private static readonly string DefaultCss = Basic.CssClass.lnkbtn.ToString();
        private const string DisableDefaultEventKey = "DisableDefaultEvent";
        private const string postEventArgumentID = "__EVENTARGUMENT";
        #endregion
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        public LinkButton()
        {
            base.CssClass = DefaultCss;
            this.EnabledDuringCallBack = false;
        }
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        /// <param name="text">The text caption displayed on the <see cref="LinkButton"/> control. </param>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        public LinkButton(string text, string cssClass)
            : this()
        {
            if (Validation.IsSet(text)) this.Text = text;
            if (Validation.IsSet(cssClass)) this.CssClass = cssClass;
        }
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        /// <param name="text">The text caption displayed on the <see cref="LinkButton"/> control. </param>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        /// <param name="commandName">The command name associated with the <see cref="System.Web.UI.WebControls.LinkButton"/> control. This value is passed to the <see cref="System.Web.UI.WebControls.LinkButton.Command"/> event handler along with the <see cref="System.Web.UI.WebControls.LinkButton.CommandArgument"/> property. </param>
        public LinkButton(string text, string cssClass, string commandName)
            : this(text, cssClass)
        {
            if (Validation.IsSet(commandName)) this.CommandName = commandName;
        }
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        /// <param name="text">The text caption displayed on the <see cref="LinkButton"/> control. </param>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        /// <param name="commandName">The command name associated with the <see cref="System.Web.UI.WebControls.LinkButton"/> control. This value is passed to the <see cref="System.Web.UI.WebControls.LinkButton.Command"/> event handler along with the <see cref="System.Web.UI.WebControls.LinkButton.CommandArgument"/> property. </param>
        public LinkButton(string text, string cssClass, Enum commandName) : this(text, cssClass, commandName.ToString()) { }
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        /// <param name="text">The text caption displayed on the <see cref="LinkButton"/> control. </param>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        /// <param name="commandName">The command name associated with the <see cref="System.Web.UI.WebControls.LinkButton"/> control. This value is passed to the <see cref="System.Web.UI.WebControls.LinkButton.Command"/> event handler along with the <see cref="System.Web.UI.WebControls.LinkButton.CommandArgument"/> property. </param>
        public LinkButton(string text, Enum cssClass, Enum commandName) : this(text, cssClass.ToString(), commandName.ToString()) { }
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        /// <param name="text">The text caption displayed on the <see cref="LinkButton"/> control. </param>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        /// <param name="commandName">The command name associated with the <see cref="System.Web.UI.WebControls.LinkButton"/> control. This value is passed to the <see cref="System.Web.UI.WebControls.LinkButton.Command"/> event handler along with the <see cref="System.Web.UI.WebControls.LinkButton.CommandArgument"/> property. </param>
        /// <param name="commandArgument">The argument for the command.. </param>
        public LinkButton(string text, string cssClass, string commandName, string commandArgument)
            : this(text, cssClass, commandName)
        {
            if (Validation.IsSet(commandArgument)) this.CommandArgument = commandArgument;
        }
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        /// <param name="text">The text caption displayed on the <see cref="LinkButton"/> control. </param>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        /// <param name="commandName">The command name associated with the <see cref="System.Web.UI.WebControls.LinkButton"/> control. This value is passed to the <see cref="System.Web.UI.WebControls.LinkButton.Command"/> event handler along with the <see cref="System.Web.UI.WebControls.LinkButton.CommandArgument"/> property. </param>
        /// <param name="commandArgument">The argument for the command. </param>
        public LinkButton(string text, Enum cssClass, Enum commandName, string commandArgument) : this(text, cssClass.ToString(), commandName.ToString(), commandArgument) { }
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        /// <param name="text">The text caption displayed on the <see cref="LinkButton"/> control. </param>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        /// <param name="commandName">The command name associated with the <see cref="System.Web.UI.WebControls.LinkButton"/> control. This value is passed to the <see cref="System.Web.UI.WebControls.LinkButton.Command"/> event handler along with the <see cref="System.Web.UI.WebControls.LinkButton.CommandArgument"/> property. </param>
        /// <param name="commandArgument">The argument for the command.. </param>
        public LinkButton(string text, Enum cssClass, Enum commandName, Enum commandArgument) : this(text, cssClass, commandName, commandArgument.ToString()) { }
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        /// <param name="text">The text caption displayed on the <see cref="LinkButton"/> control. </param>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        /// <param name="commandName">The command name associated with the <see cref="System.Web.UI.WebControls.LinkButton"/> control. This value is passed to the <see cref="System.Web.UI.WebControls.LinkButton.Command"/> event handler along with the <see cref="System.Web.UI.WebControls.LinkButton.CommandArgument"/> property. </param>
        /// <param name="commandArgument">The argument for the command.. </param>
        /// <param name="causeValidation">Define if this <see cref="LinkButton"/> control Cause Validation. </param>
        public LinkButton(string text, string cssClass, string commandName, string commandArgument, bool causeValidation)
            : this(text, cssClass, commandName, commandArgument)
        {
            this.CausesValidation = causeValidation;
        }
        /// <summary>Initializes a new instance of <see cref="LinkButton"/> control. </summary>
        /// <param name="text">The text caption displayed on the <see cref="LinkButton"/> control. </param>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        /// <param name="commandName">The command name associated with the <see cref="System.Web.UI.WebControls.LinkButton"/> control. This value is passed to the <see cref="System.Web.UI.WebControls.LinkButton.Command"/> event handler along with the <see cref="System.Web.UI.WebControls.LinkButton.CommandArgument"/> property. </param>
        /// <param name="commandArgument">The argument for the command. </param>
        /// <param name="causeValidation">Define if this <see cref="LinkButton"/> control Cause Validation. </param>
        public LinkButton(string text, string cssClass, Enum commandName, string commandArgument, bool causeValidation) : this(text, cssClass, commandName.ToString(), commandArgument, causeValidation) { }
        /// <summary>Gets or sets this linkbutton is rendered has a label and generate no event. </summary>
        public bool DisableDefaultEvent
        {
            get { return Conversion.ToBool(this.ViewState[DisableDefaultEventKey]); }
            set { this.ViewState[DisableDefaultEventKey] = value; }
        }
        ///// <summary>Renders the HTML opening tag of the control into the specified writer. This is drive by <see cref="DisableDefaultEvent"/> property. </summary>
        ///// <param name="writer">The <see cref="HtmlTextWriter"/> object that receives the <see cref="LinkButton"/> content. </param>
        //public		override void			RenderBeginTag(HtmlTextWriter writer){
        //    if(this.DisableDefaultEvent){
        //        RenderUtility.AddAttributesToRender(this, writer);
        //        writer.RenderBeginTag(HtmlTextWriterTag.Span);
        //    }else{
        //        base.RenderBeginTag(writer);
        //    }
        //}
        ///// <summary>Adds HTML attributes and styles that need to be rendered to the specified <see cref="System.Web.UI.HtmlTextWriter"/>. This is drive by <see cref="DisableDefaultEvent"/> property. </summary>
        ///// <param name="writer">The <see cref="HtmlTextWriter"/> object that receives the <see cref="LinkButton"/> content. </param>
        //protected override void				AddAttributesToRender(HtmlTextWriter writer) {
        //    if (Validation.IsNotNull(base.Page)) {
        //        base.Page.VerifyRenderingInServerForm(this);
        //    }
        //    RenderUtility.AddAttributesToRender(this, writer);
        //    string __customHRefScript = this.CustomScript;
        //    string __hRefScript				= string.Empty;
        //    if (base.Enabled && Validation.IsNotNull(base.Page) && !this.DisableDefaultEvent) {
        //        if (this.CausesValidation && base.Page.Validators.Count > 0) {
        //            if(Validation.IsSet(__customHRefScript))
        //            {
        //                __hRefScript = String.Concat("javascript:", RenderUtility.GetClientValidatedPostback(this, __customHRefScript));
        //            }
        //            else
        //            {
        //                if(Validation.IsSet(_prePostBackScript))
        //                {
        //                    __hRefScript = String.Concat("javascript:", RenderUtility.GetClientValidatedPostback(this, string.Concat(_prePostBackScript, this.GetClientPostBack())));
        //                }
        //                else{
        //                    __hRefScript = String.Concat("javascript:", RenderUtility.GetClientValidatedPostback(this));
        //                }
        //            }
        //        }else{
        //            if(Validation.IsSet(__customHRefScript))
        //            {
        //                __hRefScript = String.Concat("javascript:", __customHRefScript);
        //            }
        //            else
        //            {
        //                if(Validation.IsSet(_prePostBackScript))
        //                {
        //                    __hRefScript = string.Concat("javascript:", _prePostBackScript, this.GetClientPostBack());
        //                }
        //                else
        //                {
        //                    __hRefScript = base.Page.GetPostBackClientHyperlink(this, "");
        //                }
        //            }
        //        }
        //        //INFO: it's necessary for 'A HRef' controls to return false in onclick event.
        //        __hRefScript = string.Concat(__hRefScript, ";return false;");
        //        writer.AddAttribute(HtmlTextWriterAttribute.Href, "javascript:void(0);", false);
        //        writer.AddAttribute(HtmlTextWriterAttribute.Onclick, __hRefScript, false);
        //    }
        //}
        protected override void OnClick(EventArgs e)
        {
            if (this.CausesValidation && !this.Page.IsValid) return;
            base.OnClick(e);
        }
        protected override void OnCommand(CommandEventArgs e)
        {
            if (this.CausesValidation && !this.Page.IsValid) return;
            base.OnCommand(e);
        }
        /// <summary>Gets the javascript event arguments of the current <see cref="LinkButton"/>. </summary>
        public string JScriptEventArguments
        {
            get { return Conversion.ToString(this.Page.Request.Form[postEventArgumentID]); }
        }
        /// <summary>Gets the client script postback of the current modal link button. </summary>
        /// <returns>the string representation of the script. </returns>
        public string GetClientPostBack()
        {
            if (this.CausesValidation) return RenderUtility.GetClientValidatedPostback(this);
            else return RenderUtility.GetClientPostback(this);
        }
        /// <summary>Gets the client script postback of the current modal link button combined with the specified client <paramref name="script"/>. </summary>
        /// <param name="script">the client script to combine with postback script. </param>
        /// <returns>the string representation of the script. </returns>
        public string GetClientPostBack(string script)
        {
            if (this.CausesValidation) return RenderUtility.GetClientValidatedPostback(this, script);
            else return RenderUtility.GetClientPostback(this, script);
        }
        /// <summary>Gets the client script postback of the current modal link button combined with the no quoted <paramref name="argument"/>. </summary>
        /// <param name="argument">the postback argument to combine. </param>
        /// <returns>the string representation of the script. </returns>
        public string GetClientPostBackWithNoQuotedArgument(string argument)
        {
            if (this.CausesValidation) return RenderUtility.GetClientValidatedPostbackWithNoQuotedArgument(this, argument);
            else return RenderUtility.GetClientPostbackWithNoQuotedArgument(this, argument);
        }
        /// <summary>Gets or Sets the client script if the user click on the current <see cref="LinkButton"/>. </summary>
        public virtual string CustomScript
        {
            get { return _customScript; }
            set { _customScript = value; }
        }
        /// <summary>Gets or Sets the pre postback client script if the user click on the current <see cref="LinkButton"/>. </summary>
        public virtual string PrePostBackScript
        {
            get { return _prePostBackScript; }
            set { _prePostBackScript = value; }
        }
        protected override void RaisePostBackEvent(string eventArgument)
        {
            _eventArgument = eventArgument;
            base.RaisePostBackEvent(eventArgument);
        }
        public string EventArgument
        {
            get { return _eventArgument; }
        }

    }
}
