using System;
using System.Text;
using System.Web.UI;

namespace QXP.Framework.Web.UI.Controls.ComponentArt
{
	/// <summary>
	/// Description r�sum�e de TreeViewTools.
	/// </summary>
	public class TreeViewTools
	{
        #region Membres

        const string CheckedChangedNodesCall    = "nodeCheckChanged";
        static string CheckedChangedNodesScript = string.Empty;
        static string UpdateNodeValueScript     = string.Empty;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        static TreeViewTools()
        {
            StringBuilder __script = new StringBuilder();
            __script.Append("function nodeCheckChanged(node){\n")
                    .Append("	node.ParentTreeView.beginUpdate();\n")
                    .Append("		if (node.Checked) node.CheckAll();\n")
                    .Append("		else			  node.UnCheckAll();\n")
                    .Append("\n")
                    .Append("		nodeParentCheckUnCheck(node);\n")
                    .Append("	node.ParentTreeView.endUpdate();\n")
                    .Append("}\n")
                    .Append("function nodeParentCheckUnCheck(node){\n")
                    .Append("	var pNode = node;\n")
                    .Append("	while(pNode.ParentNode != null){;\n")
                    .Append("		if( pNode.Checked == pNode.ParentNode.Checked || (!pNode.Checked && !checkChildNodes(pNode))) break;\n")
                    .Append("		pNode.ParentNode.SetProperty(\"Checked\", pNode.Checked);\n")
                    .Append("		pNode = pNode.ParentNode;\n")
                    .Append("	};\n")
                    .Append("}\n")
                    .Append("function checkChildNodes(node){\n")
                    .Append("	var __cNode			= null;\n")
                    .Append("	var __checked		= null;\n")
                    .Append("	var __nodeArray		= node.ParentNode.get_nodes();\n")
                    .Append("	for(i = 0 ; i < __nodeArray.get_length() ; i++){;\n")
                    .Append("		__cNode			= __nodeArray.getNode(i);\n")
                    .Append("		if(__cNode != node){;\n")
                    .Append("			if(__cNode.Checked) __checked = true;\n")
                    .Append("			else				__checked = false;\n")
                    .Append("			if(__checked != node.Checked){ return false; break;}\n")
                    .Append("		}\n")
                    .Append("	}\n")
                    .Append("	return true;\n")
                    .Append("}\n");
            CheckedChangedNodesScript = __script.ToString();

            StringBuilder __updateNodeValueScript = new StringBuilder();
            __updateNodeValueScript.Append("function ToggleNodeChecked(treeview_id, node_id){\n")
                    //permet de retrouver la r�f�rence de l'objet treeview
                    .Append("	var treeview	= eval(\"window.\" + treeview_id);\n")
                    //Permet de retrouver la r�f�rence du noeud dans le treeview
                    .Append("	var node		= treeview.findNodeById(node_id);\n")
                    //permet d'effectuer un debogage forc� au passage � cette ligne
                    //.Append("	debugger;\n")
                    //V�rification de l'�tat Lecture ou lecture/Ecriture
                    .Append("	var checked		= node.get_value().startsWith('1:');\n")
                    //Cr�ation de la nouvelle valeur
                    .Append("	var new_value	= checked ? node.get_value().replace('1:', '0:'):node.get_value().replace('0:', '1:');\n")
                    //Mise � jour de la valeur du noeud cette valeur sera r�cup�rer au niveau du code dans la propri�t� Node.value
                    .Append("	node.set_value(new_value);\n")
                    .Append("}\n");
            UpdateNodeValueScript = __updateNodeValueScript.ToString();
        }

        /// <summary>
        /// Cr�e une instance de TreeViewTools
        /// </summary>
        public TreeViewTools()
        {
            //
            // TODO�: ajoutez ici la logique du constructeur
            //
        }

        #endregion Constructeur

        #region M�thodes

        public static void RegisterCheckedChangedNodesScript(Page page)
        {
            ClientScript __page_Script  = new ClientScript(page, "CheckedChangedNodesScript", CheckedChangedNodesScript);
            __page_Script.AddScriptTag  = true;
            __page_Script.StartupScript = true;
            __page_Script.Register();
        }

        /// <summary>
        /// Ajoute le script permettant de mettre � jour la valeur de l'�tat d'un noeud du treeview.
        /// </summary>
        /// <param name="page"></param>
        public static void RegisterUpdateNodeValueScript(Page page)
        {
            ClientScript __page_Script  = new ClientScript(page, "UpdateNodeValueScript", UpdateNodeValueScript);
            __page_Script.AddScriptTag  = true;
            __page_Script.StartupScript = true;
            __page_Script.Register();
        }

        public static string GetCheckedChildNodesCall()
        {
            return CheckedChangedNodesCall;
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
	}
}
