using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using ArtUI = ComponentArt.Web.UI;

namespace QXP.Framework.Web.UI.Controls.ComponentArt
{
	/// <summary>
	/// Classe qui impl�mente un webcontrol utilis� pour d�finir le template d'un noeud du menu
	/// </summary>
    public class BRNode: WebControl
	{
		private int _width = 110;

		public BRNode()
		{
			
		}

		public BRNode(int width)
		{
			_width = width;
		}


        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            this.Width = Unit.Pixel(_width);
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            this.Controls.Add(new LiteralControl(string.Concat("</nobr>", Data.Text)));
        }
        private ArtUI.NavigationNode Data{
            get{return ((ArtUI.NavigationTemplateContainer)this.NamingContainer).DataItem;}
        }
    }
}
