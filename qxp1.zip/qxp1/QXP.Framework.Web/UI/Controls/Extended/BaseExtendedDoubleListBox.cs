using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXPData = QXP.Framework.Data;
using QXPResources = QXP.Framework.Resources;

namespace QXP.Framework.Web.UI.Controls.Extended
{
    /// <summary>
    /// Class BaseExtendedDoubleListBox : Control de base web double list box
    /// </summary>
    /// <author>LCU</author>
    /// <date>10/01/2011</date>    
    public abstract class BaseExtendedDoubleListBox : WebControlTagged, INamingContainer, QXPResources.IResource
    {
        #region Membres

        private static readonly string DefaultCss = Extended.CssClass.dbllstbx.ToString();
        private bool _autoPostBack = false;
        private bool _causeValidation = false;
        private int _maxSelectedItems = 0;
        protected bool _displayInfo = true;
        private bool _displayFind = false;
        protected bool _displayUpDown = false;
        protected Basic.TableSection _table;
        private Basic.Label _labelSource;
        private Basic.Label _labelDestination;
        private Basic.ImageButton _l2r;
        private Basic.ImageButton _l2rAll;
        private Basic.ImageButton _r2l;
        private Basic.ImageButton _r2lAll;
        private Basic.ImageButton _btn_top;
        private Basic.ImageButton _btn_up;
        private Basic.ImageButton _btn_down;
        private Basic.ImageButton _btn_bottom;
        private Basic.Label _labelddlFind;
        protected Basic.DropDownList _ddlFind;
        protected Basic.ListBox _listSource;
        protected Basic.ListBox _listDestination;
        private Basic.Label _labeltxtFind;
        private Basic.TextBox _txtFind;
        private string _dataTextFormatString;
        protected Html.Hidden _hidden;
        protected int _maxTextLength = 40;
        private bool _reseatMoveItem = false;
        private QXPResources.ResourceInfo _resourceInfo;
        public event EventHandler SelectionChanged;

        #endregion Membres

        #region Constantes

        private const string VSAllLeftToRight = "AllLeftToRightMsg";
        private const string VSAllRightToLeft = "AllRightToLeftMsg";
        private const string VSMaxSelectedMsg = "MaxSelectedMsg";
        private const string AttAffinityLength = "affinityLength";
        private const string AttAffinityString = "affinityString";
        private const string VSDefaultSelectedValues = "DefautSelectedValues";
        private const string VSValuesForSave = "ValuesForSave";
        protected const Char CommandSeparator = '\x1F';
        protected const Char InfoSeparator = '^';
        protected const Char ValuesInItemInfoSeparator = '|'; //Utilis� �galement dans le javascript associ� au control
        private const int DEFAULT_NB_ROWS = 6;

        #endregion Constantes

        #region Enums

        /// <summary>
        /// Controles
        /// </summary>
        private enum Controles
        {
            ListSource,
            ListDestination,
            BtnSelect,
            BtnSelectAll,
            BtnDeselect,
            BtnDeselectAll,
            Find,
            FindText,
            MaxSelected,
        }

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Initializes a new instance of <see cref="BaseExtendedDoubleListBox"/> control. 
        /// </summary>
        public BaseExtendedDoubleListBox()
            : this(false)
        {
        }

        /// <summary>
        /// Initializes a new instance of <see cref="BaseExtendedDoubleListBox"/> control.
        /// </summary>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control.</param>
        public BaseExtendedDoubleListBox(string cssClass)
            : this()
        {
            if (Validation.IsSet(cssClass))
                this.CssClass = cssClass;
        }

        /// <summary>
        /// Initializes a new instance of <see cref="BaseExtendedDoubleListBox"/> control.
        /// </summary>
        /// <param name="displayUpDown">Affiche ou non les boutons Up et Down</param>
        public BaseExtendedDoubleListBox(bool displayUpDown)
        {
            _displayUpDown = displayUpDown;
            //INFO: cette ligne est n�cessaire car des informations peuvent �tre mises dans le viewstate avant la fin de l'initialisation du controle.
            this.TrackViewState();
            _resourceInfo = new QXPResources.ResourceInfo();
            _table = new Basic.TableSection(displayUpDown ? 4 : 3, 5);
            _table.CssClass = DefaultCss;
            _labelSource = new Basic.Label();
            _labelDestination = new Basic.Label();
            _labeltxtFind = new Basic.Label();
            _labelddlFind = new Basic.Label();
            _listSource = new Basic.ListBox();
            _listSource.SelectionMode = ListSelectionMode.Multiple;
            _listSource.Rows = DEFAULT_NB_ROWS;
            _listDestination = new Basic.ListBox();
            _listDestination.SelectionMode = ListSelectionMode.Multiple;
            _listDestination.Rows = DEFAULT_NB_ROWS;
            _txtFind = new Basic.TextBox();
            _ddlFind = new Basic.DropDownList();
            _hidden = new Html.Hidden();
            _hidden.ServerChange += this.OnSelectionChanged;

            _labelSource.CssClass = Extended.CssClass.dbllstbx_lbllstSource.ToString();
            _labelDestination.CssClass = Extended.CssClass.dbllstbx_lbllstDestination.ToString();
            _listSource.CssClass = Extended.CssClass.dbllstbx_lstSource.ToString();
            _listDestination.CssClass = Extended.CssClass.dbllstbx_lstDestination.ToString();

            _l2r = new Basic.ImageButton(AbsoluteFilesPath.PlaceHolderImg);
            _l2r.CssClass = Extended.CssClass.l2r.ToString();
            
            _r2l = new Basic.ImageButton(AbsoluteFilesPath.PlaceHolderImg);
            _r2l.CssClass = Extended.CssClass.r2l.ToString();
            
            _l2rAll = new Basic.ImageButton(AbsoluteFilesPath.PlaceHolderImg);
            _l2rAll.CssClass = Extended.CssClass.l2rAll.ToString();
            
            _r2lAll = new Basic.ImageButton(AbsoluteFilesPath.PlaceHolderImg);
            _r2lAll.CssClass = Extended.CssClass.r2lAll.ToString();
            
        }

        /// <summary>
        /// Initializes a new instance of <see cref="BaseExtendedDoubleListBox"/> control.
        /// </summary>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control.</param>
        /// <param name="displayUpDown">Affiche ou non les boutons Up et Down</param>
        public BaseExtendedDoubleListBox(string cssClass, bool displayUpDown)
            : this(displayUpDown)
        {
            if (Validation.IsSet(cssClass))
                this.CssClass = cssClass;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Efface les valeurs selectionn�es par d�faut
        /// </summary>
        public void ClearDefaultValues()
        {
            this.ViewState[VSDefaultSelectedValues] = string.Empty;
        }

        /// <summary>
        /// Efface les valeurs s�lectionn�es
        /// </summary>
        public void ClearSelectedValues()
        {
            _hidden.Value = string.Empty;
        }

        /// <summary>
        /// Efface les valeurs persist�es pour une sauvegarde
        /// </summary>
        public void ClearValuesForSave()
        {
            this.ViewState[VSValuesForSave] = string.Empty;
        }

        /// <summary>
        /// Met � jour le champs cach� � partir des �l�ments contenus dans la liste de destination
        /// </summary>
        protected void UpdateHiddenSelectedValues()
        {
            var __selectedValues = new List<string>();
            foreach (ListItem __item in _listDestination.Items)
            {
                string[] __values = Conversion.ToString(__item.Value).Split(InfoSeparator);
                if (__values.Length > 0)
                {
                    __selectedValues.Add(__values[0]);
                }
            }
            _hidden.Value = string.Join(CommandSeparator.ToString(), __selectedValues.ToArray());
        }

        /// <summary>
        /// Ajoute un item dans la liste
        /// </summary>
        /// <param name="list">Liste � modifier</param>
        /// <param name="value">Valeur ajout�e</param>
        /// <param name="text">Text associ�e</param>
        /// <param name="info">Informations associ�es</param>
        protected void AddItem(List<ListItem> list, string @value, string text, string info)
        {
            this.AddItem(list, list.Count, value, text, info);
        }

        /// <summary>
        /// Ajoute un item dans la liste
        /// </summary>
        /// <param name="list">Liste � modifier</param>
        /// <param name="value">Valeur ajout�e</param>
        /// <param name="text">Text associ�e</param>
        /// <param name="info">Informations associ�es</param>
        /// <param name="checked">Element coch� ou non</param>
        protected void AddItem(List<ListItem> list, string @value, string text, string info, bool @checked)
        {
            this.AddItem(list, list.Count, value, text, info, @checked);
        }

        /// <summary>
        /// Ajoute un item dans la liste
        /// </summary>
        /// <param name="list">Liste � modifier</param>
        /// <param name="index">Position de l'�l�ment dans la liste</param>
        /// <param name="value">Valeur ajout�e</param>
        /// <param name="text">Text associ�e</param>
        /// <param name="info">Informations associ�es</param>
        protected void AddItem(List<ListItem> list, int index, string @value, string text, string info)
        {
            this.AddItem(list, index, @value, text, info, false);
        }

        /// <summary>
        /// Ajoute un item dans la liste
        /// </summary>
        /// <param name="list">Liste � modifier</param>
        /// <param name="index">Position de l'�l�ment dans la liste</param>
        /// <param name="value">Valeur ajout�e</param>
        /// <param name="text">Text associ�e</param>
        /// <param name="info">Informations associ�es</param>
        /// <param name="checked">Element coch� ou non</param>
        protected void AddItem(List<ListItem> list, int index, string @value, string text, string info, bool @checked)
        {
            ListItem __listItem = new ListItem();

            if (Validation.IsSet(info))
                __listItem.Value = string.Join(InfoSeparator.ToString(), new string[] { value, info });
            else
                __listItem.Value = value;

            if (this.Checkable)
            {
                if (@checked)
                    __listItem.Text = string.Concat(_listDestination.CheckedString, text);
                else
                    __listItem.Text = string.Concat(_listDestination.UnCheckedString, text);
            }
            else
            {
                __listItem.Text = text;
            }

            list.Insert(index, __listItem);
        }

        /// <summary>
        /// Evenement lev� lors d'un changement de contenu du champs hidden stock�e sur la page
        /// (a lieu lorsque que les �l�ments sont modifi�s par le navigateur, evenement lev� par le javascript)
        /// </summary>
        private void HiddenChanged(object sender, EventArgs ea)
        {
            this.UpdateLists();
        }

        /// <summary>
        /// Met � jours les �l�ments disponibles et s�lectionn�es � partir des valeurs des contr�les
        /// </summary>
        protected virtual void UpdateLists()
        {
            //On utilise pas la propri�t� SelectedValues car elle est peut etre surcharg�e
            //on veut etre sur de travailler avec la totalit� des �l�ments stock�s dans la value
            List<string> __selectedValues = new List<string>();
            if (Validation.IsSet(_hidden.Value))
            {
                __selectedValues = _hidden.Value.Split(CommandSeparator.ToString().ToCharArray(), StringSplitOptions.RemoveEmptyEntries).ToList();
            }

            SortableList<ListItem> __itemsToDestination = new SortableList<ListItem>();
            SortableList<ListItem> __itemsToSource = new SortableList<ListItem>();
            bool __sortDestination = !_displayUpDown;
            ListItemCollection __allItems = new ListItemCollection();
            ListItem[] __items;
            __items = new ListItem[_listSource.Items.Count];
            _listSource.Items.CopyTo(__items, 0);
            __allItems.AddRange(__items);
            __items = new ListItem[_listDestination.Items.Count];
            _listDestination.Items.CopyTo(__items, 0);
            __allItems.AddRange(__items);
            foreach (ListItem __item in __allItems)
            {
                string __itemValue = this.GetItemValue(__item);
                if (__selectedValues.Contains(__itemValue))
                {
                    if (__sortDestination)
                    {
                        __itemsToDestination.Add(__item);
                    }
                    else
                    {
                        int __index = __selectedValues.IndexOf(__itemValue);
                        if (Validation.IsSet(__index) && __itemsToDestination.Count > __index) 
                            __itemsToDestination.Insert(__index, __item);
                        else 
                            __itemsToDestination.Add(__item);
                    }
                }
                else
                {
                    if (_listDestination.Checkable)
                    {
                        string __newItemText = __item.Text;
                        if (__newItemText.IndexOf(_listDestination.CheckedString) != -1)
                        {
                            __newItemText = _listDestination.UnCheckedString + __newItemText.Substring(_listDestination.CheckedString.Length);
                            __item.Text = __newItemText;
                        }
                    }
                    __itemsToSource.Add(__item);
                }
            }

            Comparers.ListItemComparer __comparer = new Comparers.ListItemComparer();
            __itemsToSource.Sort(__comparer);
            __itemsToDestination.Sort(__comparer);
            
            _listSource.Items.Clear();
            _listDestination.Items.Clear();

            _listSource.Items.AddRange(__itemsToSource.ToArray());
            _listDestination.Items.AddRange(__itemsToDestination.ToArray());
        }

        /// <summary>
        /// Retourne la valeur d'un �l�ment d'une listbox
        /// </summary>
        /// <param name="item">Element</param>
        /// <returns>Valeur stock�e en string</returns>
        protected string GetItemValue(ListItem item)
        {
            return ParseItem(item, 0);
        }

        /// <summary>
        /// Retourne le champs index� par le param�tre pos
        /// d'un �l�ment d'une listbox
        /// </summary>
        /// <param name="item">Element</param>
        /// <param name="pos">Position du champs</param>
        /// <returns>Valeur stock�e en string</returns>
        protected string ParseItem(ListItem item, int pos)
        {
            string __itemValue = "";
            string[] __itemValues = item.Value.Split(InfoSeparator);
            if (__itemValues.Length > pos)
            {
                __itemValue = __itemValues[pos];
            }
            return __itemValue;
        }

        /// <summary>
        /// Effectue un tri sur les �l�ments des listes sources et destinations
        /// </summary>
		/// <remarks>
		/// les listes sont pass� par r�f�rence car elles peuvent �tre re-cr��es � l'int�rieur de cette m�thode
		/// </remarks>
        /// <param name="listitemsSource">Elements de la liste source</param>
        /// <param name="listitemsDestination">Elements de la liste destination</param>
        protected void Sort(ref List<ListItem> listitemsSource, ref List<ListItem> listitemsDestination)
        {
            if (this.IsSorted)
            {
                ArrayHelper.Sort(listitemsSource, new Comparers.ListItemComparer());

                if (_displayUpDown)
                {
                    listitemsDestination = this.ReorderSelectedValues(this.DefaultSelectedValues.ToList(), listitemsDestination);
                }
                else
                {
                    ArrayHelper.Sort(listitemsDestination, new Comparers.ListItemComparer());
                }

                foreach (ListItem __item in listitemsSource)
                {
                    __item.Text = StringHelper.StartString(__item.Text, _maxTextLength);
                }

                foreach (ListItem __item in listitemsDestination)
                {
                    __item.Text = StringHelper.StartString(__item.Text, _maxTextLength);
                }
            }
        }

        /// <summary>
        /// Binding du double list box
        /// </summary>
        public override void DataBind()
        {
            _listSource.Items.Clear();
            _listDestination.Items.Clear();

            this.ClearSelectedValues();
            this.ClearValuesForSave();
        }

        /// <summary>
        /// R�ordonne les �l�ments s�lectionn�s
        /// </summary>
        /// <param name="selectedValues">Valeurs � s�lectionner</param>
        /// <param name="selectedItems">Elements s�lectionn�s</param>
        /// <returns></returns>
        protected List<ListItem> ReorderSelectedValues(List<string> selectedValues, List<ListItem> selectedItems)
        {
            List<ListItem> __items = new List<ListItem>(selectedItems.Count);
            ListItem[] __ar_items = new ListItem[selectedValues.Count];

            foreach (ListItem __item in selectedItems)
            {
                int __pos = selectedValues.IndexOf(__item.Value);
                __ar_items[__pos] = __item;
            }

            foreach (ListItem __item in __ar_items)
            {
                if (Validation.IsNotNull(__item))
                    __items.Add(__item);
            }
            return __items;
        }

        /// <summary>
        /// D�finition des localisations des contr�les contenus dans le doublelistbox
        /// </summary>
        private void SetResource()
        {
            if (this.ResourceInfo.HaveSections)
            {
                if (Validation.IsNotSet(this.LabelSource))
                    this.LabelSource = this.ResourceInfo.GetLabel(Controles.ListSource);

                if (Validation.IsNotSet(this.LabelDestination))
                    this.LabelDestination = this.ResourceInfo.GetLabel(Controles.ListDestination);

                if (Validation.IsNotSet(this.AllLeftToRightMessage))
                    this.AllLeftToRightMessage = this.ResourceInfo.GetMessage(Controles.BtnSelectAll);

                if (Validation.IsNotSet(this.AllRightToLeftMessage))
                    this.AllRightToLeftMessage = this.ResourceInfo.GetMessage(Controles.BtnDeselectAll);

                if (this.MaxSelectedItems > 0 && Validation.IsNotSet(this.MaxSelectedMessage))
                    this.MaxSelectedMessage = this.ResourceInfo.GetMessage(Controles.MaxSelected, this.MaxSelectedItems);

                if (Validation.IsNotSet(this.FindLabel) && this.ResourceInfo.ExistLabel(Controles.Find))
                {
                    this.FindLabel = this.ResourceInfo.GetLabel(Controles.Find);
                }

                if (Validation.IsNotSet(this.FindLabelText) && this.ResourceInfo.ExistLabel(Controles.FindText))
                {
                    this.FindLabelText = this.ResourceInfo.GetLabel(Controles.FindText);
                }
            }
        }

        /// <summary>
        /// Retourne la liste des labels � afficher sous le s�lecteur pour afficher les informations d'un �l�ment s�lectionn�
        /// </summary>
        /// <returns>List string</returns>
        protected virtual List<string> GetLabelsInfo()
        {
            return null;
        }

        /// <summary>
        /// Affiche ou non les contr�les d'affichage des informations d'un �l�ment s�lectionn�
        /// </summary>
        protected void PreRenderDisplayInfo()
        {
            if (!_displayInfo)
                return;


            List<string> __labelInfos = GetLabelsInfo();

            if (Validation.IsSet(__labelInfos))
            {

                string __targetSrc = string.Format("{0}_src_", this.ClientID);
                string __targetDst = string.Format("{0}_dst_", this.ClientID);

                //INFO; calculate number of items in find elements and remove 1 for emptyselection.
                Basic.TableRowSection __row = _table[4];
                Basic.TableSection __tableSrc = new Basic.TableSection(2, __labelInfos.Count);
                Basic.TableSection __tableDst = new Basic.TableSection(2, __labelInfos.Count);
                __tableSrc.CssClass = Extended.CssClass.dbllstbx_nfo.ToString();
                __tableDst.CssClass = Extended.CssClass.dbllstbx_nfo.ToString();
                __row[0].Add(__tableSrc);
                __row[2].Add(__tableDst);
                int __i = 0;
                foreach (string __labelInfo in __labelInfos)
                {                    
                    string __name = __labelInfo;
                    __tableSrc[__i, 0].Add(__name);
                    string __css = Extended.CssClass.dbllstbx_nfolbl.ToString();
                    __css = string.Concat(__css, " ", __css, "_", __name); //INFO this Css allow 
                    __tableSrc[__i, 0].CssClass = __css;
                    __tableDst[__i, 0].Add(__name);
                    __tableDst[__i, 0].CssClass = __css;

                    string __label = string.Format("<span class='{0}' id='{1}{2}'></span>", Extended.CssClass.dbllstbx_nfovaluelbl, __targetSrc, __i);
                    __tableSrc[__i, 1].Add(__label);
                    __tableSrc[__i, 1].CssClass = Extended.CssClass.dbllstbx_nfovalue.ToString();
                    __label = string.Format("<span class='{0}' id='{1}{2}'></span>", Extended.CssClass.dbllstbx_nfovaluelbl, __targetDst, __i);
                    __tableDst[__i, 1].Add(__label);
                    __tableDst[__i, 1].CssClass = Extended.CssClass.dbllstbx_nfovalue.ToString();
                    __i++;
                }


                _listSource.AutoComplete_OnChange = "AfficheInformation('" + _listSource.ClientID + "','" + __targetSrc + "' ,'" + __labelInfos.Count + "');";
                _listDestination.AutoComplete_OnChange = "AfficheInformation('" + _listDestination.ClientID + "','" + __targetDst + "', '" + __labelInfos.Count + "');";
            }
        }

        /// <summary>
        /// Retourne les �l�ments � cocher
        /// </summary>
        /// <returns>Elements � cocher</returns>
        protected ArrayList GetCheckedStatus()
        {
            ArrayList __checkValues = new ArrayList();
            if (this.Checkable)
            {
                if (Validation.IsSet(_listDestination.AlreadyChecked))
                {
                    __checkValues.AddRange(_listDestination.AlreadyChecked);
                }
                else
                {
                    if (Validation.IsNotNull(_listDestination.DefaultChecked))
                    {
                        __checkValues.AddRange(_listDestination.DefaultChecked);
                    }
                }
            }
            return __checkValues;

        }

        /// <summary>
        /// Retourne l'itemtext associ� � l'objet bind� en fonction de la propri�t� DataTextField et DataTextFormatString
        /// </summary>
        /// <param name="value">Objet</param>
        /// <returns>Valeur de l'itemtext</returns>
        protected virtual string GetDataTextField(object value)
        {
            string __itemText = string.Empty;

            if (Validation.IsSet(DataTextField))
            {
                __itemText = Conversion.ToString(QXPData.DataBinder.Eval(value, DataTextField, DataTextFormatString));
            }
            else
            {
                if (Validation.IsSet(DataTextFormatString))
                    __itemText = string.Format(DataTextFormatString, value);
                else
                    __itemText = Conversion.ToString(value);
            }
            return __itemText;
        }

        /// <summary>
        /// Retourne l'iteminfo associ� � l'objet bind� en fonction de la propri�t� DataInfoField
        /// </summary>
        /// <param name="value">Objet</param>
        /// <returns>Valeur de l'iteminfo</returns>
        protected virtual string GetDataInfoField(object value)
        {
            string __itemInfo = null;
            if (Validation.IsSet(DataInfoField))
                __itemInfo = Conversion.ToString(QXPData.DataBinder.Eval(value, DataInfoField, null));
            return __itemInfo;
        }

        /// <summary>
        /// R�cup�re les valeurs � persister sur le contr�le
        /// </summary>
        /// <param name="lstSrc">Elements de la List source</param>
        /// <param name="lstDest">Elements de la List destination</param>
        protected void SetValuesForSave(List<string> lstSrc, List<string> lstDest)
        {
            var __listitemsforsave = new List<string>();
            //Permet de r�cup�rer les objets qui ne sont ni dans la source ni dans la destination
            //mais seulement dans le r�sultat de la requete qui remplit le datasourceselect
            if (Validation.IsNotSet(this.ViewState[VSValuesForSave]))
            {
                foreach (object item in this.DefaultSelectedValues)
                {
                    if ((!lstSrc.Contains(item.ToString())) && (!lstDest.Contains(item.ToString())))
                    {
                        __listitemsforsave.Add(item.ToString());
                    }
                }

                ValuesForSave = __listitemsforsave.ToArray();
            }
        }

        #endregion M�thodes

        #region Evenements

        /// <summary>
        /// Lors de la cr�ation du controle
        /// </summary>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            this.Controls.Add(_table);
            //INFO: Labels row
            Basic.TableRowSection __row = _table[0];
            __row[0].Add(_labelSource);
            __row[2].Add(_labelDestination);
            __row[0].CssClass = Extended.CssClass.dbllstbx_colsrc.ToString();
            __row[1].CssClass = Extended.CssClass.dbllstbx_colsep.ToString(); ;
            __row[2].CssClass = Extended.CssClass.dbllstbx_coldst.ToString(); ;

            //INFO: Select find row
            __row = _table[1];
            //Faire une seul cellule !!
            __row.Cells.RemoveAt(2);
            __row.Cells.RemoveAt(1);
            __row[0].ColumnSpan = 3;
            __row[0].Add(_labelddlFind);
            __row[0].Add(_ddlFind);
            _ddlFind.EnableEmptySelection = true;
            _ddlFind.EmptyText = " ";

            //INFO: text find row
            __row = _table[2];
            //Faire une seul cellule !!
            __row.Cells.RemoveAt(2);
            __row.Cells.RemoveAt(1);
            __row[0].ColumnSpan = 3;
            __row[0].Add(_labeltxtFind);
            __row[0].Add(_txtFind);
            _txtFind.Enabled = false;

            //INFO: list /buttons row
            __row = _table[3];
            __row[0].Add(_listSource);
            _listSource.ID = _listSource.ID;
            __row[2].Add(_listDestination);
            _listDestination.ID = _listDestination.ID;

            #region verticals buttons
            //INFO: buttons table;
            Basic.TableSection __verticalButtons = new Basic.TableSection(1, 4);
            __verticalButtons.CssClass = Extended.CssClass.dbllstbx_btnstbl.ToString();

            //INFO: you must add Hiddent controll before asking ClientID on it
            __row[1].Add(_hidden);
            _hidden.ServerChange += new EventHandler(this.HiddenChanged);
            _hidden.ID = "_hidden";

            __verticalButtons[0, 0].Add(_l2r);
            __verticalButtons[1, 0].Add(_r2l);
            __verticalButtons[2, 0].Add(_l2rAll);
            __verticalButtons[3, 0].Add(_r2lAll);
            __row[1].Add(__verticalButtons);
            __row[1].CssClass = Extended.CssClass.dbllstbx_btns.ToString();
            #endregion

            #region TopUpDownBottom buttons
            if (_displayUpDown)
            {
                //INFO: buttons table;
                Basic.TableSection __topUpDownBottomButtons = new Basic.TableSection(1, 4);
                __topUpDownBottomButtons.CssClass = Extended.CssClass.dbllstbx_btnstbl.ToString();

                _btn_top = new Basic.ImageButton(AbsoluteFilesPath.PlaceHolderImg);
                _btn_top.CssClass = Extended.CssClass.move_top.ToString();
                __topUpDownBottomButtons[0, 0].Add(_btn_top);
                _btn_up = new Basic.ImageButton(AbsoluteFilesPath.PlaceHolderImg);
                _btn_up.CssClass = Extended.CssClass.move_up.ToString();
                __topUpDownBottomButtons[1, 0].Add(_btn_up);
                _btn_down = new Basic.ImageButton(AbsoluteFilesPath.PlaceHolderImg);
                _btn_down.CssClass = Extended.CssClass.move_down.ToString();
                __topUpDownBottomButtons[2, 0].Add(_btn_down);
                _btn_bottom = new Basic.ImageButton(AbsoluteFilesPath.PlaceHolderImg);
                _btn_bottom.CssClass = Extended.CssClass.move_bottom.ToString();
                __topUpDownBottomButtons[3, 0].Add(_btn_bottom);

                __row[3].Add(__topUpDownBottomButtons);
                __row[3].CssClass = Extended.CssClass.dbllstbx_btnstopupdownbottom.ToString();
            }
            #endregion

            //INFO: the lines bellow force clientID to rendering
            _txtFind.ID = _txtFind.ID;
            _ddlFind.ID = _ddlFind.ID;
            _labeltxtFind.CssClass = Extended.CssClass.dbllstbx_lblfndtbx.ToString();
            _labelddlFind.CssClass = Extended.CssClass.dbllstbx_lblfndddl.ToString();
            _txtFind.CssClass = Extended.CssClass.dbllstbx_fndtbx.ToString();
            _ddlFind.CssClass = Extended.CssClass.dbllstbx_fndddl.ToString();
            this.Page.RegisterClientScriptBlock("doubleList", string.Format("<script language=\"javascript\" src=\"{0}\"></script>", AbsoluteFilesPath.DoubleListBoxScript));
            this.SetResource();

        }

        /// <summary>
        /// Avant le rendu du controle
        /// </summary>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            int __findlength = _ddlFind.Items.Count - 1;
            _ddlFind.Visible = _txtFind.Visible = (__findlength > 0 && _displayFind);
            _labelddlFind.Visible = _labeltxtFind.Visible = (__findlength > 0 && _displayFind);

            string __targetSrc = string.Format("{0}_src_", this.ClientID);
            string __targetDst = string.Format("{0}_dst_", this.ClientID);

            _txtFind.Attributes.Add("onKeyPress", "SetTimeOut(500,'" + _listSource.ClientID + "','" + _ddlFind.ClientID + "','" + _txtFind.ClientID + "','" + __targetSrc + "');");
            _ddlFind.Attributes.Add("onchange", "ActiveDesactiveChampTexte('" + _ddlFind.ClientID + "','" + _txtFind.ClientID + "')");

            int __maxSelectedItems = _maxSelectedItems;
            string __autopostID = _autoPostBack ? _hidden.UniqueID.Replace(":", "$") : "";
            string __causeValidation = _causeValidation ? "true" : "false";
            string __replaceItem = (this.ReseatMoveItem) ? "true" : "false";
            string __maxSelectedMessage = this.MaxSelectedMessage;

            string __left2Right = string.Concat("return DoubleListBox_MoveSelectedItems('", _listSource.ClientID, "','", _listDestination.ClientID, "','", _hidden.ClientID, "', '+','", __targetSrc, "', '", __findlength, "', ", __replaceItem, ", '", __autopostID, "',", __causeValidation, ", ", __maxSelectedItems, ", '", __maxSelectedMessage, "');");
            string __right2Left;

            if (_listDestination.Checkable)
                __right2Left = string.Concat("SwapSelectedToUnchecked(document.getElementById('", _listDestination.ClientID, "'),'", _listDestination.HiddenClientID, "','", _listDestination.CheckedString, "', '", _listDestination.UnCheckedString, "')", ";return DoubleListBox_MoveSelectedItems('", _listDestination.ClientID, "','", _listSource.ClientID, "','", _hidden.ClientID, "', '-','", __targetDst, "', '", __findlength, "', ", __replaceItem, ", '", __autopostID, "',", __causeValidation, ", ", __maxSelectedItems, ", '", __maxSelectedMessage, "');");
            else
                __right2Left = string.Concat(";return DoubleListBox_MoveSelectedItems('", _listDestination.ClientID, "','", _listSource.ClientID, "','", _hidden.ClientID, "', '-','", __targetDst, "', '", __findlength, "', ", __replaceItem, ", '", __autopostID, "',", __causeValidation, ", ", __maxSelectedItems, ", '", __maxSelectedMessage, "');");

            string __allLeft2Right = string.Concat("return AfficheQuestion('", _listSource.ClientID, "','", _listDestination.ClientID, "','", this.AllLeftToRightMessage, "','", _hidden.ClientID, "', '+','", __targetSrc, "', '", __findlength, "', ", __replaceItem, ", '", __autopostID, "',", __causeValidation, ", ", __maxSelectedItems, ", '", __maxSelectedMessage, "');");

            string __allRight2Left;

            if (_listDestination.Checkable)
            {
                __allRight2Left = string.Concat("SwapAllToUnchecked(document.getElementById('", _listDestination.ClientID, "'),'", _listDestination.HiddenClientID, "','", _listDestination.CheckedString, "','", _listDestination.UnCheckedString, "')", ";return AfficheQuestion('", _listDestination.ClientID, "','", _listSource.ClientID, "','", this.AllRightToLeftMessage, "','", _hidden.ClientID, "', '-','", __targetDst, "', '", __findlength, "', ", __replaceItem, ", '", __autopostID, "',", __causeValidation, ", ", __maxSelectedItems, ", '", __maxSelectedMessage, "');");
            }
            else
                __allRight2Left = string.Concat("return AfficheQuestion('", _listDestination.ClientID, "','", _listSource.ClientID, "','", this.AllRightToLeftMessage, "','", _hidden.ClientID, "', '-','", __targetDst, "', '", __findlength, "', ", __replaceItem, ", '", __autopostID, "',", __causeValidation, ", ", __maxSelectedItems, ", '", __maxSelectedMessage, "');");

            _listSource.Attributes.Add("ondblclick", __left2Right);
            _listDestination.Attributes.Add("ondblclick", __right2Left);

            _l2r.Attributes.Add("onclick", __left2Right);
            _r2l.Attributes.Add("onclick", __right2Left);

            if (_displayUpDown)
            {
                string __top = string.Concat("return DoubleListBox_MoveUpDownSelectedItems('", _listDestination.ClientID, "','", _hidden.ClientID, "','", __autopostID, "',", __causeValidation, ",'--');");
                string __up = string.Concat("return DoubleListBox_MoveUpDownSelectedItems('", _listDestination.ClientID, "','", _hidden.ClientID, "','", __autopostID, "',", __causeValidation, ",'-');");
                string __down = string.Concat("return DoubleListBox_MoveUpDownSelectedItems('", _listDestination.ClientID, "','", _hidden.ClientID, "','", __autopostID, "',", __causeValidation, ",'+');");
                string __bottom = string.Concat("return DoubleListBox_MoveUpDownSelectedItems('", _listDestination.ClientID, "','", _hidden.ClientID, "','", __autopostID, "',", __causeValidation, ",'++');");

                _btn_top.Attributes.Add("onclick", __top);
                _btn_up.Attributes.Add("onclick", __up);
                _btn_down.Attributes.Add("onclick", __down);
                _btn_bottom.Attributes.Add("onclick", __bottom);
            }

            bool __multiSelection = (_listSource.SelectionMode == System.Web.UI.WebControls.ListSelectionMode.Multiple);

            if (__multiSelection)
            {
                _l2rAll.Attributes.Add("onclick", __allLeft2Right);
                _r2lAll.Attributes.Add("onclick", __allRight2Left);
            }

            _l2rAll.Visible = _r2lAll.Visible = __multiSelection;

            if (_autoPostBack)
            {
                _hidden.Attributes["postid"] = _hidden.UniqueID.Replace(":", "$");
            }

            PreRenderDisplayInfo();

        }

        /// <summary>
        /// Lors d'un changement dans le contenu du doublelistbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="ea"></param>
        protected virtual void OnSelectionChanged(object sender, EventArgs ea)
        {
            if (Validation.IsNotNull(this.SelectionChanged))
            {
                this.SelectionChanged(sender, ea);
            }
        }

        #endregion Evenements

        #region Propri�t�s

        /// <summary>
        /// Nombre de lignes des deux list box (source et destination)
        /// Attention � d�finir avant l'init du control
        /// </summary>
        public int NbRows
        {
            get { return this._listSource.Rows; }
            set { this._listSource.Rows = this._listDestination.Rows = value; }
        }

        /// <summary>
        /// Champs cach�
        /// </summary>
        public Html.Hidden HiddenField
        {
            get { return _hidden; }
        }

        /// <summary>
        /// Propri�t� qui contient tous les �l�ments de la liste de droite du composant
        /// Elle est initialis�e lors du databind et modifi�e cot� client par le javascript 
        /// </summary>
        public virtual string[] SelectedValues
        {
            get
            {
                if (Validation.IsSet(_hidden.Value))
                {
                    return _hidden.Value.Split(CommandSeparator.ToString().ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                }
                else
                {
                    return new string[0];
                }

            }
        }

        /// <summary>
        /// Valeurs par d�faut � selectionner lors du binding
        /// </summary>
        public virtual string[] DefaultSelectedValues
        {
            get
            {
                if (Validation.IsSet(this.ViewState[VSDefaultSelectedValues]))
                {
                    return Conversion.ToString(this.ViewState[VSDefaultSelectedValues]).Split(CommandSeparator);
                }
                else
                {
                    return new string[0];
                }
            }
            set
            {
                if (Validation.IsSet(value))
                    this.ViewState[VSDefaultSelectedValues] = string.Join(CommandSeparator.ToString(), value);
                else
                    this.ViewState[VSDefaultSelectedValues] = string.Empty;
            }
        }

        /// <summary>
        /// Contient les objets qui ne sont ni dans la source ni dans la destination
        /// mais seulement dans le r�sultat de la requete qui remplit le datasourceselect
        /// </summary>
        protected string[] ValuesForSave
        {
            get
            {
                if (Validation.IsSet(this.ViewState[VSValuesForSave]))
                {
                    return Conversion.ToString(this.ViewState[VSValuesForSave]).Split(CommandSeparator);
                }
                else
                {
                    return new string[0];
                }
            }
            set
            {
                if (Validation.IsSet(value))
                    this.ViewState[VSValuesForSave] = string.Join(CommandSeparator.ToString(), value);
                else
                    this.ViewState[VSValuesForSave] = string.Empty;
            }
        }

        /// <summary>
        /// Permet de repositionner les elements qui change de liste par ordre alphabetique (def=false)
        /// </summary>
        public bool ReseatMoveItem
        {
            get { return _reseatMoveItem; }
            set { _reseatMoveItem = value; }
        }

        public int AffinityLength
        {
            get { return Conversion.ToInt(_listSource.Attributes[AttAffinityLength]); }
            set
            {
                _listSource.Attributes[AttAffinityLength] = Conversion.ToString(value);
                _listDestination.Attributes[AttAffinityLength] = Conversion.ToString(value);
            }
        }

        public string AffinityString
        {
            get { return Conversion.ToString(_listSource.Attributes[AttAffinityString]); }
            set
            {
                _listSource.Attributes[AttAffinityString] = Conversion.ToString(value);
                _listDestination.Attributes[AttAffinityString] = Conversion.ToString(value);
            }
        }

        public override bool Enabled
        {
            get
            {
                return base.Enabled;
            }
            set
            {
                base.Enabled = value;
                _listSource.Enabled = value;
                _listDestination.Enabled = value;
                _l2r.Enabled = _l2rAll.Enabled = _r2l.Enabled = _r2lAll.Enabled = value;
                _ddlFind.Enabled = _txtFind.Enabled = value;
            }
        }

        public bool AutoPostBack
        {
            get { return _autoPostBack; }
            set { _autoPostBack = value; }
        }

        public bool CauseValidation
        {
            get { return _causeValidation; }
            set { _causeValidation = value; }
        }

        public int MaxSelectedItems
        {
            get { return _maxSelectedItems; }
            set { _maxSelectedItems = value; }
        }

        public bool Checkable
        {
            get { return _listDestination.Checkable; }
            set { _listDestination.Checkable = value; }
        }

        public string CheckedString
        {
            get { return _listDestination.CheckedString; ;}
            set
            {
                _listSource.CheckedString = value;
                _listDestination.CheckedString = value;
            }
        }

        public string UnCheckedString
        {
            get { return _listSource.UnCheckedString; }
            set
            {
                _listSource.UnCheckedString = value;
                _listDestination.UnCheckedString = value;
            }
        }

        /// <summary>
        /// Permet d'afficher des information suppl�mentaire sous le double listbox (def=true)
        /// </summary>
        public bool DisplayInfo
        {
            get { return _displayInfo; }
            set { _displayInfo = value; }
        }

        /// <summary>
        /// Permet d'afficher une boite de dialogue de recherche dans la liste
        /// </summary>
        public bool DisplayFind
        {
            get { return _displayFind; }
            set { _displayFind = value; }
        }

        public int MaxTextLength
        {
            get { return (_maxTextLength); }
            set { _maxTextLength = value; }
        }

        #region Resources

        public QXPResources.ResourceInfo ResourceInfo
        {
            get { return _resourceInfo; }
        }

        public string AllLeftToRightMessage
        {
            get { return Conversion.ToString(this.ViewState[VSAllLeftToRight]); }
            set { this.ViewState[VSAllLeftToRight] = value; }
        }

        public string AllRightToLeftMessage
        {
            get { return Conversion.ToString(this.ViewState[VSAllRightToLeft]); }
            set { this.ViewState[VSAllRightToLeft] = value; }
        }

        public string LabelSource
        {
            get { return _labelSource.Text; }
            set { _labelSource.Text = value; }
        }

        public string LabelDestination
        {
            get { return _labelDestination.Text; }
            set { _labelDestination.Text = value; }
        }

        public string FindLabel
        {
            get { return _labelddlFind.Text; }
            set { _labelddlFind.Text = value; }
        }

        public string FindLabelText
        {
            get { return _labeltxtFind.Text; }
            set { _labeltxtFind.Text = value; }
        }

        public string MaxSelectedMessage
        {
            get { return Conversion.ToString(this.ViewState[VSMaxSelectedMsg]); }
            set { this.ViewState[VSMaxSelectedMsg] = value; }
        }

        #endregion Resources

        public string DataValueFieldSelect
        {
            get { return _ddlFind.DataValueField; }
            set { _ddlFind.DataValueField = value; }
        }

        public string DataTextFieldSelect
        {
            get { return _ddlFind.DataTextField; }
            set { _ddlFind.DataTextField = value; }
        }

        public string DataTextFormatStringSelect
        {
            get { return _ddlFind.DataTextFormatString; }
            set { _ddlFind.DataTextFormatString = value; }
        }

        public object DataSourceSelect
        {
            get { return _ddlFind.DataSource; }
            set { _ddlFind.DataSource = value; }
        }

        public Basic.ListBox ListSource
        {
            get { return _listSource; }
        }

        public Basic.ListBox ListDestination
        {
            get { return _listDestination; }
        }

        public System.Web.UI.WebControls.ListSelectionMode SelectionMode
        {
            get { return _listSource.SelectionMode; }
            set { _listSource.SelectionMode = _listDestination.SelectionMode = value; }
        }

        /// <summary>
        /// DataTextField utilis� lors du binding
        /// </summary>
        public string DataTextField
        {
            get;
            set;
        }

        /// <summary>
        /// DataTextFormatString utilis� lors du binding
        /// </summary>
        public string DataTextFormatString
        {
            get { return _dataTextFormatString; }
            set { _dataTextFormatString = value; }
        }

        /// <summary>
        /// DataInfoField utilis� lors du binding
        /// </summary>
        public string DataInfoField
        {
            get;
            set;
        }

        /// <summary>
        /// Datasource du contr�le
        /// </summary>
        public object DataSource
        {
            get;
            set;
        }

        /// <summary>
        /// Indique si les �l�ments sont tri�s ou non
        /// </summary>
        public bool IsSorted
        {
            get;
            set;
        }

        public string[] DefaultChecked
        {
            get
            {
                return _listDestination.DefaultChecked;
            }
            set
            {
                _listDestination.DefaultChecked = value;
            }
        }

        #endregion Propri�t�s
    }
}