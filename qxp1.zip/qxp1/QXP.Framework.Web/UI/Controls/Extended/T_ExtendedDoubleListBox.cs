using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.UI.WebControls;
using QXP.Framework.Extensions;
using QXPData = QXP.Framework.Data;

namespace QXP.Framework.Web.UI.Controls.Extended
{

    /// <summary>
    /// Class T_DoubleListBox : Control web double list box
    /// </summary>
    /// <author>LCU</author>
    /// <date>10/01/2011</date>    
    public class DoubleListBox<T> : BaseExtendedDoubleListBox
        where T : new()
    {
        #region Membres

        IEnumerable<T> _defaultSelectedValuesObject;
        IEnumerable<T> _valuesForSave;

        #endregion Membres

        #region Constantes

        protected const Char ValueSeparator = '�';
        protected const String TextSeparator = ", ";
        private const string VSIndexSelectedValueField = "VSIndexSelectedValueField";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Initializes a new instance of <see cref="DoubleListBox"/> control. </summary>
        public DoubleListBox()
            : base(false)
        {
        }

        /// <summary>Initializes a new instance of <see cref="DoubleListBox"/> control. </summary>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control. </param>
        public DoubleListBox(string cssClass)
            : base(cssClass)
        {
        }

        public DoubleListBox(bool displayUpDown)
            : base(displayUpDown)
        {
        }

        public DoubleListBox(string cssClass, bool displayUpDown)
            : base(cssClass, displayUpDown)
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Lors de la cr�ations des contr�les
        /// </summary>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            if (Validation.IsNotSet(this.DataValueFields))
            {
                this.DataValueFields =
                    from property in typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance)
                    where Validation.IsPrimitiveValueType(property.PropertyType) && property.CanWrite
                    select property.Name;
            }
        }

        /// <summary>
        /// Retourne l'object correspondant aux valeurs stock�es dans la selectedValues
        /// selectedValues contient un la liste des valeurs des membres connues dans DataValueFields
        /// </summary>
        /// <param name="selectedValues">Liste des valeurs de chaque membre</param>
        /// <returns>Objet de type T</returns>
        private T GetObject(IEnumerable<string> selectedValues)
        {
            T __object = new T();
            var __properties = __object.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance).ToList();
            int __i = 0;
            selectedValues.ForEach
            (
                selectedValue => { SetValue(__object, __properties.First(p => p.Name == DataValueFields.ToList()[__i] && p.CanWrite), selectedValue); __i++; }
            );
            return __object;
        }

        /// <summary>
        /// D�finit la valeur de la propri�t� de l'objet
        /// </summary>
        /// <param name="object">Objet mis � jour</param>
        /// <param name="propertyInfo">Propri�t� � mettre � jour</param>
        /// <param name="selectedValue">Valeur de la propri�t�</param>
        private void SetValue(T Object, PropertyInfo propertyInfo, string selectedValue)
        {
            if (propertyInfo.PropertyType.IsEnum)
                propertyInfo.SetValue(Object, Conversion.ToEnum(propertyInfo.PropertyType, selectedValue), null);
            else
                propertyInfo.SetValue(Object, ConversionInvariante.ToObject(selectedValue, propertyInfo.PropertyType), null);
        }

        /// <summary>
        /// Binding du double list box
        /// </summary>
        public override void DataBind()
        {
            base.DataBind();

            if (Validation.IsNull(DataSource))
                return;

            ArrayList __selectedCheckedValues = new ArrayList();
            bool __checked = false;
            List<string> __lstDest = new List<string>();
            List<string> __lstSrc = new List<string>();
            List<ListItem> __listitemsSource = new List<ListItem>();
            List<ListItem> __listitemsDestination = new List<ListItem>();


            ArrayList __checkValues = base.GetCheckedStatus();
            //On acc�de qu'une seule fois � DefaultSelectedValues afin d'�viter d'analyser le contenu du viewstate � chaque it�ration (cf boucle suivante)
            ArrayList __defaultSelectedValues = new ArrayList(this.DefaultSelectedValues);

            foreach (T __entry in this.DataSource)
            {
                string __itemValue, __itemText, __itemInfo = string.Empty;
                string __key = Conversion.ToString(__entry);
                T __value = __entry;

                __itemText = GetDataTextField(__value);

                if (Validation.IsSet(DataValueFields))
                {
                    IEnumerable<string> __itemValues = DataValueFields.Select
                        (
                            (dataValue, index) =>
                            {
                                if (Validation.IsSet(DataSelectedValueField) && dataValue == DataSelectedValueField)
                                    this.IndexSelectedValueField = index;
                                return ConversionInvariante.ToString(QXPData.DataBinder.Eval(__value, dataValue));
                            }
                        );
                    __itemValue = string.Join(ValueSeparator.ToString(), __itemValues.ToArray());
                }
                else
                {
                    __itemValue = __key;
                }

                __itemInfo = GetDataInfoField(__value);

                if (this.Checkable)
                {
                    __checked = __checkValues.Contains(__itemValue);
                    if (__checked)
                        __selectedCheckedValues.Add(__itemValue);
                }


                if (Validation.IsSet(__defaultSelectedValues)
                    && __defaultSelectedValues.Contains(Conversion.ToString(QXPData.DataBinder.Eval(__value, DataSelectedValueField)))
                    )
                {
                    base.AddItem(__listitemsDestination, __itemValue, __itemText, __itemInfo, __checked);
                    __lstDest.Add(__itemValue);

                    //Remplit la value afin que le javascript cot� client puisse directement travailler
                    // sur cette valeur sans avoir besoin de l'initialiser en parcourant toutes les valeurs de la liste
                    string[] valueanyinfo = __itemValue.Split(InfoSeparator);
                    base._hidden.Value += string.Concat(valueanyinfo[0], CommandSeparator);
                }
                else
                {
                    this.AddItem(__listitemsSource, __itemValue, __itemText, __itemInfo, __checked);
                    __lstSrc.Add(__itemValue);
                }
            }

            SetValuesForSave(__lstSrc, __lstDest);

            base.Sort(ref __listitemsSource, ref __listitemsDestination);

            _listSource.Items.AddRange(__listitemsSource.ToArray());
            _listDestination.Items.AddRange(__listitemsDestination.ToArray());

            this.UpdateHiddenSelectedValues();

            if (this.Checkable)
                _listDestination.UpdateHiddenChecked(__selectedCheckedValues);

            _ddlFind.DataBind();

        }

        /// <summary>
        /// Retourne l'itemtext associ� � l'objet bind� en fonction de la propri�t� DataTextFields et DataTextFormatString
        /// </summary>
        /// <param name="value">Objet</param>
        /// <returns>Valeur de l'itemtext</returns>
        protected override string GetDataTextField(object value)
        {
            string __itemText = null;
            if (Validation.IsSet(DataTextFields))
            {
                IEnumerable<string> __itemTexts = DataTextFields.Select
                    (
                        dataText =>
                            Validation.IsSet(this.DataTextFormatString) ? string.Format(this.DataTextFormatString, QXPData.DataBinder.Eval(value, dataText))
                                                                        : Conversion.ToString(QXPData.DataBinder.Eval(value, dataText))
                    );
                if (Validation.IsSet(__itemTexts))
                    __itemText = string.Join(TextSeparator.ToString(), __itemTexts.Where(__item => Validation.IsSet(__item)).ToArray());
            }
            else
                __itemText = base.GetDataTextField(value);
            return __itemText;
        }

        /// <summary>
        /// Retourne l'iteminfo associ� � l'objet bind� en fonction de la propri�t� DataInfoFieldDataInfoField
        /// </summary>
        /// <param name="value">Objet</param>
        /// <returns>Valeur de l'iteminfo</returns>
        protected override string GetDataInfoField(object value)
        {
            string __itemInfo = null;
            if (Validation.IsSet(DataInfoFields))
            {
                IEnumerable<string> __itemInfos = DataInfoFields.Select(dataInfo => Conversion.ToString(QXPData.DataBinder.Eval(value, dataInfo)));
                __itemInfo = string.Join(ValuesInItemInfoSeparator.ToString(), __itemInfos.ToArray());
            }
            else
                __itemInfo = base.GetDataInfoField(value);
            return __itemInfo;
        }

        /// <summary>
        /// Retourne la liste des labels � afficher sous le s�lecteur pour afficher les informations d'un �l�ment s�lectionn�
        /// </summary>
        /// <returns>List string</returns>
        protected override List<string> GetLabelsInfo()
        {
            if (Validation.IsSet(DataInfoFields))
            {
                return DataInfoFields.Select(__dataInfoField => this.ResourceInfo.GetLabel(__dataInfoField)).ToList();
            }
            else
                return base.GetLabelsInfo();
        }

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        /// <summary>
        /// DataSource du contr�le
        /// </summary>
        public new IEnumerable<T> DataSource
        {
            get;
            set;
        }

        /// <summary>
        /// Propri�t� qui contient tous les �l�ments de la liste de droite du composant
        /// Elle est initialis�e lors du databind et modifi�e cot� client par le javascript 
        /// </summary>
        public IEnumerable<T> SelectedValuesObject
        {
            get
            {
                IEnumerable<T> __selectedValuesObject = null;
                if (Validation.IsSet(DataValueFields))
                {
                    __selectedValuesObject = from __value in base.SelectedValues
                                             where __value.Split(ValueSeparator).Count() == DataValueFields.Count()
                                             select GetObject(__value.Split(ValueSeparator).ToList());
                }
                return __selectedValuesObject;
            }
        }

        /// <summary>
        /// Propri�t� qui contient tous les �l�ments de la liste de droite du composant
        /// Elle est initialis�e lors du databind et modifi�e cot� client par le javascript 
        /// </summary>
        public override string[] SelectedValues
        {
            get
            {
                if (Validation.IsSet(base.SelectedValues))
                {
                    return base.SelectedValues.Select(__value => __value.Split(ValueSeparator)[this.IndexSelectedValueField]).ToArray();
                }
                return base.SelectedValues;
            }
        }

        /// <summary>
        /// Valeurs par d�faut � selectionner
        /// </summary>
        public IEnumerable<T> DefaultSelectedValuesObject
        {
            get
            {
                return _defaultSelectedValuesObject;
            }
            set
            {
                _defaultSelectedValuesObject = value;
                if (Validation.IsSet(_defaultSelectedValuesObject))
                    base.DefaultSelectedValues = _defaultSelectedValuesObject.Select(obj => Conversion.ToString(QXPData.DataBinder.Eval(obj, DataSelectedValueField))).ToArray();
                else
                    base.DefaultSelectedValues = null;
            }
        }

        /// <summary>
        /// Nom de la prori�t� d�finissant la cl� primaire de l'objet
        /// (Utilis� notamment pour reselectionner les valeurs du doublelistbox)
        /// </summary>
        public string DataSelectedValueField
        {
            get;
            set;
        }

        /// <summary>
        /// Liste des DataTextField � utiliser lors du binding (chaque DataTextField sera affich�e)
        /// </summary>
        public IEnumerable<string> DataTextFields
        {
            get;
            set;
        }

        /// <summary>
        /// Liste des DataInfoField � utiliser lors du binding (chaque DataInfoField sera affich�e)
        /// </summary>
        public IEnumerable<string> DataInfoFields
        {
            get;
            set;
        }

        /// <summary>
        /// Liste des datavaluefield � utiliser lors du binding (chaque datavaluefield sera m�moris�e dans la valeur de l'item)
        /// </summary>
        public IEnumerable<string> DataValueFields
        {
            get;
            set;
        }

        /// <summary>
        /// Contient les objets qui ne sont ni dans la source ni dans la destination
        /// mais seulement dans le r�sultat de la requete qui remplit le datasourceselect
        /// </summary>
        public new IEnumerable<T> ValuesForSave
        {
            get
            {
                return _valuesForSave;
            }
            set
            {
                _valuesForSave = value;
                if (Validation.IsSet(_valuesForSave))
                    base.ValuesForSave = _valuesForSave.Select(obj => Conversion.ToString(QXPData.DataBinder.Eval(obj, DataSelectedValueField))).ToArray();
                else
                    base.ValuesForSave = null;
            }
        }

        /// <summary>
        /// Position dans la value des items de la valeur correspondante � la propri�t� stock� dans DataSelectedValueField
        /// </summary>
        private int IndexSelectedValueField
        {
            get
            {
                return Conversion.ToInt(this.ViewState[VSIndexSelectedValueField]);
            }
            set
            {
                this.ViewState[VSIndexSelectedValueField] = value;
            }
        }

        #endregion Propri�t�s
    }
}