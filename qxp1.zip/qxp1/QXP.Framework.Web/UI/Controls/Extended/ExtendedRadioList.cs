using System;
using QXPApplication = QXP.Framework.Application;
using QXPFrk = QXP.Framework;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Extended
{
    /// <summary>
    /// Class RadioList : Cette classe abstraite permet de d�finir une liste de radio button pouvant �tre plac�e n'importe ou dans l'�cran
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public abstract class RadioList : WebControlTagged
    {
        #region Membres

        bool _autoPostBack = false;
        public event EventHandler SelectionChanged;
        int _defaultValue;
        string _rs;
        object _value;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de RadioList
        /// </summary>
        public RadioList()
        {
            _rs = this.GetType().Name;
        }        

        #endregion Constructeur

        #region M�thodes

        protected QXPWUIBasic.RadioButton CreationRadioButton(object value)
        {
            QXPWUIBasic.RadioButton __ctrl = new QXPWUIBasic.RadioButton();
            __ctrl.CssClass = this.GroupeName;
            __ctrl.GroupName = this.GroupeName;
            __ctrl.Value = value;
            __ctrl.AutoPostBack = _autoPostBack;
            __ctrl.Text = this.GetLabel(value);
            __ctrl.CheckedChanged += new EventHandler(this.OnSelectionChanged);
            return __ctrl;
        }
        
        protected QXPWUIBasic.Label CreationLabel(object value)
        {
            QXPWUIBasic.Label __label = new QXPWUIBasic.Label();
            __label.CssClass = this.GroupeName;
            __label.Text = this.GetLabel(value);
            return __label;
        }

        private string GetLabel(object value)
        {
            return QXPApplication.Application.Resources.GetLabel(this.RS, value);
        }

        public void InitList()
        {
            if (QXPFrk.Validation.IsNotSet(_value) && QXPFrk.Validation.IsSet(_defaultValue))
            {
                this.InitValue(_defaultValue);
            }
        }
        
        protected abstract void InitValue(int value);        

        #endregion M�thodes

        #region Evenements

        protected void OnSelectionChanged(object sender, EventArgs ea)
        {
            if (QXPFrk.Validation.IsNotNull(this.SelectionChanged))
            {
                this.SelectionChanged(sender, ea);
            }
        }

        #endregion Evenements

        #region Propri�t�s

        public bool AutoPostBack
        {
            get { return _autoPostBack; }
            set { _autoPostBack = value; }
        }

        public int DefaultValue
        {
            get { return _defaultValue; }
            set { _defaultValue = value; }
        }

        protected abstract string GroupeName
        {
            get;
        }

        protected string RS
        {
            get { return _rs; }
        }

        public virtual object Value
        {
            get { return _value; }
            set { _value = value; }
        }

        #endregion Propri�t�s
    }

			
}
