using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Reflection;
using System.Web.UI.WebControls;
using QXPData = QXP.Framework.Data;

namespace QXP.Framework.Web.UI.Controls.Extended
{
    /// <summary>
    /// Class DoubleListBox : Control web double list box
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class DoubleListBox : BaseExtendedDoubleListBox
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Initializes a new instance of <see cref="BaseExtendedDoubleListBox"/> control. 
        /// </summary>
        public DoubleListBox()
            : base(false)
        {
        }

        /// <summary>
        /// Initializes a new instance of <see cref="BaseExtendedDoubleListBox"/> control.
        /// </summary>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control.</param>
        public DoubleListBox(string cssClass)
            : base(cssClass)
        {
        }

        /// <summary>
        /// Initializes a new instance of <see cref="BaseExtendedDoubleListBox"/> control.
        /// </summary>
        /// <param name="displayUpDown">Affiche ou non les boutons Up et Down</param>
        public DoubleListBox(bool displayUpDown)
            : base(displayUpDown)
        {
        }

        /// <summary>
        /// Initializes a new instance of <see cref="BaseExtendedDoubleListBox"/> control.
        /// </summary>
        /// <param name="cssClass">The cascading style sheet (CSS) used to render control.</param>
        /// <param name="displayUpDown">Affiche ou non les boutons Up et Down</param>
        public DoubleListBox(string cssClass, bool displayUpDown)
            : base(cssClass, displayUpDown)
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// D�finit les �l�ments d�sactiv�s dans la liste source et destination
        /// </summary>
        /// <param name="lstSrc">Elements de la List source</param>
        /// <param name="lstDest">Elements de la List destination</param>
        protected void SetElementBlocked(List<ListItem> lstSrc, List<ListItem> lstDest)
        {
            //Si il y a des elements dans notre liste
            if (Validation.IsNotNull(this.IsBlocked))
            {
                //On regarde si dans notre liste il y a des elements pr�sent dans notre liste � bloquer
                foreach (ListItem item in lstDest)
                {
                    foreach (string itemBlocked in this.IsBlocked)
                    {
                        if (item.Value == itemBlocked)
                        {
                            //permet au code javascript de distinguer les elements bloqu�s
                            item.Attributes.Add("style", "color:lightslategray");
                        }
                    }
                }

                //On regarde si dans notre liste il y a des elements pr�sent dans notre liste � bloquer
                foreach (ListItem item in lstSrc)
                {
                    foreach (string itemBlocked in this.IsBlocked)
                    {
                        //permet au code javascript de distinguer les elements bloqu�s
                        if (item.Value == itemBlocked)
                        {
                            item.Attributes.Add("style", "color:lightslategray");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Binding du double list box
        /// </summary>
        public override void DataBind()
        {
            base.DataBind();

            object __dataSource;

            if (Validation.IsSet(this.DataMember))
            {
                __dataSource = QXPData.DataSourceResolver.GetResolvedDataSource(this.DataSource, this.DataMember);
            }
            else
            {
                __dataSource = DataSource;
            }

            IEnumerable __iEnumerable = __dataSource as IEnumerable;

            if (Validation.IsNull(__iEnumerable))
                return;

            ArrayList __selectedCheckedValues = new ArrayList();
            bool __checked = false;
            List<string> __lstDest = new List<string>();
            List<string> __lstSrc = new List<string>();
            List<ListItem> __listitemsSource = new List<ListItem>();
            List<ListItem> __listitemsDestination = new List<ListItem>();
            DataSourceType __dataSourceType = DataSourceType.Unknown;
            PropertyInfo __indexer = null;
            int __arrayRank = 1;
            int __arrayRankLength = 1;


            ArrayList __checkValues = base.GetCheckedStatus();
            //On acc�de qu'une seule fois � DefaultSelectedValues afin d'�viter d'analyser le contenu du viewstate � chaque it�ration (cf boucle suivante)
            ArrayList __defaultSelectedValues = new ArrayList(this.DefaultSelectedValues);
            IEnumerator __iEnumerator = __iEnumerable.GetEnumerator();

            try
            {

                if (__dataSource is NameObjectCollectionBase)
                {
                    __dataSourceType = DataSourceType.NameValueCollection;
                    __indexer = __dataSource.GetType().GetProperty("Item", ValueType.ArrayOf1String);
                }
                else if (__dataSource is IDictionary)
                {
                    __dataSourceType = DataSourceType.Dictionary;
                }
                else if (__dataSource is Array)
                {
                    __dataSourceType = DataSourceType.Array;
                    __arrayRank = ((Array)__dataSource).Rank;
                    if (__arrayRank > 1)
                    {
                        __arrayRankLength = ((Array)__dataSource).GetLength(__arrayRank - 1);
                    }
                }
                else
                {
                    if (__iEnumerator is IDictionaryEnumerator)
                        __dataSourceType = DataSourceType.Dictionary;
                }

                while (__iEnumerator.MoveNext())
                {
                    string __itemValue, __itemText, __itemInfo = string.Empty;
                    string __key, __info = null;
                    object __entry = __iEnumerator.Current;
                    object __value = null;
                    switch (__dataSourceType)
                    {
                        case DataSourceType.NameValueCollection:
                            __key = Conversion.ToString(__entry);
                            __value = QXPData.DataBinder.GetIndexedValue(__indexer, __dataSource, __key);
                            break;
                        case DataSourceType.Dictionary:
                            DictionaryEntry __dictionaryEntry = (DictionaryEntry)__entry;
                            __key = Conversion.ToString(__dictionaryEntry.Key);
                            __value = __dictionaryEntry.Value;
                            break;
                        case DataSourceType.Array:
                            __key = Conversion.ToString(__entry);
                            if (__arrayRankLength >= 2)
                            {
                                __iEnumerator.MoveNext();
                                __value = __iEnumerator.Current;
                                if (__arrayRankLength == 3)
                                {
                                    __iEnumerator.MoveNext();
                                    __info = Conversion.ToString(__iEnumerator.Current);
                                }
                            }
                            else
                            {
                                __value = __iEnumerator.Current;
                            }
                            break;
                        default:
                            __key = Conversion.ToString(__entry);
                            __value = __entry;
                            break;
                    }

                    __itemText = GetDataTextField(__value);

                    //DataValueField
                    if (Validation.IsSet(DataValueField))
                    {
                        __itemValue = Conversion.ToString(QXPData.DataBinder.Eval(__value, DataValueField, null));
                    }
                    else
                    {
                        __itemValue = __key;
                    }

                    if (Validation.IsNotSet(__info))
                        __itemInfo = GetDataInfoField(__value);
                    else
                        __itemInfo = __info;

                    if (this.Checkable)
                    {
                        __checked = __checkValues.Contains(__itemValue);
                        if (__checked)
                            __selectedCheckedValues.Add(__itemValue);
                    }


                    if (__defaultSelectedValues.Contains(__itemValue))
                    {
                        base.AddItem(__listitemsDestination, __itemValue, __itemText, __itemInfo, __checked);
                        __lstDest.Add(__itemValue);

                        //Remplit la value afin que le javascript cot� client puisse directement travailler
                        // sur cette valeur sans avoir besoin de l'initialiser en parcourant toutes les valeurs de la liste
                        string[] valueanyinfo = __itemValue.Split(InfoSeparator);
                        base._hidden.Value += string.Concat(valueanyinfo[0], CommandSeparator);
                    }
                    else
                    {
                        this.AddItem(__listitemsSource, __itemValue, __itemText, __itemInfo, __checked);
                        __lstSrc.Add(__itemValue);
                    }
                }

                SetValuesForSave(__lstSrc, __lstDest);

                base.Sort(ref __listitemsSource, ref __listitemsDestination);

                SetElementBlocked(__listitemsSource, __listitemsDestination);

                _listSource.Items.AddRange(__listitemsSource.ToArray());
                _listDestination.Items.AddRange(__listitemsDestination.ToArray());

                this.UpdateHiddenSelectedValues();

                if (this.Checkable)
                    _listDestination.UpdateHiddenChecked(__selectedCheckedValues);

                _ddlFind.DataBind();
            }
            catch (Exception)
            {
            }
            finally
            {
                IDisposable __iDisposable = __iEnumerator as IDisposable;
                if (Validation.IsNotNull(__iDisposable)) __iDisposable.Dispose();
            }
        }

        /// <summary>
        /// Retourne la liste des labels � afficher sous le s�lecteur pour afficher les informations d'un �l�ment s�lectionn�
        /// </summary>
        /// <returns>List string</returns>
        protected override List<string> GetLabelsInfo()
        {
            if (Validation.IsNotNull(_ddlFind))
            {
                return (from __listItem in  _ddlFind.Items.Cast<ListItem>()
                       where __listItem.Value!= _ddlFind.EmptyValue
                       select __listItem.Text).ToList();
            }
            else
                return base.GetLabelsInfo();
        }

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        /// <summary>
        /// DataMember associ� � la datasource
        /// </summary>
        public string DataMember
        {
            get;
            set;
        }

        /// <summary>
        /// Propri�t� qui contient tous les �l�ments de la liste de droite du composant
        /// Elle est initialis�e lors du databind et modifi�e cot� client par le javascript 
        /// </summary>
        public new string[] SelectedValues
        {
            get
            {
                return base.SelectedValues;
            }
        }

        /// <summary>
        /// Contient tous les elements qui seront bloqu�s si ils  apparaissent dans une des deux listbox
        /// </summary>
        protected string[] IsBlocked
        {
            get;
            set;
        }

        /// <summary>
        /// Propri�t� qui contient tous les �l�ments de la liste de droite du composant
        /// Elle est initialis�e lors du databind et modifi�e cot� client par le javascript 
        /// </summary>
        public BaseList<string> SelectedValuesList
        {
            get
            {
                return new BaseList<string>(this.SelectedValues);
            }
        }

        public string[] CheckedValues
        {
            get
            {
                return _listDestination.CheckedValues;
            }
            set
            {
                _listDestination.CheckedValues = value;
            }
        }

        /// <summary>
        /// DataValueField utilis� lors du binding
        /// </summary>
        public string DataValueField
        {
            get;
            set;
        }

        #endregion Propri�t�s
    }
}