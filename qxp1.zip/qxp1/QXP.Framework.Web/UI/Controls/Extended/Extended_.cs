using System;

namespace QXP.Framework.Web.UI.Controls.Extended
{
    /// <summary>Represents the cascading style sheet of the extended control. </summary>
    public enum CssClass
    {
        /// <summary>DoubleListBox list CSS class. </summary>
        dbllstbx,
        /// <summary>DoubleListBox Column source CSS class. </summary>
        dbllstbx_colsrc,
        /// <summary>DoubleListBox Column separator CSS class. </summary>
        dbllstbx_colsep,
        /// <summary>DoubleListBox Column destination CSS class. </summary>
        dbllstbx_coldst,
        /// <summary>DoubleListBox Find ddl CSS class. </summary>
        dbllstbx_fndddl,
        /// <summary>DoubleListBox Find textbox CSS class. </summary>
        dbllstbx_fndtbx,
        /// <summary>DoubleListBox Label Find ddl CSS class. </summary>
        dbllstbx_lblfndddl,
        /// <summary>DoubleListBox Label Find textbox CSS class. </summary>
        dbllstbx_lblfndtbx,
        /// <summary>DoubleListBox buttons CSS class. </summary>
        dbllstbx_btns,
        /// <summary>DoubleListBox buttons table CSS class. </summary>
        dbllstbx_btnstbl,
        /// <summary>DoubleListBox Infos CSS class. </summary>
        dbllstbx_nfo,
        /// <summary>DoubleListBox Label List Source CSS class. </summary>
        dbllstbx_lbllstSource,
        /// <summary>DoubleListBox Label List Destination CSS class. </summary>
        dbllstbx_lbllstDestination,
        /// <summary>DoubleListBox List Source CSS class. </summary>
        dbllstbx_lstSource,
        /// <summary>DoubleListBox List Destination CSS class. </summary>
        dbllstbx_lstDestination,
        /// <summary>DoubleListBox TD info label CSS class. </summary>
        dbllstbx_nfolbl,
        /// <summary>DoubleListBox TD info value CSS class. </summary>
        dbllstbx_nfovalue,
        /// <summary>DoubleListBox info value CSS class. </summary>
        dbllstbx_nfovaluelbl,
        /// <summary>DoubleListBox top/up/down/bottom buttons main cell CSS class. </summary>
        dbllstbx_btnstopupdownbottom,
        /// <summary>DoubleListBox Left to Right CSS class. </summary>
        l2r,
        /// <summary>DoubleListBox Left to Right all CSS class. </summary>
        l2rAll,
        /// <summary>DoubleListBox Right to Left CSS class. </summary>
        r2l,
        /// <summary>DoubleListBox Right to Left all CSS class. </summary>
        r2lAll,
        /// <summary>DoubleListBox move top button CSS class. </summary>
        move_top,
        /// <summary>DoubleListBox move up button CSS class. </summary>
        move_up,
        /// <summary>DoubleListBox move down button CSS class. </summary>
        move_down,
        /// <summary>DoubleListBox move bottom button CSS class. </summary>
        move_bottom,
    }
    /// <summary>Contains the <see cref="Type"/> of the extended controls. </summary>
    public class ExtendedType
    {
        /// <summary>Represents a <see cref="DoubleListBox"/> type. </summary>
        public static readonly Type DoubleListBox = typeof(Extended.DoubleListBox);
        private ExtendedType() { }
    }
}