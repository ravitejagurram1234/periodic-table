using System;

using QXPWUIBasic									= QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Composite
{
	/// <summary>Provides methods	and properties for a labeled <see cref="QXPWUIBasic.CheckBox"/> control. <seealso cref="BaseComposite"/></summary>
	public class CheckBox: BaseComposite{
		#region Construtors
		/// <summary>Creates a new instance of <see cref="CheckBox"/> control. </summary>
		public CheckBox(): base(QXPWUIBasic.BasicType.CheckBox, Composite.CssClass.cps_chk.ToString()){
			this.DataType						= ValueType.CLSboolean;
			this.Feature.TextAlign	= System.Web.UI.WebControls.TextAlign.Right;
		}
		/// <summary>Creates a new instance of <see cref="CheckBox"/> control with the specified <paramref name="labelText"/> text. </summary>
		/// <param name="labelText">The text label of the checkbox. </param>
		public CheckBox(string labelText): this(){
			if(Validation.IsSet(labelText)) this.Label				= labelText; 
		}
		/// <summary>Creates a new instance of <see cref="CheckBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="isRequired"/>. </summary>
		/// <param name="labelText">The text label of the checkbox. </param>
		/// <param name="readOnly"><see langword="true"/> if the checbox is readonly otherwise <see langword="false"/>. </param>
		public CheckBox(string labelText, bool readOnly): this(labelText){
			this.ReadOnly				= readOnly;
		}
		/// <summary>Creates a new instance of <see cref="CheckBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>. </summary>
		/// <param name="labelText">The text label of the checkbox. </param>
		/// <param name="readOnly"><see langword="true"/> if the checbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the checkbox. </param>
		public CheckBox(string labelText, bool readOnly, object defaultValue): this(labelText, readOnly){
			this.DefaultValue		= defaultValue;
		}
		#endregion
		/// <summary>Gets or sets the data of the <see cref="CheckBox"/>. </summary>
		protected   override	object				    FeatureData{
			get{return this.Feature.Checked;}
			set{this.Feature.Checked = Conversion.ToBool(value);}
		}
		/// <summary>Gets the <see cref="QXPWUIBasic.CheckBox"/> Feature control in the <c>Feature Zone</c>. </summary>
		public	    new         QXPWUIBasic.CheckBox	Feature{
			get{return (QXPWUIBasic.CheckBox)base._feature;}
		}
		/// <summary>Gets or sets if <see cref="CheckBox"/> change generated a post back event. </summary>
		public				    bool	                AutoPostBack{
			get{return this.Feature.AutoPostBack;}
			set{this.Feature.AutoPostBack = value;}
		}
		/// <summary>Gets or sets if <see cref="CheckBox"/> change generated a post back event. </summary>
		public							bool			AutoCallBack{
			get{return this.Feature.AutoCallBack;}
			set{this.Feature.AutoCallBack = value;}
		}
        /// <summary>Gets or sets if the control raise callback event (otherwise it raise postback event). </summary>
		public bool										EnableCallBack{
			get{return this.Feature.EnableCallBack;}
			set{this.Feature.EnableCallBack = value;}
		}
        public      bool                                CauseValidation{
            get{return this.Feature.CausesValidation;}
            set{this.Feature.CausesValidation = value;}
        }
        /// <summary>Gets the localized text representation of the <see cref="Data"/> value. </summary>
		public		override	string		            Text
		{
			get
			{
				return (this.Feature.Checked)?"Yes":"No";
			}
		}
		/// <summary>Occurs when the check box value change. </summary>
		public		event		EventHandler    	    CheckedChanged
		{
			add{this.Feature.CheckedChanged			+= value;}
			remove{this.Feature.CheckedChanged	-= value;}
		}
	}
}
