using System;
using System.Web.UI.WebControls;

using QXPWUIBasic									= QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Composite
{
	/// <summary>Provides methods	and properties for a labeled <see cref="QXPWUIBasic.TextBox"/> control. <seealso cref="BaseComposite"/></summary>
	public class TextBox: BaseComposite{
		#region internal variables
		#endregion
		#region Construtors
		/// <summary>Creates a new instance of <see cref="TextBox"/> control. </summary>
		public TextBox(): base(QXPWUIBasic.BasicType.TextBox, Composite.CssClass.cps_tbx.ToString()){}
		/// <summary>Creates a new instance of <see cref="TextBox"/> class with a <paramref name="type"/> data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		public TextBox(Type type): this(){
			this.DataType = type;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		public TextBox(System.Type type, string labelText): this(type){
			if(Validation.IsSet(labelText)) this.Label				= labelText; 
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text and <paramref name="readOnly"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		public TextBox(System.Type type, string labelText, bool readOnly): this(type, labelText){
			this.ReadOnly = readOnly;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="columns"/> number, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, int columns): this(type, labelText, readOnly){
			this.Columns = columns;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number and <paramref name="isRequired"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, int columns, bool isRequired): this(type, labelText, readOnly, columns){
			this.IsRequired = isRequired;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, int columns, bool isRequired, object defaultValue): this(type, labelText, readOnly, columns, isRequired){
			this.DefaultValue = defaultValue;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number and <paramref name="rows"/> number, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="rows">The <see cref="Int32"/> number of textbox lines. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, int columns, int rows): this(type, labelText, readOnly, columns){
			this.Rows = rows;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number, <paramref name="rows"/> and <paramref name="isRequired"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="rows">The <see cref="Int32"/> number of textbox lines. </param>
		/// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, int columns, int rows, bool isRequired): this(type, labelText, readOnly, columns, rows){
			this.IsRequired = isRequired;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number, <paramref name="rows"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="rows">The <see cref="Int32"/> number of textbox lines. </param>
		/// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, int columns, int rows, bool isRequired, object defaultValue): this(type, labelText, readOnly, columns, rows, isRequired){
			this.DefaultValue = defaultValue;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, object defaultValue): this(type, labelText, readOnly){
			this.DefaultValue = defaultValue;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="isRequired"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, bool isRequired): this(type, labelText, readOnly){
			this.IsRequired = isRequired;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, bool isRequired, object defaultValue): this(type, labelText, readOnly, isRequired){
			this.DefaultValue = defaultValue;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="isRequired"/> and <paramref name="maxLength"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
		/// <param name="maxLength">The <see cref="Int32"/> maximum number of characteres allowed int the textbox. </param>
		public TextBox(System.Type type, string labelText, bool readOnly, bool isRequired, int maxLength): this(type, labelText, readOnly, isRequired){
			this.MaxLength = maxLength;
		}
		#endregion
		/// <summary>Gets or sets the data of the <see cref="TextBox"/>. </summary>
		protected override object						FeatureData{
			get{return this.Feature.Text;}
			set{this.Feature.Text = Conversion.ToString(value, this.Format);}
		}
		public		new QXPWUIBasic.TextBox		Feature{
			get{return (QXPWUIBasic.TextBox)base._feature;}
		}
		/// <summary>Gets the text of the <see cref="Data"/> value. </summary>
		public		override		string				Text{
			get{return this.Feature.Text;}
		}
		/// <summary>Gets or sets if <see cref="TextBox"/> change generated a post back event. </summary>
		public								bool			AutoPostBack{
			get{return this.Feature.AutoPostBack;}
			set{this.Feature.AutoPostBack = value;}
		}
		/// <summary>Gets or sets if <see cref="TextBox"/> change generated a call back event. </summary>
		public								bool			AutoCallBack{
			get{return this.Feature.AutoCallBack;}
			set{this.Feature.AutoCallBack = value;}
		}
        /// <summary>Gets or sets if the control raise callback event (otherwise it raise postback event). </summary>
		public bool											EnableCallBack{
			get{return this.Feature.EnableCallBack;}
			set{this.Feature.EnableCallBack = value;}
		}
		#region Feature Properties
		/// <summary>Gets or sets the display width of the text box in characters. </summary>
		public		int										Columns{
			get{return this.Feature.Columns;}
			set{this.Feature.Columns = value;}
		}
		/// <summary>Gets or sets the display height of a multiline text box. </summary>
		public		int										Rows{
			get{return this.Feature.Rows;}
			set{this.Feature.Rows = value;}
		}
		/// <summary>Gets or sets the maximum number of characters allowed in the text box. </summary>
		public		int										MaxLength{
			get{return this.Feature.MaxLength;}
			set{this.Feature.MaxLength = value;}
		}
		/// <summary>Determines whether current textbox if in hidden mode. </summary>
		public		bool									IsTextHidden{
			get{return this.Feature.IsTextHidden;}
			set{this.Feature.IsTextHidden = value;}
		}
		/// <summary>Determines whether current textbox is in multiline mode. </summary>
		public		bool									IsMultiLineText{
			get{return(this.Feature.TextMode == TextBoxMode.MultiLine);}
			set{this.Feature.TextMode = value?TextBoxMode.MultiLine:TextBoxMode.SingleLine;}
		}
		#endregion
		/// <summary>Occurs when the content of the text box is changed. </summary>
		public		event System.EventHandler TextChanged{
			add{Feature.TextChanged += value;}
			remove{Feature.TextChanged -= value;}
		}
	}
}
