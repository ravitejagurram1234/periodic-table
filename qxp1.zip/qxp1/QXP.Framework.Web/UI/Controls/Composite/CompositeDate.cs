using System;
using System.Web.UI;

using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>
    /// Class Date : Provides methods	and properties for a labeled <see cref="QXPWUIBasic.TextBox"/> control. <seealso cref="BaseComposite"/>
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class Date : BaseComposite
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new instance of <see cref="Date"/> control. </summary>
        public Date()
            : base(QXPWUIBasic.BasicType.Date, Composite.CssClass.cps_dt.ToString())
        {
            this.DataType = ValueType.DateTime;
            this.Format = "d";
        }

        /// <summary>Creates a new instance of <see cref="Date"/> control with the specified <paramref name="labelText"/> text, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="labelText">The text label of the text box. </param>
        public Date(string labelText)
            : this()
        {
            if (Validation.IsSet(labelText)) this.Label = labelText;
        }

        /// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text and <paramref name="readOnly"/>, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="labelText">The text label of the text box. </param>
        /// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
        public Date(string labelText, bool readOnly)
            : this(labelText)
        {
            this.ReadOnly = readOnly;
        }

        /// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number and <paramref name="isRequired"/>, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="labelText">The text label of the text box. </param>
        /// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
        /// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
        public Date(string labelText, bool readOnly, bool isRequired)
            : this(labelText, readOnly)
        {
            this.IsRequired = isRequired;
        }

        /// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="labelText">The text label of the text box. </param>
        /// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
        /// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
        /// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
        public Date(string labelText, bool readOnly, bool isRequired, object defaultValue)
            : this(labelText, readOnly, isRequired)
        {
            this.DefaultValue = defaultValue;
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        /// <summary>Gets or sets the data of the <see cref="Date"/>. </summary>
        protected override object FeatureData
        {
            get { return this.Feature.SelectedDate; }
            set { this.Feature.SelectedDate = Conversion.ToString(value, this.Format); }
        }

        protected override string MinVal
        {
            get { return Conversion.ToString(this.MinValue, this.Format); }
        }

        protected override string MaxVal
        {
            get { return Conversion.ToString(this.MaxValue, this.Format); }
        }

        public new QXPWUIBasic.Date Feature
        {
            get { return (QXPWUIBasic.Date)base._feature; }
        }

        public override Control FeatureToValidate
        {
            get { return this.Feature._txtBox; }
        }

        /// <summary>Gets the text of the <see cref="Data"/> value. </summary>
        public override string Text
        {
            get { return this.Feature.SelectedDate; }
        }

        /// <summary>Gets or sets if <see cref="TextBox"/> change generated a post back event. </summary>
        public bool AutoPostBack
        {
            get { return this.Feature.AutoPostBack; }
            set { this.Feature.AutoPostBack = value; }
        }

        /// <summary>Gets or sets if <see cref="CheckBox"/> change generated a post back event. </summary>
        public bool AutoCallBack
        {
            get { return this.Feature.AutoCallBack; }
            set { this.Feature.AutoCallBack = value; }
        }

        /// <summary>Gets or sets if the control raise callback event (otherwise it raise postback event). </summary>
        public bool EnableCallBack
        {
            get { return this.Feature.EnableCallBack; }
            set { this.Feature.EnableCallBack = value; }
        }

        /// <summary>Occurs when the date is changed. </summary>
        public event System.EventHandler DateChanged
        {
            add { Feature.DateChanged += value; }
            remove { Feature.DateChanged -= value; }
        }

        /// <summary>
        /// Type d'ajaxisation
        /// </summary>
        public Anthem.AjaxMode AjaxMode
        {
            get { return this.Feature.AjaxMode; }
            set { this.Feature.AjaxMode = value; }
        }

        #endregion Propri�t�s
    }

			
}
