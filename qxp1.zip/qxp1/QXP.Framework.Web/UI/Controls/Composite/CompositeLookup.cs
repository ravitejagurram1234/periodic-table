using System;
using System.Collections;
using System.Collections.Specialized;
using System.Web.UI;
using System.Web.UI.WebControls;


using QXPWUIBasic									= QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Composite
{
	/// <summary>Provides methods	and properties for a labeled <see cref="QXPWUIBasic.TextBox"/> control. <seealso cref="BaseComposite"/></summary>
	public class Lookup: BaseComposite{
		#region internal variables
		#endregion
		#region Construtors
		/// <summary>Creates a new instance of <see cref="TextBox"/> control. </summary>
		public Lookup(): base(QXPWUIBasic.BasicType.Lookup, Composite.CssClass.cps_lkp.ToString()){}
		/// <summary>Creates a new instance of <see cref="Lookup"/> class with a <paramref name="type"/> data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		public Lookup(Type type): this(){
			this.DataType = type;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		public Lookup(System.Type type, string labelText): this(type){
			if(Validation.IsSet(labelText)) this.Label				= labelText; 
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text and <paramref name="readOnly"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		public Lookup(System.Type type, string labelText, bool readOnly): this(type, labelText){
			this.ReadOnly = readOnly;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="columns"/> number, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, int columns): this(type, labelText, readOnly){
			this.Columns = columns;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number and <paramref name="isRequired"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="isRequired"><see langword="true"/> if the Lookup is required otherwise <see langword="false"/>. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, int columns, bool isRequired): this(type, labelText, readOnly, columns){
			this.IsRequired = isRequired;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="isRequired"><see langword="true"/> if the Lookup is required otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, int columns, bool isRequired, object defaultValue): this(type, labelText, readOnly, columns, isRequired){
			this.DefaultValue = defaultValue;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number and <paramref name="rows"/> number, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="rows">The <see cref="Int32"/> number of Lookup lines. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, int columns, int rows): this(type, labelText, readOnly, columns){
			this.Rows = rows;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number, <paramref name="rows"/> and <paramref name="isRequired"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="rows">The <see cref="Int32"/> number of Lookup lines. </param>
		/// <param name="isRequired"><see langword="true"/> if the Lookup is required otherwise <see langword="false"/>. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, int columns, int rows, bool isRequired): this(type, labelText, readOnly, columns, rows){
			this.IsRequired = isRequired;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number, <paramref name="rows"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="columns">The <see cref="Int32"/> display width of the text box in characters. </param>
		/// <param name="rows">The <see cref="Int32"/> number of Lookup lines. </param>
		/// <param name="isRequired"><see langword="true"/> if the Lookup is required otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, int columns, int rows, bool isRequired, object defaultValue): this(type, labelText, readOnly, columns, rows, isRequired){
			this.DefaultValue = defaultValue;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, object defaultValue): this(type, labelText, readOnly){
			this.DefaultValue = defaultValue;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="isRequired"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the Lookup is required otherwise <see langword="false"/>. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, bool isRequired): this(type, labelText, readOnly){
			this.IsRequired = isRequired;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the Lookup is required otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, bool isRequired, object defaultValue): this(type, labelText, readOnly, isRequired){
			this.DefaultValue = defaultValue;
		}
		/// <summary>Creates a new instance of <see cref="Lookup"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="isRequired"/> and <paramref name="maxLength"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the Lookup is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the Lookup is required otherwise <see langword="false"/>. </param>
		/// <param name="maxLength">The <see cref="Int32"/> maximum number of characteres allowed int the Lookup. </param>
		public Lookup(System.Type type, string labelText, bool readOnly, bool isRequired, int maxLength): this(type, labelText, readOnly, isRequired){
			this.MaxLength = maxLength;
		}
		#endregion
		protected override	void				OnInit(EventArgs ea)
		{
			base.OnInit(ea);
		}
		/// <summary>Gets or sets the data of the <see cref="Lookup"/>. </summary>
		protected override object				FeatureData
		{
			get{return this.Feature.Text;}
			set{this.Feature.Text = Conversion.ToString(value, this.Format);}
		}
		public		new QXPWUIBasic.Lookup		Feature{
			get{return (QXPWUIBasic.Lookup)base._feature;}
		}

		public		override	Control			FeatureToValidate
		{
			get{return this.Feature._txtBox;}
		}

		/// <summary>Gets the text of the <see cref="Data"/> value. </summary>
		public		override		string		Text
		{
			get{return this.Feature.Text;}
		}
		#region Feature Properties
		/// <summary>Gets or sets if <see cref="Lookup"/> change generated a post back event. </summary>
		public						bool			AutoPostBack{
			get{return this.Feature.AutoPostBack;}
			set{this.Feature.AutoPostBack = value;}
		}
		/// <summary>Gets or sets if <see cref="Lookup"/> change generated a call back event. </summary>
		public							bool		AutoCallBack{
			get{return this.Feature.AutoCallBack;}
			set{this.Feature.AutoCallBack = value;}
		}
        /// <summary>Gets or sets if the control raise callback event (otherwise it raise postback event). </summary>
		public bool									EnableCallBack{
			get{return this.Feature.EnableCallBack;}
			set{this.Feature.EnableCallBack = value;}
		}
        public      bool                            CauseValidation{
            get{return this.Feature.CausesValidation;}
            set{this.Feature.CausesValidation = value;}
        }
		/// <summary>Gets or sets the display width of the text box in characters. </summary>
		public		int								Columns{
			get{return this.Feature.Columns;}
			set{this.Feature.Columns = value;}
		}
		public		int								Rows
		{
			get{return this.Feature.Rows;}
			set{this.Feature.Rows = value;}
		}
		/// <summary>Gets or sets the maximum number of characters allowed in the text box. </summary>
		public		int								MaxLength{
			get{return this.Feature.MaxLength;}
			set{this.Feature.MaxLength = value;}
		}

		public							string		M
		{
			get{return this.Feature.M;}
			set{this.Feature.M = value;}
		}
		public							string		P
		{
			get{return this.Feature.P;}
			set{this.Feature.P = value;}
		}
		public							int			WindowWidth
		{
			get{return this.Feature.WindowWidth;}
			set{this.Feature.WindowWidth = value;}
		}

		public							int			WindowHeight
		{
			get{return this.Feature.WindowHeight;}
			set{this.Feature.WindowHeight = value;}
		}
		public							bool		WindowResizable
		{
			get{return this.Feature.WindowResizable;}
			set{this.Feature.WindowResizable = value;}
		}
		public							string		LookupWindowName
		{
			get{return this.Feature.LookupWindowName;}
			set{this.Feature.LookupWindowName = value;}
		}
		public							bool		WindowScrollable
		{
			get{return this.WindowScrollable;}
			set{this.WindowScrollable = value;}
		}
		public							Hashtable	ExtraParameters
		{
			get{return this.Feature.ExtraParameters;}
		}

		public							NameValueCollection	StaticParameters
		{
			get{return this.Feature.StaticParameters;}
		}

		#endregion
		/// <summary>Occurs when the content of the text box is changed. </summary>
		public		event System.EventHandler	TextChanged
		{
			add{Feature.TextChanged += value;}
			remove{Feature.TextChanged -= value;}
		}
	}
}
