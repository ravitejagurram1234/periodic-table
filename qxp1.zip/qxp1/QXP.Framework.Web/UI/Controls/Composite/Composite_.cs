using System;

namespace QXP.Framework.Web.UI.Controls.Composite{
	/// <summary>Contains the <see cref="Type"/> of the composite controls. </summary>
	public class CompositeType{
//		/// <summary>Represents a <see cref="CheckBox"/> type. </summary>
//		public static readonly Type CheckBox						= typeof(QXP.Framework.Web.UI.Controls.Composite.CheckBox);
//		/// <summary>Represents a <see cref="DropDownList"/> type. </summary>
//		public static readonly Type DropDownList				= typeof(QXP.Framework.Web.UI.Controls.Composite.DropDownList);
//		/// <summary>Represents a <see cref="Label"/> type. </summary>
//		public static readonly Type Label								= typeof(QXP.Framework.Web.UI.Controls.Composite.Label);
//		/// <summary>Represents a <see cref="TextBox"/> type. </summary>
//		public static readonly Type TextBox							= typeof(QXP.Framework.Web.UI.Controls.Composite.TextBox);
//		/// <summary>Represents a <see cref="Date"/> type. </summary>
//		public static readonly Type Date								= typeof(QXP.Framework.Web.UI.Controls.Composite.Date);
		private CompositeType(){}
	}
	/// <summary>Defines CSS class elements for a composite control. </summary>
	public enum		CssClass{
		/// <summary>composite CSS class. </summary>
		cps_,
		/// <summary>Checkbox CSS class. </summary>
		cps_chk,
		/// <summary>Dropdown list CSS class. </summary>
		cps_ddl,
		/// <summary>RadioButton list CSS class. </summary>
		cps_rdlst,
		/// <summary>Textbox CSS class. </summary>
		cps_tbx,
		/// <summary>Lookup CSS class. </summary>
		cps_lkp,
		/// <summary>RegularTextbox CSS class. </summary>
		cps_rgltbx,
		/// <summary>Date CSS class. </summary>
		cps_dt,
		/// <summary>Label CSS class. </summary>
		cps_lbl,
		/// <summary>ListBox list CSS class. </summary>
		cps_lstbx,
		/// <summary>FileUpload CSS class. </summary>
		cps_flpld,
        /// <summary>CheckBox list CSS class.</summary>
        cps_chklst,
		/// <summary>Zone Label TableCell CSS class. </summary>
		zn_lbl,
		/// <summary>Zone Feature TableCell CSS class. </summary>
		zn_ftr,
		/// <summary>Zone Validator TableCell CSS class. </summary>
		zn_vld,
		/// <summary>Range control CSS class. </summary>
		rg_,
		/// <summary>Range date control CSS class. </summary>
		rg_dt,
		/// <summary>Range textbox control CSS class. </summary>
		rg_tbx,
		/// <summary>Zone Label min range control TableCell CSS class. </summary>
		zn_lbl_min,
		/// <summary>Zone Label max range control TableCell CSS class. </summary>
		zn_lbl_max,
		/// <summary>Zone Feature min range control TableCell CSS class. </summary>
		zn_ftr_min,
		/// <summary>Zone Feature max range control TableCell CSS class. </summary>
		zn_ftr_max,
		/// <summary>Zone Validator min range control TableCell CSS class. </summary>
		zn_vld_min,
		/// <summary>Zone Validator max range control TableCell CSS class. </summary>
		zn_vld_max,
	}
	/// <summary>Contains common regular expression type. </summary>
	public enum RegularExpressionType
	{
		/// <summary>Represents a custom regular expression. </summary>
		Custom,
		/// <summary>Represents an email regular expression. </summary>
		Email,
		/// <summary>Represents a password complexity regular expression. </summary>
		Password,
		/// <summary>Represents an ip address expression. </summary>
		IPAddress,
		/// <summary>Represents an url expression. </summary>
		URL,
	}
	public enum RangeControls{
		ControlOfMin,
		ControlOfMax
	}
}
