using System;
using System.Web.UI.WebControls;

using QXPWUIBasic									= QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Composite
{
	/// <summary>Provides methods	and properties for a labeled <see cref="QXPWUIBasic.TextBox"/> control. <seealso cref="BaseComposite"/></summary>
	public class RangeTextBox: BaseRange{
		#region internal variables
		#endregion
		#region Construtors
		/// <summary>Creates a new instance of <see cref="TextBox"/> control. </summary>
		public RangeTextBox(): base(QXPWUIBasic.BasicType.TextBox, Composite.CssClass.rg_tbx.ToString()){}
		/// <summary>Creates a new instance of <see cref="TextBox"/> class with a <paramref name="type"/> data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		public RangeTextBox(Type type): this(){
			this.DataType = type;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		public RangeTextBox(System.Type type, string labelText): this(type){
			if(Validation.IsSet(labelText)) this.Label				= labelText; 
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text and <paramref name="readOnly"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of text box. </param>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		public RangeTextBox(System.Type type, string labelText, bool readOnly): this(type, labelText){
			this.ReadOnlyOfMin = this.ReadOnlyOfMax = readOnly;
		}
		#endregion
		/// <summary>Gets or sets the data of the min <see cref="TextBox"/>. </summary>
		protected override object						FeatureDataOfMin{
			get{return this.FeatureOfMin.Text;}
			set{this.FeatureOfMin.Text = Conversion.ToString(value, this.Format);}
		}
		/// <summary>Gets or sets the data of the max <see cref="TextBox"/>. </summary>
		protected override object						FeatureDataOfMax
		{
			get{return this.FeatureOfMax.Text;}
			set{this.FeatureOfMax.Text = Conversion.ToString(value, this.Format);}
		}
		public		new QXPWUIBasic.TextBox				FeatureOfMin
		{
			get{return (QXPWUIBasic.TextBox)base._featureOfMin;}
		}
		public		new QXPWUIBasic.TextBox				FeatureOfMax
		{
			get{return (QXPWUIBasic.TextBox)base._featureOfMax;}
		}
		/// <summary>Gets the text of the <see cref="Data"/> value. </summary>
		public		override		string				TextOfMin
		{
			get{return this.FeatureOfMin.Text;}
		}
		/// <summary>Gets the text of the <see cref="Data"/> value. </summary>
		public		override		string				TextOfMax
		{
			get{return this.FeatureOfMax.Text;}
		}
		/// <summary>Gets or sets if min <see cref="TextBox"/> change generated a post back event. </summary>
		public						bool				AutoPostBackOfMin
		{
			get{return this.FeatureOfMin.AutoPostBack;}
			set{this.FeatureOfMin.AutoPostBack = value;}
		}
		/// <summary>Gets or sets if max <see cref="TextBox"/> change generated a post back event. </summary>
		public						bool				AutoPostBackOfMax
		{
			get{return this.FeatureOfMax.AutoPostBack;}
			set{this.FeatureOfMax.AutoPostBack = value;}
		}
		/// <summary>Gets or sets if min <see cref="TextBox"/> change generated a call back event. </summary>
		public					bool				    AutoCallBackofMin
		{
			get{return this.FeatureOfMin.AutoCallBack;}
			set{this.FeatureOfMin.AutoCallBack = value;}
		}
		/// <summary>Gets or sets if min <see cref="TextBox"/> change generated a call back event. </summary>
		public					bool				    AutoCallBackofMax
		{
			get{return this.FeatureOfMax.AutoCallBack;}
			set{this.FeatureOfMax.AutoCallBack = value;}
		}

		#region Feature Properties
		/// <summary>Gets or sets the display width of the min text box in characters. </summary>
		public		int										ColumnsOfMin
		{
			get{return this.FeatureOfMin.Columns;}
			set{this.FeatureOfMin.Columns = value;}
		}
		/// <summary>Gets or sets the display width of the max text box in characters. </summary>
		public		int										ColumnsOfMax
		{
			get{return this.FeatureOfMax.Columns;}
			set{this.FeatureOfMax.Columns = value;}
		}
		/// <summary>Gets or sets the display height of a multiline min text box. </summary>
		public		int										RowsOfMin
		{
			get{return this.FeatureOfMin.Rows;}
			set{this.FeatureOfMin.Rows = value;}
		}
		/// <summary>Gets or sets the display height of a multiline min text box. </summary>
		public		int										RowsOfMax
		{
			get{return this.FeatureOfMax.Rows;}
			set{this.FeatureOfMax.Rows = value;}
		}
		/// <summary>Gets or sets the maximum number of characters allowed in the min text box. </summary>
		public		int										MaxLengthOfMin
		{
			get{return this.FeatureOfMin.MaxLength;}
			set{this.FeatureOfMin.MaxLength = value;}
		}
		/// <summary>Gets or sets the maximum number of characters allowed in the max text box. </summary>
		public		int										MaxLengthOfMax
		{
			get{return this.FeatureOfMax.MaxLength;}
			set{this.FeatureOfMax.MaxLength = value;}
		}
		/// <summary>Determines whether current min textbox if in hidden mode. </summary>
		public		bool									IsTextHiddenOfMin
		{
			get{return this.FeatureOfMin.IsTextHidden;}
			set{this.FeatureOfMin.IsTextHidden = value;}
		}
		/// <summary>Determines whether current max textbox if in hidden mode. </summary>
		public		bool									IsTextHiddenOfMax
		{
			get{return this.FeatureOfMax.IsTextHidden;}
			set{this.FeatureOfMax.IsTextHidden = value;}
		}
		/// <summary>Determines whether current min textbox is in multiline mode. </summary>
		public		bool									IsMultiLineTextOfMin
		{
			get{return(this.FeatureOfMin.TextMode == TextBoxMode.MultiLine);}
			set{this.FeatureOfMin.TextMode = value?TextBoxMode.MultiLine:TextBoxMode.SingleLine;}
		}
		/// <summary>Determines whether current max textbox is in multiline mode. </summary>
		public		bool									IsMultiLineTextOfMax
		{
			get{return(this.FeatureOfMax.TextMode == TextBoxMode.MultiLine);}
			set{this.FeatureOfMax.TextMode = value?TextBoxMode.MultiLine:TextBoxMode.SingleLine;}
		}
		#endregion
		/// <summary>Occurs when the content of the min text box is changed. </summary>
		public		event System.EventHandler TextChangedOfMin
		{
			add{this.FeatureOfMin.TextChanged += value;}
			remove{this.FeatureOfMin.TextChanged -= value;}
		}
		/// <summary>Occurs when the content of the max text box is changed. </summary>
		public		event System.EventHandler TextChangedOfMax
		{
			add{this.FeatureOfMax.TextChanged += value;}
			remove{this.FeatureOfMax.TextChanged -= value;}
		}
	}
}
