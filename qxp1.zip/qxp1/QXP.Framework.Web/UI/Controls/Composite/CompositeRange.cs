using System;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXPFrk = QXP.Framework;
using QXPApplication = QXP.Framework.Application;
using QXPResources = QXP.Framework.Resources;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIValidator = QXP.Framework.Web.UI.Controls.Validator;

namespace QXP.Framework.Web.UI.Controls.Composite
{

    /// <summary>Provides base methods and properties to build a composite control (which have specific container zones like label/feature/validator). this class is abstract and must be derived. This class is abstract. </summary>
    /// <remarks>
    /// BaseComposite is structured in three displayed zones, the <c>Label Zone</c> which contains the text label of the composite, the <c>Feature Zone</c> which contains input control and finally the <c>Validator Zone</c> that contains all validators controls. 
    /// </remarks>  
    public abstract class BaseRange : WebControlTagged, INamingContainer, QXPWUIValidator.IRangeControlValidator, QXPResources.IResource, Anthem.IUpdatableControl
    {
        #region Membres

        private bool _isInitialized = false;
        private bool _isDefined = false;
        private System.Type _dataType = ValueType.CLSobject;
        private object _defaultValueOfMin = null;
        private object _defaultValueOfMax = null;
        private RangeZone _zone = new RangeZone();
        private QXPWUIBasic.Label _label;
        private QXPWUIBasic.Label _labelOfMin;
        private QXPWUIBasic.Label _labelOfMax;
        private QXPWUIBasic.TableSection _table;
        private object _minValueOfMin;
        private object _maxValueOfMin;
        private object _minValueOfMax;
        private object _maxValueOfMax;

        private string _rangeFullToolTipValidatorOfMin = null;
        private string _rangeFullMessageValidatorOfMin = null;
        private string _compareDataTypeToolTipValidatorOfMin = null;
        private string _compareDataTypeMessageValidatorOfMin = null;
        private string _rangeMinToolTipValidatorOfMin = null;
        private string _rangeMinMessageValidatorOfMin = null;
        private string _rangeMaxToolTipValidatorOfMin = null;
        private string _rangeMaxMessageValidatorOfMin = null;
        private string _requiredMessageValidatorOfMin = null;
        private string _requiredToolTipValidatorOfMin = null;

        private string _rangeFullToolTipValidatorOfMax = null;
        private string _rangeFullMessageValidatorOfMax = null;
        private string _compareDataTypeToolTipValidatorOfMax = null;
        private string _compareDataTypeMessageValidatorOfMax = null;
        private string _rangeMinToolTipValidatorOfMax = null;
        private string _rangeMinMessageValidatorOfMax = null;
        private string _rangeMaxToolTipValidatorOfMax = null;
        private string _rangeMaxMessageValidatorOfMax = null;
        private string _requiredMessageValidatorOfMax = null;
        private string _requiredToolTipValidatorOfMax = null;

        private string _compareControlsMessageValidator = null;
        private string _compareControlsToolTipValidator = null;


        private QXPResources.ResourceInfo _resourceInfo = null;
        private QXPWUIValidator.RequiredFieldValidator _valRequiredOfMin = null;
        private QXPWUIValidator.CompareValidator _valMinOfMin = null;
        private QXPWUIValidator.CompareValidator _valMaxOfMin = null;
        private QXPWUIValidator.RangeValidator _valRangeOfMin = null;
        private QXPWUIValidator.CompareValidator _valTypeCheckOfMin = null;

        private QXPWUIValidator.RequiredFieldValidator _valRequiredOfMax = null;
        private QXPWUIValidator.CompareValidator _valMinOfMax = null;
        private QXPWUIValidator.CompareValidator _valMaxOfMax = null;
        private QXPWUIValidator.RangeValidator _valRangeOfMax = null;
        private QXPWUIValidator.CompareValidator _valTypeCheckOfMax = null;

        private QXPWUIValidator.CompareValidator _compareControls = null;

        private ArrayList _validators;
        private string _format;

        /// <summary>Gets access to the feature <see cref="System.Web.UI.WebControls.WebControl"/>. </summary>
        protected System.Web.UI.WebControls.WebControl _featureOfMin;
        protected System.Web.UI.WebControls.WebControl _featureOfMax;

        private BasePage _qxpPage = null;
        private bool _pageIsQXPPage = true;

        #endregion Membres

        #region Constantes

        /// <summary>Represents the key name of the viewstate used to store composite data value. </summary>
        protected const string KeyDataOfMin = "DataOfMin";
        protected const string KeyDataOfMax = "DataOfMax";
        private const string KeyReadOnlyOfMin = "ReadOnlyOfMin";
        private const string KeyReadOnlyOfMax = "ReadOnlyOfMax";
        private const string KeyIsRequiredOfMin = "IsRequiredOfMin";
        private const string KeyIsRequiredOfMax = "IsRequiredOfMax";
        private const string _featureIDOfMin = "_min";
        private const string _featureIDOfMax = "_max";
        private const string VSValidationGroup = "ValidationGroup";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        private BaseRange()
            : base()
        {
            //INFO: cette ligne est n�cessaire car des informations peuvent �tre mises dans le viewstate avant la fin de l'initialisation du controle.
            this.TrackViewState();
            _resourceInfo = new QXPResources.ResourceInfo();
            _label = new QXPWUIBasic.Label();
            _labelOfMin = new QXPWUIBasic.Label();
            _labelOfMax = new QXPWUIBasic.Label();
            _table = new QXPWUIBasic.TableSection(7, 1);
            _zone.Label = _table[0, 0];
            _zone.LabelOfMin = _table[0, 1];
            _zone.FeatureOfMin = _table[0, 2];
            _zone.ValidatorOfMin = _table[0, 3];
            _zone.LabelOfMax = _table[0, 4];
            _zone.FeatureOfMax = _table[0, 5];
            _zone.ValidatorOfMax = _table[0, 6];

            _zone.Label.CssClass = Composite.CssClass.zn_lbl.ToString();
            //			_zone.LabelOfMin.CssClass		= Composite.CssClass.zn_lbl_min.ToString();  //INFO: Label.CssClass Is Set in createChildControls.
            //			_zone.LabelOfMax.CssClass		= Composite.CssClass.zn_lbl_max.ToString();  //INFO: Label.CssClass Is Set in createChildControls.
            _zone.FeatureOfMax.CssClass = Composite.CssClass.zn_ftr_max.ToString();
            _zone.FeatureOfMax.CssClass = Composite.CssClass.zn_ftr_max.ToString();
            _zone.ValidatorOfMin.CssClass = Composite.CssClass.zn_vld_min.ToString();
            _zone.ValidatorOfMax.CssClass = Composite.CssClass.zn_vld_max.ToString();
            _validators = new ArrayList();
        }

        /// <summary>Creates a new instance of <see cref="BaseRange"/> control with the specified <paramref name="featureType"/> and <paramref name="cssClass"/>. </summary>
        /// <param name="featureType">The <see cref="Type"/> of the feature control hosted by the composite control. </param>
        /// <param name="cssClass">The <see cref="String"/> cascading style sheet (CSS) of the composite control. </param>
        protected BaseRange(Type featureType, string cssClass)
            : this()
        {
            System.Web.UI.WebControls.WebControl __featureOfMin = System.Activator.CreateInstance(featureType) as System.Web.UI.WebControls.WebControl;
            System.Web.UI.WebControls.WebControl __featureOfMax = System.Activator.CreateInstance(featureType) as System.Web.UI.WebControls.WebControl;
            if (Validation.IsNull(__featureOfMin)) throw new ArgumentException(WebConstant.InvalidFeatureType);
            _featureOfMin = __featureOfMin;
            _featureOfMax = __featureOfMax;
            AddToZoneLabel(_label);
            AddToZoneLabelOfMin(_labelOfMin);
            AddToZoneLabelOfMax(_labelOfMax);
            AddToZoneFeatureOfMin(_featureOfMin);
            AddToZoneFeatureOfMax(_featureOfMax);
            this.Controls.Add(_table);
            //Definies FeatureToValidate needed by validators
            if (Validation.IsNotSet(this.FeatureToValidateOfMin.ID)) this.FeatureToValidateOfMin.ID = base.ID + _featureOfMin;
            if (Validation.IsNotSet(this.FeatureToValidateOfMax.ID)) this.FeatureToValidateOfMax.ID = base.ID + _featureIDOfMax;
            _table.CssClass = cssClass;
            base.CssClass = Composite.CssClass.rg_.ToString();
        }

        #endregion Constructeur

        #region M�thodes

        private void SetResource()
        {
            if (this.ResourceInfo.HaveInfo)
            {
                this.Label = this.ResourceInfo.GetLabel();
                this.LabelOfMin = this.ResourceInfo.GetLabel(RangeControls.ControlOfMin);
                this.LabelOfMax = this.ResourceInfo.GetLabel(RangeControls.ControlOfMax);
                if (this.ResourceInfo.ExistToolTip()) this.ToolTip = this.ResourceInfo.GetToolTip();
                if (this.ResourceInfo.ExistToolTip(RangeControls.ControlOfMin)) this.ToolTipOfMin = this.ResourceInfo.GetToolTip(RangeControls.ControlOfMin);
                if (this.ResourceInfo.ExistToolTip(RangeControls.ControlOfMax)) this.ToolTipOfMax = this.ResourceInfo.GetToolTip(RangeControls.ControlOfMax);
            }
        }

        #region Zone handlers

        private void AddControl(TableCell zone, Control control)
        {
            zone.Controls.Add(control);
        }

        /// <summary>Adds the <paramref name="control"/> to the Label zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>
        public void AddToZoneLabel(Control control)
        {
            this.AddControl(_zone.Label, control);
        }

        /// <summary>Adds the <paramref name="content"/> text to the Label zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>
        public void AddToZoneLabel(string content)
        {
            this.AddToZoneLabel(new LiteralControl(content));
        }

        /// <summary>Adds the <paramref name="control"/> to the min Label zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>
        public void AddToZoneLabelOfMin(Control control)
        {
            this.AddControl(_zone.LabelOfMin, control);
        }

        /// <summary>Adds the <paramref name="content"/> text to the min Label zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>
        public void AddToZoneLabelOfMin(string content)
        {
            this.AddToZoneLabelOfMin(new LiteralControl(content));
        }

        /// <summary>Adds the <paramref name="control"/> to the max Label zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>
        public void AddToZoneLabelOfMax(Control control)
        {
            this.AddControl(_zone.LabelOfMax, control);
        }

        /// <summary>Adds the <paramref name="content"/> text to the max Label zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>
        public void AddToZoneLabelOfMax(string content)
        {
            this.AddToZoneLabelOfMax(new LiteralControl(content));
        }

        /// <summary>Adds the <paramref name="control"/> to the min Feature zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>
        public void AddToZoneFeatureOfMin(Control control)
        {
            this.AddControl(_zone.FeatureOfMin, control);
        }

        /// <summary>Adds the <paramref name="control"/> to the max Feature zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>
        public void AddToZoneFeatureOfMax(Control control)
        {
            this.AddControl(_zone.FeatureOfMax, control);
        }

        /// <summary>Adds the <paramref name="content"/> text to the min Feature zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>
        public void AddToZoneFeatureOfMin(string content)
        {
            this.AddToZoneFeatureOfMin(new LiteralControl(content));
        }

        /// <summary>Adds the <paramref name="content"/> text to the max Feature zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>
        public void AddToZoneFeatureOfMax(string content)
        {
            this.AddToZoneFeatureOfMax(new LiteralControl(content));
        }

        /// <summary>Adds the <paramref name="control"/> to the min Validator zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>
        public void AddToZoneValidatorOfMin(Control control)
        {
            this.AddControl(_zone.ValidatorOfMin, control);
        }

        /// <summary>Adds the <paramref name="control"/> to the max Validator zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>
        public void AddToZoneValidatorOfMax(Control control)
        {
            this.AddControl(_zone.ValidatorOfMax, control);
        }

        /// <summary>Adds the <paramref name="content"/> text to the min Validator zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>
        public void AddToZoneValidatorOfMin(string content)
        {
            this.AddToZoneValidatorOfMin(new LiteralControl(content));
        }

        /// <summary>Adds the <paramref name="content"/> text to the max Validator zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>
        public void AddToZoneValidatorOfMax(string content)
        {
            this.AddToZoneValidatorOfMax(new LiteralControl(content));
        }

        /// <summary>Adds the <paramref name="validator"/> control to the min Validator Zone. </summary>
        /// <param name="validator">The <see cref="BaseValidator"/> control to add. </param>
        /// <exception cref="InvalidOperationException">If <see cref="EnableValidator"/> is set to <see langword="false"/>. </exception>
        public void AddValidatorIntoMin(BaseValidator validator)
        {
            validator.ControlToValidate = this.IDToValidateOfMin;
            _validators.Add(validator);
            this.AddToZoneValidatorOfMin(validator);
        }

        /// <summary>Adds the <paramref name="validator"/> control to the max Validator Zone. </summary>
        /// <param name="validator">The <see cref="BaseValidator"/> control to add. </param>
        /// <exception cref="InvalidOperationException">If <see cref="EnableValidator"/> is set to <see langword="false"/>. </exception>
        public void AddValidatorIntoMax(BaseValidator validator)
        {
            validator.ControlToValidate = this.IDToValidateOfMax;
            _validators.Add(validator);
            this.AddToZoneValidatorOfMax(validator);
        }

        #endregion  Zone handlers

        #region Data Manipulation

        /// <summary>Gets current composite data in the <see cref="Type"/> specified by <see cref="DataType"/>. </summary>
        /// <param name="fromFeature"><see langword="true"/> if the value is evaluated from the Feature control otherwise <see langword="false"/> if the data is retrieve from cache. </param>
        /// <returns>The <see cref="Object"/> value of the composite control otherwise <see langword="null"/>. </returns>
        protected object GetDataOfMin(bool fromFeature)
        {
            object __data = this.GetTypeDataOfMin(fromFeature);
            if (Validation.IsSet(__data)) return __data;
            else return null;
        }

        private object GetTypeDataOfMin(bool fromFeature)
        {
            object __data = null;
            if (fromFeature && _isInitialized)
            {
                __data = this.FeatureDataOfMin;
            }
            else
            {
                if (this.ViewState.IsItemDirty(KeyDataOfMin))
                {
                    __data = this.ViewState[KeyDataOfMin];
                }
                else
                {
                    if (Validation.IsSet(this.DefaultValueOfMin))
                    {
                        __data = this.DefaultValueOfMin;
                    }
                }
            }
            this.SetTypedDataOfMin(__data);
            return Conversion.ToObject(this.ViewState[KeyDataOfMin], _dataType);
        }

        /// <summary>Gets current composite data in the <see cref="Type"/> specified by <see cref="DataType"/>. </summary>
        /// <param name="fromFeature"><see langword="true"/> if the value is evaluated from the Feature control otherwise <see langword="false"/> if the data is retrieve from cache. </param>
        /// <returns>The <see cref="Object"/> value of the composite control otherwise <see langword="null"/>. </returns>
        protected object GetDataOfMax(bool fromFeature)
        {
            object __data = this.GetTypeDataOfMax(fromFeature);
            if (Validation.IsSet(__data)) return __data;
            else return null;
        }

        private object GetTypeDataOfMax(bool fromFeature)
        {
            object __data = null;
            if (fromFeature && _isInitialized)
            {
                __data = this.FeatureDataOfMax;
            }
            else
            {
                if (this.ViewState.IsItemDirty(KeyDataOfMax))
                {
                    __data = this.ViewState[KeyDataOfMax];
                }
                else
                {
                    if (Validation.IsSet(this.DefaultValueOfMax))
                    {
                        __data = this.DefaultValueOfMax;
                    }
                }
            }
            this.SetTypedDataOfMax(__data);
            return Conversion.ToObject(this.ViewState[KeyDataOfMax], _dataType);
        }

        private object ToTypedData(object data)
        {
            object __value = data;
            if (Validation.IsNotNull(__value))
            {
                Type __type = data.GetType();
                if (__type.IsEnum) __value = Enum.Format(__type, data, "D");
            }
            __value = Conversion.ToObject(__value, this.DataType);
            return __value;
        }

        private void SetTypedDataOfMin(object data)
        {
            this.ViewState[KeyDataOfMin] = this.ToTypedData(data);
            this.ViewState.SetItemDirty(KeyDataOfMin, true);
        }

        private void SetTypedDataOfMax(object data)
        {
            this.ViewState[KeyDataOfMax] = this.ToTypedData(data);
            this.ViewState.SetItemDirty(KeyDataOfMax, true);
        }

        /// <summary>Clears composite data. </summary>
        public virtual void Clear()
        {
            this.ViewState.Remove(KeyDataOfMin);
            this.ViewState.Remove(KeyDataOfMax);
            //INFO: this remove All Form entry during postback on this Composite control.
            PageUtility.ClearChildFormEntry(this.Page, this);
            this.FeatureDataOfMin = this.GetDataOfMin(false);
            this.FeatureDataOfMax = this.GetDataOfMax(false);
        }

        /// <summary>This method ensure the control have initialized it's value. </summary>
        /// <param name="forgetPostBack">specify if the evaluation ignore postback of the page. </param>
        protected void EnsureDefined(bool forgetPostBack)
        {
            if (!_isDefined)
            {
                if (forgetPostBack || !this.Page.IsPostBack)
                {
                    object _initialValueOfMin = this.GetDataOfMin(false);
                    object _initialValueOfMax = this.GetDataOfMax(false);
                    this.FeatureDataOfMin = _initialValueOfMin;
                    this.FeatureDataOfMax = _initialValueOfMax;
                    _isDefined = true;
                }
            }
        }

        //INFO: this method is used when need to retrieve values (defaultvalue) during a postback 
        /// <summary>Use this method to initialize data value of the composite. </summary>
        /// <remarks>This method is already called by the <see cref="CreateChildControls"/> method or if you set a <see cref="Data"/> value. </remarks>
        public void EnsureDefined()
        {
            this.EnsureDefined(true);
        }

        #endregion Data Manipulation

        #region Validators

        /// <summary>
        /// Cr�ation des validateurs
        /// </summary>
        protected virtual void CreateValidators()
        {
            ValidationDataType __validationType = Conversion.ToValidationDataType(this.DataType);

            _valRequiredOfMin = new QXPWUIValidator.RequiredFieldValidator(this.RequiredMessageValidatorOfMin, this.RequiredToolTipValidatorOfMin, null, this.RequiredInitialValueOfMin);
            _valRequiredOfMin.ValidationGroup = this.ValidationGroup;

            _valTypeCheckOfMin = new QXPWUIValidator.CompareValidator(this.CompareDataTypeMessageValidatorOfMin, this.CompareDataTypeToolTipValidatorOfMin, null, ValidationCompareOperator.DataTypeCheck, __validationType);
            _valTypeCheckOfMin.ValidationGroup = this.ValidationGroup;

            _valRangeOfMin = new QXPWUIValidator.RangeValidator(this.RangeFullMessageValidatorOfMin, this.RangeFullToolTipValidatorOfMin, null, __validationType, this.MinValOfMin, this.MaxValOfMin);
            _valRangeOfMin.ValidationGroup = this.ValidationGroup;

            _valMinOfMin = new QXPWUIValidator.CompareValidator(this.RangeMinMessageValidatorOfMin, this.RangeMinToolTipValidatorOfMin, null, ValidationCompareOperator.GreaterThanEqual, __validationType, this.MinValOfMin);
            _valMinOfMin.ValidationGroup = this.ValidationGroup;

            _valMaxOfMin = new QXPWUIValidator.CompareValidator(this.RangeMaxMessageValidatorOfMin, this.RangeMaxToolTipValidatorOfMin, null, ValidationCompareOperator.LessThanEqual, __validationType, this.MaxValOfMin);
            _valMaxOfMin.ValidationGroup = this.ValidationGroup;


            _valRequiredOfMax = new QXPWUIValidator.RequiredFieldValidator(this.RequiredMessageValidatorOfMax, this.RequiredToolTipValidatorOfMax, null, this.RequiredInitialValueOfMax);
            _valRequiredOfMax.ValidationGroup = this.ValidationGroup;

            _valTypeCheckOfMax = new QXPWUIValidator.CompareValidator(this.CompareDataTypeMessageValidatorOfMax, this.CompareDataTypeToolTipValidatorOfMax, null, ValidationCompareOperator.DataTypeCheck, __validationType);
            _valTypeCheckOfMax.ValidationGroup = this.ValidationGroup;

            _valRangeOfMax = new QXPWUIValidator.RangeValidator(this.RangeFullMessageValidatorOfMax, this.RangeFullToolTipValidatorOfMax, null, __validationType, this.MinValOfMax, this.MaxValOfMax);
            _valRangeOfMax.ValidationGroup = this.ValidationGroup;

            _valMinOfMax = new QXPWUIValidator.CompareValidator(this.RangeMinMessageValidatorOfMax, this.RangeMinToolTipValidatorOfMax, null, ValidationCompareOperator.GreaterThanEqual, __validationType, this.MinValOfMax);
            _valMinOfMax.ValidationGroup = this.ValidationGroup;

            _valMaxOfMax = new QXPWUIValidator.CompareValidator(this.RangeMaxMessageValidatorOfMax, this.RangeMaxToolTipValidatorOfMax, null, ValidationCompareOperator.LessThanEqual, __validationType, this.MaxValOfMax);
            _valMaxOfMax.ValidationGroup = this.ValidationGroup;

            _compareControls = new QXPWUIValidator.CompareValidator(this.CompareControlsMessageValidator, this.CompareControlsToolTipValidator, null, ValidationCompareOperator.GreaterThanEqual, __validationType, this.FeatureToValidateOfMin);
            _compareControls.ValidationGroup = this.ValidationGroup;

            this.AddValidatorIntoMin(_valRequiredOfMin);
            this.AddValidatorIntoMin(_valTypeCheckOfMin);
            this.AddValidatorIntoMin(_valRangeOfMin);
            this.AddValidatorIntoMin(_valMinOfMin);
            this.AddValidatorIntoMin(_valMaxOfMin);

            this.AddValidatorIntoMax(_valRequiredOfMax);
            this.AddValidatorIntoMax(_valTypeCheckOfMax);
            this.AddValidatorIntoMax(_valRangeOfMax);
            this.AddValidatorIntoMax(_valMinOfMax);
            this.AddValidatorIntoMax(_valMaxOfMax);

            this.AddValidatorIntoMax(_compareControls);
        }

        #endregion Validators

        private void UpdateValidator()
        {
            ValidationDataType __validationType = Conversion.ToValidationDataType(this.DataType);
            _valRequiredOfMin.Visible = false;
            _valMinOfMin.Visible = false;
            _valMaxOfMin.Visible = false;
            _valRangeOfMin.Visible = false;
            _valTypeCheckOfMin.Visible = false;

            _valRequiredOfMax.Visible = false;
            _valMinOfMax.Visible = false;
            _valMaxOfMax.Visible = false;
            _valRangeOfMax.Visible = false;
            _valTypeCheckOfMax.Visible = false;


            //MIN controle validation
            if (this.IsRequiredOfMin)
            {
                _valRequiredOfMin.InitialValue = Conversion.ToString(this.RequiredInitialValueOfMin);
                _valRequiredOfMin.ErrorMessage = this.RequiredMessageValidatorOfMin;
                _valRequiredOfMin.ToolTip = this.RequiredToolTipValidatorOfMin;
                _valRequiredOfMin.Visible = this.IsRequiredOfMin;
            }

            if (Validation.IsSet(_minValueOfMin))
            {
                if (Validation.IsSet(_maxValueOfMin))
                {
                    _valRangeOfMin.ErrorMessage = this.RangeFullMessageValidatorOfMin;
                    _valRangeOfMin.ToolTip = this.RangeFullToolTipValidatorOfMin;
                    _valRangeOfMin.Type = __validationType;
                    _valRangeOfMin.MinimumValue = this.MinValOfMin;
                    _valRangeOfMin.MaximumValue = this.MaxValOfMin;
                    _valRangeOfMin.Visible = true;
                }
                else
                {
                    _valMinOfMin.ErrorMessage = this.RangeMinMessageValidatorOfMin;
                    _valMinOfMin.ToolTip = this.RangeMinToolTipValidatorOfMin;
                    _valMinOfMin.Operator = ValidationCompareOperator.GreaterThanEqual;
                    _valMinOfMin.Type = __validationType;
                    _valMinOfMin.ValueToCompare = this.MinValOfMin;
                    _valMinOfMin.Visible = true;
                }
            }
            else
            {
                if (Validation.IsSet(_maxValueOfMin))
                {
                    _valMaxOfMin.ErrorMessage = this.RangeMaxMessageValidatorOfMin;
                    _valMaxOfMin.ToolTip = this.RangeMaxToolTipValidatorOfMin;
                    _valMaxOfMin.Operator = ValidationCompareOperator.LessThanEqual;
                    _valMaxOfMin.Type = __validationType;
                    _valMaxOfMin.ValueToCompare = this.MaxValOfMin;
                    _valMaxOfMin.Visible = true;
                }
            }


            //MAX controle validation

            if (this.IsRequiredOfMax)
            {
                _valRequiredOfMax.InitialValue = Conversion.ToString(this.RequiredInitialValueOfMax);
                _valRequiredOfMax.ErrorMessage = this.RequiredMessageValidatorOfMax;
                _valRequiredOfMax.ToolTip = this.RequiredToolTipValidatorOfMax;
                _valRequiredOfMax.Visible = this.IsRequiredOfMax;
            }

            if (Validation.IsSet(_minValueOfMax))
            {
                if (Validation.IsSet(_maxValueOfMax))
                {
                    _valRangeOfMax.ErrorMessage = this.RangeFullMessageValidatorOfMax;
                    _valRangeOfMax.ToolTip = this.RangeFullToolTipValidatorOfMax;
                    _valRangeOfMax.Type = __validationType;
                    _valRangeOfMax.MinimumValue = this.MinValOfMax;
                    _valRangeOfMax.MaximumValue = this.MaxValOfMax;
                    _valRangeOfMax.Visible = true;
                }
                else
                {
                    _valMinOfMax.ErrorMessage = this.RangeMinMessageValidatorOfMax;
                    _valMinOfMax.ToolTip = this.RangeMinToolTipValidatorOfMax;
                    _valMinOfMax.Operator = ValidationCompareOperator.GreaterThanEqual;
                    _valMinOfMax.Type = __validationType;
                    _valMinOfMax.ValueToCompare = this.MinValOfMax;
                    _valMinOfMax.Visible = true;
                }
            }
            else
            {
                if (Validation.IsSet(_maxValueOfMax))
                {
                    _valMaxOfMax.ErrorMessage = this.RangeMaxMessageValidatorOfMax;
                    _valMaxOfMax.ToolTip = this.RangeMaxToolTipValidatorOfMax;
                    _valMaxOfMax.Operator = ValidationCompareOperator.LessThanEqual;
                    _valMaxOfMax.Type = __validationType;
                    _valMaxOfMax.ValueToCompare = this.MaxValOfMax;
                    _valMaxOfMax.Visible = true;
                }
            }


            //Commun
            if (__validationType != ValidationDataType.String)
            {
                _valTypeCheckOfMin.ErrorMessage = this.CompareDataTypeMessageValidatorOfMin;
                _valTypeCheckOfMin.ToolTip = this.CompareDataTypeToolTipValidatorOfMin;
                _valTypeCheckOfMin.Operator = ValidationCompareOperator.DataTypeCheck;
                _valTypeCheckOfMin.Type = __validationType;
                _valTypeCheckOfMin.Visible = true;

                _valTypeCheckOfMax.ErrorMessage = this.CompareDataTypeMessageValidatorOfMax;
                _valTypeCheckOfMax.ToolTip = this.CompareDataTypeToolTipValidatorOfMax;
                _valTypeCheckOfMax.Operator = ValidationCompareOperator.DataTypeCheck;
                _valTypeCheckOfMax.Type = __validationType;
                _valTypeCheckOfMax.Visible = true;

            }

        }

        #endregion M�thodes

        #region Evenements

        /// <summary>Occurs when the <see cref="BaseComposite"/> is initializing. </summary>
        /// <param name="ea">The <see cref="EventArgs"/> that contains event data. </param>
        protected override void OnInit(EventArgs ea)
        {
            base.OnInit(ea);

            _qxpPage = this.Page as BasePage;

            if (Validation.IsNotNull(_qxpPage))
            {
                _pageIsQXPPage = false;
                _qxpPage.BeforePageValidation += new BasicHandler(QXPPage_BeforePageValidation);
            }

            _isInitialized = true;
            this.SetResource();
        }

        /// <summary>Notify control to create any child controls for posting back or rendering. </summary>
        /// <remarks>Control used this method to update cascading style sheet (CSS). </remarks>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            //INFO: Check if user put value in data, if not, set the default value in control.
            this.EnsureDefined(false);
            this.CreateValidators();
        }

        /// <summary>Cancel the bubbling event outside the <see cref="BaseComposite"/> control. </summary>
        /// <param name="source">The sender of event. </param>
        /// <param name="e">The <see cref="EventArgs"/> argument. </param>
        /// <returns>Always <see langword="true"/>. </returns>
        protected override bool OnBubbleEvent(object source, EventArgs e)
        {
            return true; //INFO: Cancel Bubble Event
        }

        /// <summary>Occurs when the <see cref="BaseComposite"/> is about to render to its containing control. </summary>
        /// <param name="ea">The <see cref="EventArgs"/> that contains event data. </param>
        protected override void OnPreRender(EventArgs ea)
        {
            base.OnPreRender(ea);
            if (Validation.IsNotNull(_featureOfMin)) _featureOfMin.Enabled = !this.ReadOnlyOfMin && this.Enabled;
            if (Validation.IsNotNull(_featureOfMax)) _featureOfMax.Enabled = !this.ReadOnlyOfMax && this.Enabled;
            //StringBuilder __sb		= new StringBuilder();
            StringBuilder __sb_min = new StringBuilder();
            StringBuilder __sb_max = new StringBuilder();

            if (this.ReadOnlyOfMin) __sb_min.Append(CssClassState.ro.ToString()).Append(QXPFrk.Constantes.Space);
            if (this.ReadOnlyOfMax) __sb_max.Append(CssClassState.ro.ToString()).Append(QXPFrk.Constantes.Space);
            if (this.IsRequiredOfMin) __sb_min.Append(CssClassState.rqd.ToString()).Append(QXPFrk.Constantes.Space);
            if (this.IsRequiredOfMax) __sb_max.Append(CssClassState.rqd.ToString()).Append(QXPFrk.Constantes.Space);

            //__sb.Append(Composite.CssClass.zn_lbl.ToString());
            __sb_min.Append(Composite.CssClass.zn_lbl_min.ToString());
            __sb_max.Append(Composite.CssClass.zn_lbl_max.ToString());

            _zone.FeatureOfMin.Enabled = !this.ReadOnlyOfMin;
            _zone.FeatureOfMax.Enabled = !this.ReadOnlyOfMax;
            //_zone.Label.CssClass		= __sb.ToString().Trim();
            _zone.LabelOfMin.CssClass = __sb_min.ToString().Trim();
            _zone.LabelOfMax.CssClass = __sb_max.ToString().Trim();

            if (!_pageIsQXPPage)
                this.UpdateValidator();
        }

        /// <summary>
        /// Avant la validation de la page
        /// </summary>
        private void QXPPage_BeforePageValidation()
        {
            UpdateValidator();
        }

        #endregion Evenements

        #region Propri�t�s

        /// <summary>Gets the <see cref="Control"/> that contains the value to validate by validators, this reference is also used to retrieve real composite data value. </summary>
        public virtual Control FeatureOfMin
        {
            get { return (Control)_featureOfMin; }
        }

        public virtual Control FeatureToValidateOfMin
        {
            get { return (Control)_featureOfMin; }
        }

        /// <summary>Gets the <see cref="Control"/> that contains the value to validate by validators, this reference is also used to retrieve real composite data value. </summary>
        public virtual Control FeatureOfMax
        {
            get { return (Control)_featureOfMax; }
        }

        public virtual Control FeatureToValidateOfMax
        {
            get { return (Control)_featureOfMax; }
        }

        /// <summary>Gets or sets the current data of the min composite control. </summary>
        public object DataOfMin
        {
            get
            {
                this.EnsureDefined(false);
                return this.GetTypeDataOfMin(true);
            }
            set
            {
                this.SetTypedDataOfMin(value);
                if (_isInitialized) this.FeatureDataOfMin = this.GetDataOfMin(false);
            }
        }

        /// <summary>Gets or sets the current data of the max composite control. </summary>
        public object DataOfMax
        {
            get
            {
                this.EnsureDefined(false);
                return this.GetTypeDataOfMax(true);
            }
            set
            {
                this.SetTypedDataOfMax(value);
                if (_isInitialized) this.FeatureDataOfMax = this.GetDataOfMax(false);
            }
        }

        /// <summary>Gets or sets the <see cref="Type"/> data type of the composite control. </summary>
        public Type DataType
        {
            get { return (_dataType); }
            set { _dataType = value; }
        }

        /// <summary>Gets the current Data of the control. </summary>
        /// <remarks>Generally DataCurrent is equals to <see cref="BaseComposite.Data"/>. </remarks>
        protected virtual object DataCurrentOfMin
        {
            get { return this.DataOfMin; }
        }

        /// <summary>Gets the current Data of the control. </summary>
        /// <remarks>Generally DataCurrent is equals to <see cref="BaseComposite.Data"/>. </remarks>
        protected virtual object DataCurrentOfMax
        {
            get { return this.DataOfMax; }
        }

        /// <summary>This abstract method must be overriden in the derived class to mapped feature control value. </summary>
        protected abstract object FeatureDataOfMin
        {
            get;
            set;
        }

        /// <summary>This abstract method must be overriden in the derived class to mapped feature control value. </summary>
        protected abstract object FeatureDataOfMax
        {
            get;
            set;
        }

        /// <summary>This abstract method must be overriden in the derived class to retrieve feature control text. </summary>
        public abstract string TextOfMin
        {
            get;
        }

        /// <summary>This abstract method must be overriden in the derived class to retrieve feature control text. </summary>
        public abstract string TextOfMax
        {
            get;
        }

        /// <summary>Gets or sets the min default value of the composite control. </summary>
        public virtual object DefaultValueOfMin
        {
            get { return (_defaultValueOfMin); }
            set { _defaultValueOfMin = value; }
        }

        /// <summary>Gets or sets the max default value of the composite control. </summary>
        public virtual object DefaultValueOfMax
        {
            get { return (_defaultValueOfMax); }
            set { _defaultValueOfMax = value; }
        }

        #region Validators


        /// <summary>Gets the initial value of the required validator. </summary>
        protected virtual object RequiredInitialValueOfMin
        {
            get { return null; }
        }

        /// <summary>Gets the initial value of the required validator. </summary>
        protected virtual object RequiredInitialValueOfMax
        {
            get { return null; }
        }

        /// <summary>Gets or sets if the <see cref="BaseComposite"/> <see cref="Data"/> must be defined.  </summary>
        public virtual bool IsRequiredOfMin
        {
            get { return Conversion.ToBool(this.ViewState[KeyIsRequiredOfMin]); }
            set { this.ViewState[KeyIsRequiredOfMin] = value; }
        }

        /// <summary>Gets or sets if the <see cref="BaseComposite"/> <see cref="Data"/> must be defined.  </summary>
        public virtual bool IsRequiredOfMax
        {
            get { return Conversion.ToBool(this.ViewState[KeyIsRequiredOfMax]); }
            set { this.ViewState[KeyIsRequiredOfMax] = value; }
        }

        /// <summary>Gets or sets if the <see cref="BaseComposite"/> <see cref="Data"/> must be defined.  </summary>
        public virtual bool IsRequired
        {
            set
            {
                this.IsRequiredOfMax = value;
                this.IsRequiredOfMin = value;
            }
        }

        /// <summary>Gets or sets the minimum value of the <see cref="Data"/>. </summary>
        public object MinValueOfMin
        {
            get { return _minValueOfMin; }
            set { _minValueOfMin = value; }
        }

        /// <summary>Gets or sets the maximum value of the <see cref="Data"/>. </summary>
        public object MaxValueOfMin
        {
            get { return _maxValueOfMin; }
            set { _maxValueOfMin = value; }
        }

        /// <summary>Gets or sets the minimum value of the <see cref="Data"/>. </summary>
        public object MinValueOfMax
        {
            get { return _minValueOfMax; }
            set { _minValueOfMax = value; }
        }

        /// <summary>Gets or sets the maximum value of the <see cref="Data"/>. </summary>
        public object MaxValueOfMax
        {
            get { return _maxValueOfMax; }
            set { _maxValueOfMax = value; }
        }

        protected virtual string MinValOfMin
        {
            get { return Conversion.ToString(_minValueOfMin); }
        }

        protected virtual string MaxValOfMin
        {
            get { return Conversion.ToString(_maxValueOfMin); }
        }

        protected virtual string MinValOfMax
        {
            get { return Conversion.ToString(_minValueOfMax); }
        }

        protected virtual string MaxValOfMax
        {
            get { return Conversion.ToString(_maxValueOfMax); }
        }

        /// <summary>Gets or sets the ClientID of the <see cref="DataFeature"/> associated with the min validators. </summary>
        public virtual string ClientIDToValidateOfMin
        {
            get { return this.FeatureOfMin.ClientID; }
        }

        /// <summary>Gets or sets the ID of the <see cref="DataFeature"/> associated with the min validators. </summary>
        public virtual string IDToValidateOfMin
        {
            get { return this.FeatureToValidateOfMin.ID; }
        }

        /// <summary>Gets or sets the ClientID of the <see cref="DataFeature"/> associated with the max validators. </summary>
        public virtual string ClientIDToValidateOfMax
        {
            get { return this.FeatureOfMax.ClientID; }
        }

        /// <summary>Gets or sets the ID of the <see cref="DataFeature"/> associated with the max validators. </summary>
        public virtual string IDToValidateOfMax
        {
            get { return this.FeatureToValidateOfMax.ID; }
        }

        /// <summary>Determines whether all validators contained in the current composite control are valid. </summary>
        /// <remarks>This property process a server side form validation. </remarks>
        public bool IsValid
        {
            get
            {
                foreach (BaseValidator __validator in _validators)
                {
                    __validator.Validate();
                    if (!__validator.IsValid) return false;
                }
                return true;
            }
        }
        #endregion Validators

        #region Resources

        /// <summary>Gets or sets the tooltip text of the <see cref="QXPWUIBasic.Label"/> inserted in the <c>Label Zone</c>. </summary>
        public override string ToolTip
        {
            get { return _label.ToolTip; }
            set { _label.ToolTip = value; }
        }

        /// <summary>Gets or sets the tooltip text of the <see cref="QXPWUIBasic.Label"/> inserted in the <c>min Label Zone</c>. </summary>
        public string ToolTipOfMin
        {
            get { return _labelOfMin.ToolTip; }
            set { _labelOfMin.ToolTip = value; }
        }

        /// <summary>Gets or sets the tooltip text of the <see cref="QXPWUIBasic.Label"/> inserted in the <c>max Label Zone</c>. </summary>
        public string ToolTipOfMax
        {
            get { return _labelOfMax.ToolTip; }
            set { _labelOfMax.ToolTip = value; }
        }

        /// <summary>Gets or sets the text of the <see cref="QXPWUIBasic.Label"/> inserted in the <c>Label Zone</c>. </summary>
        public string Label
        {
            get { return (_label.Text); }
            set { _label.Text = value; }
        }

        /// <summary>Gets or sets the text of the <see cref="QXPWUIBasic.Label"/> inserted in the <c>Min Label Zone</c>. </summary>
        public string LabelOfMin
        {
            get { return (_labelOfMin.Text); }
            set { _labelOfMin.Text = value; }
        }

        /// <summary>Gets or sets the text of the <see cref="QXPWUIBasic.Label"/> inserted in the <c>Min Label Zone</c>. </summary>
        public string LabelOfMax
        {
            get { return (_labelOfMax.Text); }
            set { _labelOfMax.Text = value; }
        }

        /// <summary>Gets or sets the localized message of the min required validator. </summary>
        public virtual string RequiredMessageValidatorOfMin
        {
            get
            {
                if (Validation.IsSet(_requiredMessageValidatorOfMin)) return _requiredMessageValidatorOfMin;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RequiredMessageOfMin, this.Label, this.LabelOfMin);
            }
            set { _requiredMessageValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized message of the max required validator. </summary>
        public virtual string RequiredMessageValidatorOfMax
        {
            get
            {
                if (Validation.IsSet(_requiredMessageValidatorOfMax)) return _requiredMessageValidatorOfMax;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RequiredMessageOfMax, this.Label, this.LabelOfMax);
            }
            set { _requiredMessageValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the min required validator. </summary>
        public virtual string RequiredToolTipValidatorOfMin
        {
            get { return _requiredToolTipValidatorOfMin; }
            set { _requiredToolTipValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the max required validator. </summary>
        public virtual string RequiredToolTipValidatorOfMax
        {
            get { return _requiredToolTipValidatorOfMax; }
            set { _requiredToolTipValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized message of the min range validator. </summary>
        public virtual string RangeFullMessageValidatorOfMin
        {
            get
            {
                if (Validation.IsSet(_rangeFullMessageValidatorOfMin)) return _rangeFullMessageValidatorOfMin;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RangeFullMessageOfMin, this.Label, this.LabelOfMin, this.MinValOfMin, this.MaxValOfMin);
            }
            set { _rangeFullMessageValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized message of the max range validator. </summary>
        public virtual string RangeFullMessageValidatorOfMax
        {
            get
            {
                if (Validation.IsSet(_rangeFullMessageValidatorOfMax)) return _rangeFullMessageValidatorOfMax;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RangeFullMessageOfMax, this.Label, this.LabelOfMax, this.MinValOfMax, this.MaxValOfMax);
            }
            set { _rangeFullMessageValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the min range validator. </summary>
        public virtual string RangeFullToolTipValidatorOfMin
        {
            get { return _rangeFullToolTipValidatorOfMin; }
            set { _rangeFullToolTipValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the max range validator. </summary>
        public virtual string RangeFullToolTipValidatorOfMax
        {
            get { return _rangeFullToolTipValidatorOfMax; }
            set { _rangeFullToolTipValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized message of the min compare datatype validator. </summary>
        public virtual string CompareDataTypeMessageValidatorOfMin
        {
            get
            {
                if (Validation.IsSet(_compareDataTypeMessageValidatorOfMin)) return _compareDataTypeMessageValidatorOfMin;
                else return QXPApplication.Application.Resources.GetGlobalValidator(this.DataType, this.Label, this.LabelOfMin);
            }
            set { _compareDataTypeMessageValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized message of the max compare datatype validator. </summary>
        public virtual string CompareDataTypeMessageValidatorOfMax
        {
            get
            {
                if (Validation.IsSet(_compareDataTypeMessageValidatorOfMax)) return _compareDataTypeMessageValidatorOfMax;
                else return QXPApplication.Application.Resources.GetGlobalValidator(this.DataType, this.Label, this.LabelOfMax);
            }
            set { _compareDataTypeMessageValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the min compare datatype validator. </summary>
        public virtual string CompareDataTypeToolTipValidatorOfMin
        {
            get { return _compareDataTypeToolTipValidatorOfMin; }
            set { _compareDataTypeToolTipValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the compare datatype validator. </summary>
        public virtual string CompareDataTypeToolTipValidatorOfMax
        {
            get { return _compareDataTypeToolTipValidatorOfMax; }
            set { _compareDataTypeToolTipValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized message of the min range validator minimum value. </summary>
        public virtual string RangeMinMessageValidatorOfMin
        {
            get
            {
                if (Validation.IsSet(_rangeMinMessageValidatorOfMin)) return _rangeMinMessageValidatorOfMin;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RangeMinMessageOfMin, this.Label, this.LabelOfMin, this.MinValOfMin);
            }
            set { _rangeMinMessageValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized message of the max range validator minimum value. </summary>
        public virtual string RangeMinMessageValidatorOfMax
        {
            get
            {
                if (Validation.IsSet(_rangeMinMessageValidatorOfMax)) return _rangeMinMessageValidatorOfMax;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RangeMinMessageOfMax, this.Label, this.LabelOfMax, this.MinValOfMax);
            }
            set { _rangeMinMessageValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the min range validator minimum value. </summary>
        public virtual string RangeMinToolTipValidatorOfMin
        {
            get { return _rangeMinToolTipValidatorOfMin; }
            set { _rangeMinToolTipValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the max range validator minimum value. </summary>
        public virtual string RangeMinToolTipValidatorOfMax
        {
            get { return _rangeMinToolTipValidatorOfMax; }
            set { _rangeMinToolTipValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized message of the min range validator maximum value. </summary>
        public virtual string RangeMaxMessageValidatorOfMin
        {
            get
            {
                if (Validation.IsSet(_rangeMaxMessageValidatorOfMin)) return _rangeMaxMessageValidatorOfMin;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RangeMaxMessageOfMin, this.Label, this.LabelOfMin, this.MaxValOfMin);
            }
            set { _rangeMaxMessageValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized message of the max range validator maximum value. </summary>
        public virtual string RangeMaxMessageValidatorOfMax
        {
            get
            {
                if (Validation.IsSet(_rangeMaxMessageValidatorOfMax)) return _rangeMaxMessageValidatorOfMax;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RangeMaxMessageOfMax, this.Label, this.LabelOfMax, this.MaxValOfMax);
            }
            set { _rangeMaxMessageValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the min range validator maximum value. </summary>
        public virtual string RangeMaxToolTipValidatorOfMin
        {
            get { return _rangeMaxToolTipValidatorOfMin; }
            set { _rangeMaxToolTipValidatorOfMin = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the min range validator maximum value. </summary>
        public virtual string RangeMaxToolTipValidatorOfMax
        {
            get { return _rangeMaxToolTipValidatorOfMax; }
            set { _rangeMaxToolTipValidatorOfMax = value; }
        }

        /// <summary>Gets or sets the localized message of the max compare datatype validator. </summary>
        public virtual string CompareControlsMessageValidator
        {
            get
            {
                if (Validation.IsSet(_compareControlsMessageValidator)) return _compareControlsMessageValidator;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.CompareRangedControls, this.Label, this.LabelOfMin, this.LabelOfMax);
            }
            set { _compareControlsMessageValidator = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the min control compare to max control. </summary>
        public virtual string CompareControlsToolTipValidator
        {
            get { return _compareControlsToolTipValidator; }
            set { _compareControlsToolTipValidator = value; }
        }

        public QXPResources.ResourceInfo ResourceInfo
        {
            get { return _resourceInfo; }
        }

        #endregion Resources

        /// <summary>Gets or sets if composite control is read only. </summary>
        public virtual bool ReadOnlyOfMin
        {
            get { return Conversion.ToBool(this.ViewState[KeyReadOnlyOfMin]); }
            set { this.ViewState[KeyReadOnlyOfMin] = value; }
        }

        /// <summary>Gets or sets if composite control is read only. </summary>
        public virtual bool ReadOnlyOfMax
        {
            get { return Conversion.ToBool(this.ViewState[KeyReadOnlyOfMax]); }
            set { this.ViewState[KeyReadOnlyOfMax] = value; }
        }

        /// <summary>Gets or sets the cascading style sheet (CSS) used to render control. </summary>
        public override string CssClass
        {
            get { return base.CssClass; }
            set { base.CssClass = string.Concat(base.CssClass, QXPFrk.Constantes.Space, value); }
        }

        /// <summary>Gets or sets the text format of the displayed text. </summary>
        public string Format
        {
            get { return _format; }
            set { _format = value; }
        }

        public virtual bool AutoUpdateAfterCallBack
        {
            get
            {
                return _table.AutoUpdateAfterCallBack;
            }
            set
            {
                _table.AutoUpdateAfterCallBack = value;
            }
        }

        public virtual bool UpdateAfterCallBack
        {
            get
            {
                return _table.UpdateAfterCallBack;
            }
            set
            {
                this._table.UpdateAfterCallBack = value;
            }
        }

        /// <summary>
        /// ValidationGroup
        /// </summary>
        public string ValidationGroup
        {
            get { return Conversion.ToString(this.ViewState[VSValidationGroup]); }
            set { this.ViewState[VSValidationGroup] = value; }
        }

        #endregion Propri�t�s
    }

    internal class RangeZone
    {
        public QXPWUIBasic.ItemSection Label;
        public QXPWUIBasic.ItemSection LabelOfMin;
        public QXPWUIBasic.ItemSection FeatureOfMin;
        public QXPWUIBasic.ItemSection ValidatorOfMin;
        public QXPWUIBasic.ItemSection LabelOfMax;
        public QXPWUIBasic.ItemSection FeatureOfMax;
        public QXPWUIBasic.ItemSection ValidatorOfMax;
    }
}
