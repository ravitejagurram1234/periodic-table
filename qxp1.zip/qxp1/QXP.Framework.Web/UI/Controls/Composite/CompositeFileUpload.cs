using System;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXPApplication = QXP.Framework.Application;
using QXPResources = QXP.Framework.Resources;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIValidator = QXP.Framework.Web.UI.Controls.Validator;
using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls.Composite
{   
    /// <summary>
    /// Class FileUpload : provides methods	and properties for a labeled <see cref="QXPWUIBasic.FileUpload"/> control. <seealso cref="CompositeCanvas"/>
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class FileUpload : CompositeCanvas, QXPWUIValidator.IControlValidator
    {
        #region Membres

        QXPWUIBasic.FileUpload _fileUpload;
        private QXPWUIValidator.RequiredFieldValidator _valRequired = null;
        private ArrayList _validators;
        private string _requiredMessageValidator = null;
        private string _requiredToolTipValidator;

        #endregion Membres

        #region Constantes

        private const string KeyIsRequired = "IsRequired";
        private const string VSValidationGroup = "ValidationGroup";
        private const string _featureID = "_";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new instance of <see cref="CheckBox"/> control. </summary>
        public FileUpload()
            : base(Composite.CssClass.cps_flpld.ToString())
        {
            _fileUpload = new QXPWUIBasic.FileUpload();
            this.AddToZoneFeature(_fileUpload);

            //INFO: cette ligne est n�cessaire car des informations peuvent �tre mises dans le viewstate avant la fin de l'initialisation du controle.
            this.TrackViewState();
            _validators = new ArrayList();

            //Definies FeatureToValidate needed by validators
            if (Validation.IsNotSet(this.FeatureToValidate.ID))
                this.FeatureToValidate.ID = base.ID + _featureID;
        }

        /// <summary>Creates a new instance of <see cref="CheckBox"/> control with the specified <paramref name="labelText"/> text. </summary>
        /// <param name="labelText">The text label of the checkbox. </param>
        public FileUpload(string labelText)
            : this()
        {          
            if (Validation.IsSet(labelText)) this.Label = labelText;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>Adds the <paramref name="validator"/> control to the Validator Zone. </summary>
        /// <param name="validator">The <see cref="BaseValidator"/> control to add. </param>
        /// <exception cref="InvalidOperationException">If <see cref="EnableValidator"/> is set to <see langword="false"/>. </exception>
        public void AddValidator(BaseValidator validator)
        {
            validator.ControlToValidate = this.IDToValidate;
            validator.ValidationGroup = this.ValidationGroup;
            _validators.Add(validator);
            this.AddToZoneValidator(validator);
        }

        /// <summary>
        /// Cr�ation des validateurs
        /// </summary>
        protected void CreateValidators()
        {
            _valRequired = new QXPWUIValidator.RequiredFieldValidator(this.RequiredMessageValidator, this.RequiredToolTipValidator, null, this.RequiredInitialValue);
            
            this.AddValidator(_valRequired);
        }

        /// <summary>
        /// Mise � jour des validateurs
        /// </summary>
        private void UpdateValidator()
        {
            _valRequired.Visible = false;

            if (this.Enabled)
            {
                if (this.IsRequired)
                {
                    _valRequired.InitialValue = Conversion.ToString(this.RequiredInitialValue);
                    _valRequired.ErrorMessage = this.RequiredMessageValidator;
                    _valRequired.ToolTip = this.RequiredToolTipValidator;
                    _valRequired.Visible = this.IsRequired;
                }
            }
        }

        #endregion M�thodes

        #region Evenements

        /// <summary>Notify control to create any child controls for posting back or rendering. </summary>
        /// <remarks>Control used this method to update cascading style sheet (CSS). </remarks>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            this.CreateValidators();
        }

        /// <summary>
        /// Avant la validation de la page (uniquement si la page est une page QXP)
        /// </summary>
        protected override void OnBeforePageValidation()
        {
            base.OnBeforePageValidation();
            UpdateValidator();
        }

        /// <summary>Occurs when the <see cref="BaseComposite"/> is about to render to its containing control. </summary>
        /// <param name="ea">The <see cref="EventArgs"/> that contains event data. </param>
        protected override void OnPreRender(EventArgs ea)
        {
            base.OnPreRender(ea);
            if (Validation.IsNotNull(_fileUpload)) _fileUpload.Enabled = this.Enabled;
            StringBuilder __sb = new StringBuilder();
 
            if (this.IsRequired) __sb.Append(CssClassState.rqd.ToString()).Append(QXPFrk.Constantes.Space);
            __sb.Append(Composite.CssClass.zn_lbl.ToString());

            Zone.Label.CssClass = __sb.ToString().Trim();

            if (PageIsQXPPage)
                this.UpdateValidator();
        }

        #endregion Evenements

        #region Propri�t�s

        /// <summary>Gets the localized text representation of the <see cref="Data"/> value. </summary>
        public QXPWUIBasic.FileUpload File_Upload
        {
            get
            {
                return _fileUpload;
            }
        }

        /// <summary>Gets or sets if the <see cref="BaseComposite"/> <see cref="Data"/> must be defined.  </summary>
        public virtual bool IsRequired
        {
            get { return Conversion.ToBool(this.ViewState[KeyIsRequired]); }
            set { this.ViewState[KeyIsRequired] = value; }
        }

        /// <summary>Gets or sets if the <see cref="BaseComposite"/> Validators are affected in a Group.  </summary>
        public virtual string ValidationGroup
        {
            get { return Conversion.ToString(this.ViewState[VSValidationGroup]); }
            set { this.ViewState[VSValidationGroup] = value; }
        }

        /// <summary>
        /// Feature � valider
        /// </summary>
        public virtual Control FeatureToValidate
        {
            get { return (Control)_fileUpload; }
        }

        /// <summary>Gets or sets the ClientID of the <see cref="DataFeature"/> associated with the validators. </summary>
        public virtual string ClientIDToValidate
        {
            get { return this.FeatureToValidate.ClientID; }
        }

        /// <summary>Gets or sets the ID of the <see cref="DataFeature"/> associated with the validators. </summary>
        public virtual string IDToValidate
        {
            get { return this.FeatureToValidate.ID; }
        }

        /// <summary>Gets or sets the localized message of the required validator. </summary>
        public virtual string RequiredMessageValidator
        {
            get
            {
                if (Validation.IsSet(_requiredMessageValidator)) return _requiredMessageValidator;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RequiredMessage, this.Label);
            }
            set { _requiredMessageValidator = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the required validator. </summary>
        public virtual string RequiredToolTipValidator
        {
            get { return _requiredToolTipValidator; }
            set { _requiredToolTipValidator = value; }
        }

        /// <summary>Gets the initial value of the required validator. </summary>
        protected virtual object RequiredInitialValue
        {
            get { return null; }
        }

        #endregion Propri�t�s
    }			
}
