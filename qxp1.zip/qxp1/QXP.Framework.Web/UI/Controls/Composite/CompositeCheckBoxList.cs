using System;
using System.Collections;
using System.Web.UI.WebControls;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>
    /// Objet CheckBoxList
    /// </summary>
    /// <author>lippensl</author>
    /// <date>08/07/2010 17:44:53</date>    
    public class CheckBoxList : BaseComposite
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de CheckBoxList
        /// </summary>
        public CheckBoxList()
            : base(QXPWUIBasic.BasicType.CheckBoxList, Composite.CssClass.cps_chklst.ToString())
        {
        }

        public CheckBoxList(Type type)
            : this()
        {
            this.DataType = type;
        }

        public CheckBoxList(Type type, string labelText)
            : this(type)
        {
            if (Validation.IsSet(labelText))
                this.Label = labelText;
        }

        public CheckBoxList(System.Type type, string labelText, bool readOnly)
            : this(type, labelText)
        {
            this.ReadOnly = readOnly;
        }

        public CheckBoxList(System.Type type, string labelText, bool readOnly, bool isRequired)
            : this(type, labelText, readOnly)
        {
            this.IsRequired = isRequired;
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Gets or sets the default value of the <see cref="RadioButtonList"/> control.
        /// </summary>
        public override object DefaultValue
        {
            get { return (base.DefaultValue); }
            set
            {
                string[] __defaultValue;
                if (value is ICollection)
                    __defaultValue = Conversion.ToStringArray(value);
                else
                    __defaultValue = new string[1] { Conversion.ToString(value) };

                base.DefaultValue = __defaultValue;
                this.Feature.DefaultValues = __defaultValue;
            }
        }

        /// <summary>
        /// Gets or sets the data of the <see cref="RadioButtonList"/>.
        /// </summary>
        protected override object FeatureData
        {
            get { return Conversion.ToArray(this.Feature.SelectedValues, base.DataType.GetElementType()); }
            set { this.Feature.SelectedValues = Conversion.ToStringArray(value); }
        }

        /// <summary>
        /// 
        /// </summary>
        public new QXPWUIBasic.CheckBoxList Feature
        {
            get { return (QXPWUIBasic.CheckBoxList)base._feature; }
        }

        /// <summary>
        /// Gets the text of the selected item.
        /// </summary>
        public override string Text
        {
            get { return string.Empty; }
        }

        public object DataSource
        {
            get { return this.Feature.DataSource; }
            set { this.Feature.DataSource = value; }
        }

        public string DataMember
        {
            get { return this.Feature.DataMember; }
            set { this.Feature.DataMember = value; }
        }

        public string DataTextField
        {
            get { return this.Feature.DataTextField; }
            set { this.Feature.DataTextField = value; }
        }

        public string DataValueField
        {
            get { return this.Feature.DataValueField; }
            set { this.Feature.DataValueField = value; }
        }

        public string DataTextFormatString
        {
            get { return this.Feature.DataTextFormatString; }
            set { this.Feature.DataTextFormatString = value; }
        }

        /// <summary>
        /// Obtient ou d�finit une valeur indiquant si les donn�es sont affich�s verticalement ou horizontalement.
        /// </summary>
        public RepeatDirection RepeatDirection
        {
            get { return this.Feature.RepeatDirection; }
            set { this.Feature.RepeatDirection = value; }
        }

        /// <summary>
        /// Obtient ou d�finit le nombre de colonnes � afficher.
        /// </summary>
        public int RepeatColumns
        {
            get { return this.Feature.RepeatColumns; }
            set { this.Feature.RepeatColumns = value; }
        }

        public bool AutoPostBack
        {
            get { return this.Feature.AutoPostBack; }
            set { this.Feature.AutoPostBack = value; }
        }

        public bool AutoCallBack
        {
            get { return this.Feature.AutoCallBack; }
            set { this.Feature.AutoCallBack = value; }
        }

        public bool EnableCallBack
        {
            get { return this.Feature.EnableCallBack; }
            set { this.Feature.EnableCallBack = value; }
        }

        public bool CausesValidation
        {
            get { return this.Feature.CausesValidation; }
            set { this.Feature.CausesValidation = value; }
        }

        public int ItemsCount
        {
            get { return this.Feature.Items.Count; }
        }

        public bool IsSorted
        {
            get { return this.Feature.IsSorted; }
            set { this.Feature.IsSorted = value; }
        }

        public event EventHandler SelectedIndexChanged
        {
            add { this.Feature.SelectedIndexChanged += value; }
            remove { this.Feature.SelectedIndexChanged -= value; }
        }

        #endregion Propri�t�s
    }
}
