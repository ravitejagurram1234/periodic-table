using System;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using QXPFrk = QXP.Framework;
using QXPApplication = QXP.Framework.Application;
using QXPResources = QXP.Framework.Resources;
using QXPWUIValidator = QXP.Framework.Web.UI.Controls.Validator;

namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>Provides base methods and properties to build a composite control (which have specific container zones like label/feature/validator). this class is abstract and must be derived. This class is abstract. </summary>
    /// <remarks>
    /// BaseComposite is structured in three displayed zones, the <c>Label Zone</c> which contains the text label of the composite, the <c>Feature Zone</c> which contains input control and finally the <c>Validator Zone</c> that contains all validators controls. 
    /// </remarks>
    public abstract class BaseComposite : CompositeCanvas, QXPWUIValidator.IControlValidator
    {
        #region Membres

        /// <summary>Gets access to the feature <see cref="System.Web.UI.WebControls.WebControl"/>. </summary>
        protected System.Web.UI.WebControls.WebControl _feature;

        /// <summary>Represents the key name of the viewstate used to store composite data value. </summary>
        protected bool _isInitialized = false;
        private bool _isDefined = false;
        private System.Type _dataType = ValueType.CLSobject;
        private object _defaultValue = null;
        //private	bool										_enableValidator					= true;
        private string _rangeFullToolTipValidator = null;
        private string _rangeFullMessageValidator = null;
        private string _compareDataTypeToolTipValidator = null;
        private string _compareDataTypeMessageValidator = null;
        private string _rangeMinToolTipValidator = null;
        private string _rangeMinMessageValidator = null;
        private string _rangeMaxToolTipValidator = null;
        private string _rangeMaxMessageValidator = null;
        private string _requiredMessageValidator = null;
        private string _requiredToolTipValidator;
        private QXPWUIValidator.RequiredFieldValidator _valRequired = null;
        private QXPWUIValidator.CompareValidator _valMin = null;
        private QXPWUIValidator.CompareValidator _valMax = null;
        private QXPWUIValidator.RangeValidator _valRange = null;
        private QXPWUIValidator.CompareValidator _valTypeCheck = null;
        private ArrayList _validators;
        private string _format;

        #endregion Membres

        #region Constantes

        protected const string KeyData = "Data";
        private const string KeyReadOnly = "ReadOnly";
        private const string KeyIsRequired = "IsRequired";
        private const string VSValidationGroup = "ValidationGroup";
        private const string VSMinValue = "MinValue";
        private const string VSMaxValue = "MaxValue";
        private const string _featureID = "_";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de BaseComposite
        /// </summary>
        public BaseComposite()
            : base()
        {
            this.EnabledValidationBasedOfDataType = true;
            //INFO: cette ligne est n�cessaire car des informations peuvent �tre mises dans le viewstate avant la fin de l'initialisation du controle.
            this.TrackViewState();
            _validators = new ArrayList();
        }

        /// <summary>Creates a new instance of <see cref="BaseComposite"/> control with the specified <paramref name="featureType"/> and <paramref name="cssClass"/>. </summary>
        /// <param name="featureType">The <see cref="Type"/> of the feature control hosted by the composite control. </param>
        /// <param name="cssClass">The <see cref="String"/> cascading style sheet (CSS) of the composite control. </param>
        protected BaseComposite(Type featureType, string cssClass)
            : this()
        {
            System.Web.UI.WebControls.WebControl __feature = System.Activator.CreateInstance(featureType) as System.Web.UI.WebControls.WebControl;
            if (Validation.IsNull(__feature)) throw new ArgumentException(WebConstant.InvalidFeatureType);
            _feature = __feature;
            AddToZoneFeature(_feature);
            //Definies FeatureToValidate needed by validators
            if (Validation.IsNotSet(this.FeatureToValidate.ID)) this.FeatureToValidate.ID = base.ID + _featureID;
            this.Table.CssClass = cssClass;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>Occurs when the <see cref="BaseComposite"/> is initializing. </summary>
        /// <param name="ea">The <see cref="EventArgs"/> that contains event data. </param>
        protected override void OnInit(EventArgs ea)
        {
            base.OnInit(ea);
            _isInitialized = true;
        }

        /// <summary>Notify control to create any child controls for posting back or rendering. </summary>
        /// <remarks>Control used this method to update cascading style sheet (CSS). </remarks>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            this.CreateValidators();
        }

        /// <summary>Adds the <paramref name="validator"/> control to the Validator Zone. </summary>
        /// <param name="validator">The <see cref="BaseValidator"/> control to add. </param>
        /// <exception cref="InvalidOperationException">If <see cref="EnableValidator"/> is set to <see langword="false"/>. </exception>
        public void AddValidator(BaseValidator validator)
        {
            validator.ControlToValidate = this.IDToValidate;
            validator.ValidationGroup = this.ValidationGroup;
            _validators.Add(validator);
            this.AddToZoneValidator(validator);
        }

        #region Data Manipulation

        /// <summary>Gets current composite data in the <see cref="Type"/> specified by <see cref="DataType"/>. </summary>
        /// <param name="fromFeature"><see langword="true"/> if the value is evaluated from the Feature control otherwise <see langword="false"/> if the data is retrieve from cache. </param>
        /// <returns>The <see cref="Object"/> value of the composite control otherwise <see langword="null"/>. </returns>
        protected object GetData(bool fromFeature)
        {
            object __data = this.GetTypeData(fromFeature);
            if (Validation.IsSet(__data)) return __data;
            else return null;
        }

        private object GetTypeData(bool fromFeature)
        {
            object __data = null;
            if (fromFeature && _isInitialized)
            {
                __data = this.FeatureData;
            }
            else
            {
                if (this.ViewState.IsItemDirty(KeyData))
                {
                    __data = this.ViewState[KeyData];
                }
                else
                {
                    if (Validation.IsSet(this.DefaultValue))
                    {
                        __data = this.DefaultValue;
                    }
                }
            }
            this.SetTypedData(__data);
            return Conversion.ToObject(this.ViewState[KeyData], _dataType);
        }

        private object ToTypedData(object data)
        {
            object __value = data;
            if (Validation.IsNotNull(__value))
            {
                Type __type = data.GetType();
                if (__type.IsEnum) __value = Enum.Format(__type, data, "D");
            }
            __value = Conversion.ToObject(__value, this.DataType);
            return __value;
        }

        private void SetTypedData(object data)
        {
            this.ViewState[KeyData] = this.ToTypedData(data);
            this.ViewState.SetItemDirty(KeyData, true);
        }

        /// <summary>Clears composite data. </summary>
        public virtual void Clear()
        {
            this.ViewState.Remove(KeyData);
            //INFO: this remove All Form entry during postback on this Composite control.
            PageUtility.ClearChildFormEntry(this.Page, this);
            this.FeatureData = this.GetData(false);
        }

        /// <summary>This method ensure the control have initialized it's value. </summary>
        /// <param name="forgetPostBack">specify if the evaluation ignore postback of the page. </param>
        protected void EnsureDefined(bool forgetPostBack)
        {
            if (!_isDefined)
            {
                if (forgetPostBack || !this.Page.IsPostBack)
                {
                    object _initialValue = this.GetData(false);
                    this.FeatureData = _initialValue;
                    _isDefined = true;
                }
            }
        }

        //INFO: this method is used when need to retrieve values (defaultvalue) during a postback 
        /// <summary>Use this method to initialize data value of the composite. </summary>
        /// <remarks>This method is already called by the <see cref="CreateChildControls"/> method or if you set a <see cref="Data"/> value. </remarks>
        public void EnsureDefined()
        {
            this.EnsureDefined(true);
        }

        #endregion

        #region Validators

        protected virtual void CreateValidators()
        {
            ValidationDataType __validationType = Conversion.ToValidationDataType(this.DataType);

            _valRequired = new QXPWUIValidator.RequiredFieldValidator(this.RequiredMessageValidator, this.RequiredToolTipValidator, null, this.RequiredInitialValue);
            _valTypeCheck = new QXPWUIValidator.CompareValidator(this.CompareDataTypeMessageValidator, this.CompareDataTypeToolTipValidator, null, ValidationCompareOperator.DataTypeCheck, __validationType);
            _valRange = new QXPWUIValidator.RangeValidator(this.RangeFullMessageValidator, this.RangeFullToolTipValidator, null, __validationType, this.MinVal, this.MaxVal);
            _valMin = new QXPWUIValidator.CompareValidator(this.RangeMinMessageValidator, this.RangeMinToolTipValidator, null, ValidationCompareOperator.GreaterThanEqual, __validationType, this.MinVal);
            _valMax = new QXPWUIValidator.CompareValidator(this.RangeMaxMessageValidator, this.RangeMaxToolTipValidator, null, ValidationCompareOperator.LessThanEqual, __validationType, this.MaxVal);

            this.AddValidator(_valRequired);
            this.AddValidator(_valTypeCheck);
            this.AddValidator(_valRange);
            this.AddValidator(_valMin);
            this.AddValidator(_valMax);
        }

        #endregion

        /// <summary>Occurs when the <see cref="BaseComposite"/> is about to render to its containing control. </summary>
        /// <param name="ea">The <see cref="EventArgs"/> that contains event data. </param>
        protected override void OnPreRender(EventArgs ea)
        {
            base.OnPreRender(ea);
            if (Validation.IsNotNull(_feature)) 
                _feature.Enabled = !this.ReadOnly && this.Enabled;
            StringBuilder __sb = new StringBuilder();

            if (this.ReadOnly) __sb.Append(CssClassState.ro.ToString()).Append(QXPFrk.Constantes.Space);
            if (this.IsRequired) __sb.Append(CssClassState.rqd.ToString()).Append(QXPFrk.Constantes.Space);
            __sb.Append(Composite.CssClass.zn_lbl.ToString());

            Zone.Feature.Enabled = !this.ReadOnly;
            Zone.Label.CssClass = __sb.ToString().Trim();

            if (PageIsQXPPage)
                this.UpdateValidator();
        }

        /// <summary>
        ///  Mise � jour des validateurs
        /// </summary>
        private void UpdateValidator()
        {
            ValidationDataType __validationType = Conversion.ToValidationDataType(this.DataType);
            _valRequired.Visible = false;
            _valMin.Visible = false;
            _valMax.Visible = false;
            _valRange.Visible = false;
            _valTypeCheck.Visible = false;
            if (this.Enabled)
            {
                if (this.IsRequired)
                {
                    _valRequired.InitialValue = Conversion.ToString(this.RequiredInitialValue);
                    _valRequired.ErrorMessage = this.RequiredMessageValidator;
                    _valRequired.ToolTip = this.RequiredToolTipValidator;
                    _valRequired.Visible = this.IsRequired;
                }

                if (this.EnabledValidationBasedOfDataType)
                {
                    if (Validation.IsSet(this.MinValue))
                    {
                        if (Validation.IsSet(this.MaxValue))
                        {
                            _valRange.ErrorMessage = this.RangeFullMessageValidator;
                            _valRange.ToolTip = this.RangeFullToolTipValidator;
                            _valRange.Type = __validationType;
                            _valRange.MinimumValue = this.MinVal;
                            _valRange.MaximumValue = this.MaxVal;
                            _valRange.Visible = true;
                        }
                        else
                        {
                            _valMin.ErrorMessage = this.RangeMinMessageValidator;
                            _valMin.ToolTip = this.RangeMinToolTipValidator;
                            _valMin.Operator = ValidationCompareOperator.GreaterThanEqual;
                            _valMin.Type = __validationType;
                            _valMin.ValueToCompare = this.MinVal;
                            _valMin.Visible = true;
                        }
                    }
                    else
                    {
                        if (Validation.IsSet(this.MaxValue))
                        {
                            _valMax.ErrorMessage = this.RangeMaxMessageValidator;
                            _valMax.ToolTip = this.RangeMaxToolTipValidator;
                            _valMax.Operator = ValidationCompareOperator.LessThanEqual;
                            _valMax.Type = __validationType;
                            _valMax.ValueToCompare = this.MaxVal;
                            _valMax.Visible = true;
                        }
                    }
                    if (__validationType != ValidationDataType.String)
                    {
                        _valTypeCheck.ErrorMessage = this.CompareDataTypeMessageValidator;
                        _valTypeCheck.ToolTip = this.CompareDataTypeToolTipValidator;
                        _valTypeCheck.Operator = ValidationCompareOperator.DataTypeCheck;
                        _valTypeCheck.Type = __validationType;
                        _valTypeCheck.Visible = true;
                    }
                }
            }
        }

        public override void DataBind()
        {
            base.DataBind();
            //INFO: Check if user put value in data, if not, set the default value in control.
            this.EnsureDefined(false);
        }

        #endregion M�thodes

        #region Evenements

        /// <summary>
        /// Avant la validation de la page (uniquement si la page est une page QXP)
        /// </summary>
        protected override void OnBeforePageValidation()
        {
            base.OnBeforePageValidation();
            UpdateValidator();
        }

        #endregion Evenements

        #region Propri�t�s

        /// <summary>Gets the <see cref="Control"/> that contains the value to validate by validators, this reference is also used to retrieve real composite data value. </summary>
        public virtual Control Feature
        {
            get { return (Control)_feature; }
        }

        public virtual Control FeatureToValidate
        {
            get { return (Control)_feature; }
        }

        /// <summary>Gets the current Data of the control. </summary>
        /// <remarks>Generally DataCurrent is equals to <see cref="BaseComposite.Data"/>. </remarks>
        protected virtual object DataCurrent
        {
            get { return this.Data; }
        }

        /// <summary>This abstract method must be overriden in the derived class to mapped feature control value. </summary>
        protected abstract object FeatureData
        {
            get;
            set;
        }

        /// <summary>This abstract method must be overriden in the derived class to retrieve feature control text. </summary>
        public abstract string Text
        {
            get;
        }

        /// <summary>Gets or sets the default value of the composite control. </summary>
        public virtual object DefaultValue
        {
            get { return (_defaultValue); }
            set { _defaultValue = value; }
        }

        /// <summary>Gets or sets the current data of the composite control. </summary>
        public object Data
        {
            get
            {
                this.EnsureDefined(false);
                return this.GetTypeData(true);
            }
            set
            {
                this.SetTypedData(value);
                if (_isInitialized) this.FeatureData = this.GetData(false);
            }
        }

        /// <summary>Gets or sets the <see cref="Type"/> data type of the composite control. </summary>
        public Type DataType
        {
            get { return (_dataType); }
            set { _dataType = value; }
        }

        /// <summary>Gets the initial value of the required validator. </summary>
        protected virtual object RequiredInitialValue
        {
            get { return null; }
        }

        /// <summary>Gets or sets if the <see cref="BaseComposite"/> <see cref="Data"/> must be defined.  </summary>
        public virtual bool IsRequired
        {
            get { return Conversion.ToBool(this.ViewState[KeyIsRequired]); }
            set { this.ViewState[KeyIsRequired] = value; }
        }

        /// <summary>Gets or sets if the <see cref="BaseComposite"/> Validators are affected in a Group.  </summary>
        public virtual string ValidationGroup
        {
            get { return Conversion.ToString(this.ViewState[VSValidationGroup]); }
            set { this.ViewState[VSValidationGroup] = value; }
        }

        /// <summary>Gets or sets the minimum value of the <see cref="Data"/>. </summary>
        public object MinValue
        {
            get { return this.ViewState[VSMinValue]; }
            set { this.ViewState[VSMinValue] = value; }
        }

        /// <summary>Gets or sets the maximum value of the <see cref="Data"/>. </summary>
        public object MaxValue
        {
            get { return this.ViewState[VSMaxValue]; }
            set { this.ViewState[VSMaxValue] = value; }
        }

        protected virtual string MinVal
        {
            get { return Conversion.ToString(this.MinValue); }
        }

        protected virtual string MaxVal
        {
            get { return Conversion.ToString(this.MaxValue); }
        }

        /// <summary>Gets or sets the ClientID of the <see cref="DataFeature"/> associated with the validators. </summary>
        public virtual string ClientIDToValidate
        {
            get { return this.Feature.ClientID; }
        }

        /// <summary>Gets or sets the ID of the <see cref="DataFeature"/> associated with the validators. </summary>
        public virtual string IDToValidate
        {
            get { return this.FeatureToValidate.ID; }
        }

        /// <summary>Determines whether all validators contained in the current composite control are valid. </summary>
        /// <remarks>This property process a server side form validation. </remarks>
        public bool IsValid
        {
            get
            {
                foreach (BaseValidator __validator in _validators)
                {
                    __validator.Validate();
                    if (!__validator.IsValid) return false;
                }
                return true;
            }
        }

        /// <summary>
        /// Indique si la validation bas�e sur les types de donn�es doit etre effectu�es ou non
        /// </summary>
        protected bool EnabledValidationBasedOfDataType
        {
            get;
            set;
        }

        #region Resources

        /// <summary>Gets or sets the localized message of the required validator. </summary>
        public virtual string RequiredMessageValidator
        {
            get
            {
                if (Validation.IsSet(_requiredMessageValidator)) return _requiredMessageValidator;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RequiredMessage, this.Label);
            }
            set { _requiredMessageValidator = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the required validator. </summary>
        public virtual string RequiredToolTipValidator
        {
            get { return _requiredToolTipValidator; }
            set { _requiredToolTipValidator = value; }
        }

        /// <summary>Gets or sets the localized message of the range validator. </summary>
        public virtual string RangeFullMessageValidator
        {
            get
            {
                if (Validation.IsSet(_rangeFullMessageValidator)) return _rangeFullMessageValidator;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RangeFullMessage, this.Label, this.MinVal, this.MaxVal);
            }
            set { _rangeFullMessageValidator = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the range validator. </summary>
        public virtual string RangeFullToolTipValidator
        {
            get { return _rangeFullToolTipValidator; }
            set { _rangeFullToolTipValidator = value; }
        }

        /// <summary>Gets or sets the localized message of the compare datatype validator. </summary>
        public virtual string CompareDataTypeMessageValidator
        {
            get
            {
                if (Validation.IsSet(_compareDataTypeMessageValidator)) return _compareDataTypeMessageValidator;
                else return QXPApplication.Application.Resources.GetGlobalValidator(this.DataType, this.Label);
            }
            set { _compareDataTypeMessageValidator = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the compare datatype validator. </summary>
        public virtual string CompareDataTypeToolTipValidator
        {
            get { return _compareDataTypeToolTipValidator; }
            set { _compareDataTypeToolTipValidator = value; }
        }

        /// <summary>Gets or sets the localized message of the range validator minimum value. </summary>
        public virtual string RangeMinMessageValidator
        {
            get
            {
                if (Validation.IsSet(_rangeMinMessageValidator)) return _rangeMinMessageValidator;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RangeMinMessage, this.Label, this.MinVal);
            }
            set { _rangeMinMessageValidator = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the range validator minimum value. </summary>
        public virtual string RangeMinToolTipValidator
        {
            get { return _rangeMinToolTipValidator; }
            set { _rangeMinToolTipValidator = value; }
        }

        /// <summary>Gets or sets the localized message of the range validator maximum value. </summary>
        public virtual string RangeMaxMessageValidator
        {
            get
            {
                if (Validation.IsSet(_rangeMaxMessageValidator)) return _rangeMaxMessageValidator;
                else return QXPApplication.Application.Resources.GetGlobalValidator(QXPResources.ResourceParams.Key.RangeMaxMessage, this.Label, this.MaxVal);
            }
            set { _rangeMaxMessageValidator = value; }
        }

        /// <summary>Gets or sets the localized tooltip message of the range validator maximum value. </summary>
        public virtual string RangeMaxToolTipValidator
        {
            get { return _rangeMaxToolTipValidator; }
            set { _rangeMaxToolTipValidator = value; }
        }

        /// <summary>Gets or sets if composite control is read only. </summary>
        public virtual bool ReadOnly
        {
            get { return Conversion.ToBool(this.ViewState[KeyReadOnly]); }
            set { this.ViewState[KeyReadOnly] = value; }
        }

        /// <summary>Gets or sets the text format of the displayed text. </summary>
        public string Format
        {
            get { return _format; }
            set { _format = value; }
        }

        #endregion Resources

        #endregion Propri�t�s
    }
}
