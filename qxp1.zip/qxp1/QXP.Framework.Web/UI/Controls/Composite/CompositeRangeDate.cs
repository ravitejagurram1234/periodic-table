using System;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPApplication			= QXP.Framework.Application;
using QXPResources				= QXP.Framework.Resources;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;

namespace QXP.Framework.Web.UI.Controls.Composite
{
	/// <summary>Provides methods	and properties for a labeled <see cref="QXPWUIBasic.TextBox"/> control. <seealso cref="BaseComposite"/></summary>
	public class RangeDate: BaseRange
	{
		#region internal variables
		#endregion
		#region Construtors
		/// <summary>Creates a new instance of <see cref="Date"/> control. </summary>
		public RangeDate(): base(QXPWUIBasic.BasicType.Date, Composite.CssClass.rg_dt.ToString())
		{
			this.DataType	= ValueType.DateTime;
			this.Format		= "d";
		}
		/// <summary>Creates a new instance of <see cref="Date"/> control with the specified <paramref name="labelText"/> text, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="labelText">The text label of the text box. </param>
		public RangeDate(string labelText): this()
		{
			if(Validation.IsSet(labelText)) this.Label		= labelText; 
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text and <paramref name="readOnly"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		public RangeDate(string labelText, bool readOnly): this(labelText)
		{
			this.ReadOnlyOfMin = this.ReadOnlyOfMax = readOnly;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number and <paramref name="isRequired"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
		public RangeDate(string labelText, bool readOnly, bool isRequired): this(labelText, readOnly)
		{
			this.IsRequiredOfMin = this.IsRequiredOfMax = isRequired;
		}
		/// <summary>Creates a new instance of <see cref="TextBox"/> control with the specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="columns"/> number, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="labelText">The text label of the text box. </param>
		/// <param name="readOnly"><see langword="true"/> if the textbox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the textbox is required otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the text box. </param>
		public RangeDate(string labelText, bool readOnly, bool isRequired, object defaultValue): this(labelText, readOnly, isRequired)
		{
			this.DefaultValueOfMin = this.DefaultValueOfMax = defaultValue;
		}
		#endregion
		/// <summary>Gets or sets the data of the min <see cref="Date"/>. </summary>
		protected	override	object				FeatureDataOfMin
		{
			get{return this.FeatureOfMin.SelectedDate;}
			set{this.FeatureOfMin.SelectedDate = Conversion.ToString(value, this.Format);}
		}
		/// <summary>Gets or sets the data of the max <see cref="Date"/>. </summary>
		protected	override	object				FeatureDataOfMax
		{
			get{return this.FeatureOfMax.SelectedDate;}
			set{this.FeatureOfMax.SelectedDate = Conversion.ToString(value, this.Format);}
		}
		protected	override	string				MinValOfMin
		{
			get{return Conversion.ToString(this.MinValueOfMin, this.Format);}
		}
		protected	override	string				MaxValOfMin
		{
			get{return Conversion.ToString(this.MaxValueOfMin, this.Format);}
		}
		protected	override	string				MinValOfMax
		{
			get{return Conversion.ToString(this.MinValueOfMax, this.Format);}
		}
		protected	override	string				MaxValOfMax
		{
			get{return Conversion.ToString(this.MaxValueOfMax, this.Format);}
		}
		public		new			QXPWUIBasic.Date	FeatureOfMin
		{
			get{return (QXPWUIBasic.Date)base._featureOfMin;}
		}
		public		new			QXPWUIBasic.Date	FeatureOfMax
		{
			get{return (QXPWUIBasic.Date)base._featureOfMax;}
		}
		public		override	Control				FeatureToValidateOfMin
		{
			get{return this.FeatureOfMin._txtBox;}
		}
		public		override	Control				FeatureToValidateOfMax
		{
			get{return this.FeatureOfMax._txtBox;}
		}
		/// <summary>Gets the text of the min <see cref="Data"/> value. </summary>
		public		override	string				TextOfMin
		{
			get{return this.FeatureOfMin.SelectedDate;}
		}
		/// <summary>Gets the text of the max <see cref="Data"/> value. </summary>
		public		override	string				TextOfMax
		{
			get{return this.FeatureOfMax.SelectedDate;}
		}
		/// <summary>Gets or sets if min <see cref="TextBox"/> change generated a post back event. </summary>
		public					bool				AutoPostBackofMin
		{
			get{return this.FeatureOfMin.AutoPostBack;}
			set{this.FeatureOfMin.AutoPostBack = value;}
		}
		/// <summary>Gets or sets if min <see cref="TextBox"/> change generated a call back event. </summary>
		public					bool				AutoCallBackofMin
		{
			get{return this.FeatureOfMin.AutoCallBack;}
			set{this.FeatureOfMin.AutoCallBack = value;}
		}

		/// <summary>Gets or sets if max <see cref="TextBox"/> change generated a post back event. </summary>
		public					bool				AutoPostBackofMax
		{
			get{return this.FeatureOfMax.AutoPostBack;}
			set{this.FeatureOfMax.AutoPostBack = value;}
		}
        		/// <summary>Gets or sets if min <see cref="TextBox"/> change generated a call back event. </summary>
		public					bool				AutoCallBackofMax
		{
			get{return this.FeatureOfMax.AutoCallBack;}
			set{this.FeatureOfMax.AutoCallBack = value;}
		}

		/// <summary>Occurs when the date is changed. </summary>
		public		event System.EventHandler		DateChangedOfMin
		{
			add{this.FeatureOfMin.DateChanged += value;}
			remove{this.FeatureOfMin.DateChanged -= value;}
		}
		/// <summary>Occurs when the date is changed. </summary>
		public		event System.EventHandler		DateChangedOfMax
		{
			add{this.FeatureOfMax.DateChanged += value;}
			remove{this.FeatureOfMax.DateChanged -= value;}
		}
	}
}
