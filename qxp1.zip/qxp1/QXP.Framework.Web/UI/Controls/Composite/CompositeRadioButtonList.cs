using System;
using System.Web.UI.WebControls;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>
    /// Class RadioButtonList : Provides methods	and properties for a labeled <see cref="QXPWUIBasic.RadioButtonList"/> control. <seealso cref="BaseComposite"/>
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class RadioButtonList : BaseComposite
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new instance of <see cref="RadioButtonList"/> control. </summary>
        public RadioButtonList() : base(QXPWUIBasic.BasicType.RadioButtonList, Composite.CssClass.cps_rdlst.ToString()) { }

        /// <summary>Creates a new instance of <see cref="RadioButtonList"/> control which values have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        public RadioButtonList(Type type)
            : this()
        {
            this.DataType = type;
        }

        /// <summary>Creates a new instance of <see cref="RadioButtonList"/> control with specified <paramref name="labelText"/> text, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the RadioButtonList. </param>
        public RadioButtonList(System.Type type, string labelText)
            : this(type)
        {
            if (Validation.IsSet(labelText)) this.Label = labelText;
        }

        /// <summary>Creates a new instance of <see cref="RadioButtonList"/> control with specified <paramref name="labelText"/> text and <paramref name="readOnly"/>, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the RadioButtonList. </param>
        /// <param name="readOnly"><see langword="true"/> if the RadioButtonList is readonly otherwise <see langword="false"/>. </param>
        public RadioButtonList(System.Type type, string labelText, bool readOnly)
            : this(type, labelText)
        {
            this.ReadOnly = readOnly;
        }

        /// <summary>Creates a new instance of <see cref="RadioButtonList"/> control with specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="isRequired"/> , it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the RadioButtonList. </param>
        /// <param name="readOnly"><see langword="true"/> if the RadioButtonList is readonly otherwise <see langword="false"/>. </param>
        /// <param name="isRequired"><see langword="true"/> if the RadioButtonList is required otherwise <see langword="false"/>. </param>
        public RadioButtonList(System.Type type, string labelText, bool readOnly, bool isRequired)
            : this(type, labelText, readOnly)
        {
            this.IsRequired = isRequired;
        }

        /// <summary>Creates a new instance of <see cref="RadioButtonList"/> control with specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the RadioButtonList. </param>
        /// <param name="readOnly"><see langword="true"/> if the RadioButtonList is readonly otherwise <see langword="false"/>. </param>
        /// <param name="isRequired"><see langword="true"/> if the RadioButtonList is required otherwise <see langword="false"/>. </param>
        /// <param name="defaultValue">The <see cref="Object"/> default value of the RadioButtonList. </param>
        public RadioButtonList(System.Type type, string labelText, bool readOnly, bool isRequired, object defaultValue)
            : this(type, labelText, readOnly, isRequired)
        {
            this.DefaultValue = defaultValue;
        }

        #endregion Constructeur

        #region M�thodes

        public void ClearSelection()
        {
            this.Feature.ClearSelection();
        }

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        /// <summary>Gets or sets the default value of the <see cref="RadioButtonList"/> control. </summary>
        public override object DefaultValue
        {
            get { return (base.DefaultValue); }
            set
            {
                base.DefaultValue = value;
                this.Feature.DefaultValue = base.DefaultValue;
            }
        }

        /// <summary>Gets or sets the data of the <see cref="RadioButtonList"/>. </summary>
        protected override object FeatureData
        {
            get { return this.Feature.SelectedValue; }
            set { this.Feature.SelectedValue = Conversion.ToString(value); }
        }

        /// <summary>Gets the text of the selected item. </summary>
        public override string Text
        {
            get { return this.Feature.SelectedText; }
        }

        public new QXPWUIBasic.RadioButtonList Feature
        {
            get { return (QXPWUIBasic.RadioButtonList)base._feature; }
        }

        /// <summary>Gets or sets the data source that populates the items of the list control. </summary>
        public object DataSource
        {
            get { return this.Feature.DataSource; }
            set { this.Feature.DataSource = value; }
        }

        /// <summary>Gets or sets the specific memeber in the <see cref="DataSource"/> to bind to the control. </summary>
        public string DataMember
        {
            get { return this.Feature.DataMember; }
            set { this.Feature.DataMember = value; }
        }

        /// <summary>Gets or sets the field of the data source that provides the value of each list item. </summary>
        public string DataValueField
        {
            get { return this.Feature.DataValueField; }
            set { this.Feature.DataValueField = value; }
        }

        /// <summary>Gets or sets the field of the data source that provides the text content of the list items. </summary>
        public string DataTextField
        {
            get { return this.Feature.DataTextField; }
            set { this.Feature.DataTextField = value; }
        }

        /// <summary>Gets or sets the formatting string used to control how data bound to the list control is displayed. </summary>
        public string DataTextFormatString
        {
            get { return this.Feature.DataTextFormatString; }
            set { this.Feature.DataTextFormatString = value; }
        }

        /// <summary>Gets or sets the maximum number of item text length. </summary>
        public int MaxTextLength
        {
            get { return this.Feature.MaxTextLength; }
            set { this.Feature.MaxTextLength = value; }
        }

        /// <summary>Gets or sets whether the items in the list are sorted. </summary>
        public bool IsSorted
        {
            get { return this.Feature.IsSorted; }
            set { this.Feature.IsSorted = value; }
        }

        /// <summary>Gets the Text of the selected item. </summary>
        public string DataText
        {
            get { return this.Feature.SelectedText; }
        }

        /// <summary>Gets or sets if <see cref="RadioButtonList"/> selection change generated a post back event. </summary>
        public bool AutoPostBack
        {
            get { return this.Feature.AutoPostBack; }
            set { this.Feature.AutoPostBack = value; }
        }

        /// <summary>Gets or sets if <see cref="RadioButtonList"/> change generated a call back event. </summary>
        public bool AutoCallBack
        {
            get { return this.Feature.AutoCallBack; }
            set { this.Feature.AutoCallBack = value; }
        }

        /// <summary>Gets or sets if the control raise callback event (otherwise it raise postback event). </summary>
        public bool EnableCallBack
        {
            get { return this.Feature.EnableCallBack; }
            set { this.Feature.EnableCallBack = value; }
        }

        public bool CauseValidation
        {
            get { return this.Feature.CausesValidation; }
            set { this.Feature.CausesValidation = value; }
        }

        /// <summary>Gets the selected item index. </summary>
        public int SelectedIndex
        {
            get { return this.Feature.SelectedIndex; }
        }

        public bool EnableEmptySelection
        {
            get { return this.Feature.EnableEmptySelection; }
            set { this.Feature.EnableEmptySelection = value; }
        }

        public bool IsEmptySelected
        {
            get { return this.Feature.IsEmptySelected; }
        }

        public RepeatDirection RepeatDirection
        {
            get { return this.Feature.RepeatDirection; }
            set { this.Feature.RepeatDirection = value; }
        }

        public int RepeatColumns
        {
            get { return this.Feature.RepeatColumns; }
            set { this.Feature.RepeatColumns = value; }
        }

        public RepeatLayout RepeatLayout
        {
            get { return this.Feature.RepeatLayout; }
            set { this.Feature.RepeatLayout = value; }
        }

        public string OnRadioClickScript
        {
            get { return this.Feature.OnRadioClickScript; }
            set { this.Feature.OnRadioClickScript = value; }
        }

        /// <summary>Occurs when the selected item change. </summary>
        public event EventHandler SelectedIndexChanged
        {
            add { this.Feature.SelectedIndexChanged += value; }
            remove { this.Feature.SelectedIndexChanged -= value; }
        }

        /// <summary>
        /// Type d'ajaxisation
        /// </summary>
        public Anthem.AjaxMode AjaxMode
        {
            get { return this.Feature.AjaxMode; }
            set { this.Feature.AjaxMode = value; }
        }

        #endregion Propri�t�s
    }

			
}
