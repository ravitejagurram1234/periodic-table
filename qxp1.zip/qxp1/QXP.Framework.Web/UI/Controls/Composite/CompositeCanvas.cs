using System;
using System.Web.UI;
using System.Web.UI.WebControls;

using QXPResources = QXP.Framework.Resources;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;
using QXPFrk = QXP.Framework;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>Provides base methods and properties to build a composite control (which have specific container zones like label/feature/validator). this class is abstract and must be derived. This class is abstract. </summary>
    /// <remarks>
    /// BaseComposite is structured in three displayed zones, the <c>Label Zone</c> which contains the text label of the composite, the <c>Feature Zone</c> which contains input control and finally the <c>Validator Zone</c> that contains all validators controls. 
    /// </remarks>
    public abstract class CompositeCanvas : WebControlTagged, INamingContainer, QXPResources.IResource, Anthem.IUpdatableControl
    {
        #region Membres

        /// <summary>Represents the key name of the viewstate used to store composite data value. </summary>
        protected Zone _zone = new Zone();
        protected QXPWUIBasic.Label _label;
        private QXPWUIBasic.TableSection _table;
        private QXPResources.ResourceInfo _resourceInfo = null;

        /// <summary>Gets access to the feature <see cref="System.Web.UI.WebControls.WebControl"/>. </summary>
        protected System.Web.UI.WebControls.WebControl _feature;

        bool _showLabel = true;

        private bool _pageIsQXPPage = false;

        #endregion Membres

        #region Constantes

        private const string KeyIsRequired = "IsRequired";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        protected CompositeCanvas()
            : base()
        {
            _resourceInfo = new QXPResources.ResourceInfo();
            _label = new QXPWUIBasic.Label();
            _table = new QXPWUIBasic.TableSection(3, 1);
            _zone.Label = _table[0, 0];
            _zone.Feature = _table[0, 1];
            _zone.Validator = _table[0, 2];

            _zone.Label.CssClass = Composite.CssClass.zn_lbl.ToString();
            _zone.Feature.CssClass = Composite.CssClass.zn_ftr.ToString();
            _zone.Validator.CssClass = Composite.CssClass.zn_vld.ToString();
            AddToZoneLabel(_label);
            this.Controls.Add(_table);
            base.CssClass = Composite.CssClass.cps_.ToString();
        }

        protected CompositeCanvas(string cssClass)
            : this()
        {
            _table.CssClass = cssClass;
        }


        #endregion Constructeur

        #region M�thodes

        private void SetResource()
        {
            if (this.ResourceInfo.HaveInfo)
            {
                this.Label = this.ResourceInfo.GetLabel();
                if (this.ResourceInfo.ExistToolTip()) this.ToolTip = this.ResourceInfo.GetToolTip();
            }
        }

        #region Zone handlers

        private void AddControl(TableCell zone, Control control)
        {
            zone.Controls.Add(control);
        }
        /// <summary>Adds the <paramref name="control"/> to the Label zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>

        public void AddToZoneLabel(Control control)
        {
            this.AddControl(_zone.Label, control);
        }
        /// <summary>Adds the <paramref name="content"/> text to the Label zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>

        public void AddToZoneLabel(string content)
        {
            this.AddToZoneLabel(new LiteralControl(content));
        }
        /// <summary>Adds the <paramref name="control"/> to the Feature zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>

        public void AddToZoneFeature(Control control)
        {
            this.AddControl(_zone.Feature, control);
        }
        /// <summary>Adds the <paramref name="content"/> text to the Feature zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>

        public void AddToZoneFeature(string content)
        {
            this.AddToZoneFeature(new LiteralControl(content));
        }
        /// <summary>Adds the <paramref name="control"/> to the Validator zone. </summary>
        /// <param name="control">The <see cref="Control"/> to add. </param>

        public void AddToZoneValidator(Control control)
        {
            this.AddControl(_zone.Validator, control);
        }
        /// <summary>Adds the <paramref name="content"/> text to the Validator zone. </summary>
        /// <param name="content">The <see cref="String"/> text to add. </param>

        public void AddToZoneValidator(string content)
        {
            this.AddToZoneValidator(new LiteralControl(content));
        }

        #endregion Zone handlers

        #endregion M�thodes

        #region Evenements

        /// <summary>Occurs when the <see cref="BaseComposite"/> is initializing. </summary>
        /// <param name="ea">The <see cref="EventArgs"/> that contains event data. </param>
        protected override void OnInit(EventArgs ea)
        {
            base.OnInit(ea);
            this.SetResource();

            BasePage _qxpPage = this.Page as BasePage;
            if (Validation.IsNotNull(_qxpPage))
            {
                _pageIsQXPPage = true;
                _qxpPage.BeforePageValidation += OnBeforePageValidation;
            }

        }

        /// <summary>Cancel the bubbling event outside the <see cref="BaseComposite"/> control. </summary>
        /// <param name="source">The sender of event. </param>
        /// <param name="e">The <see cref="EventArgs"/> argument. </param>
        /// <returns>Always <see langword="true"/>. </returns>
        protected override bool OnBubbleEvent(object source, EventArgs e)
        {
            return true; //INFO: Cancel Bubble Event
        }

        /// <summary>
        /// Avant le rendu de la page
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            _label.Visible = _showLabel;
        }

        /// <summary>
        /// Avant la validation de la page (uniquement si la page est une page QXP)
        /// </summary>
        protected virtual void OnBeforePageValidation()
        {            
        }

        #endregion Evenements

        #region Propri�t�s

        protected QXPWUIBasic.TableSection Table
        {
            get { return _table; }
        }

        protected Zone Zone
        {
            get { return _zone; }
        }

        /// <summary>Gets or sets the cascading style sheet (CSS) used to render control. </summary>
        public override string CssClass
        {
            get { return base.CssClass; }
            set { base.CssClass = string.Concat(base.CssClass, QXPFrk.Constantes.Space, value); }
        }

        public new virtual bool AutoUpdateAfterCallBack
        {
            get
            {
                return _table.AutoUpdateAfterCallBack;
            }
            set
            {
                _table.AutoUpdateAfterCallBack = value;
            }
        }

        public new virtual bool UpdateAfterCallBack
        {
            get
            {
                return _table.UpdateAfterCallBack;
            }
            set
            {
                this._table.UpdateAfterCallBack = value;
            }
        }

        /// <summary>
        /// Le contr�le label est visible ou non
        /// </summary>
        public bool ShowLabel
        {
            get{return _showLabel;}
            set { _showLabel = value; }
        }

        /// <summary>
        /// Est ce que la page qui contient le contr�le est une page QXP?
        /// </summary>
        public bool PageIsQXPPage
        {
            get { return _pageIsQXPPage; }
            set { _pageIsQXPPage = value; }
        }

        #region Resources

        /// <summary>Gets or sets the tooltip text of the <see cref="QXPWUIBasic.Label"/> inserted in the <c>Label Zone</c>. </summary>
        public override string ToolTip
        {
            get { return _label.ToolTip; }
            set { _label.ToolTip = value; }
        }

        /// <summary>Gets or sets the text of the <see cref="QXPWUIBasic.Label"/> inserted in the <c>Label Zone</c>. </summary>
        public string Label
        {
            get { return (_label.Text); }
            set { _label.Text = value; }
        }

        public QXPResources.ResourceInfo ResourceInfo
        {
            get { return _resourceInfo; }
        }

        #endregion Resources

        #endregion Propri�t�s
    }
}
