using System.Web.UI;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>
    /// Interface IDropDownList
    /// </summary>
    /// <remarks>Seule solution pour pouvoir cr�er des listes g�n�riques de BaseDropDownList... En attente du Frk .NET 4 qui le permet</remarks>
    /// <author>LCU</author>
    /// <date>06/05/2011</date>    
    public interface IDropDownList
    {
        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Valeur vide du DropDownList
        /// </summary>
        object EmptyValue
        {
            get;
        }

        /// <summary>
        /// Client ID du Feature
        /// </summary>
        string FeatureClientID
        {
            get;
        }

        /// <summary>
        /// Attributes du Feature
        /// </summary>
        AttributeCollection FeatureAttributes
        {
            get;
        }

        #endregion Propri�t�s
    }			
}
