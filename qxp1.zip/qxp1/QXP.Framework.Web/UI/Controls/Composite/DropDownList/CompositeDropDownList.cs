using System;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>
    /// Composite DropDownList
    /// </summary>
    /// <author>LCU</author>
    /// <date>13/01/2011</date>    
    public class DropDownList : BaseDropDownList<Basic.DropDownList>
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new instance of <see cref="DropDownList"/> control. </summary>
        public DropDownList()
            : base()
        {
        }

        /// <summary>Creates a new instance of <see cref="DropDownList"/> control which values have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        public DropDownList(Type type) : base(type)            
        {
        }

        /// <summary>Creates a new instance of <see cref="DropDownList"/> control with specified <paramref name="labelText"/> text, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the dropdownlist. </param>
        public DropDownList(System.Type type, string labelText)
            : base(type, labelText)
        {
        }

        /// <summary>Creates a new instance of <see cref="DropDownList"/> control with specified <paramref name="labelText"/> text and <paramref name="readOnly"/>, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the dropdownlist. </param>
        /// <param name="readOnly"><see langword="true"/> if the dropdownlist is readonly otherwise <see langword="false"/>. </param>
        public DropDownList(System.Type type, string labelText, bool readOnly)
            : base(type, labelText, readOnly)
        { 
        }

        /// <summary>Creates a new instance of <see cref="DropDownList"/> control with specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="isRequired"/> , it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the dropdownlist. </param>
        /// <param name="readOnly"><see langword="true"/> if the dropdownlist is readonly otherwise <see langword="false"/>. </param>
        /// <param name="isRequired"><see langword="true"/> if the dropdownlist is required otherwise <see langword="false"/>. </param>
        public DropDownList(System.Type type, string labelText, bool readOnly, bool isRequired)
            : base(type, labelText, readOnly, isRequired)
        {
        }

        /// <summary>Creates a new instance of <see cref="DropDownList"/> control with specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the dropdownlist. </param>
        /// <param name="readOnly"><see langword="true"/> if the dropdownlist is readonly otherwise <see langword="false"/>. </param>
        /// <param name="isRequired"><see langword="true"/> if the dropdownlist is required otherwise <see langword="false"/>. </param>
        /// <param name="defaultValue">The <see cref="Object"/> default value of the dropdownlist. </param>
        public DropDownList(System.Type type, string labelText, bool readOnly, bool isRequired, object defaultValue)
            : base(type, labelText, readOnly, isRequired, defaultValue)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}