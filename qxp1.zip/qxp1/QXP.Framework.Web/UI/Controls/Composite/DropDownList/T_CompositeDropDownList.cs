using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>
    /// Composite DropDownList de T
    /// </summary>
    /// <author>LCU</author>
    /// <date>13/01/2011</date>    
    public class DropDownList<T> : BaseDropDownList<Basic.DropDownList<T>>
        where T : new()
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new instance of <see cref="DropDownList"/> control. </summary>
        public DropDownList() : base()
        {
            this.EnabledValidationBasedOfDataType = false;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// D�finit le type de donn�es du composite associ�e � la propri�t� identifi� par la DataSelectedValueField sur l'objet T
        /// </summary>
        private void SetDataType()
        {
          PropertyInfo __property = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance).First(property => property.Name == this.DataSelectedValueField);
          this.DataType = __property.PropertyType;
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Valeur de type <typeparam name="T">Type de l'objet</typeparam> s�lectionn� par d�faut
        /// </summary>
        public T DefaultValueObject
        {
            get { return this.Feature.DefaultValueObject; }
            set
            {                
                this.Feature.DefaultValueObject = value;
                base.DefaultValue = this.Feature.DefaultValue;
            }
        }

        /// <summary>
        /// Valeur de type <typeparam name="T">Type de l'objet</typeparam> s�lectionn�
        /// </summary>
        protected T FeatureDataObject
        {
            get
            {
                if (this.IsEmptySelected) 
                    return default(T);
                return this.Feature.SelectedValueObject;
            }
            set { this.Feature.SelectedValueObject = value; }
        }

        /// <summary>
        /// Data de type <typeparam name="T">Type de l'objet</typeparam> s�lectionn�
        /// </summary>
        public T DataObject
        {
            get
            {
                return this.FeatureDataObject;
            }
            set
            {
                if (_isInitialized) 
                    this.FeatureDataObject = value;
            }
        }

        /// <summary>Gets or sets the data source that populates the items of the list control. </summary>
        public new IEnumerable<T> DataSource
        {
            get { return this.Feature.DataSource; }
            set { this.Feature.DataSource = value; }
        }

        /// <summary>Gets or sets the field of the data source that provides the value of each list item. </summary>
        public IEnumerable<string> DataTextFields
        {
            get { return this.Feature.DataTextFields; }
            set { this.Feature.DataTextFields = value; }
        }

        /// <summary>
        /// Liste des DataTextField � utiliser lors du binding (chaque DataTextField sera affich�e)
        /// </summary>
        public IEnumerable<string> DataValueFields
        {
            get { return this.Feature.DataValueFields; }
            set { this.Feature.DataValueFields = value; }
        }

        /// <summary>
        /// Nom de la prori�t� d�finissant la cl� primaire de l'objet
        /// (Utilis� notamment pour reselectionner un �l�ment du dropdownlist)
        /// </summary>
        public string DataSelectedValueField
        {
            get
            {                
                return Feature.DataSelectedValueField;
            }
            set
            {                
                Feature.DataSelectedValueField = value;
                SetDataType();
            }
        }

        #endregion Propri�t�s
    }
}