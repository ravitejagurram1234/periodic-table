using System;
using System.Web.UI;

namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>
    /// Class de base des composites DropDownList
    /// </summary>
    /// <author>LCU</author>
    /// <date></date>    
    public abstract class BaseDropDownList<BasicDropDownList> : BaseComposite, IDropDownList
        where BasicDropDownList : Basic.BaseDropDownList
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new instance of <see cref="BaseDropDownList"/> control. </summary>
        public BaseDropDownList() : base(typeof(BasicDropDownList), Composite.CssClass.cps_ddl.ToString()) 
        { 
        }

        /// <summary>Creates a new instance of <see cref="BaseDropDownList"/> control which values have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        public BaseDropDownList(Type type)
            : this()
        {
            this.DataType = type;
        }

        /// <summary>Creates a new instance of <see cref="BaseDropDownList"/> control with specified <paramref name="labelText"/> text, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the dropdownlist. </param>
        public BaseDropDownList(System.Type type, string labelText)
            : this(type)
        {
            if (Validation.IsSet(labelText)) 
                this.Label = labelText;
        }

        /// <summary>Creates a new instance of <see cref="BaseDropDownList"/> control with specified <paramref name="labelText"/> text and <paramref name="readOnly"/>, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the dropdownlist. </param>
        /// <param name="readOnly"><see langword="true"/> if the dropdownlist is readonly otherwise <see langword="false"/>. </param>
        public BaseDropDownList(System.Type type, string labelText, bool readOnly)
            : this(type, labelText)
        {
            this.ReadOnly = readOnly;
        }

        /// <summary>Creates a new instance of <see cref="BaseDropDownList"/> control with specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="isRequired"/> , it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the dropdownlist. </param>
        /// <param name="readOnly"><see langword="true"/> if the dropdownlist is readonly otherwise <see langword="false"/>. </param>
        /// <param name="isRequired"><see langword="true"/> if the dropdownlist is required otherwise <see langword="false"/>. </param>
        public BaseDropDownList(System.Type type, string labelText, bool readOnly, bool isRequired)
            : this(type, labelText, readOnly)
        {
            this.IsRequired = isRequired;
        }

        /// <summary>Creates a new instance of <see cref="BaseDropDownList"/> control with specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
        /// <param name="type">The <see cref="Type"/> data type of item value. </param>
        /// <param name="labelText">The text label of the dropdownlist. </param>
        /// <param name="readOnly"><see langword="true"/> if the dropdownlist is readonly otherwise <see langword="false"/>. </param>
        /// <param name="isRequired"><see langword="true"/> if the dropdownlist is required otherwise <see langword="false"/>. </param>
        /// <param name="defaultValue">The <see cref="Object"/> default value of the dropdownlist. </param>
        public BaseDropDownList(System.Type type, string labelText, bool readOnly, bool isRequired, object defaultValue)
            : this(type, labelText, readOnly, isRequired)
        {
            this.DefaultValue = defaultValue;
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>Gets or sets the default value of the <see cref="BaseDropDownList"/> control. </summary>
        public override object DefaultValue
        {
            get { return (base.DefaultValue); }
            set
            {
                base.DefaultValue = value;
                this.Feature.DefaultValue = base.DefaultValue;
            }
        }
        
        /// <summary>Gets or sets the data of the <see cref="BaseDropDownList"/>. </summary>
        protected override object FeatureData
        {
            get
            {
                if (this.IsEmptySelected) return null;
                return this.Feature.SelectedValue;
            }
            set { this.Feature.SelectedValue = Conversion.ToString(value); }
        }
        
        /// <summary>Gets the text of the selected item. </summary>
        public override string Text
        {
            get { return this.Feature.SelectedText; }
        }
        
        /// <summary>Gets the initial value of the required validator. </summary>
        protected override object RequiredInitialValue
        {
            get { return this.EmptyValue; }
        }

        /// <summary>Gets the BasicDropDownList of the <see cref="BaseDropDownList"/>. </summary>
        public new BasicDropDownList Feature
        {
            get { return (BasicDropDownList)base._feature; }
        }

        /// <summary>Gets or sets the data source that populates the items of the list control. </summary>
        public object DataSource
        {
            get { return this.Feature.DataSource; }
            set { this.Feature.DataSource = value; }
        }

        /// <summary>Gets or sets the specific member in the <see cref="DataSource"/> to bind to the control. </summary>
        public string DataMember
        {
            get { return this.Feature.DataMember; }
            set { this.Feature.DataMember = value; }
        }
        
        /// <summary>Gets or sets the field of the data source that provides the value of each list item. </summary>
        public string DataValueField
        {
            get { return this.Feature.DataValueField; }
            set { this.Feature.DataValueField = value; }
        }
        
        /// <summary>Gets or sets the field of the data source that provides the text content of the list items. </summary>
        public string DataTextField
        {
            get { return this.Feature.DataTextField; }
            set { this.Feature.DataTextField = value; }
        }
        
        /// <summary>Gets or sets the formatting string used to control how data bound to the list control is displayed. </summary>
        public string DataTextFormatString
        {
            get { return this.Feature.DataTextFormatString; }
            set { this.Feature.DataTextFormatString = value; }
        }
        
        /// <summary>Gets or sets if Empty Item will be added in the items list. </summary>
        /// <remarks>This Empty item can be used to simulate a none selection. </remarks>
        public bool EnableEmptySelection
        {
            get { return this.Feature.EnableEmptySelection; }
            set { this.Feature.EnableEmptySelection = value; }
        }
        
        /// <summary>Gets or sets the <c>Empty Item</c> value. </summary>
        public object EmptyValue
        {
            get { return Conversion.ToObject(this.Feature.EmptyValue, this.DataType); }
            set { this.Feature.EmptyValue = Conversion.ToString(value); }
        }
        
        /// <summary>Gets or sets the <c>Empty Item</c> Text. </summary>
        public string EmptyText
        {
            get { return this.Feature.EmptyText; }
            set { this.Feature.EmptyText = value; }
        }
        
        /// <summary>Determines whether Empty Item is currently selected. </summary>
        public bool IsEmptySelected
        {
            get { return this.Feature.IsEmptySelected; }
        }
        
        /// <summary>Gets or sets the maximum number of items displayed in the list. </summary>
        public int MaxItemsCount
        {
            get { return this.Feature.MaxItemsCount; }
            set { this.Feature.MaxItemsCount = value; }
        }
        
        /// <summary>Gets or sets the maximum number of item text length. </summary>
        public int MaxTextLength
        {
            get { return this.Feature.MaxTextLength; }
            set { this.Feature.MaxTextLength = value; }
        }
        
        /// <summary>Gets or sets whether the items in the list are sorted. </summary>
        public bool IsSorted
        {
            get { return this.Feature.IsSorted; }
            set { this.Feature.IsSorted = value; }
        }
        
        /// <summary>Gets the Text of the selected item. </summary>
        public string DataText
        {
            get { return this.Feature.SelectedText; }
        }
        
        /// <summary>Gets or sets if <see cref="BaseDropDownList"/> selection change generated a post back event. </summary>
        public bool AutoPostBack
        {
            get { return this.Feature.AutoPostBack; }
            set { this.Feature.AutoPostBack = value; }
        }
        
        /// <summary>Gets or sets if <see cref="CheckBox"/> change generated a call back event. </summary>
        public bool AutoCallBack
        {
            get { return this.Feature.AutoCallBack; }
            set { this.Feature.AutoCallBack = value; }
        }
        
        /// <summary>Gets or sets if the control raise callback event (otherwise it raise postback event). </summary>
        public bool EnableCallBack
        {
            get { return this.Feature.EnableCallBack; }
            set { this.Feature.EnableCallBack = value; }
        }
        
        public bool CauseValidation
        {
            get { return this.Feature.CausesValidation; }
            set { this.Feature.CausesValidation = value; }
        }
        
        /// <summary>Gets the selected item index. </summary>
        public int SelectedIndex
        {
            get { return this.Feature.SelectedIndex; }
        }
        
        /// <summary>Occurs when the selected item change. </summary>
        public event EventHandler SelectedIndexChanged
        {
            add { this.Feature.SelectedIndexChanged += value; }
            remove { this.Feature.SelectedIndexChanged -= value; }
        }
        
        public int ItemsCount
        {
            get { return this.Feature.Items.Count; }
        }
        
        public bool DisableAutoComplete
        {
            get { return this.Feature.DisableAutoComplete; }
            set { this.Feature.DisableAutoComplete = value; }
        }
        
        public string AutoComplete_OnChange
        {
            get { return this.Feature.AutoComplete_OnChange; }
            set { this.Feature.AutoComplete_OnChange = value; }
        }

        /// <summary>
        /// Type d'ajaxisation
        /// </summary>
        public new Anthem.AjaxMode AjaxMode
        {
            get { return this.Feature.AjaxMode; }
            set { this.Feature.AjaxMode = value; }
        }

        /// <summary>
        /// Client ID du Feature
        /// </summary>
        public string FeatureClientID
        {
            get { return _feature.ClientID; }
        }

        /// <summary>
        /// Attributes du Feature
        /// </summary>
        public AttributeCollection FeatureAttributes
        {
            get { return _feature.Attributes; }
        }

        #endregion Propri�t�s
    }
}