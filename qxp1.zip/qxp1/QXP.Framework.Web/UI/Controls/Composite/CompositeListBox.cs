using System;
using System.Web.UI;

using QXPWUIBasic									= QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Composite
{
	/// <summary>Provides methods and properties for a labeled <see cref="QXPWUIBasic.ListBox"/> control. <seealso cref="BaseComposite"/></summary>
	public class ListBox: BaseComposite{
		#region Construtors
		/// <summary>Creates a new instance of <see cref="ListBox"/> control. </summary>
		public ListBox(): base(QXPWUIBasic.BasicType.ListBox, Composite.CssClass.cps_lstbx.ToString()){}
		/// <summary>Creates a new instance of <see cref="ListBox"/> control which values have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of item value. </param>
		public ListBox(Type type): this(){
			this.DataType = type;
		}
		/// <summary>Creates a new instance of <see cref="ListBox"/> control with specified <paramref name="labelText"/> text, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of item value. </param>
		/// <param name="labelText">The text label of the ListBox. </param>
		public ListBox(System.Type type, string labelText): this(type){
			if(Validation.IsSet(labelText)) this.Label				= labelText; 
		}
		/// <summary>Creates a new instance of <see cref="ListBox"/> control with specified <paramref name="labelText"/> text and <paramref name="readOnly"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of item value. </param>
		/// <param name="labelText">The text label of the ListBox. </param>
		/// <param name="readOnly"><see langword="true"/> if the ListBox is readonly otherwise <see langword="false"/>. </param>
		public ListBox(System.Type type, string labelText, bool readOnly): this(type, labelText){
			this.ReadOnly = readOnly;
		}
		/// <summary>Creates a new instance of <see cref="ListBox"/> control with specified <paramref name="labelText"/> text, <paramref name="readOnly"/> and <paramref name="isRequired"/> , it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of item value. </param>
		/// <param name="labelText">The text label of the ListBox. </param>
		/// <param name="readOnly"><see langword="true"/> if the ListBox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the ListBox is required otherwise <see langword="false"/>. </param>
		public ListBox(System.Type type, string labelText, bool readOnly, bool isRequired): this(type, labelText, readOnly){
			this.IsRequired = isRequired;
		}
		/// <summary>Creates a new instance of <see cref="ListBox"/> control with specified <paramref name="labelText"/> text, <paramref name="readOnly"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>, it's value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of item value. </param>
		/// <param name="labelText">The text label of the ListBox. </param>
		/// <param name="readOnly"><see langword="true"/> if the ListBox is readonly otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the ListBox is required otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> default value of the ListBox. </param>
		public ListBox(System.Type type, string labelText, bool readOnly, bool isRequired, object defaultValue): this(type, labelText, readOnly, isRequired){
			this.DefaultValue = defaultValue;
		}
		#endregion
		/// <summary>Gets or sets the default value of the <see cref="ListBox"/> control. </summary>
		public		override		object					DefaultValue{
			get{return(base.DefaultValue);}
			set{
				base.DefaultValue					=	value;
				this.Feature.DefaultValue	= base.DefaultValue;
			}
		}
		/// <summary>Gets or sets the data of the <see cref="ListBox"/>. </summary>
		protected override	object							FeatureData{
			get{
				//TODO: !!
				//if(this.IsEmptySelected) return null;
				if(this.EnableMultiSelection)	return this.Feature.SelectedValues;
				else							return this.Feature.SelectedValue;
			}
			set{
				if(this.EnableMultiSelection)	this.Feature.SelectedValues = Conversion.ToStringArray(value);
				else							this.Feature.SelectedValue	= Conversion.ToString(value);
			}
		}
		/// <summary>Gets the initial value of the required validator. </summary>
		protected	override		object					RequiredInitialValue{
			get{return string.Empty;}
		}
		public		new QXPWUIBasic.ListBox					Feature{
			get{return (QXPWUIBasic.ListBox)base._feature;}
		}
		/// <summary>Gets the text of the selected item. </summary>
		public		override		string					Text
		{
			get{return string.Empty;}
		}
		#region Feature Wrapper
		/// <summary>Gets or sets the data source that populates the items of the list control. </summary>
		public object										DataSource
		{
			get{return this.Feature.DataSource;}
			set{this.Feature.DataSource = value ;}
		}
		/// <summary>Gets or sets the specific memeber in the <see cref="DataSource"/> to bind to the control. </summary>
		public string										DataMember{
			get{return this.Feature.DataMember;}
			set{this.Feature.DataMember = value;}
		}
		/// <summary>Gets or sets the field of the data source that provides the value of each list item. </summary>
		public string										DataValueField{
			get{return this.Feature.DataValueField;}
			set{this.Feature.DataValueField = value ;}
		}
		/// <summary>Gets or sets the field of the data source that provides the text content of the list items. </summary>
		public string										DataTextField{
			get{return this.Feature.DataTextField;}
			set{this.Feature.DataTextField = value ;}
		}
		/// <summary>Gets or sets the formatting string used to control how data bound to the list control is displayed. </summary>
		public string										DataTextFormatString{
			get{return this.Feature.DataTextFormatString;}
			set{this.Feature.DataTextFormatString = value ;}
		}
		/// <summary>Gets or sets the maximum number of items displayed in the list. </summary>
		public int											MaxItemsCount{
			get{return this.Feature.MaxItemsCount;}
			set{this.Feature.MaxItemsCount = value ;}
		}
		/// <summary>Gets or sets the maximum number of item text length. </summary>
		public int											MaxTextLength{
			get{return this.Feature.MaxTextLength;}
			set{this.Feature.MaxTextLength = value ;}
		}
		/// <summary>Gets or sets whether the items in the list are sorted. </summary>
		public bool											IsSorted{
			get{return this.Feature.IsSorted;}
			set{this.Feature.IsSorted = value ;}
		}
		/// <summary>Gets or sets if <see cref="ListBox"/> selection change generated a post back event. </summary>
		public bool											AutoPostBack{
			get{return this.Feature.AutoPostBack;}
			set{this.Feature.AutoPostBack = value;}
		}
		/// <summary>Gets or sets if <see cref="ListBox"/> change generated a call back event. </summary>
		public							bool		        AutoCallBack{
			get{return this.Feature.AutoCallBack;}
			set{this.Feature.AutoCallBack = value;}
		}
        /// <summary>Gets or sets if the control raise callback event (otherwise it raise postback event). </summary>
		public bool									        EnableCallBack{
			get{return this.Feature.EnableCallBack;}
			set{this.Feature.EnableCallBack = value;}
		}
        public      bool                                    CauseValidation{
            get{return this.Feature.CausesValidation;}
            set{this.Feature.CausesValidation = value;}
        }
		/// <summary>Gets or sets <see cref="ListBox"/> number of simultaneous displayed rows. </summary>
		public int											Rows
		{
			get{return this.Feature.Rows;}
			set{this.Feature.Rows = value;}
		}
		/// <summary>Gets the selected item index. </summary>
		public int											SelectedIndex
		{
			get{return this.Feature.SelectedIndex;}
		}
		/// <summary>Occurs when the selected item change. </summary>
		public event EventHandler							SelectedIndexChanged{
			add{this.Feature.SelectedIndexChanged += value;}
			remove{this.Feature.SelectedIndexChanged -= value;}
		}
		public bool											EnableMultiSelection{
			get{return this.Feature.EnableMultiSelection;}
			set{this.Feature.EnableMultiSelection = value;}
		}
		public int											ItemsCount{
			get{return this.Feature.Items.Count;}
		}
		public bool											DisableAutoComplete
		{
			get{return this.Feature.DisableAutoComplete;}
			set{this.Feature.DisableAutoComplete = value;}
		}
		public string								        AutoComplete_OnChange
		{
			get{return this.Feature.AutoComplete_OnChange;}
			set{this.Feature.AutoComplete_OnChange = value;}
		}
		#endregion
	}
}
