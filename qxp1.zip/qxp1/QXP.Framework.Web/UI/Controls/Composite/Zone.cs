using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Web.UI.Controls.Composite
{
    /// <summary>
    /// Objet Zone
    /// </summary>
    /// <author>cueffl</author>
    /// <date>19/01/2011 13:34:26</date>    
    public class Zone
    {
        #region Membres

        public QXPWUIBasic.ItemSection Label;
        public QXPWUIBasic.ItemSection Feature;
        public QXPWUIBasic.ItemSection Validator;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de Zone
        /// </summary>
        public Zone()
        {
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
