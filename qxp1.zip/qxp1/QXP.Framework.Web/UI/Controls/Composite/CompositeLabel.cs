using System;
using System.Web;
using System.Web.UI.WebControls;

using QXPWUIBasic									= QXP.Framework.Web.UI.Controls.Basic;

namespace QXP.Framework.Web.UI.Controls.Composite
{
	/// <summary>Provides methods	and properties for a labeled <see cref="QXPWUIBasic.Label"/> control. <seealso cref="BaseComposite"/></summary>
	public class Label: BaseComposite{
		#region internal variables
		private	int			_maxLength = 0;
		#endregion
		#region Construtors
		/// <summary>Creates a new instance of <see cref="Label"/> control. </summary>
		public Label(): base(QXPWUIBasic.BasicType.Label, Composite.CssClass.cps_lbl.ToString()){}
		/// <summary>Creates a new instance of <see cref="Label"/> control which label value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of label value. </param>
		public Label(Type type): this(){
			this.DataType = type;
		}
		/// <summary>Creates a new instance of <see cref="Label"/> control with specified <paramref name="labelText"/> text, it's label value have (<paramref name="type"/>) data type. </summary>
		/// <param name="type">The <see cref="Type"/> data type of label value. </param>
		/// <param name="labelText">The text label of the textbox. </param>
		public Label(System.Type type, string labelText): this(type){
			if(Validation.IsSet(labelText)) this.Label				= labelText; 
		}
		#endregion
		/// <summary>Gets or sets the data of the <see cref="Label"/>. </summary>
		protected override object					FeatureData{
			get{return this.ViewState[KeyData];} //INFO: retrieve data directly from viewState:
			set{string __text = Conversion.ToString(value, this.Format);
				if(_maxLength != 0 && __text.Length > _maxLength)	__text = StringHelper.StartString(__text, _maxLength);
                this.Feature.Text = StringHelper.ConvertTextForWeb(HttpUtility.HtmlEncode(__text));                
			}
		}
		public		new QXPWUIBasic.Label				Feature{
			get{return (QXPWUIBasic.Label)base._feature;}
		}
		/// <summary>Gets the text of the <see cref="Data"/> value. </summary>
		public		override		string			Text{
			get{return this.Feature.Text;}
		}
		/// <summary>Gets or sets the maximum number of characters allowed in the data label. </summary>
		public		int								MaxLength{
			get{return _maxLength;}
			set{_maxLength = value;}
		}
	}
}
