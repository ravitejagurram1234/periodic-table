using System;
using System.Collections.Specialized;
using System.Web.UI.WebControls;

using QXPApplication			= QXP.Framework.Application;
using QXPWUIBasic				= QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIValidator			= QXP.Framework.Web.UI.Controls.Validator;

namespace QXP.Framework.Web.UI.Controls.Composite
{
	/// <summary>Provides methods and properties for a regular expression text box control. </summary>
	public class RegularTextBox: TextBox
	{
		#region internal variables
		private RegularExpressionType _expressionType = RegularExpressionType.Custom;
		private string								_customExpression;
		private string								_regularMessageValidator;
		private string								_regularToolTipValidator;
		private static ListDictionary _commonExpressions;
		private const string					EmailExpression = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})";
		private const string					URLExpression		= @"^((http|https|ftp)(\:\/\/))((\w*\:\w*)\@)?([a-zA-Z]|[\.\-])+((:(([1-5]?[0-9]{1,4})|(6(([0-4][0-9]{0,3})|(5[0-5][0-3][0-5])))))?|[^:])(\/\S*)?$";
		private const string					IPExpression		= @"^([0-1]?[0-9]{0,2}|2?[0-5]{0,2})\.([0-1]?[0-9]{0,2}|2?[0-5]{0,2})\.([0-1]?[0-9]{0,2}|2?[0-5]{0,2})\.([0-1]?[0-9]{0,2}|2?[0-5]{0,2})$";
		//INFO: match 6 to 15 characters with at least one alphabetic and one numeric
		private const string					PwdExpression		= @"^.*(?=.{6,15})(?=.*\d)(?=.*[a-zA-Z]).*$"; // @"(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{6,15})$";
		
		#endregion
		#region Construtors
		static RegularTextBox()
		{
			_commonExpressions = new ListDictionary();
			_commonExpressions.Add(RegularExpressionType.Email, EmailExpression);
			_commonExpressions.Add(RegularExpressionType.Password, PwdExpression);
			_commonExpressions.Add(RegularExpressionType.IPAddress, IPExpression);
			_commonExpressions.Add(RegularExpressionType.URL, URLExpression);
		}

		public		RegularTextBox()
		{
		}

		/// <summary>Creates a new instance of <see cref="RegularTextBox"/> control with the specified <paramref name="label"/>. </summary>
		/// <param name="label">The <see cref="String"/> text label of the control.  </param>
		public		RegularTextBox(string label): base(ValueType.CLSstring, label)
		{
			this.CssClass = Composite.CssClass.cps_rgltbx.ToString();
		}
		/// <summary>Creates a new instance of <see cref="RegularTextBox"/> control with the specified <paramref name="label"/>, <paramref name="isreadOnly"/> and <paramref name="isRequired"/>. </summary>
		/// <param name="label">The <see cref="String"/> text label of the control.  </param>
		/// <param name="isReadOnly"><see langword="true"/> if the control have a readonly state. otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the control is required. otherwise <see langword="false"/>. </param>
		public		RegularTextBox(string label, bool isReadOnly, bool isRequired): base(ValueType.CLSstring, label, isReadOnly, isRequired)
		{
			this.CssClass = Composite.CssClass.cps_rgltbx.ToString();
		}
		/// <summary>Creates a new instance of <see cref="RegularTextBox"/> control with the specified <paramref name="label"/>, <paramref name="isreadOnly"/>, <paramref name="isRequired"/> and <paramref name="defaultValue"/>. </summary>
		/// <param name="label">The <see cref="String"/> text label of the control.  </param>
		/// <param name="isReadOnly"><see langword="true"/> if the control have a readonly state. otherwise <see langword="false"/>. </param>
		/// <param name="isRequired"><see langword="true"/> if the control is required. otherwise <see langword="false"/>. </param>
		/// <param name="defaultValue">The <see cref="Object"/> dafault value of the control. </param>
		public		RegularTextBox(string label, bool isReadOnly, bool isRequired, object defaultValue): base(ValueType.CLSstring, label, isReadOnly, isRequired, defaultValue)
		{
			this.CssClass = Composite.CssClass.cps_rgltbx.ToString();
		}
		#endregion
		/// <summary>Occurs when the control need to creates it's contained validators. </summary>
		protected	override		void			CreateValidators()
		{
			string __expression = string.Empty;
			if(_expressionType == RegularExpressionType.Custom)
			{
				__expression = _customExpression;
			}
			else
			{
				__expression = this.GetCommonExpression(_expressionType);
			}
			if(Validation.IsSet(__expression))
			{
				QXPWUIValidator.RegularExpressionValidator __validator = new QXPWUIValidator.RegularExpressionValidator();
                __validator.ErrorMessage            = this.RegularExpressionMessageValidator;
                __validator.ToolTip                 = this.RegularExpressionToolTipValidator;
                __validator.ValidationExpression    = __expression;
				this.AddValidator(__validator);
			}
			base.CreateValidators();
		}
		/// <summary>Gets or sets the <see cref="RegularExpressionType"/> of validation. </summary>
		public		RegularExpressionType			ExpressionType
		{
			get{return _expressionType;}
			set{_expressionType = value;}
		}
		/// <summary>Gets or sets the custom regular expression. </summary>
		public							string		CustomExpression
		{
			get{return _customExpression;}
			set
			{
				_customExpression = value;
				_expressionType = RegularExpressionType.Custom;
			}
		}
		/// <summary>Gets or sets the localized message of the regular expression validator. </summary>
		public							string		RegularExpressionMessageValidator
		{
			get{
				if(Validation.IsSet(_regularMessageValidator))	return _regularMessageValidator;
				else											return QXPApplication.Application.Resources.GetGlobalValidator(this.ExpressionType, this.Label);
			}
			set{_regularMessageValidator = value;}
		}

		/// <summary>Gets or sets the localized tooltip message of the regular expression validator. </summary>
		public							string		RegularExpressionToolTipValidator
		{
			get{return _regularToolTipValidator;}
			set{_regularToolTipValidator = value;}
		}
		private		string							GetCommonExpression(RegularExpressionType type)
		{
			if(_commonExpressions.Contains(type))
			{
				return Conversion.ToString(_commonExpressions[type]);
			}
			else
			{
				return string.Empty;
			}
		}
	}
}
