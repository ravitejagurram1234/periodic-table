using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Web.UI.Controls
{
	public interface IControlValueManager
	{
		void Load(IInfoControlValue info, IControlTag[] controls);
		void Save(IInfoControlValue info, IControlTag[] controls);
	}
}
