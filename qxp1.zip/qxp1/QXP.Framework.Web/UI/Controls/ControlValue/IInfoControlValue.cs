using System;
using System.Collections.Generic;
using System.Text;

namespace QXP.Framework.Web.UI.Controls
{
	public interface IInfoControlValue
	{
		/// <summary>
		/// Nom de la colonne contenant les identifiants 
		/// </summary>
		string IdNameColonne
		{
			get;
			set;
		}
		/// <summary>
		/// Nom de la table o� charger/sauvegarder les valeurs
		/// </summary>
		string NameTable
		{
			get;
			set;
		}
		/// <summary>
		/// Nom du package � utiliser pour charger/sauvegarder les valeurs 
		/// </summary>
		string PackageName
		{
			get;
			set;
		}

		/// <summary>
		/// Fonction � utiliser pour les suppressions de ControlValue
		/// </summary>
		string DeleteFonctionName
		{
			get;
			set;
		}

		/// <summary>
		/// Fonction � utiliser pour les insertions de ControlValue
		/// </summary>
		string InsertFonctionName
		{
			get;
			set;
		}

		/// <summary>
		/// Fonction � utiliser pour obtenir les ControlValue
		/// </summary>
		string GetFonctionName
		{
			get;
			set;
		}

		/// <summary>
		/// Nom du composant associ� aux valeurs des controles (exemple SelectionListeValidationsVL)
		/// </summary>
		string	Composant
		{
			get;
			set;
		}
		/// <summary>
		/// Identifiant associ� aux valeurs des controles (exemple id_utilisateur)
		/// </summary>
		int		Id
		{
			get;
			set;
		}
	}
}
