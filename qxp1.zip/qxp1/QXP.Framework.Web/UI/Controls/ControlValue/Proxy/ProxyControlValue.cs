using System;
using System.Data;
using Oracle.DataAccess.Client;
using QXPDataOracle = QXP.Framework.Data.Oracle;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPProxy = QXP.Framework.Proxy;


namespace QXP.Framework.Web.UI.Controls.Proxy
{
    /// <summary>
    /// Proxy ProxyControlValue
    /// </summary>
    /// <author>doufarm</author>
    /// <date>11/03/2009 17:21:58</date>    
    public class ProxyControlValue : QXPProxy.BaseProxy
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de ProxyControlValue
        /// </summary>
        public ProxyControlValue()
        {
        }

        /// <summary>
        /// Cr�e une instance de ProxyControlValue
        /// </summary>
        /// <param name="oraClient">Connexion Oracle</param>
        public ProxyControlValue(QXPDataOracle.OraClient oraClient)
            : base(oraClient)
        {
        }

        /// <summary>
        /// Cr�e une instance de ProxyControlValue
        /// </summary>
        /// <param name="dataBase">Nom de la cl� DataBase situ� dans le fichier .config de l'application (associ�e � une chaine de connexion)</param>
        public ProxyControlValue(string dataBase)
            : base(dataBase)
        {
        }

        #endregion Constructeur

        #region M�thodes

        #region Acc�s Base

        #region SELECT

        /*
         * Utiliser ici les QXPSnippet Proxy pour g�n�rer automatiquement un squelette de code pour les acc�s SELECT � la base de donn�es
         */

        #endregion SELECT

        #region INSERT / UPDATE / DELETE

        /// <summary>
        /// Insert une liste de controlValue dans la base de donn�e en fonction des crit�re info
        /// </summary>
        /// <param name="info">IInfoControlValue</param>
        /// <param name="values">Valeurs � sauvegarder</param>
        public void InsertListeControlValue(IInfoControlValue info, ListControlValue values)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;

            #endregion Variables


            string __package = string.Format(info.PackageName, this.SitePrefix);

            try
            {
                this.OracleClient.BeginTransaction();

                __sql = string.Concat(__package, info.DeleteFonctionName);

                #region Definition des OraParameters
                __oraParameters.AddParameterToSqlParamList("p_IdNameColonne", info.IdNameColonne)
                                .AddParameterToSqlParamList("p_NameTable", string.Format(info.NameTable, SitePrefix))
                                .AddParameterToSqlParamList("p_Id", info.Id)
                                .AddParameterToSqlParamList("p_Composant", info.Composant);
                #endregion Definition des OraParameters

                __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

                this.Execute(__sqlRequest);

                __sql = string.Concat(__package, info.InsertFonctionName);

                foreach (ControlValue __controlValue in values.Values)
                {
                    #region Definition des OraParameters
                    __oraParameters.Clear();
                    __oraParameters.AddParameterToSqlParamList("p_IdNameColonne", info.IdNameColonne)
                                .AddParameterToSqlParamList("p_NameTable", string.Format(info.NameTable, SitePrefix))
                                .AddParameterToSqlParamList("p_Id", info.Id)
                                .AddParameterToSqlParamList("p_Composant", info.Composant)
                                .AddParameterToSqlParamList("p_Id_Control", __controlValue.ID_Control)
                                .AddParameterToSqlParamList("p_Valeur", __controlValue.Value);
                    #endregion Definition des OraParameters

                    __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

                    this.Execute(__sqlRequest);

                }

                this.OracleClient.CommitTransaction();
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("Erreur lors de l'insertion de object : ", ex);
                this.OracleClient.RollBackTransaction();
                throw;
            }
        }


        /// <summary>
        /// Retourne une liste de ControlValue de la base de donn�es
        /// </summary>
        /// <param name="info">IInfoControlValue</param>
        /// <returns>Liste de ControlValue</returns>
        public ListControlValue GetListControlValue(IInfoControlValue info)
        {
            #region Variables

            QXPDataOracle.OraParameterList __oraParameters = new QXPDataOracle.OraParameterList();
            QXPDataOracle.SQLRequest __sqlRequest = null;
            string __sql = string.Empty;
            ListControlValue __listControlValue = new ListControlValue();

            #endregion Variables

            #region Definition des OraParameters

            __oraParameters.AddParameterToSqlParamList("Cursor", OracleDbType.RefCursor, ParameterDirection.ReturnValue)
                            .AddParameterToSqlParamList("p_IdNameColonne", info.IdNameColonne)
                            .AddParameterToSqlParamList("p_NameTable", string.Format(info.NameTable, SitePrefix))
                            .AddParameterToSqlParamList("p_Id", info.Id)
                            .AddParameterToSqlParamList("p_Composant", info.Composant);

            #endregion Definition des OraParameters

            string __package = string.Format(info.PackageName, this.SitePrefix);

            __sql = string.Concat(__package, info.GetFonctionName);

            __sqlRequest = new QXPDataOracle.SQLRequest(CommandType.StoredProcedure, __sql, __oraParameters);

            using (QXPDataOracle.OraDataReader __odr = this.GetReader(__sqlRequest))
            {

                while (__odr.Read())
                {

                    ControlValue __controlValue = new ControlValue
                                    (
                                    __odr["ID_Control"]
                                    , __odr["Valeur"]
                                    );

                    if (!__listControlValue.ContainsKey(__controlValue.ID_Control))
                    {
                        __listControlValue.Add(__controlValue.ID_Control, __controlValue);
                    }
                }
            }

            return __listControlValue;
        }


        #endregion INSERT / UPDATE / DELETE

        #endregion Acc�s Base

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
