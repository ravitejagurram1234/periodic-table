using System;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPWUIComposite = QXP.Framework.Web.UI.Controls.Composite;
using QXPWUIExtended = QXP.Framework.Web.UI.Controls.Extended;

namespace QXP.Framework.Web.UI.Controls
{
    /// <summary>
    /// Ce Manager permet le chargement et la sauvegarde de la valeur des controles d'un composant
    /// Chaque valeur est d�termin�e pour un utilisateur un composant et un control
    /// l'identification ce fait par l'id_utilisateu
    /// l'identification du composant par son nom
    /// l'identification du control par la valeur mise dans la propri�t� Tag du control, cette valeur (une Enum) est d�fini pour chaque controle du composant
    /// Les valeurs de ces controles sont sauvegard�es dans la table QXP_CONTROLVALUE
    /// Les proc�dure stock�es utilis�es (par d�faut) sont pr�sentent dans le package QXP_PK_WEB.
    /// </summary>
    /// <author>doufarm</author>
    /// <date>11/03/2009 17:19:19</date>    
    public class ControlValueManager
    {
        #region Membres

        #endregion Membres

        #region Constantes
        const string join_string = "~";
        const char split_char = '~';
        const string range_join_pattern = "{0}~{1}";
        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Constructeur static ControlValueManager
        /// </summary>
        static ControlValueManager()
        {
        }

        #endregion Constructeur

        #region M�thodes
        #region Chargement des ControlValue

        /// <summary>
        /// Chargement des valeurs et mise � jour des controles
        /// </summary>
        /// <param name="info">Information permettant de retrouver les valeurs</param>
        /// <param name="controlsTag">Liste de controle � mettre � jour</param>
        public static void ChargementControlValue(IInfoControlValue info, IControlTag[] controlsTag)
        {
            if (Validation.IsNull(info)) return;
            try
            {
                if (Validation.IsSet(controlsTag))
                {
                    //r�cup�ration de toutes les valeurs pr�c�demment sauvegard�es pour les infos
                    ListControlValue __values = GetListControlValue(info);

                    //rien � faire !!
                    if (Validation.IsNotSet(__values)) return;

                    foreach (IControlTag __controlTag in controlsTag)
                    {
                        DefinirValeurControle(__controlTag, __values);
                    }
                }
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("ChargementControlValue", ex);
                throw;
            }

        }

        /// <summary>
        /// R�cup�ration de la liste des valeurs sauvegard�es
        /// </summary>
        /// <param name="info">information permettant de retrouver les valeurs</param>
        /// <returns>La liste des controlValues pr�c�demment sauvegard�e pour ces info</returns>
        static ListControlValue GetListControlValue(IInfoControlValue info)
        {
            Proxy.ProxyControlValue __proxy = new Proxy.ProxyControlValue();
            return __proxy.GetListControlValue(info);
        }

        /// <summary>
        /// Tentative de r�cup�rer une valeur d'un controle (si le controle et sa valeur existe)
        /// </summary>
        /// <param name="controlTag">le controle dont il faut retrouver sa valeur</param>
        /// <param name="values">la liste des valeurs possibles de tous les controles une d'elle doit avoir ID_Control = Tag du controle (controlTag)</param>
        /// <returns>Le controlValue si une valeur � �t� sauvegard�e pour ce controle.</returns>
        static ControlValue GetControlValue(IControlTag controlTag, ListControlValue values)
        {
            if (Validation.IsNull(controlTag) || Validation.IsNotSet(controlTag.Tag)) return null;
            string __idControl = Conversion.ToString(controlTag.Tag);
            if (values.ContainsKey(__idControl))
            {
                return values[__idControl];
            }
            else
            {
                //Pour debug uniquement !!! � commenter apr�s test
                //Permet de savoir si un control n'a pas �t� trouv� dans les controlvalue ce qui n'est pas normal sauf cas exceptionnel ou la valeur du control est null
                System.Diagnostics.Debug.WriteLine(string.Format(" Attention => Control {0} introuvable, est-ce normal ? ", __idControl));
            }
            return null;
        }

        /// <summary>
        /// Permet de mettre � jour un controle si un controlValue � pr�c�demment �t� sauvegard�
        /// </summary>
        /// <param name="controlTag">Le controle � mettre � jour</param>
        /// <param name="values">Les valeurs de tous les controles une d'elle doit correspondre au controlTag</param>
        static void DefinirValeurControle(IControlTag controlTag, ListControlValue values)
        {

            //Permet r�cup�rer la valeur que doit avoir le controle si le controle existe ainsi que sa valeur
            ControlValue __controlValue = GetControlValue(controlTag, values);
            if (Validation.IsNull(__controlValue)) return;

            if (controlTag is QXPWUIComposite.BaseComposite)
            {
                DefinirValeurControle((QXPWUIComposite.BaseComposite)controlTag, __controlValue);
            }
            else if (controlTag is QXPWUIComposite.BaseRange)
            {
                DefinirValeurControle((QXPWUIComposite.BaseRange)controlTag, __controlValue);
            }
            else if (controlTag is QXPWUIExtended.BaseExtendedDoubleListBox)
            {
                DefinirValeurControle((QXPWUIExtended.BaseExtendedDoubleListBox)controlTag, __controlValue);
            }
            else if (controlTag is QXPWUIExtended.RadioList)
            {
                DefinirValeurControle((QXPWUIExtended.RadioList)controlTag, __controlValue);
            }
        }

        /// <summary>
        /// Permet de mettre � jour un controle avec un controlValue pr�c�demment sauvegard�
        /// </summary>
        /// <param name="control">Le controle � mettre � jour</param>
        /// <param name="controlValue">Le controlValue contenant la valeur</param>
        static void DefinirValeurControle(QXPWUIComposite.BaseComposite control, ControlValue controlValue)
        {
            if (control is QXPWUIComposite.Date)
            {
                if (Validation.IsSet(controlValue.Value)) control.DefaultValue = DateTime.Parse(controlValue.Value);
                else control.DefaultValue = null;
            }
            else
            {
                control.DefaultValue = controlValue.Value;
            }
        }

        /// <summary>
        /// Permet de mettre � jour un controle avec un controlValue pr�c�demment sauvegard�
        /// </summary>
        /// <param name="control">Le controle � mettre � jour</param>
        /// <param name="controlValue">Le controlValue contenant la valeur</param>
        static void DefinirValeurControle(QXPWUIComposite.BaseRange control, ControlValue controlValue)
        {

            string __minValue = string.Empty;
            string __maxValue = string.Empty; ;

            string[] __values = Conversion.ToString(controlValue.Value).Split(split_char);

            switch (__values.Length)
            {
                case 2:
                    __maxValue = __values[1];
                    goto case 1;
                case 1:
                    __minValue = __values[0];
                    break;
                //dans les autres cas on sort de la fonction rien � mettre � jour
                default:
                    return;
            }

            //Cas des dates
            if (control is QXPWUIComposite.RangeDate)
            {
                if (Validation.IsSet(__minValue)) control.DefaultValueOfMin = DateTime.Parse(__minValue);
                else control.DefaultValueOfMin = null;

                if (Validation.IsSet(__maxValue)) control.DefaultValueOfMax = DateTime.Parse(__maxValue);
                else control.DefaultValueOfMax = null;
            }
            else
            {
                control.DefaultValueOfMin = __minValue;
                control.DefaultValueOfMax = __maxValue;
            }
        }

        /// <summary>
        /// Permet de mettre � jour un controle avec un controlValue pr�c�demment sauvegard�
        /// </summary>
        /// <param name="control">Le controle � mettre � jour</param>
        /// <param name="controlValue">Le controlValue contenant la valeur</param>
        static void DefinirValeurControle(QXPWUIExtended.BaseExtendedDoubleListBox control, ControlValue controlValue)
        {
            if (Validation.IsSet(controlValue.Value))
            {
                string[] __selectedValues = Conversion.ToString(controlValue.Value).Split(split_char);
                if (Validation.IsSet(__selectedValues))
                {
                    control.DefaultSelectedValues = __selectedValues;
                }
            }
        }

        /// <summary>
        /// Permet de mettre � jour un controle avec un controlValue pr�c�demment sauvegard�
        /// </summary>
        /// <param name="control">Le controle � mettre � jour</param>
        /// <param name="controlValue">Le controlValue contenant la valeur</param>
        static void DefinirValeurControle(QXPWUIExtended.RadioList control, ControlValue controlValue)
        {
            if (Validation.IsSet(controlValue.Value))
            {
                control.DefaultValue = Conversion.ToInt(controlValue.Value);
            }
        }

        #endregion Chargement des ControlValue

        #region Sauvegarde ControlValue

        /// <summary>
        /// Sauvegarde de la valeur contenu dans les controles
        /// </summary>
        /// <param name="info">Param�tres de sauvegarde</param>
        /// <param name="controls">Liste des controles � sauvegarder</param>
        public static void SauvegardeControlValue(IInfoControlValue info, IControlTag[] controls)
        {
            try
            {
                if (Validation.IsSet(controls))
                {
                    ListControlValue __listControlValue = new ListControlValue();
                    foreach (IControlTag __controlTag in controls)
                    {
                        ControlValue __controlValue = RetourneControlValue(__controlTag);
                        if (Validation.IsNotNull(__controlValue) && !__listControlValue.ContainsKey(__controlValue.ID_Control))
                        {
                            __listControlValue.Add(__controlValue.ID_Control, __controlValue);
                        }
                    }
                    SauvegardeListControlValue(info, __listControlValue);
                }
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError("SauvegardeControlValue", ex);
                throw;
            }
        }

        /// <summary>
        /// Retourne le ControlValue de la valeur contenu dans le controle
        /// </summary>
        /// <param name="controleTag">Le controle contenant la valeur</param>
        /// <returns>Le ControlValue �valu�</returns>
        static ControlValue RetourneControlValue(IControlTag controleTag)
        {
            if (Validation.IsNull(controleTag)) return null;
            if (controleTag is QXPWUIComposite.BaseComposite)
            {
                return RetourneControlValue((QXPWUIComposite.BaseComposite)controleTag, Conversion.ToString(controleTag.Tag));
            }
            if (controleTag is QXPWUIComposite.BaseRange)
            {
                return RetourneControlValue((QXPWUIComposite.BaseRange)controleTag, Conversion.ToString(controleTag.Tag));
            }
            else if (controleTag is QXPWUIExtended.BaseExtendedDoubleListBox)
            {
                return RetourneControlValue((QXPWUIExtended.BaseExtendedDoubleListBox)controleTag, Conversion.ToString(controleTag.Tag));
            }
            else if (controleTag is QXPWUIExtended.RadioList)
            {
                return RetourneControlValue((QXPWUIExtended.RadioList)controleTag, Conversion.ToString(controleTag.Tag));
            }
            return null;
        }

        /// <summary>
        /// Retourne le ControlValue repr�sentant la valeur contenu dans le controle Composite
        /// </summary>
        /// <param name="controle">Le controle Composite contenant la valeur</param>
        /// <param name="idControl">L'identifiant du controle dans le composant</param>
        /// <returns>Le ControlValue �valu�</returns>
        static ControlValue RetourneControlValue(QXPWUIComposite.BaseComposite controle, string idControl)
        {
            if (Validation.IsNotSet(idControl)) return null;
            string __value = string.Empty;

            //Traitement des cas particuliers
            if (controle is QXPWUIComposite.DropDownList)
            {
                QXPWUIComposite.DropDownList __dropDownList = controle as QXPWUIComposite.DropDownList;
                //on teste �galement la propri�t� enable empty selection
                if (Validation.IsSet(controle.Data) || __dropDownList.EnableEmptySelection)
                {
                    __value = Conversion.ToString(__dropDownList.Data);
                    return new ControlValue(idControl, __value);
                }
            }
            else
            {
                if (Validation.IsSet(controle.Data))
                {
                    //traitement des formatages particuliers
                    if (controle is QXPWUIComposite.Date)
                    {
                        __value = Conversion.ToDateTime(controle.Data).ToString("yyyy/MM/dd HH:mm:ss");
                    }
                    //Formatage standard
                    else
                    {
                        __value = Conversion.ToString(controle.Data);
                    }
                    return new ControlValue(idControl, __value);
                }
            }

            return null;
        }

        /// <summary>
        /// Retourne le ControlValue repr�sentant la valeur contenu dans le controle Composite Range
        /// </summary>
        /// <param name="controle">Le controle Composite contenant la valeur</param>
        /// <param name="idControl">L'identifiant du controle dans le composant</param>
        /// <returns>Le ControlValue �valu�</returns>
        static ControlValue RetourneControlValue(QXPWUIComposite.BaseRange controle, string idControl)
        {
            if (Validation.IsNotSet(idControl)) return null;
            string __value = string.Empty;
            string __valueMin = string.Empty;
            string __valueMax = string.Empty;

            if (Validation.IsSet(controle.DataOfMin) || Validation.IsSet(controle.DataOfMax))
            {
                //traitement des formatages particuliers
                if (controle is QXPWUIComposite.RangeDate)
                {
                    __valueMin = Conversion.ToDateTime(controle.DataOfMin).ToString("yyyy/MM/dd HH:mm:ss");
                    __valueMax = Conversion.ToDateTime(controle.DataOfMax).ToString("yyyy/MM/dd HH:mm:ss");
                }
                //Formatage standard
                else
                {
                    __valueMin = Conversion.ToString(controle.DataOfMin);
                    __valueMax = Conversion.ToString(controle.DataOfMax);
                }
                __value = string.Format(range_join_pattern, __valueMin, __valueMax);
                return new ControlValue(idControl, __value);
            }

            return null;
        }

        /// <summary>
        /// Retourne le ControlValue repr�sentant la valeur contenu dans le controle doublelistbox
        /// </summary>
        /// <param name="control">Le controle doublelistbox contenant la/les valeur(s)</param>
        /// <param name="idControl">L'identifiant du controle dans le composant</param>
        /// <returns>Le ControlValue �valu�</returns>
        static ControlValue RetourneControlValue(QXPWUIExtended.BaseExtendedDoubleListBox control, string idControl)
        {
            if (Validation.IsNotSet(idControl)) return null;
            if (Validation.IsSet(control.SelectedValues))
            {
                string __value = string.Join("~", control.SelectedValues);
                return new ControlValue(idControl, __value);
            }
            return null;
        }

        /// <summary>
        /// Retourne le ControlValue repr�sentant la valeur contenu dans le controle RadioList
        /// </summary>
        /// <param name="control">Le controle RadioList contenant la valeur</param>
        /// <param name="idControl">L'identifiant du controle dans le composant</param>
        /// <returns>Le ControlValue �valu�</returns>
        static ControlValue RetourneControlValue(QXPWUIExtended.RadioList control, string idControl)
        {
            if (Validation.IsNotSet(idControl)) return null;
            if (Validation.IsSet(control.Value))
            {
                string __value = Conversion.ToString(Conversion.ToInt((Enum)control.Value));
                return new ControlValue(idControl, __value);
            }
            return null;
        }

        /// <summary>
        /// Sauvegarde en base de donn�es de la liste des ControlValue �valu�s � partir des controles
        /// </summary>
        /// <param name="info">Param�tre de sauvegarde des ControlValue</param>
        /// <param name="values">Liste des ControlValue � sauvegarder</param>
        static void SauvegardeListControlValue(IInfoControlValue info, ListControlValue values)
        {
            if (Validation.IsSet(values))
            {
                Proxy.ProxyControlValue __proxy = new Proxy.ProxyControlValue();
                __proxy.InsertListeControlValue(info, values);
            }
        }

        #endregion

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }
}
