using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls
{
	/// <summary>
	/// Repr�sente une liste de ControlValue
	/// </summary>
	/// <author>doufarm</author>
	/// <date>11/04/2009 11:07:14</date>    
	public class ListControlValue : Dictionary<string, ControlValue>
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de ListControlValue
		/// </summary>
		public ListControlValue()
		{
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
