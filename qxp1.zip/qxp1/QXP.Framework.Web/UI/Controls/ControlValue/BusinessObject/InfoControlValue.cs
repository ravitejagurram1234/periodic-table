namespace QXP.Framework.Web.UI.Controls
{
    /// <summary>
    /// Objet InfoControlValue
    /// </summary>
    /// <author>doufarm</author>
    /// <date>11/03/2009 17:18:21</date>    
    public class InfoControlValue : IInfoControlValue
    {
        #region Membres
        string _idNameColonne = "ID_UTILISATEUR";
        string _nameTable = null;
        public readonly string DefaultNameTable = "{0}.{0}_CONTROLVALUE";
        string _packageName = null;
        public readonly string DefaultPackageName = "{0}.{0}_PK_WEB.";
        string _deleteFonctionName = "DeleteListeControlValue";
        string _insertFonctionName = "InsertControlValue";
        string _getFonctionName = "GetListeControlValue";
        string _composant;
        int _id;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de InfoControlValue
        /// </summary>
        /// <param name="id">Identifiant du control</param>
        /// <param name="composant">Nom du composant associ�</param>
        public InfoControlValue(int id, string composant)
        {
            _id = id;
            _composant = composant;
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Nom de la colonne contenant les identifiants dans la table destination
        /// </summary>
        public string IdNameColonne
        {
            get { return _idNameColonne; }
            set { _idNameColonne = value; }
        }

        /// <summary>
        /// Nom de la table o� charger/sauvegarder les valeurs
        /// </summary>
        public string NameTable
        {
            get
            {
                if (Validation.IsNotSet(_nameTable))
                    return DefaultNameTable;
                else
                    return _nameTable;
            }
            set { _nameTable = value; }
        }

        /// <summary>
        /// Nom du package � utiliser pour charger/sauvegarder les valeurs 
        /// </summary>
        public string PackageName
        {
            get
            {
                if (Validation.IsNotSet(_packageName))
                    return DefaultPackageName;
                else
                    return _packageName;
            }
            set { _packageName = value; }
        }

        /// <summary>
        /// Fonction � utiliser pour les suppressions de ControlValue
        /// </summary>
        public string DeleteFonctionName
        {
            get { return _deleteFonctionName; }
            set { _deleteFonctionName = value; }
        }

        /// <summary>
        /// Fonction � utiliser pour les insertions de ControlValue
        /// </summary>
        public string InsertFonctionName
        {
            get { return _insertFonctionName; }
            set { _insertFonctionName = value; }
        }

        /// <summary>
        /// Fonction � utiliser pour obtenir les ControlValue
        /// </summary>
        public string GetFonctionName
        {
            get { return _getFonctionName; }
            set { _getFonctionName = value; }
        }

        /// <summary>
        /// Nom du composant associ� aux valeurs des controles (exemple SelectionListeValidationsVL)
        /// </summary>
        public string Composant
        {
            get { return _composant; }
            set { _composant = value; }
        }

        /// <summary>
        /// Identifiant associ� aux valeurs des controles (exemple l'identifiant d'un utilisateur)
        /// </summary>		
        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        #endregion Propri�t�s
    }
}
