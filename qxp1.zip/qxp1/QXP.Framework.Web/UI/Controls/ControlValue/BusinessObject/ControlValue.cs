using System;
using System.Collections.Generic;
using System.Text;

using QXPFrk = QXP.Framework;

namespace QXP.Framework.Web.UI.Controls
{
	/// <summary>
	/// Objet ControlValue
	/// </summary>
	/// <author>doufarm</author>
	/// <date>11/03/2009 17:11:09</date>    
	public class ControlValue
	{
		#region Membres
		private string	_id_Control;
		private string	_value;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de ControlValue
		/// </summary>
		public ControlValue(string id_Control, string value)
		{
			_id_Control = id_Control;
			_value		= value;
		}

		#endregion Constructeur

		#region M�thodes

		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// Identifiant du control
		/// </summary>
		public string	ID_Control
		{
			get { return _id_Control; }
		}

		/// <summary>
		/// Valeur du controle
		/// </summary>
		public string	Value
		{
			get { return _value; }
		}
		#endregion Propri�t�s
	}
}
