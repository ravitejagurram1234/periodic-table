using System;
using System.ComponentModel;
using System.Web.UI;

/* 
 * Code g�n�r� avec le template web : QXPWebControl
*/
namespace QXP.Framework.Web.UI.Controls.Extensions
{
    /// <summary>
    /// UpdatePanel
    /// </summary>
    /// <author>cueffl</author>
    /// <date>04/03/2011 17:59:47</date>    
    public class UpdatePanel : System.Web.UI.UpdatePanel
    {
        #region Membres

        private string _cssClass;
        private HtmlTextWriterTag _tag = HtmlTextWriterTag.Div;
        bool _updateAfterCallBack = false;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de UpdatePanel
        /// </summary>
        public UpdatePanel()
        {
            this.Init += CreateConstituantControls;
            this.DataBinding += ControlDataBind;
            this.PreRender += ControlPreRender;
            this.UpdateMode = UpdatePanelUpdateMode.Conditional;
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>
        /// Lors de la cr�ations des contr�les
        /// </summary>
        protected virtual void CreateConstituantControls(object sender, EventArgs ea)
        {
            if (UpdateMode == UpdatePanelUpdateMode.Conditional)
                this.ChildrenAsTriggers = false;
        }

        /// <summary>
        /// Lors du binding du controle
        /// </summary>
        protected virtual void ControlDataBind(object sender, EventArgs ea)
        {
        }

        /// <summary>
        /// Lors du PreRender du controle
        /// </summary>
        protected virtual void ControlPreRender(object sender, EventArgs ea)
        {
            if (_updateAfterCallBack || AutoUpdateAfterCallBack)
                this.Update();
        }

        /// <summary>
        /// Lors du rendu
        /// </summary>
        /// <param name="writer"></param>
        protected override void RenderChildren(HtmlTextWriter writer)
        {
            if (IsInPartialRendering)
            {
                // If the UpdatePanel is rendering in "partial" mode that means
                // it's the top-level UpdatePanel in this part of the page, so
                // it doesn't render its outer tag. We just delegate to the base
                // class to do all the work.
                base.RenderChildren(writer);
            }
            else
            {
                // If we're rendering in normal HTML mode we do all the new custom
                // rendering. We then go render our children, which is what the
                // normal control's behavior is.
                writer.AddAttribute(HtmlTextWriterAttribute.Id, ClientID);
                if (CssClass.Length > 0)
                {
                    writer.AddAttribute(HtmlTextWriterAttribute.Class, CssClass);
                }
                writer.RenderBeginTag(Tag);
                foreach (Control child in Controls)
                {
                    child.RenderControl(writer);
                }
                writer.RenderEndTag();
            }
        }


        /// <summary>
        /// Ajoute un control � l'UpdatePanel
        /// </summary>
        /// <param name="child">Control child</param>
        public void Add(Control child)
        {
            this.ContentTemplateContainer.Controls.Add(child);
        }

        #endregion M�thodes

        #region Propri�t�s

        /// <summary>
        /// Rafraichi (MAJ) le contenu du panel lors du rendu
        /// </summary>
        public virtual bool UpdateAfterCallBack
        {
            get
            {
                return _updateAfterCallBack;
            }
            set
            {
                _updateAfterCallBack = value;
            }
        }

        /// <summary>
        /// Le contr�le se met � jour apr�s chaque callback?
        /// </summary>
        public virtual bool AutoUpdateAfterCallBack
        {
            get
            {
                object obj = this.ViewState["AutoUpdateAfterCallBack"];
                if (obj == null)
                    return false;
                else
                    return (bool)obj;
            }
            set
            {
                if (value) UpdateAfterCallBack = true;
                ViewState["AutoUpdateAfterCallBack"] = value;
            }
        }

        /// <summary>
        /// Class CSS
        /// </summary>
        [DefaultValue("")]
        [Description("Applies a CSS style to the panel.")]
        public string CssClass
        {
            get
            {
                return _cssClass ?? String.Empty;
            }
            set
            {
                _cssClass = value;
            }
        }
       
        /// <summary>
        /// Hide the base class's RenderMode property since we don't use it 
        /// </summary>
        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public new UpdatePanelRenderMode RenderMode
        {
            get
            {
                return base.RenderMode;
            }
            set
            {
                base.RenderMode = value;
            }
        }

        /// <summary>
        /// Tag
        /// </summary>
        [DefaultValue(HtmlTextWriterTag.Div)]
        [Description("The tag to render for the panel.")]
        public HtmlTextWriterTag Tag
        {
            get
            {
                return _tag;
            }
            set
            {
                _tag = value;
            }
        }

        #endregion Propri�t�s
    }
}
