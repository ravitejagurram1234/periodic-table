using System.Collections;
using System.Web;

namespace QXP.Framework.Web
{
    /// <summary>
    /// Class BrowserCapabilities : Provides methods and properties of a web user browser capabilities.
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class BrowserCapabilities
    {
        #region Membres

        string _sessionID;
        string _browser;
        string _browserVersion;
        string _clrVersion;
        string _platform;
        string[] _languages;
        bool _supportsCookie;
        ScriptCapability _scriptCapability = ScriptCapability.Unknown;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>Creates a new instance of <see cref="BrowserCapabilities"/> class. </summary>
        public BrowserCapabilities()
        {
            HttpContext __context = HttpContext.Current;
            HttpBrowserCapabilities __capabilities = __context.Request.Browser;
            _sessionID = __context.Session.SessionID;
            _browser = __capabilities.Browser;
            _browserVersion = __capabilities.Version;
            _clrVersion = Conversion.ToString(__capabilities.ClrVersion);
            _platform = __capabilities.Platform;
            _languages = __context.Request.UserLanguages;
            _supportsCookie = this.IsCookieSupported;
        }

        #endregion Constructeur

        #region M�thodes

        internal void DefineScriptCapability(ScriptCapability scriptCapabilty)
        {
            _scriptCapability = scriptCapabilty;
        }

        #endregion M�thodes

        #region Propri�t�s

        private bool IsCookieSupported
        {
            get
            {
                HttpContext __ctxt = HttpContext.Current;
                if ((__ctxt.Request.RequestType == "POST") && (__ctxt.Session.IsNewSession))
                {
                    bool __supported = false;
                    IEnumerator __ie = __ctxt.Request.Headers.Keys.GetEnumerator();
                    while (__ie.MoveNext())
                        if ((string)__ie.Current == "Cookie")
                        {
                            __supported = true;
                            break;
                        }
                    //if(!__supported)	this.Error = new Exception("Session cookie required");
                    return __supported;
                }
                return true;
            }
        }

        /// <summary>Gets the browser session id. </summary>
        public string SessionID
        {
            get { return _sessionID; }
        }

        /// <summary>Gets the browser type. </summary>
        public string Browser
        {
            get { return _browser; }
        }

        /// <summary>Gets the browser version. </summary>
        public string BrowserVersion
        {
            get { return _browserVersion; }
        }

        /// <summary>Gets the CLR version installed on the browser client. </summary>
        public string CLRVersion
        {
            get { return _clrVersion; }
        }

        /// <summary>Gets the platform of the browser client. </summary>
        public string Platform
        {
            get { return _platform; }
        }

        /// <summary>Gets the preferred browser languages. </summary>
        public string[] Languages
        {
            get { return _languages; }
        }

        /// <summary>Check if cookies are accepted by the browser. </summary>
        public bool SupportsCookie
        {
            get { return _supportsCookie; }
        }

        /// <summary>
        /// Gets if client scripting is enabled
        /// </summary>
        public ScriptCapability ScriptCapability
        {
            get { return _scriptCapability; }
        }

        #endregion Propri�t�s
    }
}
