using System;
using System.Web;
using QXPFrkWebUser = QXP.Framework.Web.User;

namespace QXP.Framework.Web.Module
{
    /// <summary>
    /// Class UserModule : Provides methodes to initialized user context request thread.
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class UserModule : IHttpModule
    {
        #region Membres

        HttpApplication App;

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de UserModule
        /// </summary>
        public UserModule()
        {
        }

        #endregion Constructeur

        #region M�thodes

        /// <summary>Initialize the current <see cref="UserModule"/>. </summary>
        /// <param name="app">the <see cref="HttpApplication"/> associated with the <see cref="UserModule"/>. </param>
        public virtual void Init(HttpApplication app)
        {
            App = app;
            app.AcquireRequestState += new EventHandler(this.OnAcquireRequestState);
        }

        /// <summary>Disposes of the resources. </summary>
        public virtual void Dispose() { }
        
        /// <summary>Occurs just before ASP.NET begins requesting request state as a page or XML Web service. </summary>
        /// <param name="s">the <see cref="object"/> associated with the event. </param>
        /// <param name="e">the data argument asociated with the event. </param>
        public void OnAcquireRequestState(object s, EventArgs e)
        {
            //INFO: Check if Context is SessionLess then dont set user profile !!
            if (Validation.IsNull(App.Context.Session)) return;
            QXPFrkWebUser.User.SetThreadCulture();
        }

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }


}
