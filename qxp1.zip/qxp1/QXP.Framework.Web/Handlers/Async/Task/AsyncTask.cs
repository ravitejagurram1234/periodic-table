using System;
using QXPDiagnostic = QXP.Framework.Diagnostic;

/* 
 * Code g�n�r� avec le template : QXPObjectClass
*/
namespace QXP.Framework.Web.Handler
{
	/// <summary>
	/// D�fini un �l�ment d'�x�cution asynchrone. c'est cette classe qui porte les param�tres, l'�x�cution et le resultat d'un appel asynchrone.
	/// </summary>
	/// <author>doufarm</author>
	/// <date>20/09/2011 16:53:19</date>    
	public abstract class  AsyncTask
	{
		#region Membres
		string						_id;
		Enums.AsyncTaskState		_taskState	= Enums.AsyncTaskState.Undefined;
        
		//Utilis� pour d�clench� la g�n�ration du rapport de mani�re asynchrone
        private AsyncTaskDelegate	_dlgt;

        protected delegate void AsyncTaskDelegate();
		
		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de AsyncTask
		/// </summary>
		public AsyncTask(string id)
		{
			_id = id;
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// D�but de l'�x�cution de la tache
		/// </summary>
		public void ExecuteAsyncTask()
        {
			try
			{
				System.Diagnostics.Debug.WriteLine(string.Format("ExecuteAsyncTask Start:{0}, State:{1}", _id, _taskState));
				_taskState = Enums.AsyncTaskState.Started;
				this.Evaluate();
				_taskState = Enums.AsyncTaskState.Completed;
				System.Diagnostics.Debug.WriteLine(string.Format("ExecuteAsyncTask End:{0}, State:{1}", _id, _taskState));
			}
			catch (Exception ex)
			{
				_taskState = Enums.AsyncTaskState.Error;
				QXPDiagnostic.Log.LogError("ExecuteAsyncTask", ex);
				System.Diagnostics.Debug.WriteLine(string.Format("ExecuteAsyncTask Error:{0}", _id));
			}
        }

        /// <summary>
        /// M�thode appel�e au d�marrage de la t�che asynchrone
        /// </summary>
        /// <param name="sender">source de l'�v�nement</param>
        /// <param name="e">arguments</param>
        /// <param name="cb">call back r�f�rence</param>
        /// <param name="extraData">call back data</param>
        /// <returns></returns>
        public IAsyncResult OnBegin(object sender, EventArgs e, AsyncCallback cb, object extraData)
        {
			System.Diagnostics.Debug.WriteLine(string.Format("OnBegin :{0}, State:{1}", _id, _taskState));

			//important
			//Si cette tache � d�j� associ�e ExecuteAsyncTask, cette association reste valable et peut �tre r�utilis�e par un nouvel appel asynchrone
			if (Validation.IsNull(_dlgt))
			{
				//Utilisation d'un d�l�gu� asynchrone pour le lancement de la t�che
				_dlgt += ExecuteAsyncTask;
			}


            //On lance la m�thode que le d�l�gu� r�f�rence
            IAsyncResult __result = _dlgt.BeginInvoke(cb, extraData);

            return __result;
        }

        /// <summary>
        /// M�thode appel�e lorsque le traitement de la t�che asynchrone est termin� (traitement lanc� par OnBegin)
        /// </summary>
        /// <param name="ar">r�sultat de la fin de l'appel asynchrone</param>
        public void OnEnd(IAsyncResult ar)
        {
			System.Diagnostics.Debug.WriteLine(string.Format("OnEnd :{0}, State:{1}", _id, _taskState));

            _dlgt.EndInvoke(ar);
        }

        /// <summary>
        /// M�thode appel�e lorsque la partie de la tache synchrone tombe en timeout (la t�che continu en asynchrone)
        /// </summary>
        /// <param name="ar">resultat du timeout de l'appel asynchrone</param>
        public void OnTimeout(IAsyncResult ar)
        {
			System.Diagnostics.Debug.WriteLine(string.Format("OnTimeout :{0}, State:{1}", _id, _taskState));
        }

		/// <summary>
		/// C'est cette methode qu'il faut surcharger pour effectuer votre propre traitement (qui peu �tre long)
		/// </summary>
		public abstract void Evaluate();
		
		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// Identifiant unique de la tache
		/// </summary>
		public string ID
		{
			get
			{
				return _id;
			}
		}

		/// <summary>
        /// Publie une r�f�rence sur l'�tat de la t�che
        /// </summary>
        public Enums.AsyncTaskState TaskState
        {
            get
            {
                return _taskState;
            }
        }
		#endregion Propri�t�s
	}
}
