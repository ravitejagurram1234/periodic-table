using System.Text;
using System.Web.UI;
using QXPWUI = QXP.Framework.Web.UI;

/* 
 * Code g�n�r� avec le template : QXPHelperClass
*/
namespace QXP.Framework.Web.Handler
{
	/// <summary>
	/// Contient les fonctions d'assistance aux elements Handler asynchrone
	/// </summary>
	/// <author>doufarm</author>
	/// <date>21/09/2011 14:44:37</date>    
	public class AsyncHelper
	{
		#region Membres

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Constructeur static AsyncHelper
		/// </summary>
		static AsyncHelper()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
        /// Ajoute le script au contr�le pour afficher l'url dans la frame voulue
        /// </summary>
        /// <param name="host">Control web qui h�bergera le script</param>
        /// <param name="id">Identifiant du controle � informer</param>
		/// <param name="top">true le frame en cours signal � la fen�tre la plus haute la fin du traitement, false signal uniquement � la fen�tre parente. </param>
        internal static void SignalScript(Control host, string id, bool top)
        {
            StringBuilder __script = new StringBuilder();
            QXPWUI.ClientScript __changeScript;

			if (top)
			{
				__script.Append("var pWindow        = window.top;\n");
			}
			else
			{
				__script.Append("var pWindow        = window.parent;\n");			
			}
			
			//Pour le debug uniquement
			//__script.Append("debugger;\n");
            __script.AppendFormat("pWindow.{0};", QXPWUI.RenderUtility.GetCallFireEventReferenceSansJS(id));

            __changeScript = new QXPWUI.ClientScript(host, id, __script.ToString(), true);
            __changeScript.RegisterForClientSideEval();

        }

		#endregion M�thodes

		#region Propri�t�s

		#endregion Propri�t�s
	}
}
