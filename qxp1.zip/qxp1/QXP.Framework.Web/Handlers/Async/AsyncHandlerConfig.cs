using QXPConfiguration = QXP.Framework.Configuration;
using QXPFrk = QXP.Framework;
using QXPW = QXP.Framework.Web;


namespace QXP.Framework.Web.Handler
{
    /// <summary>
    /// Class InvocationHandlerConfig : D�fini les param�tres de la gestion asynchrone
    /// </summary>
    /// <author> </author>
    /// <date> </date>    
    public class AsyncHandlerConfig
    {
        #region Membres

        //Afin de rendre l'interface plus r�active je met FirstGenResponseTimeOut � 2000 et non � 4000 comme dans la g�n�ration des rapports
		public static int FirstGenResponseTimeOut = 2000;
        public static int CheckGenTimerInterval = 2000;

        static object _syncRoot = new object();
        static bool _syncOk = false;

        #endregion Membres

        #region Constantes
        public const string CallIDKey = "callid";
        public const string SupCallIDKey = "supcallid";
        public const string TaskIDKey = "taskid";

        /// <summary>
        /// D�lai de tentative de g�n�ration synchrone avant passage en asynchrone
        /// </summary>
		private const string FirstAsyncGenResponseTimeOutKey = "FirstAsyncGenResponseTimeOut";
        /// <summary>
        /// D�lai de v�rification de l'�x�cution asynchrone
        /// </summary>
        private const string CheckAsyncGenTimerIntervalKey = "CheckAsyncGenTimerInterval";

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Constructeur statique des param�tre de configuration des handlers
        /// </summary>
        static AsyncHandlerConfig()
        {
            //une petite s�curit� afin que personne n'�x�cute la m�me code en m�me temps
            lock (_syncRoot)
            {
                //si quelqun � d�j� initialis� les valeurs
                if (_syncOk) return;
				int __timeout = QXPConfiguration.Settings.Current.GetInt(FirstAsyncGenResponseTimeOutKey);

				if (QXPFrk.Validation.IsSet(__timeout))
				    FirstGenResponseTimeOut = __timeout;

				int __timerInterval = QXPConfiguration.Settings.Current.GetInt(CheckAsyncGenTimerIntervalKey);

				if (QXPFrk.Validation.IsSet(__timerInterval))
				    CheckGenTimerInterval = __timerInterval;

                _syncOk = true;
            }
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Propri�t�s

        #endregion Propri�t�s
    }

}

