using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.SessionState;

using QXPFrk = QXP.Framework;

/* 
 * Code g�n�r� avec le template : QXPBusinessClass
*/
namespace QXP.Framework.Web.Handler
{
	/// <summary>
	/// Cet Handler permet de r�pondre aux demandes asynchrones effectu�es par un composant Asynchrone.
	/// </summary>
	/// <author>doufarm</author>
	/// <date>19/09/2011 11:07:31</date>    
	public class AsyncHandler: IHttpHandler, IReadOnlySessionState
	{
		#region Membres

		#endregion Membres

		#region Constantes
        
		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de AsyncHandler
		/// </summary>
		public AsyncHandler()
		{
		}

		#endregion Constructeur

		#region M�thodes
		/// <summary>
		/// Traitement de la Request
		/// </summary>
		/// <param name="context">contexte de la Request</param>
		public void ProcessRequest(HttpContext context)
        {
			IHttpHandler __page = null;
			//On instancie un WebAsyncPage qui sera la page support de l'appel asynchrone 
			__page = new WebAsyncPage();
			//On d�clenche l'appel au handler
			__page.ProcessRequest(context);
        }
		#endregion M�thodes

		#region Propri�t�s
        
		/// <summary>Gets an <see cref="IHttpHandler"/> object for the current <see cref="HttpRequest"/>. </summary>
        protected virtual IHttpHandler Handler
        {
            get { return null; }
        }

        /// <summary>Gets a value indicating whether another request can use the <see cref="IHttpHandler"/> instance. </summary>
        public bool IsReusable
        {
            get { return true; }
        }

		#endregion Propri�t�s
	}
}
