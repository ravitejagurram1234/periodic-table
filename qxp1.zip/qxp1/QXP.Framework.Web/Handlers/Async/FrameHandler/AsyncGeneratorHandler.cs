using System;
using System.Web.SessionState;
using System.Web.UI;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPFrk = QXP.Framework;
using QXPWUI = QXP.Framework.Web.UI;
using QXPWUser = QXP.Framework.Web.User;


/* 
 * Code g�n�r� avec le template : QXPBusinessClass
*/
namespace QXP.Framework.Web.Handler
{
    /// <summary>
    /// Cet handler (qui est une page simplifi�) permet de lancer l'appel � proprement parl� du code utilisateur "AsyncTask.Evaluate"
    /// </summary>
    /// <author>mdo</author>
    /// <date>23/09/2011</date>    
    public class AsyncGeneratorHandler : QXPWUI.BasePageHandler, IReadOnlySessionState
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de AsyncGeneratorHandler
        /// </summary>
        public AsyncGeneratorHandler()
        {
            //On d�finit la page comme �tant asynchrone
            this.AsyncMode = true;
            //On d�finit le d�lai d'attente de timeout pour l'appel asynchrone
            this.AsyncTimeout = TimeSpan.FromMilliseconds(AsyncHandlerConfig.FirstGenResponseTimeOut);
        }

        #endregion Constructeur

        #region M�thodes

        #endregion M�thodes

        #region Evenements

		/// <summary>
		/// D�clench� lors du chargement du handler
		/// </summary>
		/// <param name="ea">arguments</param>
		protected override void OnLoad(EventArgs ea)
		{
		    base.OnLoad(ea);

		    string __id = this.TaskID;

		    try
		    {
		        //L'identifiant 
		        if (QXPFrk.Validation.IsNotSet(__id))
		        {
					//tout est fini on pr�vient la fen�tre top
					AsyncHelper.SignalScript(this.Body, this.SupCallID, true);
		        }
		        else
		        {
		            //On r�cup�re la tache � �x�cuter
					AsyncTask __task = QXPWUser.User.Current.GetObject(Enums.ObjectCategory.AsyncTask, __id) as AsyncTask;

		            if (QXPFrk.Validation.IsNotNull(__task))
		            {
						
						//Instanciation d'une t�che asynchrone qui sera execut�e par le page en cours (d'o� le AsyncMode dans le constructeur)
		                //On d�finit les m�thodes qui seront appel�es au d�marrage de la t�che, � la fin de la t�che et au TimeOut de la t�che
		                PageAsyncTask __pageAsyncTask = new PageAsyncTask(__task.OnBegin, __task.OnEnd, __task.OnTimeout, "Async", false);

		                // On enregistre la t�che
		                Page.RegisterAsyncTask(__pageAsyncTask);

		                // On d�marre la t�che (lancement de la m�thode __task.OnBegin)
		                Page.ExecuteRegisteredAsyncTasks();

		                // On analyse l'�tat de la t�che avant de tomb� �ventuellement en asynchrone
		                switch (__task.TaskState)
		                {
		                    //La t�che est termin�e
		                    case Enums.AsyncTaskState.Completed:
		                    //La t�che est en erreur
		                    case Enums.AsyncTaskState.Error:

								//tout est fini on pr�vient la fen�tre top
								AsyncHelper.SignalScript(this.Body, this.SupCallID, true);

		                        break;
		                    //INFO: dans les autres cas il faut avertir le parent qu'il faut v�rifier le r�sultat r�guli�rement
		                    case Enums.AsyncTaskState.Started:
		                    case Enums.AsyncTaskState.Undefined:
								//tout est fini on pr�vient la fen�tre parent (pour d�clencher le wait)
								AsyncHelper.SignalScript(this.Body, this.CallID, false);
		                        break;
		                }
		            }
		            else
		            {
						//tout est fini on pr�vient la fen�tre top
						AsyncHelper.SignalScript(this.Body, this.SupCallID, true);
		            }
		        }

		    }
		    catch (Exception ex)
		    {
				
				QXPDiagnostic.Log.LogError("Async Generator Handler", ex);

				//tout est fini on pr�vient la fen�tre top
				AsyncHelper.SignalScript(this.Body, this.SupCallID, true);

		    }

		}

        #endregion Evenements

        #region Propri�t�s

        /// <summary>
        /// Identifiant de la tache associ�e � la g�n�ration
        /// </summary>
        private string TaskID
        {
            get { return this.Page.Request[AsyncHandlerConfig.TaskIDKey]; }
        }

		/// <summary>
        /// identifiant du controle de la fen�tre parent � informer
        /// </summary>
        private string CallID
        {
            get { return this.Page.Request[AsyncHandlerConfig.CallIDKey]; }
        }

		/// <summary>
        /// identifiant du controle de la fen�tre la plus hautes � informer
        /// </summary>
        private string SupCallID
        {
            get { return this.Page.Request[AsyncHandlerConfig.SupCallIDKey]; }
        }

        #endregion Propri�t�s
    }
}

