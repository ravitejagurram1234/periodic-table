/* 
 * Code g�n�r� avec le template : QXPEnumsClass
*/
namespace QXP.Framework.Web.Handler
{
    /// <summary>
    /// Ensembles des �num�rations communes au module
    /// </summary>
    /// <author>doufarm</author>
    /// <date>10/05/2011 17:38:48</date>    
    public class Enums
    {
        /// <summary>
        /// Cat�gorie de stockage dans la table session utilisateur
        /// </summary>
		public enum ObjectCategory
        {
            AsyncTask,
        }

        /// <summary>
        /// Liste des �tats possible d'un tache asynchrone
        /// </summary>
		public enum AsyncTaskState
        {
            Undefined,
            Started,
            Completed,
            Error,
        }

    }
}
