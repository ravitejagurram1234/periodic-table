using System;
using System.Text;
using System.Web.UI;
using System.Web.SessionState;
using QXPFrk = QXP.Framework;
using QXPDiagnostic = QXP.Framework.Diagnostic;
using QXPRes = QXP.Framework.Application.Application;
using QXPWebCtrlFactory = QXP.Framework.Web.UI.Controls.Helpers.ControlFactory;
using QXPW = QXP.Framework.Web;
using QXPWUI = QXP.Framework.Web.UI;
using QXPWUIBasic = QXP.Framework.Web.UI.Controls.Basic;
using QXPWUIComposite = QXP.Framework.Web.UI.Controls.Composite;
using QXPWUIHtml = QXP.Framework.Web.UI.Controls.Html;
using QXPWUser = QXP.Framework.Web.User;

namespace QXP.Framework.Web.Handler
{
	/// <summary>
	/// WebAsyncPage : Page Web permettant le controle de la tache asynchrone
	/// </summary>
	/// <author>doufarm</author>
	/// <date>19/09/2011 16:53:37</date>    
	public class WebAsyncPage :  QXPWUI.BasePageHandler, IReadOnlySessionState
	{
		#region Membres
		QXPWUIBasic.AsyncControl	_asyncControl;
        
		//Cet handler est aussi une page car il poss�de un composant Timer
        private QXPWUIBasic.Timer	_timer;

		#endregion Membres

		#region Constantes

		#endregion Constantes

		#region Enums

		#endregion Enums

		#region Constructeur

		/// <summary>
		/// Cr�e une instance de WebAsyncPage
		/// </summary>
		public WebAsyncPage()
		{
			this.Page_Init += OnPage_Init;
		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>
        /// D�clench� lors de l'Initialisation de la page
        /// </summary>
        private void OnPage_Init()
        {
            #region D�finition du Header de la page (ajoute des styles + script javascript)

            this.Headers.AddSystemStyleSheet("Styles/styles.css");
            this.Headers.AddScript("Scripts/system.js");

            #endregion D�finition du Header de la page (ajoute des styles + script javascript)

            #region D�finition des param�tres du corps de la page (via le Membre Section de la classe de base)

            //Desactive les mise � jour par defaut!!!
            this.Sections.UpdateAfterCallBack = false;

            #endregion D�finition du corps de la page (via le Membre Section de la classe de base)

            #region D�finition du contenu du corps de la page (via le Membre Section de la classe de base)

            #region Frames

			_asyncControl = new QXPWUIBasic.AsyncControl();
			_asyncControl.IFramePage = "Async_Generator.aspx";

			//L'appel du parent devient un "supcallid" il �tait � l'origine un "callid" !!
			//Le callid en cours est g�n�r� automatiquement par l'AsyncControl
			_asyncControl.ExternalParameters.Clear();
			_asyncControl.ExternalParameters.Add(AsyncHandlerConfig.SupCallIDKey, this.CallID);
			
			this.Body.Add(_asyncControl);
			_asyncControl.Signal += OnSignal;

			//L'appel du fils ne doit ce faire que sur le premier appel de la page
			if (!this.IsPostBack)
			{
				_asyncControl.StartAsyncCall(this.TaskID);
			}


            //Ajout du timer � la page
            _timer = new QXPWUIBasic.Timer(AsyncHandlerConfig.CheckGenTimerInterval);
            _timer.Enabled = false;
            _timer.Tick += this.OnTick;

            this.Sections.Body.Add(_timer);

            #endregion Frames

            #endregion D�finition du contenu du corps de la page (via le Membre Section de la classe de base)
        }

		/// <summary>
		/// Survient lorsque le timer de la page se d�clenche
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void OnSignal(object sender, EventArgs e)
		{
			//un test et hop appel du parent encore ^^
			//AsyncHelper.SignalScript(this.Body, this.CallID, false);
            
			//lorsque l'ont arrive sur ce composant on v�rifie tout de suite !
			if (!this.CheckGeneration())
			{
				//si pas termin� ont active le timer
				_timer.Enabled = true;
			}
			
		}

		/// <summary>
		/// Ev�nement lev� par le timer lorsqu'il est enable = true
		/// </summary>
		/// <param name="sender">source de l'�v�nement</param>
		/// <param name="e">arguments de l'�v�nement</param>
		void OnTick(object sender, EventArgs e)
		{
			this.CheckGeneration();
		}

		/// <summary>
		/// V�rifie si la tache est termin�e
		/// </summary>
		/// <returns>true elle est termin�e, false elle n'est pas termin�e. </returns>
		bool CheckGeneration()
		{
			string __id = this.TaskID;
            try
            {
                System.Diagnostics.Debug.WriteLine(string.Format("Check Report:{0}", __id));

                //R�cup�ration d'une r�f�rence sur l'objet GeneratorTask d�crivant la t�che en cours
                AsyncTask __task = QXPWUser.User.Current.GetObject(Enums.ObjectCategory.AsyncTask, __id) as AsyncTask;

                if (QXPFrk.Validation.IsNotNull(__task))
                {

                    switch (__task.TaskState)
                    {
                        //La t�che est termin�e
                        case Enums.AsyncTaskState.Completed:
                        //La t�che est en erreur
                        case Enums.AsyncTaskState.Error:
							this.FinWait(true);
                            return true;
                        default:
							//on continu d'attendre
                            return false;
                    }
                }
                else
                {
					this.FinWait(false);                            
					return true;
                }
            }
            catch (Exception ex)
            {
                QXPDiagnostic.Log.LogError(string.Format("Check Generation {0} Error", __id), ex);
				this.FinWait(false);                            
				return true;
            }		
		}

		/// <summary>
		/// Met fin au timer, avec ou sans signal � la fen�tre parent
		/// </summary>
		/// <param name="signal">true la fen�tre parent est averti, false elle n'est pas averti.</param>
		private void FinWait(bool signal)
		{
            
			//On arr�te le timer
            _timer.Enabled = false;

			if (signal)
			{
				//fin du wait on le signal � le fenetre parent (celle qui � appel�e la fene^tre en cours)
				AsyncHelper.SignalScript(this.Body, this.CallID, false);
			}
		
		}
		
		#endregion M�thodes

		#region Propri�t�s

		/// <summary>
		/// Identifiant du controle asynchrone source de l'appel
		/// </summary>
		/// <remarks>
		/// Ce controle est situ� dans la page qui contient l'iframe qui affiche la page en cours
		/// </remarks>
		private string CallID
		{
		    get { return this.Page.Request[AsyncHandlerConfig.CallIDKey]; }
		}

		/// <summary>
		/// identifiant de la tache associ�e � l'appel asynchrone
		/// </summary>
		private string TaskID
		{
		    get { return this.Page.Request[AsyncHandlerConfig.TaskIDKey]; }
		}

		#endregion Propri�t�s
	}
}
