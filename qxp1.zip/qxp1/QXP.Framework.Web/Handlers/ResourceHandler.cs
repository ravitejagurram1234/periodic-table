using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Permissions;
using System.IO;
using System.Text;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.SessionState;

using QXPFrk = QXP.Framework;

/* 
 * Code g�n�r� avec le template : QXPBusinessClass
*/
namespace QXP.Framework.Web.Handler
{
	/// <summary>
	/// Description de ResourceHandler
	/// </summary>
	/// <author>doufarm</author>
	/// <date>20/01/2012 15:33:40</date>
	/// <remarks>
	/// Cette class doit �tre d�riv�e, et il faut ensuite d�finir
	/// </remarks>
	/// <typeparam name="T">Repr�sente une class contenu dans l'assembly qui contient les ressources � retourner. </typeparam>
	public abstract class ResourceHandler<T>: IHttpHandler
	{
		#region Membres
		
		private static IDictionary _assemblyInfoCache;
		private static IDictionary _webResourceCache;
		private static IDictionary _typeAssemblyCache;

		#endregion Membres

		#region Constantes
		const string ResIDKey = "r";
		/// <summary>
		/// 0 nom du handler
		/// 1 valeur temporelle de la ressource (change � chaque compilation de l'assembly qui contient les webressources).
		/// 2 nom de la ressource (ce n'est pas le nom complet).
		/// </summary>
		const string ResHandlerPattern = "{0}?t={1}&{2}=";
		#endregion Constantes

		#region Enums

		#endregion Enums

		/// <summary>
		/// Permet de d�finir une origine de webResource
		/// </summary>
		public class WebResourceInfo
		{
		    /// <summary>
		    /// Pr�fixe des ressources
		    /// </summary>
			public string ResourcePrefix
		    {
		        get;
		        set;
		    }
			
			/// <summary>
		    /// Type contenu dans l'assembly qui contient finalement les resssources
		    /// </summary>
			public Type	 RessourceType
		    {
		        get;
		        set;
		    }

		}

		#region Constructeur

		static ResourceHandler()
		{
			_assemblyInfoCache = Hashtable.Synchronized(new Hashtable());
			_webResourceCache = Hashtable.Synchronized(new Hashtable());
			_typeAssemblyCache = Hashtable.Synchronized(new Hashtable());
		}


		/// <summary>
		/// Cr�e une instance de ResourceHandler
		/// </summary>
		public ResourceHandler()
		{

		}

		#endregion Constructeur

		#region M�thodes

		/// <summary>Process an <see cref="HttpRequest"/> from the specified <see cref="HttpContext"/> (<paramref name="context"/>). </summary>
        /// <param name="context">The <see cref="HttpContext"/> used the retrieve <see cref="HttpRequest"/> send by a web client. </param>
        public void ProcessRequest(HttpContext context)
        {
			
			context.Response.Clear();
			
			HttpRequest __httpRequest	= context.Request;
			string		__resID			= context.Request[ResIDKey];
            
			if (Validation.IsNotSet(__resID))
			{
			    context.Response.End();
			    return;
			}

			WebResourceInfo[]	__webRessourceInfos			= this.RessourcesInfos;
			string				__webResource				= string.Empty;
			string				__contentType				= string.Empty;
			Stream				__manifestResourceStream	= null;
			Pair				__webResourceCache			= null;
			Assembly			__manifestAssembly			= null;

			
			//Recherche des informations dans le cache
			foreach (WebResourceInfo __webRessourceInfo in __webRessourceInfos)
			{
				__webResource		= string.Concat(__webRessourceInfo.ResourcePrefix,  __resID).Replace("/", ".");
			
				__webResourceCache	= _webResourceCache[__webResource] as Pair;

				//La ressource � d�j� �t� �valu�e
				if (QXPFrk.Validation.IsNotNull(__webResourceCache))
				{
					//Evaluation de l'asssembly qui contiendra la ressource finales
					
					__manifestAssembly			= GetAssembly(__webRessourceInfo.RessourceType);

					//Fin de la boucle nous avons trouv� la webressource 
					break;
				}

			}

			if (QXPFrk.Validation.IsNull(__webResourceCache))
			{

				//Recherche des informations dans les WebResources
				foreach (WebResourceInfo __webRessourceInfo in __webRessourceInfos)
				{
					//Evaluation du chemin de la  WebRessource possible
					__webResource		= string.Concat(__webRessourceInfo.ResourcePrefix, __resID).Replace("/", ".");

					
					//Toutes les WebRessource sont issu de la m�me assembly ( en revanche les ManifestResourceStream peuvent �tre issus d'assembly diff�rentes ).
					Assembly			__webRessourceAssembly		= GetAssembly(typeof(T));

					//R�cup�rations des attributes WebResource only
					object[] __attributes = __webRessourceAssembly.GetCustomAttributes(typeof(WebResourceAttribute), false);

					//V�rification de l'existance de la ressouce demand�e.
					foreach (WebResourceAttribute __webResourceAttribute in __attributes)
					{
						//La web ressource � �t� trouv�e
						if (string.Equals(__webResourceAttribute.WebResource, __webResource))
						{
							__webResourceCache = new Pair(__webResourceAttribute.WebResource, __webResourceAttribute.ContentType);
							_webResourceCache[__webResource] = __webResourceCache;
							
							//Evaluation de l'asssembly qui contiendra la ressource finales
							__manifestAssembly	= GetAssembly(__webRessourceInfo.RessourceType);
							break;
						}
					}

				}
			}

			if (QXPFrk.Validation.IsNull(__webResourceCache))
			{
			    throw new HttpException(string.Format("Invalid Ressource Request {0}", context.Request.Url));
			}
			else
			{
			    __webResource = QXPFrk.Conversion.ToString(__webResourceCache.First);
			    __contentType = QXPFrk.Conversion.ToString(__webResourceCache.Second);
			}
			
			try
			{
			    __manifestResourceStream = __manifestAssembly.GetManifestResourceStream(__webResource);

			    /* Gestion du cache */
			    HttpCachePolicy __cache = context.Response.Cache;
			    __cache.SetCacheability(HttpCacheability.Public);
				///* Tous les param�tres de l'url entraine une validation du cache laisse le param�tre VaryByParam["*"] = true */
				//__cache.SetOmitVaryStar(false);
			    __cache.SetExpires(DateTime.Now + TimeSpan.FromDays(365.0));
			    __cache.SetValidUntilExpires(true);
			    Pair __assemblyInfo = GetAssemblyInfo(__manifestAssembly);
			    __cache.SetLastModified(new DateTime((long)__assemblyInfo.Second));

			    if (QXPFrk.Validation.IsNotNull(__manifestResourceStream))
			    {
			        context.Response.ContentType = __contentType;

			        byte[] __buffer = new byte[0x400];
			        Stream __outputStream = context.Response.OutputStream;
			        int __count = 1;
			        while (__count > 0)
			        {
			            __count = __manifestResourceStream.Read(__buffer, 0, 0x400);
			            __outputStream.Write(__buffer, 0, __count);
			        }
			        __outputStream.Flush();
			    }
			}
			finally
			{
			    if (QXPFrk.Validation.IsNotNull(__manifestResourceStream))
			    {
			        __manifestResourceStream.Close();
			    }
			}

        }

		/// <summary>
		/// Permet de retrouver une assembly par rapport � un type contenu dedans
		/// </summary>
		/// <param name="insideType">Un System.Type contenu dans l'assembly</param>
		/// <returns>L'assembly qui contient le System.Type.</returns>
		private Assembly GetAssembly(Type insideType)
		{
			Assembly __assembly = _typeAssemblyCache[insideType] as Assembly;

			if (QXPFrk.Validation.IsNull(__assembly))
			{
				__assembly = insideType.Assembly;
				_typeAssemblyCache[insideType] = __assembly;
			}
			return __assembly;
		}

		/// <summary>
		/// Permet d'obtenir des informations sur l'assembly qui contient les ressources
		/// </summary>
		/// <param name="assembly">l'assembly � analyser</param>
		/// <returns>Un object pair contenant (assemblyName et le ticks de derni�re �criture).</returns>
		private static Pair GetAssemblyInfo(Assembly assembly)
		{
			Pair assemblyInfoWithAssertInternal = _assemblyInfoCache[assembly] as Pair;
			if (assemblyInfoWithAssertInternal == null)
			{
				assemblyInfoWithAssertInternal = GetAssemblyInfoWithAssertInternal(assembly);
				_assemblyInfoCache[assembly] = assemblyInfoWithAssertInternal;
			}
			return assemblyInfoWithAssertInternal;
		}

		/// <summary>
		/// Permet d'obtenir des informations sur l'assembly qui contient les ressources
		/// </summary>
		/// <param name="assembly">l'assembly � analyser</param>
		/// <returns>Un object pair contenant (assemblyName et le ticks de derni�re �criture).</returns>
		[FileIOPermission(SecurityAction.Assert, Unrestricted=true)]
		private static Pair GetAssemblyInfoWithAssertInternal(Assembly assembly)
		{
			AssemblyName __assemblyName = assembly.GetName();
			return new Pair(__assemblyName, File.GetLastWriteTime(new Uri(__assemblyName.CodeBase).LocalPath).Ticks);
		}

		/// <summary>
		/// Permet d'obtenir l'url de base d'une ressource embarqu�e.
		/// </summary>
		/// <param name="manifestAssembly">Assembly qui contient les webressources.</param>
		/// <param name="handlerName">Le nom de la page faisant offiche de handler pour obtenir ult�rieurement la ressource. </param>
		/// <returns>Le nom de base permettant d'obtenir une ressource.</returns>
		public static string GetWebResourceBasePath(Assembly manifestAssembly, string handlerName)
		{
		    Pair __assemblyInfo = GetAssemblyInfo(manifestAssembly);
			return string.Format(ResHandlerPattern, handlerName, __assemblyInfo.Second, ResIDKey);
		}
		
		/// <summary>
		/// Permet d'obtenir le chemin complet d'une url d'une ressource embarqu�e.
		/// </summary>
		/// <param name="manifestAssembly">Assembly qui contient les webressources.</param>
		/// <param name="handlerName">Le nom de la page faisant offiche de handler pour obtenir ult�rieurement la ressource. </param>
		/// <param name="fileName">Le nom du fichier � obtenir exemple (/Styles/Styles.css ou encore /Images/logo.gid)</param>
		/// <returns>Le nom complet permettant d'obtenir la ressource.</returns>
		public static string GetWebResourceFullPath(Assembly manifestAssembly, string handlerName, string fileName)
		{
			return string.Concat(GetWebResourceBasePath(manifestAssembly, handlerName), fileName);
		}

		/// <summary>
		/// Permet de creer les informations sur des webresources
		/// </summary>
		/// <returns>les informations. </returns>
		protected WebResourceInfo CreateWebResourceInfo(string ressourcePrefix, Type webResourceType)
		{
			return new WebResourceInfo()
			{
				ResourcePrefix = ressourcePrefix
			, RessourceType = webResourceType };
		}
		
		#endregion M�thodes

		#region Propri�t�s
		/// <summary>
		/// Cette handler est-il r�utilisable (Oui, car aucune information n'est sp�cifique � l'instance).
		/// </summary>
		bool IHttpHandler.IsReusable
		{
			get
			{
				return true;
			}
		}

		/// <summary>
		/// Permet de d�finir les informations permettant de retrouver les ressources embarqu�es contenu dans nos assembly.
		/// </summary>
		protected abstract WebResourceInfo[] RessourcesInfos
		{
			get;
		}
		#endregion Propri�t�s
	}
}
