using System.Web;
using System.Web.SessionState;
using QXPFrkWebUser = QXP.Framework.Web.User;
using QXPIO = QXP.Framework.IO;

namespace QXP.Framework.Web.Handler
{
    /// <summary>
    /// Class HelpHandler : Provides methodes to initialized user context request thread
    /// </summary>
    /// <author></author>
    /// <date></date>    
    public class HelpHandler: IHttpHandler, IReadOnlySessionState
    {
        #region Membres

        #endregion Membres

        #region Constantes

        public const string HelpId = "HelpId";
        
        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Constructeur

        /// <summary>
        /// Cr�e une instance de HelpHandler
        /// </summary>
        public HelpHandler()
        {
        }

        #endregion Constructeur

        #region M�thodes

        public void ProcessRequest(HttpContext context)
        {
            HttpRequest __httpRequest = context.Request;
            string __helpId = context.Request[HelpId];

            if (Validation.IsSet(__helpId))
            {
                string __fullHelpFileName = QXPIO.FileHelper.GetFileName("Culture", QXPFrkWebUser.User.Current.Culture.TwoLetterISOLanguageName, "Help", __helpId);
                if (System.IO.File.Exists(__fullHelpFileName))
                {
                    context.Response.ClearHeaders();
                    context.Response.ClearContent();
                    context.Response.Clear();
                    context.Response.WriteFile(__fullHelpFileName, true);
                    context.Response.End();
                }
                else
                {
                    context.Response.Write("Specified Help File does not exist !!");
                }
            }
            else
            {
                context.Response.Write("No Help File specified !!");
            }
        }

        #endregion M�thodes

        #region Evenements

        #endregion Evenements

        #region Propri�t�s

        /// <summary>Gets an <see cref="IHttpHandler"/> object for the current <see cref="HttpRequest"/>. </summary>
        protected virtual IHttpHandler Handler
        {
            get { return null; }
        }

        /// <summary>Gets a value indicating whether another request can use the <see cref="IHttpHandler"/> instance. </summary>
        public bool IsReusable
        {
            get { return true; }
        }

        #endregion Propri�t�s
    }

			
}
