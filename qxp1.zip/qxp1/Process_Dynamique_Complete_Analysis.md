# Process_Dynamique.cs - Complete Code Analysis

**File Path:** `QXP/QXP.Engine.Core/Business/Task/Process_Dynamique.cs`  
**Author:** doufarm  
**Date:** 23/03/2010 17:50:15  
**Description:** Contains the business logic for processing "Task_Dynamique" type tasks. This is the core module for dynamic report generation in the QXP system.

---

## Table of Contents

1. [Constants & Enums](#constants--enums)
2. [Main Entry Point: Process()](#main-entry-point-process)
3. [Stage 1: Get_Report() - SQL to DReport Conversion](#stage-1-get_report---sql-to-dreport-conversion)
4. [Stage 2: Check_Report() - Validation](#stage-2-check_report---validation)
5. [Stage 3: Prepare_Report() - Geometry Calculation](#stage-3-prepare_report---geometry-calculation)
6. [Stage 4: Render_Boxes() - DReport to Blocs](#stage-4-render_boxes---dreport-to-blocs)
7. [Helper Methods](#helper-methods)

---

## Constants & Enums

### Column Name Constants

```csharp
private const string ID_SECTION_COL			= "ID_SECTION"; //optionnelle
private const string ID_TABLE_COL			= "ID_TABLE"; //optionnelle
private const string ID_GROUP_COL			= "ID_GROUPE";
private const string ID_LIGNE_COL			= "ID_LIGNE";
private const string NOM_BLOC_COL			= "NOM_BLOC";
private const string VALEUR_BLOC_COL		= "VALEUR_BLOC";
private const string TEMPLATE_COL			= "TEMPLATE";
private const string ROW_LEVEL_COL			= "ROW_LEVEL";//optionnelle
private const string DESCRIPTION_BLOC_COL	= "DESCRIPTION_BLOC"; //optionnelle
private const string INFO_BLOC_COL			= "INFO_BLOC"; //optionnelle
```

### Pattern Constants

```csharp
private const string Current_Template_Info_Pattern		= "{0}-{1}-{2}-{3}";
private const string New_Page_Pattern					= "{0}_P{1}"; //0 - bloc destination 1 - indexpage
private const string New_Absolute_Cell_Index_Pattern	= "{0}_{1}"; //0 - ancien bloc name 1 - index de la page
```

### Error Constants

```csharp
private const string ErrorDuplicateBlocInTask			= "Duplicate Name Bloc in task : {0} bloc : {1}";
private const string ErrorAddingBlocSQLInTask			= "Error when adding bloc in task : {0} bloc : {1}";
private const string ErrorGettingDataInTask				= "Error when getting data in task : {0}";
```

---

## Main Entry Point: Process()

This is the primary orchestration method that coordinates all four stages of dynamic report processing.

### Method Signature & Flow

```csharp
/// <summary>
/// Création des blocs
/// </summary>
/// <param name="task">la tache</param>
public static void Process(Task_Dynamique task)
{
    DReport						__report		= null;
    //Contexte de génération du rapport dynamique		
    Prepare_Report_Parameters	__prp			= new Prepare_Report_Parameters(task);

    //si le gabarit template est null alors on ne peut rien faire on log l'erreur
    if(QXPFrk.Validation.IsNull(task.Run.Gabarit_Template))
    {
        throw new Exception_Task(Exception_Task.MSG_Gabarit_Template_NULL);
    }

    #region Etape 1: Chargement des paramètres du rapport dynamique à créer !!

    // Chargement des paramètres                   
    QXPDataOracle.OraParameter[] __parameters	= task.Run.InParams.CloneParameters();

    // Appel à la couche proxy : récupération d'un reader
    try
    {
        Proxy_Generic __proxy = new Proxy_Generic();                
        using(QXPDataOracle.OraDataReader __reader = __proxy.GetReader(task.SQL, __parameters))
        {
            // Création des éléments dans le DReport
            if (__reader.HasRows)
            {
                __report = Get_Report(__prp, __reader);
            }
            //pas de donnée
            else
            {
                Trace_Helper.Log_Message(Constantes.Error_Messages.NoSQLDataForTask, task.ID);						
            }
        }
    }
    catch(Exception_Base)
    {
        throw;
    }
    catch(Exception ex)
    {
        Exception_Helper.Raise_Exception(new Exception_Task(ex, Exception_Task.MSG_Execute_SQL, task.Debug_Info), Error_Type.Critique);
    }

    #endregion

    #region Etape 2: Vérification des éléments du rapport
    //seulement s'il y à un rapport dynamique
    if (QXPFrk.Validation.IsNotNull(__report))
    {
        Check_Report(__prp, __report);
    }
    #endregion

    #region Etape 3: Calcule de la géométrie des éléments du rapport
    //seulement s'il y à un rapport dynamique
    if (QXPFrk.Validation.IsNotNull(__report))
    {
        Prepare_Report(__prp, __report);
    }
    
    #endregion
        
    #region Etape 4: A Partir de ces éléments de rapport on construit des blocs ayant les bon types et les bonnes valeurs
    //Si le __report est null c'est traité à l'intérieur car il faut quand même effacer les anciens blocs 
    Render_Boxes(__prp, __report);
    #endregion
}
```

### Process Flow Summary

1. **Initialize** `Prepare_Report_Parameters` context object
2. **Validate** template gabarit is not null
3. **Stage 1** - Execute SQL via Proxy_Generic, call `Get_Report()` to build DReport structure
4. **Stage 2** - Call `Check_Report()` to validate elements and resolve TElement references
5. **Stage 3** - Call `Prepare_Report()` for geometry calculations (positioning, page breaks, column layout)
6. **Stage 4** - Call `Render_Boxes()` to convert DReport elements into Bloc_Page and Bloc_Box instances

---

## Stage 1: Get_Report() - SQL to DReport Conversion

This method reads SQL result set and builds the hierarchical DReport structure: **DReport → DSection → DTable → DRow → DCell → DCell.Values**

### Method Signature

```csharp
/// <summary>
/// Ajout des éléments dans le Report en fonction des informations contenues dans le reader
/// </summary>
/// <param name="prp">Prepare Report Parameters</param>
/// <param name="reader">la source de données à utiliser pour générer le rapport</param>
/// <returns>Une objet DReport</returns>
private static DReport Get_Report(Prepare_Report_Parameters prp, QXPDataOracle.OraDataReader reader)
```

### Complete Implementation

```csharp
private static DReport Get_Report(Prepare_Report_Parameters prp, QXPDataOracle.OraDataReader reader)
{
    DReport				__report	= new DReport();
    Task_Dynamique		__task		= prp.Task;
    
    //affectation des règles de découpages des lignes du rapport
    __report.Page_Break_Rules	= __task.Page_Break_Rules;
    __report.Column_Break_Rules = __task.Column_Break_Rules;

    int					__id_Groupe;	//Permet de spécifier un changement de template (un template peux remplir plusieurs bloc)
    int					__id_Ligne; 
    string				__new_Name;
    string				__data;
    string				__template_Name;
    string				__description_Bloc	= string.Empty;
    string				__info_Bloc			= string.Empty;

    //Changement de section
    bool				__newSection; //a chaque changement de section c'est une nouvelle DSection qui est créée

    //Changement de groupe 
    bool				__newGroup; //a chaque changement de groupe c'est une nouvelle DCell qui est créée mais pas forcement ajoutée dans une nouvelle DRow
    
    //Changement de Ligne
    bool				__newLigne; //à chaque changment de Ligne cest une nouvelle DCell qui est créée et ajoutée dans une nouvelle DRow Row qui est créée

    //Changement de Tableau
    bool				__newTable; //à chaque changment de Tableau cest un nouveau DTable qui est créé et ajoutée dans la section courante 

    //includes Test
    bool				__include_Row_Level				= false;
    bool				__include_ID_Table				= false;
    bool				__include_ID_Section			= false;
    bool				__include_Description_Bloc		= false;
    bool				__include_Info_Bloc				= false;

    //Nous devons stocker les données si le run et en mode store SQL et que la tache est en store_data
    bool				__store_Data					= __task.Store_Data && ((__task.Run.Properties.Store_Type & Store_Data_Type.SQL) == Store_Data_Type.SQL);
    
    int					__id_Section				= int.MinValue;	//Permet d'identifier une section
    int					__id_Table					= int.MinValue; //Permet d'identifier une table
    int					__row_Level					= int.MinValue; //Permet de spécifier un niveau de ligne

    int					__last_id_Section			= int.MinValue;
    int					__last_id_Groupe			= int.MinValue;
    int					__last_id_Table				= int.MinValue;
    int					__last_id_Ligne				= int.MinValue;

    //Current objects
    DSection			__current_DSection			= null;
    DCell				__current_DCell				= null;
    DRow				__current_DRow				= null;
    DTable				__current_DTable			= null;
    Template			__current_Template			= null;
    
    __include_Row_Level			=  reader.Exist_Column(ROW_LEVEL_COL);
    __include_ID_Table			=  reader.Exist_Column(ID_TABLE_COL);
    __include_ID_Section		=  reader.Exist_Column(ID_SECTION_COL);
    __include_Description_Bloc	=  reader.Exist_Column(DESCRIPTION_BLOC_COL);
    __include_Info_Bloc			=  reader.Exist_Column(INFO_BLOC_COL);

    while (reader.Read())
    {
        __id_Groupe			= reader[ID_GROUP_COL];
        __id_Ligne			= reader[ID_LIGNE_COL];
        __new_Name			= reader[NOM_BLOC_COL];
        __data				= reader[VALEUR_BLOC_COL];
        __template_Name		= reader[TEMPLATE_COL];
        
        if(__include_Row_Level)
        {
            __row_Level = reader[ROW_LEVEL_COL];
        }

        if(__include_ID_Table)
        {
            __id_Table = reader[ID_TABLE_COL];
        }

        if(__include_ID_Section)
        {
            __id_Section = reader[ID_SECTION_COL];
        }

        if (__include_Description_Bloc)
        {
            __description_Bloc = reader[DESCRIPTION_BLOC_COL];
        }

        if (__include_Info_Bloc)
        {
            __info_Bloc = reader[INFO_BLOC_COL];
        }

        //Nouvelle Section
        __newSection		= (__id_Section != __last_id_Section);
        //Nouveau Template
        __newGroup		= (__id_Groupe != __last_id_Groupe);
        //Nouvelle Ligne
        __newLigne		= (__id_Ligne != __last_id_Ligne);
        //Nouvelle Table
        __newTable		= (__id_Table != __last_id_Table);

        __last_id_Section	= __id_Section;
        __last_id_Groupe	= __id_Groupe;
        __last_id_Ligne		= __id_Ligne;
        __last_id_Table		= __id_Table;
        
        if(QXPFrk.Validation.IsNull(__current_DSection) || __newSection)
        {
            __current_DSection	= new DSection();
            __report.Sections.Add(__current_DSection);
            //au cas ou on force une nouvelle table / group
            __newTable			= __newGroup = true;
            //Reset de la table
            __current_DTable	= null;
        }
        
        //Utilisation d'un nouveau template
        if(__newGroup)
        {
            //Le template existe
            if(__task.Run.Templates.ContainsKey(__template_Name))
            {
                __current_Template		= __task.Run.Templates[__template_Name];
            }
            //Si le template n'existe pas on essaye d'en créer un temporaire
            else 
            {
                Template __newTemplate = new Template();
                __newTemplate.Name		= __newTemplate.Src_Name = __template_Name;
                __task.Run.Templates.Add(__newTemplate.Name, __newTemplate);
                __current_Template		= __newTemplate;
            }
        }

        //c'est une nouvelle ligne ou un nouveau template on crée un cellule
        if(__newLigne || __newGroup)
        {
            __current_DCell					= new DCell(__current_Template);

            //C'est un élément en position absolu
            if(__current_Template.Absolute)
            {
                //ajout directement dans les cells du groupe
                __current_DSection.Cells.Add(__current_DCell);
            }
            //C'est un élément en position relative
            else
            {
                //ajout d'une table dans la section si aucune table courante ou changement de table
                if(QXPFrk.Validation.IsNull(__current_DTable) || __newTable)
                {
                    __current_DTable = new DTable();
                    //La tache définit t'elle chaque tableau sur une nouvelle page
                    __current_DTable.NewPage = prp.Task.New_Page_Table;
                    __current_DSection.Tables.Add(__current_DTable);
                    //on force la une nouvelle ligne dans le nouveau table
                    __newLigne = true;
                }

                //on ajoute une nouvelle ligne dans le tableau
                if(__newLigne)
                {
                    __current_DRow = new DRow();
                    __current_DTable.Rows.Add(__current_DRow);
                    if(QXPFrk.Validation.IsSet(__row_Level)) __current_DRow.Level = __row_Level;
                }
                __current_DRow.Cells.Add(__current_DCell);
            }
            
        }

        //on ajoute la valeur en cours dans le template
        __current_DCell.Values.Add(__data);
        __current_DCell.NewNames.Add(__new_Name);

        //Si défini au stocke les données générée par la requete
        if (__store_Data)
        {
            __task.DataNamesValues.Add(__new_Name, __data, __description_Bloc, __info_Bloc);
        }
    }
    return __report;
}
```

### Key Algorithm Points

**Hierarchy Building Logic:**
- **Columns Checked:** ID_SECTION, ID_TABLE, ID_GROUP (ID_GROUPE), ID_LIGNE (row), NOM_BLOC (name), VALEUR_BLOC (value), TEMPLATE
- **Optional Columns:** ROW_LEVEL, ID_TABLE, ID_SECTION, DESCRIPTION_BLOC, INFO_BLOC
- **Detection Method:** Comparison with last row values triggers new section/table/row/group
- **Template Resolution:** Looks up template in `__task.Run.Templates` by TEMPLATE column name; if not found, creates temporary template
- **Cell Type:** 
  - **Absolute cells** → added directly to `__current_DSection.Cells`
  - **Relative cells** → added to rows within tables
- **Data Storage:** If task has `Store_Data` enabled, data is also stored in `__task.DataNamesValues`

---

## Stage 2: Check_Report() - Validation

Validates that each DCell has a valid TElement reference. Removes invalid DCells, DRows, DTables, and DSections to "clean" the DReport before geometry calculation.

### Method Signature

```csharp
/// <summary>
/// Avant la preparation du rapport il faut evaluer et vérifier si chaque DCell possède un TElement.
/// Grace à cette fonction il n'y aura plus d'éléments inutiles car il seront supprimer du DReport avant la préparation (evaluation de la géométrie)
/// </summary>
/// <param name="prp">Prepare Report Parameters</param>
/// <param name="report">le DReport à evaluer/vérifier</param>
private static void Check_Report(Prepare_Report_Parameters prp, DReport report)
```

### Complete Implementation

```csharp
private static void Check_Report(Prepare_Report_Parameters prp, DReport report)
{
    Task_Dynamique				__task							= prp.Task;
    bool						__active_Overflow_Template		= (__task.Overflow_Boxes.Count > 0); //s'il y à au moins une boite en overflow les template overflow peuvent être évalués
    QXPFrk.BaseList<DCell>		__dCells_2_Remove				= new QXPFrk.BaseList<DCell>();
    QXPFrk.BaseList<DRow>		__dRows_2_Remove				= new QXPFrk.BaseList<DRow>();
    QXPFrk.BaseList<DTable>		__dTables_2_Remove				= new QXPFrk.BaseList<DTable>();
    QXPFrk.BaseList<DSection>	__dSections_2_Remove			= new QXPFrk.BaseList<DSection>();
    
    QXP_Project			__qxpProject		= __task.Run.Gabarit_Template.QXPProject;
    __qxpProject.Analyse(__task, true);

    foreach (DSection __section in report.Sections)
    {
        #region Vérification des Cellules absolues
        
        __dCells_2_Remove.Clear();
        foreach (DCell __cell in __section.Cells)
        {
            //si la tache contient au moins une boite en overflow
            //Et Si la cellule contient au moins une box en overflow
            __cell.Overflow = (__active_Overflow_Template && __cell.NewNames.ContainsOne(__task.Overflow_Boxes));

            __cell.TElement = TElement_Helper.Evaluate_TElement(__task, __cell);
            if (QXPFrk.Validation.IsNull(__cell.TElement))
            {
                __dCells_2_Remove.Add(__cell);
            }
        }
        //suppression des cells en erreur
        __section.Cells.RemoveAll(__dCells_2_Remove);

        #endregion Vérification des Cellules absolues

        #region Vérification des cellules relatives
        __dTables_2_Remove.Clear();
        foreach (DTable __table in __section.Tables)
        {
            __dRows_2_Remove.Clear();
            foreach (DRow __row in __table.Rows)
            {
                __dCells_2_Remove.Clear();
                foreach (DCell __cell in __row.Cells)
                {
                    //si la tache contient au moins une boite en overflow
                    //Et Si la cellule contient au moins une box en overflow
                    __cell.Overflow = (__active_Overflow_Template && __cell.NewNames.ContainsOne(__task.Overflow_Boxes));
                    
                    __cell.TElement = TElement_Helper.Evaluate_TElement(__task, __cell);
                    if (QXPFrk.Validation.IsNull(__cell.TElement))
                    {
                        __dCells_2_Remove.Add(__cell);
                    }
                }
                //suppression des cells en erreur
                __row.Cells.RemoveAll(__dCells_2_Remove);
                if (__row.Cells.Count == 0)
                {
                    __dRows_2_Remove.Add(__row);
                }
            }
            //suppression des cells en erreur
            __table.Rows.RemoveAll(__dRows_2_Remove);
            if (__table.Rows.Count == 0)
            {
                __dTables_2_Remove.Add(__table);
            }
        }
        #endregion Vérification des cellules relatives
        __section.Tables.RemoveAll(__dTables_2_Remove);
        if (__section.Tables.Count == 0 && __section.Cells.Count == 0)
        {
            __dSections_2_Remove.Add(__section);
        }
    }
    report.Sections.RemoveAll(__dSections_2_Remove);
}
```

### Validation Logic

1. **Project Analysis:** Calls `__qxpProject.Analyse(__task, true)` to analyze project structure
2. **For Each Section:**
   - **Absolute Cells:** Evaluate each via `TElement_Helper.Evaluate_TElement()`. If TElement is null, mark for removal.
   - **Relative Cells (in Tables/Rows):** Same evaluation and removal logic
   - **Overflow Flag:** Set on cell if task has overflow boxes and cell contains overflow box names
   - **Cascading Removal:** If a row has no cells, mark row for removal. If a table has no rows, mark table for removal. If a section has no content, mark for removal.
3. **Result:** Clean DReport with only valid cells that have mapped TElement references

---

## Stage 3: Prepare_Report() - Geometry Calculation

Calculates spatial information for all elements: positioning, available height/width, page breaks, column layout, new page creation, cursor management.

### Main Method: Prepare_Report()

```csharp
/// <summary>
/// Préparation du DReport afin d'évaluer les Informations (spatiales) des éléments du rapport
/// </summary>
/// <param name="prp">Prepare Report Parameters</param>
/// <param name="report">Le rapport à mettre en forme</param>
private static void Prepare_Report(Prepare_Report_Parameters prp, DReport report)
{
    Task_Dynamique	__task = prp.Task;

    //Evaluation de la hauteur de contenu disponible
    if(QXPFrk.Validation.IsNotNull(__task.StartAnchor) && QXPFrk.Validation.IsNotNull(__task.EndAnchor))
    {
        //Vérification de la cohérence du positionnement des ancres
        if(__task.StartAnchor.Bottom < __task.EndAnchor.Top && __task.StartAnchor.Left < __task.StartAnchor.Right)
        {
            prp.Available_Height	= 	__task.EndAnchor.Top - __task.StartAnchor.Bottom;	
            prp.Available_Width		= 	__task.EndAnchor.Left - __task.StartAnchor.Right;	
        }
        else
        {
            Exception_Helper.Raise_Exception(new Exception_Task(Exception_Task.MSG_Ancre_Incoherente, __task.StartAnchor.Name, __task.EndAnchor.Name), Error_Type.Bloquante);
        }
    }

    foreach(DSection __section in report.Sections)
    {
        Prepare_Report_Section(prp, report, __section);
    }

    //si nous sommes en control overflow il faut conserver les noms utilisés
    if (__task.Control_Overflow)
    {
        //Mémorisation des noms traitées pour ce rapport
        //sera utilisée pour des traitement ultérieurs
        //Mais avant on purge pour avoir des listes vides
        __task.Box_Names.Clear();
        foreach (DSection __section in report.Sections)
        {
            //Cells absolutes
            foreach (DCell __cell in __section.Cells)
            {
                __task.Box_Names.AddRange(__cell.NewNames);
            }
            foreach (DTable __table in __section.Tables)
            {
                foreach (DRow __row in __table.Rows)
                {
                    //Cells relatives
                    foreach (DCell __cell in __row.Cells)
                    {
                        __task.Box_Names.AddRange(__cell.NewNames);
                    }
                }
            }
        }
    }
    //Nombre de page dans Report
    report.Info.Nb_Page = prp.Page;
}
```

### Sub-Method: Prepare_Report_Section()

This is the core geometry calculation method. It handles:
- Page breaks
- Column layout
- Cursor positioning
- Multi-column support
- Absolute cell handling
- New page creation

```csharp
/// <summary>
/// Préparation d'une section de rapport (calcul de la position de chaque bloc absolus et relatifs).
/// </summary>
/// <param name="prp">Prepare report parameters</param>
/// <param name="report">le rapport</param>
/// <param name="section">la section</param>
private static void Prepare_Report_Section(Prepare_Report_Parameters prp, DReport report, DSection section)
{
    Task_Dynamique				__task			= prp.Task;

    //Allow to flag the same Cells with the same Id, used to compare Cells to see if it's the same.
    int __cellLogicalId = 0;
    //Permet de savoir que l'on vient d'entrer dans une nouvelle table
    bool						__firstTable	= true; 
    /* Debut - nouvelle section */
    //hauteur en cours de la colonne
    decimal						__tableHeight	= 0;
    //largeur des colonnes précédentes
    decimal						__tableWidth	= 0;
    //Largeur maximum de la colonne en cours
    decimal						__maxWidth		= 0;

    //Permet de mémoriser la position en cours dans la page
    //Attention dans l'ancre de début elle correspond au point en bas à droite de l'ancre 
    DPoint __cursor				= new DPoint(__task.StartAnchor.Right, __task.StartAnchor.Bottom);

    //Il s'agit d'un curseur spécifique pour les row de type break
    //la position de départ est la même que pour le curseur standard
    DPoint __cursor_Break		= new DPoint(__cursor);
    
    prp.Reset();

    //Permet de mémoriser chaque dernière ligne DRow avec Page_Break = true (répétition de ligne en début de page) pour chaque row_level
    //ces DRow seront dupliquées et ajoutées à chaque nouvelle page
    //il s'agit d'une petite collection mais elle doit resté ordonnée donc j'utilise une baselist plutot qu'un dictionary
    QXPFrk.BaseList<DRow> __current_Page_Break_Rows		= new QXPFrk.BaseList<DRow>();

    //Permet de mémoriser chaque dernière ligne DRow avec Column_Break = true (répétition de ligne en début de colonne) pour chaque row_level
    //ces DRow seront dupliquées et ajoutées à chaque nouvelle colonne
    //il s'agit d'une petite collection mais elle doit resté ordonnée donc j'utilise une baselist plutot qu'un dictionary
    QXPFrk.BaseList<DRow> __current_Column_Break_Rows = new QXPFrk.BaseList<DRow>();
    
    //On commence une nouvelle page
    prp.Page++;

    //Chargement du masterPage
    DMaster_Page __master = DMaster_Page.Default; //MasterPage_Helper.Get_MasterPage(__group.ID_MasterPage);
    section.Info.Master_Page	= __master;

    #region Memorisation et preparation des DCells absolues

    //Cellules absolutes positionnée sur Other_Page
    foreach(DCell __cell in section.Cells)
    {                
        __cell.Info.Page		= prp.Page;
        __cell.LogicalId = ++__cellLogicalId;
        __cell.Info.Zone		= Dynamique_Geometry_Helper.Get_Zone(null, __cell);
        //c'est une cellule absolue à répéter sur les autres pages
        if ((__cell.Template.Absolute_Repeat & Absolute_Repeat_Type.Other_Page) == Absolute_Repeat_Type.Other_Page)
        {
            prp.Repeated_Cells.Add(__cell);
            //traitement très particulier.
            //L'objectif étant de mettre le nom des Box clonée entre accolodes exemple [UneBoite_2] que dans le cas ou elle sont clonées.
            //il ne faudra pas cloner les premières cellules si elles ne sont pas sur first_page ou Default.
            //ce n'est pas une cellule absolue présente sur la première page
            if (!(
                ((__cell.Template.Absolute_Repeat & Absolute_Repeat_Type.First_Page) == Absolute_Repeat_Type.First_Page)
                ||
                __cell.Template.Absolute_Repeat == Absolute_Repeat_Type.Default
                    )
                )
            {
                __cell.Downgrade_Generation();
            }
        }

        // to verify if the test is exlusivly in only the last
        if ((__cell.Template.Absolute_Repeat & Absolute_Repeat_Type.Last_Page) == Absolute_Repeat_Type.Last_Page)
        {
            prp.Last_Cells.Add(__cell);
        }
    }
    
    //Suppression des cellules absolues qui ne sont pas positionnées sur First_Page ou sur Default
    section.Cells.RemoveAll
    (
        delegate(DCell cell)
        {
            return !(
                ((cell.Template.Absolute_Repeat & Absolute_Repeat_Type.First_Page) == Absolute_Repeat_Type.First_Page)
                ||
                cell.Template.Absolute_Repeat == Absolute_Repeat_Type.Default
                    );
        }
    );

    #endregion DCells absolues

    #region Traitemant des DCells relatives

    //Positionnement des tableaux
    //Pour chaque Tableau
    foreach(DTable __table in section.Tables)
    {
        //Cas particulier du premier tableau dans le group
        if(!__firstTable)
        {
            if(__table.NewPage)
            {
                //nouvelle page
                prp.Page++;
                //hauteur en cours sur la nouvelle page
                __tableHeight	= 0;
                
                //Chaque Tableau revient
                //à la colonne revient à 1
                prp.Column		= 1;
                // largeur totale des colonnes à 0
                __tableWidth	= 0;
                // largeur max de la colonne en cours
                __maxWidth		= 0;

                //ajout des cellules absolutes 
                Add_Absolute_Cells(prp, section);

                //Reset du curseur à la fin de l'ancre de début !!
                //Attention dans l'ancre de début elle correspond au point en bas à droite de l'ancre 
                __cursor.Reset(__task.StartAnchor.Right, __task.StartAnchor.Bottom);

            }
        }
        else
        {
            __firstTable = false;
            //Chaque Tableau revient
            //à la colonne revient à 1
            prp.Column		= 1;
            // largeur totale des colonnes à 0
            __tableWidth	= 0;
            // largeur max de la colonne en cours
            __maxWidth		= 0;
        }

        
        //représente le nombre maximum de ligne dans le table
        //cette valeur peut évoluer en fonction du nombre de row ajouter par les fonctions de page breaks
        int __max_Rows = __table.Rows.Count;

        for(int __index_Row = 0 ;__index_Row < __max_Rows; __index_Row++)
        {
            //La DRow en cours
            DRow	__row	= __table.Rows[__index_Row];
            
            //on conserve la liste des DRow de type page break row
            //si au moins une cellule à un template de type Page_Break alors toute la ligne est de ce type
            //dans ce cas cette ligne n'est pas traitée comme une ligne de tableau relative habituelle elle est conservé et ajoutée (par copie) uniquement sur les nouvelles pages
            if (__row.Page_Break || __row.Column_Break)
            {
                //ajout de la ligne de type break en cours à la liste des lignes à supprimer par la suite
                //ces instances de lignes ne feront pas partie du rendu final, ou alors par duplication
                prp.Rows_2_Remove.Add(__row);

                //Traitement des lignes en page break (répétition de ligne sur changement de page)
                if (__row.Page_Break)
                {

                    //recherche de l'index de la dernière ligne possédant le même Level que la ligne en cours __row
                    int __index = __current_Page_Break_Rows.FindIndex
                                    (delegate(DRow row)
                        {
                            return (row.Level == __row.Level);
                        }
                    );

                    //Un Drow existe déjà pour ce row_level on le remplace (l'ancien est totalement ignoré du process)
                    if (__index >= 0)
                    {
                        //Copie de la geometrie de l'ancienne row
                        DRow __old_row = __current_Page_Break_Rows[__index];

                        //Transfert les informations de geometrie de l'ancienne row dans la nouvelle
                        Transfert_RowCells_Info(__old_row, __row);

                        //Avant chaque ajout ou modification il faut recréé une liste pour ne pas modifier les anciennes row
                        __current_Page_Break_Rows = new QXPFrk.BaseList<DRow>(__current_Page_Break_Rows);

                        //remplacement par la nouvelle row
                        __current_Page_Break_Rows[__index] = __row;
                    }
                    //Aucun Drow pour ce row_level on l'ajoute
                    else
                    {
                        //Définition de la géométrie de la ligne à répéter
                        //initialisation de la nouvelle ligne à répéter
                        //Cette initialisation défini la géométrie en fonction du cursor page break qui est un curseur spécifique pour les rows de type page break
                        //Cette geometrie est identique sur toute les pages (sauf position left/top qui seront mise à jour plus tard)
                        Prepare_Report_Cells(prp, __row, __cursor_Break);

                        //Avant chaque ajout ou modification il faut recréé une liste pour ne pas modifier les anciennes row
                        __current_Page_Break_Rows = new QXPFrk.BaseList<DRow>(__current_Page_Break_Rows);

                        __current_Page_Break_Rows.Add(__row);

                        //Réinitialisation du cursor page break
                        //Attention dans l'ancre de début elle correspond au point en bas à droite de l'ancre 
                        __cursor_Break.Left = __task.StartAnchor.Right;
                        __cursor_Break.Top += __row.Info.Height;

                    }
                }

                //Traitement des lignes en column break (répétition de ligne sur changement de colonne)
                if (__row.Column_Break)
                {
                    //recherche de l'index de la dernière ligne possédant le même Level que la ligne en cours __row
                    int __index = __current_Column_Break_Rows.FindIndex
                                    (delegate(DRow row)
                        {
                            return (row.Level == __row.Level);
                        }
                    );

                    //Un Drow existe déjà pour ce row_level on le remplace (l'ancien est totalement ignoré du process)
                    if (__index >= 0)
                    {
                        //Copie de la geometrie de l'ancienne row
                        DRow __old_row = __current_Column_Break_Rows[__index];

                        //Transfert les informations de geometrie de l'ancienne row dans la nouvelle
                        Transfert_RowCells_Info(__old_row, __row);

                        //Avant chaque ajout ou modification il faut recréé une liste pour ne pas modifier les anciennes row
                        __current_Column_Break_Rows = new QXPFrk.BaseList<DRow>(__current_Column_Break_Rows);

                        //remplacement par la nouvelle row
                        __current_Column_Break_Rows[__index] = __row;
                    }
                    //Aucun Drow pour ce row_level on l'ajoute
                    else
                    {
                        //Définition de la géométrie de la ligne en page break
                        //initialisation de la nouvelle ligne de type page break
                        //Cette initialisation défini la géométrie en fonction du cursor page break qui est un curseur spécifique pour les rows de type page break
                        //Cette geometrie est identique sur toute les pages (sauf position left/top qui seront mise à jour plus tard)
                        Prepare_Report_Cells(prp, __row, __cursor_Break);

                        //Avant chaque ajout ou modification il faut recréé une liste pour ne pas modifier les anciennes row
                        __current_Column_Break_Rows = new QXPFrk.BaseList<DRow>(__current_Column_Break_Rows);

                        __current_Column_Break_Rows.Add(__row);

                        //Réinitialisation du cursor page break
                        //Attention dans l'ancre de début elle correspond au point en bas à droite de l'ancre 
                        __cursor_Break.Left = __task.StartAnchor.Right;
                        __cursor_Break.Top += __row.Info.Height;

                    }						
                }

                //Le premier clonnage de cette row n'entrainera pas de renommage
                Downgrade_Report_Cells(__row);

                //Dans ce cas nous ne faisons aucun autre traitement sur la Drow Cest une page break elle sera utilisée (cloner) lors des sauts de page (puis effacée)
                continue;
            }
            
            //Cas ou c'est une ligne normale, on l'ajoute

            //on affecte les pages break row à la ligne en cours
            __row.Page_Break_Rows	= __current_Page_Break_Rows;
            __row.Column_Break_Rows = __current_Column_Break_Rows;

            Prepare_Report_Cells(prp, __row, __cursor);

            //on ajoute la hauteur de la ligne au tableau !
            __tableHeight += __row.Info.Height;

            //on vérifie que la hauteur des lignes sur la page en cours peut tenir sur la hauteur disponible entre les 2 ancres
            //Si ce n'est pas le cas il faut ajouter une page (sinon on continu)
            if (__tableHeight > prp.Available_Height)
            {
                //Faut-il ajouter une nouvelle colonne ou une nouvelle page
                if (prp.Column < __task.Nb_Column)
                {

                    //ajout d'une nouvelle colonne
                    prp.Column++;
                    
                    //il faut penser à ajouter la l'espace entre les colonnes
                    __tableWidth	+= (__maxWidth + __task.Column_Space);

                    //Traitement des règles de rupture de page (page break rules) et recopie des pages break (entête de page)
                    Dynamique_Page_Break_Helper.Update_Rows(report, __table.Rows, __row, prp, false, __tableWidth);

                    //la nouvelle hauteur/largeur de la page sur la nouvelle colonne
                    __tableHeight	= prp.Current_Table_Height;
                    __maxWidth		= prp.Current_Table_Width;

                    //des lignes ont peut-être été ajouter sur la nouvelle page dû au fonction de page break
                    //il faut tenir compte de ce décalage de ligne
                    __index_Row += prp.Nb_Rows_Added;

                    //on fait également évoluer le nombre maximum de ligne dans le table
                    __max_Rows += prp.Nb_Rows_Added;

                }
                else
                {
                    //ajout d'une nouvelle page
                    prp.Page++;
                    //Réinitialisation de la colonne à 1
                    prp.Column = 1;

                    //Traitement des règles de rupture de page (page break rules) et recopie des pages break (entête de page)
                    Dynamique_Page_Break_Helper.Update_Rows(report, __table.Rows, __row, prp, true, 0);

                    //la nouvelle hauteur/largeur de la page sur la nouvelle colonne
                    __tableHeight	= prp.Current_Table_Height;
                    __tableWidth	= 0;
                    __maxWidth		= prp.Current_Table_Width;

                    //des lignes ont peut-être été ajouter sur la nouvelle page dû au fonction de page break
                    //il faut tenir compte de ce décalage de ligne
                    __index_Row += prp.Nb_Rows_Added;

                    //on fait également évoluer le nombre maximum de ligne dans le table
                    __max_Rows += prp.Nb_Rows_Added;

                    //Ajoute des cellules absolues sur la nouvelle page
                    Add_Absolute_Cells(prp, section);

                }
            }
            else
            {
                //on conserve la largeur maximum des lignes normales de la colonne en cours
                __maxWidth	= Math.Max(__maxWidth, __row.Info.Width);
            }
                    
            //Réinitialisation du cursor;
            //Attention dans l'ancre de début elle correspond au point en bas à droite de l'ancre 
            __cursor.Left	= __task.StartAnchor.Right + __tableWidth;
            __cursor.Top	= __task.StartAnchor.Bottom + __tableHeight;

        }

        //Suppression de toutes les lignes de type page Break rows (répétition entête de colonne)
        __table.Rows.RemoveAll(prp.Rows_2_Remove);
    }
    // Add last absolute Cells
    AddLastAbsoluteCells(prp, section);
    #endregion		
}
```

### Sub-Method: Prepare_Report_Cells()

Calculates geometry (left, top, width, height) for individual cells and rows.

```csharp
/// <summary>
/// Préparation des cellules de ligne row 
/// La préparation consiste à calculer la géométrie de chaques cellules et lignes
/// La géométrie défini la left/top/hauteur/largeur etc..
/// </summary>
/// <param name="prp">Prepare Report parameters</param>
/// <param name="row">la ligne qui contient les cellules à préparer</param>
/// <param name="cursor">Le curseur de la position en cours, ce curseur est utilisé pour déterminer par exemple la position left/top actuelle</param>
private static void Prepare_Report_Cells(Prepare_Report_Parameters prp, DRow row, DPoint cursor)
{
    decimal		__rowHeight		= 0;
    decimal		__rowWidth		= 0;
    bool		__heightPercent = QXPFrk.Validation.IsSet(row.Info.Height, false);
    decimal		__cellHeight	= 0;

    foreach(DCell __cell in row.Cells)
    {
        
        __cell.Info.Page	= prp.Page;
        if(__heightPercent)
        {
            // La marge n'est pas appliquée dans ce cas (ça parait plus logique non ?)
            __cellHeight	= Math_Helper.GetValPercent(row.Info.Height, __cell.Template.Height_Percent);
        }
        else
        {
            __cellHeight	= Dynamique_Geometry_Helper.Get_CellHeight_WithTop(__cell);
        }
        __rowHeight			= Math.Max(__rowHeight, __cellHeight);
        __rowWidth			+= Dynamique_Geometry_Helper.Get_CellWidth_WithLeft(__cell);

        __cell.Info.Zone	= Dynamique_Geometry_Helper.Get_Zone_And_Update_Cursor(cursor, __cell); 
        
    }
    row.Info.Height	= __rowHeight;
    row.Info.Width  = __rowWidth; //pour info pour l'instant car inutilisé
    row.Info.Page	= prp.Page;
    row.Info.Column	= prp.Column;
}
```

### Geometry Calculation Key Points

1. **Anchor Validation:** StartAnchor.Bottom < EndAnchor.Top (vertical space), StartAnchor.Left < StartAnchor.Right (horizontal validation)
2. **Available Space:** 
   - `Available_Height = EndAnchor.Top - StartAnchor.Bottom`
   - `Available_Width = EndAnchor.Left - StartAnchor.Right`
3. **Absolute Cells:** Categorized by repeat type (First_Page, Other_Page, Last_Page, Default)
4. **Break Rows:** 
   - Page_Break rows repeat at top of each new page
   - Column_Break rows repeat at top of each new column
   - Stored by row_level to handle hierarchies
5. **Cursor Management:** 
   - Standard cursor tracks position in current column
   - Break cursor tracks position for headers
   - Cursor reset on new page/column
6. **Multi-Column Support:** Can fit multiple columns on one page using `Nb_Column`
7. **Dynamic Pagination:** Adds new page or column when `__tableHeight > Available_Height`
8. **Helper Functions Used:**
   - `Dynamique_Geometry_Helper.Get_CellHeight_WithTop()` - cell height calculation
   - `Dynamique_Geometry_Helper.Get_CellWidth_WithLeft()` - cell width calculation
   - `Dynamique_Geometry_Helper.Get_Zone_And_Update_Cursor()` - positioning + cursor update
   - `Dynamique_Page_Break_Helper.Update_Rows()` - page break rule application

---

## Stage 4: Render_Boxes() - DReport to Blocs

Converts prepared DReport structure into Bloc_Page and Bloc_Box instances that can be executed by QXPS_Modifier.

### Method Signature

```csharp
/// <summary>
/// Permet de convertir les objets du rapport vers des objects blocs qui sont ajouter à la tache et qui pourront ensuite être interprétés par le QXPS_Modifier
/// </summary>
/// <param name="prp">Prepare Report Parameters</param>
/// <param name="report">le rapport à partir duquel il faut évaluer les Bloc</param>
private static void Render_Boxes(Prepare_Report_Parameters prp, DReport report)
```

### Complete Implementation

```csharp
private static void Render_Boxes(Prepare_Report_Parameters prp, DReport report)
{
    Task_Dynamique	__task			= prp.Task;
    Bloc_Page		__bloc_Page;
    Bloc_Box		__bloc_start;
    Bloc_Box		__bloc_end;

    int			__nbNewPage;

    if (QXPFrk.Validation.IsNull(report))
    {
        __nbNewPage = 1;
    }
    else
    {
        __nbNewPage = report.Info.Nb_Page;
    }

    //1 - Il faut d'abord ajouter les bloc_page à créer !!
    for(int __i = 0; __i < __nbNewPage; __i++)
    {
        __bloc_Page					= new Bloc_Page(__task, string.Format(New_Page_Pattern, __task.DestinationBlocName, __i));
        __bloc_Page.Action			= Bloc_Action.CREATE;
        __bloc_Page.Relative_Page	= __i;
        __task.Blocs_Modify.Add(__bloc_Page.Name, __bloc_Page);
    }

    //2 - Enfin supprimer les anciennes page (+1 car si la page des ancres est la même il y à une page)
    int __nb_Ancien_Page		= (__task.EndAnchor.Page - __task.StartAnchor.Page) + 1;
    int __relative_remove_page;

    for(int __i = 0; __i < __nb_Ancien_Page; __i++)
    {
        __relative_remove_page				= __nbNewPage + __i;
        __bloc_Page							= new Bloc_Page(__task, string.Format(New_Page_Pattern, __task.DestinationBlocName, __relative_remove_page));
        __bloc_Page.Action					= Bloc_Action.REMOVE;
        __bloc_Page.Relative_Page			= __relative_remove_page;
        __task.Blocs_Modify.Add(__bloc_Page.Name, __bloc_Page);
    }

    __bloc_start			= TElement_Helper.Get_Move_Anchor(__task, __task.StartAnchor, 0);
    //Cette modification doit être effectuée en même temps que la nouvelle pagination
    __bloc_start.Pagination	= true;
    __task.Blocs_Modify.Add(__bloc_start.Name, __bloc_start);

    //4 - deplacement de l'ancre en dernière page créée
    
    __bloc_end				= TElement_Helper.Get_Move_Anchor(__task, __task.EndAnchor, __nbNewPage -1);
    //Cette modification doit être effectuée en même temps que la nouvelle pagination
    __bloc_end.Pagination	= true;
    __task.Blocs_Modify.Add(__bloc_end.Name, __bloc_end);


    //Si le rapport est null il n'y à rien à ajouter
    if (QXPFrk.Validation.IsNotNull(report))
    {
        //2 - Ensuite création de tous les blocs (bloc_box) constituant les pages 
        foreach (DSection __dSection in report.Sections)
        {
            //Cellules absolues
            foreach (DCell __dCell in __dSection.Cells)
            {
                Add_DCell_Blocs(__dCell, __task);
            }

            //Cellules relatives
            foreach (DTable __dTable in __dSection.Tables)
            {
                foreach (DRow __dRow in __dTable.Rows)
                {
                    foreach (DCell __dCell in __dRow.Cells)
                    {
                        Add_DCell_Blocs(__dCell, __task);
                    }
                }
            }
        }
    }

}
```

### Render Logic

1. **Determine Page Count:** From report.Info.Nb_Page (or 1 if report is null)
2. **Create New Pages:** For each new page index, create Bloc_Page with:
   - Name: Format string `"{DestinationBlocName}_P{i}"` (e.g., "MyBlock_P0", "MyBlock_P1")
   - Action: `CREATE`
   - RelativePage: Page index
3. **Remove Old Pages:** Calculate old page range from anchors and create Bloc_Page with Action: `REMOVE`
4. **Move Anchors:** 
   - StartAnchor moved to page 0 with Pagination=true
   - EndAnchor moved to last page with Pagination=true
5. **Add Content Blocs:** Iterate all DCell objects and convert each to blocs via `Add_DCell_Blocs()`

---

## Helper Methods

### Downgrade_Report_Cells()

Sets cell generation to 0, so first cloning doesn't rename boxes.

```csharp
/// <summary>
/// Permet de mettre la génération de chaque cell à 0. Le premier clonage ne renommera pas les Boxes contenues la première fois
/// </summary>
/// <param name="row">la ligne contenant les DCell à downgrader. </param>
private static void Downgrade_Report_Cells(DRow row)
{
    foreach (DCell __cell in row.Cells)
    {
        __cell.Downgrade_Generation();
    }
}
```

### Transfert_RowCells_Info()

Transfers geometry info from old row to new row (used for page/column break rows).

```csharp
/// <summary>
/// Transfert des informations de l'ancienne ligne vers la nouvelle lignes
/// </summary>
/// <param name="old_row">ancien ligne</param>
/// <param name="new_row">nouvelle ligne</param>
private static void Transfert_RowCells_Info(DRow old_row, DRow new_row)
{
    new_row.Info = old_row.Info;
    
    //il faut que les anciennes lignes et la nouvelle aient le même nombre de cellules
    for(int __i=0; __i < old_row.Cells.Count;__i++)
    {
        new_row.Cells[__i].Info = old_row.Cells[__i].Info;
    } 

}
```

### Add_Absolute_Cells()

Clones and adds repeated absolute cells to new page.

```csharp
/// <summary>
/// Permet de dupliquer les cellules absolutes et de renommer les éléments internes
/// </summary>
/// <param name="prp">Prepare Report Parameters</param>
/// <param name="new_Section">la section dans l'aquelle il faut ajouter les cellules absolues</param>
private static void Add_Absolute_Cells(Prepare_Report_Parameters prp, DSection new_Section)
{
    foreach(DCell __src_Cell in prp.Repeated_Cells)
    {
        DCell __new_Cell = __src_Cell.Clone();
        
        //Mise à jour de la nouvelle page dans la nouvelle cell
        __new_Cell.Info.Page = prp.Page;
        
        new_Section.Cells.Add(__new_Cell);
    }
}
```

### AddLastAbsoluteCells()

Adds absolute cells marked for last page, avoiding duplicates.

```csharp
/// <summary>
/// Add last absolute Cells
/// </summary>
/// <param name="prp"></param>
/// <param name="new_Section"></param>
private static void AddLastAbsoluteCells(Prepare_Report_Parameters prp, DSection new_Section)
{
    //Cells in the last Page
    IEnumerable<DCell> __CellsInlastPages = new_Section.Cells.Where(__cell => __cell.Info.Page == prp.Page);
    // Add the absolute last_cells
    foreach (DCell __src_Cell in prp.Last_Cells)
    {
        if (!__CellsInlastPages.Contains(__src_Cell))
        {
            //clone cell
            DCell __new_Cell = __src_Cell.Clone();
            //update the page info
            __new_Cell.Info.Page = prp.Page;
            //add cell to new section
            new_Section.Cells.Add(__new_Cell);
        }
    }
}
```

### Add_DCell_Blocs()

Converts a DCell into blocs and adds to task.

```csharp
/// <summary>
/// Permet de convertir une DCell en liste de blocs et d'ajouter ces blocs dans la tache
/// </summary>
/// <param name="dCell">la cellule contenant les blocs à ajouter dans la tache</param>
/// <param name="task">la tache dans laquelle il faut ajouter les blocs</param>
public static void Add_DCell_Blocs(DCell dCell, Task_Dynamique task)
{
    try
    {
        //Analyse de la DCell et Creation des blocs
        Bloc_Base __bloc = TElement_Helper.Get_Bloc(dCell, task);

        if(QXPFrk.Validation.IsNotNull(__bloc))
        {
            if(task.Blocs_Modify.ContainsKey(__bloc.Name))
            {
                task.Run.Errors.Add(Constantes.Error_Messages.DuplicateBlocName, __bloc.Name, task.Debug_Info);
            }
            else
            {
                task.Blocs_Modify.Add(__bloc.Name, __bloc);
            }
        }
        else
        {
            task.Run.Errors.Add(Constantes.Error_Messages.NullBlocs);
        }
    }
    catch(Exception ex)
    {
        //Erreur non bloquante
        task.Run.Errors.Add(ex.ToString());
    }
}
```

---

## Key Supporting Classes & Interfaces

### Prepare_Report_Parameters
Context object passed through all stages containing:
- Reference to Task_Dynamique
- Current page, column counters
- Available_Height, Available_Width
- Repeated_Cells, Last_Cells
- Rows_2_Remove list
- Reset() method to reinitialize for new section

### DReport Structure
```
DReport
├── Info.Nb_Page
├── Page_Break_Rules
├── Column_Break_Rules
└── Sections[]
    ├── Cells[] (absolute DCells)
    └── Tables[]
        └── Rows[]
            └── Cells[] (relative DCells)
```

### DCell
- Template (reference to Template object)
- Values (list of data values)
- NewNames (list of block names)
- TElement (resolved template element reference)
- Info (geometry: page, zone, left, top, width, height)
- Overflow flag
- LogicalId
- Generation counter

### DPoint
Cursor position with Left, Top, Reset() method

### Template Resolution
- Lookup in `__task.Run.Templates` by TEMPLATE column name
- If not found, create temporary Template with Src_Name = template name
- TElement_Helper.Evaluate_TElement() resolves template to actual element

### Anchor Management
- StartAnchor, EndAnchor are TElement references with Bottom, Top, Left, Right coordinates
- Validation: Bottom < Top (vertical), Left < Right (horizontal)
- Anchor pages tracked to calculate old page range for removal

---

## Error Handling

- **Template Null:** Throws Exception_Task with MSG_Gabarit_Template_NULL
- **SQL Error:** Catches and re-throws as Exception_Task with MSG_Execute_SQL
- **No SQL Data:** Logs to Trace_Helper, continues with null report
- **Anchor Incoherence:** Raises blocking exception with MSG_Ancre_Incoherente
- **Duplicate Bloc Names:** Added to task.Run.Errors, continues
- **Null Blocs:** Added to task.Run.Errors, continues
- **Cell Conversion Errors:** Caught and logged non-blocking

---

## Summary of Data Flow

```
SQL Query
    ↓
Proxy_Generic.GetReader()
    ↓
Get_Report() → builds DReport with SQL result structure
    ↓
Check_Report() → validates TElement references, removes invalid cells
    ↓
Prepare_Report() → calculates geometry, handles page/column breaks
    ↓
Render_Boxes() → creates Bloc_Page and Bloc_Box from DReport
    ↓
task.Blocs_Modify → ready for QXPS_Modifier execution
```

---

**End of Complete Process_Dynamique.cs Analysis**
