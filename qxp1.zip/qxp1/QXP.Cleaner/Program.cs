﻿using System;
using System.IO;

using QXPAuditProxy         = QXP.Audit.Proxy;
using QXPConfiguration      = QXP.Framework.Configuration;
using QXPDiagnostic         = QXP.Framework.Diagnostic;
using QXPFrk                = QXP.Framework;

namespace QXP.Cleaner
{
    class Program
    {
        #region Membres

        #endregion Membres

        #region Constantes

        #endregion Constantes

        #region Enums

        #endregion Enums

        #region Méthodes

        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                Console.WriteLine(string.Concat(DateTime.Now, " Démarrage de QXP.Cleaner : "));
                QXPAuditProxy.ProxyAuditBatch.Current.InsertTraceBatch(string.Concat("Début d'exécution de QXP.Cleaner : ", DateTime.Now));

                CleanDocumentDirectories();
                CleanUploadDirectories();
            }
            catch (System.Exception ex)
            {
                Console.WriteLine("Cleaner - Erreur lors de l'exécution");
                Console.WriteLine(ex.ToString());

                QXPDiagnostic.Log.LogError("Cleaner - Erreur lors de l'exécution", ex);
            }
            finally
            {
                QXPAuditProxy.ProxyAuditBatch.Current.InsertTraceBatch(string.Concat("Fin d'exécution de QXP.Cleaner : ", DateTime.Now));
                Console.WriteLine(string.Concat(DateTime.Now, " Fin d'exécution de QXP.Cleaner"));
            }
        }

        /// <summary>
        /// Supprimer les fichiers pris en compte par l'upload
        /// </summary>
        static void CleanUploadDirectories()
        {
            QXPFrk.BaseList<string> __files = new QXPFrk.BaseList<string>();
            int __nbFiles = 0;

            #region Récupération des paramètres

            // Répertoire contenant les fichiers ayant été traités par l'upload
            string __uploadOKDirectory = QXPConfiguration.Settings.Current.GetString("UploadOKDirectory");
            // Répertoire contenant les fichiers n'ayant pas pu être traités correctement par l'upload
            string __uploadKODirectory = QXPConfiguration.Settings.Current.GetString("UploadKODirectory");
            // Nombre de jours d'ancienneté depuis aujourd'hui des fichiers et répertoires à supprimer
            int __anciennete = QXPConfiguration.Settings.Current.GetInt("Anciennete");

            #endregion Récupération des paramètres

            #region Traitement des fichiers

            // 1) __uploadKODirectory
            // Récupération des chemins des fichiers
            if (Directory.Exists(__uploadKODirectory))
                __files.AddRange(Directory.GetFiles(__uploadKODirectory));

            // Suppression des fichiers
            __nbFiles = DeleteFiles(__files, __anciennete);

            // Audit de l'action effectuée
            QXPAuditProxy.ProxyAuditBatch.Current.InsertTraceBatch(string.Concat(__nbFiles, " fichiers supprimés du répertoire ", __uploadKODirectory));
            Console.WriteLine(string.Concat(__nbFiles, " fichiers supprimés du répertoire ", __uploadKODirectory));
            
            // 2) __uploadKODirectory
            __files.Clear();
            // Récupération des chemins des fichiers
            if (Directory.Exists(__uploadOKDirectory))
                __files.AddRange(Directory.GetFiles(__uploadOKDirectory));

            // Suppression des fichiers
            __nbFiles = DeleteFiles(__files, __anciennete);

            // Audit de l'action effectuée
            QXPAuditProxy.ProxyAuditBatch.Current.InsertTraceBatch(string.Concat(__nbFiles, " fichiers supprimés du répertoire ", __uploadOKDirectory));
            Console.WriteLine(string.Concat(__nbFiles, " fichiers supprimés du répertoire ", __uploadOKDirectory));
            
            #endregion Traitement des fichiers
        }

        /// <summary>
        /// Supprime les répertoires et fichiers utilisés et générés par Quark lors des runs
        /// </summary>
        static void CleanDocumentDirectories()
        {
            QXPFrk.BaseList<string> __directories = new QXPFrk.BaseList<string>();
            QXPFrk.BaseList<string> __files = new QXPFrk.BaseList<string>();

            int __nbDirectories = 0;
            int __nbFiles = 0;

            #region Récupération des paramètres

            // Répertoire de travail de Quark
            string __documentDirectory = QXPConfiguration.Settings.Current.GetString("DocumentDirectory");
            // Répertoire de travail de Quark pour les fichiers issus de l'upload
            string __documentUploadDirectory = QXPConfiguration.Settings.Current.GetString("DocumentUploadDirectory");
            // Répertoire image de DocumentDirectory pour le mode debug
            string __documentResultDirectory = QXPConfiguration.Settings.Current.GetString("DocumentResultDirectory");
            // Répertoire image de DocumentUploadDirectory pour le mode debug
            string __documentResultUploadDirectory = QXPConfiguration.Settings.Current.GetString("DocumentResultUploadDirectory");
            // Nombre de jours d'ancienneté depuis aujourd'hui des fichiers et répertoires à supprimer
            int __anciennete = QXPConfiguration.Settings.Current.GetInt("Anciennete");

            #endregion Récupération des paramètres

            #region Traitement des répertoires

            // 1) __documentDirectory
            // Récupération des répertoires
            if (Directory.Exists(__documentDirectory))
                __directories.AddRange(Directory.GetDirectories(__documentDirectory));

            // Le répertoire Upload n'est pas supprimé, mais il sera vidé après de son contenu
            __directories.Remove(__documentUploadDirectory);

            // Suppression des répertoires
            __nbDirectories = DeleteDirectories(__directories, __anciennete);

            // Audit de l'action effectuée
            QXPAuditProxy.ProxyAuditBatch.Current.InsertTraceBatch(string.Concat(__nbDirectories, " répertoires supprimés du répertoire ", __documentDirectory));
            Console.WriteLine(string.Concat(__nbDirectories, " répertoires supprimés du répertoire ", __documentDirectory));

            // 2) __documentResultDirectory
            __directories.Clear();
            // Récupération des répertoires
            if (Directory.Exists(__documentResultDirectory))
                __directories.AddRange(Directory.GetDirectories(__documentResultDirectory));

            // Le répertoire Upload n'est pas supprimé, mais il sera vidé après de son contenu
            __directories.Remove(__documentResultUploadDirectory);

            // Suppression des répertoires
            __nbDirectories = DeleteDirectories(__directories, __anciennete);

            // Audit de l'action effectuée
            QXPAuditProxy.ProxyAuditBatch.Current.InsertTraceBatch(string.Concat(__nbDirectories, " répertoires supprimés du répertoire ", __documentResultDirectory));
            Console.WriteLine(string.Concat(__nbDirectories, " répertoires supprimés du répertoire ", __documentResultDirectory));
            
            #endregion Traitement des répertoires

            #region Traitement des fichiers

            // 1) __documentUploadDirectory
            // Récupération des chemins des fichiers
            if (Directory.Exists(__documentUploadDirectory))
                __files.AddRange(Directory.GetFiles(__documentUploadDirectory));

            // Suppression des fichiers
            __nbFiles = DeleteFiles(__files, __anciennete);

            // Audit de l'action effectuée
            QXPAuditProxy.ProxyAuditBatch.Current.InsertTraceBatch(string.Concat(__nbFiles, " fichiers supprimés du répertoire ", __documentUploadDirectory));
            Console.WriteLine(string.Concat(__nbFiles, " fichiers supprimés du répertoire ", __documentUploadDirectory));

            // 2) __documentResultUploadDirectory
            __files.Clear();
            // Récupération des chemins des fichiers
            if (Directory.Exists(__documentResultUploadDirectory))
                __files.AddRange(Directory.GetFiles(__documentResultUploadDirectory));

            // Suppression des fichiers
            __nbFiles = DeleteFiles(__files, __anciennete);

            // Audit de l'action effectuée
            QXPAuditProxy.ProxyAuditBatch.Current.InsertTraceBatch(string.Concat(__nbFiles, " fichiers supprimés du répertoire ", __documentResultUploadDirectory));
            Console.WriteLine(string.Concat(__nbFiles, " fichiers supprimés du répertoire ", __documentResultUploadDirectory));
            
            #endregion Traitement des fichiers
        }

        /// <summary>
        /// Supprime les fichiers donnés
        /// </summary>
        /// <param name="files">Liste des fichiers à supprimer</param>
        /// <param name="anciennete">Nombre de jours d'ancienneté minimum depuis aujourd'hui des fichiers à supprimer</param>
        /// <returns>Nombre de fichiers supprimés</returns>
        static int DeleteFiles(QXPFrk.BaseList<string> files, int anciennete)
        {
            int __nbDeleted = 0;

            files.ForEach
            (
                delegate(string __file)
                {
                    try
                    {
                        if (File.GetCreationTime(__file) < DateTime.Now.Subtract(new TimeSpan(anciennete, 0, 0, 0)))
                        {
                            File.Delete(__file);
                            __nbDeleted++;
                        }
                    }
                    catch (Exception ex)
                    {
                        QXPDiagnostic.Log.LogError(string.Concat("Cleaner - Erreur lors de la suppression du fichier ", __file), ex);
                    }
                }
            );

            return __nbDeleted;
        }

        /// <summary>
        /// Supprime les répertoires donnés
        /// </summary>
        /// <param name="directories">Liste des répertoires à supprimer</param>
        /// <param name="anciennete">Nombre de jours d'ancienneté minimum depuis aujourd'hui des répertoires à supprimer</param>
        /// <returns>Nombre de répertoires supprimés</returns>
        static int DeleteDirectories(QXPFrk.BaseList<string> directories, int anciennete)
        {
            int __nbDeleted = 0;

            directories.ForEach
            (
                delegate(string __directory)
                {
                    try
                    {
                        if (Directory.GetCreationTime(__directory) < DateTime.Now.Subtract(new TimeSpan(anciennete, 0, 0, 0)))
                        {
                            Directory.Delete(__directory, true);
                            __nbDeleted++;
                        }
                    }
                    catch (Exception ex)
                    {
                        QXPDiagnostic.Log.LogError(string.Concat("Cleaner - Erreur lors de la suppression du répertoire ", __directory), ex);
                    }
                }
            );

            return __nbDeleted;
        }


        #endregion Méthodes

        #region Evènements

        #endregion Evènements

        #region Propriétés

        #endregion Propriétés
    }
}