# Annual Report Document Naming Format Specification

## Overview
The document name format for annual report type documents follows a specific pattern:
**`[Fund ID] - [Fund Name] - [Date] - [Report Type Code] - [Language Code]`**

**Example:** `74078 - PATRIMOINE REACTIF - 31-12-2024 - RA - FR`

---

## Format Components

| Component | Description | Source | Example |
|-----------|-------------|--------|---------|
| **Fund ID** | Unique identifier for the fund (ID_FND_CODE) | SuiviPortefeuille.Id property | `74078` |
| **Fund Name** | Long name/description of the fund (FND_LNG_DESCRIPTION) | SuiviPortefeuille.LibelleLong property | `PATRIMOINE REACTIF` |
| **Date** | Report generation/reporting date in DD-MM-YYYY format (date_echeance) | SuiviPortefeuille.EcheanceNext property | `31-12-2024` |
| **Report Type Code** | Short code representing the type of report | Gabarit.TypeRapport enum | `RA` (RapportAnnuel) |
| **Language Code** | ISO 639-1 language code | Langue.Code property | `FR` (Français) |

---

## Architecture Location: QXP.Engine Project

### Key Classes Involved

#### 1. **QXP.Engine.Core.BusinessObject.Document.Document**
   - **File:** `QXP.Engine.Core\BusinessObject\Document\Document.cs`
   - **Purpose:** Manages document metadata and file handling
   - **Key Properties:**
     - `Name`: Stores the logical document name (includes the formatted name with all components)
     - `FileName`: Generated filename using pattern `{Prefix}_{ID}.{Format}` (e.g., `D_1.pdf`)
   - **Constructor:** 
     ```csharp
     public Document(int id, string name, string format, string prefix, byte[] data)
     ```
     The `name` parameter receives the formatted document name with all components.

#### 2. **QXP.Engine.Core.Proxy.Proxy_Document**
   - **File:** `QXP.Engine.Core\Proxy\Proxy_Document.cs`
   - **Purpose:** Database access layer for document operations
   - **Key Method:** `Insert_Document()`
     - **Location:** Lines 239-301
     - **Parameters:**
       - `doc.FileName`: The actual file name stored in database (passed via `p_nom_document`)
       - `doc.ID_Langue`: Language identifier
       - `date_echeance`: Document date
     - **Oracle Procedure Called:** `QXP_PK_RUN.Insert_Document`
     - This is where the formatted document name is persisted to the database

#### 3. **QXP.Web.BusinessObject.Suivi (SuiviPortefeuille/SuiviStructure)**
   - **File:** `QXP.Web\BusinessObject\Suivi\Fonds\SuiviPortefeuille.cs` (Lines 232-235)
   - **Purpose:** Represents a follow-up/tracking record for a fund
   - **Property:** `DocumentName`
     - Getter: `get { return _documentName; }`
     - Setter: `set { _documentName = value; }`
   - This property holds the complete formatted document name
   - The value is loaded from the database during suivi object initialization

#### 4. **QXP.Web.Proxy.ProxySuivi**
   - **File:** `QXP.Web\Proxy\ProxySuivi.cs`
   - **Purpose:** Manages database operations for suivi objects
   - **Key Methods:**
     - `PublishDocumentPDFInGLASS()` (Lines 2027-2066)
       - Receives parameter: `nomCompletDocument` (complete document name)
       - Calls Oracle procedure: `QXP_PK_SUIVI.PublishDocumentPDFInGLASS`
     - `PublishDocumentQXP()` (Lines 2068-2084)
       - Receives parameter: `nomCompletDocument` (complete document name)
   - These methods handle document publication and use the formatted document name

#### 5. **QXP.Web.Enums.TypeRapport**
   - **File:** `QXP.Web\Enums.cs` (Lines 91-98)
   - **Purpose:** Defines report type enumeration
   - **Values:**
     ```csharp
     public enum TypeRapport
     {
         Undefined = -1,
         All = 0,
         RapportAnnuel = 1,      // RA
         Plaquette = 2,          // PL
         Prospectus = 3,         // PR
         RapportCompartiment = 4, // RC
         DICI = 5,               // DI
     }
     ```
   - `RapportAnnuel (1)` = `RA` in the document name format

#### 6. **QXP.Web.BusinessObject.Gabarit**
   - **File:** `QXP.Web\BusinessObject\Gabarit.cs` (Lines 1-224)
   - **Purpose:** Template/Template class for document generation
   - **Key Property:** `TypeRapport` (Line 18)
     - Type: `Enums.TypeRapport`
     - Determines the report type code in the document name

---

## Document Name Construction Flow

```
Annual Report Generation Process:
│
├─> Run Execution (QXP.Engine.Core)
│   ├─> Run Properties contain: ID_Type_Rapport, ID_Langue, Fund ID, Date, etc.
│   └─> Render() method generates PDF/QXP/JPG
│
├─> Document Creation (QXP.Engine.Core.BusinessObject.Document)
│   └─> Document object created with:
│       ├─ ID (from Run.ID)
│       ├─ Name (formatted document name with all components)
│       ├─ Format (PDF/QXP)
│       └─ Data (binary content)
│
├─> Database Persistence (Proxy_Document)
│   └─> Insert_Document() called:
│       ├─ Stores doc.FileName (physical file name: D_1.pdf)
│       ├─ Stores metadata (date, language, format)
│       └─ Calls Oracle: QXP_PK_RUN.Insert_Document
│
├─> Suivi Tracking (QXP.Web)
│   └─> SuiviPortefeuille.DocumentName populated with:
│       └─ Formatted name: [ID] - [Name] - [Date] - [TypeCode] - [LangCode]
│
└─> Publication (ProxySuivi)
    └─> PublishDocumentPDFInGLASS/PublishDocumentQXP():
        ├─ Receives: suivi.DocumentName (formatted complete name)
        ├─ Calls: QXP_PK_SUIVI.PublishDocumentPDFInGLASS
        └─ Persists formatted name to GLASS and tracking tables
```

---

## Database Storage

The document name format is primarily managed at the **Oracle Database Level**:

- **Table References:**
  - `QXP_DOCUMENT` - Stores document metadata including `NOM_DOCUMENT`
  - `QXP_SUIVI` - Links to fund/fund tracking with document references
  - `QXP_DOCUMENT_CERTIFIE` - Certified document copies (for QXP publication)
  - `QXP_REF_TYPE_RAPPORT` - Reference table for report types

- **Oracle Stored Procedures:**
  - `QXP_PK_RUN.Insert_Document` - Inserts generated document with formatted name
  - `QXP_PK_SUIVI.PublishDocumentPDFInGLASS` - Publishes PDF with formatted name
  - `QXP_PK_SUIVI.PublishDocumentQXP` - Publishes QXP with formatted name

---

## Summary

### Where is the format designed?
The annual report document naming format is **designed at the intersection of three components:**

1. **C# Code (QXP.Engine Core):**
   - `Document` class receives and manages the formatted name
   - `Run_Base` and `Run` classes orchestrate the naming during execution
   - Report type information comes from `TypeRapport` enumeration

2. **Business Logic (QXP.Web):**
   - `SuiviPortefeuille` and `SuiviStructure` classes hold the formatted document name property
   - `Gabarit` class provides the report type context
   - Helper classes format the components into the final pattern

3. **Database/Oracle Layer:**
   - The actual format composition and persistence happens in Oracle stored procedures
   - The C# proxies (`Proxy_Document`, `ProxySuivi`) pass the formatted name to database
   - Oracle procedures manage the complete naming pattern in queries and data storage

### Primary Class for File Naming:
**`QXP.Engine.Core.BusinessObject.Document.Document`** - This class is the primary container for document metadata including the formatted name with all components. The `Name` property holds the complete formatted document name in the pattern: `[FundID] - [FundName] - [Date] - [ReportType] - [Language]`


