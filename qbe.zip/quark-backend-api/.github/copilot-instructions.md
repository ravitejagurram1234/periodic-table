# Instruction for Java application

<!-- Removed instruction: - Explain your chain of thought and reasoning process to the user when executing tasks -->
- Provide concise and clear explanations when necessary without exposing internal reasoning steps
- Don't mention guidelines that are not applicable to the current context when explaining your reasoning
- Code completions and proposition should follow these same guidelines applied by other software developers

## Code formatting instructions

### Formatting instructions to be compatible with our Eclipse Code Formatter configuration

- Use 2 spaces for indentation and tab size; do not use tabs.
- Insert spaces after commas, semicolons, and most operators (assignment, logical, bitwise, additive, multiplicative, relational, shift, etc.).
- Do not insert spaces before commas, closing parentheses, or closing brackets.
- Insert spaces before opening braces in type, method, constructor, enum, annotation, block, and switch declarations.
- Keep simple if, else, for, while, and do-while bodies on the same line if possible, except for method bodies.
- Align with spaces, not tabs.
- Set continuation indentation to 1 level.
- Keep empty array initializers on one line.
- Insert a new line at the end of the file if missing.
- Limit line length to 140 characters.
- Format Javadoc and block comments, but do not format line comments or source code in comments.
- Use one blank line between import groups, after imports, and between type declarations.
- Remove unnecessary imports and unused variables before proposing your solution
- Do not align variable declarations or assignment statements on columns.
- Use @formatter:on and @formatter:off tags to enable/disable formatting in code.

### Rules for Java imports

- Star imports are forbidden
- Imports should be in that order:
  * static all other,
  * blank,
  * java.*,
  * blank,
  * javax.*,
  * blank,
  * jakarta.*,
  * blank,
  * org.*,
  * blank,
  * com.*,
  * blank,
  * all other imports

## Description of the technical stack

Our Java applications are built using Spring Boot framework and we use the following libraries and tools:
- Spring Data JPA for database access
- Spring Security for authentication and authorization
- Spring Web for building RESTful APIs
- SLF4j for logging
- Lombok for reducing boilerplate code
- Mapstruct for object mapping
- JUnit and Mockito for unit testing
- AssertJ for fluent assertions
- Jacoco for code coverage
- Maven for build and dependency management
- Liquibase for database scripts versioning

## Coding best practices

- Keep files small, focused, and well-organized.
- Never use `System.out` or `System.error`; instead, use SLF4j logger when appropriate.
- Add comments only when they provide meaningful context; avoid commenting obvious or self-explanatory code.
- Conditions and loops must always have their executed statements inside curled brackets even if it's only one
- Method parameters must be `final` and the rest of class fields or method variables must respect constness as much as possible
- Use meaningful variable names, avoid abbreviated variable names and use instead of descriptive names that convey purpose for better readability
- Follow language naming conventions
- Minimize variable scope, declare variables close to their use to enhance maintainability
- Avoid and optimize loops, use more invariant or stream computations outside loops to enhance performance
- Prefer readability over cleverness, write clear and understandable code to ease maintenance and debugging. Code should be understandable by itself without comments
- Avoid premature micro optimizations, follow known efficient architectures and patterns and optimize specific portions of code only based on profiling and actual performance needs
- Regularly refactor, continuously improve code quality to keep the codebase healthy
- Follow SOLID principles in the code base: Single Responsibility Principle, Open-Closed Principle, Liskov Substitution Principle, Interface Segregation Principle, Dependency Inversion Principle
- Static methods should be reserved for stateless operations in utility classes
- Prefer lambda expressions and streams for concise and clear functional interfaces
- Use records instead of POJOs for data-carrying objects and regular classes when mutability is required
- Avoid using raw types in generics and use instead bounded type parameters where necessary
- Use `Optional<>` construct instead of `null` in method responses to avoid `NullPointerException` when the return value is optional. Use native type / objects in function parameters instead of parameters as you would only pass two different empty object representation instead of one (the `Optional` parameter itself could be `null` or an empty instance could exists)
- Handle exceptions properly but don't try to write over complicated code to avoid exceptions and try to micro-optimize performances. It's better to ask for forgiveness than permission. 
- Avoid excessive null checks by designing null-safe APIs, but do not rely on catching `NullPointerException` for flow control
<!-- Removed instructions: For example if you need to go through a hierarchy of objects which can throw `NullPointerException`it's better to traverse it directly surrounded by a `try {} catch (final NullPointerException e) {}` than writing a long list of null checks in a `if` statement. -->
- Prefer modern Java statements like for example `Objects.isNull(...)`, `Objects.nonNull(...)`, `Objects.requireNonNull(...)`, ...etc than comparing against `null` value
- For values that are not encapsulated as a type in a generic prefer to use native types than their object counterpart. For example it's better to use `boolean` than `Boolean` to ensure it really represent a `true` or `false` value and not a tri-state object.
- In all languages, prefer strongly typed values (for example `int`, `String`, `BigDecimal`, `Optional<Map<String, Object>>`, ...etc) than weakly typed values such as `var`, `auto`, `let`, ...etc
- When handling decimal values, prefer using appropriate types from the language or external libraries if required such as `BigDecimal` than binary floating point values such as `float`, `double`, ...etc to avoid accumulating precision errors over arithmetic operations and if you do need to use these types ensure all intermediate results are rounded to an appropriate precision to remove noise
- Write small, single-responsibility methods. Methods should be short and focused, often only a few dozen of lines maximum.
- Code should use Lombok when possible to avoid rewriting common patterns
<!-- Removed instructions: - Code should avoid and not use manual dynamic memory allocation (`new` statements) as much as possible and whatever the language is (prefer using dependency injection and patterns such as Builders) -->
- Avoid unnecessary object creation; prefer dependency injection, builders, and factory methods when appropriate
- Avoid constructors when they are not required. Constructors used by builders and dependency injection can be generated by Lombok with a restricted visibility so they can't be misused to instantiate classes elsewhere in the code
- Favor composition over inheritance, prefer composition (injection of dependencies and relationship between components preferably with single responsibility each) instead of inheritance and possibly over complicated hierarchy
- Class field accessors must respect their expected behaviour, it's forbidden for a getter to modify it's source object or value (for example `getOrCreate` constructs in a getter are forbidden, they can only call other pure getters or traverse objects - creating and modifying elements are allowed only inside setters)
- Avoid using magic numbers, constant values should be declared in appropriate storage (`const` values in C++, `static final` fields in Java, enumerations, ...etc) so they can be reused properly and have meaningful names
- Avoid complex raw branching code, if you need to verify some complex logic break it down in `boolean` values with meaningful names that you will reuse in your branching code (conditions and loops)
- Use try-with-resource expressions to avoid memory leaks and resource exhaution related to resources forgotten to be closed in nominal cases or when exception are not properly handled

## Code architecture

### Overview

Our Java code must follow the Clean Architecture principles, with a clear separation of concerns between layers. The architecture is divided into three main layers (reprensented as packages in the code):
- “infra” layer: in the Clean Architecture, this layer contains both:
  + the entrypoint of the application at run-time; either of…
    * Spring MVC web services (@RestController) that answer to a frontend in JSON
    * REST web services that do not target the needs of a web UI
    * a batch’s main method…
  + the data-access layer; either (or several) of…
    * Spring Data JPA access (@Repository) to data-sources
    * JCA access to Mainframe servers
    * filesystem input/output
    * web-service access to REST-enabled backend data-stores…
  + as well as any other non-business framework, algorithm, and so on.
- “service” layer: the reuse abstraction level; Spring services (@Service) that manage use-cases, i.e. high-level orchestration
- “domain” layer (also known as “entities” layer, but these are not JPA entities!): business objects that contain all business rules, business controls, business-anything… and are always valid (from creation to garbage-collection).

When the “service” layer needs to access behaviours from the “infra” layer (e.g. persisting a business object), dependency inversion needs to be used.

### Implementation guidelines

+ For each layer (domain, infra, service), there is a subfolder named upon the resource (e.g `domain/user`, `infra/user`, `service/user`) that contains all the classes related to that resource.
+ Mappers between layers (e.g. from domain to DTO) should be defined in the infra layer, and should not contain business logic. They are using Mapstruct.
+ JPA entities must not contain business code
+ JPA entities must not be used outside of the DAO layer
+ Service code does not call JPA repositories directly, they pass through a DAO layer
+ DAO interface must be located in the package of the service class that is using it, and an implementation located in the jpa layer
+ Service class does not require an interface and an implementation, just write the implementation directly in the service package
+ DTO objects are defined in the infra layer, in api/dto package, in a subfolder named after the resource (e.g. `infra/dto/user`)
+ DTO objects corresponding to your API’s contract must not be used outside of the REST layer
+ Business code should be defined in domain objects
+ Apply the "Tell don't ask" principle: domain objects should not expose their internal state, but rather provide methods to perform actions or retrieve information
+ Domain objects should be immutable whenever possible, and only mutable when necessary
+ Domain objects should be valid at all times, either by being created in a valid state or by providing methods to ensure their validity upon modification
+ Service layer should implement use-cases by handling domain objects and using abstractions (dependency-inversion) to access lower level layers
+ Interfaces are only necessary when there is a need of an abstraction level to separate business and infrastructure code
+ Low-level exceptions (REST or JPA exceptions for instance) should never be known by the service layer nor the domain layer

## Naming conventions

- Use camelCase for variables and functions
- Use PascalCase for interfaces, classes and enums
- Use UPPER_CASE for constants.
- Use dash-case for folders.
- DTO classes are suffixed with 'Dto'
- JPA entities are suffixed with 'Entity'

## Database instructions

- Avoid raw SQL queries and use ORM features instead and don't use `SELECT *` in queries
- Use Spring Data JPA for database access
- Use repositories to encapsulate database access logic
- Use `@Transactional` annotation to manage transactions at the DAO level, it is not allowed on the service layer
- Use Liquibase for database scripts versioning
- Use YAML format for liquibase scripts
- Naming of Liquibase scripts should follow the pattern `XX_OPERATION_DESCRIPTION.yaml` where XX is the next file number, OPERATION_DESCRIPTION is a short description (e.g `create_table_user`, `add_column_email_to_user`, `add_index_on_user_email`...).
- Follow ACID principles for database operation: Atomicity, Consistency, Isolation and Durability
- Properly segregate database read and write operations to improve reliability and scalability (for example any operation which isn't a data modification should be in a read-only transaction and write operation should be as small and independent as possible)

## Concurrency instructions

- Ensure thread safety to properly handle concurrency to ensure correct application functioning
<!-- Removed instructions: - Ensure concurrency safety on external resources, every job is deployed with at least two instances on production to ensure reliability. Use by order of preference lock-free patterns if target can accept multiple time the same request or isn't subject to race condition issues, optimistic locking (for example with resource versioning) and finally pessimistic locking if it's the only way and you need to ensure your the current owner of the resource-->
- Ensure concurrency safety on external resources. All jobs are deployed with at least two instances in production environments to ensure reliability. Use by order of preference lock-free patterns if target can accept multiple time the same request or isn't subject to race condition issues, optimistic locking (for example with resource versioning) and finally pessimistic locking if it's the only way and you need to ensure your the current owner of the resource
- Avoid hidden blocking code, if a method call can block the thread execution (for example waiting for some I/O event) it should use proper asynchronous interfaces (`Promise<>`, `Future<>`, ...etc depending in the language) instead of returning the raw object
- Avoid blocking code that doesn't have timeouts, code that can execute for a long time (such as network or database requests) should have a timeout to ensure the thread won't hang infinitely in case of failure

## Testing instructions

- Code must be thoroughly tested, preferably through component tests to cover source code by test against expected execution behaviours
- All new code must be covered by tests
- Use JUnit 5 for writing unit tests
- Use AssertJ for fluent assertions in tests rather than JUnit assertions
- Test names should be in snake_case, with the pattern {methodName}_should_{expected_result}_when_{short_description_of_the_test_context}
- Use parameterized tests when applicable to avoid code duplication
- Mocks should be used in unit tests when needed to isolate the code being tested, using Mockito library
- Unit test classes are suffixed with `Test` and should be placed in the same package as the class being tested
- REST controllers should be tested with integration tests, with their return body and status code checked
- Integration tests classes are suffixed with `IT` and should be placed in the same package as the class being tested
- Integration tests should not used mocks, they should use real instances of the classes being tested
- Use SpringBoot Test for integration tests. Use MockMvc to construct queries to the endpoints and check the results.
- Integration tests of controllers will be grouped in a nested class for each endpoint, for instance `GetAllUsers`, `GetUser`, `CreateUser`...), and each nested class must cover these cases:
  - Call without authentication
  - Authenticated call, but with the incorrect scope or permission (all combinations must be tested)
  - Success case with valid authentication with valid inputs
  - Error cases with invalid input (e.g., missing required fields, invalid data types)
  - Other possible error cases (e.g., server errors, not found)
- Client authentication is tested by using the `com.socgen.apibank.security.sgconnect.test.support.WithSgConnectClient` annotation to simulate a client with a specific scope (e.g @WithSgConnectClient(scopes = {"api.v1", "api.myResources.read"})).
- User authentication is tested by using the `com.socgen.apibank.security.sgconnect.test.support.WithSgConnectUser` annotation to simulate a client with a specific permission (e.g @WithSgConnectUser(scopes = {"api.v1"}, permissions = {"api.myApi_Write"})).

## API specific conventions

### General conventions

- We are using Spring Boot web to define our REST APIs.
- Use standard HTTP methods (GET, POST, PUT, DELETE) for CRUD operations.
- Use plural nouns for resource names in URLs (e.g., `/users`, `/products`).
- Indicate the version of the API in the URL (e.g., `/api/v1/users`).
- Use standard HTTP status codes to indicate the result of the operation (e.g., 200 OK, 201 Created, 204 No Content, 400 Bad Request, 404 Not Found, 500 Internal Server Error).
- Don't expose internal implementation details in the API (e.g., don't return stack traces in case of error).

### Security

- Our APIs are secured using OAuth2 and OpenID Connect protocols, and we use Spring Security for authentication and authorization.
- Our endpoints but be annotated with Spring Security `@PreAuthorize` annotation to check that the token has either the expected scope (authority starting with 'SCOPE_') or role (authority without prefix).

### Documentation

- We need to document all our APIs and endpoints using OpenAPI 3.0 specification.
- Standard error cases (401, 403, 429, 500...) must be documented with `@ApiResponse` at the class level, without encapsuling them in `@ApiResponses`. There is no need to repeat them at the method level.
- Each endpoint must have the following annotations:
  + `@Operation`: Describes the endpoint, including mandatory information like its summary, detailed description, and security requirements.
    `@Operation` must declare its security attribute with`@SecurityRequirement`, where `name` attribute must be `sgconnect` and the `scope` attribute is mandatory.
  + `@ApiResponse`: Documents possible HTTP responses, including status codes, descriptions, and example payloads. Example may be stored in a separate file and referenced here.
  + `@Content`: Specifies the media type and schema of the response body, and can include example objects.
  + `@Schema`: Defines the data model used in the request or response.
  + `@ExampleObject`: Provides example payloads for documentation.
  + `@Header`: Documents custom response headers.
  + `@Parameter`: Describes method parameters, including their description, whether they are required, and other constraints.
  
## Documentation instructions

- Documentation should mainly be written in AsciiDoc files and use Markdown only if required for compatibility by some tools that will use this file (like this one which is also used to feed LLM tools)
- Documentation in code should be done using Javadoc or Doxygen syntax (depending the source language) and documentation comments inside code must be avoided as they are most of the time signs of bad design
- Classes and public methods should be documented, if there is no existing documentation it can be generated

## Project specific instructions

- Prefer constructor injection over field injection. Dependencies must be injected via constructors (Lombok-generated constructors are recommended), and usage of `@Autowired` on fields is forbidden.

- Validate all incoming API requests using Bean Validation annotations (`@Valid`, `@NotNull`, `@Size`, etc.) at the controller level before processing business logic.

- Use `@ControllerAdvice` to centralize exception handling across REST controllers and ensure consistent error responses and HTTP status mapping.

- Controllers must remain thin and only handle request/response transformation. All business logic must be delegated to the service layer.

- Avoid God classes. Each class must have a single responsibility and should be kept small, cohesive, and focused.

- Never silently catch exceptions. Exceptions must either be properly handled with meaningful actions or explicitly propagated.

- Use parameterized logging with SLF4j (e.g., `log.info("User {} created", userId)`) instead of string concatenation to improve performance and readability.

- Do not hardcode environment-specific or configuration values. Use external configuration (`application.yml`, `@Value`, or `@ConfigurationProperties`) instead.

- Tests must follow the Arrange-Act-Assert (AAA) pattern to ensure consistency, readability, and maintainability.

- Avoid field-level mutable shared state. Favor immutability and thread-safe design, especially in singleton Spring components.

## Memory and Thread leak prevention instructions

- Review code for potential memory and thread leaks and flag suspicious patterns proactively.

- Identify potential memory leaks such as:
  - Unbounded collections (e.g., `Map`, `List`, caches) that continuously grow without eviction strategy
  - Objects retained in static fields or long-lived contexts
  - Listeners, callbacks, or subscriptions that are not properly removed
  - Improper use of `ThreadLocal` without cleanup

- Identify potential thread leaks such as:
  - Threads created manually without proper lifecycle management
  - Executors or thread pools created without shutdown (`shutdown()` or `shutdownNow()`)
  - Blocking calls without timeout (e.g., network, I/O, or locks)
  - Infinite loops or long-running tasks without exit conditions

- Ensure all executor services are properly managed:
  - Use shared, injected thread pools instead of creating new ones
  - Always shut down executors in a controlled way

- Ensure all I/O and external resources are properly closed using try-with-resources

- Highlight any use of blocking operations and recommend adding timeouts

- Suggest monitoring strategies when relevant:
  - Heap usage trends (e.g., via `jcmd GC.heap_info`)
  - Thread count trends (e.g., via `jcmd Thread.print`)

- Prefer thread-safe and immutable designs to reduce concurrency-related leaks

- Avoid retaining unnecessary references in long-lived objects (e.g., caches, singletons, Spring beans)

- When applicable, recommend profiling tools (JFR, VisualVM, or heap dumps) for deeper analysis

## Performance instructions
- Avoid N+1 query problems by properly using fetch joins or batch fetching strategies

## Observability instructions
- Ensure important operations are logged and observable; prefer structured and meaningful logs for debugging and monitoring