# NAVAPP-<JIRA_ID> - <Short Description>

---

## ✅ Definition of Done

- [ ] Sonar review passed (no bugs, no security issues, no major/critical code smells)
- [ ] Clean Architecture is respected (Infra <= Service <= Domain)
- [ ] Build passes successfully (CI/CD pipeline green)
- [ ] Commit title follows convention (NAVAPP-XXXX)

---

## 🧪 Testing

- [ ] Unit tests implemented for all business logic
- [ ] Integration tests implemented for each feature
- [ ] Test coverage ≥ 80% (validated via JaCoCo)
- [ ] Critical business paths are fully covered

---

## ⚡ Performance & Stability

- [ ] No N+1 query issues (verified via logs or query inspection)
- [ ] No unnecessary loops or inefficient computations
- [ ] No potential memory or thread leaks (executors, streams, listeners properly managed)

---

## 🔐 Security

- [ ] Endpoints secured with `@PreAuthorize` and correct scopes/roles
- [ ] No sensitive data exposed (logs, responses, exceptions)
- [ ] Input validation implemented to mitigate OWASP Top 10 risks

---

## 📦 API & Contract

- [ ] API endpoints verified via Swagger/OpenAPI
- [ ] Contract matches implementation (request/response, status codes)
- [ ] Breaking changes are versioned or backward compatibility is ensured
- [ ] SG API rules reviewed using Swagger UI (local) or [SG Swagger Check](https://developer.sgmarkets.com/workspace/apis/swagger)

---

## 📊 Observability & Logging

- [ ] Logs are meaningful, structured, and useful for debugging
- [ ] Key operations are traceable

---

## ⚙️ Configuration

- [ ] No hardcoded environment-specific values
- [ ] Configuration externalized (`application.yml`, environment variables)

---

## 🔄 Error Handling

- [ ] Exceptions handled properly (no silent failures)
- [ ] Errors consistently mapped (e.g., via `@ControllerAdvice`)

---

## 📝 Traceability & Documentation

- [ ] Jira ticket is properly linked and updated
- [ ] Impact of changes clearly documented (e.g., new endpoint, behavior change, schema update)
- [ ] API changes or contract updates are described

---

## ⚙️ Platform & Compliance

- [ ] Platform-specific guidelines respected (ConfigMap, Secrets, IAM, SG Connect where applicable)

---

## 🤖 Automated Review

- [ ] Code reviewed using Copilot review agent (`/review-code`)
- [ ] All critical and major issues identified by the agent are resolved or justified

> Example usage:
> - `/review-code`
> - Or: “Review this code using the review-code agent”

### Review Summary
- Issues found:
- Fixes applied:
- Known deviations (if any):

---

## ✅ Review & Quality Gate

- [ ] All review comments addressed
- [ ] All review threads resolved

---

> ⚠️ PR must not be approved unless all checklist items are completed and validated.