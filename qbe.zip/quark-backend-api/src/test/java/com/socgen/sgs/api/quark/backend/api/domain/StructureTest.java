package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class StructureTest {

    @Test
    public void testNoArgsConstructor() {
        Structure structure = new Structure();
        assertNotNull(structure);
        assertNull(structure.getIdStructure());
        assertNull(structure.getNom());
    }

    @Test
    public void testAllArgsConstructor() {
        Structure structure = new Structure("STR001", "Structure Name", "Long Label",
                "SICAV", "Classification A", "MgtCompany", "Accountant",
                "CAC_FIRM", "EUR");

        assertEquals("STR001", structure.getIdStructure());
        assertEquals("Structure Name", structure.getNom());
        assertEquals("Long Label", structure.getLibelleLong());
        assertEquals("SICAV", structure.getFndLegalType());
        assertEquals("Classification A", structure.getFndClassification());
        assertEquals("MgtCompany", structure.getFndMngtCompany());
        assertEquals("Accountant", structure.getFndAccountant());
        assertEquals("CAC_FIRM", structure.getCac());
        assertEquals("EUR", structure.getDevise());
    }

    @Test
    public void testGettersAndSetters() {
        Structure structure = new Structure();

        structure.setIdStructure("STR002");
        assertEquals("STR002", structure.getIdStructure());

        structure.setNom("Name");
        assertEquals("Name", structure.getNom());

        structure.setLibelleLong("Long Name");
        assertEquals("Long Name", structure.getLibelleLong());

        structure.setFndLegalType("FCP");
        assertEquals("FCP", structure.getFndLegalType());

        structure.setFndClassification("Actions");
        assertEquals("Actions", structure.getFndClassification());

        structure.setFndMngtCompany("MGT Co");
        assertEquals("MGT Co", structure.getFndMngtCompany());

        structure.setFndAccountant("Accountant Co");
        assertEquals("Accountant Co", structure.getFndAccountant());

        structure.setCac("CAC Co");
        assertEquals("CAC Co", structure.getCac());

        structure.setDevise("USD");
        assertEquals("USD", structure.getDevise());
    }
}

