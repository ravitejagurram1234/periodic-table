package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.StructureService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class StructureBusinessTest {
    @InjectMocks
    private StructureBusiness structureBusiness;

    @Mock
    private StructureDao structureDao;

    @Test
    public void testGetListeStructuresForNewSuivi_returnsStructureList() {
        List<Structure> mockList = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    Structure structure = new Structure();
                    structure.setIdStructure(String.valueOf(i));
                    return structure;
                }).toList();

        when(structureDao.getListeStructuresForNewSuivi(2L, 1L, 160L, LocalDate.parse("2023-10-01"))).thenReturn(mockList);

        List<Structure> result = structureBusiness.getListeStructuresForNewSuivi(2L, 1L, 160L, LocalDate.parse("2023-10-01"));

        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");

        verify(structureDao, times(1)).getListeStructuresForNewSuivi(2L, 1L, 160L, LocalDate.parse("2023-10-01"));
    }
}
