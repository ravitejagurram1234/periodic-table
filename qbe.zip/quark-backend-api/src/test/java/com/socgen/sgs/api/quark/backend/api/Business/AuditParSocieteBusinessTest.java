package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditParSocieteDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuditParSocieteBusinessTest {

    @Mock
    private AuditParSocieteDao auditParSocieteDao;

    @InjectMocks
    private AuditParSocieteBusiness business;

    @Test
    void delegatesInsertAuditToDao() {
        Audit audit = new Audit();
        when(auditParSocieteDao.insertAudit(audit)).thenReturn(3);

        Integer result = business.insertAudit(audit);

        assertEquals(3, result);
        verify(auditParSocieteDao).insertAudit(audit);
    }
}

