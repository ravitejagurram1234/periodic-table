package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationPortefeuilleDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.ModificationPortefeuilleService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class ModificationPortefeuilleBusinessTest {
    @Mock
    private ModificationPortefeuilleDao modificationPortefeuilleDao;

    @InjectMocks
    private ModificationPortefeuilleBusiness modificationPortefeuilleBusiness;

    @Test
    void getListPortefeuille_returnsListOfPortefeuille() {
        List<portefeuille> mockList = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    portefeuille p=new portefeuille();
                    p.setDescription("Document" + i);
                    return p;
                }).toList();

        when(modificationPortefeuilleDao.getListPortefeuille(8)).thenReturn(mockList);

        List<portefeuille> result = modificationPortefeuilleBusiness.getListPortefeuille(8);

        assertNotNull(result,"Result should not be null");
        assertEquals(5, result.size());
        verify(modificationPortefeuilleDao,times(1)).getListPortefeuille(8);
    }
}
