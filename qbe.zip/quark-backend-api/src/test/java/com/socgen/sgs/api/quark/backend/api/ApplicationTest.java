package com.socgen.sgs.api.quark.backend.api;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ApplicationTest {

    @Test
    void application_classExists() {
        assertDoesNotThrow(() -> Class.forName(
                "com.socgen.sgs.api.quark.backend.api.Application"));
    }

    @Test
    void application_hasMainMethod() throws Exception {
        var method = Application.class.getMethod("main", String[].class);
        assertNotNull(method);
    }

    @Test
    void application_isAnnotatedWithSpringBootApplication() {
        var annotation = Application.class.getAnnotation(
                org.springframework.boot.autoconfigure.SpringBootApplication.class);
        assertNotNull(annotation);
    }
}

