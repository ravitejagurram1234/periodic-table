package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteTypesDocumentDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModificationParSocieteTypeDocumentBusinessTest {

    @Mock
    private ModificationParSocieteTypesDocumentDao modificationParSocieteTypesDocumentDao;

    @InjectMocks
    private ModificationParSocieteTypeDocumentBusiness business;

    @Test
    void getListeTypesDocumentsDispos_returnsList() {
        TypeDeDocument doc = new TypeDeDocument(10L, "DICI");
        when(modificationParSocieteTypesDocumentDao.getListeTypesDocumentsDispos("360AM"))
                .thenReturn(List.of(doc));

        List<TypeDeDocument> result = business.getListeTypesDocumentsDispos("360AM");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("DICI", result.get(0).getLIBELLE_SOUS_CATEGORIE());
        verify(modificationParSocieteTypesDocumentDao, times(1)).getListeTypesDocumentsDispos("360AM");
    }

    @Test
    void getListeTypesDocumentsDispos_returnsEmptyList() {
        when(modificationParSocieteTypesDocumentDao.getListeTypesDocumentsDispos("UNKNOWN"))
                .thenReturn(List.of());

        List<TypeDeDocument> result = business.getListeTypesDocumentsDispos("UNKNOWN");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}

