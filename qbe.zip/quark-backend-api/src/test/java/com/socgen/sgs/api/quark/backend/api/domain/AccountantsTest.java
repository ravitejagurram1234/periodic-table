package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

public class AccountantsTest {

    @Test
    public void testNoArgsConstructor() {
        Accountants accountants = new Accountants();
        assertNotNull(accountants);
        assertNull(accountants.getDes_table_value());
    }

    @Test
    public void testAllArgsConstructor() {
        Accountants accountants = new Accountants("Accountant A");
        assertEquals("Accountant A", accountants.getDes_table_value());
    }

    @Test
    public void testGetterAndSetter() {
        Accountants accountants = new Accountants();
        accountants.setDes_table_value("Accountant B");
        assertEquals("Accountant B", accountants.getDes_table_value());
    }

    @Test
    public void testBuilderPattern() {
        Accountants accountants = Accountants.builder()
                .des_table_value("Accountant C")
                .build();
        assertNotNull(accountants);
        assertEquals("Accountant C", accountants.getDes_table_value());
    }

    @Test
    public void testBuilderDefaultValues() {
        Accountants accountants = Accountants.builder().build();
        assertNotNull(accountants);
        assertNull(accountants.getDes_table_value());
    }
}

