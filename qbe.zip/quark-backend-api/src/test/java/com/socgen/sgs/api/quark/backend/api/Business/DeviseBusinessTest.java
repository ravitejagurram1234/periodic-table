package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Devise;
import com.socgen.sgs.api.quark.backend.api.infra.dao.DeviseDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DeviseBusinessTest {

    @InjectMocks
    private DeviseBusiness deviseBusiness;

    @Mock
    private DeviseDao deviseDao;

    @Test
    public void testGetListeDevises_returnsDeviseList() {
        Devise d1 = new Devise("EUR", "Euro");
        Devise d2 = new Devise("USD", "Dollar");
        when(deviseDao.getListeDevises()).thenReturn(List.of(d1, d2));

        List<Devise> result = deviseBusiness.getListeDevises();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("EUR", result.get(0).getId_devise());
        verify(deviseDao, times(1)).getListeDevises();
    }

    @Test
    public void testGetListeDevises_returnsEmptyList() {
        when(deviseDao.getListeDevises()).thenReturn(List.of());

        List<Devise> result = deviseBusiness.getListeDevises();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(deviseDao, times(1)).getListeDevises();
    }
}
