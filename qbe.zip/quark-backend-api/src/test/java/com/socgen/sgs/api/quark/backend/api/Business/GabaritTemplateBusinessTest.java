package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GabaritTemplateBusinessTest {

    @Mock
    private GabaritTemplateDao gabaritTemplateDao;

    @InjectMocks
    private GabaritTemplateBusiness business;

    @Test
    void getTemplates_returnsListFromDao() {
        GabaritTemplate t1 = new GabaritTemplate();
        GabaritTemplate t2 = new GabaritTemplate();
        List<GabaritTemplate> expected = List.of(t1, t2);

        when(gabaritTemplateDao.getTemplates()).thenReturn(expected);

        List<GabaritTemplate> result = business.getTemplates();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertSame(expected, result);
        verify(gabaritTemplateDao, times(1)).getTemplates();
    }

    @Test
    void getTemplates_returnsEmptyListWhenDaoReturnsEmpty() {
        when(gabaritTemplateDao.getTemplates()).thenReturn(List.of());

        List<GabaritTemplate> result = business.getTemplates();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(gabaritTemplateDao, times(1)).getTemplates();
    }
}

