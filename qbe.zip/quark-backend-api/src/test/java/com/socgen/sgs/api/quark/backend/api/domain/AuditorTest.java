package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

public class AuditorTest {

    @Test
    public void testNoArgsConstructor() {
        Auditor auditor = new Auditor();
        assertNotNull(auditor);
        assertNull(auditor.getDesTableValue());
    }

    @Test
    public void testAllArgsConstructor() {
        Auditor auditor = new Auditor("External Auditor");
        assertEquals("External Auditor", auditor.getDesTableValue());
    }

    @Test
    public void testGetterAndSetter() {
        Auditor auditor = new Auditor();
        auditor.setDesTableValue("Internal Auditor");
        assertEquals("Internal Auditor", auditor.getDesTableValue());
    }

    @Test
    public void testBuilderPattern() {
        Auditor auditor = Auditor.builder()
                .desTableValue("Audit Firm")
                .build();
        assertNotNull(auditor);
        assertEquals("Audit Firm", auditor.getDesTableValue());
    }

    @Test
    public void testBuilderReturnsBuilder() {
        Auditor.Builder builder = Auditor.builder();
        assertNotNull(builder);
        Auditor.Builder same = builder.desTableValue("test");
        assertNotNull(same);
    }

    @Test
    public void testBuilderDefaultValues() {
        Auditor auditor = Auditor.builder().build();
        assertNotNull(auditor);
        assertNull(auditor.getDesTableValue());
    }
}

