package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationTypeDeDocumentDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.ModificationTypeDeDocumentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class ModificationTypeDeDocumentBusinessTest {
    @Mock
    private ModificationTypeDeDocumentDao modificationTypeDeDocumentDao;

    @InjectMocks
    private ModificationTypeDeDocumentBusiness modificationTypeDeDocumentBusiness;

    @Test
    void getListTypeDocuments_returnsListOfTypeDeDocument_whenBusinessReturnsNonEmptyList() {
        List<TypeDeDocument> mockList = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    TypeDeDocument document = new TypeDeDocument();
                    document.setLIBELLE_SOUS_CATEGORIE("Document" + i);
                    return document;
                }).toList();

        when(modificationTypeDeDocumentDao.getListTypeDocuments()).thenReturn(mockList);

        List<TypeDeDocument> result =modificationTypeDeDocumentBusiness.getListTypeDocuments();

        assertNotNull(result,"Result should not be null");
        assertEquals(5, result.size());
        verify(modificationTypeDeDocumentDao,times(1)).getListTypeDocuments();
    }
}
