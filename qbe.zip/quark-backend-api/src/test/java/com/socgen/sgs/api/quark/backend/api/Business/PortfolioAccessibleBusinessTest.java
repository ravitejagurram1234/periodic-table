package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PortfolioAccessibleDao;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.GabaritRepository;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PortfolioAccessibleBusinessTest {

    @InjectMocks
    private PortfolioAccessibleBusiness business;

    @Mock
    private PortfolioAccessibleDao portfolioAccessibleDao;

    @Mock
    private GabaritRepository gabaritRepository;

    // ─── Validation guards ────────────────────────────────────────────────────

    @Test
    void throws_when_p_idTypeRapport_is_null() {
        assertThrows(IllegalArgumentException.class, () ->
                business.getAccessiblePortfolios(null, 10L, 1L, null, null, null));
    }

    @Test
    void throws_when_p_idLangue_is_null() {
        assertThrows(IllegalArgumentException.class, () ->
                business.getAccessiblePortfolios(1L, 10L, null, null, null, null));
    }

    @Test
    void throws_when_p_idGabarit_is_null() {
        assertThrows(IllegalArgumentException.class, () ->
                business.getAccessiblePortfolios(1L, null, 1L, null, null, null));
    }

    @Test
    void throws_when_gabarit_not_found() {
        when(gabaritRepository.findByGabaritId(99L)).thenReturn(null);
        assertThrows(IllegalArgumentException.class, () ->
                business.getAccessiblePortfolios(1L, 99L, 1L, null, null, null));
    }

    @Test
    void throws_when_gabarit_type_is_null() {
        QxpGabarit gabarit = new QxpGabarit();
        gabarit.setType(null);
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);
        assertThrows(IllegalArgumentException.class, () ->
                business.getAccessiblePortfolios(1L, 10L, 1L, null, null, null));
    }

    @Test
    void throws_for_unsupported_type_gabarit() {
        QxpGabarit gabarit = new QxpGabarit();
        gabarit.setType("99");
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);
        assertThrows(IllegalArgumentException.class, () ->
                business.getAccessiblePortfolios(1L, 10L, 1L, null, null, null));
    }

    // ─── RapportCompartiment (p_idTypeRapport == 4) ───────────────────────────

    @Test
    void returns_compartiments_when_p_idTypeRapport_is_4() {
        List<portefeuilleDTO> compartiments = List.of(new portefeuilleDTO("COMP1", "Compartiment 1"));
        when(portfolioAccessibleDao.getListeCompartNonDispos("AUD", "ACC", "FMC"))
                .thenReturn(compartiments);

        List<portefeuilleDTO> result = business.getAccessiblePortfolios(4L, 10L, 1L, "AUD", "ACC", "FMC");

        assertEquals(compartiments, result);
        verify(portfolioAccessibleDao).getListeCompartNonDispos("AUD", "ACC", "FMC");
        verifyNoInteractions(gabaritRepository);
    }

    @Test
    void rapport_compartiment_ignores_gabarit_type_resolution() {
        when(portfolioAccessibleDao.getListeCompartNonDispos(any(), any(), any()))
                .thenReturn(List.of());

        assertDoesNotThrow(() ->
                business.getAccessiblePortfolios(4L, 10L, 1L, null, null, null));
        verifyNoInteractions(gabaritRepository);
    }

    // ─── Fonds Simples (typeGabarit == 0) ────────────────────────────────────
    // NOTE: must use new ArrayList<>() — business calls .sort() which requires mutable list

    @Test
    void returns_fonds_when_typeGabarit_is_0() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("0");
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);

        List<portefeuilleDTO> fonds = new ArrayList<>(List.of(
                new portefeuilleDTO("FND001", "Fund 1"),
                new portefeuilleDTO("FND002", "Fund 2")
        ));
        when(portfolioAccessibleDao.getFondsSimples("AUD", "ACC", "FMC")).thenReturn(fonds);

        List<portefeuilleDTO> result = business.getAccessiblePortfolios(1L, 10L, 160L, "AUD", "ACC", "FMC");

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(portfolioAccessibleDao).getFondsSimples("AUD", "ACC", "FMC");
    }

    // ─── FondsPart (typeGabarit == 2) ────────────────────────────────────────

    @Test
    void returns_fonds_when_typeGabarit_is_2() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("2");
        when(gabaritRepository.findByGabaritId(5L)).thenReturn(gabarit);

        List<portefeuilleDTO> fonds = new ArrayList<>(List.of(
                new portefeuilleDTO("FND003", "Fund Part 3")
        ));
        when(portfolioAccessibleDao.getFondsSimples(null, null, null)).thenReturn(fonds);

        List<portefeuilleDTO> result = business.getAccessiblePortfolios(1L, 5L, 160L, null, null, null);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(portfolioAccessibleDao).getFondsSimples(null, null, null);
    }

    @Test
    void returns_empty_list_when_no_fonds() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("0");
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);
        // mutable empty list — sort() must not throw even on empty
        when(portfolioAccessibleDao.getFondsSimples(any(), any(), any())).thenReturn(new ArrayList<>());

        List<portefeuilleDTO> result = business.getAccessiblePortfolios(1L, 10L, 1L, null, null, null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // ─── Structures (typeGabarit == 1) ───────────────────────────────────────

    @Test
    void returns_structures_when_typeGabarit_is_1() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("1");
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);

        List<portefeuilleDTO> structures = List.of(new portefeuilleDTO("STR001", "Structure 1"));
        when(portfolioAccessibleDao.getListeStructures("AUD", "ACC", "FMC")).thenReturn(structures);

        List<portefeuilleDTO> result = business.getAccessiblePortfolios(1L, 10L, 160L, "AUD", "ACC", "FMC");

        assertEquals(structures, result);
        verify(portfolioAccessibleDao).getListeStructures("AUD", "ACC", "FMC");
    }

    @Test
    void returns_empty_structures_list() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("1");
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);
        when(portfolioAccessibleDao.getListeStructures(any(), any(), any())).thenReturn(List.of());

        List<portefeuilleDTO> result = business.getAccessiblePortfolios(1L, 10L, 1L, null, null, null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}
