package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class ModificationParFondsDocumentTest {

    @Test
    public void testNoArgsConstructor() {
        ModificationParFondsDocument doc = new ModificationParFondsDocument();
        assertNotNull(doc);
        assertEquals(0, doc.getId_document());
        assertNull(doc.getNom_document());
    }

    @Test
    public void testAllArgsConstructor() {
        LocalDate echeance = LocalDate.of(2024, 6, 1);
        LocalDate creation = LocalDate.of(2023, 1, 15);

        ModificationParFondsDocument doc = new ModificationParFondsDocument(
                1, 2, 3, "doc.pdf", "FND001", "UNIT001",
                1, echeance, creation, 1024L, "SOC", "PDF", 5);

        assertEquals(1, doc.getId_document());
        assertEquals(2, doc.getId_sous_categorie());
        assertEquals(3, doc.getId_langue());
        assertEquals("doc.pdf", doc.getNom_document());
        assertEquals("FND001", doc.getId_fnd_code());
        assertEquals("UNIT001", doc.getId_unit_code());
        assertEquals(1, doc.getIs_actif());
        assertEquals(echeance, doc.getDate_echeance());
        assertEquals(creation, doc.getDate_creation_sys());
        assertEquals(1024L, doc.getTaille_document());
        assertEquals("SOC", doc.getSociete());
        assertEquals("PDF", doc.getFormat());
        assertEquals(5, doc.getId_utilisateur());
    }

    @Test
    public void testGettersAndSetters() {
        ModificationParFondsDocument doc = new ModificationParFondsDocument();
        LocalDate date = LocalDate.now();

        doc.setId_document(10);
        assertEquals(10, doc.getId_document());

        doc.setId_sous_categorie(20);
        assertEquals(20, doc.getId_sous_categorie());

        doc.setId_langue(30);
        assertEquals(30, doc.getId_langue());

        doc.setNom_document("file.pdf");
        assertEquals("file.pdf", doc.getNom_document());

        doc.setId_fnd_code("FND");
        assertEquals("FND", doc.getId_fnd_code());

        doc.setId_unit_code("UNIT");
        assertEquals("UNIT", doc.getId_unit_code());

        doc.setIs_actif(1);
        assertEquals(1, doc.getIs_actif());

        doc.setDate_echeance(date);
        assertEquals(date, doc.getDate_echeance());

        doc.setDate_creation_sys(date);
        assertEquals(date, doc.getDate_creation_sys());

        doc.setTaille_document(2048L);
        assertEquals(2048L, doc.getTaille_document());

        doc.setSociete("SOC");
        assertEquals("SOC", doc.getSociete());

        doc.setFormat("DOCX");
        assertEquals("DOCX", doc.getFormat());

        doc.setId_utilisateur(7);
        assertEquals(7, doc.getId_utilisateur());
    }
}

