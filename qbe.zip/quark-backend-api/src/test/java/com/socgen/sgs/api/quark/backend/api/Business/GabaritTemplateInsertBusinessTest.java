package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateInsertDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GabaritTemplateInsertBusinessTest {

    @Mock
    private GabaritTemplateInsertDao gabaritTemplateInsertDao;

    @InjectMocks
    private GabaritTemplateInsertBusiness business;

    @Test
    void insertGabaritTemplate_returnsIdFromDao() {
        Chargement_gabarit gabarit = new Chargement_gabarit("nom_template", new byte[]{1, 2}, "commentaire");
        when(gabaritTemplateInsertDao.insertGabaritTemplate(gabarit)).thenReturn(42);

        Integer result = business.insertGabaritTemplate(gabarit);

        assertEquals(42, result);
        verify(gabaritTemplateInsertDao, times(1)).insertGabaritTemplate(gabarit);
    }

    @Test
    void insertGabaritTemplate_propagatesNullReturn() {
        Chargement_gabarit gabarit = new Chargement_gabarit();
        when(gabaritTemplateInsertDao.insertGabaritTemplate(any())).thenReturn(null);

        Integer result = business.insertGabaritTemplate(gabarit);

        assertNull(result);
        verify(gabaritTemplateInsertDao, times(1)).insertGabaritTemplate(any());
    }
}

