package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateParFondsDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UpdateParFondsBusinessTest {

    @Mock
    private UpdateParFondsDao updateParFondsDao;

    @InjectMocks
    private UpdateParFondsBusiness updateParFondsBusiness;

    @Test
    void updateDocument_delegatesToDao() {
        Document document = new Document();
        document.setP_id_fnd_code("FND001");
        document.setP_societe("SOC1");

        doNothing().when(updateParFondsDao).updateDocument(document);

        updateParFondsBusiness.updateDocument(document);

        verify(updateParFondsDao, times(1)).updateDocument(document);
    }

    @Test
    void updateDocument_withEmptyDocument_doesNotThrow() {
        Document document = new Document();

        doNothing().when(updateParFondsDao).updateDocument(document);

        updateParFondsBusiness.updateDocument(document);

        verify(updateParFondsDao).updateDocument(document);
    }
}

