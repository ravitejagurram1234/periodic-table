package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Langue;
import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;
import com.socgen.sgs.api.quark.backend.api.infra.dao.MaquettisteDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class MaquettisteBusinessTest {
    @InjectMocks
    private MaquettisteBusiness maquettisteBusiness;

    @Mock
    private MaquettisteDao maquettisteDao;

    @Test
    public void testGetMaquettistes_returnsMaquettisteList() {
        List<Maquettiste> mockList = java.util.stream.IntStream.rangeClosed(1, 154)
                .mapToObj(i -> Maquettiste.builder().id((long) i).trigramme("MAQ" + i).build())
                .toList();

        when(maquettisteDao.getMaquettiste()).thenReturn(mockList);
        List<Maquettiste> result = maquettisteBusiness.getMaquettiste();

        assertNotNull(result, "Result should not be null");
        assertEquals(154, result.size(), "Size should be 100");


        verify(maquettisteDao, times(1)).getMaquettiste();
    }
}

