package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Fonds;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FondsDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.FondsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class FondsBusinessTest {
    @InjectMocks
    private FondsBusiness fondsBusiness;

    @Mock
    private FondsDao fondsDao;

    @Test
    public void testGetListeFondsForNewSuivi_returnsFondsList() {
        List<Fonds> mockList = java.util.stream.IntStream.rangeClosed(1, 83)
                .mapToObj(i -> {
                    Fonds fonds = new Fonds();
                    fonds.setId_fnd_code(String.valueOf(i));
                    return fonds;
                }).toList();


        when(fondsDao.getListeFondsForNewSuivi(1L, 1L, 47L, LocalDate.parse("2023-10-01"))).thenReturn(mockList);

        List<Fonds> result = fondsBusiness.getListeFondsForNewSuivi(1L, 1L, 47L, LocalDate.parse("2023-10-01"));

        assertNotNull(result, "Result should not be null");
        assertEquals(83, result.size(), "Size should be 83");

        verify(fondsDao, times(1)).getListeFondsForNewSuivi(1L, 1L, 47L, LocalDate.parse("2023-10-01"));
    }
}
