package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.domain.PresentationStructure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureGabaritDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StructureGabaritBusinessTest {

    @Mock
    private StructureGabaritDao structureGabaritDao;

    @InjectMocks
    private StructureGabaritBusiness business;

    // ── getPresentationStructure ─────────────────────────────────────────────

    @Test
    void getPresentationStructure_returnsListFromDao() {
        List<PresentationStructure> expected = List.of(new PresentationStructure());
        when(structureGabaritDao.getPresentationStructure("STR01", 10L)).thenReturn(expected);

        List<PresentationStructure> result = business.getPresentationStructure("STR01", 10L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertSame(expected, result);
        verify(structureGabaritDao, times(1)).getPresentationStructure("STR01", 10L);
    }

    @Test
    void getPresentationStructure_throwsWhenIdStructureIsNull() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> business.getPresentationStructure(null, 10L));
        assertEquals("idStructure is required", ex.getMessage());
        verifyNoInteractions(structureGabaritDao);
    }

    @Test
    void getPresentationStructure_throwsWhenIdStructureIsBlank() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> business.getPresentationStructure("  ", 10L));
        assertEquals("idStructure is required", ex.getMessage());
    }

    @Test
    void getPresentationStructure_throwsWhenIdGabaritIsNull() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> business.getPresentationStructure("STR01", null));
        assertEquals("idGabarit is required", ex.getMessage());
        verifyNoInteractions(structureGabaritDao);
    }

    // ── getListeCompartsByStructGab ──────────────────────────────────────────

    @Test
    void getListeCompartsByStructGab_returnsListFromDao() {
        List<Compartiment> expected = List.of(new Compartiment());
        when(structureGabaritDao.getListeCompartsByStructGab("STR01", 10L)).thenReturn(expected);

        List<Compartiment> result = business.getListeCompartsByStructGab("STR01", 10L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertSame(expected, result);
        verify(structureGabaritDao, times(1)).getListeCompartsByStructGab("STR01", 10L);
    }

    @Test
    void getListeCompartsByStructGab_throwsWhenIdStructureIsNull() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> business.getListeCompartsByStructGab(null, 10L));
        assertEquals("idStructure is required", ex.getMessage());
    }

    @Test
    void getListeCompartsByStructGab_throwsWhenIdGabaritIsNull() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> business.getListeCompartsByStructGab("STR01", null));
        assertEquals("idGabarit is required", ex.getMessage());
    }
}
