package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritsDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GabaritsBusinessTest {

    @Mock
    private GabaritsDao gabaritDao;

    @InjectMocks
    private GabaritsBusiness business;

    @Test
    void returnsGabaritsFromDao() {
        List<Gabarits> expected = List.of(new Gabarits());
        when(gabaritDao.getGabarits(1L, 2L, 1)).thenReturn(expected);

        List<Gabarits> result = business.getGabarits(1L, 2L, 1);

        assertEquals(1, result.size());
        assertSame(expected, result);
        verify(gabaritDao).getGabarits(1L, 2L, 1);
    }
}

