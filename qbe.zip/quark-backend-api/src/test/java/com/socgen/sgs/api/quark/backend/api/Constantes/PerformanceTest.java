package com.socgen.sgs.api.quark.backend.api.Constantes;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class PerformanceTest {

    @Test
    void testDefaultConstructorInitializesStart() {
        Performance performance = new Performance();
        assertNotNull(performance.getStart());
    }

    @Test
    void testAllArgsConstructorSetsStart() {
        LocalDateTime now = LocalDateTime.now();
        Performance performance = new Performance(now);
        assertEquals(now, performance.getStart());
    }

    @Test
    void testSetStart() {
        Performance performance = new Performance();
        LocalDateTime newStart = LocalDateTime.of(2024, 1, 1, 0, 0);
        performance.setStart(newStart);
        assertEquals(newStart, performance.getStart());
    }

    @Test
    void testGetSecondsAndMillisecondsReturnsNonNegative() {
        Performance performance = new Performance();
        BigDecimal result = performance.getSecondsAndMilliseconds();
        assertNotNull(result);
        assertTrue(result.compareTo(BigDecimal.ZERO) >= 0);
    }

    @Test
    void testGetSecondsAndMillisecondsAfterDelay() throws InterruptedException {
        Performance performance = new Performance();
        Thread.sleep(100);
        BigDecimal result = performance.getSecondsAndMilliseconds();
        // should be at least ~0.1 seconds
        assertTrue(result.compareTo(BigDecimal.ZERO) > 0);
    }

    @Test
    void testGetSecondsAndMillisecondsWithPastStart() {
        LocalDateTime pastStart = LocalDateTime.now().minusSeconds(2);
        Performance performance = new Performance(pastStart);
        BigDecimal result = performance.getSecondsAndMilliseconds();
        // should be roughly >= 2 seconds
        assertTrue(result.compareTo(BigDecimal.valueOf(1)) >= 0);
    }

    @Test
    void testMainMethodExecutesWithoutException() {
        // Covers Performance.main() and the private performSomeOperation() method
        assertDoesNotThrow(() -> Performance.main(new String[]{}));
    }
}


