package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

public class AuditTest {

    @Test
    public void testNoArgsConstructor() {
        Audit audit = new Audit();
        assertNotNull(audit);
        assertNull(audit.getP_ip());
        assertNull(audit.getP_startTime());
        assertNull(audit.getP_endTime());
    }

    @Test
    public void testAllArgsConstructor() {
        LocalDate start = LocalDate.of(2024, 1, 1);
        LocalDate end = LocalDate.of(2024, 12, 31);
        BigDecimal tempsReponse = BigDecimal.valueOf(123.45);

        Audit audit = new Audit("192.168.1.1", start, end, "/page", "user1",
                "module1", "fonction1", "message1",
                "param1", "param2", "param3", "param4", "param5",
                tempsReponse, 1, 42, "AppName");

        assertEquals("192.168.1.1", audit.getP_ip());
        assertEquals(start, audit.getP_startTime());
        assertEquals(end, audit.getP_endTime());
        assertEquals("/page", audit.getP_page());
        assertEquals("user1", audit.getP_login());
        assertEquals("module1", audit.getP_module());
        assertEquals("fonction1", audit.getP_fonction());
        assertEquals("message1", audit.getP_message());
        assertEquals("param1", audit.getP_param1());
        assertEquals("param2", audit.getP_param2());
        assertEquals("param3", audit.getP_param3());
        assertEquals("param4", audit.getP_param4());
        assertEquals("param5", audit.getP_param5());
        assertEquals(tempsReponse, audit.getP_temps_reponse());
        assertEquals(1, audit.getP_statut());
        assertEquals(42, audit.getP_id_application());
        assertEquals("AppName", audit.getP_nom_application());
    }

    @Test
    public void testGettersAndSetters() {
        Audit audit = new Audit();
        LocalDate now = LocalDate.now();

        audit.setP_ip("10.0.0.1");
        assertEquals("10.0.0.1", audit.getP_ip());

        audit.setP_startTime(now);
        assertEquals(now, audit.getP_startTime());

        audit.setP_endTime(now);
        assertEquals(now, audit.getP_endTime());

        audit.setP_page("/home");
        assertEquals("/home", audit.getP_page());

        audit.setP_login("admin");
        assertEquals("admin", audit.getP_login());

        audit.setP_module("MOD");
        assertEquals("MOD", audit.getP_module());

        audit.setP_fonction("doSomething");
        assertEquals("doSomething", audit.getP_fonction());

        audit.setP_message("OK");
        assertEquals("OK", audit.getP_message());

        audit.setP_param1("p1");
        assertEquals("p1", audit.getP_param1());

        audit.setP_param2("p2");
        assertEquals("p2", audit.getP_param2());

        audit.setP_param3("p3");
        assertEquals("p3", audit.getP_param3());

        audit.setP_param4("p4");
        assertEquals("p4", audit.getP_param4());

        audit.setP_param5("p5");
        assertEquals("p5", audit.getP_param5());

        audit.setP_temps_reponse(BigDecimal.ONE);
        assertEquals(BigDecimal.ONE, audit.getP_temps_reponse());

        audit.setP_statut(2);
        assertEquals(2, audit.getP_statut());

        audit.setP_id_application(99);
        assertEquals(99, audit.getP_id_application());

        audit.setP_nom_application("MyApp");
        assertEquals("MyApp", audit.getP_nom_application());
    }
}

