package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TypeDeDocumentTest {

    @Test
    public void testNoArgsConstructor() {
        TypeDeDocument typeDoc = new TypeDeDocument();
        assertNotNull(typeDoc);
        assertNull(typeDoc.getID_SOUS_CATEGORIE());
        assertNull(typeDoc.getLIBELLE_SOUS_CATEGORIE());
    }

    @Test
    public void testAllArgsConstructor() {
        TypeDeDocument typeDoc = new TypeDeDocument(10L, "Prospectus");
        assertEquals(10L, typeDoc.getID_SOUS_CATEGORIE());
        assertEquals("Prospectus", typeDoc.getLIBELLE_SOUS_CATEGORIE());
    }

    @Test
    public void testGettersAndSetters() {
        TypeDeDocument typeDoc = new TypeDeDocument();

        typeDoc.setID_SOUS_CATEGORIE(5L);
        assertEquals(5L, typeDoc.getID_SOUS_CATEGORIE());

        typeDoc.setLIBELLE_SOUS_CATEGORIE("Rapport Annuel");
        assertEquals("Rapport Annuel", typeDoc.getLIBELLE_SOUS_CATEGORIE());
    }
}

