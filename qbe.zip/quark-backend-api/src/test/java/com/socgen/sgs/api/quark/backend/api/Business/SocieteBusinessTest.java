package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Societe;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SocieteDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.SocieteService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class SocieteBusinessTest {
    @Mock
    private SocieteDao societeDao;

    @InjectMocks
    private SocieteBusiness business;

    @Test
    public void getSocieteReturnsEmptyListWhenBusinessReturnsEmptyList() {
        List<Societe> mockList = java.util.stream.IntStream.rangeClosed(1, 8)
                .mapToObj(i -> {
                    Societe event = new Societe();
                    event.setFND_MNGT_COMPANY("EVENT" + i);
                    return event;
                }).toList();

        when(societeDao.getSociete()).thenReturn(mockList);

        List<Societe> result = business.getSociete();

        assertNotNull(result, "Result should not be null");
        assertEquals(8, result.size(), "Size should be 180");
        verify(societeDao, times(1)).getSociete();
    }
}
