package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FundMgtCompanyDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.FundMgtCompanyService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class FundMgtCompanyBusinessTest {
    @InjectMocks
    private FundMgtCompanyBusiness fundMgtCompanyBusiness;
    @Mock
    private FundMgtCompanyDao fundMgtCompanyDao;


    @Test
    public void testGetFundMgtCompany_ReturnsList() throws Exception {
        List<FundMgtCompany> mockList = java.util.stream.IntStream.rangeClosed(1, 1755).
                mapToObj(i -> FundMgtCompany.builder().idMgtCode(String.valueOf(i)).build()).toList();

        when(fundMgtCompanyDao.getListFundMgtCompanies()).thenReturn(mockList);
        List<FundMgtCompany> result = fundMgtCompanyBusiness.getFundMgtCompany();

        assertNotNull(result, "Result should not be null");
        assertEquals(1755, result.size(), "size should be 1755");

        verify(fundMgtCompanyDao, times(1)).getListFundMgtCompanies();
    }
}
