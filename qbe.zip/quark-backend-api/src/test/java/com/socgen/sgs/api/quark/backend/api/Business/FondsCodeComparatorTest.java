package com.socgen.sgs.api.quark.backend.api.Business;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FondsCodeComparatorTest {

    private final FondsCodeComparator comparator = FondsCodeComparator.INSTANCE;

    // ─── Group ordering ───────────────────────────────────────────────────────

    @Test
    void underscore_comes_before_numeric() {
        assertTrue(comparator.compare("_ABC", "100XYZ") < 0);
    }

    @Test
    void underscore_comes_before_alphabetic() {
        assertTrue(comparator.compare("_ABC", "ALPHA") < 0);
    }

    @Test
    void numeric_comes_before_alphabetic() {
        assertTrue(comparator.compare("2ABC", "ALPHA") < 0);
    }

    @Test
    void alphabetic_comes_after_numeric() {
        assertTrue(comparator.compare("ALPHA", "2ABC") > 0);
    }

    // ─── Underscore group tie-break (case-insensitive alpha) ──────────────────

    @Test
    void underscore_group_sorted_alphabetically() {
        List<String> codes = Arrays.asList("_Z", "_A", "_C", "_B");
        codes.sort(comparator);
        assertEquals(List.of("_A", "_B", "_C", "_Z"), codes);
    }

    @Test
    void underscore_C_comes_before_underscore_Z() {
        assertTrue(comparator.compare("_C", "_Z") < 0);
    }

    // ─── Numeric group tie-break (numeric sort, not lexicographic) ───────────

    @Test
    void numeric_group_sorted_by_leading_number() {
        List<String> codes = Arrays.asList("100ABC", "2XYZ", "20DEF");
        codes.sort(comparator);
        assertEquals(List.of("2XYZ", "20DEF", "100ABC"), codes);
    }

    @Test
    void numeric_group_same_number_falls_back_to_string_compare() {
        // same leading number "10" → compare full string
        assertTrue(comparator.compare("10ABC", "10XYZ") < 0);
    }

    // ─── Alphabetic group tie-break ───────────────────────────────────────────

    @Test
    void alphabetic_group_sorted_case_insensitively() {
        List<String> codes = Arrays.asList("ZFUND", "aFUND", "MFUND");
        codes.sort(comparator);
        assertEquals(List.of("aFUND", "MFUND", "ZFUND"), codes);
    }

    // ─── Full mixed sort ──────────────────────────────────────────────────────

    @Test
    void full_mixed_sort_order() {
        List<String> codes = Arrays.asList("ZFUND", "100XYZ", "_C", "2ABC", "ALPHA", "_A", "20DEF");
        codes.sort(comparator);
        assertEquals(List.of("_A", "_C", "2ABC", "20DEF", "100XYZ", "ALPHA", "ZFUND"), codes);
    }

    // ─── Edge cases ───────────────────────────────────────────────────────────

    @Test
    void null_string_goes_to_last() {
        assertTrue(comparator.compare(null, "ALPHA") > 0);
        assertTrue(comparator.compare("ALPHA", null) < 0);
    }

    @Test
    void empty_string_goes_to_last() {
        assertTrue(comparator.compare("", "ALPHA") > 0);
    }

    @Test
    void equal_strings_return_zero() {
        assertEquals(0, comparator.compare("ABC", "ABC"));
    }

    @Test
    void singleton_instance_is_not_null() {
        assertNotNull(FondsCodeComparator.INSTANCE);
    }
}
