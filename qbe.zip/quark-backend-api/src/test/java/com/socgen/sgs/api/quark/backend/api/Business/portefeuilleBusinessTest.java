package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.portefeuilleDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class portefeuilleBusinessTest {
    @Mock
    private portefeuilleDao portefeuilleDao;

    @InjectMocks
    private portefeuilleBusiness portefeuilleBusiness;

    @Test
    public void getPortefeuilleReturnsListOfPortefeuilleWhenBusinessReturnsData() {
        List<portefeuille> mockPortefeuilles = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    portefeuille p = new portefeuille();
                    p.setDescription("Portefeuille" + i);
                    return p;
                }).toList();

        when(portefeuilleDao.getPortefeuille()).thenReturn(mockPortefeuilles);

        List<portefeuille> result = portefeuilleBusiness.getPortefeuille();

        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");
        verify(portefeuilleDao, times(1)).getPortefeuille();
    }
}
