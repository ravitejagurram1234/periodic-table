package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class FondsTest {

    @Test
    public void testNoArgsConstructor() {
        Fonds fonds = new Fonds();
        assertNotNull(fonds);
        assertNull(fonds.getKey_ref_fund());
        assertNull(fonds.getId_fnd_code());
    }

    @Test
    public void testAllArgsConstructor() {
        Fonds fonds = new Fonds("KEY01", "FND001", "2020-01-01", "2025-12-31",
                "Short Desc", "Long Desc", "N", "CLASS", "MNG001",
                "Manager Name", "MNG_SHT", "MFM001", "ACT001");

        assertEquals("KEY01", fonds.getKey_ref_fund());
        assertEquals("FND001", fonds.getId_fnd_code());
        assertEquals("2020-01-01", fonds.getId_fnd_start_validity());
        assertEquals("2025-12-31", fonds.getFnd_end_validity());
        assertEquals("Short Desc", fonds.getFnd_sht_description());
        assertEquals("Long Desc", fonds.getFnd_lng_description());
        assertEquals("N", fonds.getFnd_flg_multi_mngr());
        assertEquals("CLASS", fonds.getAct_socio_class());
        assertEquals("MNG001", fonds.getId_mng_code());
        assertEquals("Manager Name", fonds.getMng_lng_description());
        assertEquals("MNG_SHT", fonds.getMng_sht_description());
        assertEquals("MFM001", fonds.getId_mfm_manager_code());
        assertEquals("ACT001", fonds.getId_act_code());
    }

    @Test
    public void testGettersAndSetters() {
        Fonds fonds = new Fonds();

        fonds.setKey_ref_fund("KEY");
        assertEquals("KEY", fonds.getKey_ref_fund());

        fonds.setId_fnd_code("FND");
        assertEquals("FND", fonds.getId_fnd_code());

        fonds.setId_fnd_start_validity("2023-01-01");
        assertEquals("2023-01-01", fonds.getId_fnd_start_validity());

        fonds.setFnd_end_validity("2024-12-31");
        assertEquals("2024-12-31", fonds.getFnd_end_validity());

        fonds.setFnd_sht_description("SHT");
        assertEquals("SHT", fonds.getFnd_sht_description());

        fonds.setFnd_lng_description("LNG");
        assertEquals("LNG", fonds.getFnd_lng_description());

        fonds.setFnd_flg_multi_mngr("Y");
        assertEquals("Y", fonds.getFnd_flg_multi_mngr());

        fonds.setAct_socio_class("SOC");
        assertEquals("SOC", fonds.getAct_socio_class());

        fonds.setId_mng_code("MNG");
        assertEquals("MNG", fonds.getId_mng_code());

        fonds.setMng_lng_description("mng lng");
        assertEquals("mng lng", fonds.getMng_lng_description());

        fonds.setMng_sht_description("mng sht");
        assertEquals("mng sht", fonds.getMng_sht_description());

        fonds.setId_mfm_manager_code("MFM");
        assertEquals("MFM", fonds.getId_mfm_manager_code());

        fonds.setId_act_code("ACT");
        assertEquals("ACT", fonds.getId_act_code());
    }
}

