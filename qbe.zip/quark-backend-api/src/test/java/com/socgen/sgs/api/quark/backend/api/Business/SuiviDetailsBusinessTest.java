package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Fonds;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviDetailsDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SuiviDetailsBusinessTest {

    @InjectMocks
    private SuiviDetailsBusiness suiviDetailsBusiness;
    @Mock
    private SuiviDetailsDao suiviDetailsDao;

    @Test
    public void testGetListeFondsForNewSuivi() {

        SuiviDetails suiviDetails=new SuiviDetails();
        suiviDetails.setIdFndCode("CODE");

        when(suiviDetailsDao.getListeNewSuivisByFondsPart(1L, 1L, 34L,0L,LocalDate.parse("2023-10-01"),"102016","","","")).thenReturn(List.of(suiviDetails));

        List<SuiviDetails> result = suiviDetailsBusiness.getListeNewSuivisByFondsPart(1L, 1L, 34L,0L, LocalDate.parse("2023-10-01"),"102016","","","");


        assertEquals(1, result.size(), "Size should be 6");

        verify(suiviDetailsDao, times(1)).getListeNewSuivisByFondsPart(1L, 1L, 34L, 0L,LocalDate.parse("2023-10-01"),"102016","","","");
    }


}
