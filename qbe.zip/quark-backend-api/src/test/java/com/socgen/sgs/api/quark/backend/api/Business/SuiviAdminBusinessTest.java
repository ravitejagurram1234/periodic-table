package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;
import com.socgen.sgs.api.quark.backend.api.domain.InsertTrace;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviAdminDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviAuditDao;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.server.ResponseStatusException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SuiviAdminBusinessTest {

    @Mock
    private SuiviAdminDao suiviAdminDao;

    @Mock
    private SuiviAuditDao suiviAuditDao;

    @Mock
    private HttpServletRequest httpServletRequest;

    @InjectMocks
    private SuiviAdminBusiness suiviAdminBusiness;

    // ── getDateExacteSuivi ───────────────────────────────────────────────────

    @Test
    void getDateExacteSuivi_returnsDaoResult() {
        when(suiviAdminDao.getDateExacteSuivi(1L)).thenReturn("2025-01-15");

        String result = suiviAdminBusiness.getDateExacteSuivi(1L);

        assertEquals("2025-01-15", result);
        verify(suiviAdminDao, times(1)).getDateExacteSuivi(1L);
    }

    @Test
    void getDateExacteSuivi_returnsNullWhenDaoReturnsNull() {
        when(suiviAdminDao.getDateExacteSuivi(99L)).thenReturn(null);

        String result = suiviAdminBusiness.getDateExacteSuivi(99L);

        assertNull(result);
    }

    // ── updateDateExacteSuivi ────────────────────────────────────────────────

    @Test
    void updateDateExacteSuivi_callsDaoAndInsertsTrace() {
        when(httpServletRequest.getRemoteAddr()).thenReturn("10.0.0.1");

        suiviAdminBusiness.updateDateExacteSuivi(1L, "2025-06-01", httpServletRequest, "user@test.com");

        verify(suiviAdminDao, times(1)).updateDateExacteSuivi(1L, "2025-06-01");
        verify(suiviAuditDao, times(1)).insertTrace(any(InsertTrace.class));
    }

    // ── resetSuivi ───────────────────────────────────────────────────────────

    @Test
    void resetSuivi_callsDaoAndInsertsTrace_whenNotTraduction() {
        when(suiviAdminDao.getTypeSuivi(2L)).thenReturn(Enums.TypeSuivi.Standard.getValue()); // 1
        when(httpServletRequest.getRemoteAddr()).thenReturn("10.0.0.2");

        suiviAdminBusiness.resetSuivi(2L, "admin@test.com", httpServletRequest);

        verify(suiviAdminDao, times(1)).resetSuivi(2L, "admin@test.com");
        verify(suiviAuditDao, times(1)).insertTrace(any(InsertTrace.class));
    }

    @Test
    void resetSuivi_throwsBadRequest_whenTypeSuiviIsTraduction() {
        when(suiviAdminDao.getTypeSuivi(3L)).thenReturn(Enums.TypeSuivi.Traduction.getValue()); // 2

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> suiviAdminBusiness.resetSuivi(3L, "user@test.com", httpServletRequest));

        assertEquals(org.springframework.http.HttpStatus.BAD_REQUEST, ex.getStatusCode());
        verify(suiviAdminDao, never()).resetSuivi(any(), any());
        verifyNoInteractions(suiviAuditDao);
    }

    @Test
    void resetSuivi_proceedsNormally_whenTypeSuiviIsNull() {
        when(suiviAdminDao.getTypeSuivi(4L)).thenReturn(null);
        when(httpServletRequest.getRemoteAddr()).thenReturn("10.0.0.3");

        suiviAdminBusiness.resetSuivi(4L, "user@test.com", httpServletRequest);

        verify(suiviAdminDao, times(1)).resetSuivi(4L, "user@test.com");
        verify(suiviAuditDao, times(1)).insertTrace(any(InsertTrace.class));
    }

    // ── removeSuivi ──────────────────────────────────────────────────────────

    @Test
    void removeSuivi_callsDaoAndInsertsTrace() {
        when(httpServletRequest.getRemoteAddr()).thenReturn("10.0.0.4");

        suiviAdminBusiness.removeSuivi(5L, "user@test.com", httpServletRequest);

        verify(suiviAdminDao, times(1)).removeSuivi(5L, "user@test.com");
        verify(suiviAuditDao, times(1)).insertTrace(any(InsertTrace.class));
    }

    // ── unlockSuivi ──────────────────────────────────────────────────────────

    @Test
    void unlockSuivi_callsDaoAndInsertsTrace() {
        when(httpServletRequest.getRemoteAddr()).thenReturn("10.0.0.5");

        suiviAdminBusiness.unlockSuivi(6L, httpServletRequest, "user@test.com");

        verify(suiviAdminDao, times(1)).unlockSuivi(6L);
        verify(suiviAuditDao, times(1)).insertTrace(any(InsertTrace.class));
    }
}
