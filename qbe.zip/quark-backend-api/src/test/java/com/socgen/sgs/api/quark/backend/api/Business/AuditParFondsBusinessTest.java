package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditParFondsDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuditParFondsBusinessTest {

    @Mock
    private AuditParFondsDao auditParFondsDao;

    @InjectMocks
    private AuditParFondsBusiness business;

    @Test
    void delegatesInsertAuditToDao() {
        Audit audit = new Audit();
        when(auditParFondsDao.insertAudit(audit)).thenReturn(7);

        Integer result = business.AuditParFonds(audit);

        assertEquals(7, result);
        verify(auditParFondsDao).insertAudit(audit);
    }
}

