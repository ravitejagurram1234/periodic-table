package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationSocieteDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.ModificationSocieteService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class ModificationSocieteBusinessTest {
    @Mock
    private ModificationSocieteDao modificationSocieteDao;

    @InjectMocks
    private ModificationSocieteBusiness modificationSocieteBusiness;


    @Test
    void getListSociete_returnsListOfSociete() {
        List<String> mockList = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> "Document" + i)
                .toList();

        when(modificationSocieteDao.getListSociete()).thenReturn(mockList);

        List<String> result =modificationSocieteBusiness.getListSociete();

        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");
        verify(modificationSocieteDao, times(1)).getListSociete();
    }
}
