package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SocieteTest {

    @Test
    public void testNoArgsConstructor() {
        Societe societe = new Societe();
        assertNotNull(societe);
        assertNull(societe.getFND_MNGT_COMPANY());
    }

    @Test
    public void testAllArgsConstructor() {
        Societe societe = new Societe("COMPANY_A");
        assertEquals("COMPANY_A", societe.getFND_MNGT_COMPANY());
    }

    @Test
    public void testGetterAndSetter() {
        Societe societe = new Societe();
        societe.setFND_MNGT_COMPANY("COMPANY_B");
        assertEquals("COMPANY_B", societe.getFND_MNGT_COMPANY());
    }

    @Test
    public void testSetOverwrite() {
        Societe societe = new Societe("INITIAL");
        societe.setFND_MNGT_COMPANY("UPDATED");
        assertEquals("UPDATED", societe.getFND_MNGT_COMPANY());
    }
}

