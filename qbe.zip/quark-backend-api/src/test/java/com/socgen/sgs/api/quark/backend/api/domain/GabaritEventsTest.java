package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GabaritEventsTest {

    @Test
    public void testNoArgsConstructor() {
        GabaritEvents ge = new GabaritEvents();
        assertNotNull(ge);
        assertNull(ge.getIdEvent());
        assertNull(ge.getTransduction_code());
    }

    @Test
    public void testAllArgsConstructor() {
        GabaritEvents ge = new GabaritEvents(1L, "TRD001", 1L, "typeA", 2L, 0L);
        assertEquals(1L, ge.getIdEvent());
        assertEquals("TRD001", ge.getTransduction_code());
        assertEquals(1L, ge.getShow_on_eos());
        assertEquals("typeA", ge.getType());
        assertEquals(2L, ge.getEvent_type());
        assertEquals(0L, ge.getMandatory());
    }

    @Test
    public void testGettersAndSetters() {
        GabaritEvents ge = new GabaritEvents();

        ge.setIdEvent(10L);
        assertEquals(10L, ge.getIdEvent());

        ge.setTransduction_code("TRD002");
        assertEquals("TRD002", ge.getTransduction_code());

        ge.setShow_on_eos(1L);
        assertEquals(1L, ge.getShow_on_eos());

        ge.setType("typeB");
        assertEquals("typeB", ge.getType());

        ge.setEvent_type(3L);
        assertEquals(3L, ge.getEvent_type());

        ge.setMandatory(1L);
        assertEquals(1L, ge.getMandatory());
    }

    @Test
    public void testBuilderPattern() {
        GabaritEvents ge = GabaritEvents.builder()
                .idEvent(5L)
                .Transduction_code("TRD003")
                .show_on_eos(1L)
                .type("typeC")
                .event_type(4L)
                .mandatory(1L)
                .build();

        assertNotNull(ge);
        assertEquals(5L, ge.getIdEvent());
        assertEquals("TRD003", ge.getTransduction_code());
        assertEquals(1L, ge.getShow_on_eos());
        assertEquals("typeC", ge.getType());
        assertEquals(4L, ge.getEvent_type());
        assertEquals(1L, ge.getMandatory());
    }

    @Test
    public void testBuilderDefaultValues() {
        GabaritEvents ge = GabaritEvents.builder().build();
        assertNotNull(ge);
        assertNull(ge.getIdEvent());
        assertNull(ge.getTransduction_code());
    }
}

