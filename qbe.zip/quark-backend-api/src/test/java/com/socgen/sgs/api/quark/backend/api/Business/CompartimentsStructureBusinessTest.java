package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentsStructureDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.CompartimentsStructureService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class CompartimentsStructureBusinessTest {
    @Mock
    private CompartimentsStructureDao compartimentsStructureDao;

    @InjectMocks
    private CompartimentsStructureBusiness compartimentsStructureBusiness;


    @Test
    void getListStructure_returnsListOfStructures() {
        List<Structure> mockList = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    Structure s=new Structure();
                    s.setIdStructure("Document" + i);
                    return s;
                }).toList();

        when(compartimentsStructureDao.getStructures(0,null,null,null)).thenReturn(mockList);

        List<Structure> result = compartimentsStructureBusiness.getStructures(0,null,null,null);

        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");
        verify(compartimentsStructureDao, times(1)).getStructures(0,null,null,null);
    }
}
