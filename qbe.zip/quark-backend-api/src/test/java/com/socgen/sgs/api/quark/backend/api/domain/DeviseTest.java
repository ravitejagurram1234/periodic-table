package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DeviseTest {

    @Test
    public void testNoArgsConstructor() {
        Devise devise = new Devise();
        assertNotNull(devise);
        assertNull(devise.getId_devise());
        assertNull(devise.getLibelle());
    }

    @Test
    public void testAllArgsConstructor() {
        Devise devise = new Devise("EUR", "Euro");
        assertEquals("EUR", devise.getId_devise());
        assertEquals("Euro", devise.getLibelle());
    }

    @Test
    public void testGettersAndSetters() {
        Devise devise = new Devise();
        devise.setId_devise("USD");
        devise.setLibelle("Dollar");

        assertEquals("USD", devise.getId_devise());
        assertEquals("Dollar", devise.getLibelle());
    }

    @Test
    public void testSettersWithNullValues() {
        Devise devise = new Devise("GBP", "Pound");
        devise.setId_devise(null);
        devise.setLibelle(null);

        assertNull(devise.getId_devise());
        assertNull(devise.getLibelle());
    }
}
