package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationGabaritLangueDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ModificationGabaritLangueBusinessTest {

    @Mock
    private ModificationGabaritLangueDao modificationGabaritLangueDao;

    @InjectMocks
    private ModificationGabaritLangueBusiness business;

    @Test
    void getListLangue_returnsListFromDao() {
        ModificationParFondsLangue langue = new ModificationParFondsLangue();
        List<ModificationParFondsLangue> expected = List.of(langue);
        when(modificationGabaritLangueDao.getListLangue(1)).thenReturn(expected);

        List<ModificationParFondsLangue> result = business.getListLangue(1);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(modificationGabaritLangueDao, times(1)).getListLangue(1);
    }

    @Test
    void getListLangue_withDifferentTypeRapport_callsDao() {
        when(modificationGabaritLangueDao.getListLangue(5)).thenReturn(List.of());

        List<ModificationParFondsLangue> result = business.getListLangue(5);

        assertTrue(result.isEmpty());
        verify(modificationGabaritLangueDao).getListLangue(5);
    }
}

