package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.checkDoublOnDocumentDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class checkDoublOnDocumentBusinessTest {

    @Mock
    private checkDoublOnDocumentDao checkDoublOnDocument;

    @InjectMocks
    private checkDoublOnDocumentBusiness business;

    @Test
    void delegatesToDao() {
        Document document = new Document();
        when(checkDoublOnDocument.checkDoublonDocument(document)).thenReturn(1);

        Integer result = business.checkDoublOnDocument(document);

        assertEquals(1, result);
        verify(checkDoublOnDocument).checkDoublonDocument(document);
    }
}

