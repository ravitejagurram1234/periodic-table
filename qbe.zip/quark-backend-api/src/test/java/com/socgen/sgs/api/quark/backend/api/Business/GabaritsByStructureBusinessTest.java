package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritByStructure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritsByStructureDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GabaritsByStructureBusinessTest {

    @Mock
    private GabaritsByStructureDao gabaritsByStructureDao;

    @InjectMocks
    private GabaritsByStructureBusiness business;

    @Test
    void getGabaritsByStructure_returnsListFromDao() {
        List<GabaritByStructure> expected = List.of(new GabaritByStructure());
        when(gabaritsByStructureDao.getGabaritsByStructure("STR001")).thenReturn(expected);

        List<GabaritByStructure> result = business.getGabaritsByStructure("STR001");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertSame(expected, result);
        verify(gabaritsByStructureDao, times(1)).getGabaritsByStructure("STR001");
    }

    @Test
    void getGabaritsByStructure_returnsEmptyList_whenDaoReturnsEmpty() {
        when(gabaritsByStructureDao.getGabaritsByStructure("STR999")).thenReturn(List.of());

        List<GabaritByStructure> result = business.getGabaritsByStructure("STR999");

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(gabaritsByStructureDao).getGabaritsByStructure("STR999");
    }
}
