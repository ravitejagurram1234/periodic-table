package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Auditor;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditorDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.AuditorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class AuditorBusinessTest {
    @Mock
    private AuditorDao auditorDao;

    @InjectMocks
    private AuditorBusiness auditorBusiness;



    @Test
    public void testGetAccountants_ReturnsList() throws Exception {
        List<Auditor> mockAuditors = java.util.stream.IntStream.rangeClosed(1, 104)
                .mapToObj(i -> Auditor.builder().desTableValue(String.valueOf(i)).build())
                .toList();

        when(auditorDao.getListAuditors()).thenReturn(mockAuditors);
        List<Auditor> result = auditorBusiness.getAuditors();

        assertNotNull(result, "Result should not be null");
        assertEquals(104, result.size(), "Size should be 104");

        verify(auditorDao, times(1)).getListAuditors();

    }
}
