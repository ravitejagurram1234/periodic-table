package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviEventDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SuiviEventsBusinessTest {

    @Mock
    private SuiviEventDao suiviEventDao;

    @InjectMocks
    private SuiviEventsBusiness suiviEventsBusiness;

    @Test
    void getSuiviEvents_returnsList() {
        SuiviEvents event = new SuiviEvents(1L, 2L, 3L, LocalDate.of(2025, 6, 1));
        when(suiviEventDao.getSuiviEvents(100L)).thenReturn(List.of(event));

        List<SuiviEvents> result = suiviEventsBusiness.getSuiviEvents(100L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getIdEvent());
        verify(suiviEventDao, times(1)).getSuiviEvents(100L);
    }

    @Test
    void getSuiviEvents_returnsEmptyList() {
        when(suiviEventDao.getSuiviEvents(999L)).thenReturn(List.of());

        List<SuiviEvents> result = suiviEventsBusiness.getSuiviEvents(999L);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(suiviEventDao).getSuiviEvents(999L);
    }
}

