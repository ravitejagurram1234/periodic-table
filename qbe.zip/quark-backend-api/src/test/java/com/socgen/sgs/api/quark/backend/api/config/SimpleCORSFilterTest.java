package com.socgen.sgs.api.quark.backend.api.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SimpleCORSFilterTest {

    private SimpleCORSFilter filter;

    @Mock
    private FilterChain filterChain;

    @BeforeEach
    void setUp() {
        filter = new SimpleCORSFilter("http://localhost:4200", "default-src 'self'; ");
    }

    @Test
    void doFilter_setsSecurityHeaders() throws IOException, ServletException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();

        filter.doFilter(request, response, filterChain);

        assertEquals("strict-origin-when-cross-origin", response.getHeader("referrer-policy"));
        assertTrue(response.getHeader("content-security-policy").contains("default-src 'self';"));
        verify(filterChain, times(1)).doFilter(request, response);
    }

    @Test
    void doFilter_callsFilterChain() throws IOException, ServletException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();

        filter.doFilter(request, response, filterChain);

        verify(filterChain).doFilter(request, response);
    }

    @Test
    void constructor_setsAllowedOriginsAndCspPolicy() throws IOException, ServletException {
        SimpleCORSFilter f = new SimpleCORSFilter("http://example.com", "frame-ancestors 'none'; ");
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();

        f.doFilter(request, response, filterChain);

        String csp = response.getHeader("content-security-policy");
        assertNotNull(csp);
        assertTrue(csp.contains("frame-ancestors 'none';"));
        assertTrue(csp.contains("http://example.com"));
    }
}

