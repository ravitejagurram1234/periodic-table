package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SocieteDocumentDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.SocieteDocumentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class SocieteDocumentBusinessTest {
    @Mock
    private SocieteDocumentDao societeDocumentDao;

    @InjectMocks
    private SocieteDocumentBusiness societeDocumentBusiness;

    @Test
    public void getSocieteDocumentReturnsListOfDocumentsWhenBusinessReturnsData() {
        List<TypeDeDocument> mockDocuments = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    TypeDeDocument document = new TypeDeDocument();
                    document.setLIBELLE_SOUS_CATEGORIE("Document" + i);
                    return document;
                }).toList();

        when(societeDocumentDao.getSocieteDocument("123PAR")).thenReturn(mockDocuments);

        List<TypeDeDocument> result =societeDocumentBusiness.getSocieteDocument("123PAR");

        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");
        verify(societeDocumentDao, times(1)).getSocieteDocument("123PAR");
    }
}
