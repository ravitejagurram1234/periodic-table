package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ModificationParFondsLangueTest {

    @Test
    public void testNoArgsConstructor() {
        ModificationParFondsLangue langue = new ModificationParFondsLangue();
        assertNotNull(langue);
        assertEquals(0, langue.getId_langue_document());
        assertNull(langue.getValeur_langue());
        assertNull(langue.getNom_langue());
    }

    @Test
    public void testAllArgsConstructor() {
        ModificationParFondsLangue langue = new ModificationParFondsLangue(1, "FR", "Français");
        assertEquals(1, langue.getId_langue_document());
        assertEquals("FR", langue.getValeur_langue());
        assertEquals("Français", langue.getNom_langue());
    }

    @Test
    public void testGettersAndSetters() {
        ModificationParFondsLangue langue = new ModificationParFondsLangue();

        langue.setId_langue_document(2);
        assertEquals(2, langue.getId_langue_document());

        langue.setValeur_langue("EN");
        assertEquals("EN", langue.getValeur_langue());

        langue.setNom_langue("English");
        assertEquals("English", langue.getNom_langue());
    }
}

