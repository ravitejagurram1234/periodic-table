package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Accountants;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AccountantsDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.AccountantsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class AccountantBusinessTest {
    @InjectMocks
    private AccountantBusiness accountantBusiness;

    @Mock
    private AccountantsDao accountantsDao;


    @Test
    public void testGetAccountants_ReturnsList() throws Exception {
        List<Accountants> mockList = java.util.stream.IntStream.rangeClosed(1, 134)
                .mapToObj(i -> Accountants.builder().des_table_value(String.valueOf(i)).build())
                .toList();

        when(accountantsDao.getListAccountants()).thenReturn(mockList);
        List<Accountants> result = accountantBusiness.getAccountants();

        assertNotNull(result, "Result should not be null");
        assertEquals(134, result.size(), "Size should be 100");

        verify(accountantsDao, times(1)).getListAccountants();
    }
}
