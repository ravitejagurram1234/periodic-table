package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GabaritTemplateTest {

    @Test
    public void testNoArgsConstructor() {
        GabaritTemplate template = new GabaritTemplate();
        assertNotNull(template);
        assertEquals(0, template.getId_gabarit_template());
        assertNull(template.getNom());
    }

//    @Test
//    public void testAllArgsConstructor() {
//        GabaritTemplate template = new GabaritTemplate(5, "template.qxp");
//        assertEquals(5, template.getId_gabarit_template());
//        assertEquals("template.qxp", template.getNom());
//    }

    @Test
    public void testGettersAndSetters() {
        GabaritTemplate template = new GabaritTemplate();

        template.setId_gabarit_template(3);
        assertEquals(3, template.getId_gabarit_template());

        template.setNom("my-template");
        assertEquals("my-template", template.getNom());
    }
}

