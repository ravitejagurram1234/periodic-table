package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeRapport;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TypeRapportDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TypeRapportBusinessTest {

    @InjectMocks
    private TypeRapportBusiness typeRapportBusiness;

    @Mock
    private TypeRapportDao typeRapportDao;

    @Test
    public void testGetTypeRapport_returnsTypeRapportList() {
        List<TypeRapport> mockTypeRapportList = java.util.stream.IntStream.rangeClosed(1, 6)
                .mapToObj(i -> TypeRapport.builder().id((long) i).libelle("TYPE" + i).build())
                .toList();

        when(typeRapportDao.getTypeRapport()).thenReturn(mockTypeRapportList);
        List<TypeRapport> result = typeRapportBusiness.getTypeRapport();
        assertNotNull(result, "Result should not be null");
        assertEquals(6, result.size(), "Size should be 6");

        verify(typeRapportDao, times(1)).getTypeRapport();
    }
}
