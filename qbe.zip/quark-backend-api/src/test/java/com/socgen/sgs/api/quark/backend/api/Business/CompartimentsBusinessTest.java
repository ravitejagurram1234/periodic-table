package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentsDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.CompartimentsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class CompartimentsBusinessTest {
    @Mock
    private CompartimentsDao compartimentsDao;

    @InjectMocks
    private CompartimentsBusiness compartimentsBusiness;


    @Test
    void getListStructure_returnsListOfStructures() {
        List<Compartiment> mockList = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    Compartiment c=new Compartiment();
                    c.setId_fnd_code("Document" + i);
                    return c;
                }).toList();

        when(compartimentsDao.getStructures("_A0_12",null,null,null)).thenReturn(mockList);

        List<Compartiment> result =compartimentsBusiness.getStructures("_A0_12",null,null,null);

        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");
        verify(compartimentsDao, times(1)).getStructures("_A0_12",null,null,null);
    }
}
