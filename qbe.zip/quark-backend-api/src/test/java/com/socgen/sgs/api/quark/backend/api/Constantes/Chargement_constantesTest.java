package com.socgen.sgs.api.quark.backend.api.Constantes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class Chargement_constantesTest {

    @Test
    void testInstantiation() {
        // Exercises the implicit default constructor for coverage
        Chargement_constantes instance = new Chargement_constantes();
        assertNotNull(instance);
    }

    @Test
    void testMODULE_NAME() {
        assertEquals("Chargement", Chargement_constantes.MODULE_NAME);
    }

    @Test
    void testLIEN_GABARIT_FONDS() {
        assertEquals("Lien gabarit-fonds", Chargement_constantes.LIEN_GABARIT_FONDS);
    }

    @Test
    void testLIEN_STRUCTURE_COMP() {
        assertEquals("Lien structure-compartiment", Chargement_constantes.LIEN_STRUCTURE_COMP);
    }

    @Test
    void testLIEN_STRUCTURE_GABARIT_FONDS() {
        assertEquals("Lien structure-gabarit-fonds", Chargement_constantes.LIEN_STRUCTURE_GABARIT_FONDS);
    }

    @Test
    void testCREATION_DOCUMENT_PAR_FONDS() {
        assertEquals("Creation document par fonds", Chargement_constantes.CREATION_DOCUMENT_PAR_FONDS);
    }

    @Test
    void testCREATION_DOCUMENT_PAR_PART() {
        assertEquals("Creation document par part", Chargement_constantes.CREATION_DOCUMENT_PAR_PART);
    }

    @Test
    void testCREATION_DOCUMENT_PAR_SOCIETE() {
        assertEquals("Creation document par societe", Chargement_constantes.CREATION_DOCUMENT_PAR_SOCIETE);
    }

    @Test
    void testCREATION_DOCUMENT_QXP() {
        assertEquals("Creation document QXP", Chargement_constantes.CREATION_DOCUMENT_QXP);
    }

    @Test
    void testCREATION_GABARIT_TEMPLATE() {
        assertEquals("Creation gabarit template", Chargement_constantes.CREATION_GABARIT_TEMPLATE);
    }

    @Test
    void testCREATION_GABARIT() {
        assertEquals("Creation gabarit", Chargement_constantes.CREATION_GABARIT);
    }

    @Test
    void testMODIFICATION_DOCUMENT_PAR_FONDS() {
        assertEquals("Modification document par fonds", Chargement_constantes.MODIFICATION_DOCUMENT_PAR_FONDS);
    }

    @Test
    void testMODIFICATION_DOCUMENT_PAR_PART() {
        assertEquals("Modification document par part", Chargement_constantes.MODIFICATION_DOCUMENT_PAR_PART);
    }

    @Test
    void testMODIFICATION_DOCUMENT_PAR_SOCIETE() {
        assertEquals("Modification document par societe", Chargement_constantes.MODIFICATION_DOCUMENT_PAR_SOCIETE);
    }

    @Test
    void testMODIFICATION_DOCUMENT_QXP() {
        assertEquals("Modification document QXP", Chargement_constantes.MODIFICATION_DOCUMENT_QXP);
    }

    @Test
    void testMODIFICATION_GABARIT() {
        assertEquals("Modification gabarit", Chargement_constantes.MODIFICATION_GABARIT);
    }

    @Test
    void testMODIFICATION_COMPARTIMENTS() {
        assertEquals("Modification compartiments", Chargement_constantes.MODIFICATION_COMPARTIMENTS);
    }

    @Test
    void testMODIFICATION_GABARIT_TEMPLATE() {
        assertEquals("Modification gabarit template", Chargement_constantes.MODIFICATION_GABARIT_TEMPLATE);
    }

    @Test
    void testSUPPRESSION_DOCUMENT_PAR_FONDS() {
        assertEquals("Suppression document par fonds", Chargement_constantes.SUPPRESSION_DOCUMENT_PAR_FONDS);
    }

    @Test
    void testSUPPRESSION_DOCUMENT_PAR_PART() {
        assertEquals("Suppression document par part", Chargement_constantes.SUPPRESSION_DOCUMENT_PAR_PART);
    }

    @Test
    void testCSS_EXISTANTDOCUMENT() {
        assertEquals("ExistantDocument", Chargement_constantes.CSS_EXISTANTDOCUMENT);
    }
}


