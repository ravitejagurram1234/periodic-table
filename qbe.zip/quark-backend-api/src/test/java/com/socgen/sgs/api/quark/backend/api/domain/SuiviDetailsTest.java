package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class SuiviDetailsTest {

    @Test
    public void testNoArgsConstructor() {
        SuiviDetails details = new SuiviDetails();
        assertNotNull(details);
        assertNull(details.getKeyRefFund());
        assertNull(details.getIdSuivi());
    }

    @Test
    public void testAllArgsConstructor() {
        LocalDate maturity = LocalDate.of(2025, 12, 31);
        LocalDate lastEcheance = LocalDate.of(2024, 3, 1);

        SuiviDetails details = new SuiviDetails(
                "KEY001", "FND001", "INS001", "Short Desc", "Long Desc",
                maturity, "EUR", "EXT001", "Auditor X", "Accountant Y",
                "2023-12-31", "2024-12-31", "MGT Co", "Customer A",
                1L, 2L, 1, "Libelle Fond", "Libelle Classe",
                lastEcheance, "UNIT001", "INS002", "USD", "Unit Short");

        assertEquals("KEY001", details.getKeyRefFund());
        assertEquals("FND001", details.getIdFndCode());
        assertEquals("INS001", details.getUnitIdInsCode());
        assertEquals("Short Desc", details.getFndShtDescription());
        assertEquals("Long Desc", details.getFndLngDescription());
        assertEquals(maturity, details.getFndMaturityDate());
        assertEquals("EUR", details.getFndCurrency());
        assertEquals("EXT001", details.getFndExternalCode());
        assertEquals("Auditor X", details.getFndAuditor());
        assertEquals("Accountant Y", details.getFndAccountant());
        assertEquals("2023-12-31", details.getFndLastFiscalYearEnd());
        assertEquals("2024-12-31", details.getFndNextFiscalYearEnd());
        assertEquals("MGT Co", details.getFndMngtCompany());
        assertEquals("Customer A", details.getFndCustomer());
        assertEquals(1L, details.getIdSuivi());
        assertEquals(2L, details.getIdStatutGeneration());
        assertEquals(1, details.getTypeSuivi());
        assertEquals("Libelle Fond", details.getLibelleFond());
        assertEquals("Libelle Classe", details.getLibelleClasse());
        assertEquals(lastEcheance, details.getDateLastEcheance());
        assertEquals("UNIT001", details.getId_unit_code());
        assertEquals("INS002", details.getUnit_id_ins_code());
        assertEquals("USD", details.getUnit_currency());
        assertEquals("Unit Short", details.getUnit_sht_description());
    }

    @Test
    public void testGettersAndSetters() {
        SuiviDetails details = new SuiviDetails();
        LocalDate date = LocalDate.now();

        details.setKeyRefFund("KEY");
        assertEquals("KEY", details.getKeyRefFund());

        details.setIdFndCode("FND");
        assertEquals("FND", details.getIdFndCode());

        details.setUnitIdInsCode("INS");
        assertEquals("INS", details.getUnitIdInsCode());

        details.setFndShtDescription("short");
        assertEquals("short", details.getFndShtDescription());

        details.setFndLngDescription("long");
        assertEquals("long", details.getFndLngDescription());

        details.setFndMaturityDate(date);
        assertEquals(date, details.getFndMaturityDate());

        details.setFndCurrency("GBP");
        assertEquals("GBP", details.getFndCurrency());

        details.setFndExternalCode("EXT");
        assertEquals("EXT", details.getFndExternalCode());

        details.setFndAuditor("Audit");
        assertEquals("Audit", details.getFndAuditor());

        details.setFndAccountant("Account");
        assertEquals("Account", details.getFndAccountant());

        details.setFndLastFiscalYearEnd("2022-12-31");
        assertEquals("2022-12-31", details.getFndLastFiscalYearEnd());

        details.setFndNextFiscalYearEnd("2023-12-31");
        assertEquals("2023-12-31", details.getFndNextFiscalYearEnd());

        details.setFndMngtCompany("MGT");
        assertEquals("MGT", details.getFndMngtCompany());

        details.setFndCustomer("Customer");
        assertEquals("Customer", details.getFndCustomer());

        details.setIdSuivi(5L);
        assertEquals(5L, details.getIdSuivi());

        details.setIdStatutGeneration(6L);
        assertEquals(6L, details.getIdStatutGeneration());

        details.setTypeSuivi(2);
        assertEquals(2, details.getTypeSuivi());

        details.setLibelleFond("Fond");
        assertEquals("Fond", details.getLibelleFond());

        details.setLibelleClasse("Classe");
        assertEquals("Classe", details.getLibelleClasse());

        details.setDateLastEcheance(date);
        assertEquals(date, details.getDateLastEcheance());

        details.setId_unit_code("UNIT");
        assertEquals("UNIT", details.getId_unit_code());

        details.setUnit_id_ins_code("INS_UNIT");
        assertEquals("INS_UNIT", details.getUnit_id_ins_code());

        details.setUnit_currency("CHF");
        assertEquals("CHF", details.getUnit_currency());

        details.setUnit_sht_description("Unit Desc");
        assertEquals("Unit Desc", details.getUnit_sht_description());
    }
}

