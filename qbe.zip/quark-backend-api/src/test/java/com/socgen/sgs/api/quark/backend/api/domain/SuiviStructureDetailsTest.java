package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class SuiviStructureDetailsTest {

    @Test
    public void testNoArgsConstructor() {
        SuiviStructureDetails details = new SuiviStructureDetails();
        assertNotNull(details);
        assertNull(details.getIdStructure());
        assertNull(details.getIdSuivi());
    }

    @Test
    public void testAllArgsConstructor() {
        LocalDate lastFiscal = LocalDate.of(2023, 12, 31);

        SuiviStructureDetails details = new SuiviStructureDetails(
                "STR001", "Structure Name", "Accountant X", "MGT Co",
                1L, 2L, 1, "SICAV", "Actions", "Auditor Y",
                "2024-06-01", "2024-12-31", lastFiscal);

        assertEquals("STR001", details.getIdStructure());
        assertEquals("Structure Name", details.getNom());
        assertEquals("Accountant X", details.getFndAccountant());
        assertEquals("MGT Co", details.getFndMngtCompany());
        assertEquals(1L, details.getIdSuivi());
        assertEquals(2L, details.getIdStatutGeneration());
        assertEquals(1, details.getTypeSuivi());
        assertEquals("SICAV", details.getFndLegalType());
        assertEquals("Actions", details.getFndClassification());
        assertEquals("Auditor Y", details.getFndAuditor());
        assertEquals("2024-06-01", details.getDateLastEcheance());
        assertEquals("2024-12-31", details.getFndNextFiscalYearEnd());
        assertEquals(lastFiscal, details.getFndLastFiscalYearEnd());
    }

    @Test
    public void testGettersAndSetters() {
        SuiviStructureDetails details = new SuiviStructureDetails();
        LocalDate date = LocalDate.now();

        details.setIdStructure("STR002");
        assertEquals("STR002", details.getIdStructure());

        details.setNom("Name");
        assertEquals("Name", details.getNom());

        details.setFndAccountant("Account");
        assertEquals("Account", details.getFndAccountant());

        details.setFndMngtCompany("MGT");
        assertEquals("MGT", details.getFndMngtCompany());

        details.setIdSuivi(5L);
        assertEquals(5L, details.getIdSuivi());

        details.setIdStatutGeneration(6L);
        assertEquals(6L, details.getIdStatutGeneration());

        details.setTypeSuivi(2);
        assertEquals(2, details.getTypeSuivi());

        details.setFndLegalType("FCP");
        assertEquals("FCP", details.getFndLegalType());

        details.setFndClassification("Obligations");
        assertEquals("Obligations", details.getFndClassification());

        details.setFndAuditor("Audit Co");
        assertEquals("Audit Co", details.getFndAuditor());

        details.setDateLastEcheance("2024-01-01");
        assertEquals("2024-01-01", details.getDateLastEcheance());

        details.setFndNextFiscalYearEnd("2025-12-31");
        assertEquals("2025-12-31", details.getFndNextFiscalYearEnd());

        details.setFndLastFiscalYearEnd(date);
        assertEquals(date, details.getFndLastFiscalYearEnd());
    }
}

