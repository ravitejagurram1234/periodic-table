package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.DocumentQXPInsertDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DocumentQXPInsertBusinessTest {

    @Mock
    private DocumentQXPInsertDao documentQXPInsertDao;

    @InjectMocks
    private DocumentQXPInsertBusiness business;

    @Test
    void delegatesInsertCall() {
        byte[] content = new byte[] {1, 2, 3};
        when(documentQXPInsertDao.DocumentQXPInsert(content, 3)).thenReturn(11);

        Integer result = business.DocumentQXPInsert(content, 3);

        assertEquals(11, result);
        verify(documentQXPInsertDao).DocumentQXPInsert(content, 3);
    }
}

