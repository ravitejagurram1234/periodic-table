package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class R_DOMAINTest {

    @Test
    public void testNoArgsConstructor() {
        R_DOMAIN domain = new R_DOMAIN();
        assertNotNull(domain);
        assertNull(domain.getLibelle());
        assertNull(domain.getIdSuivi());
    }

    @Test
    public void testAllArgsConstructor() {
        R_DOMAIN domain = new R_DOMAIN("Libelle R", 42L);
        assertEquals("Libelle R", domain.getLibelle());
        assertEquals(42L, domain.getIdSuivi());
    }

    @Test
    public void testGettersAndSetters() {
        R_DOMAIN domain = new R_DOMAIN();

        domain.setLibelle("New Libelle");
        assertEquals("New Libelle", domain.getLibelle());

        domain.setIdSuivi(99L);
        assertEquals(99L, domain.getIdSuivi());
    }
}

