package com.socgen.sgs.api.quark.backend.api.Constantes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EnumsTest {

    @Test
    void testEnumsInstantiation() {
        // Exercises Lombok-generated default constructor on outer class
        Enums enums = new Enums();
        assertNotNull(enums);
    }

    // ---- RS ----

    @Test
    void testRS_Global() {
        assertEquals(Enums.RS.Global, Enums.RS.valueOf("Global"));
    }

    @Test
    void testRS_TypeRapport() {
        assertEquals(Enums.RS.TypeRapport, Enums.RS.valueOf("TypeRapport"));
    }

    @Test
    void testRS_values() {
        assertEquals(2, Enums.RS.values().length);
    }

    // ---- StatutGeneration ----

    @Test
    void testStatutGeneration_Blanc() {
        assertEquals(0, Enums.StatutGeneration.Blanc.getValue());
    }

    @Test
    void testStatutGeneration_AGenerer() {
        assertEquals(1, Enums.StatutGeneration.AGenerer.getValue());
    }

    @Test
    void testStatutGeneration_Genere() {
        assertEquals(2, Enums.StatutGeneration.Genere.getValue());
    }

    @Test
    void testStatutGeneration_EnErreur() {
        assertEquals(3, Enums.StatutGeneration.EnErreur.getValue());
    }

    @Test
    void testStatutGeneration_values() {
        assertEquals(4, Enums.StatutGeneration.values().length);
    }

    // ---- Roles ----

    @Test
    void testRoles_Utilisateur() {
        assertEquals(1, Enums.Roles.Utilisateur.getValue());
    }

    @Test
    void testRoles_Maquettiste() {
        assertEquals(2, Enums.Roles.Maquettiste.getValue());
    }

    @Test
    void testRoles_Admin() {
        assertEquals(3, Enums.Roles.Admin.getValue());
    }

    @Test
    void testRoles_values() {
        assertEquals(3, Enums.Roles.values().length);
    }

    // ---- TypeDocument ----

    @Test
    void testTypeDocument_QXP() {
        assertEquals(1, Enums.TypeDocument.QXP.getValue());
    }

    @Test
    void testTypeDocument_PDF() {
        assertEquals(2, Enums.TypeDocument.PDF.getValue());
    }

    @Test
    void testTypeDocument_DOC() {
        assertEquals(3, Enums.TypeDocument.DOC.getValue());
    }

    @Test
    void testTypeDocument_values() {
        assertEquals(3, Enums.TypeDocument.values().length);
    }

    // ---- TypePublication ----

    @Test
    void testTypePublication_Aucune() {
        assertEquals(Integer.MIN_VALUE, Enums.TypePublication.Aucune.getValue());
    }

    @Test
    void testTypePublication_En_cours() {
        assertEquals(1, Enums.TypePublication.En_cours.getValue());
    }

    @Test
    void testTypePublication_En_cours_interne() {
        assertEquals(2, Enums.TypePublication.En_cours_interne.getValue());
    }

    @Test
    void testTypePublication_Final() {
        assertEquals(3, Enums.TypePublication.Final.getValue());
    }

    @Test
    void testTypePublication_values() {
        assertEquals(4, Enums.TypePublication.values().length);
    }

    // ---- TypeRapport ----

    @Test
    void testTypeRapport_Undefined() {
        assertEquals(-1, Enums.TypeRapport.Undefined.getValue());
    }

    @Test
    void testTypeRapport_All() {
        assertEquals(0, Enums.TypeRapport.All.getValue());
    }

    @Test
    void testTypeRapport_RapportAnnuel() {
        assertEquals(1, Enums.TypeRapport.RapportAnnuel.getValue());
    }

    @Test
    void testTypeRapport_Plaquette() {
        assertEquals(2, Enums.TypeRapport.Plaquette.getValue());
    }

    @Test
    void testTypeRapport_Prospectus() {
        assertEquals(3, Enums.TypeRapport.Prospectus.getValue());
    }

    @Test
    void testTypeRapport_RapportCompartiment() {
        assertEquals(4, Enums.TypeRapport.RapportCompartiment.getValue());
    }

    @Test
    void testTypeRapport_DICI() {
        assertEquals(5, Enums.TypeRapport.DICI.getValue());
    }

    @Test
    void testTypeRapport_fromValue_valid() {
        assertEquals(Enums.TypeRapport.RapportAnnuel, Enums.TypeRapport.fromValue(1));
    }

    @Test
    void testTypeRapport_fromValue_invalid() {
        assertThrows(IllegalArgumentException.class, () -> Enums.TypeRapport.fromValue(99));
    }

    @Test
    void testTypeRapport_values() {
        assertEquals(7, Enums.TypeRapport.values().length);
    }

    // ---- TypeGabarit ----

    @Test
    void testTypeGabarit_Fonds_simple() {
        assertEquals(0, Enums.TypeGabarit.Fonds_simple.getValue());
    }

    @Test
    void testTypeGabarit_Structure() {
        assertEquals(1, Enums.TypeGabarit.Structure.getValue());
    }

    @Test
    void testTypeGabarit_FondsPart() {
        assertEquals(2, Enums.TypeGabarit.FondsPart.getValue());
    }

    @Test
    void testTypeGabarit_fromValue_valid() {
        assertEquals(Enums.TypeGabarit.Structure, Enums.TypeGabarit.fromValue(1));
    }

    @Test
    void testTypeGabarit_fromValue_invalid() {
        assertThrows(IllegalArgumentException.class, () -> Enums.TypeGabarit.fromValue(99));
    }

    @Test
    void testTypeGabarit_values() {
        assertEquals(3, Enums.TypeGabarit.values().length);
    }

    // ---- TypeCategorieDocument ----

    @Test
    void testTypeCategorieDocument_Portefeuille() {
        assertEquals(1, Enums.TypeCategorieDocument.Portefeuille.getValue());
    }

    @Test
    void testTypeCategorieDocument_Societe() {
        assertEquals(2, Enums.TypeCategorieDocument.Societe.getValue());
    }

    @Test
    void testTypeCategorieDocument_Autre() {
        assertEquals(99, Enums.TypeCategorieDocument.Autre.getValue());
    }

    @Test
    void testTypeCategorieDocument_Part() {
        assertEquals(3, Enums.TypeCategorieDocument.Part.getValue());
    }

    @Test
    void testTypeCategorieDocument_fromString_valid() {
        assertEquals(Enums.TypeCategorieDocument.Portefeuille, Enums.TypeCategorieDocument.fromString("Portefeuille"));
    }

    @Test
    void testTypeCategorieDocument_fromString_caseInsensitive() {
        assertEquals(Enums.TypeCategorieDocument.Societe, Enums.TypeCategorieDocument.fromString("SOCIETE"));
    }

    @Test
    void testTypeCategorieDocument_fromString_null() {
        assertThrows(IllegalArgumentException.class, () -> Enums.TypeCategorieDocument.fromString(null));
    }

    @Test
    void testTypeCategorieDocument_fromString_invalid() {
        assertThrows(IllegalArgumentException.class, () -> Enums.TypeCategorieDocument.fromString("Unknown"));
    }

    @Test
    void testTypeCategorieDocument_values() {
        assertEquals(4, Enums.TypeCategorieDocument.values().length);
    }

    // ---- EventDataType ----

    @Test
    void testEventDataType_Undefined() {
        assertEquals(-1, Enums.EventDataType.Undefined.getValue());
    }

    @Test
    void testEventDataType_SGSS() {
        assertEquals(1, Enums.EventDataType.SGSS.getValue());
    }

    @Test
    void testEventDataType_CLIENT() {
        assertEquals(2, Enums.EventDataType.CLIENT.getValue());
    }

    @Test
    void testEventDataType_values() {
        assertEquals(3, Enums.EventDataType.values().length);
    }

    // ---- EventDependency ----

    @Test
    void testEventDependency_Interne() {
        assertEquals(Enums.EventDependency.Interne, Enums.EventDependency.valueOf("Interne"));
    }

    @Test
    void testEventDependency_Tiers() {
        assertEquals(Enums.EventDependency.Tiers, Enums.EventDependency.valueOf("Tiers"));
    }

    @Test
    void testEventDependency_CAC() {
        assertEquals(Enums.EventDependency.CAC, Enums.EventDependency.valueOf("CAC"));
    }

    @Test
    void testEventDependency_values() {
        assertEquals(3, Enums.EventDependency.values().length);
    }

    // ---- EventType ----

    @Test
    void testEventType_Undefined() {
        assertEquals(0, Enums.EventType.Undefined.getValue());
    }

    @Test
    void testEventType_EventCheck() {
        assertEquals(1, Enums.EventType.EventCheck.getValue());
    }

    @Test
    void testEventType_EventDateEcheance() {
        assertEquals(2, Enums.EventType.EventDateEcheance.getValue());
    }

    @Test
    void testEventType_ListEventDataType() {
        assertEquals(4, Enums.EventType.ListEventDataType.getValue());
    }

    @Test
    void testEventType_fromValue_valid() {
        assertEquals(Enums.EventType.EventCheck, Enums.EventType.fromValue(1));
    }

    @Test
    void testEventType_fromValue_invalid() {
        assertThrows(IllegalArgumentException.class, () -> Enums.EventType.fromValue(99));
    }

    @Test
    void testEventType_values() {
        assertEquals(4, Enums.EventType.values().length);
    }

    // ---- TypeSuivi ----

    @Test
    void testTypeSuivi_Undefined() {
        assertEquals(0, Enums.TypeSuivi.Undefined.getValue());
    }

    @Test
    void testTypeSuivi_Standard() {
        assertEquals(1, Enums.TypeSuivi.Standard.getValue());
    }

    @Test
    void testTypeSuivi_Traduction() {
        assertEquals(2, Enums.TypeSuivi.Traduction.getValue());
    }

    @Test
    void testTypeSuivi_values() {
        assertEquals(3, Enums.TypeSuivi.values().length);
    }

    // ---- pagination ----

    @Test
    void testPagination_Simple() {
        assertEquals(1, Enums.pagination.Simple.getValue());
    }

    @Test
    void testPagination_Double() {
        assertEquals(2, Enums.pagination.Double.getValue());
    }

    @Test
    void testPagination_values() {
        assertEquals(2, Enums.pagination.values().length);
    }

    // ---- SuiviSortExpression ----

    @Test
    void testSuiviSortExpression_Choix() {
        assertEquals(Enums.SuiviSortExpression.Choix, Enums.SuiviSortExpression.valueOf("Choix"));
    }

    @Test
    void testSuiviSortExpression_StatutSuivi() {
        assertEquals(Enums.SuiviSortExpression.StatutSuivi, Enums.SuiviSortExpression.valueOf("StatutSuivi"));
    }

    @Test
    void testSuiviSortExpression_CodePortefeuille() {
        assertEquals(Enums.SuiviSortExpression.CodePortefeuille, Enums.SuiviSortExpression.valueOf("CodePortefeuille"));
    }

    @Test
    void testSuiviSortExpression_LibelleLongPortefeuille() {
        assertEquals(Enums.SuiviSortExpression.LibelleLongPortefeuille, Enums.SuiviSortExpression.valueOf("LibelleLongPortefeuille"));
    }

    @Test
    void testSuiviSortExpression_LibellePortefeuille() {
        assertEquals(Enums.SuiviSortExpression.LibellePortefeuille, Enums.SuiviSortExpression.valueOf("LibellePortefeuille"));
    }

    @Test
    void testSuiviSortExpression_Part() {
        assertEquals(Enums.SuiviSortExpression.Part, Enums.SuiviSortExpression.valueOf("Part"));
    }

    @Test
    void testSuiviSortExpression_CabinetGestion() {
        assertEquals(Enums.SuiviSortExpression.CabinetGestion, Enums.SuiviSortExpression.valueOf("CabinetGestion"));
    }

    @Test
    void testSuiviSortExpression_GroupeComptable() {
        assertEquals(Enums.SuiviSortExpression.GroupeComptable, Enums.SuiviSortExpression.valueOf("GroupeComptable"));
    }

    @Test
    void testSuiviSortExpression_DateClotureLast() {
        assertEquals(Enums.SuiviSortExpression.DateClotureLast, Enums.SuiviSortExpression.valueOf("DateClotureLast"));
    }

    @Test
    void testSuiviSortExpression_DateClotureNext() {
        assertEquals(Enums.SuiviSortExpression.DateClotureNext, Enums.SuiviSortExpression.valueOf("DateClotureNext"));
    }

    @Test
    void testSuiviSortExpression_Classification() {
        assertEquals(Enums.SuiviSortExpression.Classification, Enums.SuiviSortExpression.valueOf("Classification"));
    }

    @Test
    void testSuiviSortExpression_SocieteGestion() {
        assertEquals(Enums.SuiviSortExpression.SocieteGestion, Enums.SuiviSortExpression.valueOf("SocieteGestion"));
    }

    @Test
    void testSuiviSortExpression_TypeFonds() {
        assertEquals(Enums.SuiviSortExpression.TypeFonds, Enums.SuiviSortExpression.valueOf("TypeFonds"));
    }

    @Test
    void testSuiviSortExpression_TypeRapport() {
        assertEquals(Enums.SuiviSortExpression.TypeRapport, Enums.SuiviSortExpression.valueOf("TypeRapport"));
    }

    @Test
    void testSuiviSortExpression_DateDocument() {
        assertEquals(Enums.SuiviSortExpression.DateDocument, Enums.SuiviSortExpression.valueOf("DateDocument"));
    }

    @Test
    void testSuiviSortExpression_DateEcheance() {
        assertEquals(Enums.SuiviSortExpression.DateEcheance, Enums.SuiviSortExpression.valueOf("DateEcheance"));
    }

    @Test
    void testSuiviSortExpression_Langue() {
        assertEquals(Enums.SuiviSortExpression.Langue, Enums.SuiviSortExpression.valueOf("Langue"));
    }

    @Test
    void testSuiviSortExpression_CAC() {
        assertEquals(Enums.SuiviSortExpression.CAC, Enums.SuiviSortExpression.valueOf("CAC"));
    }

    @Test
    void testSuiviSortExpression_Maquettiste() {
        assertEquals(Enums.SuiviSortExpression.Maquettiste, Enums.SuiviSortExpression.valueOf("Maquettiste"));
    }

    @Test
    void testSuiviSortExpression_Gabarit() {
        assertEquals(Enums.SuiviSortExpression.Gabarit, Enums.SuiviSortExpression.valueOf("Gabarit"));
    }

    @Test
    void testSuiviSortExpression_Code() {
        assertEquals(Enums.SuiviSortExpression.Code, Enums.SuiviSortExpression.valueOf("Code"));
    }

    @Test
    void testSuiviSortExpression_values() {
        assertEquals(21, Enums.SuiviSortExpression.values().length);
    }
}



