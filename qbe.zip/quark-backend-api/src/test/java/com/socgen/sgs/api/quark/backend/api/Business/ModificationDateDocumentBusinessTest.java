package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationDateDocumentDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.ModificationDateDocumentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ModificationDateDocumentBusinessTest {
    @Mock
    private ModificationDateDocumentDao modificationDateDocumentDao;

    @InjectMocks
    private ModificationDateDocumentBusiness modificationDateDocumentBusiness;

    @Test
    void getListDateDocumentsParFonds_returnList() {
        List<Date> mockList = IntStream.rangeClosed(1, 5)
                .mapToObj(i -> Date.valueOf(LocalDate.now().minusDays(i)))
                .toList();

        when(modificationDateDocumentDao.getDateDocuments(8,"104003",null)).thenReturn(mockList);


        List<LocalDate> result =modificationDateDocumentBusiness.getDateDocuments(8,"104003",null);

        assertNotNull(result,"Result should not be null");
        assertEquals(5, result.size());
        verify(modificationDateDocumentDao,times(1)).getDateDocuments(8,"104003",null);
    }
}

