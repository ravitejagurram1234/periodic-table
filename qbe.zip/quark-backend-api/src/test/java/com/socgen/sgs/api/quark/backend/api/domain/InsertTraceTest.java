package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class InsertTraceTest {

    @Test
    public void testNoArgsConstructor() {
        InsertTrace trace = new InsertTrace();
        assertNotNull(trace);
        assertNull(trace.getP_ip());
        assertNull(trace.getP_login());
    }

    @Test
    public void testAllArgsConstructor() {
        LocalDate start = LocalDate.of(2024, 1, 10);
        LocalDate end = LocalDate.of(2024, 1, 11);
        InsertTrace trace = new InsertTrace("10.0.0.1", start, end, "/page", "user",
                "module", "fonction", "message",
                "p1", "p2", "p3", "p4", "p5",
                200, 0, 1L, "MyApp");

        assertEquals("10.0.0.1", trace.getP_ip());
        assertEquals(start, trace.getP_startTime());
        assertEquals(end, trace.getP_endTime());
        assertEquals("/page", trace.getP_page());
        assertEquals("user", trace.getP_login());
        assertEquals("module", trace.getP_module());
        assertEquals("fonction", trace.getP_fonction());
        assertEquals("message", trace.getP_message());
        assertEquals("p1", trace.getP_param1());
        assertEquals("p2", trace.getP_param2());
        assertEquals("p3", trace.getP_param3());
        assertEquals("p4", trace.getP_param4());
        assertEquals("p5", trace.getP_param5());
        assertEquals(200, trace.getP_temps_reponse());
        assertEquals(0, trace.getP_statut());
        assertEquals(1L, trace.getP_id_application());
        assertEquals("MyApp", trace.getP_nom_application());
    }

    @Test
    public void testGettersAndSetters() {
        InsertTrace trace = new InsertTrace();
        LocalDate now = LocalDate.now();

        trace.setP_ip("192.168.0.1");
        assertEquals("192.168.0.1", trace.getP_ip());

        trace.setP_startTime(now);
        assertEquals(now, trace.getP_startTime());

        trace.setP_endTime(now);
        assertEquals(now, trace.getP_endTime());

        trace.setP_page("/home");
        assertEquals("/home", trace.getP_page());

        trace.setP_login("admin");
        assertEquals("admin", trace.getP_login());

        trace.setP_module("MOD");
        assertEquals("MOD", trace.getP_module());

        trace.setP_fonction("doSomething");
        assertEquals("doSomething", trace.getP_fonction());

        trace.setP_message("OK");
        assertEquals("OK", trace.getP_message());

        trace.setP_param1("p1");
        assertEquals("p1", trace.getP_param1());

        trace.setP_param2("p2");
        assertEquals("p2", trace.getP_param2());

        trace.setP_param3("p3");
        assertEquals("p3", trace.getP_param3());

        trace.setP_param4("p4");
        assertEquals("p4", trace.getP_param4());

        trace.setP_param5("p5");
        assertEquals("p5", trace.getP_param5());

        trace.setP_temps_reponse(150);
        assertEquals(150, trace.getP_temps_reponse());

        trace.setP_statut(1);
        assertEquals(1, trace.getP_statut());

        trace.setP_id_application(42L);
        assertEquals(42L, trace.getP_id_application());

        trace.setP_nom_application("App");
        assertEquals("App", trace.getP_nom_application());
    }

    @Test
    public void testBuilderPattern() {
        LocalDate start = LocalDate.of(2024, 3, 1);
        LocalDate end = LocalDate.of(2024, 3, 2);

        InsertTrace trace = InsertTrace.builder()
                .p_ip("127.0.0.1")
                .p_startTime(start)
                .p_endTime(end)
                .p_page("/test")
                .p_login("testUser")
                .p_module("testModule")
                .p_fonction("testFonction")
                .p_message("testMsg")
                .p_param1("a")
                .p_param2("b")
                .p_param3("c")
                .p_param4("d")
                .p_param5("e")
                .p_temps_reponse(100)
                .p_statut(0)
                .p_id_application(5L)
                .p_nom_application("TestApp")
                .build();

        assertNotNull(trace);
        assertEquals("127.0.0.1", trace.getP_ip());
        assertEquals(start, trace.getP_startTime());
        assertEquals(end, trace.getP_endTime());
        assertEquals("/test", trace.getP_page());
        assertEquals("testUser", trace.getP_login());
        assertEquals("testModule", trace.getP_module());
        assertEquals("testFonction", trace.getP_fonction());
        assertEquals("testMsg", trace.getP_message());
        assertEquals("a", trace.getP_param1());
        assertEquals("b", trace.getP_param2());
        assertEquals("c", trace.getP_param3());
        assertEquals("d", trace.getP_param4());
        assertEquals("e", trace.getP_param5());
        assertEquals(100, trace.getP_temps_reponse());
        assertEquals(0, trace.getP_statut());
        assertEquals(5L, trace.getP_id_application());
        assertEquals("TestApp", trace.getP_nom_application());
    }

    @Test
    public void testBuilderDefaultValues() {
        InsertTrace trace = InsertTrace.builder().build();
        assertNotNull(trace);
        assertNull(trace.getP_ip());
        assertNull(trace.getP_statut());
    }
}

