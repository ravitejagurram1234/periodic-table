package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class SuiviEventsTest {

    @Test
    public void testNoArgsConstructor() {
        SuiviEvents event = new SuiviEvents();
        assertNotNull(event);
        assertNull(event.getIdEvent());
        assertNull(event.getIdEventStep());
        assertNull(event.getEventDataType());
        assertNull(event.getEventDateEcheance());
    }

    @Test
    public void testAllArgsConstructor() {
        LocalDate date = LocalDate.of(2024, 9, 15);
        SuiviEvents event = new SuiviEvents(1L, 2L, 3L, date);

        assertEquals(1L, event.getIdEvent());
        assertEquals(2L, event.getIdEventStep());
        assertEquals(3L, event.getEventDataType());
        assertEquals(date, event.getEventDateEcheance());
    }

    @Test
    public void testGettersAndSetters() {
        SuiviEvents event = new SuiviEvents();
        LocalDate date = LocalDate.now();

        event.setIdEvent(10L);
        assertEquals(10L, event.getIdEvent());

        event.setIdEventStep(20L);
        assertEquals(20L, event.getIdEventStep());

        event.setEventDataType(30L);
        assertEquals(30L, event.getEventDataType());

        event.setEventDateEcheance(date);
        assertEquals(date, event.getEventDateEcheance());
    }
}

