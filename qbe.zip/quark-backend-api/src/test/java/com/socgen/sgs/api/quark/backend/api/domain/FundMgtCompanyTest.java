package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class FundMgtCompanyTest {

    @Test
    public void testNoArgsConstructor() {
        FundMgtCompany company = new FundMgtCompany();
        assertNotNull(company);
        assertNull(company.getIdMgtCode());
    }

    @Test
    public void testAllArgsConstructor() {
        FundMgtCompany company = new FundMgtCompany("MGT001");
        assertEquals("MGT001", company.getIdMgtCode());
    }

    @Test
    public void testGetterAndSetter() {
        FundMgtCompany company = new FundMgtCompany();
        company.setIdMgtCode("MGT002");
        assertEquals("MGT002", company.getIdMgtCode());
    }

    @Test
    public void testBuilderPattern() {
        FundMgtCompany company = FundMgtCompany.builder()
                .idMgtCode("MGT003")
                .build();
        assertNotNull(company);
        assertEquals("MGT003", company.getIdMgtCode());
    }

    @Test
    public void testBuilderDefaultValues() {
        FundMgtCompany company = FundMgtCompany.builder().build();
        assertNotNull(company);
        assertNull(company.getIdMgtCode());
    }

    @Test
    public void testBuilderReturnsFluentBuilder() {
        FundMgtCompany.Builder builder = FundMgtCompany.builder();
        FundMgtCompany.Builder same = builder.idMgtCode("X");
        assertNotNull(same);
        assertEquals("X", builder.build().getIdMgtCode());
    }
}

