package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDTO;
import com.socgen.sgs.api.quark.backend.api.domain.InsertTrace;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviAuditDao;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SuiviAuditBusinessTest {

    @Mock
    private SuiviAuditDao suiviAuditDao;

    @Mock
    private HttpServletRequest httpServletRequest;

    @InjectMocks
    private SuiviAuditBusiness suiviAuditBusiness;

    @Test
    void insertTrace_mapsAndDelegatesToDao() {
        SuiviDTO suivi = new SuiviDTO();
        suivi.setP_id("FND001");
        suivi.setP_id_type_rapport(2L);
        suivi.setP_date_echeance(LocalDate.of(2025, 1, 1));
        suivi.setP_id_langue(1L);

        when(httpServletRequest.getRemoteAddr()).thenReturn("127.0.0.1");
        when(suiviAuditDao.insertTrace(any(InsertTrace.class))).thenReturn(42L);

        Long result = suiviAuditBusiness.InsertTrace(suivi, httpServletRequest);

        assertNotNull(result);
        assertEquals(42L, result);
        verify(suiviAuditDao, times(1)).insertTrace(any(InsertTrace.class));
    }

    @Test
    void insertTrace_withNullFields_doesNotThrow() {
        SuiviDTO suivi = new SuiviDTO();
        suivi.setP_id(null);
        suivi.setP_id_type_rapport(null);
        suivi.setP_date_echeance(null);
        suivi.setP_id_langue(null);

        when(httpServletRequest.getRemoteAddr()).thenReturn("192.168.1.1");
        when(suiviAuditDao.insertTrace(any(InsertTrace.class))).thenReturn(1L);

        Long result = suiviAuditBusiness.InsertTrace(suivi, httpServletRequest);

        assertNotNull(result);
        assertEquals(1L, result);
    }
}

