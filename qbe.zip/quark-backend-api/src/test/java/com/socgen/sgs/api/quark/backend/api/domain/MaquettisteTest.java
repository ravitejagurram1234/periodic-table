package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MaquettisteTest {

    @Test
    public void testNoArgsConstructor() {
        Maquettiste maquettiste = new Maquettiste();
        assertNotNull(maquettiste);
        assertNull(maquettiste.getId());
        assertNull(maquettiste.getTrigramme());
    }

    @Test
    public void testAllArgsConstructor() {
        Maquettiste maquettiste = new Maquettiste(1L, "MAQ");
        assertEquals(1L, maquettiste.getId());
        assertEquals("MAQ", maquettiste.getTrigramme());
    }

    @Test
    public void testGettersAndSetters() {
        Maquettiste maquettiste = new Maquettiste();

        maquettiste.setId(5L);
        assertEquals(5L, maquettiste.getId());

        maquettiste.setTrigramme("ABC");
        assertEquals("ABC", maquettiste.getTrigramme());
    }

    @Test
    public void testBuilderPattern() {
        Maquettiste maquettiste = Maquettiste.builder()
                .id(10L)
                .trigramme("XYZ")
                .build();

        assertNotNull(maquettiste);
        assertEquals(10L, maquettiste.getId());
        assertEquals("XYZ", maquettiste.getTrigramme());
    }

    @Test
    public void testBuilderDefaultValues() {
        Maquettiste maquettiste = Maquettiste.builder().build();
        assertNotNull(maquettiste);
        assertNull(maquettiste.getId());
        assertNull(maquettiste.getTrigramme());
    }

    @Test
    public void testBuilderFluentApi() {
        Maquettiste.Builder builder = Maquettiste.builder();
        assertNotNull(builder.id(1L));
        assertNotNull(builder.trigramme("TRI"));
    }
}

