package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateGabaritDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UpdateGabaritBusinessTest {

    @Mock
    private UpdateGabaritDao updateGabaritDao;

    @InjectMocks
    private UpdateGabaritBusiness updateGabaritBusiness;

    @Test
    void updateGabarit_delegatesToDao() {
        Gabarit gabarit = new Gabarit();
        gabarit.setNom("TestGabarit");
        Long id = 10L;

        doNothing().when(updateGabaritDao).updateGabarit(gabarit, id);

        updateGabaritBusiness.updateGabarit(gabarit, id);

        verify(updateGabaritDao, times(1)).updateGabarit(gabarit, id);
    }

    @Test
    void updateGabarit_calledWithNullGabarit_doesNotThrow() {
        Gabarit gabarit = new Gabarit();
        Long id = 99L;

        doNothing().when(updateGabaritDao).updateGabarit(gabarit, id);

        updateGabaritBusiness.updateGabarit(gabarit, id);

        verify(updateGabaritDao).updateGabarit(gabarit, id);
    }
}

