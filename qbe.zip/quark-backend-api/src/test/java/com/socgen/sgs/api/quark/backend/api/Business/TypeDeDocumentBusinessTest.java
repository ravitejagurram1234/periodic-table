package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TypeDeDocumentDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.TypeDeDocumentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class TypeDeDocumentBusinessTest {
    @Mock
    private TypeDeDocumentDao typeDeDocumentDao;

    @InjectMocks
    private TypeDeDocumentBusiness typeDeDocumentBusiness;

    @Test
    public void getTypeDocumentReturnsListOfDocumentsWhenBusinessReturnsData() {
        List<TypeDeDocument> mockDocuments = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    TypeDeDocument document = new TypeDeDocument();
                    document.setLIBELLE_SOUS_CATEGORIE("Document" + i);
                    return document;
                }).toList();

        when(typeDeDocumentBusiness.getTypeDocument("101001", 1L)).thenReturn(mockDocuments);

        List<TypeDeDocument> result = typeDeDocumentBusiness.getTypeDocument("101001", 1L);

        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");
        verify(typeDeDocumentDao, times(1)).getTypeDocument("101001", 1L);
    }
}
