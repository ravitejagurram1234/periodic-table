package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class CompartimentTest {

    @Test
    public void testNoArgsConstructor() {
        Compartiment compartiment = new Compartiment();
        assertNotNull(compartiment);
        assertNull(compartiment.getKey_ref_fund());
        assertNull(compartiment.getId_fnd_code());
    }

    @Test
    public void testAllArgsConstructor() {
        LocalDate start = LocalDate.of(2020, 1, 1);
        LocalDate end = LocalDate.of(2025, 12, 31);
        LocalDate lastFiscal = LocalDate.of(2023, 12, 31);
        LocalDate nextFiscal = LocalDate.of(2024, 12, 31);
        LocalDate finComp = LocalDate.of(2026, 6, 30);

        Compartiment c = new Compartiment("KEY01", "FND001", start, end,
                "SHT", "LNG", "N", "CHR", "ACC", "ACT",
                "CLASS", "ACT_LNG", "MNG001", "EUR", "MNG LNG",
                "MNG_SHT", "MFM001", lastFiscal, nextFiscal,
                "MFM_ACT", "Libelle", finComp, "ECO_GEO");

        assertEquals("KEY01", c.getKey_ref_fund());
        assertEquals("FND001", c.getId_fnd_code());
        assertEquals(start, c.getId_fnd_start_validity());
        assertEquals(end, c.getFnd_end_validity());
        assertEquals("SHT", c.getFnd_sht_description());
        assertEquals("LNG", c.getFnd_lng_description());
        assertEquals("N", c.getFnd_flg_multi_mngr());
        assertEquals("CHR", c.getFnd_chart_account());
        assertEquals("ACC", c.getFnd_accountant());
        assertEquals("ACT", c.getId_act_code());
        assertEquals("CLASS", c.getAct_socio_class());
        assertEquals("ACT_LNG", c.getAct_lng_description());
        assertEquals("MNG001", c.getId_mng_code());
        assertEquals("EUR", c.getDevise_poche());
        assertEquals("MNG LNG", c.getMng_lng_description());
        assertEquals("MNG_SHT", c.getMngShtDescription());
        assertEquals("MFM001", c.getId_mfm_manager_code());
        assertEquals(lastFiscal, c.getFnd_last_fiscal_year_end());
        assertEquals(nextFiscal, c.getFnd_next_fiscal_year_end());
        assertEquals("MFM_ACT", c.getMfm_actor());
        assertEquals("Libelle", c.getLibelle_compartiment());
        assertEquals(finComp, c.getDate_fin_compartiment());
        assertEquals("ECO_GEO", c.getPresentation_eco_geo());
    }

    @Test
    public void testGettersAndSetters() {
        Compartiment c = new Compartiment();
        LocalDate date = LocalDate.of(2024, 6, 1);

        c.setKey_ref_fund("KEY");
        assertEquals("KEY", c.getKey_ref_fund());

        c.setId_fnd_code("FND");
        assertEquals("FND", c.getId_fnd_code());

        c.setId_fnd_start_validity(date);
        assertEquals(date, c.getId_fnd_start_validity());

        c.setFnd_end_validity(date);
        assertEquals(date, c.getFnd_end_validity());

        c.setFnd_sht_description("short");
        assertEquals("short", c.getFnd_sht_description());

        c.setFnd_lng_description("long");
        assertEquals("long", c.getFnd_lng_description());

        c.setFnd_flg_multi_mngr("Y");
        assertEquals("Y", c.getFnd_flg_multi_mngr());

        c.setFnd_chart_account("chart");
        assertEquals("chart", c.getFnd_chart_account());

        c.setFnd_accountant("acc");
        assertEquals("acc", c.getFnd_accountant());

        c.setId_act_code("ACT");
        assertEquals("ACT", c.getId_act_code());

        c.setAct_socio_class("SOC");
        assertEquals("SOC", c.getAct_socio_class());

        c.setAct_lng_description("act lng");
        assertEquals("act lng", c.getAct_lng_description());

        c.setId_mng_code("MNG");
        assertEquals("MNG", c.getId_mng_code());

        c.setDevise_poche("USD");
        assertEquals("USD", c.getDevise_poche());

        c.setMng_lng_description("mng lng");
        assertEquals("mng lng", c.getMng_lng_description());

        c.setMngShtDescription("mng sht");
        assertEquals("mng sht", c.getMngShtDescription());

        c.setId_mfm_manager_code("MFM");
        assertEquals("MFM", c.getId_mfm_manager_code());

        c.setFnd_last_fiscal_year_end(date);
        assertEquals(date, c.getFnd_last_fiscal_year_end());

        c.setFnd_next_fiscal_year_end(date);
        assertEquals(date, c.getFnd_next_fiscal_year_end());

        c.setMfm_actor("actor");
        assertEquals("actor", c.getMfm_actor());

        c.setLibelle_compartiment("libelle");
        assertEquals("libelle", c.getLibelle_compartiment());

        c.setDate_fin_compartiment(date);
        assertEquals(date, c.getDate_fin_compartiment());

        c.setPresentation_eco_geo("eco");
        assertEquals("eco", c.getPresentation_eco_geo());
    }
}

