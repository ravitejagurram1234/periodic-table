package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParFondsDocumentDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.ModificationParFondsDocumentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class ModificationParFondsDocumentBusinessTest {
    @Mock
    private ModificationParFondsDocumentDao modificationParFondsDocumentDao;

    @InjectMocks
    private ModificationParFondsDocumentBusiness modificationParFondsDocumentBusiness;


    @Test
    void getListDocument_returnsListOfPortefeuille() {
        List<ModificationParFondsDocument> mockDocuments = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    ModificationParFondsDocument d=new ModificationParFondsDocument();
                    d.setNom_document("Document" + i);
                    return d;
                }).toList();

        when(modificationParFondsDocumentDao.getDocumentName("104003",null,8,1, LocalDate.parse("2010-09-01"))).thenReturn(mockDocuments);

        List<ModificationParFondsDocument> result = modificationParFondsDocumentBusiness.getDocumentName("104003",null,8,1,LocalDate.parse("2010-09-01"));

        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");
        verify(modificationParFondsDocumentDao, times(1)).getDocumentName("104003",null,8,1,LocalDate.parse("2010-09-01"));
    }
}
