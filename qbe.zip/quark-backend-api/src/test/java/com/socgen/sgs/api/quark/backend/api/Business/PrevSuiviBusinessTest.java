package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Fonds;
import com.socgen.sgs.api.quark.backend.api.domain.PrevSuiviEvents;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PrevSuiviDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviDetailsDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class PrevSuiviBusinessTest {
    @InjectMocks
    private PrevSuiviBusiness prevSuiviBusiness;
    @Mock
    private PrevSuiviDao prevSuiviDao;

    @Test
    public void testGetListePrevSuiviForNewSuivi() {
        PrevSuiviEvents p=new PrevSuiviEvents();
        p.setLibelle("CODE");

        when(prevSuiviDao.getPrevSuiviEvents("102016",null,1L,1L, LocalDate.parse("2023-12-31"),34L)).thenReturn(List.of(p));

        List<PrevSuiviEvents> result = prevSuiviBusiness.getSuiviEvents("102016",null,1L,1L, LocalDate.parse("2023-12-31"),34L);


        assertEquals(1, result.size(), "Size should be 5");

        verify(prevSuiviDao, times(1)).getPrevSuiviEvents("102016",null,1L,1L, LocalDate.parse("2023-12-31"),34L);
    }
}
