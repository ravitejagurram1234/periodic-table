package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GabaritsTest {

    @Test
    public void testNoArgsConstructor() {
        Gabarits gabarits = new Gabarits();
        assertNotNull(gabarits);
        assertEquals(0, gabarits.getId_gabarit());
        assertNull(gabarits.getNom());
    }

    @Test
    public void testAllArgsConstructor() {
        Gabarits gabarits = new Gabarits(1, "gabarit.qxp", 2L, 3L, 4L);
        assertEquals(1, gabarits.getId_gabarit());
        assertEquals("gabarit.qxp", gabarits.getNom());
        assertEquals(2L, gabarits.getId_type_rapport());
        assertEquals(3L, gabarits.getId_langue());
        assertEquals(4L, gabarits.getType_gabarit());
    }

    @Test
    public void testGettersAndSetters() {
        Gabarits gabarits = new Gabarits();

        gabarits.setId_gabarit(10);
        assertEquals(10, gabarits.getId_gabarit());

        gabarits.setNom("name");
        assertEquals("name", gabarits.getNom());

        gabarits.setId_type_rapport(5L);
        assertEquals(5L, gabarits.getId_type_rapport());

        gabarits.setId_langue(6L);
        assertEquals(6L, gabarits.getId_langue());

        gabarits.setType_gabarit(7L);
        assertEquals(7L, gabarits.getType_gabarit());
    }

    @Test
    public void testBuilderPattern() {
        Gabarits gabarits = Gabarits.builder()
                .id_gabarit(2)
                .nom("templateName")
                .id_type_rapport(3L)
                .id_langue(4L)
                .type_gabarit(5L)
                .build();

        assertNotNull(gabarits);
        assertEquals(2, gabarits.getId_gabarit());
        assertEquals("templateName", gabarits.getNom());
        assertEquals(3L, gabarits.getId_type_rapport());
        assertEquals(4L, gabarits.getId_langue());
        assertEquals(5L, gabarits.getType_gabarit());
    }

    @Test
    public void testBuilderDefaultValues() {
        Gabarits gabarits = Gabarits.builder().build();
        assertNotNull(gabarits);
        assertEquals(0, gabarits.getId_gabarit());
        assertNull(gabarits.getNom());
    }
}

