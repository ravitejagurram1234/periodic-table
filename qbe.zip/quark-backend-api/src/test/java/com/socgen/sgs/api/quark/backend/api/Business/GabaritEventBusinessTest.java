package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritEventDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.GabaritEventService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class GabaritEventBusinessTest {
    @InjectMocks
    private GabaritEventBusiness gabaritEventBusiness;

    @Mock
    private GabaritEventDao gabaritEventDao;

    @Test
    public void getGabaritEvent_returnsLargeEventListSuccessfully() {
        List<GabaritEvents> mockList = java.util.stream.IntStream.rangeClosed(1, 8)
                .mapToObj(i -> {
                    GabaritEvents event = new GabaritEvents();
                    event.setTransduction_code("EVENT" + i);
                    return event;
                }).toList();

        when(gabaritEventDao.getGabaritEvent(47L)).thenReturn(mockList);
        List<GabaritEvents> result = gabaritEventBusiness.getGabaritEvents(47L);

        assertNotNull(result, "Result should not be null");
        assertEquals(8, result.size(), "Size should be 8");

        verify(gabaritEventDao, times(1)).getGabaritEvent(47L);
    }
}
