package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.categorieDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class categorieBusinessTest {

    @Mock
    private categorieDao dao;

    @InjectMocks
    private categorieBusiness categorieBusiness;

    @Test
    void getListeSousCategorie_returnsList() {
        TypeDeDocument doc = new TypeDeDocument(1L, "Rapport Annuel");
        when(dao.getListeSousCategorie(1, 0)).thenReturn(List.of(doc));

        List<TypeDeDocument> result = categorieBusiness.getListeSousCategorie(1, 0);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Rapport Annuel", result.get(0).getLIBELLE_SOUS_CATEGORIE());
        verify(dao, times(1)).getListeSousCategorie(1, 0);
    }

    @Test
    void getListeSousCategorie_returnsEmptyList() {
        when(dao.getListeSousCategorie(99, 1)).thenReturn(List.of());

        List<TypeDeDocument> result = categorieBusiness.getListeSousCategorie(99, 1);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(dao).getListeSousCategorie(99, 1);
    }
}

