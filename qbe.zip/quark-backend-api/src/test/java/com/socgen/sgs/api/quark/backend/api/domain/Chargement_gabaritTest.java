package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Chargement_gabaritTest {

    @Test
    public void testNoArgsConstructor() {
        Chargement_gabarit cg = new Chargement_gabarit();
        assertNotNull(cg);
        assertNull(cg.getNom_gabarit());
        assertEquals(0, cg.getP_id_type_rapport());
    }

//    @Test
//    public void testAllArgsConstructor() {
//        byte[] content = new byte[]{1, 2, 3};
//        Chargement_gabarit cg = new Chargement_gabarit().
////        Chargement_gabarit cg = new Chargement_gabarit(1, "gabarit.qxp", 2, content, 3, 1, 4, 5, 6, 0, "comment", "templateName");
//        assertEquals(1, cg.getP_id_type_rapport());
//        assertEquals("gabarit.qxp", cg.getNom_gabarit());
//        assertEquals(2, cg.getP_id_langue());
//        assertArrayEquals(content, cg.getP_contenu());
//        assertEquals(3, cg.getP_taille_gabarit());
//        assertEquals(1, cg.getP_is_actif());
//        assertEquals(4, cg.getP_type());
//        assertEquals(5, cg.getP_id_sous_categorie());
//        assertEquals(6, cg.getP_id_gabarit_template());
//        assertEquals(0, cg.getP_pagination_double());
//        assertEquals("comment", cg.getP_commentaire());
//        assertEquals("templateName", cg.getP_nom_gabarit_template());
//    }

    @Test
    public void testPartialConstructor() {
        byte[] content = new byte[]{5, 6};
        Chargement_gabarit cg = new Chargement_gabarit("myTemplate", content, "my comment");
        assertEquals("myTemplate", cg.getP_nom_gabarit_template());
        assertArrayEquals(content, cg.getP_contenu());
        assertEquals("my comment", cg.getP_commentaire());
    }

    @Test
    public void testGettersAndSetters() {
        Chargement_gabarit cg = new Chargement_gabarit();

        cg.setP_id_type_rapport(10);
        assertEquals(10, cg.getP_id_type_rapport());

        cg.setNom_gabarit("nom");
        assertEquals("nom", cg.getNom_gabarit());

        cg.setP_id_langue(20);
        assertEquals(20, cg.getP_id_langue());

        byte[] content = new byte[]{9};
        cg.setP_contenu(content);
        assertArrayEquals(content, cg.getP_contenu());

        cg.setP_taille_gabarit(100);
        assertEquals(100, cg.getP_taille_gabarit());

        cg.setP_is_actif(1);
        assertEquals(1, cg.getP_is_actif());

        cg.setP_type(3);
        assertEquals(3, cg.getP_type());

        cg.setP_id_sous_categorie(7);
        assertEquals(7, cg.getP_id_sous_categorie());

        cg.setP_id_gabarit_template(8);
        assertEquals(8, cg.getP_id_gabarit_template());

        cg.setP_pagination_double(1);
        assertEquals(1, cg.getP_pagination_double());

        cg.setP_commentaire("a comment");
        assertEquals("a comment", cg.getP_commentaire());

        cg.setP_nom_gabarit_template("template");
        assertEquals("template", cg.getP_nom_gabarit_template());
    }
}

