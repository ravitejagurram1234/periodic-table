package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritsDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GabaritBusinessTest {

    @InjectMocks
    private GabaritsBusiness gabaritBusiness;

    @Mock
    private GabaritsDao gabaritDao;

    @Test
    public void testGetGabarit_returnsGabaritList() {
        List<Gabarits> mockList=java.util.stream.IntStream.rangeClosed(1,180).
                mapToObj(i-> {
                    Gabarits g = new Gabarits();
                    g.setId_gabarit(i);
                    g.setNom("GAB" + i);
                    g.setId_langue(1L);
                    g.setId_type_rapport(2L);
                    g.setType_gabarit(10L);
                    return g;
                }).toList();

        when(gabaritDao.getGabarits(1L,2L,1)).thenReturn(mockList);
        List<Gabarits> result = gabaritBusiness.getGabarits(1L,2L,1);
        assertNotNull(result, "Result should not be null");
        assertEquals(180, result.size(), "Size should be 5");

        verify(gabaritDao, times(1)).getGabarits(1L,2L,1);
    }
}
