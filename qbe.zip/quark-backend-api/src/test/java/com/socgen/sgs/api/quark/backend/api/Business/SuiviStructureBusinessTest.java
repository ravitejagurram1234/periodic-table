package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviStructureDetails;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviDetailsDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviStructureDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class SuiviStructureBusinessTest {
    @InjectMocks
    private SuiviStructureBusiness structureBusiness;
    @Mock
    private SuiviStructureDao structureDao;

    @Test
    public void testGetListeStructuresForNewSuivi() {
        SuiviStructureDetails suiviStructureDetails=new SuiviStructureDetails();
        suiviStructureDetails.setIdStructure("CODE");
        when(structureDao.getListeStructuresForNewSuivi(2L, 1L, 160L, LocalDate.parse("2023-10-01"),"_A0_12","","",""))
                .thenReturn(List.of(suiviStructureDetails));

        List<SuiviStructureDetails> result = structureBusiness.getListeStructuresForNewSuivi(2L, 1L, 160L, LocalDate.parse("2023-10-01"),"_A0_12","","","");


        assertEquals(1, result.size(), "Size should be 1");

        verify(structureDao, times(1)).getListeStructuresForNewSuivi(2L, 1L, 160L, LocalDate.parse("2023-10-01"),"_A0_12","","","");
    }
}
