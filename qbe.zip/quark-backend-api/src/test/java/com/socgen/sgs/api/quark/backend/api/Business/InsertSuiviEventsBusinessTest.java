package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertSuiviEventDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InsertSuiviEventsBusinessTest {

    @Mock
    private InsertSuiviEventDao insertSuiviEventDao;

    @InjectMocks
    private InsertSuiviEventsBusiness business;

    @Test
    void insertSuiviEvent_delegatesToDao_withAllParams() {
        Long idSuivi = 10L, idEvent = 5L, idUser = 1L, eventDataType = -1L;
        LocalDate date = LocalDate.of(2024, 12, 31);
        doNothing().when(insertSuiviEventDao).insertSuiviEvent(idSuivi, idEvent, idUser, eventDataType, date);

        business.insertSuiviEvent(idSuivi, idEvent, idUser, eventDataType, date);

        verify(insertSuiviEventDao, times(1)).insertSuiviEvent(idSuivi, idEvent, idUser, eventDataType, date);
    }

    @Test
    void insertSuiviEvent_withNullDate_delegatesToDao() {
        doNothing().when(insertSuiviEventDao).insertSuiviEvent(20L, 3L, 2L, -1L, null);

        business.insertSuiviEvent(20L, 3L, 2L, -1L, null);

        verify(insertSuiviEventDao).insertSuiviEvent(20L, 3L, 2L, -1L, null);
    }
}

