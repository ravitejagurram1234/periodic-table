package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PrevSuiviEventsTest {

    @Test
    public void testNoArgsConstructor() {
        PrevSuiviEvents event = new PrevSuiviEvents();
        assertNotNull(event);
        assertNull(event.getId_event());
        assertNull(event.getLibelle());
    }

    @Test
    public void testAllArgsConstructor() {
        PrevSuiviEvents event = new PrevSuiviEvents(1L, 2L, "Libelle", 1L, "TRAD001", "typeX", 3L, 0L);
        assertEquals(1L, event.getId_event());
        assertEquals(2L, event.getId_statut_suivi());
        assertEquals("Libelle", event.getLibelle());
        assertEquals(1L, event.getShow_on_eos());
        assertEquals("TRAD001", event.getTraduction_code());
        assertEquals("typeX", event.getType());
        assertEquals(3L, event.getEvent_type());
        assertEquals(0L, event.getMandatory());
    }

    @Test
    public void testGettersAndSetters() {
        PrevSuiviEvents event = new PrevSuiviEvents();

        event.setId_event(10L);
        assertEquals(10L, event.getId_event());

        event.setId_statut_suivi(20L);
        assertEquals(20L, event.getId_statut_suivi());

        event.setLibelle("Libelle Test");
        assertEquals("Libelle Test", event.getLibelle());

        event.setShow_on_eos(1L);
        assertEquals(1L, event.getShow_on_eos());

        event.setTraduction_code("TRD");
        assertEquals("TRD", event.getTraduction_code());

        event.setType("typeY");
        assertEquals("typeY", event.getType());

        event.setEvent_type(5L);
        assertEquals(5L, event.getEvent_type());

        event.setMandatory(1L);
        assertEquals(1L, event.getMandatory());
    }
}

