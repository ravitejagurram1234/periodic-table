package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentsDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateCompartimentsDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UpdateCompartimentsBusinessTest {

    @Mock
    private UpdateCompartimentsDao updateCompartimentsDao;

    @InjectMocks
    private UpdateCompartimentsBusiness updateCompartimentsBusiness;

    @Test
    void updateCompartimentInfos_delegatesToDao() {
        CompartimentsDTO dto = new CompartimentsDTO();
        dto.setId_fnd_code("FND001");
        dto.setLibelle_compartiment("Short desc");

        doNothing().when(updateCompartimentsDao).updateCompartimentInfos(any());

        updateCompartimentsBusiness.updateCompartimentInfos(dto);

        verify(updateCompartimentsDao, times(1)).updateCompartimentInfos(any());
    }

    @Test
    void updateCompartimentInfos_withEmptyDto_doesNotThrow() {
        CompartimentsDTO dto = new CompartimentsDTO();

        doNothing().when(updateCompartimentsDao).updateCompartimentInfos(any());

        updateCompartimentsBusiness.updateCompartimentInfos(dto);

        verify(updateCompartimentsDao).updateCompartimentInfos(any());
    }
}


