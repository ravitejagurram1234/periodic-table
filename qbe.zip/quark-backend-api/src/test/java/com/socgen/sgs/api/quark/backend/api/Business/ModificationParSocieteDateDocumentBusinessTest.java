package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteDateDocumentDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.ModificationParSocieteDateDocumentsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class ModificationParSocieteDateDocumentBusinessTest {
    @Mock
    private ModificationParSocieteDateDocumentDao modificationParSocieteDateDocumentDao;

    @InjectMocks
    private ModificationParSocieteDateDocumentBusiness modificationParSocieteDateDocumentBusiness;

    @Test
    void getListDateDocumentsParFonds() {
        List<java.sql.Date> mockList = IntStream.rangeClosed(1, 5)
                .mapToObj(i -> Date.valueOf(LocalDate.now().minusDays(i)))
                .toList();

        when(modificationParSocieteDateDocumentDao.getDateDocuments("360AM",5)).thenReturn(mockList);

        List<LocalDate> result =modificationParSocieteDateDocumentBusiness.getDateDocuments("360AM",5);

        assertNotNull(result,"Result should not be null");
        assertEquals(5, result.size());
        verify(modificationParSocieteDateDocumentDao,times(1)).getDateDocuments("360AM",5);
    }
}
