package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteLangueDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.ModificationParSocieteLangueService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class ModificationParSocieteLangueBusinessTest {
    @Mock
    private ModificationParSocieteLangueDao modificationParSocieteLangueDao;

    @InjectMocks
    private ModificationParSocieteLangueBusiness modificationParSocieteLangueBusiness;

    @Test
    void getListLangue_returnsListOfLangue() {
        List<ModificationParFondsLangue> mockList = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> {
                    ModificationParFondsLangue l=new ModificationParFondsLangue();
                    l.setNom_langue("Document" + i);
                    return l;
                }).toList();

        when(modificationParSocieteLangueDao.getLangues("360AM",8, LocalDate.parse("2010-09-01"))).thenReturn(mockList);

        List<ModificationParFondsLangue> result =modificationParSocieteLangueBusiness.getLangues("360AM",8, LocalDate.parse("2010-09-01"));

        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");
        verify(modificationParSocieteLangueDao, times(1)).getLangues("360AM",8, LocalDate.parse("2010-09-01"));
    }
}
