package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Suivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertSuiviDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InsertSuiviBusinessTest {

    @Mock
    private InsertSuiviDao suiviDao;

    @InjectMocks
    private InsertSuiviBusiness business;

    @Test
    void insertSuivi_mapsToDomaindAndReturnsId() {
        SuiviDTO dto = new SuiviDTO();
        dto.setP_id_type_rapport(1L);
        dto.setP_date_echeance(LocalDate.of(2024, 12, 31));
        dto.setP_id_langue(2L);
        dto.setP_id_maquettiste(3L);
        dto.setP_id_gabarit(34L);
        dto.setP_id_createur(5L);
        dto.setP_id_suivi(null);
        dto.setP_id("104003");
        dto.setP_id_unit_code("PART");
        dto.setP_date_echeance_exacte("2024-12-31");

        when(suiviDao.insertSuivi(any(Suivi.class))).thenReturn(100L);

        Long result = business.insertSuivi(dto);

        assertEquals(100L, result);
        verify(suiviDao, times(1)).insertSuivi(any(Suivi.class));
    }

    @Test
    void insertSuivi_withNullUnitCode_stillCallsDao() {
        SuiviDTO dto = new SuiviDTO();
        dto.setP_id_type_rapport(1L);
        dto.setP_date_echeance(LocalDate.of(2024, 6, 30));
        dto.setP_id_langue(1L);
        dto.setP_id("FND01");
        dto.setP_id_unit_code(null);

        when(suiviDao.insertSuivi(any(Suivi.class))).thenReturn(55L);

        Long result = business.insertSuivi(dto);

        assertEquals(55L, result);
        verify(suiviDao).insertSuivi(any(Suivi.class));
    }
}

