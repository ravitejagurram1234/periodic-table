package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Langue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.LangueDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class LangueBusinessTest {

    @InjectMocks
    private LangueBusiness langueBusiness;

    @Mock
    private LangueDao langueDao;

    @Test
    public void testGetLangue_returnsLangueList() {

        List<Langue> mockLangueList = java.util.stream.IntStream.rangeClosed(1, 5)
                .mapToObj(i -> Langue.builder().id((long) i).nomLangue("LAN" + i).build())
                .toList();

        when(langueDao.getLangue()).thenReturn(mockLangueList);
        List<Langue> result = langueBusiness.getLangue();
        assertNotNull(result, "Result should not be null");
        assertEquals(5, result.size(), "Size should be 5");
        assertEquals("LAN1", result.get(0).getNomLangue(), "First item should match");
        verify(langueDao, times(1)).getLangue();
    }
}

