package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class portefeuilleTest {

    @Test
    public void testNoArgsConstructor() {
        portefeuille p = new portefeuille();
        assertNotNull(p);
        assertNull(p.getId_fnd_code());
        assertNull(p.getDescription());
    }

    @Test
    public void testAllArgsConstructor() {
        portefeuille p = new portefeuille("FND001", "Description of fund");
        assertEquals("FND001", p.getId_fnd_code());
        assertEquals("Description of fund", p.getDescription());
    }

    @Test
    public void testGettersAndSetters() {
        portefeuille p = new portefeuille();

        p.setId_fnd_code("FND002");
        assertEquals("FND002", p.getId_fnd_code());

        p.setDescription("Another description");
        assertEquals("Another description", p.getDescription());
    }
}

