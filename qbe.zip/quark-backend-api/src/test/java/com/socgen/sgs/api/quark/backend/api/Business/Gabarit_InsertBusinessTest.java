package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.Gabarit_InsertDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class Gabarit_InsertBusinessTest {

    @Mock
    private Gabarit_InsertDao gabaritInsertDao;

    @InjectMocks
    private Gabarit_InsertBusiness gabarit_InsertBusiness;

    @Test
    void insertGabarit_delegatesToDaoAndReturnsResult() {
        Chargement_gabarit gabarit = new Chargement_gabarit();
        gabarit.setNom_gabarit("GabaritTest");
        when(gabaritInsertDao.insertGabarit(gabarit)).thenReturn(1);

        Integer result = gabarit_InsertBusiness.insertGabarit(gabarit);

        assertEquals(1, result);
        verify(gabaritInsertDao, times(1)).insertGabarit(gabarit);
    }

    @Test
    void insertGabarit_returnsZeroOnFailure() {
        Chargement_gabarit gabarit = new Chargement_gabarit();
        when(gabaritInsertDao.insertGabarit(gabarit)).thenReturn(0);

        Integer result = gabarit_InsertBusiness.insertGabarit(gabarit);

        assertEquals(0, result);
        verify(gabaritInsertDao).insertGabarit(gabarit);
    }
}

