package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateParSocieteDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UpdateParSocieteBusinessTest {

    @Mock
    private UpdateParSocieteDao updateParSocieteDao;

    @InjectMocks
    private UpdateParSocieteBusiness updateParSocieteBusiness;

    @Test
    void updateParSociete_delegatesToDao() {
        Document document = new Document();
        document.setP_societe("SOC1");
        document.setP_id_fnd_code("FND001");

        doNothing().when(updateParSocieteDao).updateParSociete(document);

        updateParSocieteBusiness.updateParSociete(document);

        verify(updateParSocieteDao, times(1)).updateParSociete(document);
    }

    @Test
    void updateParSociete_withEmptyDocument_doesNotThrow() {
        Document document = new Document();

        doNothing().when(updateParSocieteDao).updateParSociete(document);

        updateParSocieteBusiness.updateParSociete(document);

        verify(updateParSocieteDao).updateParSociete(document);
    }
}

