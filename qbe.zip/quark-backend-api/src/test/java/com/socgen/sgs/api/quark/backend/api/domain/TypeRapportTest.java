package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TypeRapportTest {

    @Test
    public void testNoArgsConstructor() {
        TypeRapport typeRapport = new TypeRapport();
        assertNotNull(typeRapport);
        assertNull(typeRapport.getId());
        assertNull(typeRapport.getLibelle());
    }

    @Test
    public void testAllArgsConstructor() {
        TypeRapport typeRapport = new TypeRapport(1L, "Rapport Annuel");
        assertEquals(1L, typeRapport.getId());
        assertEquals("Rapport Annuel", typeRapport.getLibelle());
    }

    @Test
    public void testGettersAndSetters() {
        TypeRapport typeRapport = new TypeRapport();

        typeRapport.setId(5L);
        assertEquals(5L, typeRapport.getId());

        typeRapport.setLibelle("Rapport Semestriel");
        assertEquals("Rapport Semestriel", typeRapport.getLibelle());
    }

    @Test
    public void testBuilderPattern() {
        TypeRapport typeRapport = TypeRapport.builder()
                .id(2L)
                .libelle("Rapport Trimestriel")
                .build();

        assertNotNull(typeRapport);
        assertEquals(2L, typeRapport.getId());
        assertEquals("Rapport Trimestriel", typeRapport.getLibelle());
    }

    @Test
    public void testBuilderDefaultValues() {
        TypeRapport typeRapport = TypeRapport.builder().build();
        assertNotNull(typeRapport);
        assertNull(typeRapport.getId());
        assertNull(typeRapport.getLibelle());
    }

    @Test
    public void testBuilderFluentApi() {
        TypeRapport.Builder builder = TypeRapport.builder();
        assertNotNull(builder.id(10L));
        assertNotNull(builder.libelle("Libelle"));
        TypeRapport built = builder.build();
        assertEquals(10L, built.getId());
        assertEquals("Libelle", built.getLibelle());
    }
}

