package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PortfolioSelectedDao;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.GabaritRepository;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PortfolioSelectedBusinessTest {

    @InjectMocks
    private PortfolioSelectedBusiness business;

    @Mock
    private PortfolioSelectedDao portfolioSelectedDao;

    @Mock
    private GabaritRepository gabaritRepository;

    // ─── Validation guards ────────────────────────────────────────────────────

    @Test
    void throws_when_p_idTypeRapport_is_null() {
        assertThrows(IllegalArgumentException.class, () ->
                business.getSelectedPortfolios(null, 1L, 1L, null, null, null));
    }

    @Test
    void throws_when_p_idGabarit_is_null() {
        assertThrows(IllegalArgumentException.class, () ->
                business.getSelectedPortfolios(1L, null, 1L, null, null, null));
    }

    @Test
    void throws_when_p_idLangue_is_null() {
        assertThrows(IllegalArgumentException.class, () ->
                business.getSelectedPortfolios(1L, 1L, null, null, null, null));
    }

    @Test
    void throws_when_gabarit_not_found() {
        when(gabaritRepository.findByGabaritId(99L)).thenReturn(null);
        assertThrows(IllegalArgumentException.class, () ->
                business.getSelectedPortfolios(1L, 99L, 1L, null, null, null));
    }

    @Test
    void throws_when_gabarit_type_is_null() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType(null);
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);
        assertThrows(IllegalArgumentException.class, () ->
                business.getSelectedPortfolios(1L, 10L, 1L, null, null, null));
    }

    @Test
    void throws_for_unsupported_type_gabarit() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("99");
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);
        assertThrows(IllegalArgumentException.class, () ->
                business.getSelectedPortfolios(1L, 10L, 1L, null, null, null));
    }

    // ─── RapportCompartiment (p_idTypeRapport == 4) ───────────────────────────

    @Test
    void returns_compartiments_when_p_idTypeRapport_is_4() {
        List<portefeuilleDTO> compartiments = List.of(new portefeuilleDTO("COMP1", "Compartiment 1"));
        when(portfolioSelectedDao.getListeCompartsByGabarit(4L, 10L, 160L))
                .thenReturn(compartiments);

        List<portefeuilleDTO> result = business.getSelectedPortfolios(4L, 10L, 160L, null, null, null);

        assertEquals(compartiments, result);
        verify(portfolioSelectedDao).getListeCompartsByGabarit(4L, 10L, 160L);
        verifyNoInteractions(gabaritRepository);
    }

    @Test
    void rapport_compartiment_ignores_gabarit_type_resolution() {
        when(portfolioSelectedDao.getListeCompartsByGabarit(any(), any(), any()))
                .thenReturn(List.of());

        assertDoesNotThrow(() -> business.getSelectedPortfolios(4L, 1L, 1L, null, null, null));
        verifyNoInteractions(gabaritRepository);
    }

    // ─── Fonds (typeGabarit == 0) ─────────────────────────────────────────────

    @Test
    void returns_fonds_when_typeGabarit_is_0() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("0");
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);

        List<portefeuilleDTO> fonds = List.of(new portefeuilleDTO("FND001", "Fund 1"));
        when(portfolioSelectedDao.getFondsSimplesByGabarit(1L, 10L, 160L, "AUD", "ACC", "FMC"))
                .thenReturn(fonds);

        List<portefeuilleDTO> result = business.getSelectedPortfolios(1L, 10L, 160L, "AUD", "ACC", "FMC");

        assertEquals(fonds, result);
        verify(portfolioSelectedDao).getFondsSimplesByGabarit(1L, 10L, 160L, "AUD", "ACC", "FMC");
    }

    // ─── FondsPart (typeGabarit == 2) ─────────────────────────────────────────

    @Test
    void returns_fonds_when_typeGabarit_is_2() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("2");
        when(gabaritRepository.findByGabaritId(5L)).thenReturn(gabarit);

        List<portefeuilleDTO> fonds = List.of(new portefeuilleDTO("FND002", "Fund Part 2"));
        when(portfolioSelectedDao.getFondsSimplesByGabarit(1L, 5L, 160L, null, null, null))
                .thenReturn(fonds);

        List<portefeuilleDTO> result = business.getSelectedPortfolios(1L, 5L, 160L, null, null, null);

        assertEquals(fonds, result);
        verify(portfolioSelectedDao).getFondsSimplesByGabarit(1L, 5L, 160L, null, null, null);
    }

    // ─── Structure (typeGabarit == 1) ─────────────────────────────────────────

    @Test
    void returns_structures_when_typeGabarit_is_1() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("1");
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);

        List<portefeuilleDTO> structures = List.of(new portefeuilleDTO("STR001", "Structure 1"));
        when(portfolioSelectedDao.getListeStructuresByGabarit(1L, 10L, 160L, "AUD", "ACC", "FMC"))
                .thenReturn(structures);

        List<portefeuilleDTO> result = business.getSelectedPortfolios(1L, 10L, 160L, "AUD", "ACC", "FMC");

        assertEquals(structures, result);
        verify(portfolioSelectedDao).getListeStructuresByGabarit(1L, 10L, 160L, "AUD", "ACC", "FMC");
    }

    @Test
    void returns_empty_list_for_structures() {
        QxpGabarit gabarit = new QxpGabarit(); gabarit.setType("1");
        when(gabaritRepository.findByGabaritId(10L)).thenReturn(gabarit);
        when(portfolioSelectedDao.getListeStructuresByGabarit(any(), any(), any(), any(), any(), any()))
                .thenReturn(List.of());

        List<portefeuilleDTO> result = business.getSelectedPortfolios(1L, 10L, 1L, null, null, null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}
