package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LangueTest {

    @Test
    public void testNoArgsConstructor() {
        Langue langue = new Langue();
        assertNotNull(langue);
        assertNull(langue.getId());
        assertNull(langue.getNomLangue());
        assertNull(langue.getValeur_langue());
    }

    @Test
    public void testAllArgsConstructor() {
        Langue langue = new Langue(1L, "Français", "FR");
        assertEquals(1L, langue.getId());
        assertEquals("Français", langue.getNomLangue());
        assertEquals("FR", langue.getValeur_langue());
    }

    @Test
    public void testGettersAndSetters() {
        Langue langue = new Langue();

        langue.setId(2L);
        assertEquals(2L, langue.getId());

        langue.setNomLangue("English");
        assertEquals("English", langue.getNomLangue());

        langue.setValeur_langue("EN");
        assertEquals("EN", langue.getValeur_langue());
    }

    @Test
    public void testBuilderPattern() {
        Langue langue = Langue.builder()
                .id(3L)
                .nomLangue("Deutsch")
                .valeur_langue("DE")
                .build();

        assertNotNull(langue);
        assertEquals(3L, langue.getId());
        assertEquals("Deutsch", langue.getNomLangue());
        assertEquals("DE", langue.getValeur_langue());
    }

    @Test
    public void testBuilderDefaultValues() {
        Langue langue = Langue.builder().build();
        assertNotNull(langue);
        assertNull(langue.getId());
        assertNull(langue.getNomLangue());
        assertNull(langue.getValeur_langue());
    }

    @Test
    public void testBuilderFluentApi() {
        Langue.Builder builder = Langue.builder();
        assertNotNull(builder.id(1L));
        assertNotNull(builder.nomLangue("FR"));
        assertNotNull(builder.valeur_langue("FR"));
    }
}

