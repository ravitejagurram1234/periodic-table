package com.socgen.sgs.api.quark.backend.api.domain;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class SuiviTest {

    @Test
    public void testNoArgsConstructor() {
        Suivi suivi = new Suivi();
        assertNotNull(suivi);
        assertNull(suivi.getP_id_type_rapport());
        assertNull(suivi.getP_id_langue());
    }

    @Test
    public void testAllArgsConstructor() {
        LocalDate date = LocalDate.of(2024, 6, 15);
        Suivi suivi = new Suivi(1L, date, 2L, 3L, 4L, 5L, 6L, "FND001", "UNIT001", "2024-06-15");

        assertEquals(1L, suivi.getP_id_type_rapport());
        assertEquals(date, suivi.getP_date_echeance());
        assertEquals(2L, suivi.getP_id_langue());
        assertEquals(3L, suivi.getP_id_maquettiste());
        assertEquals(4L, suivi.getP_id_gabarit());
        assertEquals(5L, suivi.getP_id_createur());
        assertEquals(6L, suivi.getP_id_suivi());
        assertEquals("FND001", suivi.getP_id());
        assertEquals("UNIT001", suivi.getP_id_unit_code());
        assertEquals("2024-06-15", suivi.getP_date_echeance_exacte());
    }

    @Test
    public void testGettersAndSetters() {
        Suivi suivi = new Suivi();
        LocalDate date = LocalDate.now();

        suivi.setP_id_type_rapport(10L);
        assertEquals(10L, suivi.getP_id_type_rapport());

        suivi.setP_date_echeance(date);
        assertEquals(date, suivi.getP_date_echeance());

        suivi.setP_id_langue(20L);
        assertEquals(20L, suivi.getP_id_langue());

        suivi.setP_id_maquettiste(30L);
        assertEquals(30L, suivi.getP_id_maquettiste());

        suivi.setP_id_gabarit(40L);
        assertEquals(40L, suivi.getP_id_gabarit());

        suivi.setP_id_createur(50L);
        assertEquals(50L, suivi.getP_id_createur());

        suivi.setP_id_suivi(60L);
        assertEquals(60L, suivi.getP_id_suivi());

        suivi.setP_id("FND002");
        assertEquals("FND002", suivi.getP_id());

        suivi.setP_id_unit_code("UNIT002");
        assertEquals("UNIT002", suivi.getP_id_unit_code());

        suivi.setP_date_echeance_exacte("2025-01-01");
        assertEquals("2025-01-01", suivi.getP_date_echeance_exacte());
    }

    @Test
    public void testBuilderPattern() {
        LocalDate date = LocalDate.of(2025, 3, 1);
        Suivi suivi = Suivi.builder()
                .p_id_type_rapport(1L)
                .p_date_echeance(date)
                .p_id_langue(2L)
                .p_id_maquettiste(3L)
                .p_id_gabarit(4L)
                .p_id_createur(5L)
                .p_id_suivi(6L)
                .p_id("FND_BUILDER")
                .p_id_unit_code("UNIT_BUILDER")
                .p_date_echeance_exacte("2025-03-01")
                .build();

        assertNotNull(suivi);
        assertEquals(1L, suivi.getP_id_type_rapport());
        assertEquals(date, suivi.getP_date_echeance());
        assertEquals(2L, suivi.getP_id_langue());
        assertEquals(3L, suivi.getP_id_maquettiste());
        assertEquals(4L, suivi.getP_id_gabarit());
        assertEquals(5L, suivi.getP_id_createur());
        assertEquals(6L, suivi.getP_id_suivi());
        assertEquals("FND_BUILDER", suivi.getP_id());
        assertEquals("UNIT_BUILDER", suivi.getP_id_unit_code());
        assertEquals("2025-03-01", suivi.getP_date_echeance_exacte());
    }

    @Test
    public void testBuilderDefaultValues() {
        Suivi suivi = Suivi.builder().build();
        assertNotNull(suivi);
        assertNull(suivi.getP_id_type_rapport());
        assertNull(suivi.getP_id());
    }
}

