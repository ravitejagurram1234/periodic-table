package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateUpdateDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class UpdateGabaritTemplateBusiness {

    @Autowired
    private GabaritTemplateUpdateDao gabaritTemplateUpdateDao;

    public void updateGabaritTemplate(Chargement_gabarit gabarit) {
        gabaritTemplateUpdateDao.updateGabaritTemplate(gabarit);
    }
}
