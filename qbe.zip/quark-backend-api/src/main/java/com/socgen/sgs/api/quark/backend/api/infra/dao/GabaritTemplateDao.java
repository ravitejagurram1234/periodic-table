package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;

import java.util.List;

public interface GabaritTemplateDao {
    List<GabaritTemplate> getTemplates();

//    GabaritTemplate getGabaritTemplate(int p_idGabaritTemplate);
}
