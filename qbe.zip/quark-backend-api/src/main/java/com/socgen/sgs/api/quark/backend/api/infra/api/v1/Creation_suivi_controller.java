package com.socgen.sgs.api.quark.backend.api.infra.api.v1;

import com.socgen.apibank.http.ratelimiter.RateLimiter;
import com.socgen.sgs.api.quark.backend.api.Business.PrevSuiviBusiness;
import com.socgen.sgs.api.quark.backend.api.Dto.*;
import com.socgen.sgs.api.quark.backend.api.Mapper.*;
import com.socgen.sgs.api.quark.backend.api.domain.*;
import com.socgen.sgs.api.quark.backend.api.service.*;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.Problem;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_PROBLEM_JSON_VALUE;
import static org.springframework.http.ResponseEntity.ok;



@RestController
@RequestMapping(value = "/api/v1/")
public class Creation_suivi_controller {


    private static final String QUOTA_EXCEEDED_EXAMPLE = "";

    @Autowired
    private LangueSerInterface service;
    @GetMapping("/Langue")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<LangueDTO>>getLangue() {

        List<Langue> activity = service.getLangue();
        List<LangueDTO>dtoList=activity.stream().map(LangueMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private TypeRapportSerInterface type;

    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")

    @Operation(summary = "Generate Kpi Report", description = "Kpi Report", security = @SecurityRequirement(name = "sgconnect", scopes = { "api.ast-link-app.v1", "api.fund-status-view.v1" }))

    @ApiResponses({

            @ApiResponse(responseCode = "200", description = "Success"),

            @ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", examples = @ExampleObject("""

             {

               "data": {},

               "errorDetail": "One or more parameters are missing, unknown or not correctly provided"

             }\

             """))),

            @ApiResponse(responseCode = "401", description = "No authentication", content = @Content(mediaType = "application/json", examples = @ExampleObject("""

             {

               "data": {},

               "errorDetail": "Please provide full authentication information"

             }\

             """))),

            @ApiResponse(responseCode = "403", description = "Bad authentication", content = @Content(mediaType = "application/json", examples = @ExampleObject("""

             {

               "data": {},

               "errorDetail": "Your token is not valid"

             }\

             """))),

            @ApiResponse(responseCode = "404", description = "Input Data issue", content = @Content(mediaType = "application/json", examples = @ExampleObject("""

             {

               "data": {},

               "errorDetail": "No Data exists for "

             }\

             """))),

            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", examples = @ExampleObject("""

             {

               "data": {},

               "errorDetail": "Internal API error / Server error. Please report it to team"

             }\

             """))) })


    @GetMapping("/TypeRapport")
//    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeRapportDTO>>getTypeRapport() {

        List<TypeRapport> rapports = type.getTypeRapport();
        List<TypeRapportDTO>dtoList=rapports.stream().map(TypeRapportMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }


    @Autowired
    private MaquettisteSerInterface maq;

    @GetMapping("/Maquettiste")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<MaquettisteDTO>> getMaquettiste() {

        List<Maquettiste> activity = maq.getMaquettiste();
        List<MaquettisteDTO> dtoList = activity.stream().map(MaquettisteMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private GabaritsSerInterface gab;

    @GetMapping("/Gabarits")
//    @Operation(description = "Get Service activity information", summary = "Fetch Services(L1,L2,L3) activity details", security = @SecurityRequirement(name = "sgconnect", scopes = {
//            "profile", "api.sgss-product-catalog.v1"}))
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<GabaritsDTO>> getGabarits(@RequestParam Long p_idTypeRapport, @RequestParam Long p_idLangue, @RequestParam int p_onlyActive) {

        List<Gabarits> gabarits = gab.getGabarits(p_idTypeRapport, p_idLangue, p_onlyActive);
        List<GabaritsDTO> dtoList = gabarits.stream().map(GabaritsMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private FondsSerInterface fondsService;

    @GetMapping("/ListeFondsForNewSuivi")
    public ResponseEntity<List<FondsDTO>> getListeFondsForNewSuivi(
            @RequestParam Long p_idTypeRapport,
            @RequestParam Long p_idLangue,
            @RequestParam Long p_idGabarit,
            @RequestParam @DateTimeFormat(iso= DateTimeFormat.ISO.DATE)LocalDate p_dateEcheance) {

        List<Fonds> fonds = fondsService.getListeFondsForNewSuivi(p_idTypeRapport, p_idLangue, p_idGabarit, p_dateEcheance);
        List<FondsDTO> dtoList =fonds.stream().map(FondsMapper::toDto).toList();
        return ResponseEntity.ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }


    @Autowired
    private StructureSerInterface structureSerInterface;

    @GetMapping("/Structures")
    public ResponseEntity<List<StructureDTO>> getListeStructures(
            @RequestParam Long p_idTypeRapport,
            @RequestParam Long p_idLangue,
            @RequestParam Long p_idGabarit,
            @RequestParam @DateTimeFormat(iso= DateTimeFormat.ISO.DATE)LocalDate p_dateEcheance) {

        List<Structure> structures = structureSerInterface.getListeStructuresForNewSuivi(p_idTypeRapport, p_idLangue, p_idGabarit, p_dateEcheance);
        List<StructureDTO> dtoList =structures.stream().map(StructureMapper::toDto).toList();
        return ResponseEntity.ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private FundMgtCompanySerInterface fund;

    @GetMapping("/FundMgtCompany")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<FundMgtCompanyDTO>> getFundMgtCompany() {

        List<FundMgtCompany> funds = fund.getListFundMgtCompanies();
        List<FundMgtCompanyDTO> dtoList = funds.stream().map(FundMgtCompanyMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }


    @Autowired
    private AccountantsSerInterface accountant;
    @GetMapping("/Accountants")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<AccountantsDTO>> getAccountants() {

        List<Accountants> accountants = accountant.getListAccountants();
        List<AccountantsDTO> dtoList = accountants.stream().map(AccountantsMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private AuditorsSerInterface auditor;
    @GetMapping("/Auditors")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<AuditorDTO>> getAuditors() {

        List<Auditor> auditors = auditor.getListAuditors();
        List<AuditorDTO> dtoList = auditors.stream().map(AuditorMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }


    @Autowired
    private ValiderSerInterface validerSerInterface;
    @GetMapping("/Valider")
    public ResponseEntity<ValiderDTO>Valider(
            @RequestParam Long p_idTypeRapport,
            @RequestParam Long p_idLangue,
            @RequestParam Long p_idGabarit,
//            @RequestParam Long p_typeGabarit,
            @RequestParam @DateTimeFormat(iso= DateTimeFormat.ISO.DATE) LocalDate p_dateEcheance,
            @RequestParam String p_portefeuilles,
            @RequestParam (required = false)String p_auditor,
            @RequestParam (required = false)String p_accountant,
            @RequestParam (required = false)String p_fundMgtCompany){

        ValiderDTO suivis= validerSerInterface.getSuivis( p_idTypeRapport, p_idLangue, p_idGabarit, p_dateEcheance, p_portefeuilles,  p_auditor, p_accountant,  p_fundMgtCompany);
        return ResponseEntity.ok().cacheControl(CacheControl.noCache()).body(suivis);
    }


    @Autowired
    private GabaritEventSerInterface gabaritEventSerInterface;

    @GetMapping("/gabaritEvents")
    public ResponseEntity<List<GabaritEventsDTO>>gabEvents(
            @RequestParam Long p_idGabarit
    ){

        List<GabaritEvents> fonds =gabaritEventSerInterface.getGabaritEvent(p_idGabarit);
        List<GabaritEventsDTO> dtoList =fonds.stream().map(GabaritEventMapper::toDto).toList();
        return ResponseEntity.ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private SuiviEventsSerInterface suiviEventsSerInterface;

    @GetMapping("/SuiviEvents")
    public ResponseEntity<List<SuiviEventsDTO>>suiviEvents(
            @RequestParam Long p_idSuivi
    ){

        List<SuiviEvents> fonds =suiviEventsSerInterface.getSuiviEvents(p_idSuivi);
        List<SuiviEventsDTO> dtoList =fonds.stream().map(SuiviEventsMapper::toDto).toList();
        return ResponseEntity.ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private InsertSuiviSerInterface serInterface;


    @PostMapping("/insert")
    public ResponseEntity<String> insertSuivi(@RequestBody List<SuiviDTO> suivis, HttpServletRequest request, @RequestParam Long p_idUser) {

       for(SuiviDTO suivi : suivis) {
           Long id = serInterface.insertSuivi(suivi);
           if (id != null && id != 0) {
               serInterface.InsertEvent(suivi,id,p_idUser);
               Long audit_id = serInterface.InsertTrace(suivi, request);
           }
       }
        return ResponseEntity.ok("success");
    }

    @Autowired
    private PrevSuiviBusiness prevSuiviBusiness;
    @GetMapping("/prev")
    public ResponseEntity<List<PrevSuiviEvents>>prevSuivi(
            @RequestParam  String p_id, @RequestParam(required = false) String p_id_unit_code, @RequestParam Long p_id_type_rapport,@RequestParam Long p_id_langue,
            @RequestParam @DateTimeFormat(iso= DateTimeFormat.ISO.DATE)LocalDate p_date_echeance,@RequestParam Long p_id_gabarit
    ){

        List<PrevSuiviEvents> fonds =prevSuiviBusiness.getSuiviEvents(p_id, p_id_unit_code,  p_id_type_rapport, p_id_langue,  p_date_echeance,  p_id_gabarit);

        return ResponseEntity.ok().cacheControl(CacheControl.noCache()).body(fonds);
    }
}