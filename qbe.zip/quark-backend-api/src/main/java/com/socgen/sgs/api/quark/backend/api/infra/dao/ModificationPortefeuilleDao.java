package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;

import java.util.List;

public interface ModificationPortefeuilleDao {
    List<portefeuille> getListPortefeuille(int p_id_sous_categorie);
}
