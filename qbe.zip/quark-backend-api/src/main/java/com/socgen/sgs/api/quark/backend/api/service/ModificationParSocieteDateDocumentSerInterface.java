package com.socgen.sgs.api.quark.backend.api.service;

import java.time.LocalDate;
import java.util.List;

public interface ModificationParSocieteDateDocumentSerInterface {
    List<LocalDate> getDateDocuments(String p_societe , int p_id_sous_categorie);
}
