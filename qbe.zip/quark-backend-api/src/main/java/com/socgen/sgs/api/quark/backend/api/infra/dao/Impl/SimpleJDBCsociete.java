package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.SocieteMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.portefeuilleMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Societe;
import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SocieteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCsociete implements SocieteDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCsociete(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeSociete")
                .declareParameters(
                        new SqlOutParameter("RETURN", oracle.jdbc.OracleTypes.CURSOR, (rs, rowNum) -> SocieteMapper.mapResult(rs))
                );
    }

    @Override
    public List<Societe> getSociete() {
        Map<String, Object> result = simpleJdbcCall.execute();
        return (List<Societe>) result.get("RETURN");
    }
}
