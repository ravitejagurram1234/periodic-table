package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.PrevSuiviEventsMapper;
import com.socgen.sgs.api.quark.backend.api.domain.PrevSuiviEvents;
import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PrevSuiviDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCPrevSuivi implements PrevSuiviDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCPrevSuivi(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetSelectedEventsByPrevSuivi")
                .declareParameters(
                        new SqlOutParameter("RETURN", oracle.jdbc.OracleTypes.CURSOR, (rs, rowNum) -> PrevSuiviEventsMapper.mapResult(rs)),
                        new SqlParameter("p_id", Types.VARCHAR),
                        new SqlParameter("p_id_unit_code", Types.VARCHAR),
                        new SqlParameter("p_id_type_rapport", Types.NUMERIC),
                        new SqlParameter("p_id_langue", Types.NUMERIC),
                        new SqlParameter("p_date_echeance", Types.DATE),
                        new SqlParameter("p_id_gabarit", Types.NUMERIC)
                );
    }

    @Override
    public List<PrevSuiviEvents> getPrevSuiviEvents(String p_id, String p_id_unit_code, Long p_id_type_rapport, Long p_id_langue, LocalDate p_date_echeance, Long p_id_gabarit) {
        java.sql.Date sqlDate=java.sql.Date.valueOf(p_date_echeance);
        Map<String, Object> params = new HashMap<>();
                params.put( "p_id", p_id);
                params.put( "p_id_unit_code", (p_id_unit_code == null || p_id_unit_code.isEmpty()) ? null : p_id_unit_code);
                params.put( "p_id_type_rapport", p_id_type_rapport);
                params.put( "p_id_langue", p_id_langue);
                params.put( "p_date_echeance",sqlDate);
                params.put( "p_id_gabarit", p_id_gabarit);


        Map<String, Object> result = simpleJdbcCall.execute(params);
        return (List<PrevSuiviEvents>) result.get("RETURN");
    }
}
