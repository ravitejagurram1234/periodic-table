package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationParFondsDocumentBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsDocument;
import com.socgen.sgs.api.quark.backend.api.domain.R_DOMAIN;
import com.socgen.sgs.api.quark.backend.api.service.ModificationParFondsDocumentSerInterfce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Service
public class ModificationParFondsDocumentService implements ModificationParFondsDocumentSerInterfce {
  @Autowired
  private ModificationParFondsDocumentBusiness modificationParFondsDocumentBusiness;

  public List<ModificationParFondsDocument> getDocumentName(String p_id_fnd_code, String p_id_unit_code, int p_id_sous_categorie, int p_id_langue, LocalDate p_date_document){
    return modificationParFondsDocumentBusiness.getDocumentName(p_id_fnd_code,p_id_unit_code,p_id_sous_categorie,p_id_langue,p_date_document);
  }

    }
