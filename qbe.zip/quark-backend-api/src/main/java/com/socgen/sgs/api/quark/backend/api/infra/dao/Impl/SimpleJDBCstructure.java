package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.StructureMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureDao;
import oracle.jdbc.OracleTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class SimpleJDBCstructure implements StructureDao {

    private static final Logger log = LoggerFactory.getLogger(SimpleJDBCstructure.class);

    private final SimpleJdbcCall simpleJdbcCallForNewSuivi;
    private final SimpleJdbcCall simpleJdbcCallGetListeStructures;
    private final SimpleJdbcCall simpleJdbcCallGetStructure;

    @Autowired
    public SimpleJDBCstructure(DataSource dataSource) {
        this.simpleJdbcCallForNewSuivi = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeStructuresForNewSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> StructureMapper.mapResult(rs)),
                        new SqlParameter("p_idTypeRapport", Types.NUMERIC),
                        new SqlParameter("p_idLangue", Types.NUMERIC),
                        new SqlParameter("p_idGabarit", Types.NUMERIC),
                        new SqlParameter("p_dateEcheance", Types.DATE)
                );

        this.simpleJdbcCallGetListeStructures = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withFunctionName("GetListeStructures")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> StructureMapper.mapResult(rs)),
                        new SqlParameter("p_withAtLeastOneCompatiment", Types.NUMERIC),
                        new SqlParameter("p_auditor", Types.VARCHAR),
                        new SqlParameter("p_accountant", Types.VARCHAR),
                        new SqlParameter("p_fundMgtCompany", Types.VARCHAR)
                );

        this.simpleJdbcCallGetStructure = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withFunctionName("GetStructure")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> StructureMapper.mapResult(rs)),
                        new SqlParameter("p_idStructure", Types.VARCHAR)
                );
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Structure> getListeStructuresForNewSuivi(
            Long p_idTypeRapport,
            Long p_idLangue,
            Long p_idGabarit,
            LocalDate p_dateEcheance
    ) {
        java.sql.Date sqlDate = java.sql.Date.valueOf(p_dateEcheance);

        Map<String, Object> params = Map.of(
                "p_idTypeRapport", p_idTypeRapport,
                "p_idLangue", p_idLangue,
                "p_idGabarit", p_idGabarit,
                "p_dateEcheance", sqlDate
        );

        try {
            Map<String, Object> result = simpleJdbcCallForNewSuivi.execute(params);
            return (List<Structure>) result.get("RETURN_VALUE");
        } catch (Exception e) {
            log.error("Error during GetListeStructuresForNewSuivi JDBC call: {}", e.getMessage(), e);
            return Collections.emptyList();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Structure> getListeStructures(String p_auditor, String p_accountant, String p_fundMgtCompany) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_withAtLeastOneCompatiment", 0);
        params.put("p_auditor", normalize(p_auditor));
        params.put("p_accountant", normalize(p_accountant));
        params.put("p_fundMgtCompany", normalize(p_fundMgtCompany));

        try {
            Map<String, Object> result = simpleJdbcCallGetListeStructures.execute(params);
            return (List<Structure>) result.get("RETURN_VALUE");
        } catch (Exception e) {
            log.error("Error during GetListeStructures JDBC call: {}", e.getMessage(), e);
            return Collections.emptyList();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public Optional<Structure> getStructureById(String idStructure) {
        try {
            Map<String, Object> result = simpleJdbcCallGetStructure.execute(
                    Map.of("p_idStructure", idStructure)
            );
            List<Structure> rows = (List<Structure>) result.get("RETURN_VALUE");
            return (rows == null || rows.isEmpty()) ? Optional.empty() : Optional.of(rows.get(0));
        } catch (Exception e) {
            log.error("Error during GetStructure JDBC call: {}", e.getMessage(), e);
            return Optional.empty();
        }
    }

    private String normalize(String value) {
        return value != null ? value : "";
    }
}
