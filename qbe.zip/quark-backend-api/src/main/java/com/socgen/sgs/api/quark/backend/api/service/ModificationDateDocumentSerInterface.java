package com.socgen.sgs.api.quark.backend.api.service;

import java.time.LocalDate;
import java.util.List;

public interface ModificationDateDocumentSerInterface {
    List<LocalDate> getDateDocuments(int p_id_sous_categorie, String p_id_fnd_code, String p_id_unit_code);

}
