package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.TypeDeDocumentBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.service.TypeDeDocumentSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TypeDeDocumentService implements TypeDeDocumentSerInterface {
    @Autowired
    private TypeDeDocumentBusiness typeDeDocumentBusiness;

    public List<TypeDeDocument> getTypeDocument(String p_id_fnd_code, Long p_typeCategorieDocument) {
        return typeDeDocumentBusiness.getTypeDocument(p_id_fnd_code, p_typeCategorieDocument);
    }
}
