package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateInsertDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCgabaritTemplateInsert implements GabaritTemplateInsertDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public  SimpleJDBCgabaritTemplateInsert(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("InsertGabaritTemplate")
                .declareParameters(
                        new SqlParameter("p_nom_gabarit_template", Types.VARCHAR),
                        new SqlParameter("p_contenu", Types.VARBINARY),
                        new SqlParameter("p_commentaire", Types.VARCHAR)

                );
    }

    public Integer insertGabaritTemplate(Chargement_gabarit gabarit) {
        Map<String,Object> params = new HashMap<>();

        params.put("p_nom_gabarit_template", gabarit.getP_nom_gabarit_template());
        params.put("p_contenu", gabarit.getP_contenu());
        params.put("p_commentaire", gabarit.getP_commentaire());

        Number result = simpleJdbcCall.executeFunction(Number.class, params);

        return result != null ? result.intValue() : null;
    }
}
