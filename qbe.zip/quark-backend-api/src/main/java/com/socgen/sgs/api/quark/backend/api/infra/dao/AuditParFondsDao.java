package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;

public interface AuditParFondsDao {
    Integer insertAudit(Audit audit);
}
