package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Suivi;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class SuiviMapper {
    public static Suivi toDomain(SuiviDTO dto){
        return Suivi.builder()
                .p_id_type_rapport(dto.getP_id_type_rapport())
                .p_date_echeance(dto.getP_date_echeance())
                .p_id_langue(dto.getP_id_langue())
                .p_id_maquettiste(dto.getP_id_maquettiste())
                . p_id_gabarit(dto.getP_id_gabarit())
                .p_id_createur(dto.getP_id_createur())
                .p_id_suivi(dto.getP_id_suivi())
                .p_id(dto.getP_id())
                .p_id_unit_code(dto.getP_id_unit_code())
                .p_date_echeance_exacte(dto.getP_date_echeance_exacte())
                .build();
    }
}


