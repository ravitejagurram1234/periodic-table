package com.socgen.sgs.api.quark.backend.api.domain;

public class PrevSuiviEvents {

    private Long id_event;
    private Long id_statut_suivi;
    private String libelle;
    private Long show_on_eos;
    private String traduction_code;
    private String type;
    private Long event_type;
    private Long mandatory;

    public PrevSuiviEvents() {}

    public PrevSuiviEvents(Long id_event, Long id_statut_suivi, String libelle, Long show_on_eos,
                           String traduction_code, String type, Long event_type, Long mandatory) {
        this.id_event = id_event;
        this.id_statut_suivi = id_statut_suivi;
        this.libelle = libelle;
        this.show_on_eos = show_on_eos;
        this.traduction_code = traduction_code;
        this.type = type;
        this.event_type = event_type;
        this.mandatory = mandatory;
    }

    public Long getId_event()               { return id_event; }
    public void setId_event(Long id_event)  { this.id_event = id_event; }

    public Long getId_statut_suivi()                       { return id_statut_suivi; }
    public void setId_statut_suivi(Long id_statut_suivi)   { this.id_statut_suivi = id_statut_suivi; }

    public String getLibelle()              { return libelle; }
    public void setLibelle(String libelle)  { this.libelle = libelle; }

    public Long getShow_on_eos()                   { return show_on_eos; }
    public void setShow_on_eos(Long show_on_eos)   { this.show_on_eos = show_on_eos; }

    public String getTraduction_code()                     { return traduction_code; }
    public void setTraduction_code(String traduction_code) { this.traduction_code = traduction_code; }

    public String getType()             { return type; }
    public void setType(String type)    { this.type = type; }

    public Long getEvent_type()                  { return event_type; }
    public void setEvent_type(Long event_type)   { this.event_type = event_type; }

    public Long getMandatory()                 { return mandatory; }
    public void setMandatory(Long mandatory)   { this.mandatory = mandatory; }
}
