package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.checkDoublOnDocumentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class checkDoublOnDocumentBusiness {
    @Autowired
    private checkDoublOnDocumentDao checkDoublOnDocument;

    public Integer checkDoublOnDocument(Document document1){
        return checkDoublOnDocument.checkDoublonDocument(document1);
    }

}
