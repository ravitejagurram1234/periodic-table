package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;

import java.util.List;

public interface categorieSerInterface {
    List<TypeDeDocument>getListeSousCategorie(int p_idCategorie, int p_checkAtLeastOneDocument);
}
