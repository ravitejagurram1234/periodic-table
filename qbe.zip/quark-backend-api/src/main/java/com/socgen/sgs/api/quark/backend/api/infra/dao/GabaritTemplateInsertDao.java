package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;

public interface GabaritTemplateInsertDao {
    Integer insertGabaritTemplate(Chargement_gabarit gabarit);
}
