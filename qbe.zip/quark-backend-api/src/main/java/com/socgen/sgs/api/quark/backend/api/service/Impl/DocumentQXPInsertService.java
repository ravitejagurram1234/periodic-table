package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AuditParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.DocumentQXPInsertBusiness;
import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.service.DocumentQXPInsertSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class DocumentQXPInsertService implements DocumentQXPInsertSerInterface {

    @Autowired
    private DocumentQXPInsertBusiness documentQXPInsertBusiness;
    @Autowired
    private AuditParFondsBusiness auditParFondsBusiness;


    public Integer DocumentQXPInsert(MultipartFile file) {
        int p_taille_document = (int) file.getSize();
        try {
            return documentQXPInsertBusiness.DocumentQXPInsert(file.getBytes(), p_taille_document);

        } catch (IOException e) {
            throw new RuntimeException("Error reading file bytes", e);
        }
    }

    public String getClientIp(HttpServletRequest request) {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.isEmpty() || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }


    public Integer DocumentQXPaudit(MultipartFile document, String page,String user, int id, HttpServletRequest request){
        Performance performance = new Performance();
        LocalDate start = LocalDate.now();
        LocalDate end = LocalDate.now();


        BigDecimal responseTime = performance.getSecondsAndMilliseconds();

        String clientIp = getClientIp(request);

        String formattedNom = "Id document : " + id;

        LocalDateTime now = LocalDateTime.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = now.format(formatter);
        String formattedDate = "Date insertion : " + formattedDateTime;


        Audit audit = new Audit(clientIp, start, end, page, user, Chargement_constantes.MODULE_NAME, Chargement_constantes.CREATION_DOCUMENT_QXP,
                "", formattedNom, formattedDate, "", "", "", responseTime, 0, 0, "");

        return auditParFondsBusiness.AuditParFonds(audit);

    }
}

