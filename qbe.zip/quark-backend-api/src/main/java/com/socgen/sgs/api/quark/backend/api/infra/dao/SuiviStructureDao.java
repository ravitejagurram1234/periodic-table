package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviStructureDetails;

import java.time.LocalDate;
import java.util.List;

public interface SuiviStructureDao {
    List<SuiviStructureDetails> getListeStructuresForNewSuivi(Long p_idTypeRapport, Long p_idLangue, Long p_idGabarit,
                                                              LocalDate p_dateEcheance, String p_structures, String p_auditor,
                                                              String p_accountant, String p_fundMgtCompany) ;
}

