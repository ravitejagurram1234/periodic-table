package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.SuiviEventsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SuiviEventsMapper {
    public static SuiviEvents mapResult(ResultSet rs) throws SQLException {
        SuiviEvents events = new SuiviEvents();
        events.setIdEvent(rs.getLong("ID_EVENT"));
        events.setIdEventStep(rs.getLong("ID_EVENT_STEP"));
        events.setEventDataType(rs.getLong("EVENT_DATA_TYPE"));
        java.sql.Date eventDate= rs.getDate("EVENT_DATE_ECHEANCE");
        events.setEventDateEcheance(eventDate.toLocalDate());

        return events;

    }

    public static SuiviEventsDTO toDto(SuiviEvents suivi) {
        SuiviEventsDTO dto=new SuiviEventsDTO();
       dto.setId_event(suivi.getIdEvent());
       dto.setId_event_step(suivi.getIdEventStep());
       dto.setEvent_data_type(suivi.getEventDataType());
       dto.setEvent_date_echeance(suivi.getEventDateEcheance());

       return dto;
    }
}
