package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class GabaritTemplateBusiness {
    @Autowired
    private GabaritTemplateDao gabaritTemplateDao;

    public List<GabaritTemplate> getTemplates(){
        return gabaritTemplateDao.getTemplates();
    }
}
