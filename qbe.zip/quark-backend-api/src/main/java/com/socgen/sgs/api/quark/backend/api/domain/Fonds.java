package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Fonds {
        private String key_ref_fund;
        private String id_fnd_code;
        private String id_fnd_start_validity;
        private String fnd_end_validity;
        private String fnd_sht_description;
        private String fnd_lng_description;
        private String fnd_flg_multi_mngr;
        private String act_socio_class;
        private String id_mng_code;
        private String mng_lng_description;
        private String mng_sht_description;
        private String id_mfm_manager_code;
        private String id_act_code;
}
