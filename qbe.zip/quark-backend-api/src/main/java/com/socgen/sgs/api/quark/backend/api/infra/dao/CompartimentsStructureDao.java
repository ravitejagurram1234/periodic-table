package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Structure;

import java.util.List;

public interface CompartimentsStructureDao {
    List<Structure> getStructures(int p_withAtLeastOneCompatiment, String p_auditor, String p_accountant, String p_fundMgtCompany);
}
