package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Auditor {
    private String desTableValue;

    private Auditor(Builder builder) {this.desTableValue= builder.desTableValue;
    }


    public static Builder builder() {
        return new Builder();
    }


    public static class Builder {
        private String desTableValue;

        public Builder desTableValue(String desTableValue) {
            this.desTableValue=desTableValue;
            return this;
        }

        public Auditor build() {
            return new Auditor(this);
        }
    }
}

