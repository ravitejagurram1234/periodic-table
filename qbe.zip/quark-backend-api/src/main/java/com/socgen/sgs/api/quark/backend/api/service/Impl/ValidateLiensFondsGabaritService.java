package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.LiensFondsGabaritResponseDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateLiensFondsGabaritDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditInsertTraceDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertLiensFondsGabaritDao;
import com.socgen.sgs.api.quark.backend.api.service.ValidateLiensFondsGabaritSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Slf4j
@Service
public class ValidateLiensFondsGabaritService implements ValidateLiensFondsGabaritSerInterface {

    @Autowired
    private InsertLiensFondsGabaritDao insertLiensFondsGabaritDao;

    @Autowired
    private AuditInsertTraceDao auditInsertTraceDao;

    @Override
    @Transactional
    public LiensFondsGabaritResponseDTO validateAndLinkFonds(ValidateLiensFondsGabaritDTO dto,
                                                             HttpServletRequest request) {
        if (dto.getIdGabarit() == null || dto.getIdGabarit() <= 0) {
            return buildError("INVALID_GABARIT_ID", "idGabarit is mandatory and must be > 0");
        }
        if (dto.getIdTypeRapport() == null || dto.getIdTypeRapport() <= 0) {
            return buildError("INVALID_RAPPORT_TYPE", "idTypeRapport is mandatory and must be > 0");
        }
        if (dto.getIdLangue() == null || dto.getIdLangue() <= 0) {
            return buildError("INVALID_LANGUE", "idLangue is mandatory and must be > 0");
        }
        if (dto.getListeFonds() == null || dto.getListeFonds().isEmpty()) {
            return buildError("EMPTY_FONDS_LIST", "listeFonds must contain at least one fund code");
        }

        insertLiensFondsGabaritDao.insertLiensFondsGabarit(
                dto.getIdTypeRapport(),
                dto.getIdGabarit(),
                dto.getIdLangue(),
                dto.getAuditor(),
                dto.getAccountant(),
                dto.getFundMgtCompany(),
                dto.getListeFonds()
        );

        return LiensFondsGabaritResponseDTO.builder()
                .success(true)
                .message("Fonds successfully linked to gabarit")
                .timestamp(LocalDateTime.now())
                .fondsLinked(dto.getListeFonds().size())
                .idGabarit(dto.getIdGabarit())
                .idTypeRapport(dto.getIdTypeRapport())
                .errorCode(null)
                .build();
    }

    @Override
    public String getClientIp(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        String xRealIp = request.getHeader("X-Real-IP");
        if (xRealIp != null && !xRealIp.isEmpty()) {
            return xRealIp;
        }
        return request.getRemoteAddr();
    }

    @Override
    public Integer auditLiensFondsGabarit(ValidateLiensFondsGabaritDTO dto, String page,
                                          String user, HttpServletRequest request) {
        try {
            BigDecimal responseTime = new Performance().getSecondsAndMilliseconds();

            Audit audit = new Audit(
                    getClientIp(request),
                    LocalDate.now(),
                    LocalDate.now(),
                    page,
                    user,
                    Chargement_constantes.MODULE_NAME,
                    Chargement_constantes.LIEN_GABARIT_FONDS,
                    "Validate lien gabarit-fonds",
                    "idGabarit=" + dto.getIdGabarit(),
                    "idTypeRapport=" + dto.getIdTypeRapport(),
                    "idLangue=" + dto.getIdLangue(),
                    "fondsCount=" + (dto.getListeFonds() == null ? 0 : dto.getListeFonds().size()),
                    "",
                    responseTime,
                    0,
                    0,
                    ""
            );

            return auditInsertTraceDao.insertTrace(audit);
        } catch (Exception e) {
            log.error("Audit insertTrace failed for ValidateLienGabaritFonds", e);
            return 0;
        }
    }

    private LiensFondsGabaritResponseDTO buildError(String code, String message) {
        return LiensFondsGabaritResponseDTO.builder()
                .success(false)
                .message(message)
                .timestamp(LocalDateTime.now())
                .fondsLinked(0)
                .errorCode(code)
                .build();
    }
}
