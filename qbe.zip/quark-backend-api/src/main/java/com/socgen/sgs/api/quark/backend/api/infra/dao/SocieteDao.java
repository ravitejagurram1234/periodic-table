package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Societe;

import java.util.List;

public interface SocieteDao {
    List<Societe> getSociete();
}
