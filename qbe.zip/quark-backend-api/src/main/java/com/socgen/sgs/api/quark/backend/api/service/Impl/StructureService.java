package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.FondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.StructureBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Fonds;
import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.service.StructureSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
@Service
public class StructureService implements StructureSerInterface {

    @Autowired
    private StructureBusiness structureBusiness;

    public List<Structure> getListeStructuresForNewSuivi(Long idTypeRapport, Long idLangue, Long idGabarit, LocalDate dateEcheance) {
        return structureBusiness.getListeStructuresForNewSuivi(idTypeRapport, idLangue, idGabarit, dateEcheance);
    }
    @Override
    public List<Structure> getListeStructures(String p_auditor, String p_accountant, String p_fundMgtCompany) {
        return structureBusiness.getListeStructures(p_auditor, p_accountant, p_fundMgtCompany);
    }

    }

