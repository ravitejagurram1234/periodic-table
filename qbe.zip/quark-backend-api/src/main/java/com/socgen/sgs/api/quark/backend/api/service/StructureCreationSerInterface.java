package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentDispoDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.StructureDTO;
import java.util.List;

public interface StructureCreationSerInterface {

    List<CompartimentDispoDTO> getCompartimentsDispos(String idStructure);

    StructureDTO createStructure(StructureDTO dto);

    StructureDTO getStructureDetails(String idStructure);
}
