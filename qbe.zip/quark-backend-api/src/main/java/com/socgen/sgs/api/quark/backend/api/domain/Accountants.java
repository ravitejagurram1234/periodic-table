package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Accountants {
    private String des_table_value;

    private Accountants(Builder builder) {
        this.des_table_value= builder.des_table_value;
    }

    public static Builder builder() {
        return new Builder();
    }


    public static class Builder {
        private String des_table_value;


        public Builder des_table_value(String des_table_value) {

            this.des_table_value=des_table_value;
            return this;
        }

        public Accountants build() {
           return new Accountants(this);
        }
    }
}
