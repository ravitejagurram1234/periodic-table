package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationSocieteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class ModificationSocieteBusiness {
    @Autowired
    private ModificationSocieteDao modificationSocieteDao;

    public List<String> getListSociete(){
        return modificationSocieteDao.getListSociete();
    }
}
