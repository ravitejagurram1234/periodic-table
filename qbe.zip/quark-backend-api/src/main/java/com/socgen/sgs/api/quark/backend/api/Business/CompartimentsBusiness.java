package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class CompartimentsBusiness {
    @Autowired
    private CompartimentsDao compartimentsDao;

    public List<Compartiment> getStructures(String p_idStructure, String p_auditor, String p_accountant, String p_fundMgtCompany){
        return compartimentsDao.getStructures(p_idStructure,p_auditor,p_accountant,p_fundMgtCompany);
    }
}
