package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.portefeuilleBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.service.IAuthenticationService;
import com.socgen.sgs.api.quark.backend.api.service.portefeuilleSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.devtools.autoconfigure.OptionalLiveReloadServer;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class portefeuilleService implements portefeuilleSerInterface {
    @Autowired
    private portefeuilleBusiness portefeuilleBusiness;


    public List<portefeuille> getPortefeuille(){

        return portefeuilleBusiness.getPortefeuille();
    }
}
