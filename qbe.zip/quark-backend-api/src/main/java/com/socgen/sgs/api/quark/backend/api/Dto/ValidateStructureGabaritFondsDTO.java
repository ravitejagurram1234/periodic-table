// src/main/java/.../Dto/ValidateStructureGabaritFondsDTO.java
package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ValidateStructureGabaritFondsDTO {
    private String       idStructure;
    private Long         idGabarit;
    private List<String> listeCompartiments;
    private String       idPresentationPatrimoine;
    private String       idPresentationCompteRes;
}
