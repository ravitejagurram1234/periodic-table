package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Fonds;
import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FondsDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Component
@Transactional
public class StructureBusiness {
    @Autowired
    private StructureDao structureDao;

    public List<Structure> getListeStructuresForNewSuivi(Long idTypeRapport, Long idLangue, Long idGabarit, LocalDate dateEcheance) {

        return structureDao.getListeStructuresForNewSuivi(idTypeRapport, idLangue, idGabarit, dateEcheance);

    }
    public List<Structure> getListeStructures(String p_auditor, String p_accountant, String p_fundMgtCompany) {
        return structureDao.getListeStructures(p_auditor, p_accountant, p_fundMgtCompany);
    }

}
