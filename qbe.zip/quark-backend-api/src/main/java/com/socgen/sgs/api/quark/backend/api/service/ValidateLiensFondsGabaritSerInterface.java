package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.ValidateLiensFondsGabaritDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.LiensFondsGabaritResponseDTO;
import jakarta.servlet.http.HttpServletRequest;

public interface ValidateLiensFondsGabaritSerInterface {
    LiensFondsGabaritResponseDTO validateAndLinkFonds(ValidateLiensFondsGabaritDTO dto, HttpServletRequest request);
    String getClientIp(HttpServletRequest request);
    Integer auditLiensFondsGabarit(ValidateLiensFondsGabaritDTO dto, String page, String user, HttpServletRequest request);
}
