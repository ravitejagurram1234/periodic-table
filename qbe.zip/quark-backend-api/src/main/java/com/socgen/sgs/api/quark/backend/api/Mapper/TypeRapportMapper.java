package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TypeRapportDTO;
import com.socgen.sgs.api.quark.backend.api.domain.R_DOMAIN;
import com.socgen.sgs.api.quark.backend.api.domain.TypeRapport;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.TypeRapportData;

public class TypeRapportMapper {
    public static TypeRapport mapDetails(TypeRapportData data) {
     return TypeRapport.builder()
             .id(data.getId())
             .libelle(data.getLibelle())
             .build();
    }



    public static TypeRapportDTO toDto(TypeRapport domain){

        return new TypeRapportDTO(domain.getId(), domain.getLibelle());
    }
}
