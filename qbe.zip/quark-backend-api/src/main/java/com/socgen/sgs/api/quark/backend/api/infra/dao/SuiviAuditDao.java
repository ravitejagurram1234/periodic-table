package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.InsertTrace;

import java.util.Map;

public interface SuiviAuditDao {
    Long insertTrace(InsertTrace insertTrace);
}
