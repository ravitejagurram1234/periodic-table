package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationParSocieteLangueBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteLangueDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationSocieteDao;
import com.socgen.sgs.api.quark.backend.api.service.ModificationParSocieteLangueSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
@Service
public class ModificationParSocieteLangueService implements ModificationParSocieteLangueSerInterface {
    @Autowired
    private ModificationParSocieteLangueBusiness modificationParSocieteLangueBusiness;

    public List<ModificationParFondsLangue> getLangues(String p_societe, int p_id_sous_categorie, LocalDate p_date_document) {
     return modificationParSocieteLangueBusiness.getLangues(p_societe,p_id_sous_categorie,p_date_document);

    }
}