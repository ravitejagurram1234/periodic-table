package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.portefeuilleMapper;
import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.portefeuilleDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCportefeuille implements portefeuilleDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCportefeuille(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetFondsDescription")
                .declareParameters(
                        new SqlOutParameter("RETURN", oracle.jdbc.OracleTypes.CURSOR, (rs, rowNum) -> portefeuilleMapper.mapResult(rs))
                );
    }

    @Override
    public List<portefeuille> getPortefeuille() {
        Map<String, Object> result = simpleJdbcCall.execute();
        return (List<portefeuille>) result.get("RETURN");
    }
}

