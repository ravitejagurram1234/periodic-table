// src/main/java/.../Dto/PresentationStructureDTO.java
package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PresentationStructureDTO {
    private String id_presentation_patrimoine;
    private String id_presentation_compte_res;
}
