package com.socgen.sgs.api.quark.backend.api.domain;

import jakarta.validation.constraints.NegativeOrZero;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SuiviDetails {
    private String keyRefFund;
    private String idFndCode;
    private String unitIdInsCode;
    private String fndShtDescription;
    private String fndLngDescription;
    private LocalDate fndMaturityDate;
    private String fndCurrency;
    private String fndExternalCode;
    private String fndAuditor;
    private String fndAccountant;
    private String fndLastFiscalYearEnd;
//    private LocalDate fndNextFiscalYearEnd;
    private String fndNextFiscalYearEnd;
    private String fndMngtCompany;
    private String fndCustomer;
    private Long idSuivi;
    private Long idStatutGeneration;
    private Integer typeSuivi;
    private String libelleFond;
    private String libelleClasse;
    private LocalDate dateLastEcheance;
    private String id_unit_code;
    private String unit_id_ins_code;
    private String unit_currency;
    private String unit_sht_description;


}
