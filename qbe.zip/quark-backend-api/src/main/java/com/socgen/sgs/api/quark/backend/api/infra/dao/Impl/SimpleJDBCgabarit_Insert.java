package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.Gabarit_InsertDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCgabarit_Insert implements Gabarit_InsertDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCgabarit_Insert (DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("InsertGabarit")
                .declareParameters(
                        new SqlParameter("p_id_type_rapport", Types.NUMERIC),
                        new SqlParameter("p_nom_gabarit", Types.VARCHAR),
                        new SqlParameter("p_id_langue", Types.NUMERIC),
                        new SqlParameter("p_contenu", Types.VARBINARY),
                        new SqlParameter("p_taille_gabarit", Types.NUMERIC),
                        new SqlParameter("p_is_actif", Types.NUMERIC),
                        new SqlParameter("p_type", Types.NUMERIC),
                        new SqlParameter("p_id_sous_categorie", Types.NUMERIC),
                        new SqlParameter("p_id_gabarit_template", Types.NUMERIC),
                        new SqlParameter("p_pagination_double", Types.NUMERIC)
                );
    }

    public Integer insertGabarit(Chargement_gabarit gabarit) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_id_type_rapport", gabarit.getP_id_type_rapport());
        params.put("p_nom_gabarit", gabarit.getNom_gabarit());
        params.put("p_id_langue",gabarit.getP_id_langue());
        params.put("p_contenu",gabarit.getP_contenu());
        params.put("p_taille_gabarit", gabarit.getP_taille_gabarit());
        params.put("p_is_actif", gabarit.getP_is_actif());
        params.put("p_type", gabarit.getP_type());
        params.put("p_id_sous_categorie", gabarit.getP_id_sous_categorie());
        params.put("p_id_gabarit_template", gabarit.getP_id_gabarit_template());
        params.put("p_pagination_double", gabarit.getP_pagination_double());

        Number result = simpleJdbcCall.executeFunction(Number.class,params);

        return result!=null?result.intValue():null;
    }

    }

