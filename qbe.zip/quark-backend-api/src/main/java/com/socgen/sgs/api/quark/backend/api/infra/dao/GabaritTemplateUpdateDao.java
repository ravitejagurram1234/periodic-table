package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;

public interface GabaritTemplateUpdateDao {
    void updateGabaritTemplate(Chargement_gabarit gabarit);
}
