package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AuditParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.UpdateCompartimentsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.UpdateGabaritBusiness;
import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ModificationGabaritDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateCompartimentsDao;
import com.socgen.sgs.api.quark.backend.api.service.UpdateCompartimentsSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class UpdateCompartimentsService implements UpdateCompartimentsSerInterface {
    @Autowired
    private UpdateCompartimentsBusiness updateCompartimentsBusiness;

    @Autowired
    private AuditParFondsBusiness auditParFondsBusiness;
    public void updateCompartimentInfos(CompartimentsDTO dto){
        updateCompartimentsBusiness.updateCompartimentInfos(dto);
    }

    public String getClientIp(HttpServletRequest request) {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.isEmpty() || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }

    public Integer AuditUpdateCompartiments(CompartimentsDTO dto, String page, String user, HttpServletRequest request) {

        Performance performance = new Performance();
        LocalDate start = LocalDate.now();
        LocalDate end = LocalDate.now();


        BigDecimal responseTime = performance.getSecondsAndMilliseconds();
        String clientIp = getClientIp(request);

        String param1 = "Insert/Update params [Libellé/Date de fin/Présentation Eco Geo]";
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = now.format(formatter);

        String p_message="Insert/Update du compartiment effectué avec succès";

        Audit audit = new Audit(clientIp, start, end, page, user, Chargement_constantes.MODULE_NAME,Chargement_constantes.MODIFICATION_COMPARTIMENTS,
                p_message, param1, dto.getId_fnd_code(), formattedDateTime, dto.getPresentation_eco_geo(), "", responseTime, 0, 0, "");

        return auditParFondsBusiness.AuditParFonds(audit);
    }

}
