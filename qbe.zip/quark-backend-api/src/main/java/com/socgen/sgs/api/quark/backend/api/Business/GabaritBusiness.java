package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class GabaritBusiness {
    @Autowired
    private GabaritDao gabaritDao;

    public Gabarit getGabarit(Long p_idGabarit){
        return gabaritDao.getGabarit(p_idGabarit);
    }
}
