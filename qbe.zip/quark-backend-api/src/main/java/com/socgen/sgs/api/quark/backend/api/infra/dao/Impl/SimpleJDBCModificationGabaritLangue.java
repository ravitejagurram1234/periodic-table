package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.ModificationLangueMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.portefeuilleMapper;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationGabaritLangueDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCModificationGabaritLangue implements ModificationGabaritLangueDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public  SimpleJDBCModificationGabaritLangue(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetLanguesDisposByTypeRapport")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> ModificationLangueMapper.mapResult(rs)),
                        new SqlParameter("p_id_type_rapport", Types.INTEGER)
                );
    }

    @Override
    public List<ModificationParFondsLangue> getListLangue(int p_id_type_rapport) {

        Map<String, Object> params = new HashMap<>();
        params.put( "p_id_type_rapport",p_id_type_rapport);
        Map<String, Object> result = simpleJdbcCall.execute(params);
        return (List<ModificationParFondsLangue>) result.get("RETURN_VALUE");

    }
}
