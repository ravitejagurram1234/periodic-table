package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationGabaritLangueBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationGabaritLangueDao;
import com.socgen.sgs.api.quark.backend.api.service.ModificationGabaritLangueSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ModificationGabaritLangueService implements ModificationGabaritLangueSerInterface {
    @Autowired
    private ModificationGabaritLangueBusiness modificationGabaritLangueBusiness;

    public List<ModificationParFondsLangue> getListLangue(int p_id_type_rapport){
        return modificationGabaritLangueBusiness.getListLangue(p_id_type_rapport);
    }
}
