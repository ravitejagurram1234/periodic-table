package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.TypeRapport;

import java.util.List;

public interface TypeRapportSerInterface {
    List<TypeRapport> getTypeRapport();
}
