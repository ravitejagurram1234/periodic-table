package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentDispoDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.StructureDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.StructureMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentDispoDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertStructureDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureDao;
import com.socgen.sgs.api.quark.backend.api.service.StructureCreationSerInterface;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

@Slf4j
@Service
public class StructureCreationService implements StructureCreationSerInterface {

    @Autowired
    private CompartimentDispoDao compartimentDispoDao;

    @Autowired
    private InsertStructureDao insertStructureDao;

    @Autowired
    private StructureDao structureDao;

    @Override
    public List<CompartimentDispoDTO> getCompartimentsDispos(String idStructure) {
        List<Compartiment> compartiments = compartimentDispoDao.getListeCompartsDispos(idStructure);

        if (compartiments == null || compartiments.isEmpty()) {
            return List.of();
        }

        boolean isWildcard = idStructure == null || idStructure.isBlank() || "%".equals(idStructure.trim());
        if (isWildcard) {
            compartiments = compartiments.stream()
                    .sorted(Comparator.comparingLong(c -> {
                        try {
                            return Long.parseLong(c.getId_fnd_code());
                        } catch (NumberFormatException e) {
                            return Long.MAX_VALUE;
                        }
                    }))
                    .toList();
        }

        return compartiments.stream()
                .map(c -> CompartimentDispoDTO.builder()
                        .idFndCode(c.getId_fnd_code())
                        .nom(c.getLibelle_compartiment())
                        .build())
                .toList();
    }

    @Override
    @Transactional
    public StructureDTO createStructure(StructureDTO dto) {
        if (dto.getIdStructure() == null || dto.getIdStructure().trim().isEmpty()) {
            throw new IllegalArgumentException("Structure ID is mandatory");
        }

        if (insertStructureDao.structureExists(dto.getIdStructure())) {
            throw new IllegalStateException("Structure with ID " + dto.getIdStructure() + " already exists");
        }

        insertStructureDao.insertStructure(
                dto.getIdStructure(),
                dto.getNom(),
                dto.getLibelleLong(),
                dto.getFndLegalType(),
                dto.getFndClassification(),
                dto.getFndMngtCompany(),
                dto.getFndAccountant(),
                dto.getCac(),
                dto.getDevise()
        );

        return dto;
    }

    @Override
    public StructureDTO getStructureDetails(String idStructure) {
        if ("NOUVELLE_STRUCTURE".equalsIgnoreCase(idStructure)) {
            return StructureDTO.builder()
                    .idStructure("")
                    .nom("")
                    .libelleLong("")
                    .fndLegalType("")
                    .fndClassification("")
                    .fndMngtCompany("")
                    .fndAccountant("")
                    .cac("")
                    .devise("")
                    .build();
        }

        Structure found = structureDao.getStructureById(idStructure)
                .orElseThrow(() -> new IllegalArgumentException("Structure not found: " + idStructure));

        return StructureMapper.toFullDto(found);
    }
}
