package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.GabaritEventBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;
import com.socgen.sgs.api.quark.backend.api.service.GabaritEventSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GabaritEventService implements GabaritEventSerInterface {

    @Autowired
    private GabaritEventBusiness gabaritEventBusiness;

    public List<GabaritEvents> getGabaritEvent(Long p_idGabarit) {
        return gabaritEventBusiness.getGabaritEvents(p_idGabarit);
    }
}

