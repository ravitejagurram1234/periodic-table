package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentsDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.CompartimentMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateCompartimentsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class UpdateCompartimentsBusiness {
    @Autowired
    private UpdateCompartimentsDao updateCompartimentsDao;

    public void updateCompartimentInfos(CompartimentsDTO dto){
        Compartiment compartiment= CompartimentMapper.toDomain(dto);
         updateCompartimentsDao.updateCompartimentInfos(compartiment);
    }
}
