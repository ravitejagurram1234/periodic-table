// src/main/java/.../service/StructureGabaritSerInterface.java
package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.domain.PresentationStructure;

import java.util.List;

public interface StructureGabaritSerInterface {
    List<PresentationStructure> getPresentationStructure(String idStructure, Long idGabarit);
    List<Compartiment> getListeCompartsByStructGab(String idStructure, Long idGabarit);
}
