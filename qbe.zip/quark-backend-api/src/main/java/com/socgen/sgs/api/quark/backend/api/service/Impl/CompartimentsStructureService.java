package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.CompartimentsStructureBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.service.CompartimentsStructureSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CompartimentsStructureService implements CompartimentsStructureSerInterface{
    @Autowired
    private CompartimentsStructureBusiness compartimentsStructureBusiness;

    public List<Structure> getStructures(int p_withAtLeastOneCompatiment, String p_auditor, String p_accountant, String p_fundMgtCompany){
        return compartimentsStructureBusiness.getStructures(p_withAtLeastOneCompatiment,p_auditor,p_accountant,p_fundMgtCompany);
    }
}
