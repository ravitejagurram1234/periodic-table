package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class portefeuille {
    private String id_fnd_code;
    private String description;

}
