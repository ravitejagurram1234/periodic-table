package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Langue;

import java.util.List;

public interface LangueDao {
    List<Langue> getLangue();
}
