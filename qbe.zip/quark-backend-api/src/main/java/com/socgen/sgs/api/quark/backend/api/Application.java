package com.socgen.sgs.api.quark.backend.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.zalando.problem.spring.web.advice.security.SecurityProblemSupport;

@SpringBootApplication
@Import(SecurityProblemSupport.class)
public class Application {

  public static void main(String[] args) {
    SpringApplication.run(Application.class);
  }
}
