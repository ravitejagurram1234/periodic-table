package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationGabaritLangueDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class ModificationGabaritLangueBusiness {
    @Autowired
    private ModificationGabaritLangueDao modificationGabaritLangueDao;

    public List<ModificationParFondsLangue> getListLangue(int p_id_type_rapport){
        return modificationGabaritLangueDao.getListLangue(p_id_type_rapport);
    }
}
