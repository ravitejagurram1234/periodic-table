package com.socgen.sgs.api.quark.backend.api.Constantes;

public class Chargement_constantes {
    public static final String MODULE_NAME = "Chargement";

    public static final String LIEN_GABARIT_FONDS = "Lien gabarit-fonds";
    public static final String LIEN_STRUCTURE_COMP = "Lien structure-compartiment";
    public static final String LIEN_STRUCTURE_GABARIT_FONDS = "Lien structure-gabarit-fonds";

    public static final String CREATION_DOCUMENT_PAR_FONDS = "Creation document par fonds";
    public static final String CREATION_DOCUMENT_PAR_PART = "Creation document par part";
    public static final String CREATION_DOCUMENT_PAR_SOCIETE = "Creation document par societe";
    public static final String CREATION_DOCUMENT_QXP = "Creation document QXP";
    public static final String CREATION_GABARIT_TEMPLATE = "Creation gabarit template";
    public static final String CREATION_GABARIT = "Creation gabarit";

    public static final String MODIFICATION_DOCUMENT_PAR_FONDS = "Modification document par fonds";
    public static final String MODIFICATION_DOCUMENT_PAR_PART = "Modification document par part";
    public static final String MODIFICATION_DOCUMENT_PAR_SOCIETE = "Modification document par societe";
    public static final String MODIFICATION_DOCUMENT_QXP = "Modification document QXP";
    public static final String MODIFICATION_GABARIT = "Modification gabarit";
    public static final String MODIFICATION_COMPARTIMENTS = "Modification compartiments";
    public static final String MODIFICATION_GABARIT_TEMPLATE = "Modification gabarit template";

    public static final String SUPPRESSION_DOCUMENT_PAR_FONDS = "Suppression document par fonds";
    public static final String SUPPRESSION_DOCUMENT_PAR_PART = "Suppression document par part";

    public static final String CSS_EXISTANTDOCUMENT = "ExistantDocument";



}
