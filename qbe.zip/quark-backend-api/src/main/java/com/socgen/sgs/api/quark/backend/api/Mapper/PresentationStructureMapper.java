// src/main/java/.../Mapper/PresentationStructureMapper.java
package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.PresentationStructureDTO;
import com.socgen.sgs.api.quark.backend.api.domain.PresentationStructure;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PresentationStructureMapper {

    public static PresentationStructure mapResult(ResultSet rs) throws SQLException {
        return PresentationStructure.builder()
                .id_presentation_patrimoine(rs.getString("id_presentation_patrimoine"))
                .id_presentation_compte_res(rs.getString("id_presentation_compte_res"))
                .build();
    }

    public static PresentationStructureDTO toDto(PresentationStructure domain) {
        return PresentationStructureDTO.builder()
                .id_presentation_patrimoine(domain.getId_presentation_patrimoine())
                .id_presentation_compte_res(domain.getId_presentation_compte_res())
                .build();
    }
}
