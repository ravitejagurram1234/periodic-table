package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TypeDeDocumentDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TypeDeDocumentMapper {
    public static TypeDeDocument mapResult(ResultSet rs) throws SQLException{
        TypeDeDocument typeDeDocument=new TypeDeDocument();
        typeDeDocument.setID_SOUS_CATEGORIE(rs.getLong("ID_SOUS_CATEGORIE"));
        typeDeDocument.setLIBELLE_SOUS_CATEGORIE(rs.getString("LIBELLE_SOUS_CATEGORIE"));

        return typeDeDocument;
    }
    public static TypeDeDocumentDTO toDto(TypeDeDocument domain){
     TypeDeDocumentDTO dto=new TypeDeDocumentDTO();
     dto.setID_SOUS_CATEGORIE(domain.getID_SOUS_CATEGORIE());
     dto.setLIBELLE_SOUS_CATEGORIE(domain.getLIBELLE_SOUS_CATEGORIE());
     return dto;
    }
}