package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.Data;
import java.util.List;

@Data
public class ValidateStructureRequestDTO {
    private String idStructure;          // always the real structure ID (new or existing)
    private boolean creationMode;        // true = create, false = update

    private String nom;
    private String libelleLong;
    private String fndLegalType;
    private String fndClassification;
    private String fndMngtCompany;
    private String fndAccountant;
    private String cac;
    private String devise;

    // ALL final compartments after user validation (not just selected delta)
    private List<String> allCompartiments;
}
