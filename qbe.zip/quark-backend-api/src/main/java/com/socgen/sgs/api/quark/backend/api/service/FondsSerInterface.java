package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Fonds;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public interface FondsSerInterface {
    List<Fonds> getListeFondsForNewSuivi(Long p_idTypeRapport, Long p_idLangue, Long p_idGabarit, LocalDate p_dateEcheance);
}
