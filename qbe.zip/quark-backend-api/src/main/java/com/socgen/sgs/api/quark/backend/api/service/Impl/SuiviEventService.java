package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.SuiviEventsBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviEventDao;
import com.socgen.sgs.api.quark.backend.api.service.SuiviEventsSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SuiviEventService implements SuiviEventsSerInterface {

    @Autowired
    private SuiviEventsBusiness suiviEventsBusiness;

    public List<SuiviEvents> getSuiviEvents(Long p_idSuivi) {
        return suiviEventsBusiness.getSuiviEvents(p_idSuivi);

    }
}
