package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateInsertDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class GabaritTemplateInsertBusiness {
    @Autowired
    private GabaritTemplateInsertDao gabaritTemplateInsertDao;

    public Integer insertGabaritTemplate(Chargement_gabarit gabarit){
        return gabaritTemplateInsertDao.insertGabaritTemplate(gabarit);
    }
}
