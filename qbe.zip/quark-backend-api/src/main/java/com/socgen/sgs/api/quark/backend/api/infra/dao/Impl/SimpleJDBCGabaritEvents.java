package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.GabaritEventMapper;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritEventDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCGabaritEvents implements GabaritEventDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCGabaritEvents(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeDefaultEventsByGabarit")
                .declareParameters(
                        new SqlOutParameter("RETURN", oracle.jdbc.OracleTypes.CURSOR, (rs, rowNum) -> GabaritEventMapper.mapResult(rs)),
                        new SqlParameter("p_idGabarit", Types.NUMERIC)

                );
    }

    @Override
    public List<GabaritEvents> getGabaritEvent(Long p_idGabarit) {
        Map<String, Object> result = simpleJdbcCall.execute(Map.of("p_idGabarit", p_idGabarit));
        return (List<GabaritEvents>) result.get("RETURN");
    }
}
