package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateGabaritDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class UpdateGabaritBusiness {
    @Autowired
    private UpdateGabaritDao updateGabaritDao;

    public void updateGabarit(Gabarit gabarit,Long p_idGabarit){
        updateGabaritDao.updateGabarit(gabarit,p_idGabarit);
    }
}
