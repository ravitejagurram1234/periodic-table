package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritEventDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class GabaritEventBusiness {
    @Autowired
    private GabaritEventDao gabaritEventDao;
    public List<GabaritEvents> getGabaritEvents(Long p_idGabarit){
        return gabaritEventDao.getGabaritEvent(p_idGabarit);
    }
}
