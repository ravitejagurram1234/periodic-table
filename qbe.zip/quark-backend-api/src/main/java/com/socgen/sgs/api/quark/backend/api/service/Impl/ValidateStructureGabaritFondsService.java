package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.StructureGabaritFondsResponseDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureGabaritFondsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditInsertTraceDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertLiensStructGabCompartsDao;
import com.socgen.sgs.api.quark.backend.api.service.IAuthenticationService;
import com.socgen.sgs.api.quark.backend.api.service.ValidateStructureGabaritFondsSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

@Slf4j
@Service
public class ValidateStructureGabaritFondsService implements ValidateStructureGabaritFondsSerInterface {

    @Autowired
    private InsertLiensStructGabCompartsDao insertLiensStructGabCompartsDao;

    @Autowired
    private AuditInsertTraceDao auditInsertTraceDao;

    @Autowired
    private IAuthenticationService authenticationService;

    @Override
    @Transactional
    public StructureGabaritFondsResponseDTO validateAndLinkCompartiments(
            ValidateStructureGabaritFondsDTO dto, HttpServletRequest request) {

        if (dto.getIdStructure() == null || dto.getIdStructure().isBlank()) {
            audit(dto, request, 1, "Validation failed: idStructure is mandatory");
            return buildError("INVALID_STRUCTURE_ID", "idStructure is mandatory", dto);
        }
        if (dto.getIdGabarit() == null || dto.getIdGabarit() <= 0) {
            audit(dto, request, 1, "Validation failed: idGabarit is mandatory");
            return buildError("INVALID_GABARIT_ID", "idGabarit is mandatory and must be > 0", dto);
        }
        if (dto.getListeCompartiments() == null || dto.getListeCompartiments().isEmpty()) {
            audit(dto, request, 1, "Validation failed: listeCompartiments is empty");
            return buildError("EMPTY_COMPARTIMENTS_LIST",
                    "listeCompartiments must contain at least one compartiment code", dto);
        }

        try {
            insertLiensStructGabCompartsDao.insertLiensStructGabComparts(
                    dto.getIdStructure(),
                    dto.getIdGabarit(),
                    dto.getListeCompartiments(),
                    dto.getIdPresentationPatrimoine(),
                    dto.getIdPresentationCompteRes()
            );

            audit(dto, request, 0, "Validate structure-gabarit-fonds success");

            return StructureGabaritFondsResponseDTO.builder()
                    .success(true)
                    .message("Compartiments successfully linked to structure-gabarit")
                    .timestamp(LocalDateTime.now())
                    .compartimentsLinked(dto.getListeCompartiments().size())
                    .idStructure(dto.getIdStructure())
                    .idGabarit(dto.getIdGabarit())
                    .errorCode(null)
                    .build();
        } catch (Exception ex) {
            audit(dto, request, 1, "Validate structure-gabarit-fonds failed: " + ex.getMessage());
            throw ex;
        }
    }

    private void audit(ValidateStructureGabaritFondsDTO dto, HttpServletRequest request, int statut, String message) {
        try {
            Optional<String> user = authenticationService.getCurrentUserEmailId();
            BigDecimal responseTime = new Performance().getSecondsAndMilliseconds();

            Audit a = new Audit(
                    getClientIp(request),
                    LocalDate.now(),
                    LocalDate.now(),
                    "/api/v1/ValidateStructureGabaritFonds",
                    user.orElse("UNKNOWN"),
                    Chargement_constantes.MODULE_NAME,
                    Chargement_constantes.LIEN_STRUCTURE_GABARIT_FONDS,
                    message,
                    "idStructure=" + (dto == null ? null : dto.getIdStructure()),
                    "idGabarit=" + (dto == null ? null : dto.getIdGabarit()),
                    "idPresentationPatrimoine=" + (dto == null ? null : dto.getIdPresentationPatrimoine()),
                    "idPresentationCompteRes=" + (dto == null ? null : dto.getIdPresentationCompteRes()),
                    "compartimentsCount=" + (dto == null || dto.getListeCompartiments() == null ? 0 : dto.getListeCompartiments().size()),
                    responseTime,
                    statut,
                    0,
                    ""
            );

            auditInsertTraceDao.insertTrace(a);
        } catch (Exception e) {
            log.error("Audit insertTrace failed for ValidateStructureGabaritFonds", e);
        }
    }

    private String getClientIp(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isBlank()) {
            return xForwardedFor.split(",")[0].trim();
        }
        String xRealIp = request.getHeader("X-Real-IP");
        if (xRealIp != null && !xRealIp.isBlank()) {
            return xRealIp.trim();
        }
        return request.getRemoteAddr();
    }

    private StructureGabaritFondsResponseDTO buildError(
            String code, String message, ValidateStructureGabaritFondsDTO dto) {
        return StructureGabaritFondsResponseDTO.builder()
                .success(false)
                .message(message)
                .timestamp(LocalDateTime.now())
                .compartimentsLinked(0)
                .idStructure(dto != null ? dto.getIdStructure() : null)
                .idGabarit(dto != null ? dto.getIdGabarit() : null)
                .errorCode(code)
                .build();
    }
}
