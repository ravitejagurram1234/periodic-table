package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.LangueMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Langue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.LangueDao;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.LangueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
@Component
@Transactional

public class LangueDaoImpl implements LangueDao {


        @Autowired
        private LangueRepository langueRepository;
        @Override
        public List<Langue> getLangue() {
            return langueRepository.getLangue().stream().filter(Objects::nonNull)
                    .map(LangueMapper:: mapDetails).toList();
        }
    }