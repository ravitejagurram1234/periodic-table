package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TypeRapport;

import java.util.List;

public interface TypeRapportDao {
    List<TypeRapport> getTypeRapport();
}
