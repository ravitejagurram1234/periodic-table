package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.SocieteDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Societe;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SocieteMapper {
    public static Societe mapResult(ResultSet rs) throws SQLException {
        Societe s=new Societe();
        s.setFND_MNGT_COMPANY(rs.getString("FND_MNGT_COMPANY"));
        return s;
    }

    public static SocieteDTO toDto(Societe societe){
        SocieteDTO dto=new SocieteDTO();
        dto.setFND_MNGT_COMPANY(societe.getFND_MNGT_COMPANY());
        return  dto;
    }

}
