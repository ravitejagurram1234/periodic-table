package com.socgen.sgs.api.quark.backend.api.infra.jpa.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "QXP_REF_TYPE_RAPPORT")
public class TypeRapportEntity {
    @Id
    @Column(name = "ID_TYPE_RAPPORT", nullable = false)
    private Long ID_TYPE_RAPPORT;
    @Column(name = "LIBELLE", nullable = false)
    private String LIBELLE;
}
