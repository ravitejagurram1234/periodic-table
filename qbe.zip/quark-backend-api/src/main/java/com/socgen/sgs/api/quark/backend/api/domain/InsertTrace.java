package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InsertTrace {
    private String p_ip;
    private LocalDate p_startTime;
    private LocalDate p_endTime;
    private String p_page;
    private String p_login;
    private String p_module;
    private String p_fonction;
    private String p_message;
    private String p_param1;
    private String p_param2;
    private String p_param3;
    private String p_param4;
    private String p_param5;
    private Integer p_temps_reponse;
    private Integer p_statut;
    private Long p_id_application;
    private String p_nom_application;
}
