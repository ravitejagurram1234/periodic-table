package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SuiviDetailsMapper {

    public static SuiviDetails mapResult(ResultSet rs,Long p_typeGabarit) throws SQLException {
        SuiviDetails newSuivi=new SuiviDetails();
        newSuivi.setKeyRefFund(rs.getString("KEY_REF_FUND"));
        newSuivi.setIdFndCode(rs.getString("ID_FND_CODE"));
        newSuivi.setUnitIdInsCode(rs.getString("UNIT_ID_INS_CODE"));
        newSuivi.setFndShtDescription(rs.getString("FND_SHT_DESCRIPTION"));
        newSuivi.setFndLngDescription(rs.getString("FND_LNG_DESCRIPTION"));
        try {
            java.sql.Date fnd_maturity = rs.getDate("FND_MATURITY_DATE");
            newSuivi.setFndMaturityDate(fnd_maturity != null ? fnd_maturity.toLocalDate() : null);
        } catch (IllegalArgumentException e) {
            newSuivi.setFndMaturityDate(null);
        }
        newSuivi.setFndCurrency(rs.getString("FND_CURRENCY"));
        newSuivi.setFndExternalCode(rs.getString("FND_EXTERNAL_CODE"));
        newSuivi.setFndAuditor(rs.getString("FND_AUDITOR"));
        newSuivi.setFndAccountant(rs.getString("FND_ACCOUNTANT"));
        newSuivi.setFndLastFiscalYearEnd(rs.getString("FND_LAST_FISCAL_YEAR_END"));
//        try {
//            java.sql.Date lastFiscalYearEnd = rs.getDate("FND_LAST_FISCAL_YEAR_END");
//            newSuivi.setFndLastFiscalYearEnd(lastFiscalYearEnd != null ? lastFiscalYearEnd.toLocalDate() : null);
//        } catch (IllegalArgumentException e) {
//            newSuivi.setFndLastFiscalYearEnd(null);
//        }
        newSuivi.setFndNextFiscalYearEnd(rs.getString("FND_NEXT_FISCAL_YEAR_END"));
//        try {
//            java.sql.Date nextFiscalYearEnd = rs.getDate("FND_NEXT_FISCAL_YEAR_END");
//            newSuivi.setFndNextFiscalYearEnd(nextFiscalYearEnd != null ? nextFiscalYearEnd.toLocalDate() : null);
//        } catch (IllegalArgumentException e) {
//            newSuivi.setFndNextFiscalYearEnd(null);
//        }

        newSuivi.setFndMngtCompany(rs.getString("FND_MNGT_COMPANY"));
        newSuivi.setFndCustomer(rs.getString("FND_CUSTOMER"));
        newSuivi.setIdSuivi(rs.getLong("ID_SUIVI"));
        newSuivi.setIdStatutGeneration(rs.getLong("ID_STATUT_GENERATION"));
        newSuivi.setTypeSuivi(rs.getInt("TYPE_SUIVI"));
        newSuivi.setLibelleFond(rs.getString("LIBELLE_FOND"));
        newSuivi.setLibelleClasse(rs.getString("LIBELLE_CLASSE"));
        try {
            java.sql.Date dateEcheance = rs.getDate("DATE_LAST_ECHEANCE");
            newSuivi.setDateLastEcheance(dateEcheance != null ? dateEcheance.toLocalDate() : null);
        } catch (IllegalArgumentException e) {
            newSuivi.setDateLastEcheance(null);
        }

        if(p_typeGabarit!=null && p_typeGabarit==2L) {
            newSuivi.setId_unit_code(rs.getString("ID_UNIT_CODE") != null ? rs.getString("ID_UNIT_CODE") : null);
            newSuivi.setUnitIdInsCode(rs.getString("UNIT_ID_INS_CODE")!=null? rs.getString("UNIT_ID_INS_CODE"):null);
            newSuivi.setUnit_currency(rs.getString("UNIT_CURRENCY") != null ? rs.getString("UNIT_CURRENCY") : null);
            newSuivi.setUnit_sht_description(rs.getString("UNIT_SHT_DESCRIPTION") != null ? rs.getString("UNIT_SHT_DESCRIPTION") : null);
        }
        return newSuivi;
    }


    public static SuiviDetailsDTO toDto(SuiviDetails suivi,Long p_typeGabarit) {
        SuiviDetailsDTO dto=new SuiviDetailsDTO();
        dto.setId_fnd_code(suivi.getIdFndCode());
        dto.setFnd_next_fiscal_year_end(suivi.getFndNextFiscalYearEnd());
        dto.setFndLastFiscalYearEnd(suivi.getFndLastFiscalYearEnd());
        dto.setFndShtDescription(suivi.getFndShtDescription());
        dto.setLibelleFond(suivi.getLibelleFond());
        dto.setLibelleClasse(suivi.getLibelleClasse());
        dto.setFndMngtCompany(suivi.getFndMngtCompany());
        dto.setFndAccountant(suivi.getFndAccountant());
        dto.setFndAuditor(suivi.getFndAuditor());

        if(p_typeGabarit!=null && p_typeGabarit==2L){
            dto.setId_unit_code(suivi.getId_unit_code());

        }

        return dto;
    }
}



