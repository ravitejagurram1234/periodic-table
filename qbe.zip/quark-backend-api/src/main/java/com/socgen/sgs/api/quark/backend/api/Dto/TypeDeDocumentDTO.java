package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TypeDeDocumentDTO {
    private Long ID_SOUS_CATEGORIE;
    private String LIBELLE_SOUS_CATEGORIE;
}

