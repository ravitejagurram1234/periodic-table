package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;

import java.util.List;

public interface FundMgtCompanySerInterface {
    List<FundMgtCompany> getListFundMgtCompanies();
}

