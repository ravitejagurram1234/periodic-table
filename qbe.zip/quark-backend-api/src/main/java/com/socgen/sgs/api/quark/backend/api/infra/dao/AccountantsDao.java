package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Accountants;

import java.util.List;

public interface AccountantsDao {
    List<Accountants> getListAccountants();
}
