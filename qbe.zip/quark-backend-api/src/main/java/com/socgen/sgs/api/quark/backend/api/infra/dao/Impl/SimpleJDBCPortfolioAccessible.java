package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PortfolioAccessibleDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCPortfolioAccessible implements PortfolioAccessibleDao {

    private final SimpleJdbcCall getFondsSimples;
    private final SimpleJdbcCall getListeStructures;
    private final SimpleJdbcCall getListeCompartsNonDispos;

    @Autowired
    public SimpleJDBCPortfolioAccessible(DataSource dataSource) {

        this.getFondsSimples = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetFondsSimples")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> {
                            rs.setFetchSize(1000);
                            return mapToPortefeuilleDTO(rs, "ID_FND_CODE", "FND_SHT_DESCRIPTION");
                        }),
                        new SqlParameter("P_AUDITOR", Types.VARCHAR),
                        new SqlParameter("P_ACCOUNTANT", Types.VARCHAR),
                        new SqlParameter("P_FUNDMGTCOMPANY", Types.VARCHAR)
                );

        this.getListeStructures = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withFunctionName("GetListeStructures")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR,
                                (rs, rowNum) -> mapToPortefeuilleDTO(rs, "ID_STRUCTURE", "NOM")),
                        new SqlParameter("p_withAtLeastOneCompatiment", Types.NUMERIC),
                        new SqlParameter("p_auditor", Types.VARCHAR),
                        new SqlParameter("p_accountant", Types.VARCHAR),
                        new SqlParameter("p_fundMgtCompany", Types.VARCHAR)
                );

        this.getListeCompartsNonDispos = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withFunctionName("GetListeCompartsNonDispos")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR,
                                (rs, rowNum) -> mapToPortefeuilleDTO(rs, "ID_FND_CODE", "LIBELLE_COMPARTIMENT")),
                        new SqlParameter("P_AUDITOR", Types.VARCHAR),
                        new SqlParameter("P_ACCOUNTANT", Types.VARCHAR),
                        new SqlParameter("P_FUNDMGTCOMPANY", Types.VARCHAR)
                );
    }

    @Override
    public List<portefeuilleDTO> getFondsSimples(String p_auditor, String p_accountant, String p_fundMgtCompany) {
        Map<String, Object> params = new HashMap<>();
        params.put("P_AUDITOR", normalize(p_auditor));
        params.put("P_ACCOUNTANT", normalize(p_accountant));
        params.put("P_FUNDMGTCOMPANY", normalize(p_fundMgtCompany));
        return extractReturnList(getFondsSimples.execute(params));
    }

    @Override
    public List<portefeuilleDTO> getListeStructures(String p_auditor, String p_accountant, String p_fundMgtCompany) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_withAtLeastOneCompatiment", 1);
        params.put("p_auditor", normalize(p_auditor));
        params.put("p_accountant", normalize(p_accountant));
        params.put("p_fundMgtCompany", normalize(p_fundMgtCompany));
        return extractReturnList(getListeStructures.execute(params));
    }

    @Override
    public List<portefeuilleDTO> getListeCompartNonDispos(String p_auditor, String p_accountant, String p_fundMgtCompany) {
        Map<String, Object> params = new HashMap<>();
        params.put("P_AUDITOR", normalize(p_auditor));
        params.put("P_ACCOUNTANT", normalize(p_accountant));
        params.put("P_FUNDMGTCOMPANY", normalize(p_fundMgtCompany));
        return extractReturnList(getListeCompartsNonDispos.execute(params));
    }

    private portefeuilleDTO mapToPortefeuilleDTO(ResultSet rs, String codeColumn, String descColumn) throws SQLException {
        return new portefeuilleDTO(
                rs.getString(codeColumn),
                rs.getString(descColumn)
        );
    }

    private String normalize(String value) {
        if (value == null) return null;
        String v = value.trim();
        return v.isEmpty() ? null : v;
    }

    @SuppressWarnings("unchecked")
    private <T> List<T> extractReturnList(Map<String, Object> result) {
        Object value = result.get("RETURN_VALUE");
        return value == null ? Collections.emptyList() : (List<T>) value;
    }
}
