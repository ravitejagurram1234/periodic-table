package com.socgen.sgs.api.quark.backend.api.infra.dao;

import java.util.List;

public interface CheckStructureGabaritAssociationDao {
    /**
     * Calls the Oracle function CheckIfNoAssoStructsGabarit to check
     * if there are any structure associations for the given gabarit and funds.
     *
     * @param p_idGabarit the gabarit ID
     * @param p_listeFonds the list of funds (unselected) to check
     * @return the count of associated structures (0 if none, >0 if some exist)
     */
    Integer checkIfNoAssoStructsGabarit(Long p_idGabarit, List<String> p_listeFonds);
}
