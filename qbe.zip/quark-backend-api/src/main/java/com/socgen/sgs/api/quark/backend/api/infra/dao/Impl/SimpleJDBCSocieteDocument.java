package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.SocieteMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.TypeDeDocumentMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Societe;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SocieteDocumentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCSocieteDocument implements SocieteDocumentDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCSocieteDocument(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListTypeDocumentBySociete")
                .declareParameters(
                        new SqlOutParameter("RETURN", oracle.jdbc.OracleTypes.CURSOR, (rs, rowNum) -> TypeDeDocumentMapper.mapResult(rs)),
                        new SqlParameter("p_societe", Types.VARCHAR)
                );
    }

    @Override
    public List<TypeDeDocument> getSocieteDocument(String p_societe) {
        Map<String, Object> params = new HashMap<>();
        params.put( "p_societe", p_societe);
        Map<String, Object> result = simpleJdbcCall.execute(params);
        return (List<TypeDeDocument>) result.get("RETURN");
    }
}
