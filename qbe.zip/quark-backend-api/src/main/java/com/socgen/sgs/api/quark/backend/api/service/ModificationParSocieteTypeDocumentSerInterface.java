package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;

import java.util.List;

public interface ModificationParSocieteTypeDocumentSerInterface {
    List<TypeDeDocument> getListeTypesDocumentsDispos(String p_societe);
}
