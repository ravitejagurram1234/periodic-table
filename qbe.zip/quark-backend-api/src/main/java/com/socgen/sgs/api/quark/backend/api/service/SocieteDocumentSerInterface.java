package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;

import java.util.List;

public interface SocieteDocumentSerInterface {
    List<TypeDeDocument> getSocieteDocument(String p_societe);
}
