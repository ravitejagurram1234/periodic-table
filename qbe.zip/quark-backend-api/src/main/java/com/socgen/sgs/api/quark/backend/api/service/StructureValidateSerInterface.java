package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureRequestDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureResponseDTO;

public interface StructureValidateSerInterface {
    ValidateStructureResponseDTO validateStructure(ValidateStructureRequestDTO dto);
}
