package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureRequestDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureResponseDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditInsertTraceDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertStructureDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureValidateDao;
import com.socgen.sgs.api.quark.backend.api.service.IAuthenticationService;
import com.socgen.sgs.api.quark.backend.api.service.StructureValidateSerInterface;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

@Service
public class StructureValidateService implements StructureValidateSerInterface {

    private static final String STRUCTURE_DELETE_BLOCK_MESSAGE =
            "The removal of the link between the structure and a compartment can only be performed if no gabarit is associated.";

    private final InsertStructureDao insertStructureDao;
    private final StructureDao structureDao;
    private final StructureValidateDao structureValidateDao;
    private final AuditInsertTraceDao auditInsertTraceDao;
    private final IAuthenticationService authenticationService;

    public StructureValidateService(InsertStructureDao insertStructureDao,
                                    StructureDao structureDao,
                                    StructureValidateDao structureValidateDao,
                                    AuditInsertTraceDao auditInsertTraceDao,
                                    IAuthenticationService authenticationService) {
        this.insertStructureDao = insertStructureDao;
        this.structureDao = structureDao;
        this.structureValidateDao = structureValidateDao;
        this.auditInsertTraceDao = auditInsertTraceDao;
        this.authenticationService = authenticationService;
    }

    @Override
    @Transactional
    public ValidateStructureResponseDTO validateStructure(ValidateStructureRequestDTO dto) {

        // Step 0: Input validation
        validateInput(dto);

        String finalId = dto.getIdStructure().trim();
        List<String> submittedComparts = normalizeCompartiments(dto.getAllCompartiments());

        // Step 1: CREATE flow
        if (dto.isCreationMode()) {
            if (insertStructureDao.structureExists(finalId)) {
                audit(finalId, "Create structure rejected - already exists", 1);
                throw new IllegalStateException("Structure with ID " + finalId + " already exists");
            }

            insertStructureDao.insertStructure(
                    finalId, dto.getNom(), dto.getLibelleLong(), dto.getFndLegalType(),
                    dto.getFndClassification(), dto.getFndMngtCompany(), dto.getFndAccountant(),
                    dto.getCac(), dto.getDevise()
            );

            structureValidateDao.updateLiensStructCompartiments(finalId, submittedComparts);

            audit(finalId, "Create structure success", 0);
            return ValidateStructureResponseDTO.builder()
                    .success(true)
                    .message("Structure created successfully")
                    .idStructure(finalId)
                    .build();
        }

        // Step 2: UPDATE flow — structure must exist
        structureDao.getStructureById(finalId)
                .orElseThrow(() -> new IllegalArgumentException("Structure not found: " + finalId));

        // Step 3: Compute deleted compartments
        // allCompartiments = full final list the user wants to keep
        Set<String> selected = new HashSet<>(submittedComparts);
        List<String> currentComparts = structureValidateDao.getListeCompartsByStructure(finalId);

        List<String> deleted = currentComparts.stream()
                .filter(c -> !selected.contains(c))
                .toList();

        // Step 4: Block update if deleted compartments are still linked to gabarits
        if (!deleted.isEmpty()) {
            Integer blockedCount = structureValidateDao.checkIfNoAssoCompartsGabarit(finalId, deleted);
            if (blockedCount != null && blockedCount > 0) {
                audit(finalId, "Update structure rejected - associated gabarits exist", 1);
                throw new IllegalStateException(STRUCTURE_DELETE_BLOCK_MESSAGE);
            }
        }

        // Step 5: Persist structure metadata
        structureValidateDao.updateStructure(
                finalId, dto.getNom(), dto.getLibelleLong(), dto.getFndLegalType(),
                dto.getFndClassification(), dto.getFndMngtCompany(), dto.getFndAccountant(),
                dto.getCac(), dto.getDevise()
        );

        // Step 6: Persist structure-compartiment links (full final list)
        structureValidateDao.updateLiensStructCompartiments(finalId, submittedComparts);

        // Step 7: Audit success
        audit(finalId, "Update structure success", 0);

        return ValidateStructureResponseDTO.builder()
                .success(true)
                .message("Structure updated successfully")
                .idStructure(finalId)
                .build();
    }

    private void validateInput(ValidateStructureRequestDTO dto) {
        if (dto == null) {
            throw new IllegalArgumentException("Request body is mandatory");
        }
        if (dto.getIdStructure() == null || dto.getIdStructure().isBlank()) {
            throw new IllegalArgumentException("idStructure is mandatory");
        }
    }

    private List<String> normalizeCompartiments(List<String> compartiments) {
        if (compartiments == null) {
            return List.of();
        }
        return compartiments.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .distinct()
                .toList();
    }

    private void audit(String idStructure, String message, int statut) {
        try {
            Optional<String> user = authenticationService.getCurrentUserEmailId();
            BigDecimal responseTime = new Performance().getSecondsAndMilliseconds();

            Audit a = new Audit(
                    "N/A",
                    LocalDate.now(),
                    LocalDate.now(),
                    "/api/v1/structures/validate",
                    user.orElse("UNKNOWN"),
                    Chargement_constantes.MODULE_NAME,
                    Chargement_constantes.LIEN_STRUCTURE_COMP,
                    message,
                    "idStructure=" + idStructure,
                    "", "", "", "",
                    responseTime,
                    statut,
                    0,
                    ""
            );

            auditInsertTraceDao.insertTrace(a);
        } catch (Exception ignored) {
            // Do not fail business transaction because of audit failure
        }
    }
}
