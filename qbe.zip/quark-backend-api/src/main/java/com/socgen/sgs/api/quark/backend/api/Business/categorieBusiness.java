package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.categorieDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class categorieBusiness {
    @Autowired
    private categorieDao dao;

    public List<TypeDeDocument> getListeSousCategorie(int p_idCategorie, int p_checkAtLeastOneDocument) {
       return dao.getListeSousCategorie( p_idCategorie, p_checkAtLeastOneDocument);
    }
}