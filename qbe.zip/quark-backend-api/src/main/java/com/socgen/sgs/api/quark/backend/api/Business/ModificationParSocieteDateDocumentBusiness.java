package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteDateDocumentDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteTypesDocumentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@Transactional
public class ModificationParSocieteDateDocumentBusiness {
    @Autowired
    private ModificationParSocieteDateDocumentDao modificationParSocieteDateDocumentDao;

    public List<LocalDate> getDateDocuments(String p_societe, int p_id_sous_categorie) {

        List<java.sql.Date>port = modificationParSocieteDateDocumentDao.getDateDocuments(p_societe,p_id_sous_categorie);
        List<LocalDate>localdates=port.stream().filter(Objects::nonNull).map(java.sql.Date::toLocalDate).collect(Collectors.toList());

        return localdates;
    }
}



