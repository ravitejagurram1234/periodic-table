package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;
import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FundMgtCompanyDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.MaquettisteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class FundMgtCompanyBusiness {
    @Autowired
    private FundMgtCompanyDao dao;

    public List<FundMgtCompany> getFundMgtCompany(){
        return dao.getListFundMgtCompanies();
    }
}
