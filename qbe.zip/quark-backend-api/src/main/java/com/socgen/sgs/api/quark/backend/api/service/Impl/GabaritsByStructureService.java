package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.GabaritsByStructureBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritByStructure;
import com.socgen.sgs.api.quark.backend.api.service.GabaritsByStructureSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GabaritsByStructureService implements GabaritsByStructureSerInterface {

    @Autowired
    private GabaritsByStructureBusiness gabaritsByStructureBusiness;

    @Override
    public List<GabaritByStructure> getGabaritsByStructure(String p_idStructure) {
        return gabaritsByStructureBusiness.getGabaritsByStructure(p_idStructure);
    }
}
