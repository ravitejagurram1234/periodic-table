package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SuiviStructureDetails {
    private String  idStructure;
    private String nom;
    private String fndAccountant;
    private String fndMngtCompany;
    private Long idSuivi;
    private Long idStatutGeneration;
    private Integer typeSuivi;
    private String fndLegalType;
    private String fndClassification;
    private String fndAuditor;
//    private LocalDate dateLastEcheance;
    private String dateLastEcheance;
//    private LocalDate fndNextFiscalYearEnd;
    private String fndNextFiscalYearEnd;
    private LocalDate fndLastFiscalYearEnd;
}
