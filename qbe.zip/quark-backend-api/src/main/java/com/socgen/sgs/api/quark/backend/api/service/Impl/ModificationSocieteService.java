package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationSocieteBusiness;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationSocieteDao;
import com.socgen.sgs.api.quark.backend.api.service.ModificationSocieteSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ModificationSocieteService implements ModificationSocieteSerInterface{
    @Autowired
    private ModificationSocieteBusiness modificationSocieteBusiness;

    public List<String> getListSociete(){
        return modificationSocieteBusiness.getListSociete();
    }
}
