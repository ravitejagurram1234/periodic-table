package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.GabaritsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GabaritsMapper {
    public static Gabarits mapResult(ResultSet rs) throws SQLException{
        Gabarits g=new Gabarits();

        g.setId_gabarit(rs.getInt("ID_GABARIT"));
        g.setNom(rs.getString("NOM"));
        g.setId_type_rapport(rs.getLong("ID_TYPE_RAPPORT"));
        g.setId_langue(rs.getLong("ID_LANGUE"));
        g.setType_gabarit(rs.getLong("TYPE_GABARIT"));
        return  g;
    }

    public static GabaritsDTO toDto(Gabarits g){
      return new GabaritsDTO(g.getId_gabarit(),
              g.getNom()
              );
    }
}
