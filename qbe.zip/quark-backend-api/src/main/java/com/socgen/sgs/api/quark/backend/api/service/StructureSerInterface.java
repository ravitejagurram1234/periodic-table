package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Structure;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public interface StructureSerInterface {
    List<Structure> getListeStructuresForNewSuivi(Long idTypeRapport, Long idLangue, Long idGabarit, LocalDate dateEcheance) ;
    List<Structure> getListeStructures(String p_auditor, String p_accountant, String p_fundMgtCompany);

}
