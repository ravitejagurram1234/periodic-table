package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Suivi;

public interface InsertSuiviDao {
    Long insertSuivi(Suivi suivi);
}
