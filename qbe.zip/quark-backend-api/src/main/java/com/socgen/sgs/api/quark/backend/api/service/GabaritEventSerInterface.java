package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;

import java.util.List;

public interface GabaritEventSerInterface {
    List<GabaritEvents> getGabaritEvent(Long p_idGabarit);
}
