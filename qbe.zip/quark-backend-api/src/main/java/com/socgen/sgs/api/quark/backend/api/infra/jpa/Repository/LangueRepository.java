package com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository;

import com.socgen.sgs.api.quark.backend.api.infra.jpa.LangueData;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.LangueEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface LangueRepository  extends JpaRepository<LangueEntity,Long> {

    @Query(value = "SELECT ID_LANGUE_DOCUMENT AS id,NOM_LANGUE AS nomLangue ,VALEUR_LANGUE AS valeur_langue " +
            "FROM QXP_REF_LANGUE_DOCUMENT ORDER BY ID_LANGUE_DOCUMENT", nativeQuery = true)
    public List<LangueData> getLangue();
}
