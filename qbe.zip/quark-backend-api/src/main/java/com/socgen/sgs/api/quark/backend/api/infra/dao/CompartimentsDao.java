package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;

import java.util.List;

public interface CompartimentsDao {
    List<Compartiment> getStructures(String p_idStructure, String p_auditor, String p_accountant, String p_fundMgtCompany);

    }
