package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.GetGabaritTemplatesBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;
import com.socgen.sgs.api.quark.backend.api.service.GetGabaritTemplateSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GetGabaritTemplateService implements GetGabaritTemplateSerInterface {
    @Autowired
    private GetGabaritTemplatesBusiness getGabaritTemplatesBusiness;

    public GabaritTemplate getGabaritTemplate(Long p_idGabaritTemplate){
        return getGabaritTemplatesBusiness.getGabaritTemplates(p_idGabaritTemplate);
    }
}
