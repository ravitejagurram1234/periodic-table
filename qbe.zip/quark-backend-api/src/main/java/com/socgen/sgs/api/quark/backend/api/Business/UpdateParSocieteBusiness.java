package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateParSocieteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class UpdateParSocieteBusiness {
    @Autowired
    private UpdateParSocieteDao updateParSocieteDao;

    public void updateParSociete(Document document){
         updateParSocieteDao.updateParSociete(document);
    }
}
