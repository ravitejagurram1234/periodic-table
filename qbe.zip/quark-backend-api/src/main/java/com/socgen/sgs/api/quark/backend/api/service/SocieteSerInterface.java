package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Societe;

import java.util.List;

public interface SocieteSerInterface {
    List<Societe> getSociete();
}
