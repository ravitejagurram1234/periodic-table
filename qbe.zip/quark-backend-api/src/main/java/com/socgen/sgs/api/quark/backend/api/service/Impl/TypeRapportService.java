package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.TypeRapportBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.TypeRapport;
import com.socgen.sgs.api.quark.backend.api.service.TypeRapportSerInterface;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TypeRapportService implements TypeRapportSerInterface {
    private static final Logger log = LoggerFactory.getLogger(TypeRapportService.class);
    @Autowired
    private TypeRapportBusiness business;

    public List<TypeRapport> getTypeRapport() {
        log.info("Fetching ");
        return business.getTypeRapport();
    }

}
