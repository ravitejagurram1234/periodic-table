package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Chargement_gabaritDTO {
    private MultipartFile file;
    private int p_id_type_rapport;
    private int p_id_langue;
    private int p_type;
    private int p_id_sous_categorie;
    private int p_id_gabarit_template;
    private int p_pagination_double;

}
