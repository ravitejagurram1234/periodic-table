package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;

public interface GetGabaritTemplateSerInterface {
    GabaritTemplate getGabaritTemplate(Long p_idGabaritTemplate);
}
