package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.PrevSuiviEvents;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviStructureDetails;

import java.time.LocalDate;
import java.util.List;

public interface PrevSuiviDao {
    List<PrevSuiviEvents> getPrevSuiviEvents(String p_id, String p_id_unit_code, Long p_id_type_rapport, Long p_id_langue, LocalDate p_date_echeance, Long p_id_gabarit);
}
