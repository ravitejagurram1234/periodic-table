package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TypeDeDocumentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class TypeDeDocumentBusiness {
    @Autowired
    private TypeDeDocumentDao typeDeDocumentDao;

    public List<TypeDeDocument> getTypeDocument(String p_id_fnd_code , Long p_typeCategorieDocument){
     return typeDeDocumentDao.getTypeDocument(p_id_fnd_code,p_typeCategorieDocument);
    }
}