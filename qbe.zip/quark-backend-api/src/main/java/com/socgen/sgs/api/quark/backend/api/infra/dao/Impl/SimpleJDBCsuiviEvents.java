package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;


import com.socgen.sgs.api.quark.backend.api.Mapper.SuiviEventsMapper;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviEventDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCsuiviEvents implements SuiviEventDao{

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCsuiviEvents(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetListeSuiviEventsBySuivi")
                .declareParameters(
                        new SqlOutParameter("RETURN", oracle.jdbc.OracleTypes.CURSOR, (rs, rowNum) -> SuiviEventsMapper.mapResult(rs)),
                        new SqlParameter("p_idSuivi", Types.NUMERIC)
                );
    }

    @Override
    public List<SuiviEvents> getSuiviEvents(Long p_idSuivi) {
        Map<String, Object> result = simpleJdbcCall.execute(Map.of("p_idSuivi", p_idSuivi));
        return (List<SuiviEvents>) result.get("RETURN");
    }
}
