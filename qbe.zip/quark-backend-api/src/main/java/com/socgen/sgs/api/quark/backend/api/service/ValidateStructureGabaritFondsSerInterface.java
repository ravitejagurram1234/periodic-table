// src/main/java/.../service/ValidateStructureGabaritFondsSerInterface.java
package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.StructureGabaritFondsResponseDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureGabaritFondsDTO;
import jakarta.servlet.http.HttpServletRequest;

public interface ValidateStructureGabaritFondsSerInterface {
    StructureGabaritFondsResponseDTO validateAndLinkCompartiments(
            ValidateStructureGabaritFondsDTO dto, HttpServletRequest request);
}
