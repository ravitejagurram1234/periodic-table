package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompartimentDispoDTO {
    private String idFndCode;
    private String nom;
}
