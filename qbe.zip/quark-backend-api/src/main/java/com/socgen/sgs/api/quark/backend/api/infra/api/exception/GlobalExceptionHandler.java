package com.socgen.sgs.api.quark.backend.api.infra.api.exception;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.ConversionFailedException;
import org.springframework.http.HttpStatus;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import jakarta.validation.ConstraintViolationException;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

  @ExceptionHandler({ ConstraintViolationException.class, ConversionFailedException.class })
  public ErrorResponse conversionErrorsComeFromMisuseOfTheApi(Exception e) {
    return ErrorResponse.builder(e, HttpStatus.BAD_REQUEST, "Please review the API documentation at URL /api-docs").build();
  }
}
