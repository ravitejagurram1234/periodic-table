package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ValidateLiensFondsGabaritDTO {
    private Long idTypeRapport;   // mandatory
    private Long idGabarit;       // mandatory
    private Long idLangue;        // mandatory
    private String auditor;       // nullable
    private String accountant;    // nullable
    private String fundMgtCompany;// nullable
    private List<String> listeFonds;
}
