package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Devise;

import java.util.List;

public interface DeviseDao {
    List<Devise> getListeDevises();
}
