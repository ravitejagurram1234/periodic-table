package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationPortefeuilleBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.service.ModificationPortefeuilleSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ModificationPortefeuilleService implements ModificationPortefeuilleSerInterface {
    @Autowired
    private ModificationPortefeuilleBusiness modificationPortefeuilleBusiness;

    public List<portefeuille> getListPortefeuille(int p_id_sous_categorie){
        return modificationPortefeuilleBusiness.getListPortefeuille(p_id_sous_categorie);
    }
}
