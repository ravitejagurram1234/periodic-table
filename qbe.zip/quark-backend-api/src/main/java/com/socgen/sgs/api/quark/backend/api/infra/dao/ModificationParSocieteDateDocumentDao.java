package com.socgen.sgs.api.quark.backend.api.infra.dao;

import java.sql.Date;
import java.util.List;

public interface ModificationParSocieteDateDocumentDao {
    List<Date> getDateDocuments(String p_societe, int p_id_sous_categorie);
}
