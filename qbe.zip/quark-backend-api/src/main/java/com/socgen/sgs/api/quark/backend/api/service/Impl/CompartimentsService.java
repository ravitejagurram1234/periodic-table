package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.CompartimentsBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.service.CompartimentsSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CompartimentsService implements CompartimentsSerInterface{
    @Autowired
    private CompartimentsBusiness compartimentsBusiness;

    public List<Compartiment> getStructures(String p_idStructure, String p_auditor, String p_accountant, String p_fundMgtCompany){
        return compartimentsBusiness.getStructures(p_idStructure,p_auditor,p_accountant,p_fundMgtCompany);
    }
}
