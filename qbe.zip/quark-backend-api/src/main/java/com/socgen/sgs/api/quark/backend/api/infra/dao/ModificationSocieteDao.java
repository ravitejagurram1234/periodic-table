package com.socgen.sgs.api.quark.backend.api.infra.dao;

import java.util.List;

public interface ModificationSocieteDao {
    List<String> getListSociete();
}
