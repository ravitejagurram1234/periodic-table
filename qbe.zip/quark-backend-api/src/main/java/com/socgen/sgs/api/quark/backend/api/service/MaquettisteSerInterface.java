package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;

import java.util.List;

public interface MaquettisteSerInterface {
    List<Maquettiste> getMaquettiste();
}
