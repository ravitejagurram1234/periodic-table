package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.InsertTraceDTO;
import com.socgen.sgs.api.quark.backend.api.domain.InsertTrace;

public class SuiviAuditMapper {
    public static InsertTrace toDomain(InsertTraceDTO dto) {
        return InsertTrace.builder()
                .p_ip(dto.getP_ip())
                .p_startTime(dto.getP_startTime())
                .p_endTime(dto.getP_endTime())
                .p_page(dto.getP_page())
                .p_login(dto.getP_login())
                .p_module(dto.getP_module())
                .p_fonction(dto.getP_fonction())
                .p_message(dto.getP_message())
                .p_param1(dto.getP_param1())
                .p_param2(dto.getP_param2())
                .p_param3(dto.getP_param3())
                .p_param4(dto.getP_param4())
                .p_param5(dto.getP_param5())
                .p_temps_reponse(dto.getP_temps_reponse())
                .p_statut(dto.getP_statut())
                .p_id_application(dto.getP_id_application())
                .p_nom_application(dto.getP_nom_application())
                .build();
    }
}
