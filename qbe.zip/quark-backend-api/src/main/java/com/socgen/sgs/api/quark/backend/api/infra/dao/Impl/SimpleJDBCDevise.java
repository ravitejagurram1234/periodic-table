package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.DeviseMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Devise;
import com.socgen.sgs.api.quark.backend.api.infra.dao.DeviseDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCDevise implements DeviseDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCDevise(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withFunctionName("GetListeDevises")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR,
                                (rs, rowNum) -> DeviseMapper.mapResult(rs))
                );
    }

    @Override
    public List<Devise> getListeDevises() {
        try {
            Map<String, Object> result = simpleJdbcCall.execute();
            return (List<Devise>) result.get("RETURN_VALUE");
        } catch (Exception e) {
            System.err.println("Error during GetListeDevises JDBC call: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
}
