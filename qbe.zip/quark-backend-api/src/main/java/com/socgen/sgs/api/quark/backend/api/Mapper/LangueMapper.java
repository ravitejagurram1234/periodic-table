package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.LangueDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Langue;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.LangueData;

public class LangueMapper {
    public static Langue mapDetails(LangueData data) {
        if (data == null) {
            return null;
        }
        Long id = data.getId();
        long primitiveId = (id != null) ? id : 0L; // Provide default value for null id
        String nomLangue = data.getNomLangue();
        String valeur_langue = data.getValeurLangue();

        return Langue.builder()
                .id(primitiveId)
                .nomLangue(nomLangue != null ? nomLangue : "")
                .valeur_langue(valeur_langue!=null? valeur_langue:"")
                .build();
    }

    public static LangueDTO toDto(Langue domain){
        if(domain==null){
            return null;
        }
        return new LangueDTO(domain.getId(), domain.getNomLangue());
    }
}
