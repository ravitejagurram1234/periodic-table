package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Langue;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.LangueData;

import java.util.List;

public interface LangueSerInterface {
    List<Langue> getLangue();
}
