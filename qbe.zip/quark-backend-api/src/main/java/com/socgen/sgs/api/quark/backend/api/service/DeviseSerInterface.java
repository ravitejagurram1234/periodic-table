package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Devise;

import java.util.List;

public interface DeviseSerInterface {
    List<Devise> getListeDevises();
}
