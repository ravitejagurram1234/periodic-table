package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.GabaritsMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritsDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCgabarit implements GabaritsDao {

    public final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCgabarit (DataSource dataSource) {

        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetGabarits")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> GabaritsMapper.mapResult(rs)),
                        new SqlParameter("P_IDTYPERAPPORT", Types.NUMERIC),
                        new SqlParameter("P_IDLANGUE", Types.NUMERIC),
                        new SqlParameter("P_ONLYACTIVE", Types.INTEGER)
                );
    }


    @Override
    public List<Gabarits> getGabarits(Long p_idTypeRapport, Long p_idLangue, int p_onlyActive) {
        Map<String, Object> params = Map.of(
                "P_IDTYPERAPPORT", p_idTypeRapport,
                "P_IDLANGUE", p_idLangue,
                "P_ONLYACTIVE", p_onlyActive
        );
        Map<String, Object> result = simpleJdbcCall.execute(params);
        return (List<Gabarits>) result.get("RETURN_VALUE");
    }
    }

