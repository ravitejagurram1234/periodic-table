package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateCompartimentsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCupdateCompartiments implements UpdateCompartimentsDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCupdateCompartiments(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withProcedureName("UpdateCompartimentInfos")
                .declareParameters(
                        new SqlParameter("p_idFndCode", Types.VARCHAR),
                        new SqlParameter("p_libelleCompartiment", Types.VARCHAR),
                        new SqlParameter("p_dateFinCompartiment", Types.DATE),
                        new SqlParameter("p_presentationEcoGeo", Types.VARCHAR)
                );
    }

    public void updateCompartimentInfos(Compartiment compartiment) {
        Date sqlDate1= (compartiment.getDate_fin_compartiment()!=null)?java.sql.Date.valueOf(compartiment.getDate_fin_compartiment()):null;

        Map<String, Object> params = new HashMap<>();
        params.put("p_idFndCode", compartiment.getId_fnd_code());
        params.put("p_libelleCompartiment", compartiment.getLibelle_compartiment());
        params.put("p_dateFinCompartiment", sqlDate1);
        params.put("p_presentationEcoGeo", (compartiment.getPresentation_eco_geo()==null || compartiment.getPresentation_eco_geo().isEmpty())?null:compartiment.getPresentation_eco_geo());

        simpleJdbcCall.execute(params);
    }
}
