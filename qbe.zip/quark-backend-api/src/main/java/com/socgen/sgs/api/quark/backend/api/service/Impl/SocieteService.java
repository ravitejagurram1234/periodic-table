package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.SocieteBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Societe;
import com.socgen.sgs.api.quark.backend.api.service.SocieteSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SocieteService implements SocieteSerInterface {
    @Autowired
    private SocieteBusiness business;

    public List<Societe> getSociete() {
        return business.getSociete();
    }
}