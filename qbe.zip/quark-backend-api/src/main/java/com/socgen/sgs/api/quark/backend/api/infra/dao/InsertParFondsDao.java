package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Document;

import javax.print.Doc;

public interface InsertParFondsDao {
    void insertParFonds(Document document);
}
