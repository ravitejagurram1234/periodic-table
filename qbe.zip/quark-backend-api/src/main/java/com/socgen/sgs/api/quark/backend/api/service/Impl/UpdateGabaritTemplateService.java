package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AuditParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.UpdateGabaritTemplateBusiness;
import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.gabaritTemplateDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.service.UpdateGabaritTemplateSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;

@Service
public class UpdateGabaritTemplateService implements UpdateGabaritTemplateSerInterface {

    @Autowired
    private UpdateGabaritTemplateBusiness updateGabaritTemplateBusiness;

    @Autowired
    private AuditParFondsBusiness auditParFondsBusiness;

    @Override
    public void updateGabaritTemplate(MultipartFile file, gabaritTemplateDTO dto, String commentaire) {
        int taille_document = (int) file.getSize();

        try {
            // Map DTO to domain object
            Chargement_gabarit gabarit = new Chargement_gabarit(
                    dto.getNom(),
                    file.getBytes(),
                    commentaire
            );
            gabarit.setP_idGabaritTemplate((long) dto.getId_gabarit_template());
            gabarit.setP_taille_gabarit(taille_document);

            // Call business layer to update
            updateGabaritTemplateBusiness.updateGabaritTemplate(gabarit);

        } catch (IOException e) {
            throw new RuntimeException("Error reading file bytes: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new RuntimeException("Error updating gabarit template: " + e.getMessage(), e);
        }
    }

    @Override
    public String getClientIp(HttpServletRequest request) {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.isEmpty() || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }

    @Override
    public Integer auditUpdateGabaritTemplate(MultipartFile file, gabaritTemplateDTO dto, String page, String user, HttpServletRequest request) {
        String originalFilename = file.getOriginalFilename();

        Performance performance = new Performance();
        LocalDate start = LocalDate.now();
        LocalDate end = LocalDate.now();

        BigDecimal responseTime = performance.getSecondsAndMilliseconds();
        String clientIp = getClientIp(request);

        String param1 = "Id gabarit template : " + dto.getId_gabarit_template();
        String param2 = "Nom gabarit : " + dto.getNom();
        String param3 = "Taille fichier : " + file.getSize() + " bytes";
        String param4 = "Type fichier : " + file.getContentType();
        String param5 = "Nom original fichier : " + originalFilename;
        String p_message = "Modification gabarit template effectuée avec succès";

        Audit audit = new Audit(clientIp, start, end, page, user, Chargement_constantes.MODULE_NAME, "UpdateGabaritTemplate",
                p_message, param1, param2, param3, param4, param5, responseTime, 0, 0, "");

        return auditParFondsBusiness.AuditParFonds(audit);
    }
}
