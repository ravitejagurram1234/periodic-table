package com.socgen.sgs.api.quark.backend.api.Dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SuiviStructureDetailsDTO {
    private String idStructure;
    private String nom;
//    private LocalDate fndNextFiscalYearEnd;
//    private LocalDate dateLastEcheance;
    private String fndNextFiscalYearEnd;
    private String dateLastEcheance;
    private String fndLegalType;
    private String fndMngtCompany;
    private String fndClassification;
    private String fndAccountant;
    private String fndAuditor;

}
