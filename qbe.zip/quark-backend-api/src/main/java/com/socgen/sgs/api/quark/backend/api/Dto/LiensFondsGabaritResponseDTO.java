package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LiensFondsGabaritResponseDTO {
    private boolean success;
    private String message;
    private LocalDateTime timestamp;
    private int fondsLinked;
    private Long idGabarit;
    private Long idTypeRapport;
    private String errorCode;
}
