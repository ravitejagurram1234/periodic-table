package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FundMgtCompany {
    private String idMgtCode;

    private FundMgtCompany(Builder builder) {
        this.idMgtCode= builder.idMgtCode;
    }


    public static Builder builder() {
        return new Builder();
    }


    public static class Builder {
        private String idMgtCode;


        public Builder idMgtCode(String idMgtCode) {
            this.idMgtCode = idMgtCode;
            return this;
        }

        public FundMgtCompany build() {
           return new FundMgtCompany(this);
        }
    }
}
