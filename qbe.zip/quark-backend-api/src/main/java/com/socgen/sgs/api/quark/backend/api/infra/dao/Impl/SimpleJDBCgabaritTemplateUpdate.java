package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateUpdateDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

@Repository
public class SimpleJDBCgabaritTemplateUpdate implements GabaritTemplateUpdateDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCgabaritTemplateUpdate(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withProcedureName("UpdateGabaritTemplate")
                .declareParameters(
                        new SqlParameter("p_idGabaritTemplate", Types.NUMERIC),
                        new SqlParameter("p_nom", Types.VARCHAR),
                        new SqlParameter("p_contenu", Types.VARBINARY),
                        new SqlParameter("p_commentaire", Types.VARCHAR)
                );
    }

    @Override
    public void updateGabaritTemplate(Chargement_gabarit gabarit) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("p_idGabaritTemplate", gabarit.getP_idGabaritTemplate());
            params.put("p_nom", gabarit.getP_nom_gabarit_template());
            params.put("p_contenu", gabarit.getP_contenu());
            params.put("p_commentaire", gabarit.getP_commentaire());

            simpleJdbcCall.execute(params);
        } catch (DataAccessException e) {
            throw new RuntimeException("Failed to update gabarit template: " + e.getMessage(), e);
        }
    }
}
