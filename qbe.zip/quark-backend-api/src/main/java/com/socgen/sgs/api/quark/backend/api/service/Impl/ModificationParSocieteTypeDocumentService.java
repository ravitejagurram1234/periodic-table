package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationParSocieteTypeDocumentBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteTypesDocumentDao;
import com.socgen.sgs.api.quark.backend.api.service.ModificationParSocieteTypeDocumentSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ModificationParSocieteTypeDocumentService implements ModificationParSocieteTypeDocumentSerInterface {
    @Autowired
    private ModificationParSocieteTypeDocumentBusiness modificationParSocieteTypesDocumentBusiness;

    public List<TypeDeDocument> getListeTypesDocumentsDispos(String p_societe){
        return modificationParSocieteTypesDocumentBusiness.getListeTypesDocumentsDispos(p_societe);
    }
}
