package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Compartiment {
        private String key_ref_fund;
        private String id_fnd_code;
        private LocalDate id_fnd_start_validity;
        private LocalDate fnd_end_validity;
        private String fnd_sht_description;
        private String fnd_lng_description;
        private String fnd_flg_multi_mngr;
        private String fnd_chart_account;
        private String fnd_accountant;
        private String id_act_code;
        private String act_socio_class;
        private String act_lng_description;
        private String id_mng_code;
        private String devise_poche;
        private String mng_lng_description;
        private String mngShtDescription;
        private String id_mfm_manager_code;
        private LocalDate fnd_last_fiscal_year_end;
        private LocalDate fnd_next_fiscal_year_end;
        private String mfm_actor;
        private String libelle_compartiment;
        private LocalDate date_fin_compartiment;
        private String presentation_eco_geo;
}
