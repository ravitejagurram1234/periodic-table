package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.FundMgtCompanyDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.MaquettisteDTO;
import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;
import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FundMgtCompanyMapper {
    public static FundMgtCompany mapResult(ResultSet rs) throws SQLException {
        FundMgtCompany company = new FundMgtCompany();
        company.setIdMgtCode(rs.getString("ID_MGT_CODE"));
        return company;
    }

    public static FundMgtCompanyDTO toDto(FundMgtCompany domain){

        return new FundMgtCompanyDTO(domain.getIdMgtCode());
    }

}
