package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.*;

import java.sql.Types;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Chargement_gabarit {

        private int p_id_type_rapport;
        private String nom_gabarit;
        private int p_id_langue;
        private byte[] p_contenu;
        private int p_taille_gabarit;
        private int p_is_actif;
        private int p_type;
        private int p_id_sous_categorie;
        private Long p_idGabaritTemplate;
        private int p_id_gabarit_template;
        private int p_pagination_double;
        private String p_commentaire;
        private String  p_nom_gabarit_template;

        public Chargement_gabarit(String p_nom_gabarit_template , byte[] p_contenu, String p_commentaire) {
        this.p_nom_gabarit_template=p_nom_gabarit_template;
        this.p_contenu=p_contenu;
        this.p_commentaire=p_commentaire;
        }
}
