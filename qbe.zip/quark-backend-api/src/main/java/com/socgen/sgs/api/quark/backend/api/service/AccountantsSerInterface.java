package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Accountants;

import java.util.List;

public interface AccountantsSerInterface {

    List<Accountants> getListAccountants();
}
