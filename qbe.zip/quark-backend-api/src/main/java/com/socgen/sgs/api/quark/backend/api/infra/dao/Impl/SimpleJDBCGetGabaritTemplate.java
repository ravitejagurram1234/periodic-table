package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;


import com.socgen.sgs.api.quark.backend.api.Mapper.GabaritTemplateMapper;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GetGabaritTemplateDao;
import oracle.jdbc.internal.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCGetGabaritTemplate implements GetGabaritTemplateDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCGetGabaritTemplate(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetGabaritTemplate")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> GabaritTemplateMapper.mapResultgabaritemplate(rs)),
                        new SqlParameter("p_idGabaritTemplate", Types.NUMERIC)
                );
    }

    @Override
    public GabaritTemplate getGabaritTemplates(Long p_idGabaritTemplate) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_idGabaritTemplate", p_idGabaritTemplate);

        Map<String, Object> result = simpleJdbcCall.execute(params);
        return ((List<GabaritTemplate>) result.get("RETURN_VALUE")).stream().findFirst().orElse(null);
    }

}
