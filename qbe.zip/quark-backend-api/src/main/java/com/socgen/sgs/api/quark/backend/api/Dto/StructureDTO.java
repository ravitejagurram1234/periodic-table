package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StructureDTO {
    private String idStructure;
    private String nom;
    private String libelleLong;
    private String fndLegalType;
    private String fndClassification;
    private String fndMngtCompany;
    private String fndAccountant;
    private String cac;
    private String devise;
}
