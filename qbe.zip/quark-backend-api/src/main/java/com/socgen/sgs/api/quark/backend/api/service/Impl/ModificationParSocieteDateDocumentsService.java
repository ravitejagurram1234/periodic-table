package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationParSocieteDateDocumentBusiness;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteDateDocumentDao;
import com.socgen.sgs.api.quark.backend.api.service.ModificationParSocieteDateDocumentSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ModificationParSocieteDateDocumentsService implements ModificationParSocieteDateDocumentSerInterface{
    @Autowired
    private ModificationParSocieteDateDocumentBusiness modificationParSocieteDateDocumentBusiness;

    public List<LocalDate> getDateDocuments(String p_societe , int p_id_sous_categorie){
        return modificationParSocieteDateDocumentBusiness.getDateDocuments(p_societe,p_id_sous_categorie);
    }
}
