package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.ModificationGabaritDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GabaritMapper {

    public static Gabarit mapResult(final ResultSet rs) throws SQLException {
        return Gabarit.builder()
                .nom(rs.getString("nom"))
                .id_type_rapport(rs.getLong("id_type_rapport"))
                .is_actif(rs.getBoolean("is_actif"))
                .taille_document(rs.getLong("taille_document"))
                .id_langue(rs.getLong("id_langue"))
                .type(rs.getLong("type"))
                .id_sous_categorie(rs.getInt("id_sous_categorie"))
                .id_gabarit_template(rs.getInt("id_gabarit_template"))
                .pagination_double(rs.getBoolean("pagination_double"))
                .generate_to_word(rs.getInt("generate_to_word"))
                .contenu(rs.getBytes("contenu"))
                .build();
    }

    public static ModificationGabaritDTO toDto(final Gabarit domain) {
        ModificationGabaritDTO dto = new ModificationGabaritDTO();
        dto.setIs_actif(domain.getIs_actif());
        dto.setType(domain.getType());
        dto.setId_gabarit_template(domain.getId_gabarit_template());
        dto.setPagination_double(domain.getPagination_double());
        return dto;
    }

}

