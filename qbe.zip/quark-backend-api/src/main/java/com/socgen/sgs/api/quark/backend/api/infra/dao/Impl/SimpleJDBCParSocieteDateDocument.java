package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteDateDocumentDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCParSocieteDateDocument implements ModificationParSocieteDateDocumentDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCParSocieteDateDocument(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeDatesDisposSociete")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> rs.getDate("date_document")),
                        new SqlParameter("p_societe", Types.VARCHAR),
                        new SqlParameter("p_id_sous_categorie", Types.NUMERIC)

                );
    }

    @Override
    public List<Date> getDateDocuments(String p_societe,int p_id_sous_categorie) {
        Map<String, Object> params = new HashMap<>();

        params.put("p_societe", p_societe);
        params.put("p_id_sous_categorie", p_id_sous_categorie);
        Map<String, Object> result = simpleJdbcCall.execute(params);
        return (List<Date>) result.get("RETURN_VALUE");
    }
}

