package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Document {
    private Long p_id_document;
    private String p_societe;
    private String p_id_fnd_code;
    private String p_id_unit_code;
    private Long p_id_sous_categorie;
    private String p_format;
    private Long p_id_langue;
    private LocalDate p_date_document;
    private LocalDate p_old_date;
    private String p_nom_document;
    private Long p_id_utilisateur;
    private String p_email;
    private byte[] p_contenu;
    private int p_taille_document;
    private Long p_is_actif;
    private Long p_for_all_part;
}
