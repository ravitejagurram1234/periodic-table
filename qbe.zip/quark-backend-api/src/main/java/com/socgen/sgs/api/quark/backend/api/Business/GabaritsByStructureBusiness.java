package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritByStructure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritsByStructureDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GabaritsByStructureBusiness {

    @Autowired
    private GabaritsByStructureDao gabaritsByStructureDao;

    public List<GabaritByStructure> getGabaritsByStructure(String p_idStructure) {
        return gabaritsByStructureDao.getGabaritsByStructure(p_idStructure);
    }
}
