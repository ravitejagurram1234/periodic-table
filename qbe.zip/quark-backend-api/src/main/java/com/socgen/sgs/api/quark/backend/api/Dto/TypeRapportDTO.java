package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TypeRapportDTO {
    private Long id;
    private String libelle;
}
