package com.socgen.sgs.api.quark.backend.api.Mapper;


import com.socgen.sgs.api.quark.backend.api.Dto.AuditorDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Auditor;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AuditorMapper {
    public static Auditor mapResult(ResultSet rs) throws SQLException {
        Auditor auditor=new Auditor();
        auditor.setDesTableValue(rs.getString("DES_TABLE_VALUE"));
        return auditor;
    }

    public static AuditorDTO toDto(Auditor domain){

        return new AuditorDTO(domain.getDesTableValue());
    }
}
