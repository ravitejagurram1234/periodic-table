package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

import java.nio.channels.MulticastChannel;

public interface UpdateParFondsSerInterface {
    void updateDocument(MultipartFile file, DocumentDTO dto);
    String getClientIp(HttpServletRequest request);
    Integer AuditUpdateParFonds(MultipartFile file,DocumentDTO dto,String page, String user, HttpServletRequest request);
}
