package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PortfolioSelectedDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCPortfolioSelected implements PortfolioSelectedDao {

    private final SimpleJdbcCall getFondsSimplesByGabarit;
    private final SimpleJdbcCall getCompartsByGabarit;
    private final SimpleJdbcCall getStructuresByGabarit;

    @Autowired
    public SimpleJDBCPortfolioSelected(DataSource dataSource) {

        this.getFondsSimplesByGabarit = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetFondsSimplesByGabarit")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR,
                                (rs, rowNum) -> mapToPortefeuilleDTO(rs, "ID_FND_CODE", "FND_SHT_DESCRIPTION")),
                        new SqlParameter("P_IDTYPERAPPORT", Types.NUMERIC),
                        new SqlParameter("P_IDGABARIT", Types.NUMERIC),
                        new SqlParameter("P_IDLANGUE", Types.NUMERIC),
                        new SqlParameter("P_AUDITOR", Types.VARCHAR),
                        new SqlParameter("P_ACCOUNTANT", Types.VARCHAR),
                        new SqlParameter("P_FUNDMGTCOMPANY", Types.VARCHAR)
                );

        this.getCompartsByGabarit = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeCompartsByGabarit")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR,
                                (rs, rowNum) -> mapToPortefeuilleDTO(rs, "ID_FND_CODE", "LIBELLE_COMPARTIMENT")),
                        new SqlParameter("P_IDTYPERAPPORT", Types.NUMERIC),
                        new SqlParameter("P_IDGABARIT", Types.NUMERIC),
                        new SqlParameter("P_IDLANGUE", Types.NUMERIC)
                );

        this.getStructuresByGabarit = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeStructuresByGabarit")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR,
                                (rs, rowNum) -> mapToPortefeuilleDTO(rs, "ID_STRUCTURE", "NOM")),
                        new SqlParameter("P_IDTYPERAPPORT", Types.NUMERIC),
                        new SqlParameter("P_IDGABARIT", Types.NUMERIC),
                        new SqlParameter("P_IDLANGUE", Types.NUMERIC),
                        new SqlParameter("P_AUDITOR", Types.VARCHAR),
                        new SqlParameter("P_ACCOUNTANT", Types.VARCHAR),
                        new SqlParameter("P_FUNDMGTCOMPANY", Types.VARCHAR)
                );
    }

    @Override
    public List<portefeuilleDTO> getFondsSimplesByGabarit(Long p_idTypeRapport, Long p_idGabarit, Long p_idLangue,
                                                          String p_auditor, String p_accountant, String p_fundMgtCompany) {
        Map<String, Object> params = new HashMap<>();
        params.put("P_IDTYPERAPPORT", p_idTypeRapport);
        params.put("P_IDGABARIT", p_idGabarit);
        params.put("P_IDLANGUE", p_idLangue);
        params.put("P_AUDITOR", p_auditor);
        params.put("P_ACCOUNTANT", p_accountant);
        params.put("P_FUNDMGTCOMPANY", p_fundMgtCompany);
        return extractReturnList(getFondsSimplesByGabarit.execute(params));
    }

    @Override
    public List<portefeuilleDTO> getListeCompartsByGabarit(Long p_idTypeRapport, Long p_idGabarit, Long p_idLangue) {
        Map<String, Object> params = new HashMap<>();
        params.put("P_IDTYPERAPPORT", p_idTypeRapport);
        params.put("P_IDGABARIT", p_idGabarit);
        params.put("P_IDLANGUE", p_idLangue);
        return extractReturnList(getCompartsByGabarit.execute(params));
    }

    @Override
    public List<portefeuilleDTO> getListeStructuresByGabarit(Long p_idTypeRapport, Long p_idGabarit, Long p_idLangue,
                                                             String p_auditor, String p_accountant, String p_fundMgtCompany) {
        Map<String, Object> params = new HashMap<>();
        params.put("P_IDTYPERAPPORT", p_idTypeRapport);
        params.put("P_IDGABARIT", p_idGabarit);
        params.put("P_IDLANGUE", p_idLangue);
        params.put("P_AUDITOR", p_auditor);
        params.put("P_ACCOUNTANT", p_accountant);
        params.put("P_FUNDMGTCOMPANY", p_fundMgtCompany);
        return extractReturnList(getStructuresByGabarit.execute(params));
    }

    private portefeuilleDTO mapToPortefeuilleDTO(ResultSet rs, String codeColumn, String descColumn) throws SQLException {
        return new portefeuilleDTO(
                rs.getString(codeColumn),
                rs.getString(descColumn)
        );
    }

    @SuppressWarnings("unchecked")
    private <T> List<T> extractReturnList(Map<String, Object> result) {
        Object value = result.get("RETURN_VALUE");
        return value == null ? Collections.emptyList() : (List<T>) value;
    }
}
