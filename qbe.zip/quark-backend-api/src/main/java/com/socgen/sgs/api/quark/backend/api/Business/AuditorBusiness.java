package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Accountants;
import com.socgen.sgs.api.quark.backend.api.domain.Auditor;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AccountantsDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditorDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class AuditorBusiness {
    @Autowired
    private AuditorDao dao;

    public List<Auditor> getAuditors(){
        return dao.getListAuditors();
    }
}
