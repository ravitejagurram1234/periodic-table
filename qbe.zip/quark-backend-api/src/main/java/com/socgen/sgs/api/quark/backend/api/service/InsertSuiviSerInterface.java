package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.InsertTraceDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Suivi;
import jakarta.servlet.http.HttpServletRequest;

public interface InsertSuiviSerInterface {
    Long insertSuivi(SuiviDTO suivi);
    Long InsertTrace(SuiviDTO suivi, HttpServletRequest request);
    void InsertEvent(SuiviDTO suivi,Long p_idSuivi, Long p_idUser);
}
