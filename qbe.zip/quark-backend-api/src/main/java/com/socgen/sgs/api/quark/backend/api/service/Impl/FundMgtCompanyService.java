package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.FondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.FundMgtCompanyBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Fonds;
import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FundMgtCompanyDao;
import com.socgen.sgs.api.quark.backend.api.service.FundMgtCompanySerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class FundMgtCompanyService implements FundMgtCompanySerInterface {
    @Autowired
    private FundMgtCompanyBusiness fundMgtCompanyBusiness;
    public List<FundMgtCompany> getListFundMgtCompanies() {
        return fundMgtCompanyBusiness.getFundMgtCompany();
    }
}
