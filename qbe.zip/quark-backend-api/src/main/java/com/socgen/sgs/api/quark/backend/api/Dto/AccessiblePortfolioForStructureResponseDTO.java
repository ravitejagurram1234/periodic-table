package com.socgen.sgs.api.quark.backend.api.Dto;

import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

@Schema(name = "AccessiblePortfolioForStructureResponse", description = "Response containing available and selected portfolios for a structure + gabarit")
public record AccessiblePortfolioForStructureResponseDTO(
    @Schema(description = "Available items (left list)") List<PortfolioItemDTO> available,
    @Schema(description = "Selected items (right list)") List<PortfolioItemDTO> selected) {

  @Schema(name = "AccessiblePortfolioForStructureItem", description = "Portfolio item")
  public record PortfolioItemDTO(
      @Schema(description = "Fund/compartment code") String code,
      @Schema(description = "Short description / label") String label) {
  }
}

