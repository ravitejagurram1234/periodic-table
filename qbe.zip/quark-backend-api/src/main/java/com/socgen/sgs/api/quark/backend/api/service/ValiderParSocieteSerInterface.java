package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

public interface ValiderParSocieteSerInterface {
    void InsertParSociete( MultipartFile file,DocumentDTO dto);
    String getClientIp(HttpServletRequest request);
    Integer AuditParSociete(MultipartFile file, DocumentDTO dto, String page, String user, HttpServletRequest request);

    }
