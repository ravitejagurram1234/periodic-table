package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AccountantBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.AuditorBusiness;
import com.socgen.sgs.api.quark.backend.api.Mapper.AuditorMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Accountants;
import com.socgen.sgs.api.quark.backend.api.domain.Auditor;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditorDao;
import com.socgen.sgs.api.quark.backend.api.service.AuditorsSerInterface;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
@Service
public class AuditorService implements AuditorsSerInterface {

    @Autowired
    private AuditorBusiness auditorBusiness;

    public List<Auditor> getListAuditors() {
        return auditorBusiness.getAuditors();
    }
}
