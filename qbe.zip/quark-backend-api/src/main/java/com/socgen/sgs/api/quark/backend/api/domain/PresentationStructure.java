// src/main/java/.../domain/PresentationStructure.java
package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PresentationStructure {
    private String id_presentation_patrimoine;
    private String id_presentation_compte_res;
}
