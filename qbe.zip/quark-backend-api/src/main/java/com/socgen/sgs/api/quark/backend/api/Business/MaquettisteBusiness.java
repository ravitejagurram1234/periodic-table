package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;
import com.socgen.sgs.api.quark.backend.api.infra.dao.MaquettisteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public class MaquettisteBusiness {

        @Autowired
        private MaquettisteDao dao;

        public List<Maquettiste> getMaquettiste(){
            return dao.getMaquettiste();
        }
    }

