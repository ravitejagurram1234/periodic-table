package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.ModificationParFondsLangueDTO;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ModificationLangueMapper {
    public static ModificationParFondsLangue mapResult(ResultSet rs) throws SQLException {
        ModificationParFondsLangue m=new ModificationParFondsLangue();
        m.setId_langue_document(rs.getInt("ID_LANGUE_DOCUMENT"));
        m.setNom_langue(rs.getString("NOM_LANGUE"));
        m.setValeur_langue(rs.getString("VALEUR_LANGUE"));
        return m;
    }

    public static ModificationParFondsLangueDTO toDto(ModificationParFondsLangue domain){
        ModificationParFondsLangueDTO d=new ModificationParFondsLangueDTO();
        d.setNom_langue(domain.getNom_langue());
        d.setId_langue_document(domain.getId_langue_document());
        return d;
    }
}
