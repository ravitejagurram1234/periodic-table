package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AuditParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.Gabarit_InsertBusiness;
import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.Chargement_gabaritDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.service.ValiderGabarit_InsertSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;

@Service
public class ValiderGabarit_InsertService implements ValiderGabarit_InsertSerInterface {
    @Autowired
    private Gabarit_InsertBusiness gabaritInsertBusiness;
    @Autowired
    private AuditParFondsBusiness auditParFondsBusiness;


    public Integer insertGabarit(Chargement_gabaritDTO gabarit, MultipartFile file) {

        String originalFilename = file.getOriginalFilename();
        int tailleGabarit = (int) file.getSize();
        String nomDocument = originalFilename.substring(0, originalFilename.lastIndexOf('.'));

        try {
//            Chargement_gabarit gabarit1 = new Chargement_gabarit(gabarit.getP_id_type_rapport(), nomDocument, gabarit.getP_id_langue(),
//                    file.getBytes(), tailleGabarit, 1, gabarit.getP_type(), gabarit.getP_id_sous_categorie(),
//                    gabarit.getP_id_gabarit_template(), gabarit.getP_pagination_double(),null,null);

            Chargement_gabarit gabarit1 =
                    Chargement_gabarit.builder()
                            .p_id_gabarit_template(gabarit.getP_id_type_rapport())
                            .nom_gabarit(nomDocument)
                            .p_id_langue(gabarit.getP_id_langue())
                            .p_contenu(gabarit.getFile().getBytes())
                            .p_taille_gabarit(tailleGabarit)
                            .p_is_actif(1)
                            .p_type(gabarit.getP_type())
                            .p_id_sous_categorie(gabarit.getP_id_sous_categorie())
                            .p_id_gabarit_template(gabarit.getP_id_gabarit_template())
                            .p_pagination_double(gabarit.getP_pagination_double())
                    .build();


            return gabaritInsertBusiness.insertGabarit(gabarit1);
        } catch (IOException e) {
            throw new RuntimeException("Error reading file bytes", e);

        }
    }

    public String getClientIp(HttpServletRequest request) {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.isEmpty() || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }


    public Integer AuditGabarit(MultipartFile file, Chargement_gabaritDTO dto, String page, String user, int gabarit_id,HttpServletRequest request) {

        Performance performance = new Performance();
        LocalDate start = LocalDate.now();
        LocalDate end = LocalDate.now();


        BigDecimal responseTime = performance.getSecondsAndMilliseconds();
        String originalFilename = file.getOriginalFilename();
        String nomDocument = originalFilename.substring(0, originalFilename.lastIndexOf('.'));

        String clientIp = getClientIp(request);
        String formattedTemplate = "Id gabarit template : " + dto.getP_id_gabarit_template();
        String formattedid = "Id gabarit : " +gabarit_id ;
        String formattedNom = "Nom gabarit : " + nomDocument;
        Enums.TypeRapport type = Enums.TypeRapport.fromValue(dto.getP_id_type_rapport());
        Enums.TypeGabarit gabtype = Enums.TypeGabarit.fromValue(dto.getP_type());
        String formattedType = " Type Rapport : " + type;
        String formattedLangue = " Id langue gabarit : " + dto.getP_id_langue() + "/ Type gabarit :" + gabtype;
        String formattedsous = " Id sous-categorie : " + dto.getP_id_sous_categorie();
        Audit audit = new Audit(clientIp, start, end, page, user, Chargement_constantes.MODULE_NAME, Chargement_constantes.CREATION_GABARIT,
                formattedTemplate, formattedid, formattedNom, formattedType, formattedLangue, formattedsous, responseTime, 0, 0, "");

        return auditParFondsBusiness.AuditParFonds(audit);
    }

}