package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.LangueBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Langue;
import com.socgen.sgs.api.quark.backend.api.service.LangueSerInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class LangueService implements LangueSerInterface {
    private static final Logger log= LoggerFactory.getLogger(LangueService.class);
    @Autowired
    private LangueBusiness business;
    public List<Langue> getLangue() {
        log.info("Fetching ");
        return business.getLangue();
    }
}
