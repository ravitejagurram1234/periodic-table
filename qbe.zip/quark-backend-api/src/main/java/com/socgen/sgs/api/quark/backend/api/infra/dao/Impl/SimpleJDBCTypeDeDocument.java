package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.PrevSuiviEventsMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.TypeDeDocumentMapper;
import com.socgen.sgs.api.quark.backend.api.domain.PrevSuiviEvents;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TypeDeDocumentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCTypeDeDocument implements TypeDeDocumentDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTypeDeDocument(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetTypesDocumentsByFondsPart")
                .declareParameters(
                        new SqlOutParameter("RETURN", oracle.jdbc.OracleTypes.CURSOR, (rs, rowNum) -> TypeDeDocumentMapper.mapResult(rs)),
                        new SqlParameter("p_id_fnd_code", Types.VARCHAR),
                        new SqlParameter("p_typeCategorieDocument", Types.NUMERIC)

                );
    }

    @Override
    public List<TypeDeDocument> getTypeDocument(String p_id_fnd_code, Long p_typeCategorieDocument) {

        Map<String, Object> params = new HashMap<>();
        params.put( "p_id_fnd_code", p_id_fnd_code);
        params.put( "p_typeCategorieDocument", p_typeCategorieDocument);


        Map<String, Object> result = simpleJdbcCall.execute(params);
        return (List<TypeDeDocument>) result.get("RETURN");
    }
}
