package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationDateDocumentBusiness;
import com.socgen.sgs.api.quark.backend.api.service.ModificationDateDocumentSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
@Service
public class ModificationDateDocumentService implements ModificationDateDocumentSerInterface {
    @Autowired
    private ModificationDateDocumentBusiness modificationDateDocumentBusiness;

    public List<LocalDate> getDateDocuments(int p_id_sous_categorie, String p_id_fnd_code, String p_id_unit_code){
        return modificationDateDocumentBusiness.getDateDocuments(p_id_sous_categorie,p_id_fnd_code,p_id_unit_code);
    }

}
