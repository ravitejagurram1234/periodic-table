package com.socgen.sgs.api.quark.backend.api.config;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SimpleCORSFilter implements Filter {

    private final String cspPolicy;
    private final String httpCorsAllowedOrigins;

    public SimpleCORSFilter(@Value("${http.cors.allowed-origins:*}") String allowedOrigins, @Value("${http.cors.csp-policy:frame-ancestors 'self' }") String cspPolicy) {
        super();
        this.httpCorsAllowedOrigins = allowedOrigins;
        this.cspPolicy = cspPolicy;
    }

    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletResponse response = (HttpServletResponse) res;
        response.setHeader("referrer-policy", "strict-origin-when-cross-origin");

        response.setHeader("content-security-policy", this.cspPolicy + this.httpCorsAllowedOrigins.replace(",", " "));

        chain.doFilter(req, res);
    }

}
