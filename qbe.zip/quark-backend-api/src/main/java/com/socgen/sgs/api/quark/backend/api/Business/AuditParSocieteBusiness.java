package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditParSocieteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class AuditParSocieteBusiness {
    @Autowired
    private AuditParSocieteDao auditParSocieteDao;

    public Integer insertAudit(Audit audit){
        return auditParSocieteDao.insertAudit(audit);
    }
}
