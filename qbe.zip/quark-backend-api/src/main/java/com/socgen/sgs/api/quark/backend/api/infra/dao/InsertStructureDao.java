package com.socgen.sgs.api.quark.backend.api.infra.dao;

public interface InsertStructureDao {

    /**
     * Checks if a structure with the given ID already exists.
     * @return true if structure exists, false otherwise
     */
    boolean structureExists(String idStructure);

    /**
     * Inserts a new structure via QXP_PK_CHARGEMENT.InsertStructure.
     */
    void insertStructure(String idStructure, String nom, String libelleLong,
                         String fndLegalType, String fndClassification,
                         String fndMngtCompany, String fndAccountant,
                         String cac, String devise);
}
