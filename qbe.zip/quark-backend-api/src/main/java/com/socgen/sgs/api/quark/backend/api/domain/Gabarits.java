package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Gabarits {
    private int id_gabarit;
    private String nom;
    private Long id_type_rapport;
    private Long id_langue;
    private Long type_gabarit;

    private Gabarits(Builder builder) {
        this.id_gabarit = builder.id_gabarit;
        this.nom = builder.nom;
        this.id_type_rapport = builder.id_type_rapport;
        this.id_langue = builder.id_langue;
        this.type_gabarit = builder.type_gabarit;
    }

    // Static builder method
    public static Builder builder() {
        return new Builder();
    }

    // Builder class
    public static class Builder {
        private int id_gabarit;
        private String nom;
        private Long id_type_rapport;
        private Long id_langue;
        private Long type_gabarit;

        public Builder id_gabarit(int id_gabarit) {
            this.id_gabarit = id_gabarit;
            return this;
        }

        public Builder nom(String nom) {
            this.nom = nom;
            return this;
        }

        public Builder id_type_rapport(Long id_type_rapport) {
            this.id_type_rapport = id_type_rapport;
            return this;
        }

        public Builder id_langue(Long id_langue) {
            this.id_langue = id_langue;
            return this;
        }

        public Builder type_gabarit(Long type_gabarit) {
            this.type_gabarit = type_gabarit;
            return this;
        }

        public Gabarits build() {
            return new Gabarits(this);
        }
    }

}
