package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.MaquettisteBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;
import com.socgen.sgs.api.quark.backend.api.service.MaquettisteSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MaquettisteService implements MaquettisteSerInterface {

    @Autowired
    private MaquettisteBusiness business;

    @Override
    public List<Maquettiste> getMaquettiste(){
       return business.getMaquettiste();
    }
}
