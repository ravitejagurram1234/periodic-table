package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;

import java.util.List;

public interface ModificationTypeDeDocumentSerInterface {

    List<TypeDeDocument> getListTypeDocuments();
}
