package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureValidateDao;
import oracle.jdbc.OracleTypes;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Repository
public class SimpleJDBCStructureValidate implements StructureValidateDao {

    private final JdbcTemplate jdbcTemplate;
    private final SimpleJdbcCall getListeCompartsByStructureCall;
    private final SimpleJdbcCall updateStructureCall;

    public SimpleJDBCStructureValidate(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);

        this.getListeCompartsByStructureCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withFunctionName("GetListeCompartsByStructure")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> rs.getString(1)),
                        new SqlParameter("p_idStructure", Types.VARCHAR),
                        new SqlParameter("p_auditor", Types.VARCHAR),
                        new SqlParameter("p_accountant", Types.VARCHAR),
                        new SqlParameter("p_fundMgtCompany", Types.VARCHAR)
                );

        this.updateStructureCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withProcedureName("UpdateStructure")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_idStructure", Types.VARCHAR),
                        new SqlParameter("p_nom", Types.VARCHAR),
                        new SqlParameter("p_libelleLong", Types.VARCHAR),
                        new SqlParameter("p_type", Types.VARCHAR),
                        new SqlParameter("p_classification", Types.VARCHAR),
                        new SqlParameter("p_societeGestion", Types.VARCHAR),
                        new SqlParameter("p_groupeComptable", Types.VARCHAR),
                        new SqlParameter("p_cac", Types.VARCHAR),
                        new SqlParameter("p_devise", Types.VARCHAR)
                );
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<String> getListeCompartsByStructure(String idStructure) {
        Map<String, Object> in = new HashMap<>();
        in.put("p_idStructure", idStructure);
        in.put("p_auditor", null);
        in.put("p_accountant", null);
        in.put("p_fundMgtCompany", null);

        Map<String, Object> out = getListeCompartsByStructureCall.execute(in);
        Object rows = out.get("RETURN_VALUE");
        return rows == null ? Collections.emptyList() : (List<String>) rows;
    }

    @Override
    public Integer checkIfNoAssoCompartsGabarit(String idStructure, List<String> deletedCompartiments) {
        if (deletedCompartiments == null || deletedCompartiments.isEmpty()) {
            return 0;
        }

        try {
            List<String> cleaned = deletedCompartiments.stream()
                    .filter(Objects::nonNull)
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .distinct()
                    .toList();

            StringBuilder block = new StringBuilder();
            block.append("DECLARE ");
            block.append("  l_listeComparts QXP_PK_COMMON.VarCharArray; ");
            block.append("  l_result NUMBER; ");
            block.append("BEGIN ");

            for (int i = 0; i < cleaned.size(); i++) {
                block.append("  l_listeComparts(")
                        .append(i + 1)
                        .append(") := '")
                        .append(escape(cleaned.get(i)))
                        .append("'; ");
            }

            block.append("  l_result := QXP_PK_CHARGEMENT.CheckIfNoAssoCompartsGabarit(");
            block.append("    p_listeComparts => l_listeComparts");
            block.append("  ); ");
            block.append("  ? := l_result; ");
            block.append("END;");

            return jdbcTemplate.execute(block.toString(),
                    (java.sql.CallableStatement cs) -> {
                        cs.registerOutParameter(1, Types.NUMERIC);
                        cs.execute();
                        return cs.getInt(1);
                    });

        } catch (Exception e) {
            throw new RuntimeException("Error in CheckIfNoAssoCompartsGabarit", e);
        }
    }


    @Override
    public void updateStructure(String idStructure, String nom, String libelleLong, String fndLegalType,
                                String fndClassification, String fndMngtCompany, String fndAccountant,
                                String cac, String devise) {
        Map<String, Object> in = new HashMap<>();
        in.put("p_idStructure", idStructure);
        in.put("p_nom", nom);
        in.put("p_libelleLong", libelleLong);
        in.put("p_type", fndLegalType);
        in.put("p_classification", fndClassification);
        in.put("p_societeGestion", fndMngtCompany);
        in.put("p_groupeComptable", fndAccountant);
        in.put("p_cac", cac);
        in.put("p_devise", devise);

        updateStructureCall.execute(in);
    }

    @Override
    public void updateLiensStructCompartiments(String idStructure, List<String> compartiments) {
        try {
            List<String> cleaned = compartiments == null
                    ? List.of()
                    : compartiments.stream()
                    .filter(Objects::nonNull)
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .distinct()
                    .toList();

            StringBuilder block = new StringBuilder();
            block.append("DECLARE ");
            block.append("  l_listeCompartiments QXP_PK_COMMON.VarCharArray; ");
            block.append("BEGIN ");

            if (cleaned.isEmpty()) {
                block.append("  l_listeCompartiments(1) := NULL; ");
            } else {
                for (int i = 0; i < cleaned.size(); i++) {
                    block.append("  l_listeCompartiments(")
                            .append(i + 1)
                            .append(") := '")
                            .append(escape(cleaned.get(i)))
                            .append("'; ");
                }
            }

            block.append("  QXP_PK_GP.UpdateLiensStructCompartiments(");
            block.append("    p_idStructure => '").append(escape(idStructure)).append("', ");
            block.append("    p_listeCompartiments => l_listeCompartiments");
            block.append("  ); ");
            block.append("END;");

            jdbcTemplate.execute(block.toString());
        } catch (Exception e) {
            throw new RuntimeException("Error in UpdateLiensStructCompartiments", e);
        }
    }

    private String escape(String value) {
        return value == null ? "" : value.replace("'", "''");
    }
}
