package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.GabaritTemplateBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;
import com.socgen.sgs.api.quark.backend.api.service.GabaritTemplateSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class GabaritTemplateService implements GabaritTemplateSerInterface {
    @Autowired
    private GabaritTemplateBusiness gabaritTemplateBusiness;

    public List<GabaritTemplate> getTemplates(){
        return gabaritTemplateBusiness.getTemplates();
    }
}
