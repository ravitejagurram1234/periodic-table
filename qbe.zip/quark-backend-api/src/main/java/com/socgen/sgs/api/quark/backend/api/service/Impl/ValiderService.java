package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.SuiviDetailsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.SuiviStructureBusiness;
import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.SuiviStructureDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValiderDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.SuiviDetailsMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.SuiviStructureMapper;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.GabaritRepository;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import com.socgen.sgs.api.quark.backend.api.service.ValiderSerInterface;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ValiderService implements ValiderSerInterface {

    private final SuiviDetailsBusiness suiviDetailsBusiness;
    private final SuiviStructureBusiness structureBusiness;
    private final GabaritRepository gabaritRepository;

    @Override
    public ValiderDTO getSuivis(
            final Long p_idTypeRapport,
            final Long p_idLangue,
            final Long p_idGabarit,
            final LocalDate p_dateEcheance,
            final String p_portfeuilles,
            final String p_auditor,
            final String p_accountant,
            final String p_fundMgtCompany) {

        final QxpGabarit gabarit = gabaritRepository.findByGabaritId(p_idGabarit)
                .orElseThrow(() -> new IllegalArgumentException("Gabarit not found with ID: " + p_idGabarit));

        if (gabarit.getType() == null) {
            throw new IllegalArgumentException("Type not set for gabarit ID: " + p_idGabarit);
        }

        final long gabaritType = gabarit.getType();

        List<SuiviDetailsDTO> fondsList = Collections.emptyList();
        List<SuiviStructureDetailsDTO> structureList = Collections.emptyList();

        if (gabaritType == 0L || gabaritType == 2L) {
            fondsList = suiviDetailsBusiness
                    .getListeNewSuivisByFondsPart(p_idTypeRapport, p_idLangue, p_idGabarit, gabaritType,
                            p_dateEcheance, p_portfeuilles, p_auditor, p_accountant, p_fundMgtCompany)
                    .stream()
                    .map(suivi -> SuiviDetailsMapper.toDto(suivi, gabaritType))
                    .toList();
        }

        if (gabaritType == 1L) {
            structureList = structureBusiness
                    .getListeStructuresForNewSuivi(p_idTypeRapport, p_idLangue, p_idGabarit,
                            p_dateEcheance, p_portfeuilles, p_auditor, p_accountant, p_fundMgtCompany)
                    .stream()
                    .map(SuiviStructureMapper::toDto)
                    .toList();
        }

        return new ValiderDTO(fondsList, structureList);
    }
}
