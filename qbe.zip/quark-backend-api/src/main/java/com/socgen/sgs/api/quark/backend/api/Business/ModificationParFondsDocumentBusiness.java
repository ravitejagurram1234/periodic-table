package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsDocument;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParFondsDocumentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

@Component
@Transactional
public class ModificationParFondsDocumentBusiness {
    @Autowired
    private ModificationParFondsDocumentDao modificationParFondsDocumentDao;

    public List<ModificationParFondsDocument> getDocumentName(String p_id_fnd_code, String p_id_unit_code, int p_id_sous_categorie, int p_id_langue, LocalDate p_date_document){
        return modificationParFondsDocumentDao.getDocumentName(p_id_fnd_code,p_id_unit_code,p_id_sous_categorie,p_id_langue,p_date_document);
    }

}