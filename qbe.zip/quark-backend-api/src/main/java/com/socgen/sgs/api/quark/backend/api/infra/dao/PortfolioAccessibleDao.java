package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;

import java.util.List;

public interface PortfolioAccessibleDao {
    List<portefeuilleDTO> getFondsSimples(String p_auditor, String p_accountant, String p_fundMgtCompany);
    List<portefeuilleDTO> getListeStructures(String p_auditor, String p_accountant, String p_fundMgtCompany);
    List<portefeuilleDTO> getListeCompartNonDispos(String p_auditor, String p_accountant, String p_fundMgtCompany);
}
