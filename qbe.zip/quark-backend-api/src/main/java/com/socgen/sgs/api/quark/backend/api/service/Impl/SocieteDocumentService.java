package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.SocieteDocumentBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.service.SocieteDocumentSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SocieteDocumentService implements SocieteDocumentSerInterface {
    @Autowired
    private SocieteDocumentBusiness societeDocumentBusiness;

    public List<TypeDeDocument> getSocieteDocument(String p_societe){
        return societeDocumentBusiness.getSocieteDocument(p_societe);
    }

}
