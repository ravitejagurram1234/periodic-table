// src/main/java/.../Dto/StructureGabaritFondsResponseDTO.java
package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StructureGabaritFondsResponseDTO {
    private boolean       success;
    private String        message;
    private LocalDateTime timestamp;
    private int           compartimentsLinked;
    private String        idStructure;
    private Long          idGabarit;
    private String        errorCode;
}
