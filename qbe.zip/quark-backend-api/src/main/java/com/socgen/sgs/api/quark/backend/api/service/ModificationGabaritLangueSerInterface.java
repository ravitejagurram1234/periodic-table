package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;

import java.util.List;

public interface ModificationGabaritLangueSerInterface {
    List<ModificationParFondsLangue> getListLangue(int p_id_type_rapport);
}
