package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.MaquettisteMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;
import com.socgen.sgs.api.quark.backend.api.infra.dao.MaquettisteDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;

@Repository
public class simpleJDBCmaquettiste implements MaquettisteDao {
    public final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public simpleJDBCmaquettiste(DataSource dataSource) {

        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_HABILITATION")
                .withFunctionName("GetListeMaquettistes")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(new SqlOutParameter("RETURN", OracleTypes.CURSOR, (rs, rowNum) ->
                        MaquettisteMapper.mapResult(rs))
                );
    }
    @Override
    public List<Maquettiste> getMaquettiste() {

        Map<String, Object> result = simpleJdbcCall.execute();
        return (List<Maquettiste>) result.get("RETURN");

    }
}
