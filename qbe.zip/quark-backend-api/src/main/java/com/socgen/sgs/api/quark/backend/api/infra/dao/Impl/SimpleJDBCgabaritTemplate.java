package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.GabaritTemplateMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCgabaritTemplate implements GabaritTemplateDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCgabaritTemplate(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeNomsGabaritsTemplate")
                .declareParameters(
                        new SqlOutParameter("RETURN", oracle.jdbc.OracleTypes.CURSOR, (rs, rowNum) -> GabaritTemplateMapper.mapResult(rs))
                );
    }

    @Override
    public List<GabaritTemplate> getTemplates() {
        Map<String, Object> result = simpleJdbcCall.execute();
        return (List<GabaritTemplate>) result.get("RETURN");


    }
}
