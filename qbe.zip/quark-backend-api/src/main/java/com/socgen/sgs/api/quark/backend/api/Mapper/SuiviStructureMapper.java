package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.SuiviStructureDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviStructureDetails;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class SuiviStructureMapper {
    public static SuiviStructureDetails mapResult(ResultSet rs) throws SQLException {
        SuiviStructureDetails newStructure = new SuiviStructureDetails();

        newStructure.setIdStructure(rs.getString("ID_STRUCTURE"));
        newStructure.setNom(rs.getString("NOM"));
        newStructure.setFndAccountant(rs.getString("FND_ACCOUNTANT"));
        newStructure.setFndMngtCompany(rs.getString("FND_MNGT_COMPANY"));
        newStructure.setIdSuivi(rs.getLong("ID_SUIVI"));
        newStructure.setIdStatutGeneration(rs.getLong("ID_STATUT_GENERATION"));
        newStructure.setTypeSuivi(rs.getInt("TYPE_SUIVI"));
        newStructure.setFndLegalType(rs.getString("FND_LEGAL_TYPE"));
        newStructure.setFndClassification(rs.getString("FND_CLASSIFICATION"));
        newStructure.setFndAuditor(rs.getString("FND_AUDITOR"));
        newStructure.setDateLastEcheance(rs.getString("DATE_LAST_ECHEANCE"));
        newStructure.setFndNextFiscalYearEnd(rs.getString("FND_NEXT_FISCAL_YEAR_END"));

//        try {
//            java.sql.Date lastEcheance = rs.getDate("DATE_LAST_ECHEANCE");
//            newStructure.setDateLastEcheance(lastEcheance != null ? lastEcheance.toLocalDate() : null);
//        } catch (IllegalArgumentException e) {
//            newStructure.setDateLastEcheance(null);
//        }

//        try {
//            java.sql.Date nextFiscalYearEnd = rs.getDate("FND_NEXT_FISCAL_YEAR_END");
//            newStructure.setFndNextFiscalYearEnd(nextFiscalYearEnd != null ? nextFiscalYearEnd.toLocalDate() : null);
//        } catch (IllegalArgumentException e) {
//            newStructure.setFndNextFiscalYearEnd(null);
//        }

        try {
            java.sql.Date lastFiscalYearEnd = rs.getDate("FND_LAST_FISCAL_YEAR_END");
            newStructure.setFndLastFiscalYearEnd(lastFiscalYearEnd != null ? lastFiscalYearEnd.toLocalDate() : null);
        } catch (IllegalArgumentException e) {
            newStructure.setFndLastFiscalYearEnd(null);
        }

        return newStructure;
    }

    public static SuiviStructureDetailsDTO toDto(SuiviStructureDetails suivi) {
        SuiviStructureDetailsDTO dto = new SuiviStructureDetailsDTO();
        dto.setIdStructure(suivi.getIdStructure());
        dto.setNom(suivi.getNom());
        dto.setFndNextFiscalYearEnd(suivi.getFndNextFiscalYearEnd());
        dto.setDateLastEcheance(suivi.getDateLastEcheance());
        dto.setFndLegalType(suivi.getFndLegalType());
        dto.setFndMngtCompany(suivi.getFndMngtCompany());
        dto.setFndClassification(suivi.getFndClassification());
        dto.setFndAccountant(suivi.getFndAccountant());
        dto.setFndAuditor(suivi.getFndAuditor());

        return dto;

    }
}


