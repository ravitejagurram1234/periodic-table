package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Auditor;

import java.util.List;

public interface AuditorsSerInterface {
    List<Auditor>getListAuditors();
}
