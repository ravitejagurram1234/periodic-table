package com.socgen.sgs.api.quark.backend.api.Business;

import java.util.Comparator;

public class FondsCodeComparator implements Comparator<String> {

    public static final FondsCodeComparator INSTANCE = new FondsCodeComparator();

    @Override
    public int compare(String a, String b) {
        int ra = rank(a), rb = rank(b);
        if (ra != rb) return Integer.compare(ra, rb);   // fixed: no redundant compare
        return tieBreak(a, b, ra);
    }

    // 0 = underscore, 1 = numeric, 2 = alphabetic, 3 = null/empty
    private int rank(String s) {
        if (s == null || s.isEmpty()) return 3;
        char first = s.charAt(0);
        if (first == '_') return 0;
        if (Character.isDigit(first)) return 1;
        return 2;
    }

    private int tieBreak(String a, String b, int rank) {
        if (rank == 1) {
            long numA = extractLeadingNumber(a);
            long numB = extractLeadingNumber(b);
            if (numA != numB) return Long.compare(numA, numB);
        }
        return a.compareToIgnoreCase(b);
    }

    private long extractLeadingNumber(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (Character.isDigit(c)) sb.append(c);
            else break;
        }
        try {
            return !sb.isEmpty() ? Long.parseLong(sb.toString()) : Long.MAX_VALUE;  // fixed: isEmpty()
        } catch (NumberFormatException e) {
            return Long.MAX_VALUE;
        }
    }
}
