package com.socgen.sgs.api.quark.backend.api.infra.jpa.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "QXP_REF_EVENT")
public class QXP_REF_ENTITY {

        @Id
        @Column(name = "ID_EVENT", nullable = false)
        private Long ID_EVENT;
        @Column(name = "LIBELLE",nullable= false)
        private String LIBELLE;

}
