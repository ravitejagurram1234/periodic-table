package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
    public class Structure {
        private String idStructure;
        private String nom;
        private String libelleLong;
        private String fndLegalType;
        private String fndClassification;
        private String fndMngtCompany;
        private String fndAccountant;
        private String cac;
        private String devise;
    }

