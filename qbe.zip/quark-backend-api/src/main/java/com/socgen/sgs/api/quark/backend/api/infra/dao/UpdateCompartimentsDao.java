package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;

public interface UpdateCompartimentsDao {
    void updateCompartimentInfos(Compartiment compartiment);
}
