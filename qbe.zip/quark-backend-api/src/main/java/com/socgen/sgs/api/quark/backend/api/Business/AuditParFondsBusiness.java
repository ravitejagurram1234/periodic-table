package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditParFondsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class AuditParFondsBusiness {
    @Autowired
    private AuditParFondsDao auditParFondsDao;

    public Integer AuditParFonds(Audit audit){
        return auditParFondsDao.insertAudit(audit);
    }
}
