package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CompartimentsDTO {
    private String libelle_compartiment;
    private LocalDate date_fin_compartiment;
    private String presentation_eco_geo;
    private String id_fnd_code;
    private String fnd_sht_description;
    private String fnd_lng_description;
}
