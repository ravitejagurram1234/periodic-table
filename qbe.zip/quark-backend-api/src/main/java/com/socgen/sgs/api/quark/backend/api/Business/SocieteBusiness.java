package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Societe;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SocieteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class SocieteBusiness {
    @Autowired
    private SocieteDao societeDao;

    public List<Societe> getSociete(){
     return societeDao.getSociete();
    }
}
