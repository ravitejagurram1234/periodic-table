package com.socgen.sgs.api.quark.backend.api.infra.dao;

import java.util.List;

public interface InsertLiensFondsGabaritDao {
    void insertLiensFondsGabarit(Long p_idTypeRapport, Long p_idGabarit, Long p_idLangue,
                                 String p_auditor, String p_accountant, String p_fundMgtCompany,
                                 List<String> p_listeFonds);
}
