package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;

public interface GabaritSerInterface {
    Gabarit getGabarit(Long p_idGabarit);
}
