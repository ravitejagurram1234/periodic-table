package com.socgen.sgs.api.quark.backend.api.service;

import java.util.List;

public interface ModificationSocieteSerInterface {
    List<String> getListSociete();
}
