package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;

import java.util.List;

public interface SuiviEventsSerInterface {
    List<SuiviEvents> getSuiviEvents(Long p_idSuivi);
}
