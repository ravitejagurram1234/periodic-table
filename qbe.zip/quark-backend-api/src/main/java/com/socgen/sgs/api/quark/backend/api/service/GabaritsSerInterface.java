package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;

import java.util.List;

public interface GabaritsSerInterface {
    List<Gabarits>getGabarits(Long p_idTypeRapport, Long p_idLangue, int p_onlyActive);
}
