// src/main/java/.../infra/dao/InsertLiensStructGabCompartsDao.java
package com.socgen.sgs.api.quark.backend.api.infra.dao;

import java.util.List;

public interface InsertLiensStructGabCompartsDao {
    void insertLiensStructGabComparts(
            String       idStructure,
            Long         idGabarit,
            List<String> listeCompartiments,
            String       idPresentationPatrimoine,
            String       idPresentationCompteRes
    );
}
