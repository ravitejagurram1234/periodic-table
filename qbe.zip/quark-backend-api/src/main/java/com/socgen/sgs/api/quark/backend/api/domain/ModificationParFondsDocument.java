package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ModificationParFondsDocument {

        private int id_document;
        private int id_sous_categorie;
        private int id_langue;
        private String nom_document;
        private String id_fnd_code;
        private String id_unit_code;
        private int is_actif;
        private LocalDate date_echeance;
        private LocalDate date_creation_sys;
        private long taille_document;
        private String societe;
        private String format;
        private int id_utilisateur;
}
