package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import java.util.List;

public interface SuiviEventDao {
    List<SuiviEvents> getSuiviEvents(Long p_idSuivi);
}
