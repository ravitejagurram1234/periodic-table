package com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository;

import com.socgen.sgs.api.quark.backend.api.infra.jpa.TypeRapportData;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.LangueEntity;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.TypeRapportEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface TypeRapportRepository extends JpaRepository<TypeRapportEntity,Long> {
    @Query(value = "SELECT ID_TYPE_RAPPORT AS id,LIBELLE AS libelle FROM QXP_REF_TYPE_RAPPORT ORDER BY ID_TYPE_RAPPORT", nativeQuery = true)
    public List<TypeRapportData> getTypeRapport();

}
