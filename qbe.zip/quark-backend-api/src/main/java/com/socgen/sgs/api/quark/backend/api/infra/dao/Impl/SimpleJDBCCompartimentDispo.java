package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentDispoDao;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Slf4j
@Repository
public class SimpleJDBCCompartimentDispo implements CompartimentDispoDao {

    private final SimpleJdbcCall simpleJdbcCall;
    private boolean metadataLogged = false;

    @Autowired
    public SimpleJDBCCompartimentDispo(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withFunctionName("GetListeCompartsDispos")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR,
                                (rs, rowNum) -> {
                                    rs.setFetchSize(1000);
                                    return mapCompartimentDispo(rs);
                                }),
                        new SqlParameter("p_id_structure", Types.VARCHAR)
                );
    }

    /**
     * Maps GetListeCompartsDispos cursor to Compartiment.
     * Uses column index (position) to avoid case sensitivity issues.
     */
    private Compartiment mapCompartimentDispo(ResultSet rs) throws SQLException {
        // Log metadata only once for debugging
        if (!metadataLogged) {
            ResultSetMetaData meta = rs.getMetaData();
            StringBuilder columnInfo = new StringBuilder("GetListeCompartsDispos columns: ");
            for (int i = 1; i <= meta.getColumnCount(); i++) {
                columnInfo.append(i).append("=").append(meta.getColumnName(i)).append(" ");
            }
            log.info(columnInfo.toString());
            metadataLogged = true;
        }

        Compartiment compartiment = new Compartiment();

        // Access by index (1-based) - most reliable method
        compartiment.setId_fnd_code(rs.getString(1));
        compartiment.setLibelle_compartiment(rs.getString(2));

        return compartiment;
    }

    @Override
    public List<Compartiment> getListeCompartsDispos(String idStructure) {
        long start = System.currentTimeMillis();
        log.info("GetListeCompartsDispos called with idStructure={}", idStructure);

        try {
            Map<String, Object> result = simpleJdbcCall.execute(
                    Map.of("p_id_structure", idStructure != null ? idStructure : "%")
            );

            @SuppressWarnings("unchecked")
            List<Compartiment> compartiments = (List<Compartiment>) result.get("RETURN_VALUE");

            long duration = System.currentTimeMillis() - start;
            log.info("GetListeCompartsDispos returned {} rows in {}ms",
                    compartiments != null ? compartiments.size() : 0, duration);

            return compartiments != null ? compartiments : Collections.emptyList();
        } catch (Exception e) {
            log.error("Error calling GetListeCompartsDispos: {}", e.getMessage(), e);
            return Collections.emptyList();
        }
    }
}
