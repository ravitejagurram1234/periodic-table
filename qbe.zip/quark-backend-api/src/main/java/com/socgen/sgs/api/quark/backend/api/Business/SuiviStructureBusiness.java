package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviStructureDetails;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviDetailsDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviStructureDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
@Component
@Transactional
public class SuiviStructureBusiness {
    @Autowired
    private SuiviStructureDao suiviStructureDao;

    public List<SuiviStructureDetails> getListeStructuresForNewSuivi(Long p_idTypeRapport, Long p_idLangue, Long p_idGabarit,
                                                                            LocalDate p_dateEcheance, String p_structures, String p_auditor,
                                                                            String p_accountant, String p_fundMgtCompany) {
        return suiviStructureDao.getListeStructuresForNewSuivi(p_idTypeRapport,  p_idLangue, p_idGabarit,  p_dateEcheance,
                p_structures,  p_auditor,  p_accountant,  p_fundMgtCompany);


    }
}

