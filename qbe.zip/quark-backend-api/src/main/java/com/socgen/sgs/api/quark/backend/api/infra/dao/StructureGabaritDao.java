// src/main/java/.../infra/dao/StructureGabaritDao.java
package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.domain.PresentationStructure;

import java.util.List;

public interface StructureGabaritDao {
    List<PresentationStructure> getPresentationStructure(String idStructure, Long idGabarit);
    List<Compartiment> getListeCompartsByStructGab(String idStructure, Long idGabarit);
}
