package com.socgen.sgs.api.quark.backend.api.infra.dao;

public interface DocumentQXPInsertDao {
    Integer DocumentQXPInsert(byte[] p_contenu, int p_taille_document);
}
