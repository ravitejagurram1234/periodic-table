package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;

public interface AuditParSocieteDao {
    Integer insertAudit(Audit audit);
}
