package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.domain.PrevSuiviEvents;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PrevSuiviEventsMapper {
    public static PrevSuiviEvents mapResult(ResultSet rs) throws SQLException {
        PrevSuiviEvents events = new PrevSuiviEvents();
        events.setId_event(rs.getLong("ID_EVENT"));
        events.setId_statut_suivi(rs.getLong("ID_STATUT_SUIVI"));
        events.setLibelle(rs.getString("LIBELLE"));
        events.setShow_on_eos(rs.getLong("SHOW_ON_EOS"));
        events.setTraduction_code(rs.getString("TRADUCTION_CODE"));
        events.setType(rs.getString("TYPE"));
        events.setEvent_type(rs.getLong("EVENT_TYPE"));
        events.setMandatory(rs.getLong("MANDATORY"));

        return events;

    }
}