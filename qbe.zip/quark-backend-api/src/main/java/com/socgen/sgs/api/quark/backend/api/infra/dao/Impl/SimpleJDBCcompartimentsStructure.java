package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.ModificationLangueMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.StructureMapper;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentsStructureDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.Types;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCcompartimentsStructure implements CompartimentsStructureDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCcompartimentsStructure (DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withFunctionName("GetListeStructures")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> StructureMapper.mapResult(rs)),

                        new SqlParameter("p_withAtLeastOneCompatiment", Types.NUMERIC),
                        new SqlParameter("p_auditor", Types.VARCHAR),
                        new SqlParameter("p_accountant", Types.VARCHAR),
                        new SqlParameter("p_fundMgtCompany", Types.VARCHAR)

                );
    }

    @Override
    public List<Structure> getStructures(int p_withAtLeastOneCompatiment,String p_auditor,String p_accountant, String p_fundMgtCompany) {

        Map<String, Object> params = new HashMap<>();
        params.put("p_withAtLeastOneCompatiment", p_withAtLeastOneCompatiment);
        params.put("p_auditor", (p_auditor==null || p_auditor.isEmpty()?null:p_auditor));
        params.put("p_accountant",(p_accountant==null || p_accountant.isEmpty()?null:p_auditor));
        params.put("p_fundMgtCompany",(p_fundMgtCompany==null || p_fundMgtCompany.isEmpty()?null:p_fundMgtCompany));

        Map<String, Object> result = simpleJdbcCall.execute(params);
        return (List<Structure>) result.get("RETURN_VALUE");
    }
}
