package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationParFondsLangueBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.service.ModificationParFondsLangueSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
@Service
public class ModificationParFondsLangueService implements ModificationParFondsLangueSerInterface {
@Autowired
private ModificationParFondsLangueBusiness modificationParFondsLangueBusiness;

    public List<ModificationParFondsLangue> getLangues(int p_id_sous_categorie, String p_id_fnd_code, String p_id_unit_code, LocalDate p_date_document){
        return  modificationParFondsLangueBusiness.getLangues(p_id_sous_categorie,p_id_fnd_code,p_id_unit_code,p_date_document);
}
}
