package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import java.util.List;

public interface PortfolioSelectedDao {
    List<portefeuilleDTO> getFondsSimplesByGabarit(Long p_idTypeRapport, Long p_idGabarit, Long p_idLangue,
                                                   String p_auditor, String p_accountant, String p_fundMgtCompany);
    List<portefeuilleDTO> getListeCompartsByGabarit(Long p_idTypeRapport, Long p_idGabarit, Long p_idLangue);
    List<portefeuilleDTO> getListeStructuresByGabarit(Long p_idTypeRapport, Long p_idGabarit, Long p_idLangue,
                                                      String p_auditor, String p_accountant, String p_fundMgtCompany);
}
