package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;

import java.util.List;

public interface GabaritEventDao {
    List<GabaritEvents> getGabaritEvent(Long p_idGabarit);
}
