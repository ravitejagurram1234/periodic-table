package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.CompartimentMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentsDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCcompartiments implements CompartimentsDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCcompartiments(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_GP")
                .withFunctionName("GetListeCompartsByStructure")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> {
                            rs.setFetchSize(1000);
                            return CompartimentMapper.mapResult(rs);
                        }),
                        new SqlParameter("p_idStructure", Types.VARCHAR),
                        new SqlParameter("p_auditor", Types.VARCHAR),
                        new SqlParameter("p_accountant", Types.VARCHAR),
                        new SqlParameter("p_fundMgtCompany", Types.VARCHAR)
                );
    }

    @Override
    public List<Compartiment> getStructures(String p_idStructure, String p_auditor,
                                            String p_accountant, String p_fundMgtCompany) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_idStructure",   p_idStructure);
        params.put("p_auditor",       (p_auditor       == null || p_auditor.isEmpty())       ? null : p_auditor);
        params.put("p_accountant",    (p_accountant     == null || p_accountant.isEmpty())    ? null : p_accountant); // ✅ fixed: was p_auditor
        params.put("p_fundMgtCompany",(p_fundMgtCompany == null || p_fundMgtCompany.isEmpty()) ? null : p_fundMgtCompany);

        Map<String, Object> result = simpleJdbcCall.execute(params);

        @SuppressWarnings("unchecked")
        List<Compartiment> compartiments = (List<Compartiment>) result.get("RETURN_VALUE");
        return compartiments != null ? compartiments : Collections.emptyList();
    }
}
