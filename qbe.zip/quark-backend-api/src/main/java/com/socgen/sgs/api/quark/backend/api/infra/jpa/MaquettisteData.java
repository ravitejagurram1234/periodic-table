package com.socgen.sgs.api.quark.backend.api.infra.jpa;

public interface MaquettisteData {
    Long getId();

    String getTrigramme();


}
