package com.socgen.sgs.api.quark.backend.api.Dto;

import com.socgen.sgs.api.quark.backend.api.domain.Accountants;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AccountantsDTO {
    private String des_table_value;


}
