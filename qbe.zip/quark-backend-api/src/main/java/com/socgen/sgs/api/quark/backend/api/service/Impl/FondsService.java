package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.FondsBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Fonds;
import com.socgen.sgs.api.quark.backend.api.service.FondsSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
@Service
public class FondsService implements FondsSerInterface {

        @Autowired
        private FondsBusiness fondsBusiness;

        public List<Fonds> getListeFondsForNewSuivi(Long p_idTypeRapport, Long p_idLangue, Long p_idGabarit, LocalDate p_dateEcheance) {
            return fondsBusiness.getListeFondsForNewSuivi(p_idTypeRapport, p_idLangue, p_idGabarit, p_dateEcheance);
        }
}
