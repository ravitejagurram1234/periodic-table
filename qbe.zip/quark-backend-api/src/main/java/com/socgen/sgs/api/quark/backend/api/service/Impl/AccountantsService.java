package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AccountantBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.FundMgtCompanyBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Accountants;
import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AccountantsDao;
import com.socgen.sgs.api.quark.backend.api.service.AccountantsSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AccountantsService implements AccountantsSerInterface {

    @Autowired
    private AccountantBusiness accountantBusiness;

    public List<Accountants> getListAccountants() {
        return accountantBusiness.getAccountants();
    }
}
