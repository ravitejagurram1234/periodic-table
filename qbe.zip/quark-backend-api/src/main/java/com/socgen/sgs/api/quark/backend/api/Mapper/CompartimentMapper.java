package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CompartimentMapper {

    public static Compartiment mapResult(final ResultSet rs) throws SQLException {
        final Compartiment compartiment = new Compartiment();
        compartiment.setKey_ref_fund(rs.getString("key_ref_fund"));
        compartiment.setId_fnd_code(rs.getString("id_fnd_code"));

        final java.sql.Date fndStartValidity = rs.getDate("id_fnd_start_validity");
        compartiment.setId_fnd_start_validity(fndStartValidity != null ? fndStartValidity.toLocalDate() : null);

        final java.sql.Date fndEndValidity = rs.getDate("fnd_end_validity");
        compartiment.setFnd_end_validity(fndEndValidity != null ? fndEndValidity.toLocalDate() : null);

        compartiment.setFnd_sht_description(rs.getString("fnd_sht_description"));
        compartiment.setFnd_lng_description(rs.getString("fnd_lng_description"));
        compartiment.setFnd_flg_multi_mngr(rs.getString("fnd_flg_multi_mngr"));
        compartiment.setFnd_chart_account(rs.getString("fnd_chart_account"));
        compartiment.setFnd_accountant(rs.getString("fnd_accountant"));
        compartiment.setId_act_code(rs.getString("id_act_code"));
        compartiment.setAct_socio_class(rs.getString("act_socio_class"));
        compartiment.setAct_lng_description(rs.getString("act_lng_description"));
        compartiment.setId_mng_code(rs.getString("id_mng_code"));
        compartiment.setDevise_poche(rs.getString("devise_poche"));
        compartiment.setMng_lng_description(rs.getString("mng_lng_description"));
        compartiment.setMngShtDescription(rs.getString("mng_sht_description"));
        compartiment.setId_mfm_manager_code(rs.getString("id_mfm_manager_code"));

        final java.sql.Date fndLastFiscalYearEnd = rs.getDate("fnd_last_fiscal_year_end");
        compartiment.setFnd_last_fiscal_year_end(fndLastFiscalYearEnd != null ? fndLastFiscalYearEnd.toLocalDate() : null);

        final java.sql.Date fndNextFiscalYearEnd = rs.getDate("fnd_next_fiscal_year_end");
        compartiment.setFnd_next_fiscal_year_end(fndNextFiscalYearEnd != null ? fndNextFiscalYearEnd.toLocalDate() : null);

        compartiment.setMfm_actor(rs.getString("mfm_actor"));
        compartiment.setLibelle_compartiment(rs.getString("libelle_compartiment"));

        final java.sql.Date dateFinCompartiment = rs.getDate("date_fin_compartiment");
        compartiment.setDate_fin_compartiment(dateFinCompartiment != null ? dateFinCompartiment.toLocalDate() : null);

        compartiment.setPresentation_eco_geo(rs.getString("presentation_eco_geo"));

        return compartiment;
    }

    public static CompartimentsDTO toDto(Compartiment domain){
        CompartimentsDTO d=new CompartimentsDTO();
        d.setLibelle_compartiment(domain.getLibelle_compartiment());
        d.setDate_fin_compartiment(domain.getDate_fin_compartiment());
        d.setPresentation_eco_geo(domain.getPresentation_eco_geo());
        d.setId_fnd_code(domain.getId_fnd_code());
        d.setFnd_sht_description(domain.getFnd_sht_description());
        d.setFnd_lng_description(domain.getFnd_lng_description());

        return d;
 }

 public static Compartiment toDomain(CompartimentsDTO dto){
        Compartiment domain=new Compartiment();
        domain.setId_fnd_code(dto.getId_fnd_code());
        domain.setLibelle_compartiment(dto.getLibelle_compartiment());
        domain.setDate_fin_compartiment(dto.getDate_fin_compartiment());
        domain.setPresentation_eco_geo(dto.getPresentation_eco_geo());
        domain.setFnd_sht_description(dto.getFnd_sht_description());
        domain.setFnd_lng_description(dto.getFnd_lng_description());
        return domain;
        }
 }








