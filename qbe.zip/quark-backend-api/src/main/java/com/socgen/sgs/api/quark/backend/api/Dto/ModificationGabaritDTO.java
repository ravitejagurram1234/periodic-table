package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ModificationGabaritDTO {
    private MultipartFile file; //for upload
//    private byte[] contenu; //for download
//    private String fileName; // for download
    private Long p_idGabarit;
    private int p_id_typerapport;
    private Boolean is_actif;
    private Long type;
    private Integer id_gabarit_template;
    private Boolean pagination_double;
}

