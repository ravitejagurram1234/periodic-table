package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;
import com.socgen.sgs.api.quark.backend.api.service.Chargement_gabaritSerInterface;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
@Service
public class Chargement_gabaritService implements Chargement_gabaritSerInterface {
    public List<Enums.TypeGabarit> getAllTypeGabarits() {

        return Arrays.asList(Enums.TypeGabarit.values());
    }

    public List<Enums.pagination> getPagination()
    {
        return Arrays.asList(Enums.pagination.values());
    }

}
