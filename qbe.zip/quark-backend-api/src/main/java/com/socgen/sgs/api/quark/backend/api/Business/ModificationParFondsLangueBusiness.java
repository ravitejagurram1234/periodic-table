package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParFondsLangueDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
@Component
@Transactional
public class ModificationParFondsLangueBusiness {
   @Autowired
   private ModificationParFondsLangueDao modificationParFondsLangueDao;
  public List<ModificationParFondsLangue> getLangues(int p_id_sous_categorie, String p_id_fnd_code, String p_id_unit_code, LocalDate p_date_document){
   return modificationParFondsLangueDao.getLangues(p_id_sous_categorie,p_id_fnd_code,p_id_unit_code,p_date_document);
}

}
