package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.InsertTrace;
import com.socgen.sgs.api.quark.backend.api.domain.Suivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviAuditDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCsuiviAudit implements SuiviAuditDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCsuiviAudit(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_AUDIT")
                .withProcedureName("InsertTrace")
                .declareParameters(
                        new SqlParameter("p_ip", Types.VARCHAR),
                        new SqlParameter("p_startTime", Types.DATE),
                        new SqlParameter("p_endTime", Types.DATE),
                        new SqlParameter("p_page", Types.VARCHAR),
                        new SqlParameter("p_login", Types.VARCHAR),
                        new SqlParameter("p_module", Types.VARCHAR),
                        new SqlParameter("p_fonction", Types.VARCHAR),
                        new SqlParameter("p_message", Types.VARCHAR),
                        new SqlParameter("p_param1", Types.VARCHAR),
                        new SqlParameter("p_param2", Types.VARCHAR),
                        new SqlParameter("p_param3", Types.VARCHAR),
                        new SqlParameter("p_param4", Types.VARCHAR),
                        new SqlParameter("p_param5", Types.VARCHAR),
                        new SqlParameter("p_temps_reponse", Types.NUMERIC),
                        new SqlParameter("p_statut", Types.NUMERIC),
                        new SqlParameter("p_id_application", Types.NUMERIC),
                        new SqlParameter("p_nom_application", Types.VARCHAR),
                        new SqlOutParameter("p_id_trace", Types.NUMERIC)
                );
    }

    @Override
    public Long insertTrace(InsertTrace insertTrace) {
        Date sqlDate1= java.sql.Date.valueOf(insertTrace.getP_startTime());
        Date sqlDate2= java.sql.Date.valueOf(insertTrace.getP_endTime());
        Map<String, Object> params = new HashMap<>();
        params.put("p_ip",insertTrace.getP_ip());
        params.put("p_startTime", sqlDate1);
        params.put("p_endTime", sqlDate2);
        params.put("p_page", insertTrace.getP_page());
        params.put("p_login", insertTrace.getP_login());
        params.put("p_module", insertTrace.getP_module());
        params.put("p_fonction", insertTrace.getP_fonction());
        params.put("p_message", insertTrace.getP_message());
        params.put("p_param1", insertTrace.getP_param1());
        params.put("p_param2", insertTrace.getP_param2());
        params.put("p_param3", insertTrace.getP_param3());
        params.put("p_param4", insertTrace.getP_param4());
        params.put("p_param5", insertTrace.getP_param5());
        params.put("p_temps_reponse", insertTrace.getP_temps_reponse());
        params.put("p_statut", insertTrace.getP_statut());
        params.put("p_id_application", insertTrace.getP_id_application());
        params.put("p_nom_application", insertTrace.getP_nom_application());

        Map<String, Object> result = simpleJdbcCall.execute(params);
        BigDecimal outValue=(BigDecimal)result.get("p_id_trace");
        return outValue!=null?outValue.longValue():null;
    }

    }




