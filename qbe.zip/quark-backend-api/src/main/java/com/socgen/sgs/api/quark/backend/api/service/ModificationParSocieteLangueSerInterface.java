package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;

import java.time.LocalDate;
import java.util.List;

public interface ModificationParSocieteLangueSerInterface {
    List<ModificationParFondsLangue> getLangues(String p_societe, int p_id_sous_categorie, LocalDate p_date_document) ;
}
