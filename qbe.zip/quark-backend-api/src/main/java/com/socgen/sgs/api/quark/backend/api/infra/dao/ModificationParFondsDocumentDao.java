package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsDocument;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public interface ModificationParFondsDocumentDao {
   List<ModificationParFondsDocument> getDocumentName(String p_id_fnd_code, String p_id_unit_code, int p_id_sous_categorie, int p_id_langue, LocalDate p_date_document);

   }
