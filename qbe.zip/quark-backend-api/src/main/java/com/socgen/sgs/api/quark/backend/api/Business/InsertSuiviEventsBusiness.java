package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertSuiviEventDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Component
@Transactional
public class InsertSuiviEventsBusiness {
    @Autowired
    private InsertSuiviEventDao insertSuiviEventDao;

    public void insertSuiviEvent(Long p_idSuivi, Long p_idEvent, Long p_idUser, Long p_eventDataType, LocalDate p_eventDateEcheance){
        insertSuiviEventDao.insertSuiviEvent(p_idSuivi,p_idEvent,p_idUser,p_eventDataType,p_eventDateEcheance);
    }
}
