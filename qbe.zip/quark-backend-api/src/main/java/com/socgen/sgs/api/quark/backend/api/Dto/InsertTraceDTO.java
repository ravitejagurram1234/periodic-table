package com.socgen.sgs.api.quark.backend.api.Dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InsertTraceDTO {
    private String p_ip;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate p_startTime;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate p_endTime;

    private String p_page;
    private String p_login;
    private String p_module;
    private String p_fonction;
    private String p_message;
    private String p_param1;
    private String p_param2;
    private String p_param3;
    private String p_param4;
    private String p_param5;
    private Integer p_temps_reponse;
    private Integer p_statut;
    private Long p_id_application;
    private String p_nom_application;

}
