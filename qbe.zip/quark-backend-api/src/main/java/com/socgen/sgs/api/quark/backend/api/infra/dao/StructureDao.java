package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Structure;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface StructureDao {

    List<Structure> getListeStructuresForNewSuivi(
            Long idTypeRapport,
            Long idLangue,
            Long idGabarit,
            LocalDate dateEcheance
    );

    List<Structure> getListeStructures(String p_auditor, String p_accountant, String p_fundMgtCompany);

    Optional<Structure> getStructureById(String idStructure);
}
