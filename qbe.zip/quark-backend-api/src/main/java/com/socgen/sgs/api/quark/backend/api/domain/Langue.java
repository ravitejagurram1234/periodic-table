package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Langue {
    private Long id;
    private String nomLangue;
    private String valeur_langue;

    private Langue(Builder builder) {
        this.id = builder.id;
        this.nomLangue = builder.nomLangue;
        this.valeur_langue=builder.valeur_langue;
    }


    // Static builder method
    public static Builder builder() {
        return new Builder();
    }

    // Builder class
    public static class Builder {
        private Long id;
        private String nomLangue;
        private String valeur_langue;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }

        public Builder nomLangue(String nomLangue) {
            this.nomLangue = nomLangue;
            return this;
        }

        public Builder valeur_langue(String valeur_langue) {
            this.valeur_langue=valeur_langue;
            return this;
        }

        public Langue build() {
            return new Langue(this);
        }


    }
}
