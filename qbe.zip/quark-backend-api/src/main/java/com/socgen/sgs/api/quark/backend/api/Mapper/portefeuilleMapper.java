package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.domain.PrevSuiviEvents;
import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;

import java.sql.ResultSet;
import java.sql.SQLException;

public class portefeuilleMapper {
    public static portefeuille mapResult(ResultSet rs) throws SQLException {
        portefeuille p = new portefeuille();
        p.setId_fnd_code(rs.getString("ID_FND_CODE"));
        p.setDescription(rs.getString("DESCRIPTION"));
        return p;
    }

    public static portefeuilleDTO toDto(portefeuille p){
        portefeuilleDTO dto=new portefeuilleDTO();
        dto.setDescription( p.getDescription());
        return dto;
    }
}
