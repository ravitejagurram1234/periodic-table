package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;

import java.time.LocalDate;
import java.util.List;

public interface ModificationParFondsLangueSerInterface {
    List<ModificationParFondsLangue> getLangues(int p_id_sous_categorie, String p_id_fnd_code, String p_id_unit_code, LocalDate p_date_document);

}
