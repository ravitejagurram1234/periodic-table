package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SocieteDocumentDao;
import org.hibernate.validator.constraints.CodePointLength;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class SocieteDocumentBusiness {
    @Autowired
    private SocieteDocumentDao societeDocumentDao;
    public List<TypeDeDocument> getSocieteDocument(String p_societe){
        return societeDocumentDao.getSocieteDocument(p_societe);
    }
}
