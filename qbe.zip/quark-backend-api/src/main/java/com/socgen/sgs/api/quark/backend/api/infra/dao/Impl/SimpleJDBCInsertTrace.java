package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditInsertTraceDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

@Repository
public class SimpleJDBCInsertTrace implements AuditInsertTraceDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCInsertTrace(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_AUDIT")
                .withProcedureName("InsertTrace")
                .declareParameters(
                        new SqlOutParameter("p_id_trace", Types.INTEGER),
                        new SqlParameter("p_ip", Types.VARCHAR),
                        new SqlParameter("p_startTime", Types.DATE),
                        new SqlParameter("p_endTime", Types.DATE),
                        new SqlParameter("p_page", Types.VARCHAR),
                        new SqlParameter("p_login", Types.VARCHAR),
                        new SqlParameter("p_module", Types.VARCHAR),
                        new SqlParameter("p_fonction", Types.VARCHAR),
                        new SqlParameter("p_message", Types.VARCHAR),
                        new SqlParameter("p_param1", Types.VARCHAR),
                        new SqlParameter("p_param2", Types.VARCHAR),
                        new SqlParameter("p_param3", Types.VARCHAR),
                        new SqlParameter("p_param4", Types.VARCHAR),
                        new SqlParameter("p_param5", Types.VARCHAR),
                        new SqlParameter("p_temps_reponse", Types.NUMERIC),
                        new SqlParameter("p_statut", Types.NUMERIC),
                        new SqlParameter("p_id_application", Types.NUMERIC),
                        new SqlParameter("p_nom_application", Types.VARCHAR)
                );
    }

    @Override
    public Integer insertTrace(Audit audit) {
        Date sqlStartDate = (audit.getP_startTime() != null) ? java.sql.Date.valueOf(audit.getP_startTime()) : null;
        Date sqlEndDate = (audit.getP_endTime() != null) ? java.sql.Date.valueOf(audit.getP_endTime()) : null;

        Map<String, Object> params = new HashMap<>();
        params.put("p_ip", audit.getP_ip());
        params.put("p_startTime", sqlStartDate);
        params.put("p_endTime", sqlEndDate);
        params.put("p_page", audit.getP_page());
        params.put("p_login", audit.getP_login());
        params.put("p_module", audit.getP_module());
        params.put("p_fonction", audit.getP_fonction());
        params.put("p_message", audit.getP_message());
        params.put("p_param1", audit.getP_param1());
        params.put("p_param2", audit.getP_param2());
        params.put("p_param3", audit.getP_param3());
        params.put("p_param4", audit.getP_param4());
        params.put("p_param5", audit.getP_param5());
        params.put("p_temps_reponse", audit.getP_temps_reponse());
        params.put("p_statut", audit.getP_statut());
        params.put("p_id_application", audit.getP_id_application());
        params.put("p_nom_application", audit.getP_nom_application());

        Map<String, Object> result = simpleJdbcCall.execute(params);

        Number returnValue = (Number) result.get("p_id_trace");
        return (returnValue != null) ? returnValue.intValue() : null;
    }
}
