package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.StructureDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Structure;

import java.sql.ResultSet;
import java.sql.SQLException;

public class StructureMapper {

    public static Structure mapResult(ResultSet rs) throws SQLException {
        Structure structure = new Structure();
        structure.setIdStructure(rs.getString("ID_STRUCTURE"));
        structure.setNom(rs.getString("NOM"));
        structure.setLibelleLong(rs.getString("LIBELLE_LONG"));
        structure.setFndLegalType(rs.getString("FND_LEGAL_TYPE"));
        structure.setFndClassification(rs.getString("FND_CLASSIFICATION"));
        structure.setFndMngtCompany(rs.getString("FND_MNGT_COMPANY"));
        structure.setFndAccountant(rs.getString("FND_ACCOUNTANT"));
        structure.setCac(rs.getString("CAC"));
        structure.setDevise(rs.getString("DEVISE"));
        return structure;
    }

    /** Full DTO with all fields for structure detail view */
    public static StructureDTO toFullDto(Structure structure) {
        return StructureDTO.builder()
                .idStructure(structure.getIdStructure())
                .nom(structure.getNom())
                .libelleLong(structure.getLibelleLong())
                .fndLegalType(structure.getFndLegalType())
                .fndClassification(structure.getFndClassification())
                .fndMngtCompany(structure.getFndMngtCompany())
                .fndAccountant(structure.getFndAccountant())
                .cac(structure.getCac())
                .devise(structure.getDevise())
                .build();
    }

    /** Minimal DTO for dropdown lists (id + nom only) */
    public static StructureDTO toDto(Structure structure) {
        return StructureDTO.builder()
                .idStructure(structure.getIdStructure())
                .nom(structure.getNom())
                .build();
    }
}
