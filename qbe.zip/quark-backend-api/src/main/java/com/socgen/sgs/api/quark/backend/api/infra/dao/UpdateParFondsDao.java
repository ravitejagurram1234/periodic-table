package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Document;

public interface UpdateParFondsDao {
    void updateDocument(Document document);
}
