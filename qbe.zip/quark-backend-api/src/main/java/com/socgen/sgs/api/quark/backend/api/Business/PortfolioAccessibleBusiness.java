package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Constantes.Enums.TypeGabarit;
import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PortfolioAccessibleDao;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.GabaritRepository;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

@Component
@Transactional(readOnly = true)
public class PortfolioAccessibleBusiness {

    @Autowired
    private PortfolioAccessibleDao portfolioAccessibleDao;

    @Autowired
    private GabaritRepository gabaritRepository;

    public List<portefeuilleDTO> getAccessiblePortfolios(
            Long p_idTypeRapport,
            Long p_idGabarit,
            Long p_idLangue,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        if (p_idTypeRapport == null) {
            throw new IllegalArgumentException("p_idTypeRapport is required");
        }
        if (p_idLangue == null) {
            throw new IllegalArgumentException("p_idLangue is required");
        }
        if (p_idGabarit == null) {
            throw new IllegalArgumentException("p_idGabarit is required");
        }

        if (p_idTypeRapport == 4L) {
            return portfolioAccessibleDao.getListeCompartNonDispos(p_auditor, p_accountant, p_fundMgtCompany);
        }

        QxpGabarit gabarit = gabaritRepository.findByGabaritId(p_idGabarit)
                .orElseThrow(() -> new IllegalArgumentException("Gabarit not found for p_idGabarit: " + p_idGabarit));

        if (gabarit.getType() == null) {
            throw new IllegalArgumentException("Type not set for p_idGabarit: " + p_idGabarit);
        }

        TypeGabarit typeGabarit = TypeGabarit.fromValue(gabarit.getType());

        switch (typeGabarit) {
            case Fonds_simple:
            case FondsPart: {
                List<portefeuilleDTO> fonds = portfolioAccessibleDao.getFondsSimples(p_auditor, p_accountant, p_fundMgtCompany);
                fonds.sort(Comparator.comparing(portefeuilleDTO::getId_fnd_code, FondsCodeComparator.INSTANCE));
                return fonds;
            }
            case Structure:
                return portfolioAccessibleDao.getListeStructures(p_auditor, p_accountant, p_fundMgtCompany);
            default:
                throw new IllegalArgumentException("Unsupported typeGabarit: " + typeGabarit + " for p_idGabarit: " + p_idGabarit);
        }
    }
}
