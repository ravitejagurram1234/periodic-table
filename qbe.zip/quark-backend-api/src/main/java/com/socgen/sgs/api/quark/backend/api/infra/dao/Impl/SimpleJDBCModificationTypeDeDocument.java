package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.AccountantsMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.TypeDeDocumentMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Accountants;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationTypeDeDocumentDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCModificationTypeDeDocument implements ModificationTypeDeDocumentDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCModificationTypeDeDocument(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetTypesDocumentFonds")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> TypeDeDocumentMapper.mapResult(rs))
                );
    }

    @Override
    public List<TypeDeDocument> getListTypeDocuments() {
        try {
            Map<String, Object> result = simpleJdbcCall.execute();
            return (List<TypeDeDocument>) result.get("RETURN_VALUE");
        } catch (Exception e) {
            System.err.println("Error during JDBC call: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
}
