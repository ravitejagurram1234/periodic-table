package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Dto.ModificationParFondsDocumentDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationSocieteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCModificationSociete implements ModificationSocieteDao {
     private final SimpleJdbcCall simpleJdbcCall;

        @Autowired
        public SimpleJDBCModificationSociete(DataSource dataSource) {
            this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                    .withCatalogName("QXP_PK_CHARGEMENT")
                    .withFunctionName("GetListeSocieteDispos")
                    .withoutProcedureColumnMetaDataAccess()
                    .declareParameters(
                            new SqlOutParameter("RETURN_VALUE", oracle.jdbc.OracleTypes.CURSOR, (rs, rowNum) -> rs.getString("SOCIETE"))
                    );
        }

        public List<String> getListSociete() {
            Map<String, Object> result = simpleJdbcCall.execute();
            return (List<String>) result.get("RETURN_VALUE");
        }
}
