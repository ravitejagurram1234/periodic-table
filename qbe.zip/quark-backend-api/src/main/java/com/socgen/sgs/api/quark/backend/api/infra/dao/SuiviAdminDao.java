package com.socgen.sgs.api.quark.backend.api.infra.dao;

public interface SuiviAdminDao {
    String getDateExacteSuivi(Long p_idSuivi);
    void updateDateExacteSuivi(Long p_idSuivi, String p_newDate);
    Integer getTypeSuivi(Long p_idSuivi);
    void resetSuivi(Long p_idSuivi, String p_email);
    void removeSuivi(Long p_idSuivi, String p_email);
    void unlockSuivi(Long p_idSuivi);
}
