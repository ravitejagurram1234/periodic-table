package com.socgen.sgs.api.quark.backend.api.infra.dao;

import java.util.List;

public interface StructureValidateDao {
    List<String> getListeCompartsByStructure(String idStructure); // existing linked compartments
    Integer checkIfNoAssoCompartsGabarit(String idStructure, List<String> deletedCompartiments);

    void updateStructure(String idStructure, String nom, String libelleLong, String fndLegalType,
                         String fndClassification, String fndMngtCompany, String fndAccountant,
                         String cac, String devise);

    void updateLiensStructCompartiments(String idStructure, List<String> compartiments);
}
