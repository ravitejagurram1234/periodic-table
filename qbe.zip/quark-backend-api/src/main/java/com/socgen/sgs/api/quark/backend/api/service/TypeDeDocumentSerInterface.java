package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;

import java.util.List;

public interface TypeDeDocumentSerInterface {
    List<TypeDeDocument> getTypeDocument(String p_id_fnd_code , Long p_typeCategorieDocument);
}
