package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Document;

public interface UpdateParSocieteDao {
    void updateParSociete(Document document);
}
