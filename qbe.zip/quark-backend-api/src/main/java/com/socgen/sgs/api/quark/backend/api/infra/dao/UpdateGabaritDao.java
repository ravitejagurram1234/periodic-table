package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;

public interface UpdateGabaritDao {
    void updateGabarit(Gabarit gabarit,Long p_idGabarit);
}
