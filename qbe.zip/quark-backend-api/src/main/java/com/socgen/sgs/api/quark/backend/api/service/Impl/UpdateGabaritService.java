package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AuditParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.UpdateGabaritBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.UpdateParSocieteBusiness;
import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.GabaritsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ModificationGabaritDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;
import com.socgen.sgs.api.quark.backend.api.service.UpdateGabaritSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
@Service
public class UpdateGabaritService implements UpdateGabaritSerInterface {
    @Autowired
    private UpdateGabaritBusiness updateGabaritBusiness;

    @Autowired
    private AuditParFondsBusiness auditParFondsBusiness;

    public void updateGabarit(MultipartFile file, ModificationGabaritDTO dto) {
        int taille_document = (int) file.getSize();
        try {
            Gabarit gabarit = Gabarit.builder()
                    .contenu(file.getBytes())
                    .taille_document((long) taille_document)
                    .is_actif(dto.getIs_actif())
                    .type(dto.getType())
                    .id_gabarit_template(dto.getId_gabarit_template())
                    .pagination_double(dto.getPagination_double())
                    .build();
            updateGabaritBusiness.updateGabarit(gabarit, dto.getP_idGabarit());
        } catch (IOException e) {
            throw new RuntimeException("Error reading file bytes", e);
        }
    }




    public String getClientIp(HttpServletRequest request) {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.isEmpty() || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }




    public Integer AuditUpdateGabarit(MultipartFile file, ModificationGabaritDTO dto, String page, String user, HttpServletRequest request) {
        String originalFilename = file.getOriginalFilename();
        String p_nom_document = originalFilename.substring(0, originalFilename.lastIndexOf('.'));

        Enums.TypeRapport type = Enums.TypeRapport.fromValue(dto.getP_id_typerapport());
        Performance performance = new Performance();
        LocalDate start = LocalDate.now();
        LocalDate end = LocalDate.now();


        BigDecimal responseTime = performance.getSecondsAndMilliseconds();
        String clientIp = getClientIp(request);
        LocalDateTime now = LocalDateTime.now();
        String param1 = "Id gabarit : " + dto.getP_idGabarit();
        String param2 = "Nom gabarit : " + p_nom_document;
        String param3 = "Type rapport : " + type;
        String param4 = "Type gabarit : " + dto.getType();
        String param5 = "Id gabarit template : " +dto.getId_gabarit_template();
        String p_message="Modification gabarit effectuée avec succès";

        Audit audit = new Audit(clientIp, start, end, page, user, Chargement_constantes.MODULE_NAME,"UpdateGabarit",
                p_message, param1, param2, param3, param4, param5, responseTime, 0, 0, "");

        return auditParFondsBusiness.AuditParFonds(audit);
    }
}
