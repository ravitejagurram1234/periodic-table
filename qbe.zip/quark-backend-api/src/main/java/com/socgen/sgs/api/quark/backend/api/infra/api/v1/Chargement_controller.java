package com.socgen.sgs.api.quark.backend.api.infra.api.v1;


import com.socgen.apibank.http.ratelimiter.RateLimiter;
import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;
import com.socgen.sgs.api.quark.backend.api.Dto.*;
import com.socgen.sgs.api.quark.backend.api.Mapper.*;
import com.socgen.sgs.api.quark.backend.api.domain.*;
import com.socgen.sgs.api.quark.backend.api.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.Problem;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.http.MediaType.APPLICATION_PROBLEM_JSON_VALUE;
import static org.springframework.http.ResponseEntity.ok;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;

@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
@RestController
@RequestMapping(value = "/api/v1/")
public class Chargement_controller {

    private static final String QUOTA_EXCEEDED_EXAMPLE = "";

    @Autowired
    private portefeuilleSerInterface portefeuilleSerInterface;

    @GetMapping("/portefeuille")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<portefeuilleDTO>> getPortefeuille() {

        List<portefeuille> port = portefeuilleSerInterface.getPortefeuille();
        List<portefeuilleDTO> dtoList = port.stream().map(portefeuilleMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private TypeDeDocumentSerInterface typeDeDocumentSerInterface;

    @GetMapping("/TypeDeDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getTypeDeDocument(@RequestParam String p_id_fnd_code, @RequestParam Long p_typeCategorieDocument) {

        List<TypeDeDocument> port = typeDeDocumentSerInterface.getTypeDocument(p_id_fnd_code, p_typeCategorieDocument);
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @PostMapping(value = "/Document", consumes = "multipart/form-data")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(file.getOriginalFilename());
    }


    @Autowired
    private ValiderParFondsSerInterface validerParFondsSerInterface;
    @Autowired
    private IAuthenticationService authenticationService;

    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
    @Operation(summary = "Fetches FundAllocation items", description = "Fetches FundAllocation items")
    @PostMapping(value = "/ValiderParFonds", produces = APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)

    public ResponseEntity<String> getValider(
            @ModelAttribute final DocumentDTO dto,
            @RequestParam final String page,
            final HttpServletRequest request) {
        final MultipartFile file = dto.getFile();
        validerParFondsSerInterface.InsertParFonds(file, dto);
        final String userEmail = authenticationService.getCurrentUserEmailId()
                .orElseThrow(() -> new IllegalStateException("Authenticated user email not available"));
        validerParFondsSerInterface.AuditParFonds(file, dto, page, userEmail, request);
        return ResponseEntity.ok("success");
    }


    @Autowired
    private SocieteSerInterface societeSerInterface;

    @GetMapping("/Societe")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<SocieteDTO>> getSociete() {

        List<Societe> port = societeSerInterface.getSociete();
        List<SocieteDTO> dtoList = port.stream().map(SocieteMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private SocieteDocumentSerInterface societeDocumentSerInterface;

    @GetMapping("/SocieteDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getSocieteDocument(@RequestParam String p_societe) {

        List<TypeDeDocument> port = societeDocumentSerInterface.getSocieteDocument(p_societe);
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private ValiderParSocieteSerInterface validerParSocieteSerInterface;

    @PostMapping(value = "/ValiderParSociete", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getValiderParSociete(
            @ModelAttribute final DocumentDTO dto,
            @RequestParam final String page,
            final HttpServletRequest request) {
        final MultipartFile file = dto.getFile();
        validerParSocieteSerInterface.InsertParSociete(file, dto);
        final String userEmail = authenticationService.getCurrentUserEmailId()
                .orElseThrow(() -> new IllegalStateException("Authenticated user email not available"));
        validerParSocieteSerInterface.AuditParSociete(file, dto, page, userEmail, request);
        return ResponseEntity.ok("success");
    }

    @Autowired
    private Chargement_gabaritSerInterface gabarit;

    @GetMapping("/type-gabarits")
    public List<Enums.TypeGabarit> getTypeGabarits() {
        return gabarit.getAllTypeGabarits();
    }

    @GetMapping("/pagination")
    public List<Enums.pagination> getPagination() {

        return gabarit.getPagination();
    }

    @Autowired
    private categorieSerInterface categorieSerInterface;

    @GetMapping("/categorie")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getSocieteDocument(@RequestParam int p_idCategorie, @RequestParam int p_checkAtLeastOneDocument) {
        List<TypeDeDocument> port = categorieSerInterface.getListeSousCategorie(p_idCategorie, p_checkAtLeastOneDocument);
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private GabaritTemplateSerInterface gabaritTemplateSerInterface;

    @GetMapping("/gabarit-template")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<gabaritTemplateDTO>> getGabaritTemplate() {
        List<GabaritTemplate> port = gabaritTemplateSerInterface.getTemplates();
        List<gabaritTemplateDTO> dtoList = port.stream().map(GabaritTemplateMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }



    @Autowired
    private ValiderGabarit_InsertSerInterface validerGabaritSerInterface;

    @PostMapping(value = "/ValiderGabarit", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getValiderGabarit(
            @ModelAttribute final Chargement_gabaritDTO dto,
            @RequestParam final String page,
            final HttpServletRequest request) {
        final MultipartFile file = dto.getFile();
        final int gabaritId = validerGabaritSerInterface.insertGabarit(dto, file);
        if (gabaritId != 0) {
            final String userEmail = authenticationService.getCurrentUserEmailId()
                    .orElseThrow(() -> new IllegalStateException("Authenticated user email not available"));
            validerGabaritSerInterface.AuditGabarit(file, dto, page, userEmail, gabaritId, request);
        }
        return ResponseEntity.ok("success");
    }

    @Autowired
    private ValiderGabaritTemplateSerInterface validerGabaritTemplateSerInterface;

    @Autowired
    private UpdateGabaritTemplateSerInterface updateGabaritTemplateSerInterface;

    @PostMapping(value = "/GabaritTemplate", consumes = "multipart/form-data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = "application/json", examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getValiderGabaritTemplate(
            @RequestPart("file") final MultipartFile file,
            @RequestParam final String commentaire,
            @RequestParam final String page,
            final HttpServletRequest request) {
        final int gabaritId = validerGabaritTemplateSerInterface.insertGabaritTemplate(file, commentaire);
        if (gabaritId != 0) {
            final String userEmail = authenticationService.getCurrentUserEmailId()
                    .orElseThrow(() -> new IllegalStateException("Authenticated user email not available"));
            validerGabaritTemplateSerInterface.AuditGabaritTemplate(file, commentaire, page, userEmail, gabaritId, request);
        }
        return ResponseEntity.ok("success");
    }

    @PutMapping(value = "/GabaritTemplate/{id}", consumes = "multipart/form-data")
    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
    @Operation(summary = "Update Gabarit Template", description = "Updates an existing gabarit template with new file and details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Gabarit Template successfully updated"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = "application/json", examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> updateGabaritTemplate(@PathVariable int id, @RequestPart("file") MultipartFile file, @RequestParam String commentaire,
                                                        @RequestParam String page, HttpServletRequest request) {
        try {
            gabaritTemplateDTO dto = new gabaritTemplateDTO();
            dto.setId_gabarit_template(id);
            dto.setNom(file.getOriginalFilename());
            dto.setFile(file);

            updateGabaritTemplateSerInterface.updateGabaritTemplate(file, dto, commentaire);

            Optional<String> user_email = authenticationService.getCurrentUserEmailId();
            Integer auditId = updateGabaritTemplateSerInterface.auditUpdateGabaritTemplate(file, dto, page, user_email.orElse("unknown"), request);

            return ResponseEntity.ok("Gabarit template updated successfully");
        } catch (Exception e) {
            log.error("Error updating gabarit template: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error updating gabarit template: " + e.getMessage());
        }
    }


    @Autowired
    private DocumentQXPInsertSerInterface documentQXPInsertSerInterface;

    @PostMapping(value = "/DocumentQXP", consumes = "multipart/form-data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getValiderDocumentQXP(
            @RequestPart("file") final MultipartFile file,
            @RequestParam final String page,
            final HttpServletRequest request) {
        final Integer gabaritId = documentQXPInsertSerInterface.DocumentQXPInsert(file);
        if (gabaritId != 0) {
            final String userEmail = authenticationService.getCurrentUserEmailId()
                    .orElseThrow(() -> new IllegalStateException("Authenticated user email not available"));
            documentQXPInsertSerInterface.DocumentQXPaudit(file, page, userEmail, gabaritId, request);
        }
        return ResponseEntity.ok("success");
    }

    @Autowired
    private ModificationTypeDeDocumentSerInterface modificationTypeDeDocumentSerInterface;

    @GetMapping("/ModificationTypeDeDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getTypeDeDocument() {

        List<TypeDeDocument> port = modificationTypeDeDocumentSerInterface.getListTypeDocuments();
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private ModificationPortefeuilleSerInterface modificationPortefeuilleSerInterface;

    @GetMapping("/ModificationPortefeuille")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<portefeuilleDTO>> getPortefeuille(@RequestParam int p_id_sous_categorie) {

        List<portefeuille> port = modificationPortefeuilleSerInterface.getListPortefeuille(p_id_sous_categorie);
        List<portefeuilleDTO> dtoList = port.stream().map(portefeuilleMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private ModificationDateDocumentSerInterface modificationDateDocumentSerInterface;






    @GetMapping("/ModificationDateDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<LocalDate>> getDateDocument(@RequestParam int p_id_sous_categorie, @RequestParam String p_id_fnd_code, @RequestParam(required = false) String p_id_unit_code) {

        List<LocalDate> port = modificationDateDocumentSerInterface.getDateDocuments(p_id_sous_categorie, p_id_fnd_code, p_id_unit_code);

        return ok().cacheControl(CacheControl.noCache()).body(port);
    }

    @Autowired
    private ModificationParFondsLangueSerInterface modificationParFondsLangueSerInterface;

    @GetMapping("/ModificationParFondsLangue")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<ModificationParFondsLangueDTO>> getLangues(@RequestParam int p_id_sous_categorie, @RequestParam String p_id_fnd_code, @RequestParam(required = false) String p_id_unit_code, @RequestParam LocalDate p_date_document) {
        List<ModificationParFondsLangue> port = modificationParFondsLangueSerInterface.getLangues(p_id_sous_categorie, p_id_fnd_code, p_id_unit_code, p_date_document);
        List<ModificationParFondsLangueDTO> dtoList = port.stream().map(ModificationLangueMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }


    @Autowired
    private ModificationParFondsDocumentSerInterfce modificationParFondsDocumentSerInterfce;

    @GetMapping("/ModificationParFondsDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<ModificationParFondsDocumentDTO>> getDocuments(@RequestParam String p_id_fnd_code, @RequestParam(required = false) String p_id_unit_code, @RequestParam int p_id_sous_categorie, @RequestParam int p_id_langue, @RequestParam LocalDate p_date_document) {
        List<ModificationParFondsDocument> port = modificationParFondsDocumentSerInterfce.getDocumentName(p_id_fnd_code, p_id_unit_code, p_id_sous_categorie, p_id_langue, p_date_document);
        List<ModificationParFondsDocumentDTO> dtoList = port.stream().map(ModificationParFondsDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private ModificationSocieteSerInterface modificationSocieteSerInterface;

    @GetMapping("/ModificationSociete")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<String>> getModificationSociete() {
        List<String> societe = modificationSocieteSerInterface.getListSociete();
        return ok().cacheControl(CacheControl.noCache()).body(societe);

    }

    @Autowired
    private ModificationParSocieteTypeDocumentSerInterface modificationParSocieteTypeDocumentSerInterface;

    @GetMapping("/ModificationParSocieteTypeDeDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getParSocietetTypeDocuments(@RequestParam String p_societe) {
        List<TypeDeDocument> port = modificationParSocieteTypeDocumentSerInterface.getListeTypesDocumentsDispos(p_societe);
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private ModificationParSocieteDateDocumentSerInterface modificationParSocieteDateDocumentSerInterface;

    @GetMapping("/ModificationParSocieteDateDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<LocalDate>> getParSocieteDateDocuments(@RequestParam String p_societe, @RequestParam int p_id_sous_categorie) {
        List<LocalDate> dates = modificationParSocieteDateDocumentSerInterface.getDateDocuments(p_societe, p_id_sous_categorie);
        return ok().cacheControl(CacheControl.noCache()).body(dates);

    }

    @Autowired
    private ModificationParSocieteLangueSerInterface modificationParSocieteLangueSerInterface;

    @GetMapping("/ModificationParSocieteLangue")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<ModificationParFondsLangueDTO>> getLangues(@RequestParam String p_societe, @RequestParam int p_id_sous_categorie, @RequestParam LocalDate p_date_document) {
        List<ModificationParFondsLangue> port = modificationParSocieteLangueSerInterface.getLangues(p_societe, p_id_sous_categorie, p_date_document);
        List<ModificationParFondsLangueDTO> dtoList = port.stream().map(ModificationLangueMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }


    @Autowired
    private ModificationGabaritLangueSerInterface modificationGabaritLangueSerInterface;

    @GetMapping("/ModificationGabaritLangue")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<ModificationParFondsLangueDTO>> getGabaritLangues(@RequestParam int p_id_type_rapport) {
        List<ModificationParFondsLangue> port = modificationGabaritLangueSerInterface.getListLangue(p_id_type_rapport);
        List<ModificationParFondsLangueDTO> dtoList = port.stream().map(ModificationLangueMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private GabaritSerInterface gabaritSerInterface;

//    @GetMapping("/GetGabarit")
//
//    @ApiResponses(value = {
//            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
//            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
//                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
//            @ApiResponse(responseCode = "404", description = "Not found", content = {
//                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
//            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
//                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
//                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
//    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
//    public ResponseEntity<ModificationGabaritDTO> getGabarit(@RequestParam Long p_idGabarit) {
//        Gabarit gabarit = gabaritSerInterface.getGabarit(p_idGabarit);
//        ModificationGabaritDTO dtoList = GabaritMapper.toDto(gabarit);
//        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
//
//    }

    @GetMapping("/GetGabarit")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<?> getGabarit(@RequestParam Long p_idGabarit, @RequestParam(defaultValue = "false") boolean download) {
        Gabarit gabarit = gabaritSerInterface.getGabarit(p_idGabarit);

        if (download) {
            // Return file for download
            if (gabarit == null || gabarit.getContenu() == null) {
                return ResponseEntity.notFound().build();
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDisposition(ContentDisposition.attachment()
                    .filename(gabarit.getNom() != null ? gabarit.getNom() : "gabarit")
                    .build());
            headers.setContentLength(gabarit.getContenu().length);

            return new ResponseEntity<>(gabarit.getContenu(), headers, HttpStatus.OK);
        } else {
            // Return DTO with metadata
            ModificationGabaritDTO dtoList = GabaritMapper.toDto(gabarit);
            return ok().cacheControl(CacheControl.noCache()).body(dtoList);
        }
    }

    @Autowired
    private GetGabaritTemplateSerInterface getGabaritTemplateSerInterface;

    @GetMapping("/GetGabaritTemplates")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<?> getGabaritTemplate(@RequestParam Long p_idGabaritTemplate, @RequestParam(defaultValue = "false") boolean download) {
        GabaritTemplate gabaritTemplate = getGabaritTemplateSerInterface.getGabaritTemplate(p_idGabaritTemplate);

        if(download){
            if(gabaritTemplate == null || gabaritTemplate.getContenu() == null) {
                return ResponseEntity.notFound().build();
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDisposition(ContentDisposition.attachment()
                    .filename(gabaritTemplate.getNom() != null ? gabaritTemplate.getNom() : "gabarit_template")
                    .build());
            headers.setContentLength(gabaritTemplate.getContenu().length);

            return new ResponseEntity<>(gabaritTemplate.getContenu(), headers, HttpStatus.OK);
        }
        else {
            gabaritTemplateDTO dtoList = GabaritTemplateMapper.toDto(gabaritTemplate);
            return ok().cacheControl(CacheControl.noCache()).body(dtoList);
        }
    }


    @Autowired
    private CompartimentsStructureSerInterface compartimentsStructureSerInterface;

    @GetMapping("/CompartimentsStructure")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<StructureDTO>> getStructures(@RequestParam int p_withAtLeastOneCompatiment, @RequestParam(required = false) String p_auditor, @RequestParam(required = false) String p_accountant, @RequestParam(required = false) String p_fundMgtCompany) {
        List<Structure> structure = compartimentsStructureSerInterface.getStructures(p_withAtLeastOneCompatiment, p_auditor, p_accountant, p_fundMgtCompany);
        List<StructureDTO> dtoList = structure.stream().map(StructureMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private CompartimentsSerInterface compartimentsSerInterface;


    //**
    @GetMapping("/structures/accessibleportfoliosforstructuregabarit")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Accessible portfolios fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(
                            schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE,
                            examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)
                    )},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    }
            )
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<AccessiblePortfolioForStructureResponseDTO> getAccessiblePortfoliosForStructure(
            @RequestParam(name = "p_idStructure") final String idStructure,
            @RequestParam(name = "p_idGabarit") final Long idGabarit,
            @RequestParam(name = "p_auditor", required = false) final String auditor,
            @RequestParam(name = "p_accountant", required = false) final String accountant,
            @RequestParam(name = "p_fundMgtCompany", required = false) final String fundMgtCompany) {

        final String normalizedIdStructure = idStructure == null ? "" : idStructure.trim();

        // Legacy parity for CreationLiensStructureGabaritFonds:
        // base list must be loaded by structure only (no optional filters).
        final List<Compartiment> baseList = compartimentsSerInterface.getStructures(
                normalizedIdStructure, null, null, null);

        // selected list for structure + gabarit
        final List<Compartiment> selectedRaw = structureGabaritService.getListeCompartsByStructGab(
                normalizedIdStructure, idGabarit);

        // Temporary debug logs to validate environment behavior
        log.info("accessible-portfolios input idStructure={}, idGabarit={}", normalizedIdStructure, idGabarit);
        log.info("ignored filters for base list: auditor={}, accountant={}, fundMgtCompany={}", auditor, accountant, fundMgtCompany);
        log.info("baseList size={}, selectedRaw size={}", baseList.size(), selectedRaw.size());
        log.info("base codes raw={}", baseList.stream().map(Compartiment::getId_fnd_code).toList());
        log.info("selected codes raw={}", selectedRaw.stream().map(Compartiment::getId_fnd_code).toList());

        final Set<String> selectedNorm = selectedRaw.stream()
                .map(Compartiment::getId_fnd_code)
                .map(Chargement_controller::norm)
                .filter(value -> !value.isBlank())
                .collect(Collectors.toSet());

        // Preserve base order and deduplicate by normalized code
        final LinkedHashMap<String, AccessiblePortfolioForStructureResponseDTO.PortfolioItemDTO> baseByNorm = new LinkedHashMap<>();
        for (final Compartiment compartiment : baseList) {
            final String rawCode = compartiment.getId_fnd_code();
            final String normalizedCode = norm(rawCode);
            if (normalizedCode.isBlank()) {
                continue;
            }

            baseByNorm.putIfAbsent(
                    normalizedCode,
                    new AccessiblePortfolioForStructureResponseDTO.PortfolioItemDTO(
                            rawCode == null ? "" : rawCode.trim(),
                            firstNonBlank(compartiment.getFnd_sht_description(), "")
                    )
            );
        }

        // Split strictly from base list only
        final List<AccessiblePortfolioForStructureResponseDTO.PortfolioItemDTO> selected = baseByNorm.entrySet().stream()
                .filter(entry -> selectedNorm.contains(entry.getKey()))
                .map(Map.Entry::getValue)
                .toList();

        final List<AccessiblePortfolioForStructureResponseDTO.PortfolioItemDTO> available = baseByNorm.entrySet().stream()
                .filter(entry -> !selectedNorm.contains(entry.getKey()))
                .map(Map.Entry::getValue)
                .toList();

        return ok().cacheControl(CacheControl.noCache())
                .body(new AccessiblePortfolioForStructureResponseDTO(available, null));

    }

    private static String norm(final String value) {
        return value == null ? "" : value.trim().toUpperCase(java.util.Locale.ROOT);
    }

    private static String firstNonBlank(final String firstCandidate, final String secondCandidate) {
        if (Objects.nonNull(firstCandidate) && !firstCandidate.isBlank()) {
            return firstCandidate;
        }
        return secondCandidate;
    }




    @Autowired
    private UpdateParFondsSerInterface updateParFondsSerInterface;

    @PostMapping(value = "/UpdateParFonds", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getUpdateParFonds(
            @ModelAttribute final DocumentDTO dto,
            @RequestParam final String page,
            final HttpServletRequest request) {
        final MultipartFile file = dto.getFile();
        updateParFondsSerInterface.updateDocument(file, dto);
        final String userEmail = authenticationService.getCurrentUserEmailId()
                .orElseThrow(() -> new IllegalStateException("Authenticated user email not available"));
        updateParFondsSerInterface.AuditUpdateParFonds(file, dto, page, userEmail, request);
        return ResponseEntity.ok("success");
    }


    @Autowired
    private UpdateParSocieteSerInterface updateParSocieteSerInterface;

    @PostMapping(value = "/UpdateParSociete", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getUpdateParSociete(
            @ModelAttribute final DocumentDTO dto,
            @RequestParam final String page,
            final HttpServletRequest request) {
        final MultipartFile file = dto.getFile();
        final String userEmail = authenticationService.getCurrentUserEmailId()
                .orElseThrow(() -> new IllegalStateException("Authenticated user email not available"));
        updateParSocieteSerInterface.updateDocument(file, dto);
        updateParSocieteSerInterface.AuditUpdateParSociete(file, dto, page, userEmail, request);
        return ResponseEntity.ok("success");
    }

    @Autowired
    private UpdateGabaritSerInterface updateGabaritSerInterface;

    @PostMapping(value = "/UpdateGabarit", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getUpdateGabarit(
            @ModelAttribute final ModificationGabaritDTO dto,
            @RequestParam final String page,
            final HttpServletRequest request) {
        final MultipartFile file = dto.getFile();
        final String userEmail = authenticationService.getCurrentUserEmailId()
                .orElseThrow(() -> new IllegalStateException("Authenticated user email not available"));
        updateGabaritSerInterface.updateGabarit(file, dto);
        updateGabaritSerInterface.AuditUpdateGabarit(file, dto, page, userEmail, request);
        return ResponseEntity.ok("success");
    }

    @Autowired
    private UpdateCompartimentsSerInterface updateCompartimentsSerInterface;

    @PostMapping(value = "/UpdateCompartiments", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")

    public ResponseEntity<String> getUpdateCompartiments(
            @ModelAttribute final CompartimentsDTO dto,
            @RequestParam final String page,
            final HttpServletRequest request) {
        final String userEmail = authenticationService.getCurrentUserEmailId()
                .orElseThrow(() -> new IllegalStateException("Authenticated user email not available"));
        updateCompartimentsSerInterface.updateCompartimentInfos(dto);
        updateCompartimentsSerInterface.AuditUpdateCompartiments(dto, page, userEmail, request);
        return ResponseEntity.ok("success");
    }
}

