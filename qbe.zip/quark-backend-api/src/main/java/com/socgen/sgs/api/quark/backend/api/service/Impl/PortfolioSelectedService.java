package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.PortfolioSelectedBusiness;
import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.service.PortfolioSelectedSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PortfolioSelectedService implements PortfolioSelectedSerInterface {

    @Autowired
    private PortfolioSelectedBusiness portfolioSelectedBusiness;

    @Override
    public List<portefeuilleDTO> getSelectedPortfolios(
            Long p_idTypeRapport,
            Long p_idGabarit,
            Long p_idLangue,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {
        return portfolioSelectedBusiness.getSelectedPortfolios(
                p_idTypeRapport, p_idGabarit, p_idLangue, p_auditor, p_accountant, p_fundMgtCompany);
    }
}
