package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Langue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.LangueDao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public class LangueBusiness {
    private final LangueDao dao;
    public LangueBusiness(LangueDao dao){

        this.dao=dao;
    }
    public List<Langue> getLangue() {
        return this.dao.getLangue();
    }

}
