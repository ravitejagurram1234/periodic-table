package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.GabaritBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;
import com.socgen.sgs.api.quark.backend.api.service.GabaritSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.GabaritsSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.ParameterResolutionDelegate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GabaritService implements GabaritSerInterface {
    @Autowired
    private GabaritBusiness gabaritBusiness;

    public Gabarit  getGabarit(Long p_idGabarit){
        return gabaritBusiness.getGabarit(p_idGabarit);
    }


}
