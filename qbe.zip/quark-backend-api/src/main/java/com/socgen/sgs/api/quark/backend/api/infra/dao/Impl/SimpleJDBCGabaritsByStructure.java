package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.GabaritByStructureMapper;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritByStructure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritsByStructureDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCGabaritsByStructure implements GabaritsByStructureDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCGabaritsByStructure(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeNomsGabaritsByStruct")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> GabaritByStructureMapper.mapResult(rs)),
                        new SqlParameter("p_idStructure", Types.VARCHAR)
                );
    }

    @Override
    public List<GabaritByStructure> getGabaritsByStructure(String p_idStructure) {
        Map<String, Object> params = Map.of("p_idStructure", p_idStructure);
        Map<String, Object> result = simpleJdbcCall.execute(params);
        return (List<GabaritByStructure>) result.get("RETURN_VALUE");
    }
}
