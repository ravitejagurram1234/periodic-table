// src/main/java/.../infra/dao/Impl/SimpleJDBCStructureGabarit.java
package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.PresentationStructureMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.domain.PresentationStructure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureGabaritDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCStructureGabarit implements StructureGabaritDao {

    private final SimpleJdbcCall getPresentationStructureCall;
    private final SimpleJdbcCall getListeCompartsByStructGabCall;

    @Autowired
    public SimpleJDBCStructureGabarit(DataSource dataSource) {

        // QXP_PK_CHARGEMENT.GetPresentationStructure(p_idStructure, p_idGabarit)
        // Returns: id_presentation_patrimoine, id_presentation_compte_res
        this.getPresentationStructureCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetPresentationStructure")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR,
                                (rs, rowNum) -> PresentationStructureMapper.mapResult(rs)),
                        new SqlParameter("p_idStructure", Types.VARCHAR),
                        new SqlParameter("p_idGabarit",   Types.NUMERIC)
                );

        // QXP_PK_CHARGEMENT.GetListeCompartsByStructGab(p_idStructure, p_idGabarit)
        // Returns: standard EOS_VUE_PORTEFEUILLE columns — NO libelle_compartiment /
        //          date_fin_compartiment / presentation_eco_geo → custom inline mapper
        this.getListeCompartsByStructGabCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeCompartsByStructGab")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> {
                            Compartiment c = new Compartiment();
                            c.setKey_ref_fund(rs.getString("key_ref_fund"));
                            c.setId_fnd_code(rs.getString("id_fnd_code"));

                            java.sql.Date startValidity = rs.getDate("id_fnd_start_validity");
                            c.setId_fnd_start_validity(startValidity != null ? startValidity.toLocalDate() : null);

                            java.sql.Date endValidity = rs.getDate("fnd_end_validity");
                            c.setFnd_end_validity(endValidity != null ? endValidity.toLocalDate() : null);

                            c.setFnd_sht_description(rs.getString("fnd_sht_description"));
                            c.setFnd_lng_description(rs.getString("fnd_lng_description"));
                            c.setFnd_flg_multi_mngr(rs.getString("fnd_flg_multi_mngr"));
                            c.setFnd_chart_account(rs.getString("fnd_chart_account"));
                            c.setFnd_accountant(rs.getString("fnd_accountant"));
                            c.setId_act_code(rs.getString("id_act_code"));
                            c.setAct_socio_class(rs.getString("act_socio_class"));
                            c.setAct_lng_description(rs.getString("act_lng_description"));
                            c.setId_mng_code(rs.getString("id_mng_code"));
                            c.setDevise_poche(rs.getString("devise_poche"));
                            c.setMng_lng_description(rs.getString("mng_lng_description"));
                            c.setMngShtDescription(rs.getString("mng_sht_description"));
                            c.setId_mfm_manager_code(rs.getString("id_mfm_manager_code"));

                            java.sql.Date lastFiscal = rs.getDate("fnd_last_fiscal_year_end");
                            c.setFnd_last_fiscal_year_end(lastFiscal != null ? lastFiscal.toLocalDate() : null);

                            java.sql.Date nextFiscal = rs.getDate("fnd_next_fiscal_year_end");
                            c.setFnd_next_fiscal_year_end(nextFiscal != null ? nextFiscal.toLocalDate() : null);

                            c.setMfm_actor(rs.getString("mfm_actor"));
                            // libelle_compartiment, date_fin_compartiment, presentation_eco_geo
                            // are NOT in the Oracle query — leave null
                            return c;
                        }),
                        new SqlParameter("p_idStructure", Types.VARCHAR),
                        new SqlParameter("p_idGabarit",   Types.NUMERIC)
                );
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<PresentationStructure> getPresentationStructure(String idStructure, Long idGabarit) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_idStructure", idStructure);
        params.put("p_idGabarit",   idGabarit);

        Map<String, Object> result = getPresentationStructureCall.execute(params);
        Object rows = result.get("RETURN_VALUE");
        return rows == null ? Collections.emptyList() : (List<PresentationStructure>) rows;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Compartiment> getListeCompartsByStructGab(String idStructure, Long idGabarit) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_idStructure", idStructure);
        params.put("p_idGabarit",   idGabarit);

        Map<String, Object> result = getListeCompartsByStructGabCall.execute(params);
        Object rows = result.get("RETURN_VALUE");
        return rows == null ? Collections.emptyList() : (List<Compartiment>) rows;
    }
}
