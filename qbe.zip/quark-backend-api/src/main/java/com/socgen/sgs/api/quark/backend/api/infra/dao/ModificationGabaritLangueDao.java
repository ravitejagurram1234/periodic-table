package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;

import java.util.List;

public interface ModificationGabaritLangueDao {
     List<ModificationParFondsLangue> getListLangue(int p_id_type_rapport);
}
