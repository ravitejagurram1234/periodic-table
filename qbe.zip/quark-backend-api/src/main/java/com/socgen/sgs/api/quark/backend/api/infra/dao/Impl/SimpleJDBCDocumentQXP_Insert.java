package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.DocumentQXPInsertDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCDocumentQXP_Insert implements DocumentQXPInsertDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCDocumentQXP_Insert(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withProcedureName("InsertDocumentUpload")
                .declareParameters(
                        new SqlOutParameter("p_id_document_qxp", Types.INTEGER),
                        new SqlParameter("p_contenu", Types.VARBINARY),
                        new SqlParameter("p_taille_document", Types.INTEGER)

                );
    }

    @Override
    public Integer DocumentQXPInsert(byte[] p_contenu, int p_taille_document) {

        Map<String, Object> params = new HashMap<>();
        params.put("p_contenu", p_contenu);
        params.put("p_taille_document", p_taille_document);


        Map<String, Object> result = simpleJdbcCall.execute(params);

        Number returnValue=(Number) result.get("p_id_document_qxp");
        return (returnValue!=null)?returnValue.intValue():null;

    }
}
