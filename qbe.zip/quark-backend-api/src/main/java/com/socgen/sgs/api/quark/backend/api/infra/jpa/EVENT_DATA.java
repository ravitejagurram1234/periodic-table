package com.socgen.sgs.api.quark.backend.api.infra.jpa;

public interface EVENT_DATA {
    String getLibelle();
    Long getIdSuivi();

}
