package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.FondsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Fonds;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FondsMapper {

    public static Fonds mapResult(ResultSet rs) throws SQLException {
        Fonds fonds = new Fonds();
        fonds.setKey_ref_fund(rs.getString("KEY_REF_FUND"));
        fonds.setId_fnd_code(rs.getString("ID_FND_CODE"));
        fonds.setId_fnd_start_validity(rs.getString("ID_FND_START_VALIDITY"));
        fonds.setFnd_end_validity(rs.getString("FND_END_VALIDITY"));
        fonds.setFnd_sht_description(rs.getString("FND_SHT_DESCRIPTION"));
        fonds.setFnd_lng_description(rs.getString("FND_LNG_DESCRIPTION"));
        fonds.setFnd_flg_multi_mngr(rs.getString("FND_FLG_MULTI_MNGR"));
        fonds.setAct_socio_class(rs.getString("ACT_SOCIO_CLASS"));
        fonds.setId_mng_code(rs.getString("ID_MNG_CODE"));
        fonds.setMng_lng_description(rs.getString("MNG_LNG_DESCRIPTION"));
        fonds.setMng_sht_description(rs.getString("MNG_SHT_DESCRIPTION"));
        fonds.setId_mfm_manager_code(rs.getString("ID_MFM_MANAGER_CODE"));
        fonds.setId_act_code(rs.getString("ID_ACT_CODE"));
        return fonds;
    }

    public static Fonds mapResultFondsSimpleTest(ResultSet rs) throws SQLException {
        Fonds fonds = new Fonds();
        fonds.setId_fnd_code(rs.getString("ID_FND_CODE"));
        return fonds;
    }

    public static FondsDTO toDto(Fonds g) {
        return new FondsDTO(
                g.getKey_ref_fund(),
                g.getId_fnd_code(),
                g.getId_fnd_start_validity(),
                g.getFnd_end_validity(),
                g.getFnd_sht_description(),
                g.getFnd_lng_description(),
                g.getFnd_flg_multi_mngr(),
                g.getAct_socio_class(),
                g.getId_mng_code(),
                g.getMng_lng_description(),
                g.getMng_sht_description(),
                g.getId_mfm_manager_code(),
                g.getId_act_code()
        );
    }
}
