package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritByStructure;

import java.util.List;

public interface GabaritsByStructureDao {
    List<GabaritByStructure> getGabaritsByStructure(String p_idStructure);
}
