package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.DeviseBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Devise;
import com.socgen.sgs.api.quark.backend.api.service.DeviseSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeviseService implements DeviseSerInterface {

    @Autowired
    private DeviseBusiness deviseBusiness;

    @Override
    public List<Devise> getListeDevises() {
        return deviseBusiness.getListeDevises();
    }
}
