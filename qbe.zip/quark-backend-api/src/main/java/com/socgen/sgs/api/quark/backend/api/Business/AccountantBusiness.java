package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Accountants;
import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AccountantsDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FundMgtCompanyDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class AccountantBusiness {

        @Autowired
        private AccountantsDao dao;

        public List<Accountants> getAccountants(){
            return dao.getListAccountants();
        }
}
