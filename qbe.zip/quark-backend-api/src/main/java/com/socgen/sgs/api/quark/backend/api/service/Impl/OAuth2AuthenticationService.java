package com.socgen.sgs.api.quark.backend.api.service.Impl;


import com.socgen.sgs.api.quark.backend.api.service.IAuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.BearerTokenAuthentication;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class OAuth2AuthenticationService implements IAuthenticationService {

    private static final String SESAME_PROPERTY_NAME = "sesame_id";
    private static final String EMAIL_PROPERTY_NAME = "mail";
    private static final String GRANT_TYPE= "grant_type";
    private static final String CLIENT_CREDENTIALS = "client_credentials";
    public static final String EXTERNAL_API="external_api";

    private static final String FIRST_NAME = "first_name";

    private static final String LAST_NAME = "last_name";

//    @Autowired
//    private UserOverrideService usersOverrideService;

    public Authentication getAuthentication() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

    public boolean isClientCredentials(BearerTokenAuthentication authentication ){
        Object attribute =  authentication.getTokenAttributes().get(GRANT_TYPE);
        return attribute!=null && ((String)attribute).equals(CLIENT_CREDENTIALS);
    }

    public Optional<String> getUserProperty(String propertyName) {
        Authentication authentication = getAuthentication();
        if (authentication instanceof BearerTokenAuthentication) {
            Object attribute = ((BearerTokenAuthentication) authentication).getTokenAttributes().get(propertyName);
            return attribute != null ? Optional.of((String) attribute) : isClientCredentials((BearerTokenAuthentication) authentication)? Optional.of(EXTERNAL_API) : Optional.empty();
        } else {
            return Optional.empty();
        }
    }

    @Override
    public Optional<String> getCurrentUserSesameId() {
        return Optional.empty();
    }


    @Override
    public List<String> getAuthorities() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getAuthorities()
                .stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());
    }

    public Optional<String> getCurrentUserEmailId() {
        Optional<String> emailID = getUserProperty(EMAIL_PROPERTY_NAME);
        return emailID;
    }

    public Optional<String> getCurrentUserLastName() {
        return getUserProperty(LAST_NAME);
//        return usersOverrideService.getUsernameOverride(lastName);
    }

    public Optional<String> getCurrentUserFirstName() {
        return  getUserProperty(FIRST_NAME);
//        return usersOverrideService.getUsernameOverride(firstName);
    }

    public Optional<String> getCurrentUserFullName() {
        Optional<String> firstName = (getUserProperty(FIRST_NAME));
        Optional<String> lastName =  (getUserProperty(LAST_NAME));
        if(firstName.isPresent() && lastName.isPresent()){
            return Optional.of(lastName.get() + " " + firstName.get());
        }
        return Optional.empty();
    }
}
