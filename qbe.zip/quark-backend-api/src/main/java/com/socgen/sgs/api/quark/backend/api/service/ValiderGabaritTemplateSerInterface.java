package com.socgen.sgs.api.quark.backend.api.service;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

public interface ValiderGabaritTemplateSerInterface {

        Integer insertGabaritTemplate(MultipartFile file, String commentaire);
        String getClientIp(HttpServletRequest request);
        Integer AuditGabaritTemplate(MultipartFile file, String commentaire, String page, String user, int gabarit_id,
        HttpServletRequest request);
}
