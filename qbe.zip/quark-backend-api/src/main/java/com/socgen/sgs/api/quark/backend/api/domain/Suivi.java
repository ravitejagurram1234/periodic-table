package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Suivi {
        private Long p_id_type_rapport;
        private LocalDate p_date_echeance;
        private Long p_id_langue;
        private Long p_id_maquettiste;
        private Long p_id_gabarit;
        private Long p_id_createur;
        private Long p_id_suivi;
        private String p_id;
        private String p_id_unit_code;
        private String p_date_echeance_exacte;

        public static Builder builder() {
                return new Builder();
        }

        public static class Builder {
                private Long p_id_type_rapport;
                private LocalDate p_date_echeance;
                private Long p_id_langue;
                private Long p_id_maquettiste;
                private Long p_id_gabarit;
                private Long p_id_createur;
                private Long p_id_suivi;
                private String p_id;
                private String p_id_unit_code;
                private String p_date_echeance_exacte;

                public Builder p_id_type_rapport(Long p_id_type_rapport) {
                        this.p_id_type_rapport = p_id_type_rapport;
                        return this;
                }

                public Builder p_date_echeance(LocalDate p_date_echeance) {
                        this.p_date_echeance = p_date_echeance;
                        return this;
                }

                public Builder p_id_langue(Long p_id_langue) {
                        this.p_id_langue = p_id_langue;
                        return this;
                }

                public Builder p_id_maquettiste(Long p_id_maquettiste) {
                        this.p_id_maquettiste = p_id_maquettiste;
                        return this;
                }

                public Builder p_id_gabarit(Long p_id_gabarit) {
                        this.p_id_gabarit = p_id_gabarit;
                        return this;
                }

                public Builder p_id_createur(Long p_id_createur) {
                        this.p_id_createur = p_id_createur;
                        return this;
                }

                public Builder p_id_suivi(Long p_id_suivi) {
                        this.p_id_suivi = p_id_suivi;
                        return this;
                }

                public Builder p_id(String p_id) {
                        this.p_id = p_id;
                        return this;
                }

                public Builder p_id_unit_code(String p_id_unit_code) {
                        this.p_id_unit_code = p_id_unit_code;
                        return this;
                }

                public Builder p_date_echeance_exacte(String p_date_echeance_exacte) {
                        this.p_date_echeance_exacte = p_date_echeance_exacte;
                        return this;
                }

                public Suivi build() {
                        Suivi suivi = new Suivi();
                        suivi.p_id_type_rapport = this.p_id_type_rapport;
                        suivi.p_date_echeance = this.p_date_echeance;
                        suivi.p_id_langue = this.p_id_langue;
                        suivi.p_id_maquettiste = this.p_id_maquettiste;
                        suivi.p_id_gabarit = this.p_id_gabarit;
                        suivi.p_id_createur = this.p_id_createur;
                        suivi.p_id_suivi = this.p_id_suivi;
                        suivi.p_id = this.p_id;
                        suivi.p_id_unit_code = this.p_id_unit_code;
                        suivi.p_date_echeance_exacte = this.p_date_echeance_exacte;
                        return suivi;
                }
        }
}


