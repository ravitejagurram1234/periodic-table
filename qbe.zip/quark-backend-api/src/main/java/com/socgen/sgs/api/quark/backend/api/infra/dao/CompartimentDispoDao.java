package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import java.util.List;

public interface CompartimentDispoDao {
    List<Compartiment> getListeCompartsDispos(String idStructure);
}
