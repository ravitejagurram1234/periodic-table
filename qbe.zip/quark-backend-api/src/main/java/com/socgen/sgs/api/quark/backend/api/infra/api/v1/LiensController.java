package com.socgen.sgs.api.quark.backend.api.infra.api.v1;

import com.socgen.apibank.http.ratelimiter.RateLimiter;
import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentDispoDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.DeviseDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.GabaritByStructureDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.LiensFondsGabaritResponseDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.PresentationStructureDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.StructureDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.StructureGabaritFondsResponseDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateLiensFondsGabaritDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureGabaritFondsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureRequestDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureResponseDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.CompartimentMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.DeviseMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.GabaritByStructureMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.PresentationStructureMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.StructureMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.domain.Devise;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritByStructure;
import com.socgen.sgs.api.quark.backend.api.domain.PresentationStructure;
import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.service.CompartimentsSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.DeviseSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.GabaritsByStructureSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.IAuthenticationService;
import com.socgen.sgs.api.quark.backend.api.service.PortfolioAccessibleSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.PortfolioSelectedSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.StructureCreationSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.StructureGabaritSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.StructureSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.StructureValidateSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.ValidateLiensFondsGabaritSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.ValidateStructureGabaritFondsSerInterface;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.parsing.Problem;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_PROBLEM_JSON_VALUE;
import static org.springframework.http.ResponseEntity.ok;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

/**
 * REST controller for managing liens (links/associations) between:
 * - Portfolios (fonds, structures, compartments)
 * - Gabarits (templates)
 * - Structures
 *
 * Handles accessible/selected portfolios, structure-gabarit links, and validation operations.
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/v1")
@RequiredArgsConstructor
public class LiensController {

  private static final String QUOTA_EXCEEDED_EXAMPLE = "";

  private final PortfolioAccessibleSerInterface portfolioAccessibleService;
  private final PortfolioSelectedSerInterface portfolioSelectedService;
  private final StructureSerInterface structureSerInterface;
  private final DeviseSerInterface deviseSerInterface;
  private final CompartimentsSerInterface compartimentsSerInterface;
  private final ValidateLiensFondsGabaritSerInterface validateLiensFondsGabaritService;
  private final StructureCreationSerInterface structureCreationService;
  private final GabaritsByStructureSerInterface gabaritsByStructureSerInterface;
  private final StructureValidateSerInterface structureValidateService;
  private final StructureGabaritSerInterface structureGabaritService;
  private final ValidateStructureGabaritFondsSerInterface validateStructureGabaritFondsService;
  private final IAuthenticationService authenticationService;

  // ==================== PORTFOLIO ACCESSIBLE ====================

  /**
   * GET /api/v1/portfolio/accessible
   * Purpose: Return accessible portfolios based on TypeRapport and TypeGabarit
   * Rules:
   * - If TypeRapport == RapportCompartiment (4): Load compartiments (ignore TypeGabarit)
   * - If TypeGabarit == Fonds (0) or FondsPart (2): Load Fonds
   * - If TypeGabarit == Structure (1): Load Structures
   * TypeGabarit is resolved server-side from p_idGabarit (DB field: type)
   */
  @GetMapping("/portfolio/accessible")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Accessible portfolios successfully fetched"),
    @ApiResponse(responseCode = "400", description = "Bad Request - Missing required parameters",
      content = @Content(schema = @Schema(implementation = Problem.class),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
    @ApiResponse(responseCode = "429", description = "Quota exceeded",
      content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE,
        examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
      headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
        @Header(name = "X-RateLimit-Reset")})
  })
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  public ResponseEntity<List<portefeuilleDTO>> getAccessiblePortfolios(
      @RequestParam(name = "p_idTypeRapport") final Long p_idTypeRapport,
      @RequestParam(name = "p_idGabarit") final Long p_idGabarit,
      @RequestParam(name = "p_idLangue") final Long p_idLangue,
      @RequestParam(name = "p_auditor", required = false) final String p_auditor,
      @RequestParam(name = "p_accountant", required = false) final String p_accountant,
      @RequestParam(name = "p_fundMgtCompany", required = false) final String p_fundMgtCompany) {

    final List<portefeuilleDTO> portfolios = portfolioAccessibleService.getAccessiblePortfolios(
      p_idTypeRapport, p_idGabarit, p_idLangue, p_auditor, p_accountant, p_fundMgtCompany);

    return ok().cacheControl(CacheControl.noCache()).body(portfolios);
  }

  // ==================== PORTFOLIO SELECTED ====================

  /**
   * GET /api/v1/portfolio/selected
   * Purpose: Return selected portfolios (already linked to a gabarit)
   * - If TypeRapport == RapportCompartiment (4): Use GetListeCompartsByGabarit
   * - If TypeGabarit == Fonds (0) or FondsPart (2): Use GetFondsSimplesByGabarit
   * - If TypeGabarit == Structure (1): Use GetListeStructuresByGabarit
   */
  @GetMapping("/portfolio/selected")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Selected portfolios successfully fetched"),
    @ApiResponse(responseCode = "400", description = "Bad Request - Missing required parameters",
      content = @Content(schema = @Schema(implementation = Problem.class),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
    @ApiResponse(responseCode = "429", description = "Quota exceeded",
      content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE,
        examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
      headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
        @Header(name = "X-RateLimit-Reset")})
  })
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  public ResponseEntity<List<portefeuilleDTO>> getSelectedPortfolios(
      @RequestParam(name = "p_idTypeRapport") final Long p_idTypeRapport,
      @RequestParam(name = "p_idGabarit") final Long p_idGabarit,
      @RequestParam(name = "p_idLangue") final Long p_idLangue,
      @RequestParam(name = "p_auditor", required = false) final String p_auditor,
      @RequestParam(name = "p_accountant", required = false) final String p_accountant,
      @RequestParam(name = "p_fundMgtCompany", required = false) final String p_fundMgtCompany) {

    final List<portefeuilleDTO> portfolios = portfolioSelectedService.getSelectedPortfolios(
      p_idTypeRapport, p_idGabarit, p_idLangue, p_auditor, p_accountant, p_fundMgtCompany);

    return ok().cacheControl(CacheControl.noCache()).body(portfolios);
  }

  // ==================== VALIDATE LIEN GABARIT FONDS ====================

  /**
   * POST /api/v1/ValidateLienGabaritFonds
   * Validate Gabarit — link fonds
   * Calls QXP_PK_CHARGEMENT.InsertLiensFondsGabarit
   * Deletes existing links and inserts the new list into QXP_ASSO_FOND_GABARIT
   */
  @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
  @Operation(
    summary = "Validate Gabarit — link fonds",
    description = "Calls QXP_PK_CHARGEMENT.InsertLiensFondsGabarit. " +
      "Deletes existing links and inserts the new list into QXP_ASSO_FOND_GABARIT.",
    security = @SecurityRequirement(name = "sgconnect", scopes = {"api.ast-link-app.v1"})
  )
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Gabarit validated and fonds linked"),
    @ApiResponse(responseCode = "400", description = "Invalid request body",
      content = @Content(schema = @Schema(implementation = Problem.class),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE))
  })
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  @PostMapping(value = "/ValidateLienGabaritFonds", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<LiensFondsGabaritResponseDTO> validateLienGabaritFonds(
      @RequestBody final ValidateLiensFondsGabaritDTO dto,
      final HttpServletRequest request) {

    final LiensFondsGabaritResponseDTO response =
      validateLiensFondsGabaritService.validateAndLinkFonds(dto, request);

    if (response.isSuccess()) {
      final String userEmail = authenticationService.getCurrentUserEmailId().orElse("UNKNOWN");
      validateLiensFondsGabaritService.auditLiensFondsGabarit(
        dto, "gabarits/validate", userEmail, request);
      return ok().cacheControl(CacheControl.noCache()).body(response);
    } else {
      return ResponseEntity.badRequest().body(response);
    }
  }

  // ==================== STRUCTURES ====================

  /**
   * GET /api/v1/structures
   * Returns list of structures with optional filtering
   */
  @GetMapping("/structures")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Structures successfully fetched"),
    @ApiResponse(responseCode = "400", description = "Bad Request", content = {
      @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
    @ApiResponse(responseCode = "404", description = "Not found", content = {
      @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)})
  })
  public ResponseEntity<List<StructureDTO>> getListeStructures(
      @RequestParam(required = false) final String p_auditor,
      @RequestParam(required = false) final String p_accountant,
      @RequestParam(required = false) final String p_fundMgtCompany) {

    final List<Structure> structures = structureSerInterface.getListeStructures(
      p_auditor, p_accountant, p_fundMgtCompany);
    final List<StructureDTO> dtoList = structures.stream()
      .map(StructureMapper::toDto)
      .toList();
    return ok().cacheControl(CacheControl.noCache()).body(dtoList);
  }

  /**
   * GET /api/v1/structures/{idStructure}
   * Returns structure details by ID
   * If idStructure = "NOUVELLE_STRUCTURE", returns empty structure for creation form
   */
  @GetMapping("/structures/{idStructure}")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Structure details fetched"),
    @ApiResponse(responseCode = "404", description = "Structure not found",
      content = @Content(schema = @Schema(implementation = Problem.class),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE))
  })
  public ResponseEntity<StructureDTO> getStructureDetails(@PathVariable final String idStructure) {
    try {
      final StructureDTO dto = structureCreationService.getStructureDetails(idStructure);
      return ok().cacheControl(CacheControl.noCache()).body(dto);
    } catch (IllegalArgumentException e) {
      return ResponseEntity.notFound().build();
    }
  }

  /**
   * POST /api/v1/structures
   * Create new structure
   * Validates that structure doesn't already exist
   */
  @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
  @PostMapping(value = "/structures", produces = APPLICATION_JSON_VALUE)
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Structure created successfully"),
    @ApiResponse(responseCode = "400", description = "Bad Request - Structure already exists or invalid data",
      content = @Content(schema = @Schema(implementation = Problem.class),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE))
  })
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  public ResponseEntity<?> createStructure(@RequestBody final StructureDTO dto) {
    try {
      final StructureDTO created = structureCreationService.createStructure(dto);
      return ok().cacheControl(CacheControl.noCache()).body(created);
    } catch (IllegalStateException | IllegalArgumentException e) {
      return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
    }
  }

  // ==================== DEVISES ====================

  /**
   * GET /api/v1/devises
   * Returns list of currencies
   */
  @GetMapping("/devises")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Devises successfully fetched"),
    @ApiResponse(responseCode = "400", description = "Bad Request", content = {
      @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
    @ApiResponse(responseCode = "404", description = "Not found", content = {
      @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
    @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
      @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE,
        examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
      headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
        @Header(name = "X-RateLimit-Reset")})})
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  public ResponseEntity<List<DeviseDTO>> getListeDevises() {
    final List<Devise> devises = deviseSerInterface.getListeDevises();
    final List<DeviseDTO> dtoList = devises.stream().map(DeviseMapper::toDto).toList();
    return ok().cacheControl(CacheControl.noCache()).body(dtoList);
  }

  // ==================== COMPARTIMENTS ====================

  /**
   * GET /api/v1/Compartiments
   * Returns compartments for a structure
   */
  @GetMapping("/Compartiments")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
    @ApiResponse(responseCode = "400", description = "Bad Request", content = {
      @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
    @ApiResponse(responseCode = "404", description = "Not found", content = {
      @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
    @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
      @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
      headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
        @Header(name = "X-RateLimit-Reset")})})
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  public ResponseEntity<List<CompartimentsDTO>> getCompartiments(
      @RequestParam final String p_idStructure,
      @RequestParam(required = false) final String p_auditor,
      @RequestParam(required = false) final String p_accountant,
      @RequestParam(required = false) final String p_fundMgtCompany) {

    final List<Compartiment> compartiments = compartimentsSerInterface.getStructures(
      p_idStructure, p_auditor, p_accountant, p_fundMgtCompany);
    final List<CompartimentsDTO> dtoList = compartiments.stream()
      .map(CompartimentMapper::toDto)
      .toList();
    return ok().cacheControl(CacheControl.noCache()).body(dtoList);
  }

  // ==================== COMPARTIMENTS DISPOS ====================

  /**
   * GET /api/v1/compartiments-dispos
   * Returns compartments available for structure creation
   * p_id_structure: specific structure ID or "%" for all
   */
  @GetMapping("/compartiments-dispos")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Compartiments dispos fetched"),
    @ApiResponse(responseCode = "400", description = "Bad Request",
      content = @Content(schema = @Schema(implementation = Problem.class),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE))
  })
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  public ResponseEntity<List<CompartimentDispoDTO>> getCompartimentsDispos(
      @RequestParam(name = "p_id_structure", defaultValue = "%") final String idStructure) {

    final List<CompartimentDispoDTO> compartiments =
      structureCreationService.getCompartimentsDispos(idStructure);
    return ok().cacheControl(CacheControl.noCache()).body(compartiments);
  }

  // ==================== VALIDATE LIEN STRUCTURE FONDS ====================

  /**
   * POST /api/v1/ValidateLienStructureFonds
   * Validate structure-fonds links
   */
  @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
  @PostMapping(value = "/ValidateLienStructureFonds", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<?> validateLienStructureFonds(
      @RequestBody final ValidateStructureRequestDTO dto) {
    try {
      final ValidateStructureResponseDTO response = structureValidateService.validateStructure(dto);
      return ok().cacheControl(CacheControl.noCache()).body(response);
    } catch (IllegalArgumentException | IllegalStateException e) {
      return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
    }
  }

  // ==================== GABARITS BY STRUCTURE ====================

  /**
   * GET /api/v1/GabaritsByStructure
   * Returns gabarits for a specific structure
   */
  @GetMapping("/GabaritsByStructure")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
    @ApiResponse(responseCode = "400", description = "Bad Request", content = {
      @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
    @ApiResponse(responseCode = "404", description = "Not found", content = {
      @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
    @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
      @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE,
        examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
      headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
        @Header(name = "X-RateLimit-Reset")})})
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  public ResponseEntity<List<GabaritByStructureDTO>> getGabaritsByStructure(
      @RequestParam final String p_idStructure) {

    final List<GabaritByStructure> gabarits =
      gabaritsByStructureSerInterface.getGabaritsByStructure(p_idStructure);
    final List<GabaritByStructureDTO> dtoList = gabarits.stream()
      .sorted(Comparator.comparingLong(g -> {
        try {
          return Long.parseLong(g.getNom().trim().split("\\s+")[0].replaceAll("[^0-9]", ""));
        } catch (NumberFormatException e) {
          return Long.MAX_VALUE;
        }
      }))
      .map(GabaritByStructureMapper::toDto)
      .toList();
    return ok().cacheControl(CacheControl.noCache()).body(dtoList);
  }

  // ==================== STRUCTURES PRESENTATION ====================

  /**
   * GET /api/v1/structures/presentation
   * Returns id_presentation_patrimoine + id_presentation_compte_res
   * for the given structure + gabarit combination
   * Calls QXP_PK_CHARGEMENT.GetPresentationStructure(p_idStructure, p_idGabarit)
   */
  @GetMapping("/structures/presentation")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Presentation structure fetched"),
    @ApiResponse(responseCode = "400", description = "Bad Request",
      content = @Content(schema = @Schema(implementation = Problem.class),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
    @ApiResponse(responseCode = "429", description = "Quota exceeded",
      content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE,
        examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
      headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
        @Header(name = "X-RateLimit-Reset")})
  })
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  public ResponseEntity<List<PresentationStructureDTO>> getPresentationStructure(
      @RequestParam(name = "p_idStructure") final String idStructure,
      @RequestParam(name = "p_idGabarit") final Long idGabarit) {

    final List<PresentationStructure> results =
      structureGabaritService.getPresentationStructure(idStructure, idGabarit);

    final List<PresentationStructureDTO> dtoList = results.stream()
      .map(PresentationStructureMapper::toDto)
      .toList();

    return ok().cacheControl(CacheControl.noCache()).body(dtoList);
  }

  // ==================== PORTFOLIO SELECTED BY STRUCT GAB ====================

  /**
   * GET /api/v1/portfolio/selected-by-struct-gab
   * Returns compartments already linked to the given structure + gabarit,
   * ordered by position. Used for the structure-gabarit-fonds page.
   * Calls QXP_PK_CHARGEMENT.GetListeCompartsByStructGab(p_idStructure, p_idGabarit)
   */
  @GetMapping("/portfolio/selected-by-struct-gab")
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Compartments for structure-gabarit fetched"),
    @ApiResponse(responseCode = "400", description = "Bad Request",
      content = @Content(schema = @Schema(implementation = Problem.class),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
    @ApiResponse(responseCode = "429", description = "Quota exceeded",
      content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE,
        examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
      headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
        @Header(name = "X-RateLimit-Reset")})
  })
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  public ResponseEntity<List<CompartimentsDTO>> getListeCompartsByStructGab(
      @RequestParam(name = "p_idStructure") final String idStructure,
      @RequestParam(name = "p_idGabarit") final Long idGabarit) {

    final List<Compartiment> results =
      structureGabaritService.getListeCompartsByStructGab(idStructure, idGabarit);

    final List<CompartimentsDTO> dtoList = results.stream()
      .map(CompartimentMapper::toDto)
      .toList();

    return ok().cacheControl(CacheControl.noCache()).body(dtoList);
  }

  // ==================== VALIDATE STRUCTURE GABARIT FONDS ====================

  /**
   * POST /api/v1/ValidateStructureGabaritFonds
   * Deletes all existing compartiment associations for the given structure+gabarit,
   * then re-inserts the supplied list with position ordering.
   * Calls QXP_PK_GP.InsertLiensStructGabComparts(
   *     p_idStructure, p_idGabarit, p_listeCompartiments,
   *     p_idPresentationPatrimoine, p_idPresentationCompteRes)
   */
  @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
  @Operation(
    summary = "Validate Structure-Gabarit-Fonds links",
    description = "Replaces compartiment associations for a structure+gabarit combination. " +
      "Deletes existing rows in QXP_ASSO_STRUCT_GABARIT_COMP then inserts the new list " +
      "with position ordering.",
    security = @SecurityRequirement(name = "sgconnect", scopes = {"api.ast-link-app.v1"})
  )
  @ApiResponses({
    @ApiResponse(responseCode = "200", description = "Compartiments linked successfully"),
    @ApiResponse(responseCode = "400", description = "Invalid request body",
      content = @Content(schema = @Schema(implementation = Problem.class),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
    @ApiResponse(responseCode = "429", description = "Quota exceeded",
      content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
        mediaType = APPLICATION_PROBLEM_JSON_VALUE,
        examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
      headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
        @Header(name = "X-RateLimit-Reset")})
  })
  @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
  @PostMapping(value = "/ValidateStructureGabaritFonds", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<StructureGabaritFondsResponseDTO> validateStructureGabaritFonds(
      @RequestBody final ValidateStructureGabaritFondsDTO dto,
      final HttpServletRequest request) {

    final StructureGabaritFondsResponseDTO response =
      validateStructureGabaritFondsService.validateAndLinkCompartiments(dto, request);

    if (response.isSuccess()) {
      return ok().cacheControl(CacheControl.noCache()).body(response);
    } else {
      return ResponseEntity.badRequest().body(response);
    }
  }
}
