package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.GabaritByStructureDTO;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritByStructure;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GabaritByStructureMapper {

    public static GabaritByStructure mapResult(ResultSet rs) throws SQLException {
        GabaritByStructure g = new GabaritByStructure();
        g.setId_gabarit(rs.getInt("ID_GABARIT"));
        g.setNom(rs.getString("NOM"));
        return g;
    }

    public static GabaritByStructureDTO toDto(GabaritByStructure g) {
        return new GabaritByStructureDTO(g.getId_gabarit(), g.getNom());
    }
}
