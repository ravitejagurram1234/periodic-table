package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Constantes.Enums.TypeGabarit;
import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PortfolioSelectedDao;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.GabaritRepository;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class PortfolioSelectedBusiness {

    private final PortfolioSelectedDao portfolioSelectedDao;
    private final GabaritRepository gabaritRepository;

    public List<portefeuilleDTO> getSelectedPortfolios(
            final Long p_idTypeRapport,
            final Long p_idGabarit,
            final Long p_idLangue,
            final String p_auditor,
            final String p_accountant,
            final String p_fundMgtCompany) {

        if (p_idTypeRapport == null) {
            throw new IllegalArgumentException("p_idTypeRapport is required");
        }
        if (p_idGabarit == null) {
            throw new IllegalArgumentException("p_idGabarit is required");
        }
        if (p_idLangue == null) {
            throw new IllegalArgumentException("p_idLangue is required");
        }

        if (p_idTypeRapport == 4L) {
            return portfolioSelectedDao.getListeCompartsByGabarit(p_idTypeRapport, p_idGabarit, p_idLangue);
        }

        final QxpGabarit gabarit = gabaritRepository.findByGabaritId(p_idGabarit)
                .orElseThrow(() -> new IllegalArgumentException("Gabarit not found for p_idGabarit: " + p_idGabarit));

        if (gabarit.getType() == null) {
            throw new IllegalArgumentException("Type not set for p_idGabarit: " + p_idGabarit);
        }

        final TypeGabarit typeGabarit = TypeGabarit.fromValue(gabarit.getType());

        switch (typeGabarit) {
            case Fonds_simple:
            case FondsPart:
                return portfolioSelectedDao.getFondsSimplesByGabarit(
                        p_idTypeRapport, p_idGabarit, p_idLangue, p_auditor, p_accountant, p_fundMgtCompany);
            case Structure:
                return portfolioSelectedDao.getListeStructuresByGabarit(
                        p_idTypeRapport, p_idGabarit, p_idLangue, p_auditor, p_accountant, p_fundMgtCompany);
            default:
                throw new IllegalArgumentException(
                        "Unsupported typeGabarit: " + typeGabarit + " for p_idGabarit: " + p_idGabarit);
        }
    }
}
