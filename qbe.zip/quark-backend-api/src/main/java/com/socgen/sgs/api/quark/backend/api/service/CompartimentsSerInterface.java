package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;

import java.util.List;

public interface CompartimentsSerInterface {
    List<Compartiment> getStructures(String p_idStructure, String p_auditor, String p_accountant, String p_fundMgtCompany);
}
