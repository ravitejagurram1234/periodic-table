package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Auditor;

import java.util.List;

public interface AuditorDao {
    List<Auditor> getListAuditors();
}
