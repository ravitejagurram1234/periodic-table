package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;

import java.util.List;

public interface Chargement_gabaritSerInterface {
    List<Enums.TypeGabarit> getAllTypeGabarits();
    List<Enums.pagination> getPagination();
}
