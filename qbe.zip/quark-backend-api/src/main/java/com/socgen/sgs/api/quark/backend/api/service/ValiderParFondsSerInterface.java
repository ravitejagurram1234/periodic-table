package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

public interface ValiderParFondsSerInterface {
    void InsertParFonds(MultipartFile file,DocumentDTO dto);
    String getClientIp(HttpServletRequest request);
    Integer AuditParFonds(MultipartFile file,DocumentDTO dto,String page,String user, HttpServletRequest request);
}
