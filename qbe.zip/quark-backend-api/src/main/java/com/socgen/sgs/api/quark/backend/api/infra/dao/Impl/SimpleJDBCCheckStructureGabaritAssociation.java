package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.CheckStructureGabaritAssociationDao;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;

@Repository
public class SimpleJDBCCheckStructureGabaritAssociation implements CheckStructureGabaritAssociationDao {

    private static final String CALL =
            "{? = call QXP_PK_CHARGEMENT.CheckIfNoAssoStructsGabarit(?,?)}";

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public SimpleJDBCCheckStructureGabaritAssociation(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public Integer checkIfNoAssoStructsGabarit(Long p_idGabarit, List<String> p_listeFonds) {

        CallableStatementCreator creator = conn ->
                conn.unwrap(OracleConnection.class).prepareCall(CALL);

        CallableStatementCallback<Integer> callback = cs -> {
            cs.registerOutParameter(1, Types.NUMERIC);
            cs.setLong(2, p_idGabarit);

            OracleCallableStatement ocs = cs.unwrap(OracleCallableStatement.class);
            String[] fonds = p_listeFonds.toArray(new String[0]);
            ocs.setPlsqlIndexTable(3, fonds, fonds.length, fonds.length,
                    OracleTypes.VARCHAR, 255);

            cs.execute();

            Object result = cs.getObject(1);
            if (result instanceof Number) {
                return ((Number) result).intValue();
            }
            return 0;
        };

        return jdbcTemplate.execute(creator, callback);
    }
}
