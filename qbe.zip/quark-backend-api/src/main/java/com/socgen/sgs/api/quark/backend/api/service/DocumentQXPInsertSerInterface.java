package com.socgen.sgs.api.quark.backend.api.service;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

public interface DocumentQXPInsertSerInterface {
    Integer DocumentQXPInsert(MultipartFile file);
    String getClientIp(HttpServletRequest request);
    Integer DocumentQXPaudit(MultipartFile document, String page,String user,int id, HttpServletRequest request);
}
