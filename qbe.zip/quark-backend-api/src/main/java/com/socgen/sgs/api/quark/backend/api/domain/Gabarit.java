package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Gabarit {
        private String nom;
        private Long id_type_rapport;
        private Boolean is_actif;
        private Long taille_document;
        private Long id_langue;
        private Long type;
        private Integer id_sous_categorie;
        private Integer id_gabarit_template;
        private Boolean pagination_double;
        private Integer generate_to_word;
        private byte[] contenu;
}
