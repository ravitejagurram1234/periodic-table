package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Date;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SuiviEventsDTO {
    private Long id_event;
    private Long id_event_step;
    private Long event_data_type;
    private LocalDate event_date_echeance;


}
