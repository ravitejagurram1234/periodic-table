package com.socgen.sgs.api.quark.backend.api.Constantes;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;

public class Performance {
    private LocalDateTime start;

    public Performance() {
        this.start = LocalDateTime.now();
    }

    public BigDecimal getSecondsAndMilliseconds() {
        Duration interval = Duration.between(start, LocalDateTime.now());
        return BigDecimal.valueOf(interval.getSeconds())
                .add(BigDecimal.valueOf(interval.getNano()).divide(BigDecimal.valueOf(1_000_000_000)));
    }
}
