package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertParSocieteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.print.Doc;
@Component
@Transactional
public class InsertParSocieteBusiness {
    @Autowired
    private InsertParSocieteDao insertParSocieteDao;

    public void InsertParSociete(Document document){
        insertParSocieteDao.InsertParSociete(document);
    }
}
