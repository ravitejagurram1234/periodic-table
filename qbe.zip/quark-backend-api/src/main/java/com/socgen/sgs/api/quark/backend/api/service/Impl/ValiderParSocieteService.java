package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AuditParSocieteBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.InsertParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.InsertParSocieteBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.checkDoublOnDocumentBusiness;
import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.service.IAuthenticationService;
import com.socgen.sgs.api.quark.backend.api.service.ValiderParSocieteSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Service
public class ValiderParSocieteService implements ValiderParSocieteSerInterface {
    @Autowired
    private InsertParSocieteBusiness insertParSocieteBusiness;
    @Autowired
    private checkDoublOnDocumentBusiness business;
    @Autowired
    private AuditParSocieteBusiness auditParSocieteBusiness;
    @Autowired
    private IAuthenticationService authenticationService;

    public void InsertParSociete(MultipartFile file, DocumentDTO dto) {
        String originalFilename = file.getOriginalFilename();
        int tailleGabarit = (int) file.getSize();
        String nomDocument = originalFilename.substring(0, originalFilename.lastIndexOf('.'));
        String fileExtension = "";
        Optional<String> userEmail = authenticationService.getCurrentUserEmailId();

        if (originalFilename != null && originalFilename.lastIndexOf('.') > 0) {
            int dotIndex = originalFilename.lastIndexOf('.');
            fileExtension = originalFilename.substring(dotIndex + 1);
        }

        Document document1 = Document.builder()
                .p_id_fnd_code(dto.getP_id_fnd_code())
                .p_societe(dto.getP_societe())
                .p_id_sous_categorie(dto.getP_id_sous_categorie())
                .p_id_langue(dto.getP_id_langue())
                .p_date_document(dto.getP_date_document())
                .build();

        Integer valid = business.checkDoublOnDocument(document1);
        try {
            if (valid == 1) {
                throw new IllegalArgumentException("Duplicate exists");
            }

            Document document2 = Document.builder()
                    .p_id_fnd_code(dto.getP_id_fnd_code())
                    .p_id_unit_code(dto.getP_id_unit_code())
                    .p_id_sous_categorie(dto.getP_id_sous_categorie())
                    .p_contenu(dto.getFile().getBytes())
                    .p_id_langue(dto.getP_id_langue())
                    .p_date_document(dto.getP_date_document())
                    .p_nom_document(nomDocument)
                    .p_format(fileExtension)
                    .p_email(userEmail.get())
                    .p_taille_document(tailleGabarit)
                    .p_is_actif(dto.getP_is_actif())
                    .p_for_all_part(dto.getP_for_all_part())
                    .p_societe(dto.getP_societe())
                    .build();
            insertParSocieteBusiness.InsertParSociete(document2);
        } catch (IOException e) {
            throw new RuntimeException("Error reading file bytes", e);
        }
    }

    public String getClientIp(HttpServletRequest request) {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.isEmpty() || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }

    public Integer AuditParSociete(MultipartFile file, DocumentDTO dto, String page, String user, HttpServletRequest request) {
        Performance performance = new Performance();
        LocalDate start = LocalDate.now();
        LocalDate end = LocalDate.now();

        BigDecimal responseTime = performance.getSecondsAndMilliseconds();
        String clientIp = getClientIp(request);
        LocalDateTime now = LocalDateTime.now();

        String param1 = "Nom societe : " + dto.getP_societe();
        String param2 = "Id sous-cat : " + dto.getP_id_sous_categorie();
        String param3 = "Id langue : " + dto.getP_id_langue();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = now.format(formatter);
        String formattedDate = "Date insertion : " + formattedDateTime;

        Audit audit = new Audit(clientIp, start, end, page, user, Chargement_constantes.MODULE_NAME,Chargement_constantes.CREATION_DOCUMENT_PAR_SOCIETE,
                "", param1, param2, param3, formattedDate, "", responseTime, 0, 0, "");

        return auditParSocieteBusiness.insertAudit(audit);
    }
}
