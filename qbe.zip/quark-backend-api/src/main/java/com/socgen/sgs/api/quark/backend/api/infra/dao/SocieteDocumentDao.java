package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;

import java.util.List;

public interface SocieteDocumentDao {
    List<TypeDeDocument> getSocieteDocument(String p_societe);
}
