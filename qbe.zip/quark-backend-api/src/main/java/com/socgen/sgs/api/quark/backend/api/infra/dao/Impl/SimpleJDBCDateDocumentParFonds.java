package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationDateDocumentDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCDateDocumentParFonds implements ModificationDateDocumentDao {

        private final SimpleJdbcCall simpleJdbcCall;

        @Autowired
        public SimpleJDBCDateDocumentParFonds(DataSource dataSource) {
            this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                    .withCatalogName("QXP_PK_CHARGEMENT")
                    .withFunctionName("GetListeDatesDisposFondsPart")
                    .withoutProcedureColumnMetaDataAccess()
                    .declareParameters(
                            new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> rs.getDate("date_document")),
                            new SqlParameter("p_id_sous_categorie", Types.NUMERIC),
                            new SqlParameter("p_id_fnd_code", Types.VARCHAR),
                            new SqlParameter("p_id_unit_code", Types.VARCHAR)
                    );
        }

        @Override
        public List<java.sql.Date> getDateDocuments(int p_id_sous_categorie, String p_id_fnd_code, String p_id_unit_code) {
            Map<String, Object> params = new HashMap<>();
            params.put("p_id_sous_categorie", p_id_sous_categorie);
            params.put("p_id_fnd_code", p_id_fnd_code);
            params.put("p_id_unit_code", (p_id_unit_code==null || p_id_unit_code.isEmpty()?null:p_id_unit_code));
            Map<String, Object> result = simpleJdbcCall.execute(params);
            return (List<Date>) result.get("RETURN_VALUE");
        }
}
