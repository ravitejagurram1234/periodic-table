package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateGabaritDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCupdateGabarit implements UpdateGabaritDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCupdateGabarit(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withProcedureName("UpdateGabarit")
                .declareParameters(
                        new SqlParameter("p_idGabarit", Types.NUMERIC),
                        new SqlParameter("p_contenu", Types.VARBINARY),
                        new SqlParameter("p_tailleDocument", Types.NUMERIC),
                        new SqlParameter("p_isActif", Types.NUMERIC),
                        new SqlParameter("p_typeGabarit", Types.NUMERIC),
                        new SqlParameter("p_idGabaritTemplate", Types.NUMERIC),
                        new SqlParameter("p_pagination_double", Types.BOOLEAN)
                );
    }

    public void updateGabarit(Gabarit gabarit,Long p_idGabarit) {

        Map<String, Object> params = new HashMap<>();
        params.put("p_idGabarit", p_idGabarit);
        params.put("p_contenu", gabarit.getContenu());
        params.put("p_tailleDocument", gabarit.getTaille_document());
        params.put("p_isActif", gabarit.getIs_actif());
        params.put("p_typeGabarit", gabarit.getType());
        params.put("p_idGabaritTemplate", gabarit.getId_gabarit_template());
        params.put("p_pagination_double", gabarit.getPagination_double());

        simpleJdbcCall.execute(params);
    }
}
