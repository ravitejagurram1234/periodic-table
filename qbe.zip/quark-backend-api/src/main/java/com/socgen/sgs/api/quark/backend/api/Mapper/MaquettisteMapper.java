package com.socgen.sgs.api.quark.backend.api.Mapper;


import com.socgen.sgs.api.quark.backend.api.Dto.MaquettisteDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;

import java.sql.ResultSet;
import java.sql.SQLException;


public class MaquettisteMapper {



    public static Maquettiste mapResult(ResultSet rs) throws SQLException {
        Maquettiste m =new Maquettiste();

        m.setId(rs.getLong("ID_UTILISATEUR"));
        m.setTrigramme(rs.getString("TRIGRAMME"));

        return  m;
    }

    public static MaquettisteDTO toDto(Maquettiste domain){

        return new MaquettisteDTO(domain.getId(), domain.getTrigramme());
    }
}
