package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertParFondsDao;
import org.hibernate.query.sql.internal.ParameterRecognizerImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class InsertParFondsBusiness {
    @Autowired
    private InsertParFondsDao insertParFondsDao;

    public void InsertParFonds(Document document){
         insertParFondsDao.insertParFonds(document);
    }

}
