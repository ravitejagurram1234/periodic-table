package com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository;

import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for managing QXP_GABARIT entity.
 */
@Repository
public interface GabaritRepository extends JpaRepository<QxpGabarit, Long> {

    /**
     * Retrieves a gabarit entity by its ID.
     *
     * @param gabaritId the gabarit identifier
     * @return an Optional containing the QxpGabarit entity if found, empty otherwise
     */
    Optional<QxpGabarit> findByGabaritId(Long gabaritId);
}
