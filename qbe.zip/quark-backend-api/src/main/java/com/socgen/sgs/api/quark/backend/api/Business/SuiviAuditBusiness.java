package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.InsertTraceDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.SuiviAuditMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.SuiviMapper;
import com.socgen.sgs.api.quark.backend.api.domain.InsertTrace;
import com.socgen.sgs.api.quark.backend.api.domain.Suivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertSuiviDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviAuditDao;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Component
@Transactional
public class SuiviAuditBusiness {

    @Autowired
    private SuiviAuditDao suiviAuditDao;

    public Long InsertTrace(SuiviDTO suivi, HttpServletRequest httpServletRequest) {
        String param2="Fonds:"+suivi.getP_id();
        String param3="Id type rapport:"+suivi.getP_id_type_rapport();
        String param4="Date echeance:"+suivi.getP_date_echeance();
        String param5="Id langue:" +suivi.getP_id_langue();

        InsertTraceDTO insertTraceDTO=new InsertTraceDTO();
        insertTraceDTO.setP_ip(httpServletRequest.getRemoteAddr());
        insertTraceDTO.setP_startTime(LocalDate.now());
        insertTraceDTO.setP_endTime(LocalDate.now());
        insertTraceDTO.setP_page("creation_of_suivi");
        insertTraceDTO.setP_login("qxp_user");
        insertTraceDTO.setP_module("Generation");
        insertTraceDTO.setP_fonction("CreationSuivi");
        insertTraceDTO.setP_message("Insertion du suivi : opération effectuée avec succès");
        insertTraceDTO.setP_param1("Insertion");
        insertTraceDTO.setP_param2(param2);
        insertTraceDTO.setP_param3(param3);
        insertTraceDTO.setP_param4(param4);
        insertTraceDTO.setP_param5(param5);
        insertTraceDTO.setP_temps_reponse(0);
        insertTraceDTO.setP_statut(null);
        insertTraceDTO.setP_id_application(null);
        insertTraceDTO.setP_nom_application(null);

        InsertTrace domain = SuiviAuditMapper.toDomain(insertTraceDTO);
        return suiviAuditDao.insertTrace(domain);


    }
}
