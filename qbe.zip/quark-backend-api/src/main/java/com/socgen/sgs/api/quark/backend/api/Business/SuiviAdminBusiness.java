package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;
import com.socgen.sgs.api.quark.backend.api.domain.InsertTrace;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviAdminDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviAuditDao;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;

@Component
@Transactional
public class SuiviAdminBusiness {

    @Autowired
    private SuiviAdminDao suiviAdminDao;

    @Autowired
    private SuiviAuditDao suiviAuditDao;

    // --- Get exact date of suivi ---
    public String getDateExacteSuivi(Long idSuivi) {
        return suiviAdminDao.getDateExacteSuivi(idSuivi);
    }
    // --- Update exact date of suivi ---
    public void updateDateExacteSuivi(Long idSuivi, String newDate, HttpServletRequest request, String email) {
        suiviAdminDao.updateDateExacteSuivi(idSuivi, newDate);
        insertTrace(request, email, "Administration", "UpdateDateExacteSuivi",
                "Modification de la date exacte du suivi effectuée avec succès",
                String.valueOf(idSuivi), newDate, null, null, null);
    }

    // --- Reset suivi ---
    public void resetSuivi(Long idSuivi, String email, HttpServletRequest request) {
        Integer typeSuivi = suiviAdminDao.getTypeSuivi(idSuivi);
        if (typeSuivi != null && typeSuivi == Enums.TypeSuivi.Traduction.getValue()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Impossible de réinitialiser les évenements d'un suivi de traduction");
        }
        suiviAdminDao.resetSuivi(idSuivi, email);
        insertTrace(request, email, "Administration", "ResetSuivi",
                "Réinitialisation effectuée avec succès",
                String.valueOf(idSuivi), email, null, null, null);
    }

    // --- Remove suivi ---
    public void removeSuivi(Long idSuivi, String email, HttpServletRequest request) {
        suiviAdminDao.removeSuivi(idSuivi, email);
        insertTrace(request, email, "Administration", "RemoveSuivi",
                "Suppression du suivi effectuée avec succès",
                String.valueOf(idSuivi), email, null, null, null);
    }

    // --- Unlock suivi ---
    public void unlockSuivi(Long idSuivi, HttpServletRequest request, String email) {
        suiviAdminDao.unlockSuivi(idSuivi);
        insertTrace(request, email, "Administration", "UnlockSuivi",
                "Déverrouillage du suivi effectué avec succès",
                String.valueOf(idSuivi), email, null, null, null);
    }

    // --- Private helper: InsertTrace (QXP_PK_AUDIT) ---
    private void insertTrace(HttpServletRequest request, String email,
                             String page, String fonction, String message,
                             String param1, String param2, String param3,
                             String param4, String param5) {
        InsertTrace trace = InsertTrace.builder()
                .p_ip(request != null ? request.getRemoteAddr() : null)
                .p_startTime(LocalDate.now())
                .p_endTime(LocalDate.now())
                .p_page(page)
                .p_login(email)
                .p_module("Administration")
                .p_fonction(fonction)
                .p_message(message)
                .p_param1(param1)
                .p_param2(param2)
                .p_param3(param3)
                .p_param4(param4)
                .p_param5(param5)
                .p_temps_reponse(0)
                .p_statut(0)
                .p_id_application(null)
                .p_nom_application(null)
                .build();
        suiviAuditDao.insertTrace(trace);
    }
}
