package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeRapport;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TypeRapportDao;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public class TypeRapportBusiness {
    private final TypeRapportDao dao;
    public TypeRapportBusiness(TypeRapportDao dao){

        this.dao=dao;
    }
    public List<TypeRapport> getTypeRapport() {
        return this.dao.getTypeRapport();
    }
}
