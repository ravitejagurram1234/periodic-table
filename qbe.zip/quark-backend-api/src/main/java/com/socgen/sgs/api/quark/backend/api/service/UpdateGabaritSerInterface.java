package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ModificationGabaritDTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

public interface UpdateGabaritSerInterface {
    void updateGabarit(MultipartFile file, ModificationGabaritDTO dto);
    String getClientIp(HttpServletRequest request);
    Integer AuditUpdateGabarit(MultipartFile file, ModificationGabaritDTO dto,String page, String user, HttpServletRequest request);
}
