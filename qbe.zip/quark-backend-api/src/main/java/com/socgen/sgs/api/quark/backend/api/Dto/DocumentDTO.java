package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.Optional;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DocumentDTO {

    private MultipartFile file;
    private String p_id_fnd_code;
    private String p_id_unit_code;
    private String p_societe;
    private Long p_id_sous_categorie;
    private Long p_id_langue;
    private LocalDate p_date_document;
    private Long p_id_utilisateur;

    private Long p_is_actif;
    private Long p_for_all_part;
    private LocalDate p_old_date;
    private String p_email;

}
