package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertLiensFondsGabaritDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;

@Slf4j
@Repository
public class SimpleJDBCInsertLiensFondsGabarit implements InsertLiensFondsGabaritDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public SimpleJDBCInsertLiensFondsGabarit(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void insertLiensFondsGabarit(Long p_idTypeRapport, Long p_idGabarit, Long p_idLangue,
                                        String p_auditor, String p_accountant, String p_fundMgtCompany,
                                        List<String> p_listeFonds) {

        StringBuilder block = new StringBuilder();
        block.append("DECLARE ");
        block.append("l_listefonds QXP_PK_COMMON.VarCharArray; ");
        block.append("BEGIN ");

        for (int i = 0; i < p_listeFonds.size(); i++) {
            String safe = p_listeFonds.get(i).replace("'", "''");
            block.append("l_listefonds(").append(i + 1).append(") := '").append(safe).append("'; ");
        }

        block.append("QXP_PK_CHARGEMENT.InsertLiensFondsGabarit(");
        block.append(p_idTypeRapport != null ? p_idTypeRapport : 0).append(", ");
        block.append(p_idGabarit    != null ? p_idGabarit    : 0).append(", ");
        block.append(p_idLangue     != null ? p_idLangue     : 0).append(", ");
        block.append(p_auditor       != null ? "'" + p_auditor.replace("'", "''")       + "'" : "NULL").append(", ");
        block.append(p_accountant    != null ? "'" + p_accountant.replace("'", "''")    + "'" : "NULL").append(", ");
        block.append(p_fundMgtCompany!= null ? "'" + p_fundMgtCompany.replace("'","''") + "'" : "NULL").append(", ");
        block.append("l_listefonds); ");
        block.append("END;");

        String sql = block.toString();
        log.info(">>> InsertLiensFondsGabarit executing SQL:\n{}", sql); // INFO so it always prints in logs

        jdbcTemplate.execute(sql);

        log.info(">>> InsertLiensFondsGabarit completed for gabarit={} fonds={}", p_idGabarit, p_listeFonds);
    }
}
