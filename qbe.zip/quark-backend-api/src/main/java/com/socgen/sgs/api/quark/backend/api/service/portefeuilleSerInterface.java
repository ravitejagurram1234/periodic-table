package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;

import java.util.List;

public interface portefeuilleSerInterface {
    List<portefeuille>getPortefeuille();
}
