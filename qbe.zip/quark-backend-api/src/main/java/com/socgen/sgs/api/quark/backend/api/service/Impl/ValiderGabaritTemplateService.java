package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AuditParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.GabaritTemplateInsertBusiness;
import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.service.ValiderGabaritTemplateSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class ValiderGabaritTemplateService implements ValiderGabaritTemplateSerInterface {
    @Autowired
    private GabaritTemplateInsertBusiness gabaritTemplateInsertBusiness;
    @Autowired
    private AuditParFondsBusiness auditParFondsBusiness;

    public Integer insertGabaritTemplate(MultipartFile file, String commentaire) {
        String originalFilename = file.getOriginalFilename();
        String nomDocument = originalFilename.substring(0, originalFilename.lastIndexOf('.'));
        try {
            Chargement_gabarit gabarit = new Chargement_gabarit(nomDocument, file.getBytes(), commentaire);

            return gabaritTemplateInsertBusiness.insertGabaritTemplate(gabarit);
        } catch (IOException e) {
            throw new RuntimeException("Error reading file bytes", e);

        }
    }

    public String getClientIp(HttpServletRequest request) {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.isEmpty() || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }


    public Integer  AuditGabaritTemplate(MultipartFile file ,String commentaire,String page,String user, int id, HttpServletRequest request) {

        Performance performance = new Performance();
        LocalDate start = LocalDate.now();
        LocalDate end = LocalDate.now();


        BigDecimal responseTime = performance.getSecondsAndMilliseconds();

        String clientIp = getClientIp(request);
        String formattedid = "Id gabarit template: " + id;
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || !originalFilename.endsWith(".qxp")) {
            throw new IllegalArgumentException("Invalid file type. Only .qxp files are allowed.");
        }

        String nom = originalFilename.substring(0, originalFilename.lastIndexOf('.'));

        String formattedNom = "Nom gabarit : " + nom;
        String formattedcomment = " commentaire : " + commentaire;
        LocalDateTime now = LocalDateTime.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = now.format(formatter);
        String formattedDate = "Date insertion : " + formattedDateTime;


        Audit audit = new Audit(clientIp, start, end, page, user, Chargement_constantes.MODULE_NAME, Chargement_constantes.CREATION_GABARIT_TEMPLATE,
                "", formattedid, formattedNom, formattedcomment, formattedDate, "", responseTime, 0, 0, "");

        return auditParFondsBusiness.AuditParFonds(audit);

    }
}
