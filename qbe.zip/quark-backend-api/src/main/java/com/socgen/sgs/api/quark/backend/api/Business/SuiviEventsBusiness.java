package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviEventsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviEventDao;
import com.socgen.sgs.api.quark.backend.api.service.SuiviEventsSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Component
@Transactional
public class SuiviEventsBusiness {


    @Autowired
    private SuiviEventDao suiviEventDao;

    public List<SuiviEvents> getSuiviEvents(Long p_idSuivi) {
        return suiviEventDao.getSuiviEvents(p_idSuivi);

    }
}
