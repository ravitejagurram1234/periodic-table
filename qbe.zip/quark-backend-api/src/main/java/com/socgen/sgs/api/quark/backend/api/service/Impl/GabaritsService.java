package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.GabaritsBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;
import com.socgen.sgs.api.quark.backend.api.service.GabaritsSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GabaritsService implements GabaritsSerInterface {

    @Autowired
    private GabaritsBusiness gabaritBusiness;

    public List<Gabarits> getGabarits(Long p_idTypeRapport, Long p_idLangue, int p_onlyActive){
        return gabaritBusiness.getGabarits(p_idTypeRapport,p_idLangue,  p_onlyActive);
    }
}
