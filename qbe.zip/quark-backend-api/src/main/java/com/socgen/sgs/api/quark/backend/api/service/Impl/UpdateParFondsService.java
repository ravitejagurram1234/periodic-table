package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AuditParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.UpdateParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.service.UpdateParFondsSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class UpdateParFondsService implements UpdateParFondsSerInterface {
    @Autowired
    private UpdateParFondsBusiness business;

    @Autowired
    private AuditParFondsBusiness auditParFondsBusiness;

    public void updateDocument(MultipartFile file, DocumentDTO dto) {
        String originalFilename = file.getOriginalFilename();
        int taille_document = (int) file.getSize();
        String nom_complet = originalFilename.substring(0, originalFilename.lastIndexOf('.'));
        String fileExtension = "";

        if (originalFilename != null && originalFilename.lastIndexOf('.') > 0) {
            int dotIndex = originalFilename.lastIndexOf('.');
            fileExtension = originalFilename.substring(dotIndex + 1);
        }
        LocalDate withOneMonth = dto.getP_date_document().withDayOfMonth(1);
        try {
            Document document = Document.builder()
                    .p_id_sous_categorie(dto.getP_id_sous_categorie())
                    .p_id_fnd_code(dto.getP_id_fnd_code())
                    .p_id_unit_code(dto.getP_id_unit_code())
                    .p_old_date(dto.getP_old_date())
                    .p_id_langue(dto.getP_id_langue())
                    .p_date_document(withOneMonth)
                    .p_contenu(file.getBytes())
                    .p_taille_document(taille_document)
                    .p_format(fileExtension)
//                    .p_id_utilisateur(dto.getP_id_utilisateur())
                    .p_nom_document(nom_complet)
                    .build();
            business.updateDocument(document);
        } catch (IOException e) {
            throw new RuntimeException("Error reading file bytes", e);
        }
    }


    public String getClientIp(HttpServletRequest request) {
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.isEmpty() || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
        }
        return ipAddress;
    }



    public Integer AuditUpdateParFonds(MultipartFile file, DocumentDTO dto, String page, String user, HttpServletRequest request) {
        Performance performance = new Performance();
        LocalDate start = LocalDate.now();
        LocalDate end = LocalDate.now();


        BigDecimal responseTime = performance.getSecondsAndMilliseconds();
        String clientIp = getClientIp(request);
        //LocalDateTime now = LocalDateTime.now();
        String param1 = "Code port : " + dto.getP_id_fnd_code();
        String param2 = "Id sous-cat : " + dto.getP_id_sous_categorie();
        String param3 = "Id langue : " + dto.getP_id_langue();
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//        String formattedDateTime = now.format(formatter);
        String formattedDate = "Ancienne date document : " + dto.getP_old_date();
        String p_message="Modification du document par fonds effectuée avec succès";
        Audit audit = new Audit(clientIp, start, end, page, user, Chargement_constantes.MODULE_NAME,Chargement_constantes.MODIFICATION_DOCUMENT_PAR_FONDS,
                p_message, param1, param2, param3, formattedDate, "", responseTime, 0, 0, "");

        return auditParFondsBusiness.AuditParFonds(audit);
    }

}
