package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritByStructure;

import java.util.List;

public interface GabaritsByStructureSerInterface {
    List<GabaritByStructure> getGabaritsByStructure(String p_idStructure);
}
