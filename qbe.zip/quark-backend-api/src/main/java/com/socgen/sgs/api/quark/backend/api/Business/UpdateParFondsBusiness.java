package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateParFondsDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.UpdateParFondsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class UpdateParFondsBusiness {
    @Autowired
    private UpdateParFondsDao updateParFondsDao;

    public void updateDocument(Document document){
        updateParFondsDao.updateDocument(document);
    }
}
