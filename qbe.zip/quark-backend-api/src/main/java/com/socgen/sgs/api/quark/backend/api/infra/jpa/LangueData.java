package com.socgen.sgs.api.quark.backend.api.infra.jpa;

import com.socgen.sgs.api.quark.backend.api.domain.TypeRapport;
import lombok.Builder;


public interface LangueData {

    Long getId();

    String getNomLangue();

    String getValeurLangue();
}
