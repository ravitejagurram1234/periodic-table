package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.Gabarit_InsertDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class Gabarit_InsertBusiness {
    @Autowired
    private Gabarit_InsertDao gabaritInsertDao;

    public Integer insertGabarit(Chargement_gabarit gabarit){

        return gabaritInsertDao.insertGabarit(gabarit);
    }
}
