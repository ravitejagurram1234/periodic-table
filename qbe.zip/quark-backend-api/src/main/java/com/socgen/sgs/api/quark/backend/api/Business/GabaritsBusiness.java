package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GabaritsBusiness {
    @Autowired
    private GabaritsDao gabaritDao;
    public List<Gabarits> getGabarits(Long p_idTypeRapport, Long p_idLangue, int p_onlyActive){
        return gabaritDao.getGabarits(p_idTypeRapport,p_idLangue,  p_onlyActive);
    }
}
