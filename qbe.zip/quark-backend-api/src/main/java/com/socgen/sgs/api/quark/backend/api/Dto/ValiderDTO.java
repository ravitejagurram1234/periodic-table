package com.socgen.sgs.api.quark.backend.api.Dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ValiderDTO {
    private List<SuiviDetailsDTO> fondsPart;
    private List<SuiviStructureDetailsDTO>structure;
}