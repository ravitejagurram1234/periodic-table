package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;

import java.util.List;

public interface categorieDao {
    List<TypeDeDocument> getListeSousCategorie(int p_idCategorie, int p_checkAtLeastOneDocument);
}
