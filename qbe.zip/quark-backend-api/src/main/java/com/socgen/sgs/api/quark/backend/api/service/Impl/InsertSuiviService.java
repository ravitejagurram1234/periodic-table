package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.*;
import com.socgen.sgs.api.quark.backend.api.Dto.InsertTraceDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDTO;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;
import com.socgen.sgs.api.quark.backend.api.domain.PrevSuiviEvents;
import com.socgen.sgs.api.quark.backend.api.domain.Suivi;
import com.socgen.sgs.api.quark.backend.api.service.InsertSuiviSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InsertSuiviService implements InsertSuiviSerInterface {

    @Autowired
    private InsertSuiviBusiness suiviBusiness;

    @Override
    public Long insertSuivi(SuiviDTO suivi) {
        return suiviBusiness.insertSuivi(suivi);

    }

    @Autowired
    private SuiviAuditBusiness suiviAuditBusiness;

    @Override
    public Long InsertTrace(SuiviDTO suivi, HttpServletRequest request) {
        return suiviAuditBusiness.InsertTrace(suivi,request);

    }

    @Autowired
    private GabaritEventBusiness gabaritEventBusiness;
    @Autowired
    private PrevSuiviBusiness prevSuiviBusiness;
    @Autowired
    private InsertSuiviEventsBusiness insertSuiviEventsBusiness;

    @Override
    public void InsertEvent(SuiviDTO suivi, Long p_idSuivi,Long p_idUser){
        List<GabaritEvents> defaultEvents=gabaritEventBusiness.getGabaritEvents(suivi.getP_id_gabarit());
        List<PrevSuiviEvents>prevEvents=prevSuiviBusiness.getSuiviEvents(suivi.getP_id(),suivi.getP_id_unit_code(),
                suivi.getP_id_type_rapport(),suivi.getP_id_langue(),suivi.getP_date_echeance(),suivi.getP_id_gabarit());

        boolean hasPreviousSuivi=prevEvents!=null && !prevEvents.isEmpty();

        for(GabaritEvents event: defaultEvents){

            boolean eventExists= hasPreviousSuivi && prevEvents.stream().anyMatch(prev->prev.getId_event().equals(event.getIdEvent()));
            if(!hasPreviousSuivi || eventExists){
                insertSuiviEventsBusiness.insertSuiviEvent(p_idSuivi,event.getIdEvent(),p_idUser,-1L,null);
            }
        }
    }
}
