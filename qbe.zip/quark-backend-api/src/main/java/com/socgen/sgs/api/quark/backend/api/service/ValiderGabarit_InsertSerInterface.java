package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.Chargement_gabaritDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

public interface ValiderGabarit_InsertSerInterface {
    Integer insertGabarit(Chargement_gabaritDTO gabarit, MultipartFile file);
    String getClientIp(HttpServletRequest request);
    Integer AuditGabarit(MultipartFile file, Chargement_gabaritDTO dto, String page, String user,int gabarit_id, HttpServletRequest request);
}
