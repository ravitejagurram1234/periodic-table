package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

import java.nio.channels.MulticastChannel;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class gabaritTemplateDTO {
    MultipartFile file;
    private byte[] contenu;
    private int id_gabarit_template;
    private String nom;
    private String commentaire;
}
