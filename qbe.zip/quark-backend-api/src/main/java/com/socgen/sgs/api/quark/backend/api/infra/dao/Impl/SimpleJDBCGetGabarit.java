package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.GabaritMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;

import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



@Repository
public class SimpleJDBCGetGabarit implements GabaritDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCGetGabarit(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetGabarit")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> GabaritMapper.mapResult(rs)),
                        new SqlParameter("p_idGabarit", Types.NUMERIC)
                );
    }

    @Override
    public Gabarit getGabarit(Long p_idGabarit) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_idGabarit", p_idGabarit);

        Map<String, Object> result = simpleJdbcCall.execute(params);
        return ((List<Gabarit>) result.get("RETURN_VALUE")).stream().findFirst().orElse(null);
    }
}
