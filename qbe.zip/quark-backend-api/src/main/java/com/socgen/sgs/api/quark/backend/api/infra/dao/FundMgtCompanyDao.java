package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;

import java.util.List;

public interface FundMgtCompanyDao {
    List<FundMgtCompany> getListFundMgtCompanies();
}
