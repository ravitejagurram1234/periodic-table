package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SuiviEvents {
    private Long idEvent;
    private Long idEventStep;
    private Long eventDataType;
    private LocalDate eventDateEcheance;
}
