package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;

import java.time.LocalDate;
import java.util.List;

public interface SuiviDetailsDao {
    List<SuiviDetails> getListeNewSuivisByFondsPart(Long p_idTypeRapport, Long p_idLangue, Long p_idGabarit, Long p_typeGabarit,
                                                    LocalDate p_dateEcheance, String p_portefeuilles, String p_auditor,
                                                    String p_accountant, String p_fundMgtCompany) ;
}
