package com.socgen.sgs.api.quark.backend.api.Dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SuiviDTO {
    private Long p_id_type_rapport;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate p_date_echeance;
    private Long p_id_langue;
    private Long p_id_maquettiste;
    private Long p_id_gabarit;
    private Long p_id_createur;
    private Long p_id_suivi;
    private String p_id;
    private String p_id_unit_code;
    private String p_date_echeance_exacte;
}
