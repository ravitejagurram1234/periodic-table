package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;

public interface GetGabaritTemplateDao {
    GabaritTemplate getGabaritTemplates(Long p_idGabaritTemplate);
}
