// src/main/java/.../infra/dao/Impl/SimpleJDBCInsertLiensStructGabComparts.java
package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertLiensStructGabCompartsDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;

@Slf4j
@Repository
public class SimpleJDBCInsertLiensStructGabComparts implements InsertLiensStructGabCompartsDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public SimpleJDBCInsertLiensStructGabComparts(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void insertLiensStructGabComparts(
            String       idStructure,
            Long         idGabarit,
            List<String> listeCompartiments,
            String       idPresentationPatrimoine,
            String       idPresentationCompteRes) {

        StringBuilder block = new StringBuilder();
        block.append("DECLARE ");
        block.append("l_listeCompartiments QXP_PK_COMMON.VarCharArray; ");
        block.append("BEGIN ");

        // Populate the VarCharArray elements (1-based Oracle index)
        for (int i = 0; i < listeCompartiments.size(); i++) {
            String safe = listeCompartiments.get(i).replace("'", "''");
            block.append("l_listeCompartiments(").append(i + 1).append(") := '").append(safe).append("'; ");
        }

        block.append("QXP_PK_CHARGEMENT.InsertLiensStructGabComparts(");
        block.append("'").append(idStructure.replace("'", "''")).append("', ");
        block.append(idGabarit).append(", ");
        block.append("l_listeCompartiments, ");
        block.append(idPresentationPatrimoine != null
                ? "'" + idPresentationPatrimoine.replace("'", "''") + "'"
                : "NULL").append(", ");
        block.append(idPresentationCompteRes != null
                ? "'" + idPresentationCompteRes.replace("'", "''") + "'"
                : "NULL");
        block.append("); ");
        block.append("END;");

        String sql = block.toString();
        log.info(">>> InsertLiensStructGabComparts executing SQL:\n{}", sql);

        jdbcTemplate.execute(sql);

        log.info(">>> InsertLiensStructGabComparts completed | structure={} gabarit={} compartimentsCount={}",
                idStructure, idGabarit, listeCompartiments.size());
    }
}
