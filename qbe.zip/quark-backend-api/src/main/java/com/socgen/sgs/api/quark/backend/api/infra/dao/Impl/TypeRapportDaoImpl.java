package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.TypeRapportMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TypeRapport;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TypeRapportDao;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.TypeRapportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
@Component
@Transactional
public class TypeRapportDaoImpl   implements TypeRapportDao{
   @Autowired
   private TypeRapportRepository repository;
   @Override
   public List<TypeRapport> getTypeRapport() {
    return repository.getTypeRapport().stream().filter(Objects::nonNull)
            .map(TypeRapportMapper:: mapDetails).toList();
}
}
