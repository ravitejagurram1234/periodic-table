package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.AuditorMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Auditor;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditorDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCauditor implements AuditorDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCauditor(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetListAuditors")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> AuditorMapper.mapResult(rs))
                );
    }

    @Override
    public List<Auditor> getListAuditors() {
        Map<String, Object> result = simpleJdbcCall.execute();
        return (List<Auditor>) result.get("RETURN_VALUE");
    }
}
