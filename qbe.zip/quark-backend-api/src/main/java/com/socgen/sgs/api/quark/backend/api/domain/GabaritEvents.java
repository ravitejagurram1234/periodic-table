package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GabaritEvents {
    private Long idEvent;
    private String Transduction_code;
    private Long show_on_eos;
    private String type;
    private Long event_type;
    private Long mandatory;

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long idEvent;
        private String Transduction_code;
        private Long show_on_eos;
        private String type;
        private Long event_type;
        private Long mandatory;

        public Builder idEvent(Long idEvent) {
            this.idEvent = idEvent;
            return this;
        }

        public Builder Transduction_code(String Transduction_code) {
            this.Transduction_code = Transduction_code;
            return this;
        }

        public Builder show_on_eos(Long show_on_eos) {
            this.show_on_eos = show_on_eos;
            return this;
        }

        public Builder type(String type) {
            this.type = type;
            return this;
        }

        public Builder event_type(Long event_type) {
            this.event_type = event_type;
            return this;
        }

        public Builder mandatory(Long mandatory) {
            this.mandatory = mandatory;
            return this;
        }

        public GabaritEvents build() {
            GabaritEvents gabaritEvents = new GabaritEvents();
            gabaritEvents.idEvent = this.idEvent;
            gabaritEvents.Transduction_code = this.Transduction_code;
            gabaritEvents.show_on_eos = this.show_on_eos;
            gabaritEvents.type = this.type;
            gabaritEvents.event_type = this.event_type;
            gabaritEvents.mandatory = this.mandatory;
            return gabaritEvents;
        }
    }
}


