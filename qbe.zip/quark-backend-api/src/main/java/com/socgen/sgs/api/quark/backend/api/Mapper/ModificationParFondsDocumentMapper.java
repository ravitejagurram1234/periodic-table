package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.apibank.problem.reactive.ReactiveSecurityAdviceTrait;
import com.socgen.sgs.api.quark.backend.api.Dto.ModificationParFondsDocumentDTO;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsDocument;
import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ModificationParFondsDocumentMapper {
    public static ModificationParFondsDocument mapResult(ResultSet rs)throws SQLException{
        ModificationParFondsDocument m=new ModificationParFondsDocument();
        m.setId_document(rs.getInt("id_document"));
        m.setId_sous_categorie(rs.getInt("id_sous_categorie"));
        m.setId_langue(rs.getInt("id_langue"));
        m.setNom_document(rs.getString("nom_document"));
        m.setId_fnd_code(rs.getString("id_fnd_code"));
        m.setId_unit_code(rs.getString("id_unit_code"));
        m.setIs_actif(rs.getInt("is_actif"));
        java.sql.Date date_echeance = rs.getDate("date_echeance");
        m.setDate_echeance(date_echeance != null ? date_echeance.toLocalDate() : null);
        java.sql.Date date_creation=rs.getDate("date_creation_sys");
        m.setDate_creation_sys(date_creation!=null? date_creation.toLocalDate():null);
        m.setTaille_document(rs.getLong("taille_document"));
        m.setSociete(rs.getString("societe"));
        m.setFormat(rs.getString("format"));
        m.setId_utilisateur(rs.getInt("id_utilisateur"));
        return m;
    }

    public static ModificationParFondsDocumentDTO toDto(ModificationParFondsDocument domain){
        ModificationParFondsDocumentDTO d=new ModificationParFondsDocumentDTO();
        d.setNom_document(domain.getNom_document());
        return d;
    }
}
