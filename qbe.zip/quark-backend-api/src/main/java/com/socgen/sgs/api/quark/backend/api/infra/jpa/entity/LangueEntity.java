package com.socgen.sgs.api.quark.backend.api.infra.jpa.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "QXP_REF_LANGUE_DOCUMENT")
public class LangueEntity {
    @Id
    @Column(name = "ID_LANGUE_DOCUMENT", nullable = false)
    private Long ID_LANGUE_DOCUMENT;
    @Column(name = "NOM_LANGUE",nullable= false)
    private String NOM_LANGUE;
    @Column(name = "VALEUR_LANGUE",nullable= false)
    private String VALEUR_LANGUE;

}
