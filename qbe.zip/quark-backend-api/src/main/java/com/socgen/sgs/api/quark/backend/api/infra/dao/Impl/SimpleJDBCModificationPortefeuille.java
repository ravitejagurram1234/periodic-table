package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.TypeDeDocumentMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.portefeuilleMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationPortefeuilleDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCModificationPortefeuille implements ModificationPortefeuilleDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCModificationPortefeuille(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetFondsAtLeastOneDocument")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> portefeuilleMapper.mapResult(rs)),
                        new SqlParameter("p_id_sous_categorie", Types.INTEGER)
                );
    }

    @Override
    public List<portefeuille> getListPortefeuille(int p_id_sous_categorie) {

            Map<String, Object> params = new HashMap<>();
            params.put( "p_id_sous_categorie",p_id_sous_categorie);
            Map<String, Object> result = simpleJdbcCall.execute(params);
            return (List<portefeuille>) result.get("RETURN_VALUE");

    }
}
