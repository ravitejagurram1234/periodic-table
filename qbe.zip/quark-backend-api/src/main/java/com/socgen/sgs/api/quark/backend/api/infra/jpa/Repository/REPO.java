package com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository;

import com.socgen.sgs.api.quark.backend.api.infra.jpa.EVENT_DATA;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QXP_REF_ENTITY;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface REPO extends JpaRepository<QXP_REF_ENTITY,Long> {
    @Query(value = """ 
           SELECT re.LIBELLE as libelle , se.ID_SUIVI as idSuivi
           FROM QXP_REF_EVENT re 
           JOIN QXP_SUIVI_EVENT se ON se.ID_EVENT = re.ID_EVENT 
           FETCH FIRST 20 ROWS ONLY
           """,nativeQuery = true)
    List<EVENT_DATA> findByEvent();
}
