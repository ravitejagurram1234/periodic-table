package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.ValiderDTO;

import java.time.LocalDate;

public interface ValiderSerInterface {
    ValiderDTO getSuivis(Long p_idTypeRapport, Long p_idLangue, Long p_idGabarit,
                         LocalDate p_dateEcheance, String p_portefeuilles, String p_auditor,
                         String p_accountant, String p_fundMgtCompany);
}
