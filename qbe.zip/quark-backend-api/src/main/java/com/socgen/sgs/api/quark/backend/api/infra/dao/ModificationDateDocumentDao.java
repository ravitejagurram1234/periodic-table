package com.socgen.sgs.api.quark.backend.api.infra.dao;

import java.util.List;

public interface ModificationDateDocumentDao {
    List<java.sql.Date> getDateDocuments(int p_id_sous_categorie, String p_id_fnd_code, String p_id_unit_code);
}
