package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.PrevSuiviEvents;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PrevSuiviDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviEventDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
@Component
@Transactional
public class PrevSuiviBusiness {

    @Autowired
    private PrevSuiviDao prevSuiviDao;

    public List<PrevSuiviEvents> getSuiviEvents(String p_id, String p_id_unit_code, Long p_id_type_rapport, Long p_id_langue, LocalDate p_date_echeance, Long p_id_gabarit) {
        return prevSuiviDao.getPrevSuiviEvents(p_id, p_id_unit_code,  p_id_type_rapport, p_id_langue,  p_date_echeance,  p_id_gabarit);

    }
}