package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;

import java.util.List;

public interface GabaritTemplateSerInterface {
    List<GabaritTemplate> getTemplates();
}
