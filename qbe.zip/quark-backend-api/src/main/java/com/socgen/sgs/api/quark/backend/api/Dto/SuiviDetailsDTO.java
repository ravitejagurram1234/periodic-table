package com.socgen.sgs.api.quark.backend.api.Dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SuiviDetailsDTO {
    private String id_fnd_code;
//    private LocalDate fnd_next_fiscal_year_end;
    private String fnd_next_fiscal_year_end;
    private String fndLastFiscalYearEnd;
    private String fndShtDescription;
    private String libelleFond;
    private String libelleClasse;
    private String fndMngtCompany;
    private String fndAccountant;
    private String fndAuditor;
    private String id_unit_code;
    private String unit_id_ins_code;
    private String unit_currency;
    private String unit_sht_description;
}
