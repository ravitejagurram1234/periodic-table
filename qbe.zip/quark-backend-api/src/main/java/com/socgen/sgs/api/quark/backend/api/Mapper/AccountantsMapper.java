package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.AccountantsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.FundMgtCompanyDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Accountants;
import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountantsMapper {

    public static Accountants mapResult(ResultSet rs) throws SQLException {
        Accountants accountant = new Accountants();
        accountant.setDes_table_value(rs.getString("DES_TABLE_VALUE"));
        return accountant;
    }

    public static AccountantsDTO toDto(Accountants domain){

        return new AccountantsDTO(domain.getDes_table_value());
    }
}

