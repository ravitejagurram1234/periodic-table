package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteTypesDocumentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class ModificationParSocieteTypeDocumentBusiness {
    @Autowired
    private ModificationParSocieteTypesDocumentDao modificationParSocieteTypesDocumentDao;

    public List<TypeDeDocument> getListeTypesDocumentsDispos(String p_societe){
        return modificationParSocieteTypesDocumentDao.getListeTypesDocumentsDispos(p_societe);
    }
}
