package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.SuiviDetailsMapper;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviDetailsDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCSuiviDetails implements SuiviDetailsDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCSuiviDetails(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetListeNewSuivisByFondsPart")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR),
                        new SqlParameter("p_idTypeRapport",Types.NUMERIC),
                        new SqlParameter("p_idLangue",Types.NUMERIC),
                        new SqlParameter("p_idGabarit", Types.NUMERIC),
                        new SqlParameter("p_typeGabarit", Types.NUMERIC),
                        new SqlParameter("p_dateEcheance", Types.DATE),
                        new SqlParameter("p_portefeuilles", Types.VARCHAR),
                        new SqlParameter("p_auditor", Types.VARCHAR),
                        new SqlParameter("p_accountant", Types.VARCHAR),
                        new SqlParameter("p_fundMgtCompany", Types.VARCHAR)
                );
    }

    @Override
    public List<SuiviDetails> getListeNewSuivisByFondsPart(Long p_idTypeRapport, Long p_idLangue, Long p_idGabarit, Long p_typeGabarit,
                                                           LocalDate p_dateEcheance, String p_portefeuilles, String p_auditor,
                                                           String p_accountant, String p_fundMgtCompany) {
        java.sql.Date sqlDate =p_dateEcheance!=null? java.sql.Date.valueOf(p_dateEcheance):null;


        Map<String, Object> params = Map.of(
                "p_idTypeRapport", p_idTypeRapport,
                "p_idLangue", p_idLangue,
                "p_idGabarit", p_idGabarit,
                "p_typeGabarit", p_typeGabarit,
                "p_dateEcheance", sqlDate,
                "p_portefeuilles", p_portefeuilles,
                "p_auditor", p_auditor != null && !p_auditor.isEmpty() ? p_auditor : "",
                "p_accountant", p_accountant != null && !p_accountant.isEmpty() ? p_accountant : "",
                "p_fundMgtCompany", p_fundMgtCompany != null && !p_fundMgtCompany.isEmpty() ? p_fundMgtCompany : ""
        );

        SimpleJdbcCall jdbcCallWithMapper=this.simpleJdbcCall
                .returningResultSet("RETURN_VALUE",(rs,rowNum)->{
                    try{
                        return SuiviDetailsMapper.mapResult(rs, p_typeGabarit);
                    }catch (SQLException e){
                        throw new RuntimeException("ERROR mapping",e);
                    }
                });



        try {
            Map<String, Object> result = jdbcCallWithMapper.execute(params);
            return (List<SuiviDetails>) result.get("RETURN_VALUE");
        } catch (Exception e) {
            System.err.println("Error during JDBC call: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
}
