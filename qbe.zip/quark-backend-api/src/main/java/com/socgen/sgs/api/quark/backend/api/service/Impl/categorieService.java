package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.categorieBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.service.categorieSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class categorieService implements categorieSerInterface {
    @Autowired
    private categorieBusiness categorieBusiness;

    public List<TypeDeDocument> getListeSousCategorie(int p_idCategorie, int p_checkAtLeastOneDocument) {
        return categorieBusiness.getListeSousCategorie( p_idCategorie, p_checkAtLeastOneDocument);
    }
}
