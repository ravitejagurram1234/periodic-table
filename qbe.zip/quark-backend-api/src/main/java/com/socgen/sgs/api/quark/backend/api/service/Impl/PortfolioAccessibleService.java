package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.PortfolioAccessibleBusiness;
import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.service.PortfolioAccessibleSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PortfolioAccessibleService implements PortfolioAccessibleSerInterface {

    @Autowired
    private PortfolioAccessibleBusiness portfolioAccessibleBusiness;

    @Override
    public List<portefeuilleDTO> getAccessiblePortfolios(
            Long p_idTypeRapport,
            Long p_idGabarit,
            Long p_idLangue,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {
        return portfolioAccessibleBusiness.getAccessiblePortfolios(
                p_idTypeRapport, p_idGabarit, p_idLangue, p_auditor, p_accountant, p_fundMgtCompany);
    }
}
