package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationPortefeuilleDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationTypeDeDocumentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class ModificationPortefeuilleBusiness {
    @Autowired
    private ModificationPortefeuilleDao modificationPortefeuilleDao;

    public List<portefeuille> getListPortefeuille(int p_id_sous_categorie){
        return modificationPortefeuilleDao.getListPortefeuille(p_id_sous_categorie);
    }
}
