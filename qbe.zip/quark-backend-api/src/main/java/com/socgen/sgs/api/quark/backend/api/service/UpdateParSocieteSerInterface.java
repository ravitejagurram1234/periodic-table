package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

public interface UpdateParSocieteSerInterface {
    void updateDocument(MultipartFile file, DocumentDTO dto);
    String getClientIp(HttpServletRequest request);
    Integer AuditUpdateParSociete(MultipartFile file, DocumentDTO dto, String page, String user, HttpServletRequest request);
}

