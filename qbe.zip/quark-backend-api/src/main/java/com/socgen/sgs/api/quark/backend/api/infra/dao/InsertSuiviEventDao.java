package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;

import java.time.LocalDate;

public interface InsertSuiviEventDao {
    void insertSuiviEvent(Long p_idSuivi, Long p_idEvent, Long p_idUser, Long p_eventDataType, LocalDate p_eventDateEcheance);
}
