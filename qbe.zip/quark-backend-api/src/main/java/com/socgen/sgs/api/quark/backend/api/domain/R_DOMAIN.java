package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class R_DOMAIN {
    private String libelle;
    private Long idSuivi;
}
