package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Devise;
import com.socgen.sgs.api.quark.backend.api.infra.dao.DeviseDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class DeviseBusiness {

    @Autowired
    private DeviseDao deviseDao;

    public List<Devise> getListeDevises() {
        return deviseDao.getListeDevises();
    }
}
