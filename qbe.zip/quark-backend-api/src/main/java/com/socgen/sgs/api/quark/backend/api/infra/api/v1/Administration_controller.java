package com.socgen.sgs.api.quark.backend.api.infra.api.v1;

import com.nimbusds.oauth2.sdk.AbstractOptionallyAuthenticatedRequest;
import com.socgen.sgs.api.quark.backend.api.Business.SuiviAdminBusiness;
import com.socgen.apibank.http.ratelimiter.RateLimiter;
import com.socgen.sgs.api.quark.backend.api.service.IAuthenticationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.Problem;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Optional;

import static org.springframework.http.MediaType.APPLICATION_PROBLEM_JSON_VALUE;
import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping(value = "/api/v1/administration")
@CrossOrigin(origins = "*", allowedHeaders = "*",
        methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
                RequestMethod.DELETE, RequestMethod.OPTIONS})
public class Administration_controller {

    private static final String QUOTA_EXCEEDED_EXAMPLE = "";

    @Autowired
    private SuiviAdminBusiness suiviAdminBusiness;
    @Autowired
    private IAuthenticationService  authenticationService;

    // ─────────────────────────────────────────────────────────────────────────
    // 1. GET exact date of suivi
    // ─────────────────────────────────────────────────────────────────────────
    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
    @Operation(summary = "Get exact date of a suivi",
            description = "Calls QXP_PK_SUIVI.GetDateExacteSuivi")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Date retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Bad Request",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
            @ApiResponse(responseCode = "404", description = "Not found",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE))
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    @GetMapping("/suivi/{idSuivi}/dateExacte")
    public ResponseEntity<String> getDateExacteSuivi(@PathVariable Long idSuivi) {
        String date = suiviAdminBusiness.getDateExacteSuivi(idSuivi);
        if (date == null || date.isEmpty()) {
            return ResponseEntity.ok()
                    .cacheControl(CacheControl.noCache())
                    .body(null); // or return ResponseEntity.noContent().build()
        }
        return ResponseEntity.ok()
                .cacheControl(CacheControl.noCache())
                .body(date);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2. PUT – Update exact date of suivi
    // ─────────────────────────────────────────────────────────────────────────
    @Operation(summary = "Update exact date of a suivi",
            description = "Calls QXP_PK_SUIVI.UpdateDateExacteSuivi then InsertTrace")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Date updated successfully"),
            @ApiResponse(responseCode = "400", description = "Bad Request",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE))
    })
    @PutMapping("/suivi/{idSuivi}/dateExacte")
    public ResponseEntity<String> updateDateExacteSuivi(
            @PathVariable Long idSuivi,
            @RequestParam String newDate,
//            @RequestParam String email,
            HttpServletRequest request) {
        Optional<String> user_email = authenticationService.getCurrentUserEmailId();
        suiviAdminBusiness.updateDateExacteSuivi(idSuivi, newDate, request, user_email.get());
        return ResponseEntity.ok().body("Date mise à jour avec succès");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 3. POST – Reset suivi
    // ─────────────────────────────────────────────────────────────────────────
    @Operation(summary = "Reset (reinitialize) a suivi",
            description = "Calls QXP_PK_SUIVI.GetTypeSuivi, blocks Traduction type, "
                    + "then QXP_PK_SUIVI.ResetSuivi and InsertTrace")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Suivi reset successfully"),
            @ApiResponse(responseCode = "400", description = "Cannot reset a translation suivi",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE))
    })
    @PostMapping("/suivi/{idSuivi}/reset")
    public ResponseEntity<String> resetSuivi(
            @PathVariable Long idSuivi,
//            @RequestParam String email,
            HttpServletRequest request) {
        Optional<String> user_email = authenticationService.getCurrentUserEmailId();
        suiviAdminBusiness.resetSuivi(idSuivi, user_email.get(), request);
        return ok().body("Réinitialisation effectuée avec succès");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 4. DELETE – Remove/suppress suivi
    // ─────────────────────────────────────────────────────────────────────────
    @Operation(summary = "Remove a suivi",
            description = "Calls QXP_PK_SUIVI.RemoveSuivi then InsertTrace")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Suivi removed successfully"),
            @ApiResponse(responseCode = "400", description = "Bad Request",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE))
    })
    @DeleteMapping("/suivi/{idSuivi}")
    public ResponseEntity<String> removeSuivi(
            @PathVariable Long idSuivi,
//            @RequestParam String email,
            HttpServletRequest request) {
        Optional<String> user_email = authenticationService.getCurrentUserEmailId();
        suiviAdminBusiness.removeSuivi(idSuivi, user_email.get(), request);
        return ok().body("Suppression du suivi effectuée avec succès");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 5. POST – Unlock suivi
    // ─────────────────────────────────────────────────────────────────────────
    @Operation(summary = "Unlock (déverrouiller) a suivi",
            description = "Calls QXP_PK_SUIVI.UnlockSuivi then InsertTrace")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Suivi unlocked successfully"),
            @ApiResponse(responseCode = "400", description = "Bad Request",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE))
    })
    @PostMapping("/suivi/{idSuivi}/unlock")
    public ResponseEntity<String> unlockSuivi(
            @PathVariable Long idSuivi,
//            @RequestParam String email,
            HttpServletRequest request) {
        Optional<String> user_email = authenticationService.getCurrentUserEmailId();
        suiviAdminBusiness.unlockSuivi(idSuivi, request, user_email.get());
        return ok().body("Déverrouillage du suivi effectué avec succès");
    }
}
