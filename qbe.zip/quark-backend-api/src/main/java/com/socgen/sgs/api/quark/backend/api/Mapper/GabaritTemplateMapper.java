package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.gabaritTemplateDTO;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GabaritTemplateMapper {
    public static GabaritTemplate mapResult(ResultSet rs)throws SQLException {
        GabaritTemplate g=new GabaritTemplate();
        g.setId_gabarit_template(rs.getInt("id_gabarit_template"));
        g.setNom(rs.getString("nom"));
//        g.setContenu(rs.getBytes("contenu"));
//        g.setCommentaire(rs.getString("commentaire"));
        return g;
    }

    public static gabaritTemplateDTO toDto(GabaritTemplate domain){
        gabaritTemplateDTO g=new gabaritTemplateDTO();
        g.setId_gabarit_template(domain.getId_gabarit_template());
        g.setNom(domain.getNom());
        g.setContenu(domain.getContenu());
        g.setCommentaire(domain.getCommentaire());
        return g;
    }

    public static GabaritTemplate mapResultgabaritemplate(ResultSet rs)throws SQLException {
        GabaritTemplate g=new GabaritTemplate();
        g.setId_gabarit_template(rs.getInt("id_gabarit_template"));
        g.setNom(rs.getString("nom"));
        g.setContenu(rs.getBytes("contenu"));
        g.setCommentaire(rs.getString("commentaire"));
        return g;
    }
}
