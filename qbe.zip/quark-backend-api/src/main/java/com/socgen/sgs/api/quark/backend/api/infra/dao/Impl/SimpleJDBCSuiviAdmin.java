package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviAdminDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

@Repository
public class SimpleJDBCSuiviAdmin implements SuiviAdminDao {

    private final SimpleJdbcCall callGetDate;
    private final SimpleJdbcCall callUpdateDate;
    private final SimpleJdbcCall callGetType;
    private final SimpleJdbcCall callReset;
    private final SimpleJdbcCall callRemove;
    private final SimpleJdbcCall callUnlock;

    @Autowired
    public SimpleJDBCSuiviAdmin(DataSource dataSource) {

        // FUNCTION GetDateExacteSuivi(p_id_suivi IN NUMBER) RETURN VARCHAR2
        this.callGetDate = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetDateExacteSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("return", Types.VARCHAR),
                        new SqlParameter("p_id_suivi", Types.NUMERIC)
                );

        // PROCEDURE UpdateDateExacteSuivi(p_id_suivi IN NUMBER, p_new_date IN VARCHAR2)
        this.callUpdateDate = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withProcedureName("UpdateDateExacteSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_new_date", Types.VARCHAR)
                );

        // FUNCTION GetTypeSuivi(p_idSuivi IN NUMBER) RETURN NUMBER
        this.callGetType = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetTypeSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("return", Types.NUMERIC),
                        new SqlParameter("p_idSuivi", Types.NUMERIC)
                );

        // PROCEDURE ResetSuivi(p_id_suivi IN NUMBER, p_email IN VARCHAR2)
        this.callReset = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withProcedureName("ResetSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_email", Types.VARCHAR)
                );


        // PROCEDURE RemoveSuivi(p_id_suivi IN NUMBER, p_email IN VARCHAR2)
        this.callRemove = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withProcedureName("RemoveSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_email", Types.VARCHAR)
                );

        // PROCEDURE UnlockSuivi(p_id_suivi IN NUMBER)
        this.callUnlock = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withProcedureName("UnlockSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_id_suivi", Types.NUMERIC)
                );
    }

    @Override
    public String getDateExacteSuivi(Long p_idSuivi) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_id_suivi", p_idSuivi);
        Map<String, Object> result = callGetDate.execute(params);
        // Oracle FUNCTION returns value under key "return"
        return (String) result.get("return");
    }

    @Override
    public void updateDateExacteSuivi(Long p_idSuivi, String p_newDate) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_id_suivi", p_idSuivi);
        params.put("p_new_date", p_newDate);
        callUpdateDate.execute(params);
    }

    @Override
    public Integer getTypeSuivi(Long p_idSuivi) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_idSuivi", p_idSuivi);
        Map<String, Object> result = callGetType.execute(params);
        BigDecimal val = (BigDecimal) result.get("return");
        return val != null ? val.intValue() : null;
    }

    @Override
    public void resetSuivi(Long p_idSuivi, String p_email) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_id_suivi", p_idSuivi);
        params.put("p_email", p_email);
        callReset.execute(params);
    }


    @Override
    public void removeSuivi(Long p_idSuivi, String p_email) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_id_suivi", p_idSuivi);
        params.put("p_email", p_email);
        callRemove.execute(params);
    }

    @Override
    public void unlockSuivi(Long p_idSuivi) {
        Map<String, Object> params = new HashMap<>();
        params.put("p_id_suivi", p_idSuivi);
        callUnlock.execute(params);
    }
}
