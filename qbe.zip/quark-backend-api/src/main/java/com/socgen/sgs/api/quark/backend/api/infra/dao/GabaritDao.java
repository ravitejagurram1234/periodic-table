package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;

public interface GabaritDao {
    Gabarit getGabarit(Long p_idGabarit);
}
