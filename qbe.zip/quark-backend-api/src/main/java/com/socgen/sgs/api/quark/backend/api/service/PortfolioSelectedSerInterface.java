package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import java.util.List;

public interface PortfolioSelectedSerInterface {
    List<portefeuilleDTO> getSelectedPortfolios(
            Long p_idTypeRapport,
            Long p_idGabarit,
            Long p_idLangue,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany
    );
}
