package com.socgen.sgs.api.quark.backend.api.infra.jpa;

public interface TypeRapportData {
    Long getId();

    String getLibelle();
}
