package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentsStructureDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class CompartimentsStructureBusiness {
    @Autowired
    private CompartimentsStructureDao compartimentsStructureDao;

    public List<Structure> getStructures(int p_withAtLeastOneCompatiment, String p_auditor, String p_accountant, String p_fundMgtCompany){
        return compartimentsStructureDao.getStructures(p_withAtLeastOneCompatiment,p_auditor,p_accountant,p_fundMgtCompany);
    }
}
