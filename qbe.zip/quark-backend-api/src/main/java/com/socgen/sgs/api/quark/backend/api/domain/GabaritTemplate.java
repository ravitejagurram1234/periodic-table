package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GabaritTemplate {

        private int id_gabarit_template;
        private String nom;
        private byte[] contenu;
        private String commentaire;

//        public GabaritTemplate(byte[] contenu, String nom, String commentaire, int id_gabarit_template) {
//                this.contenu=contenu;
//                this.nom = nom;
//                this.commentaire = commentaire;
//                this.id_gabarit_template = id_gabarit_template;
//        }
}
