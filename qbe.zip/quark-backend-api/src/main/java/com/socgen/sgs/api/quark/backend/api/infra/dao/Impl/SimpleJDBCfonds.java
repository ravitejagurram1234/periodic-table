package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.FondsMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Fonds;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FondsDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;
@Repository
public class SimpleJDBCfonds implements FondsDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCfonds(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeFondsForNewSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> FondsMapper.mapResult(rs)),
                        new SqlParameter("p_idTypeRapport", Types.NUMERIC),
                        new SqlParameter("p_idLangue", Types.NUMERIC),
                        new SqlParameter("p_idGabarit", Types.NUMERIC),
                        new SqlParameter("p_dateEcheance", Types.DATE)
                );

    }

    @Override
    public List<Fonds> getListeFondsForNewSuivi(Long p_idTypeRapport, Long p_idLangue, Long p_idGabarit, LocalDate p_dateEcheance) {

        java.sql.Date sqlDate=java.sql.Date.valueOf(p_dateEcheance);
        Map<String, Object> params = Map.of(
                "p_idTypeRapport", p_idTypeRapport,
                "p_idLangue", p_idLangue,
                "p_idGabarit", p_idGabarit,
                "p_dateEcheance", sqlDate
        );
        try {
            Map<String, Object> result = simpleJdbcCall.execute(params);
            return (List<Fonds>) result.get("RETURN_VALUE");
        } catch (Exception e) {
            System.err.println("Error during JDBC call: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
}
