package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.InsertTrace;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertSuiviEventDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Types;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCInsertSuiviEvents  implements InsertSuiviEventDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCInsertSuiviEvents(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withProcedureName("InsertSuiviEvent")
                .declareParameters(
                        new SqlParameter("p_idSuivi", Types.NUMERIC),
                        new SqlParameter("p_idEvent", Types.NUMERIC),
                        new SqlParameter("p_idUser", Types.NUMERIC),
                        new SqlParameter("p_eventDataType", Types.NUMERIC),
                        new SqlParameter("p_eventDateEcheance",Types.DATE)

                );
    }

    @Override
    public void insertSuiviEvent(Long p_idSuivi, Long p_idEvent, Long p_idUser, Long p_eventDataType, LocalDate p_eventDateEcheance) {
        Date sqlDate= (p_eventDateEcheance!=null)?java.sql.Date.valueOf(p_eventDateEcheance):null;
        Map<String, Object> params = new HashMap<>();
        params.put("p_idSuivi",p_idSuivi);
        params.put("p_idEvent",p_idEvent);
        params.put("p_idUser",p_idUser);
        params.put("p_eventDataType",p_eventDataType);
        params.put("p_eventDateEcheance", sqlDate);

        simpleJdbcCall.execute(params);

    }


}

