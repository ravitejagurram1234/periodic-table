package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.Structure;

import java.util.List;

public interface CompartimentsStructureSerInterface {
    List<Structure> getStructures(int p_withAtLeastOneCompatiment, String p_auditor, String p_accountant, String p_fundMgtCompany);
}
