package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Audit {
    private String p_ip;
    private LocalDate p_startTime;
    private LocalDate p_endTime;
    private String p_page;
    private String p_login;
    private String p_module;
    private String p_fonction;
    private String p_message;
    private String p_param1;
    private String p_param2;
    private String p_param3;
    private String p_param4;
    private String p_param5;
    private BigDecimal p_temps_reponse ;
    private int p_statut = 0;
    private int p_id_application;
    private String p_nom_application;
}
