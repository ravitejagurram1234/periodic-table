package com.socgen.sgs.api.quark.backend.api.domain;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TypeRapport {
    private Long id;
    private String libelle;


    private TypeRapport(TypeRapport.Builder builder) {
        this.id = builder.id;
        this.libelle=builder.libelle;
    }


    // Static builder method
    public static TypeRapport.Builder builder() {
        return new TypeRapport.Builder();
    }

    // Builder class
    public static class Builder {
        private Long id;
        public String libelle;


        public TypeRapport.Builder id(Long id) {
            this.id = id;
            return this;
        }

        public TypeRapport.Builder libelle(String libelle) {
            this.libelle=libelle;
            return this;
        }



        public TypeRapport build() {
            return new TypeRapport(this);
        }


    }
}
