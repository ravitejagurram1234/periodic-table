package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GetGabaritTemplateDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class GetGabaritTemplatesBusiness {
    @Autowired
    private GetGabaritTemplateDao getGabaritTemplateDao;

    public GabaritTemplate getGabaritTemplates(Long p_idGabaritTemplate){
        return getGabaritTemplateDao.getGabaritTemplates(p_idGabaritTemplate);
    }
}
