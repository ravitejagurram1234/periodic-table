package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.portefeuilleDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class portefeuilleBusiness {
    @Autowired
    private portefeuilleDao portefeuilleDao;

    public List<portefeuille> getPortefeuille(){
        return portefeuilleDao.getPortefeuille();
    }
}
