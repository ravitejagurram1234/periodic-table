package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.gabaritTemplateDTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

public interface UpdateGabaritTemplateSerInterface {
    void updateGabaritTemplate(MultipartFile file, gabaritTemplateDTO dto, String commentaire);
    String getClientIp(HttpServletRequest request);
    Integer auditUpdateGabaritTemplate(MultipartFile file, gabaritTemplateDTO dto, String page, String user, HttpServletRequest request);
}
