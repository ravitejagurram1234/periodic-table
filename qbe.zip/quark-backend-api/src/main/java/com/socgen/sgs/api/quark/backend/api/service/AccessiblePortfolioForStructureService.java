package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.AccessiblePortfolioForStructureResponseDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.AccessiblePortfolioForStructureResponseDTO.PortfolioItemDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentsDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureGabaritDao;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class AccessiblePortfolioForStructureService {

  private final CompartimentsDao compartimentsDao;
  private final StructureGabaritDao structureGabaritDao;

  public AccessiblePortfolioForStructureService(final CompartimentsDao compartimentsDao, final StructureGabaritDao structureGabaritDao) {
    this.compartimentsDao = compartimentsDao;
    this.structureGabaritDao = structureGabaritDao;
  }

  public AccessiblePortfolioForStructureResponseDTO getAccessiblePortfoliosForStructure(final String idStructure, final Long idGabarit,
      final String auditor, final String accountant, final String fundMgtCompany) {

    final List<Compartiment> baseList = compartimentsDao.getStructures(idStructure, auditor, accountant, fundMgtCompany);

    final List<Compartiment> selectedList = structureGabaritDao.getListeCompartsByStructGab(idStructure, idGabarit);
    final Set<String> selectedCodes = selectedList.stream()
        .map(Compartiment::getId_fnd_code)
        .filter(Objects::nonNull)
        .collect(Collectors.toSet());

    final Map<String, PortfolioItemDTO> baseByCode = new LinkedHashMap<>();
    for (final Compartiment compartiment : baseList) {
      final String code = compartiment.getId_fnd_code();
      if (Objects.isNull(code)) {
        continue;
      }

      baseByCode.put(code, new PortfolioItemDTO(code, firstNonBlank(compartiment.getLibelle_compartiment(), compartiment.getFnd_sht_description())));
    }

    final List<PortfolioItemDTO> selected = selectedList.stream()
        .map(c -> {
          final String code = c.getId_fnd_code();
          if (Objects.isNull(code)) {
            return null;
          }

          final PortfolioItemDTO fromBase = baseByCode.get(code);
          if (Objects.nonNull(fromBase)) {
            return fromBase;
          }

          return new PortfolioItemDTO(code, firstNonBlank(c.getLibelle_compartiment(), c.getFnd_sht_description()));
        })
        .filter(Objects::nonNull)
        .toList();

    final List<PortfolioItemDTO> available = baseByCode.entrySet().stream()
        .filter(e -> !selectedCodes.contains(e.getKey()))
        .map(Map.Entry::getValue)
        .toList();

    return new AccessiblePortfolioForStructureResponseDTO(available, selected);
  }

  private static String firstNonBlank(final String firstCandidate, final String secondCandidate) {
    if (Objects.nonNull(firstCandidate) && !firstCandidate.isBlank()) {
      return firstCandidate;
    }

    return secondCandidate;
  }
}

