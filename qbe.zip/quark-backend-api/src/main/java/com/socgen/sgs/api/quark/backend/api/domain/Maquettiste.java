package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Maquettiste {

        private Long id;
        private String trigramme;

        private Maquettiste(Builder builder) {
                this.id = builder.id;
                this.trigramme = builder.trigramme;
        }



        // Static builder method
        public static Builder builder() {
                return new Builder();
        }

        // Builder class
        public static class Builder {
                private Long id;
                private String trigramme;

                public Builder id(Long id) {
                        this.id = id;
                        return this;
                }

                public Builder trigramme(String trigramme) {
                        this.trigramme = trigramme;
                        return this;
                }

                public Maquettiste build() {
                        return new Maquettiste(this);
                }
        }

}

