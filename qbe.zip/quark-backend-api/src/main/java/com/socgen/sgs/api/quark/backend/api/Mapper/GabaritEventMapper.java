package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.GabaritEventsDTO;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GabaritEventMapper {

    public static GabaritEvents mapResult(ResultSet rs) throws SQLException {
        GabaritEvents gabaritEvents = new GabaritEvents();
        gabaritEvents.setIdEvent(rs.getLong("ID_EVENT"));
        gabaritEvents.setTransduction_code(rs.getString("TRADUCTION_CODE"));
        gabaritEvents.setShow_on_eos(rs.getLong("SHOW_ON_EOS"));
        gabaritEvents.setType(rs.getString("TYPE"));
        gabaritEvents.setEvent_type(rs.getLong("EVENT_TYPE"));
        gabaritEvents.setMandatory(rs.getLong("MANDATORY"));
        return gabaritEvents;
    }

    public static GabaritEventsDTO toDto(GabaritEvents gabaritEvents) {
        return new GabaritEventsDTO(
                gabaritEvents.getTransduction_code()
                );
    }
}
