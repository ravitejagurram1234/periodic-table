package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ValidateStructureResponseDTO {
    private boolean success;
    private String message;
    private String idStructure;
}
