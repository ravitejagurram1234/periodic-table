package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.checkDoublOnDocumentDao;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCcheckDoublOnDocument implements checkDoublOnDocumentDao {

        private final SimpleJdbcCall simpleJdbcCall;

        @Autowired
        public SimpleJDBCcheckDoublOnDocument(DataSource dataSource) {
            this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                    .withCatalogName("QXP_PK_CHARGEMENT")
                    .withFunctionName("CheckDoublonDocument")
                    .declareParameters(
                            new SqlOutParameter("return", Types.NUMERIC),
                            new SqlParameter("p_id_document", Types.NUMERIC),
                            new SqlParameter("p_id_fnd_code", Types.VARCHAR),
                            new SqlParameter("p_id_unit_code", Types.VARCHAR),
                            new SqlParameter("p_societe", Types.VARCHAR),
                            new SqlParameter("p_id_sous_categorie", Types.NUMERIC),
                            new SqlParameter("p_id_langue", Types.NUMERIC),
                            new SqlParameter("p_date_document", Types.DATE)
                    );
        }




    @Override
    public Integer checkDoublonDocument(Document document1) {
            Date sqlDate = (document1.getP_date_document() != null) ? Date.valueOf(document1.getP_date_document()) : null;

            Map<String, Object> params = new HashMap<>();

            params.put("p_id_document", (document1.getP_id_document() == null || document1.getP_id_document()==0L) ? null :document1.getP_id_document());
            params.put("p_id_fnd_code", (document1.getP_id_fnd_code()==null || document1.getP_id_fnd_code().isEmpty())?null : document1.getP_id_fnd_code());
            params.put("p_id_unit_code", (document1.getP_id_unit_code() == null || document1.getP_id_unit_code().isEmpty()) ? null : document1.getP_id_unit_code());
            params.put("p_societe",(document1.getP_societe() == null || document1.getP_societe().isEmpty()) ? null : document1.getP_societe());
            params.put("p_id_sous_categorie",document1.getP_id_sous_categorie());
            params.put("p_id_langue", document1.getP_id_langue());
            params.put("p_date_document", sqlDate);

            Map<String, Object> result = simpleJdbcCall.execute(params);
            BigDecimal returnValue=(BigDecimal) result.get("return");
            return (returnValue!=null)?returnValue.intValue():null;


        }
}
