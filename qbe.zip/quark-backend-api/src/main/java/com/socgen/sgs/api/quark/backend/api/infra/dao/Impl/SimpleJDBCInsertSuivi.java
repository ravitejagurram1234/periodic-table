package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Suivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertSuiviDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCInsertSuivi implements InsertSuiviDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCInsertSuivi(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withProcedureName("InsertSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_id_type_rapport", Types.NUMERIC),
                        new SqlParameter("p_date_echeance", Types.DATE),
                        new SqlParameter("p_id_langue", Types.NUMERIC),
                        new SqlParameter("p_id_maquettiste", Types.NUMERIC),
                        new SqlParameter("p_id_gabarit", Types.NUMERIC),
                        new SqlParameter("p_id_createur", Types.NUMERIC),
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_id", Types.VARCHAR),
                        new SqlParameter("p_id_unit_code", Types.VARCHAR),
                        new SqlParameter("p_date_echeance_exacte", Types.VARCHAR),
        new SqlOutParameter("p_id_suivi_returned", Types.NUMERIC)
                );
    }

    @Override
    public Long insertSuivi(Suivi suivi) {

        Date sqlDate= java.sql.Date.valueOf(suivi.getP_date_echeance());
        Map<String, Object> params = new HashMap<>();
                params.put("p_id_type_rapport", suivi.getP_id_type_rapport());
                params.put("p_date_echeance", sqlDate);
                params.put("p_id_langue", suivi.getP_id_langue());
                params.put("p_id_maquettiste", suivi.getP_id_maquettiste());
                params.put("p_id_gabarit", suivi.getP_id_gabarit());
                params.put("p_id_createur", suivi.getP_id_createur());
                params.put("p_id_suivi",suivi.getP_id_suivi());
                params.put("p_id", suivi.getP_id());
                params.put("p_id_unit_code",suivi.getP_id_unit_code()!=null && !suivi.getP_id_unit_code().isEmpty()? suivi.getP_id_unit_code():null);
                params.put("p_date_echeance_exacte", suivi.getP_date_echeance_exacte());


        Map<String, Object> result = simpleJdbcCall.execute(params);
        BigDecimal outValue=(BigDecimal)result.get("p_id_suivi_returned");
        return outValue!=null?outValue.longValue():null;
    }
}
