package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import jakarta.persistence.criteria.CriteriaBuilder;

public interface checkDoublOnDocumentDao {
    Integer checkDoublonDocument(Document document1);
}
