package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;

import java.util.List;

public interface MaquettisteDao {
    List<Maquettiste> getMaquettiste();
}
