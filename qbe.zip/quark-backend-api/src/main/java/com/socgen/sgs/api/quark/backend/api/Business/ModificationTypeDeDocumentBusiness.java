package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationTypeDeDocumentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Component
@Transactional
public class ModificationTypeDeDocumentBusiness {
   @Autowired
   private ModificationTypeDeDocumentDao modificationTypeDeDocumentDao;

   public List<TypeDeDocument> getListTypeDocuments(){
       return modificationTypeDeDocumentDao.getListTypeDocuments();
   }
}
