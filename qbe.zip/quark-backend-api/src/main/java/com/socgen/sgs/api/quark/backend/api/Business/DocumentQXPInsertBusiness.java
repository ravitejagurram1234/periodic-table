package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.DocumentQXPInsertDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DocumentQXPInsertBusiness {
    @Autowired
    private DocumentQXPInsertDao documentQXPInsertDao;

    public Integer DocumentQXPInsert(byte[] p_contenu, int p_taille_document){
        return documentQXPInsertDao.DocumentQXPInsert(p_contenu,p_taille_document);
    }
}
