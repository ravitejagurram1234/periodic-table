package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;

public interface Gabarit_InsertDao {
    Integer insertGabarit(Chargement_gabarit gabarit);
}
