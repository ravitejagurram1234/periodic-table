package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.ModificationTypeDeDocumentBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.service.ModificationTypeDeDocumentSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ModificationTypeDeDocumentService implements ModificationTypeDeDocumentSerInterface {
    @Autowired
    private ModificationTypeDeDocumentBusiness modificationTypeDeDocumentBusiness;

    public List<TypeDeDocument> getListTypeDocuments() {
        return modificationTypeDeDocumentBusiness.getListTypeDocuments();
    }
}

