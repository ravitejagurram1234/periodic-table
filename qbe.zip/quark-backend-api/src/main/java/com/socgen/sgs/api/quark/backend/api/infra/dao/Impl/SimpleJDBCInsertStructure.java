package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertStructureDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;

@Slf4j
@Repository
public class SimpleJDBCInsertStructure implements InsertStructureDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public SimpleJDBCInsertStructure(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public boolean structureExists(String idStructure) {
        // Let Oracle handle it via unique constraint (ORA-00001)
        return false;
    }

    @Override
    public void insertStructure(String idStructure, String nom, String libelleLong,
                                String fndLegalType, String fndClassification,
                                String fndMngtCompany, String fndAccountant,
                                String cac, String devise) {

        StringBuilder sql = new StringBuilder();
        sql.append("BEGIN ");
        sql.append("  QXP_PK_GP.InsertStructure(");
        sql.append("    p_idStructure     => '").append(escape(idStructure)).append("', ");
        sql.append("    p_nom             => ").append(toSqlString(nom)).append(", ");
        sql.append("    p_libelleLong     => ").append(toSqlString(libelleLong)).append(", ");
        sql.append("    p_type            => ").append(toSqlString(fndLegalType)).append(", ");
        sql.append("    p_classification  => ").append(toSqlString(fndClassification)).append(", ");
        sql.append("    p_societeGestion  => ").append(toSqlString(fndMngtCompany)).append(", ");
        sql.append("    p_groupeComptable => ").append(toSqlString(fndAccountant)).append(", ");
        sql.append("    p_cac             => ").append(toSqlString(cac)).append(", ");
        sql.append("    p_devise          => ").append(toSqlString(devise));
        sql.append("  ); ");
        sql.append("  COMMIT; ");
        sql.append("END;");

        log.info("InsertStructure SQL: {}", sql);

        try {
            jdbcTemplate.execute(sql.toString());
            log.info("Structure '{}' created successfully", idStructure);
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().contains("ORA-00001")) {
                throw new IllegalStateException("Structure with ID '" + idStructure + "' already exists", e);
            }
            throw e;
        }
    }

    private String escape(String value) {
        return value == null ? "" : value.replace("'", "''");
    }

    private String toSqlString(String value) {
        return value != null ? "'" + escape(value) + "'" : "NULL";
    }
}
