package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ModificationGabaritDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

public interface UpdateCompartimentsSerInterface {
    void updateCompartimentInfos(CompartimentsDTO dto);
    String getClientIp(HttpServletRequest request);
    Integer AuditUpdateCompartiments(CompartimentsDTO dto, String page, String user, HttpServletRequest request);

}
