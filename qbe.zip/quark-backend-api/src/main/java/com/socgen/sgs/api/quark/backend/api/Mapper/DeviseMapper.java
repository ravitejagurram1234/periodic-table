package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.DeviseDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Devise;
import lombok.extern.slf4j.Slf4j;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

@Slf4j
public class DeviseMapper {

    private static boolean metaLogged = false; // log only once, not for every row

    public static Devise mapResult(ResultSet rs) throws SQLException {

        // Log column names once to identify actual Oracle column names
        if (!metaLogged) {
            ResultSetMetaData meta = rs.getMetaData();
            for (int i = 1; i <= meta.getColumnCount(); i++) {
                log.info("Devise cursor - Column {} = {}", i, meta.getColumnName(i));
            }
            metaLogged = true;
        }

        Devise devise = new Devise();
        devise.setId_devise(rs.getString(1));  // safe positional until column names confirmed
        devise.setLibelle(rs.getString(2));
        return devise;
    }

    public static DeviseDTO toDto(Devise domain) {
        DeviseDTO dto = new DeviseDTO();
        dto.setId_devise(domain.getId_devise());
        dto.setLibelle(domain.getLibelle());
        return dto;
    }
}
