package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.dto.UploadErrorDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.UploadErrorDao;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.List;

@Repository
public class UploadErrorDaoImpl implements UploadErrorDao {

    private static final Logger logger = LoggerFactory.getLogger(UploadErrorDaoImpl.class);

    /** VarCharArray element type is VARCHAR2(200); clamp messages to avoid ORA-06502. */
    private static final int MAX_MESSAGE_LENGTH = 200;

    private final DataSource dataSource;

    @Autowired
    public UploadErrorDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public Integer updateUploadsWithErrors(List<UploadErrorDTO> uploadErrors) {
        if (uploadErrors == null || uploadErrors.isEmpty()) {
            return 0;
        }

        // Build parallel arrays from upload errors
        int[] errorIds = new int[uploadErrors.size()];
        String[] errorMessages = new String[uploadErrors.size()];
        for (int i = 0; i < uploadErrors.size(); i++) {
            errorIds[i] = uploadErrors.get(i).getUploadId();
            errorMessages[i] = clampMessage(uploadErrors.get(i).getErrorMessage());
        }

        // UPDATE_UPLOAD_WITH_ERRORS is a function returning the updated row count. Its parameters are PL/SQL
        // associative arrays (TABLE OF ... INDEX BY BINARY_INTEGER), not SQL collection types, so they must
        // be bound with setPlsqlIndexTable rather than Types.ARRAY.
        try (Connection conn = dataSource.getConnection();
             CallableStatement cs = conn.prepareCall(
                     "{ ? = call QXP_PK_BATCH.UPDATE_UPLOAD_WITH_ERRORS(?, ?) }")) {

            OracleCallableStatement oraCs = cs.unwrap(OracleCallableStatement.class);
            oraCs.registerOutParameter(1, OracleTypes.NUMBER);
            oraCs.setPlsqlIndexTable(2, errorIds, errorIds.length, errorIds.length,
                    OracleTypes.NUMBER, 0);
            oraCs.setPlsqlIndexTable(3, errorMessages, errorMessages.length, errorMessages.length,
                    OracleTypes.VARCHAR, MAX_MESSAGE_LENGTH);

            oraCs.execute();
            int rowsUpdated = oraCs.getInt(1);
            logger.info("Flagged {} upload(s) with errors", rowsUpdated);
            return rowsUpdated;
        } catch (Exception e) {
            logger.error("Error updating uploads with errors", e);
            throw new RuntimeException("Failed to update uploads with errors", e);
        }
    }

    private static String clampMessage(String message) {
        if (message == null) {
            return "";
        }
        return message.length() > MAX_MESSAGE_LENGTH
                ? message.substring(0, MAX_MESSAGE_LENGTH)
                : message;
    }
}