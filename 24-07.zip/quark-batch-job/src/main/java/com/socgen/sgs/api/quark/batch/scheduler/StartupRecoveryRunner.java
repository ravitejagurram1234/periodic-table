package com.socgen.sgs.api.quark.batch.scheduler;

import com.socgen.sgs.api.quark.batch.service.ReInitiatePendingRunsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Profile;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * Resets stuck runs/uploads and re-initiates pending runs once when the application is ready, recovering
 * any items left mid-flight by a previous shutdown. Also available on demand via
 * {@code GET /api/v1/batchService/reInitiatePendingRuns}.
 * <p>
 * Recovered run ids are re-published, so the run-engine consumer must be idempotent per id_run: a run
 * that is in-flight when this executes is reset (4/5 -> 1) and re-queued.
 */
@Component
@Profile("!test")
public class StartupRecoveryRunner {

    private static final Logger logger = LoggerFactory.getLogger(StartupRecoveryRunner.class);

    private final ReInitiatePendingRunsService reInitiatePendingRunsService;

    public StartupRecoveryRunner(ReInitiatePendingRunsService reInitiatePendingRunsService) {
        this.reInitiatePendingRunsService = reInitiatePendingRunsService;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void recoverOnStartup() {
        try {
            logger.info("Startup recovery: resetting stuck runs/uploads and re-initiating pending runs");
            reInitiatePendingRunsService.reInitiatePendingRuns();
        } catch (Exception e) {
            logger.error("Startup recovery failed (application will continue)", e);
        }
    }
}