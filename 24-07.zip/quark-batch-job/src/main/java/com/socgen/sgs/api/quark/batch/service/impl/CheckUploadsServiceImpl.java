package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.business.CreateRunUploadBusiness;
import com.socgen.sgs.api.quark.batch.business.NewUploadsBusiness;
import com.socgen.sgs.api.quark.batch.business.UploadDocumentBusiness;
import com.socgen.sgs.api.quark.batch.business.UploadErrorBusiness;
import com.socgen.sgs.api.quark.batch.domain.DocumentIdentity;
import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.CreateRunUploadResultDTO;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.dto.UploadDocumentDTO;
import com.socgen.sgs.api.quark.batch.dto.UploadErrorDTO;
import com.socgen.sgs.api.quark.batch.service.DocumentPoolService;
import com.socgen.sgs.api.quark.batch.mapper.UploadDocumentMapper;
import com.socgen.sgs.api.quark.batch.service.CheckUploadsService;
import com.socgen.sgs.api.quark.batch.service.QuarkXPressServerXmlService;
import com.socgen.sgs.api.quark.batch.service.S3UploadService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

@Service
public class CheckUploadsServiceImpl implements CheckUploadsService {

    private static final Logger logger = LoggerFactory.getLogger(CheckUploadsServiceImpl.class);

    private final NewUploadsBusiness newUploadsBusiness;
    private final UploadDocumentBusiness uploadDocumentBusiness;
    private final S3UploadService s3UploadService;
    private final QuarkXPressServerXmlService quarkXPressServerXmlService;
    private final DocumentPoolService qxpsDocumentPoolService;
    private final CreateRunUploadBusiness createRunUploadBusiness;
    private final RabbitMqProducer rabbitMqProducer;
    private final UploadErrorBusiness uploadErrorBusiness;

    public CheckUploadsServiceImpl(NewUploadsBusiness newUploadsBusiness,
                                   UploadDocumentBusiness uploadDocumentBusiness,
                                   S3UploadService s3UploadService,
                                   QuarkXPressServerXmlService quarkXPressServerXmlService,
                                   DocumentPoolService qxpsDocumentPoolService,
                                   CreateRunUploadBusiness createRunUploadBusiness,
                                   RabbitMqProducer rabbitMqProducer,
                                   UploadErrorBusiness uploadErrorBusiness) {
        this.newUploadsBusiness = newUploadsBusiness;
        this.uploadDocumentBusiness = uploadDocumentBusiness;
        this.s3UploadService = s3UploadService;
        this.quarkXPressServerXmlService = quarkXPressServerXmlService;
        this.qxpsDocumentPoolService = qxpsDocumentPoolService;
        this.createRunUploadBusiness = createRunUploadBusiness;
        this.rabbitMqProducer = rabbitMqProducer;
        this.uploadErrorBusiness = uploadErrorBusiness;
    }

    @Override
    public List<RunIdDto> checkUploads() {
        // 1–3: Get new uploads, exit if none
        List<UploadDocumentDTO> newUploads = getNewUploads();
        logger.info("Found {} new upload(s)", newUploads.size());
        if (newUploads.isEmpty()) {
            return List.of();
        }

        // 4: Load blob content. A single upload whose load fails or returns no row is skipped; the rest of
        // the pass still runs.
        List<UploadDocumentDTO> uploadDocuments = getUploadDocuments(newUploads);
        logger.info("Processing {} uploads with content", uploadDocuments.size());

        // 5: Accumulators. Run ids are de-duplicated as they are collected.
        LinkedHashSet<Integer> runIdsToBeLaunched = new LinkedHashSet<>();
        List<UploadErrorDTO> uploadErrors = new ArrayList<>();
        int successCount = 0;
        int failureCount = 0;

        // 6: Per-upload processing loop
        for (UploadDocumentDTO doc : uploadDocuments) {
            Integer uploadId = doc.getUploadId();
            String documentName = constructDocumentName(uploadId);
            try {
                // 6a: S3 upload is best-effort — a failure must not block run creation, so it is caught here.
                try {
                    String s3Key = s3UploadService.uploadDocument(uploadId, doc.getContenu());
                    logger.info("Uploaded to S3. Upload ID: {}, S3 Key: {}", uploadId, s3Key);
                } catch (Exception e) {
                    logger.warn("S3 upload failed for Upload ID {} (non-critical, continuing)", uploadId, e);
                }

                boolean addedToPool = false;
                try {
                    // 6b: Add file to QuarkXPress Server document pool
                    qxpsDocumentPoolService.addFileToPool(documentName, doc.getContenu());
                    addedToPool = true;

                    // 6c: Fetch the DID box and parse the identity. An empty box or a not-defined identity
                    // is treated as a DID-field error.
                    String xmlContent = qxpsDocumentPoolService.fetchXmlForBox(documentName, "DID");
                    String didValue = (xmlContent == null || xmlContent.isBlank())
                            ? null
                            : quarkXPressServerXmlService.getElementValueByIdName(xmlContent, "DID");
                    DocumentIdentity identity = (didValue == null || didValue.isBlank())
                            ? null
                            : quarkXPressServerXmlService.parseDocumentIdentity(didValue);

                    if (identity == null || !identity.isDefined()) {
                        String errorMsg = "Invalid DID field(s) in document " + documentName;
                        logger.error("{}. Upload ID: {}", errorMsg, uploadId);
                        uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                        failureCount++;
                        continue;
                    }

                    Integer idSuivi = Integer.parseInt(identity.getIdSuivi());
                    logger.info("Extracted metadata. Upload ID: {}, Suivi ID: {}", uploadId, idSuivi);

                    // 6d: Create run via stored procedure. A DB failure is normalised to code 0, producing
                    // the create-error message below.
                    CreateRunUploadResultDTO result;
                    try {
                        result = createRunUploadBusiness.createRunUpload(idSuivi, uploadId);
                    } catch (Exception e) {
                        logger.error("Error during run upload creation. Upload ID: {}", uploadId, e);
                        result = new CreateRunUploadResultDTO(0);
                    }

                    // 6e: Handle result codes
                    if (result.isSuccess()) {
                        logger.info("Run created. Upload ID: {}, Run ID: {}", uploadId, result.getRunId());
                        runIdsToBeLaunched.add(result.getRunId());
                        successCount++;
                    } else if (result.isRunInExecution()) {
                        String errorMsg = "Run already taken by batch for document " + documentName;
                        logger.error("{}. Upload ID: {}, Suivi ID: {}", errorMsg, uploadId, idSuivi);
                        uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                        failureCount++;
                    } else if (result.isSuiviLocked()) {
                        String errorMsg = "Suivi is locked for document " + documentName;
                        logger.error("{}. Upload ID: {}, Suivi ID: {}", errorMsg, uploadId, idSuivi);
                        uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                        failureCount++;
                    } else {
                        String errorMsg = "Error creating run upload for document " + documentName;
                        logger.error("{}. Upload ID: {}, Suivi ID: {}", errorMsg, uploadId, idSuivi);
                        uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                        failureCount++;
                    }
                } finally {
                    // Always remove the file added to the QXPS pool this pass.
                    if (addedToPool) {
                        try {
                            qxpsDocumentPoolService.deleteFileFromPool(documentName);
                        } catch (Exception ex) {
                            logger.warn("Failed to remove {} from QXPS pool", documentName, ex);
                        }
                    }
                }
            } catch (Exception e) {
                String errorMsg = "Failed to retrieve XML or DID field not found for document " + documentName;
                logger.error("{}. Upload ID: {}. Continuing.", errorMsg, uploadId, e);
                uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                failureCount++;
            }
        }

        // 7: Queue successful run IDs to RabbitMQ (done before writing errors).
        for (Integer runId : runIdsToBeLaunched) {
            try {
                rabbitMqProducer.sendRunId(runId);
                logger.info("Run ID {} queued to RabbitMQ", runId);
            } catch (Exception e) {
                logger.error("Failed to queue Run ID {}.", runId, e);
            }
        }

        // 8: Flag error uploads in the database.
        if (!uploadErrors.isEmpty()) {
            try {
                Integer rowsUpdated = uploadErrorBusiness.updateUploadsWithErrors(uploadErrors);
                logger.info("Updated {} upload records with error status", rowsUpdated);
                if (rowsUpdated != null && rowsUpdated != uploadErrors.size()) {
                    logger.warn("Error count ({}) does not match rows updated in qxp_document_upload ({})",
                            uploadErrors.size(), rowsUpdated);
                }
            } catch (Exception e) {
                logger.error("Failed to update error uploads in database", e);
            }
        }

        logger.info("Completed: {} successful, {} failed", successCount, failureCount);
        return runIdsToBeLaunched.stream().map(RunIdDto::new).toList();
    }

    private String constructDocumentName(Integer uploadId) {
        return String.format("UP_%d.qxp", uploadId);
    }

    private List<UploadDocumentDTO> getNewUploads() {
        List<UploadDocumentDomain> uploadDocumentDomains = newUploadsBusiness.getNewUploadDocuments();
        return uploadDocumentDomains.stream().map(UploadDocumentMapper:: toDto).toList();
    }

    private List<UploadDocumentDTO> getUploadDocuments(List<UploadDocumentDTO> uploadIds) {
        List<UploadDocumentDTO> loaded = new ArrayList<>();
        for (UploadDocumentDTO uploadId : uploadIds) {
            try {
                UploadDocumentDomain domain = uploadDocumentBusiness.getUploadDocument(uploadId);
                if (domain != null) {
                    loaded.add(UploadDocumentMapper.toDto(domain));
                } else {
                    logger.error("Unable to load file {} from qxp_document_upload", uploadId.getUploadId());
                }
            } catch (Exception e) {
                logger.error("Unable to load file {} from qxp_document_upload", uploadId.getUploadId(), e);
            }
        }
        return loaded;
    }
}