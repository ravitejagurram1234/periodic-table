package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.UploadDocumentDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.UploadDocumentDao;
import com.socgen.sgs.api.quark.batch.mapper.UploadDocumentMapper;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;

@Repository
public class UploadDocumentDaoImpl implements UploadDocumentDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public UploadDocumentDaoImpl(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public UploadDocumentDomain getUploadDocument(UploadDocumentDTO uploadId) {
        // GET_UPLOAD_DOCUMENT(p_id_upload) returns a REF CURSOR of (id_upload, CONTENU) for one upload.
        return jdbcTemplate.execute(
                "{ ? = call QXP_PK_BATCH.GET_UPLOAD_DOCUMENT(?) }",
                (CallableStatementCallback<UploadDocumentDomain>) cs -> {
                    cs.registerOutParameter(1, OracleTypes.CURSOR);
                    cs.setInt(2, uploadId.getUploadId());
                    cs.execute();
                    try (ResultSet rs = (ResultSet) cs.getObject(1)) {
                        if (rs.next()) {
                            return UploadDocumentMapper.mapResultWithContenu(rs);
                        }
                        return null;
                    }
                });
    }
}