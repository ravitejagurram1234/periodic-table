package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.NewUploadDocumentsDao;
import com.socgen.sgs.api.quark.batch.mapper.UploadDocumentMapper;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Repository
public class NewUploadDocumentsDaoImpl implements NewUploadDocumentsDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public NewUploadDocumentsDaoImpl(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public List<UploadDocumentDomain> getNewUploadDocuments() {
        // GET_NEW_UPLOAD is a function returning a REF CURSOR of upload ids.
        return jdbcTemplate.execute(
                "{ ? = call QXP_PK_BATCH.GET_NEW_UPLOAD() }",
                (CallableStatementCallback<List<UploadDocumentDomain>>) cs -> {
                    cs.registerOutParameter(1, OracleTypes.CURSOR);
                    cs.execute();
                    List<UploadDocumentDomain> uploads = new ArrayList<>();
                    try (ResultSet rs = (ResultSet) cs.getObject(1)) {
                        while (rs.next()) {
                            uploads.add(UploadDocumentMapper.mapResult(rs));
                        }
                    }
                    return uploads;
                });
    }
}