package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.PlannedRunsDao;
import com.socgen.sgs.api.quark.batch.mapper.RunMapper;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Repository
public class PlannedRunsDaoImpl implements PlannedRunsDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public PlannedRunsDaoImpl(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public List<RunDomain> getPlannedRuns() {
        // GET_RUNS is a function returning a REF CURSOR of run ids. Register the return as an Oracle CURSOR,
        // then read the ResultSet before the statement closes.
        return jdbcTemplate.execute(
                "{ ? = call QXP_PK_BATCH.GET_RUNS() }",
                (CallableStatementCallback<List<RunDomain>>) cs -> {
                    cs.registerOutParameter(1, OracleTypes.CURSOR);
                    cs.execute();
                    List<RunDomain> runs = new ArrayList<>();
                    try (ResultSet rs = (ResultSet) cs.getObject(1)) {
                        while (rs.next()) {
                            runs.add(RunMapper.mapResult(rs));
                        }
                    }
                    return runs;
                });
    }
}