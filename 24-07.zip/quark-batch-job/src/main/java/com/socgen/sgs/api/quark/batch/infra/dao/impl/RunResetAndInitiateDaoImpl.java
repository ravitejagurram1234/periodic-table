package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.RunResetAndInitiateDao;
import com.socgen.sgs.api.quark.batch.mapper.RunMapper;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Repository
public class RunResetAndInitiateDaoImpl implements RunResetAndInitiateDao {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public RunResetAndInitiateDaoImpl(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void resetRunsStatus() {
        // RESET_RUNS_STATUS is a procedure with no parameters or return value.
        jdbcTemplate.execute(
                "{ call QXP_PK_BATCH.RESET_RUNS_STATUS() }",
                (CallableStatementCallback<Void>) cs -> {
                    cs.execute();
                    return null;
                });
    }

    @Override
    public List<RunDomain> getRunsToBeInitiated() {
        // GET_RUNS_INITIALS is a function returning a REF CURSOR of run ids.
        return jdbcTemplate.execute(
                "{ ? = call QXP_PK_BATCH.GET_RUNS_INITIALS() }",
                (CallableStatementCallback<List<RunDomain>>) cs -> {
                    cs.registerOutParameter(1, OracleTypes.CURSOR);
                    cs.execute();
                    List<RunDomain> runs = new ArrayList<>();
                    try (ResultSet rs = (ResultSet) cs.getObject(1)) {
                        while (rs.next()) {
                            runs.add(RunMapper.mapResult(rs));
                        }
                    }
                    return runs;
                });
    }
}