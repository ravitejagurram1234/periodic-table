package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.config.QuarkXPressServerProperties;
import com.socgen.sgs.api.quark.batch.domain.DocumentIdentity;
import com.socgen.sgs.api.quark.batch.exception.QuarkXPressServerException;
import com.socgen.sgs.api.quark.batch.service.QuarkXPressServerXmlService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Objects;
import java.util.List;
import java.util.Locale;


/**
 * Implementation of QuarkXPressServerXmlService using HttpURLConnection.
 * URL format: {baseUrl}:{port}/{uploadDirectory}/{DID}/{documentName}
 */
@Service
public class QuarkXPressServerXmlServiceImpl implements QuarkXPressServerXmlService {

    private static final Logger logger = LoggerFactory.getLogger(QuarkXPressServerXmlServiceImpl.class);

    private static final int HTTP_OK = 200;
    private static final String HTTP_GET = "GET";
    private static final String ACCEPT_HEADER = "Accept";
    private static final String APPLICATION_XML = "application/xml";
    private static final String ID_TAG = "ID";
    private static final String NAME_ATTRIBUTE = "NAME";
    private static final String DID = "xml";

    // Document Identity parsing constants
    private static final String PIPE_DELIMITER = "\\|";
    private static final int MIN_IDENTITY_PARTS = 6;
    private static final int IDX_FND_CODE = 0;
    private static final int IDX_SUIVI = 1;
    private static final int IDX_RUN = 2;
    private static final int IDX_LANGUE = 3;
    private static final int IDX_DUE_DATE = 4;
    private static final int IDX_GENERATION_DATETIME = 5;
    private static final int IDX_UNIT_CODE = 6;

    //private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");

    // DID dates arrive in US/invariant style; accept the common variants (zero-padded or not, 24-hour or
    // 12-hour with AM/PM). An unparseable value yields null, which marks the identity as undefined.
    private static final List<DateTimeFormatter> DATE_TIME_FORMATTERS = List.of(
            DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss", Locale.US),
            DateTimeFormatter.ofPattern("M/d/yyyy H:mm:ss", Locale.US),
            DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a", Locale.US),
            DateTimeFormatter.ofPattern("M/d/yyyy h:mm:ss a", Locale.US));

    private final QuarkXPressServerProperties serverProperties;

    @Value("${quarkxpress.server.connection-timeout:30000}")
    private int connectionTimeout;

    @Value("${quarkxpress.server.read-timeout:60000}")
    private int readTimeout;

    public QuarkXPressServerXmlServiceImpl(QuarkXPressServerProperties serverProperties) {
        this.serverProperties = Objects.requireNonNull(serverProperties, "Server properties must not be null");
    }

    @Override
    public String fetchXmlContent(String documentName) {
        Objects.requireNonNull(documentName, "Document name must not be null");

        String url = buildUrl(documentName);
        logger.info("Fetching XML content from QuarkXPress Server: {}", url);

        HttpURLConnection connection = null;
        try {
            connection = createConnection(url);
            int responseCode = connection.getResponseCode();

            if (responseCode != HTTP_OK) {
                String errorMessage = String.format("Failed to fetch XML content. HTTP Status: %d, URL: %s",
                        responseCode, url);
                logger.error(errorMessage);
                throw new QuarkXPressServerException(errorMessage);
            }

            String xmlContent = readResponse(connection);
            logger.debug("Successfully fetched XML content from QuarkXPress Server. Content length: {} bytes",
                    xmlContent.length());

            return xmlContent;

        } catch (IOException e) {
            String errorMessage = String.format("I/O error while fetching XML content from URL: %s", url);
            logger.error(errorMessage, e);
            throw new QuarkXPressServerException(errorMessage, e);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    @Override
    public String getElementValueByIdName(String xmlContent, String idName) {
        Objects.requireNonNull(xmlContent, "XML content must not be null");
        Objects.requireNonNull(idName, "ID name must not be null");

        // Strip BOM and any leading non-XML characters before the XML declaration
        xmlContent = xmlContent.strip();
        if (xmlContent.startsWith("\uFEFF")) {
            xmlContent = xmlContent.substring(1).strip();
        }
        // Strip any characters before the XML declaration or root element
        int xmlDeclIndex = xmlContent.indexOf("<?xml");
        int rootIndex = xmlContent.indexOf("<");
        if (xmlDeclIndex > 0) {
            xmlContent = xmlContent.substring(xmlDeclIndex);
        } else if (rootIndex > 0) {
            xmlContent = xmlContent.substring(rootIndex);
        }

        if (!xmlContent.startsWith("<")) {
            throw new QuarkXPressServerException(
                    String.format("Response is not valid XML for ID NAME: %s. Content starts with: %.100s", idName, xmlContent));
        }

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Security: Disable external entities to prevent XXE attacks
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);

            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(xmlContent)));
            document.getDocumentElement().normalize();

            NodeList idElements = document.getElementsByTagName(ID_TAG);

            for (int i = 0; i < idElements.getLength(); i++) {
                Element idElement = (Element) idElements.item(i);
                String nameAttribute = idElement.getAttribute(NAME_ATTRIBUTE);

                if (idName.equals(nameAttribute)) {
                    // Navigate to parent BOX element and find RICHTEXT content
                    Element boxElement = (Element) idElement.getParentNode();
                    NodeList richTextElements = boxElement.getElementsByTagName("RICHTEXT");

                    if (richTextElements.getLength() > 0) {
                        String textContent = richTextElements.item(0).getTextContent();
                        logger.debug("Found element value for ID NAME '{}': {}", idName, textContent);
                        return textContent;
                    }
                }
            }

            logger.warn("No element found with ID NAME: {}", idName);
            return null;

        } catch (Exception e) {
            String errorMessage = String.format("Error parsing XML content to find element with ID NAME: %s", idName);
            logger.error(errorMessage, e);
            throw new QuarkXPressServerException(errorMessage, e);
        }
    }

    /**
     * Parses pipe-separated identity string into DocumentIdentity.
     * Format: ID_Fnd_Code|ID_Suivi|ID_Run|ID_Langue|Due_Date|Generation_DateTime|ID_Unit_Code(optional)
     */
    @Override
    public DocumentIdentity parseDocumentIdentity(String identityString) {
        Objects.requireNonNull(identityString, "Identity string must not be null");

        if (identityString.trim().isEmpty()) {
            throw new QuarkXPressServerException("Identity string must not be empty");
        }

        logger.debug("Parsing document identity string: {}", identityString);

        String[] parts = identityString.split(PIPE_DELIMITER, -1); // -1 to keep trailing empty strings

        if (parts.length < MIN_IDENTITY_PARTS) {
            logger.warn("DID has {} part(s), fewer than the required {}: {}",
                    parts.length, MIN_IDENTITY_PARTS, identityString);
            return DocumentIdentity.builder().build();
        }

        try {
            String idFndCode = parts[IDX_FND_CODE].trim();
            String idSuivi = parts[IDX_SUIVI].trim();
            String idRun = parts[IDX_RUN].trim();
            String idLangue = parts[IDX_LANGUE].trim();
            LocalDateTime dueDate = parseDateTime(parts[IDX_DUE_DATE].trim());
            LocalDateTime generationDateTime = parseDateTime(parts[IDX_GENERATION_DATETIME].trim());
            // ID_Unit_Code is optional - may be missing, empty, or present
            String idUnitCode = null;
            if (parts.length > IDX_UNIT_CODE) {
                String unitCodeValue = parts[IDX_UNIT_CODE].trim();
                if (!unitCodeValue.isEmpty()) {
                    idUnitCode = unitCodeValue;
                }
            }

            DocumentIdentity documentIdentity = DocumentIdentity.builder()
                    .idFndCode(idFndCode)
                    .idSuivi(idSuivi)
                    .idRun(idRun)
                    .idLangue(idLangue)
                    .dueDate(dueDate)
                    .generationDateTime(generationDateTime)
                    .idUnitCode(idUnitCode)
                    .build();

            logger.info("Successfully parsed document identity: {}", documentIdentity);
            return documentIdentity;

        } catch (QuarkXPressServerException e) {
            throw e;
        } catch (Exception e) {
            String errorMessage = String.format("Failed to parse document identity string: %s", identityString);
            logger.error(errorMessage, e);
            throw new QuarkXPressServerException(errorMessage, e);
        }
    }

    /** Parses date-time string with format MM/dd/yyyy HH:mm:ss */
    /** Parses a DID date-time, trying each accepted format. Returns null when empty or unparseable. */
    private LocalDateTime parseDateTime(String dateTimeString) {
        if (dateTimeString == null || dateTimeString.trim().isEmpty()) {
            return null;
        }
        String value = dateTimeString.trim();
        for (DateTimeFormatter formatter : DATE_TIME_FORMATTERS) {
            try {
                return LocalDateTime.parse(value, formatter);
            } catch (DateTimeParseException ignored) {
                // try the next accepted format
            }
        }
        logger.warn("Unparseable DID date-time: {}", value);
        return null;
    }

    /** Builds URL: {baseUrl}:{port}/xml/{uploadDirectory}/{documentName}?box=DID */
    private String buildUrl(String documentName) {
        return String.format("%s:%d/xml/%s/%s?box=DID",
                serverProperties.getBaseUrl(),
                serverProperties.getPort(),
                serverProperties.getUploadDirectory(),
                documentName);
    }

    /** Creates and configures HTTP connection */
    private HttpURLConnection createConnection(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        connection.setRequestMethod(HTTP_GET);
        connection.setConnectTimeout(connectionTimeout);
        connection.setReadTimeout(readTimeout);
        connection.setRequestProperty(ACCEPT_HEADER, APPLICATION_XML);
        connection.setDoInput(true);

        return connection;
    }

    /** Reads response body from HTTP connection */
    private String readResponse(HttpURLConnection connection) throws IOException {
        StringBuilder response = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
                response.append(System.lineSeparator());
            }
        }

        return response.toString().trim();
    }
}

