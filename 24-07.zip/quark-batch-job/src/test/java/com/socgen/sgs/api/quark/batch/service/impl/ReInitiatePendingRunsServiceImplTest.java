package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.business.RunResetAndInitiateBusiness;
import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReInitiatePendingRunsServiceImplTest {

    @Mock
    private RunResetAndInitiateBusiness runResetAndInitiateBusiness;
    @Mock
    private RabbitMqProducer rabbitMqProducer;
    @InjectMocks
    private ReInitiatePendingRunsServiceImpl service;

    @Test
    void reInitiatePendingRuns_withRuns_sendsToRabbitMq() {
        when(runResetAndInitiateBusiness.getRunsToBeInitiated()).thenReturn(Arrays.asList(new RunDomain(10), new RunDomain(20)));
        List<RunIdDto> result = service.reInitiatePendingRuns();
        assertThat(result).hasSize(2);
        verify(runResetAndInitiateBusiness).resetRunsStatus();
        verify(rabbitMqProducer).sendRunIds(anyList());
    }

    @Test
    void reInitiatePendingRuns_emptyRuns_noRabbitMqCalls() {
        when(runResetAndInitiateBusiness.getRunsToBeInitiated()).thenReturn(Collections.emptyList());
        List<RunIdDto> result = service.reInitiatePendingRuns();
        assertThat(result).isEmpty();
        verify(runResetAndInitiateBusiness).resetRunsStatus();
        verifyNoInteractions(rabbitMqProducer);
    }

    @Test
    void reInitiatePendingRuns_nullRuns_returnsEmpty() {
        when(runResetAndInitiateBusiness.getRunsToBeInitiated()).thenReturn(null);
        List<RunIdDto> result = service.reInitiatePendingRuns();
        assertThat(result).isEmpty();
    }

    @Test
    void reInitiatePendingRuns_resetThrows_propagatesException() {
        doThrow(new RuntimeException("reset failed")).when(runResetAndInitiateBusiness).resetRunsStatus();
        assertThatThrownBy(() -> service.reInitiatePendingRuns())
                .isInstanceOf(RuntimeException.class).hasMessage("reset failed");
    }
}