package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.business.*;
import com.socgen.sgs.api.quark.batch.domain.DocumentIdentity;
import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.CreateRunUploadResultDTO;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.service.DocumentPoolService;
import com.socgen.sgs.api.quark.batch.service.QuarkXPressServerXmlService;
import com.socgen.sgs.api.quark.batch.service.S3UploadService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CheckUploadsServiceImplTest {

    @Mock private NewUploadsBusiness newUploadsBusiness;
    @Mock private UploadDocumentBusiness uploadDocumentBusiness;
    @Mock private S3UploadService s3UploadService;
    @Mock private QuarkXPressServerXmlService quarkXPressServerXmlService;
    @Mock private DocumentPoolService qxpsDocumentPoolService;
    @Mock private CreateRunUploadBusiness createRunUploadBusiness;
    @Mock private RabbitMqProducer rabbitMqProducer;
    @Mock private UploadErrorBusiness uploadErrorBusiness;
    @InjectMocks private CheckUploadsServiceImpl service;

    /** A fully-populated identity that satisfies isDefined() (idSuivi = 200). */
    private DocumentIdentity definedIdentity() {
        return DocumentIdentity.builder()
                .idFndCode("101").idSuivi("200").idRun("300").idLangue("1")
                .dueDate(LocalDateTime.of(2024, 12, 1, 0, 0, 0))
                .generationDateTime(LocalDateTime.of(2025, 6, 25, 6, 31, 36))
                .idUnitCode("101223")
                .build();
    }

    @Test
    void checkUploads_noNewUploads_returnsEmpty() {
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(Collections.emptyList());
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).isEmpty();
    }

    @Test
    void checkUploads_blobLoadReturnsNull_skipsUpload() {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(null);
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).isEmpty();
        verifyNoInteractions(qxpsDocumentPoolService, createRunUploadBusiness, rabbitMqProducer);
    }

    @Test
    void checkUploads_successfulFlow_returnsRunIds() throws Exception {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        UploadDocumentDomain withContent = new UploadDocumentDomain(100, new byte[]{1, 2, 3});
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(withContent);
        when(s3UploadService.uploadDocument(eq(100), any())).thenReturn("s3key");
        when(qxpsDocumentPoolService.fetchXmlForBox(eq("UP_100.qxp"), eq("DID"))).thenReturn("<xml>content</xml>");
        when(quarkXPressServerXmlService.getElementValueByIdName(anyString(), eq("DID"))).thenReturn("101|200|300|1|12/01/2024 00:00:00|06/25/2025 06:31:36|101223");
        when(quarkXPressServerXmlService.parseDocumentIdentity(anyString())).thenReturn(definedIdentity());
        when(createRunUploadBusiness.createRunUpload(200, 100)).thenReturn(new CreateRunUploadResultDTO(500));
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getRunId()).isEqualTo(500);
        verify(rabbitMqProducer).sendRunId(500);
    }

    @Test
    void checkUploads_emptyXmlResponse_addsError() throws Exception {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        UploadDocumentDomain withContent = new UploadDocumentDomain(100, new byte[]{1});
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(withContent);
        when(s3UploadService.uploadDocument(eq(100), any())).thenReturn("key");
        when(qxpsDocumentPoolService.fetchXmlForBox(anyString(), eq("DID"))).thenReturn("");
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).isEmpty();
        verify(uploadErrorBusiness).updateUploadsWithErrors(anyList());
    }

    @Test
    void checkUploads_didNotFoundInXml_addsError() throws Exception {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        UploadDocumentDomain withContent = new UploadDocumentDomain(100, new byte[]{1});
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(withContent);
        when(s3UploadService.uploadDocument(eq(100), any())).thenReturn("key");
        when(qxpsDocumentPoolService.fetchXmlForBox(anyString(), eq("DID"))).thenReturn("<xml/>");
        when(quarkXPressServerXmlService.getElementValueByIdName(anyString(), eq("DID"))).thenReturn(null);
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).isEmpty();
        verify(uploadErrorBusiness).updateUploadsWithErrors(anyList());
    }

    @Test
    void checkUploads_invalidDidFields_addsError() throws Exception {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        UploadDocumentDomain withContent = new UploadDocumentDomain(100, new byte[]{1});
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(withContent);
        when(s3UploadService.uploadDocument(eq(100), any())).thenReturn("key");
        when(qxpsDocumentPoolService.fetchXmlForBox(anyString(), eq("DID"))).thenReturn("<xml/>");
        when(quarkXPressServerXmlService.getElementValueByIdName(anyString(), eq("DID"))).thenReturn("val");
        // Missing dates and other fields -> not defined -> rejected before createRunUpload
        when(quarkXPressServerXmlService.parseDocumentIdentity(anyString()))
                .thenReturn(DocumentIdentity.builder().idSuivi("200").build());
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).isEmpty();
        verify(uploadErrorBusiness).updateUploadsWithErrors(anyList());
        verifyNoInteractions(createRunUploadBusiness);
    }

    @Test
    void checkUploads_runInExecution_addsError() throws Exception {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        UploadDocumentDomain withContent = new UploadDocumentDomain(100, new byte[]{1});
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(withContent);
        when(s3UploadService.uploadDocument(eq(100), any())).thenReturn("key");
        when(qxpsDocumentPoolService.fetchXmlForBox(anyString(), eq("DID"))).thenReturn("<xml/>");
        when(quarkXPressServerXmlService.getElementValueByIdName(anyString(), eq("DID"))).thenReturn("val");
        when(quarkXPressServerXmlService.parseDocumentIdentity(anyString())).thenReturn(definedIdentity());
        when(createRunUploadBusiness.createRunUpload(200, 100)).thenReturn(new CreateRunUploadResultDTO(-1));
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).isEmpty();
        verify(uploadErrorBusiness).updateUploadsWithErrors(anyList());
    }

    @Test
    void checkUploads_suiviLocked_addsError() throws Exception {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        UploadDocumentDomain withContent = new UploadDocumentDomain(100, new byte[]{1});
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(withContent);
        when(s3UploadService.uploadDocument(eq(100), any())).thenReturn("key");
        when(qxpsDocumentPoolService.fetchXmlForBox(anyString(), eq("DID"))).thenReturn("<xml/>");
        when(quarkXPressServerXmlService.getElementValueByIdName(anyString(), eq("DID"))).thenReturn("val");
        when(quarkXPressServerXmlService.parseDocumentIdentity(anyString())).thenReturn(definedIdentity());
        when(createRunUploadBusiness.createRunUpload(200, 100)).thenReturn(new CreateRunUploadResultDTO(-2));
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).isEmpty();
    }

    @Test
    void checkUploads_exceptionDuringProcessing_addsError() throws Exception {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        UploadDocumentDomain withContent = new UploadDocumentDomain(100, new byte[]{1});
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(withContent);
        when(s3UploadService.uploadDocument(eq(100), any())).thenReturn("key");
        // A failure in the critical QXPS step fails the upload.
        doThrow(new RuntimeException("qxps fail")).when(qxpsDocumentPoolService).addFileToPool(anyString(), any());
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).isEmpty();
        verify(uploadErrorBusiness).updateUploadsWithErrors(anyList());
    }

    @Test
    void checkUploads_rabbitMqFailsForRun_doesNotThrow() throws Exception {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        UploadDocumentDomain withContent = new UploadDocumentDomain(100, new byte[]{1});
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(withContent);
        when(s3UploadService.uploadDocument(eq(100), any())).thenReturn("key");
        when(qxpsDocumentPoolService.fetchXmlForBox(anyString(), eq("DID"))).thenReturn("<xml/>");
        when(quarkXPressServerXmlService.getElementValueByIdName(anyString(), eq("DID"))).thenReturn("val");
        when(quarkXPressServerXmlService.parseDocumentIdentity(anyString())).thenReturn(definedIdentity());
        when(createRunUploadBusiness.createRunUpload(200, 100)).thenReturn(new CreateRunUploadResultDTO(500));
        doThrow(new RuntimeException("mq fail")).when(rabbitMqProducer).sendRunId(500);
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).hasSize(1);
    }

    @Test
    void checkUploads_errorUpdateFails_doesNotThrow() throws Exception {
        UploadDocumentDomain upload = new UploadDocumentDomain(100, null);
        when(newUploadsBusiness.getNewUploadDocuments()).thenReturn(List.of(upload));
        UploadDocumentDomain withContent = new UploadDocumentDomain(100, new byte[]{1});
        when(uploadDocumentBusiness.getUploadDocument(any())).thenReturn(withContent);
        when(s3UploadService.uploadDocument(eq(100), any())).thenReturn("key");
        doThrow(new RuntimeException("qxps fail")).when(qxpsDocumentPoolService).addFileToPool(anyString(), any());
        when(uploadErrorBusiness.updateUploadsWithErrors(anyList())).thenThrow(new RuntimeException("db error"));
        List<RunIdDto> result = service.checkUploads();
        assertThat(result).isEmpty();
    }
}