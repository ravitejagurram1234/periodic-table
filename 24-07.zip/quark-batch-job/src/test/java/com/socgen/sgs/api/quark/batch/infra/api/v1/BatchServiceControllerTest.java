package com.socgen.sgs.api.quark.batch.infra.api.v1;

import com.socgen.sgs.api.quark.batch.business.UpdateRunsStatusBusiness;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.service.CheckUploadsService;
import com.socgen.sgs.api.quark.batch.service.ProcessPlannedRunsService;
import com.socgen.sgs.api.quark.batch.service.ReInitiatePendingRunsService;
import com.socgen.sgs.api.quark.batch.service.impl.RabbitMqProducer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BatchServiceControllerTest {

    @Mock private CheckUploadsService checkUploadsService;
    @Mock private ProcessPlannedRunsService processPlannedRunsService;
    @Mock private ReInitiatePendingRunsService reInitiatePendingRunsService;
    @Mock private UpdateRunsStatusBusiness updateRunsStatusBusiness;
    @Mock private RabbitMqProducer rabbitMqProducer;
    @InjectMocks private BatchServiceController controller;

    @Test
    void getNewUploads_returnsOk() {
        when(checkUploadsService.checkUploads()).thenReturn(List.of(new RunIdDto(1)));
        ResponseEntity<List<RunIdDto>> response = controller.getNewUploads();
        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).hasSize(1);
    }

    @Test
    void fetchPlannedRuns_returnsOk() {
        when(processPlannedRunsService.processPlannedRuns()).thenReturn(List.of(new RunIdDto(2)));
        ResponseEntity<List<RunIdDto>> response = controller.fetchPlannedRuns();
        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).hasSize(1);
    }

    @Test
    void reInitiatePendingRuns_returnsOk() {
        when(reInitiatePendingRunsService.reInitiatePendingRuns()).thenReturn(List.of());
        ResponseEntity<List<RunIdDto>> response = controller.reInitiatePendingRuns();
        assertThat(response.getStatusCode().value()).isEqualTo(200);
    }

    @Test
    void executeRuns_success() {
        ResponseEntity<String> response = controller.executeRuns(List.of(1, 2));
        verify(updateRunsStatusBusiness).updateRunsStatus(anyList());
        verify(checkUploadsService).checkUploads();
        verify(rabbitMqProducer).sendRunIds(anyList());
        assertThat(response.getBody()).contains("2 run IDs");
        assertThat(response.getStatusCode().value()).isEqualTo(200);
    }

    @Test
    void executeRuns_checkUploadsFails_stillQueuesRuns() {
        doThrow(new RuntimeException("upload check boom")).when(checkUploadsService).checkUploads();
        ResponseEntity<String> response = controller.executeRuns(List.of(1, 2));
        assertThat(response.getStatusCode().value()).isEqualTo(200);
        verify(updateRunsStatusBusiness).updateRunsStatus(anyList());
        verify(rabbitMqProducer).sendRunIds(anyList());
    }
}