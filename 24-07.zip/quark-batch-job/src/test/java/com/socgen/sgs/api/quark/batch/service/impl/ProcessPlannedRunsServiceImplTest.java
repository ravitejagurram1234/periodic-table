package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.business.PlannedRunsBusiness;
import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProcessPlannedRunsServiceImplTest {

    @Mock
    private PlannedRunsBusiness plannedRunsBusiness;

    @Mock
    private RabbitMqProducer rabbitMqProducer;

    @InjectMocks
    private ProcessPlannedRunsServiceImpl service;

    @Test
    void processPlannedRuns_withRuns_sendsToRabbitMq() {
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(Arrays.asList(new RunDomain(1), new RunDomain(2)));

        List<RunIdDto> result = service.processPlannedRuns();

        assertThat(result).hasSize(2);
        verify(rabbitMqProducer).sendRunIds(anyList());
    }

    @Test
    void processPlannedRuns_emptyList_returnsEmpty() {
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(Collections.emptyList());

        List<RunIdDto> result = service.processPlannedRuns();

        assertThat(result).isEmpty();
        verifyNoInteractions(rabbitMqProducer);
    }

    @Test
    void processPlannedRuns_nullList_returnsEmpty() {
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(null);

        List<RunIdDto> result = service.processPlannedRuns();

        assertThat(result).isEmpty();
        verifyNoInteractions(rabbitMqProducer);
    }

    @Test
    void processPlannedRuns_nullRunDomainInList_filtersOut() {
        List<RunDomain> runs = Arrays.asList(new RunDomain(1), null, new RunDomain(null));
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(runs);

        List<RunIdDto> result = service.processPlannedRuns();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getRunId()).isEqualTo(1);
    }
}