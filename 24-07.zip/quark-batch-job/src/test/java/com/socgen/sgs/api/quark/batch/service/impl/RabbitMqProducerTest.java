package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.config.RabbitMqConfig;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpIOException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RabbitMqProducerTest {

    @Mock
    private RabbitTemplate rabbitTemplate;

    @InjectMocks
    private RabbitMqProducer rabbitMqProducer;

    @BeforeEach
    void setQueueName() {
        // BATCH_RUN_QUEUE has private access; set it via the public setter (it writes the static field).
        new RabbitMqConfig().setBatchRunQueue("test-queue");
    }

    @Test
    void sendRunId_sendsToCorrectQueue() throws Exception {
        rabbitMqProducer.sendRunId(42);
        verify(rabbitTemplate).convertAndSend("", "test-queue", 42);
    }

    @Test
    void sendRunIds_whenOneRunFails_continuesWithoutThrowing() {
        doThrow(new AmqpIOException(new IOException("boom")))
                .when(rabbitTemplate).convertAndSend("", "test-queue", 1);
        assertDoesNotThrow(() ->
                rabbitMqProducer.sendRunIds(List.of(new RunIdDto(1), new RunIdDto(2))));
        verify(rabbitTemplate).convertAndSend("", "test-queue", 2);
    }

    @Test
    void sendRunIds_emptyList_doesNothing() {
        rabbitMqProducer.sendRunIds(List.of());
        verifyNoInteractions(rabbitTemplate);
    }
}