package com.socgen.sgs.api.quark.batch.scheduler;

import com.socgen.sgs.api.quark.batch.service.ProcessPlannedRunsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProcessPlannedRunsSchedulerTest {

    @Mock private ProcessPlannedRunsService processPlannedRunsService;
    @InjectMocks private ProcessPlannedRunsScheduler scheduler;

    @Test
    void processPlannedRuns_callsService() {
        when(processPlannedRunsService.processPlannedRuns()).thenReturn(List.of());
        scheduler.processPlannedRuns();
        verify(processPlannedRunsService).processPlannedRuns();
    }

    @Test
    void processPlannedRuns_exceptionHandled() {
        when(processPlannedRunsService.processPlannedRuns()).thenThrow(new RuntimeException("err"));
        scheduler.processPlannedRuns();
    }
}