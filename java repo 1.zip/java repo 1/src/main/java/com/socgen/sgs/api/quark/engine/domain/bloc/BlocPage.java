package com.socgen.sgs.api.quark.engine.domain.bloc;

import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import lombok.Getter;
import lombok.Setter;

/** Represents a page bloc for page creation/deletion in a QuarkXPress document. */
@Getter
@Setter
public class BlocPage extends BlocBase {

    private boolean createNextDummyPage = false;

    public BlocPage(TaskBase task, String name) {
        super(task, name);
        this.setPagination(true);
    }

    /** Page position relative to the spine (LEFTOFSPINE or empty). */
    public String getPosition() {
        RunProperties props = getTask().getRun().getRunProperties();
        if (props.getNbPageBySpread() != RunProperties.PAGINATION_SIMPLE
                && getPageId() != 1
                && getIndexPosition() == 0) {
            return "LEFTOFSPINE";
        }
        return "";
    }

    /** Index of the page position within its spread. */
    public int getIndexPosition() {
        RunProperties props = getTask().getRun().getRunProperties();
        if (getPageId() == 1) {
            return 0;
        }
        if (isLagSpread()) {
            return (getPageId() + 1) % props.getNbPageBySpread();
        }
        return getPageId() % props.getNbPageBySpread();
    }

    @Override
    public int getNbBox() {
        if (getAction() == BlocActionEnum.REMOVE) {
            // When removing a page, count the boxes on that page from gabarit XML
            // Cross-reference: .NET Bloc_Page.Nb_Box — uses Gabarit.XML.Project_Info.GetNbBoxOnPage()
            try {
                return getTask().getRun().getGabarit()
                        .getQxpXml().getProjectInfo().getNbBoxOnPage(getPageId());
            } catch (Exception e) {
                // Fallback if gabarit XML is not available
                return super.getNbBox();
            }
        }
        return super.getNbBox();
    }
}

