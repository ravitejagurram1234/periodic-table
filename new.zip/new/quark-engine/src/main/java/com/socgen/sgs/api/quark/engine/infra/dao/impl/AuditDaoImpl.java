package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.infra.dao.AuditDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.Duration;

/**
 * Calls QXP_PK_AUDIT.InsertAuditRun (PROCEDURE, 8 IN params).
 * Cross-reference: .NET Proxy_Audit.InsertAuditRun.
 */
@Repository
@Slf4j
public class AuditDaoImpl implements AuditDao {

    /** p_message is VARCHAR2 — keep within Oracle's standard VARCHAR2 limit. */
    private static final int MAX_MESSAGE_SIZE = 4000;

    private final SimpleJdbcCall insertAuditRunCall;

    @Autowired
    public AuditDaoImpl(DataSource dataSource) {
        this.insertAuditRunCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_AUDIT")
                .withProcedureName("InsertAuditRun")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_id_run", Types.NUMERIC),
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_run_type", Types.VARCHAR),
                        new SqlParameter("p_start_date", Types.TIMESTAMP),
                        new SqlParameter("p_end_date", Types.TIMESTAMP),
                        new SqlParameter("p_duration", Types.NUMERIC),
                        new SqlParameter("p_end_status", Types.VARCHAR),
                        new SqlParameter("p_message", Types.VARCHAR)
                );
    }

    @Override
    public void insertAuditRun(Run run, String message) {
        // Duration in seconds between start and end (.NET audit.Duration).
        long durationSeconds = 0L;
        if (run.getStartDate() != null && run.getEndDate() != null) {
            durationSeconds = Duration.between(run.getStartDate(), run.getEndDate()).getSeconds();
        }

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_run", run.getId())
                .addValue("p_id_suivi", run.getRunProperties() != null ? run.getRunProperties().getIdSuivi() : null)
                .addValue("p_run_type", run.getRunProperties() != null ? run.getRunProperties().getRunType() : null)
                .addValue("p_start_date", run.getStartDate() != null ? Timestamp.valueOf(run.getStartDate()) : null)
                .addValue("p_end_date", run.getEndDate() != null ? Timestamp.valueOf(run.getEndDate()) : null)
                .addValue("p_duration", durationSeconds)
                .addValue("p_end_status", run.getStatus() != null ? run.getStatus().name() : null)
                .addValue("p_message", truncate(message, MAX_MESSAGE_SIZE));

        try {
            insertAuditRunCall.execute(params);
            log.info("Audit row inserted for run [{}]", run.getId());
        } catch (Exception e) {
            log.error("Failed to insert audit row for run [{}]: {}", run.getId(), e.getMessage(), e);
            throw new RuntimeException("Failed to insert audit row for run: " + run.getId(), e);
        }
    }

    private static String truncate(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        return value.length() > maxLength ? value.substring(0, maxLength) : value;
    }
}