package com.socgen.sgs.api.quark.engine.domain.project;

import com.socgen.sgs.api.quark.engine.domain.element.TBox;
import com.socgen.sgs.api.quark.engine.domain.element.TElement;
import com.socgen.sgs.api.quark.engine.domain.element.TGroup;
import com.socgen.sgs.api.quark.engine.domain.RunError;
import com.socgen.sgs.api.quark.engine.domain.element.TTable;
import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Group;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Project;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Table;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents an advanced structure of a QuarkXPress project.
 * Analyses the SOAP Project object model to build a dictionary of named elements
 * (TBox, TTable, TGroup) that can be looked up by name.
 *
 * <p>The {@link #analyse(TaskBase, boolean)} method iterates through all
 * layouts → spreads → boxes/tables/groups and populates the elements dictionary.
 * This dictionary is then used by tasks (e.g., QXP_Data STYLE mode) to find
 * and clone source elements.
 *
 * <p>Usage:
 * <pre>
 *   QxpProject project = new QxpProject(soapProject);
 *   project.analyse(task, false);
 *   TElement element = project.getElements().get("MY_BOX_NAME");
 * </pre>
 *
 * Cross-reference: QXP.Engine.Core.QXP_Project
 */
@Getter
@Slf4j
public class QxpProject {

    /** The underlying SOAP project structure. */
    private final Project project;

    /** Named elements dictionary, populated by {@link #analyse(TaskBase, boolean)}. */
    private Map<String, TElement> elements;

    /** Whether the project has already been analysed. */
    private boolean analysed = false;

    /** Empty QxpProject singleton (non-null but contains no elements). */
    public static final QxpProject EMPTY = new QxpProject(new Project());

    /**
     * Create a QxpProject from a SOAP Project.
     *
     * @param project the SOAP-generated Project
     */
    public QxpProject(Project project) {
        this.project = project;
    }

    /**
     * Analyse the project structure to build the elements dictionary.
     * Iterates through all layouts → spreads → boxes/tables/groups,
     * creating TBox/TTable/TGroup instances and adding them to the elements map.
     *
     * <p>This method is idempotent — calling it multiple times has no effect
     * after the first successful analysis.
     *
     * @param task     a reference to the calling task (for error logging to run)
     * @param logError if true, structural errors are logged to the run's error list;
     *                 if false, errors are silently ignored
     */
    public void analyse(TaskBase task, boolean logError) {
        // Don't re-analyse if already done
        if (analysed) {
            return;
        }

        elements = new LinkedHashMap<>();
        List<TGroup> pendingGroups = new ArrayList<>();

        if (project.getLayouts() == null) {
            analysed = true;
            return;
        }

        for (Layout layout : project.getLayouts()) {
            if (layout == null || layout.getSpreads() == null) {
                continue;
            }

            for (Spread spread : layout.getSpreads()) {
                if (spread == null) {
                    continue;
                }

                // Process boxes
                processBoxes(spread);

                // Process tables
                processTables(spread);

                // Process groups (collect first, evaluate after all elements are registered)
                processGroups(spread, pendingGroups);
            }
        }

        // Evaluate all groups after all boxes/tables are in the elements map.
        // Groups reference boxes by name via boxRefs, so boxes must be registered first.
        evaluatePendingGroups(pendingGroups, task, logError);

        analysed = true;
    }

    /**
     * Process all boxes in a spread.
     * Creates TBox instances and adds them to the elements dictionary.
     */
    private void processBoxes(Spread spread) {
        if (spread.getBoxes() == null) {
            return;
        }

        for (Box box : spread.getBoxes()) {
            if (box == null) {
                continue;
            }

            TBox tBox = new TBox(box);

            // Some documents have duplicate box names (legacy QXP Server 7 bug)
            if (!elements.containsKey(tBox.getName())) {
                elements.put(tBox.getName(), tBox);
                tBox.evaluate(this);
            } else {
                log.debug("Duplicate box name [{}] — skipping", tBox.getName());
            }
        }
    }

    /**
     * Process all tables in a spread.
     * Creates TTable instances and adds them to the elements dictionary.
     */
    private void processTables(Spread spread) {
        if (spread.getTables() == null) {
            return;
        }

        for (Table table : spread.getTables()) {
            // QXP Server v9 bug: there's always a null table even when none exist
            if (table == null) {
                continue;
            }

            TTable tTable = new TTable(table);

            if (!elements.containsKey(tTable.getName())) {
                elements.put(tTable.getName(), tTable);
                tTable.evaluate(this);
            } else {
                log.debug("Duplicate table name [{}] — skipping", tTable.getName());
            }
        }
    }

    /**
     * Process all groups in a spread.
     * Creates TGroup instances, adds them to the elements dictionary,
     * and collects them for deferred evaluation.
     *
     * <p>Groups are evaluated after all boxes and tables are registered
     * because groups reference child elements via boxRefs.
     */
    private void processGroups(Spread spread, List<TGroup> pendingGroups) {
        if (spread.getGroups() == null) {
            return;
        }

        for (Group group : spread.getGroups()) {
            // QXP Server v9 bug: there's always a null group even when none exist
            if (group == null) {
                continue;
            }

            TGroup tGroup = new TGroup(group);

            if (!elements.containsKey(tGroup.getName())) {
                elements.put(tGroup.getName(), tGroup);
                pendingGroups.add(tGroup);
            } else {
                log.debug("Duplicate group name [{}] — skipping", tGroup.getName());
            }
        }
    }

    /**
     * Evaluate all pending groups.
     * Called after all boxes/tables/groups are registered in the elements map.
     *
     * @param pendingGroups the groups to evaluate
     * @param task          the calling task (for error logging)
     * @param logError      whether to log structural errors to the run
     */
    private void evaluatePendingGroups(List<TGroup> pendingGroups, TaskBase task, boolean logError) {
        for (TGroup tGroup : pendingGroups) {
            try {
                tGroup.evaluate(this);
            } catch (Exception e) {
                if (logError && task != null) {
                    log.error("Error evaluating TGroup [{}]: {}", tGroup.getName(), e.getMessage());
                    // Cross-reference: .NET QXP_Project — task.Run.Errors.Add(tex.ToString()). (2 = Critique)
                    task.getRun().getErrors().add(new RunError(2,
                            "Erreur evaluation du groupe [" + tGroup.getName() + "] : " + e.getMessage()));
                } else {
                    log.debug("Error evaluating TGroup [{}]: {}", tGroup.getName(), e.getMessage());
                }
            }
        }
    }
}