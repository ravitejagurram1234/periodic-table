package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeTachesByGabarit;

import java.util.List;

public interface TDBGetListeTachesByGabaritDAO {

    List<TDBGetListeTachesByGabarit>
    getListeTachesByGabarit(
            Long p_idGabarit
    );
}
