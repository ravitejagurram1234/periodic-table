package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.FeatureExceptions.ResourceNotFoundException;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.AmundiFilenameMatch;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.DocumentFormat;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.ReportDownload;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.ReportNamingContext;
import com.socgen.sgs.api.quark.backend.api.infra.dao.DocumentDownloadDao;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DocumentDownloadBusiness {

    private final DocumentDownloadDao documentDownloadDao;
    private final ReportFilenameBusiness reportFilenameBusiness;

    @Transactional
    public ReportDownload download(long idSuivi, String requestedFormat) {
        DocumentFormat format = DocumentFormat.fromPath(requestedFormat);
        ReportNamingContext context = documentDownloadDao.findNamingContext(idSuivi)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No suivi exists for idSuivi=" + idSuivi));

        List<AmundiFilenameMatch> matches = List.of();
        if (reportFilenameBusiness.isAmundiCandidate(context)) {
            matches = documentDownloadDao.findAmundiMatches(
                    context, reportFilenameBusiness.perimeterReportType(context));
        }

        byte[] content = documentDownloadDao.findContent(idSuivi, format)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No " + format.extension() + " document exists for idSuivi=" + idSuivi));
        String filename = reportFilenameBusiness.buildFilename(context, matches, format);

        documentDownloadDao.markVisited(idSuivi, format);
        return new ReportDownload(content, filename, format.mediaType());
    }
}