package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Devise;
import com.socgen.sgs.api.quark.backend.api.infra.dao.DeviseDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DeviseBusiness {

    private final DeviseDao deviseDao;

    public DeviseBusiness(DeviseDao deviseDao) {
        this.deviseDao = deviseDao;
    }

    public List<Devise> getListeDevises() {
        return deviseDao.getListeDevises();
    }
}