package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TDBGetListeTachesByGabarit {

    private Long idTache;
    private String commentaire;
    private Long idStatutSuiviDebut;
    private Long idStatutSuiviFin;
    private Long idTypeTache;

    private TDBGetListeTachesByGabarit(Builder builder) {
        this.idTache = builder.idTache;
        this.commentaire = builder.commentaire;
        this.idStatutSuiviDebut = builder.idStatutSuiviDebut;
        this.idStatutSuiviFin = builder.idStatutSuiviFin;
        this.idTypeTache = builder.idTypeTache;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {

        private Long idTache;
        private String commentaire;
        private Long idStatutSuiviDebut;
        private Long idStatutSuiviFin;
        private Long idTypeTache;

        public Builder idTache(Long idTache) {
            this.idTache = idTache;
            return this;
        }

        public Builder commentaire(String commentaire) {
            this.commentaire = commentaire;
            return this;
        }

        public Builder idStatutSuiviDebut(Long idStatutSuiviDebut) {
            this.idStatutSuiviDebut = idStatutSuiviDebut;
            return this;
        }

        public Builder idStatutSuiviFin(Long idStatutSuiviFin) {
            this.idStatutSuiviFin = idStatutSuiviFin;
            return this;
        }

        public Builder idTypeTache(Long idTypeTache) {
            this.idTypeTache = idTypeTache;
            return this;
        }

        public TDBGetListeTachesByGabarit build() {
            return new TDBGetListeTachesByGabarit(this);
        }
    }
}