package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiDateFormat;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportMode;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportRowError;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportTemplateConfiguration;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportValidationResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiPerimeterRecord;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.CsvParseResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.ParsedAmundiRow;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.UploadedFile;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.FeatureExceptions.ImportRejectedException;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AmundiPerimeterDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditInsertTraceDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.EXPECTED_HEADERS;
import static com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.TEMPLATE_NAME;

@Slf4j
@Component
@RequiredArgsConstructor
public class AmundiPerimeterImportBusiness {

    private final AmundiCsvParser csvParser;
    private final AmundiPerimeterDao amundiPerimeterDao;
    private final AuditInsertTraceDao auditInsertTraceDao;

    public AmundiImportTemplateConfiguration configuration() {
        return new AmundiImportTemplateConfiguration(
                TEMPLATE_NAME,
                ".csv",
                "UTF-8 with optional BOM",
                ",",
                true,
                EXPECTED_HEADERS,
                List.of(AmundiDateFormat.values()),
                AmundiDateFormat.DD_MM_YYYY,
                List.of(AmundiImportMode.DELETE, AmundiImportMode.DELETE_AND_INSERT, AmundiImportMode.UPDATE),
                AmundiImportMode.DELETE_AND_INSERT,
                false,
                false);
    }

    @Transactional
    public AmundiImportValidationResult validate(
            UploadedFile file,
            AmundiDateFormat dateFormat,
            String userEmail,
            String clientIp) {

        long startedAt = System.nanoTime();
        try {
            CsvParseResult parsed = parseAndValidateFunds(file, dateFormat);
            AmundiImportValidationResult result = toValidation(file, parsed);
            writeAudit("ValidateAmundiPerimeter", file, result, null, userEmail, clientIp,
                    startedAt, 0, "Validation completed");
            return result;
        } catch (RuntimeException exception) {
            writeFailureAudit("ValidateAmundiPerimeter", file, null, userEmail, clientIp,
                    startedAt, exception);
            throw exception;
        }
    }

    @Transactional
    public AmundiImportResult importFile(
            UploadedFile file,
            AmundiDateFormat dateFormat,
            AmundiImportMode mode,
            String expectedChecksum,
            String userEmail,
            String clientIp) {

        long startedAt = System.nanoTime();
        try {
            CsvParseResult parsed = parseAndValidateFunds(file, dateFormat);
            AmundiImportValidationResult validation = toValidation(file, parsed);

            if (expectedChecksum == null
                    || !parsed.checksumSha256().equalsIgnoreCase(expectedChecksum.trim())) {
                throw new ImportRejectedException(
                        "The uploaded file is not the same file that was validated (SHA-256 mismatch)");
            }
            if (parsed.validRows().isEmpty()) {
                throw new ImportRejectedException("There are no valid rows to import");
            }

            List<AmundiPerimeterRecord> rows = parsed.validRows().stream()
                    .map(ParsedAmundiRow::value)
                    .toList();

            int deleted = 0;
            int inserted = 0;
            int updated = 0;

            switch (mode) {
                case DELETE -> deleted = amundiPerimeterDao.deleteMatching(rows);
                case DELETE_AND_INSERT -> {
                    deleted = amundiPerimeterDao.deleteMatching(rows);
                    inserted = amundiPerimeterDao.insert(rows);
                }
                case UPDATE -> updated = amundiPerimeterDao.update(rows);
            }

            int primaryAffected = switch (mode) {
                case DELETE -> deleted;
                case DELETE_AND_INSERT -> inserted;
                case UPDATE -> updated;
            };
            int unchanged = Math.max(0, rows.size() - primaryAffected);

            AmundiImportResult result = new AmundiImportResult(
                    validation, mode, deleted, inserted, updated, unchanged);
            writeAudit("ImportAmundiPerimeter", file, validation, mode, userEmail, clientIp,
                    startedAt, 0,
                    "Import completed; deleted=" + deleted + ", inserted=" + inserted
                            + ", updated=" + updated + ", unchanged=" + unchanged);
            return result;
        } catch (RuntimeException exception) {
            writeFailureAudit("ImportAmundiPerimeter", file, mode, userEmail, clientIp,
                    startedAt, exception);
            throw exception;
        }
    }

    private CsvParseResult parseAndValidateFunds(UploadedFile file, AmundiDateFormat dateFormat) {
        Map<String, Integer> lengths = amundiPerimeterDao.findLiveColumnLengths();
        CsvParseResult parsed = csvParser.parse(file, dateFormat, lengths);

        Set<String> requestedCodes = parsed.validRows().stream()
                .map(row -> row.value().fundName())
                .collect(HashSet::new, Set::add, Set::addAll);
        Set<String> existingCodes = amundiPerimeterDao.findExistingFundCodes(requestedCodes);

        List<ParsedAmundiRow> stillValid = new ArrayList<>();
        List<AmundiImportRowError> errors = new ArrayList<>(parsed.errors());
        for (ParsedAmundiRow row : parsed.validRows()) {
            if (existingCodes.contains(row.value().fundName())) {
                stillValid.add(row);
            } else {
                errors.add(new AmundiImportRowError(
                        row.rowNumber(),
                        "Code Comptable",
                        row.value().fundName(),
                        "No active fund exists in OWB_DWH.REF_FUND"));
            }
        }

        return new CsvParseResult(
                parsed.checksumSha256(),
                parsed.totalRows(),
                stillValid,
                errors,
                parsed.duplicateRows());
    }

    private AmundiImportValidationResult toValidation(UploadedFile file, CsvParseResult parsed) {
        int invalidRows = (int) parsed.errors().stream()
                .map(AmundiImportRowError::rowNumber)
                .distinct()
                .count();
        return new AmundiImportValidationResult(
                TEMPLATE_NAME,
                file.originalFilename(),
                parsed.checksumSha256(),
                parsed.totalRows(),
                parsed.validRows().size(),
                invalidRows,
                parsed.duplicateRows(),
                parsed.errors());
    }

    private void writeFailureAudit(
            String function,
            UploadedFile file,
            AmundiImportMode mode,
            String userEmail,
            String clientIp,
            long startedAt,
            RuntimeException exception) {
        AmundiImportValidationResult empty = new AmundiImportValidationResult(
                TEMPLATE_NAME, file.originalFilename(), "unavailable", 0, 0, 0, 0, List.of());
        writeAudit(function, file, empty, mode, userEmail, clientIp, startedAt, 1,
                "Failed: " + abbreviate(exception.getMessage(), 500));
    }

    private void writeAudit(
            String function,
            UploadedFile file,
            AmundiImportValidationResult validation,
            AmundiImportMode mode,
            String userEmail,
            String clientIp,
            long startedAt,
            int status,
            String message) {
        try {
            BigDecimal seconds = BigDecimal.valueOf((System.nanoTime() - startedAt) / 1_000_000_000d)
                    .setScale(3, RoundingMode.HALF_UP);
            Audit audit = new Audit(
                    abbreviate(clientIp, 100),
                    LocalDate.now(),
                    LocalDate.now(),
                    "referential/importer-un-fichier",
                    abbreviate(userEmail, 200),
                    "Referential",
                    function,
                    abbreviate(message, 1000),
                    "template=" + TEMPLATE_NAME,
                    "file=" + abbreviate(file.originalFilename(), 300),
                    "checksum=" + validation.checksumSha256(),
                    "mode=" + (mode == null ? "VALIDATE" : mode),
                    "total=" + validation.totalRows() + ", valid=" + validation.validRows()
                            + ", invalid=" + validation.invalidRows(),
                    seconds,
                    status,
                    0,
                    "QXP");
            auditInsertTraceDao.insertTrace(audit);
        } catch (RuntimeException auditException) {
            log.error("AMUNDI audit failed for function={} user={}", function, userEmail, auditException);
        }
    }

    private String abbreviate(String value, int maximum) {
        String safe = value == null ? "" : value;
        return safe.length() <= maximum ? safe : safe.substring(0, maximum - 3) + "...";
    }
}