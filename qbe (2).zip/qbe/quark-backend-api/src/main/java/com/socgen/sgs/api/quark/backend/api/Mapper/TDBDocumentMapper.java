package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBDocumentDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBDocument;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TDBDocumentMapper {

    public static TDBDocument mapResult(ResultSet rs) throws SQLException {

        TDBDocument documentContent = new TDBDocument();

        documentContent.setContenu(rs.getBytes("CONTENU"));

        return documentContent;
    }

    public static TDBDocumentDTO toDto(TDBDocument documentContent) {


        return new TDBDocumentDTO(documentContent.getContenu());
    }
}