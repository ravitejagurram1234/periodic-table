package com.socgen.sgs.api.quark.backend.api.service.Impl;
import com.socgen.sgs.api.quark.backend.api.Dto.FondsHaveSuiviDto;
import com.socgen.sgs.api.quark.backend.api.Mapper.FondsHaveSuiviMapper;
import com.socgen.sgs.api.quark.backend.api.domain.FondsHaveSuivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FondsHaveSuiviDao;
import com.socgen.sgs.api.quark.backend.api.service.FondsHaveSuiviSerInterface;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FondsHaveSuiviServiceImpl implements FondsHaveSuiviSerInterface {

    private final FondsHaveSuiviDao fondsHaveSuiviDao;

    public FondsHaveSuiviServiceImpl(FondsHaveSuiviDao fondsHaveSuiviDao) {
        this.fondsHaveSuiviDao = fondsHaveSuiviDao;
    }

    @Override
    public List<FondsHaveSuiviDto> getListeFondsHaveSuivi(
            Long idLangue,
            LocalDate dateEcheance,
            Long idTypeRapport) {

        List<FondsHaveSuivi> fondsList =
                fondsHaveSuiviDao.getListeFondsHaveSuivi(
                        idLangue,
                        dateEcheance,
                        idTypeRapport
                );

        return fondsList.stream()
                .map(FondsHaveSuiviMapper::toDto)
                .collect(Collectors.toList());
    }
}