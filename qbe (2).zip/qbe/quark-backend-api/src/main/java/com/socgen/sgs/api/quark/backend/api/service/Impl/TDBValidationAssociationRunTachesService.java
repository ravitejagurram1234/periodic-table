package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.TDBValidationAssociationRunTachesRequestDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviAuditDao;
import com.socgen.sgs.api.quark.backend.api.domain.*;
import com.socgen.sgs.api.quark.backend.api.service.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TDBValidationAssociationRunTachesService implements TDBValidationAssociationRunTachesSerInterface {

    private final TDBCheckIfRunsEnCoursSerInterface tdbCheckIfRunsEnCoursSerInterface;

    private final TDBInsertRunSerInterface tdbInsertRunSerInterface;

    private final IAuthenticationService authenticationService;
    
    private final TDBInsertRunTachesSerInterface tdbInsertRunTachesSerInterface;
    
    private final TDBGetListeSuivisCompartBySuiviSerInterface tdbGetListeSuivisCompartBySuiviSerInterface;
    
    private final TDBGetListeEventsByGabaritSerInterface tdbGetListeEventsByGabaritSerInterface;

    private final SuiviAuditDao suiviAuditDao;
    
    private final TDBGetListeTachesByGabaritSerInterface tdbGetListeTachesByGabaritSerInterface;
    
    private final InsertSuiviSerInterface  insertSuiviSerInterface;
    

    public TDBValidationAssociationRunTachesService(
            TDBCheckIfRunsEnCoursSerInterface tdbCheckIfRunsEnCoursSerInterface,
            TDBInsertRunSerInterface tdbInsertRunSerInterface,
            TDBInsertRunTachesSerInterface tdbInsertRunTachesSerInterface,
            TDBGetListeSuivisCompartBySuiviSerInterface tdbGetListeSuivisCompartBySuiviSerInterface,
            TDBGetListeEventsByGabaritSerInterface tdbGetListeEventsByGabaritSerInterface,
            SuiviAuditDao suiviAuditDao,
            TDBGetListeTachesByGabaritSerInterface tdbGetListeTachesByGabaritSerInterface,
            InsertSuiviSerInterface insertSuiviSerInterface,
            IAuthenticationService authenticationService
    ) {

        this.tdbCheckIfRunsEnCoursSerInterface = tdbCheckIfRunsEnCoursSerInterface;
        this.tdbInsertRunSerInterface = tdbInsertRunSerInterface;
        this.authenticationService = authenticationService;
        this.tdbInsertRunTachesSerInterface = tdbInsertRunTachesSerInterface;
        this.tdbGetListeSuivisCompartBySuiviSerInterface = tdbGetListeSuivisCompartBySuiviSerInterface;
        this.tdbGetListeEventsByGabaritSerInterface = tdbGetListeEventsByGabaritSerInterface;
        this.tdbGetListeTachesByGabaritSerInterface = tdbGetListeTachesByGabaritSerInterface;
        this.insertSuiviSerInterface = insertSuiviSerInterface;
        this.suiviAuditDao = suiviAuditDao;

    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String validationAssociationRunTaches(TDBValidationAssociationRunTachesRequestDTO request, HttpServletRequest req) {

        CheckIfRunsEnCours(request);

        List<Long> runIds = InsertRun(request);

        handleCompartiments(request, req);

        List<String> infos = new ArrayList<>();

        infos.add(String.format("Run(s) : %s", runIds.stream().map(String::valueOf).collect(Collectors.joining(","))));

        infos.add(String.format("Id du gabarit : %s", request.getIdGabarit()));

        Optional<String> useremail = authenticationService.getCurrentUserEmailId();

        String listeIdRunsFormatee = runIds.stream().map(String::valueOf).collect(Collectors.joining(", "));

        if(request.getModeDeclenchment() == 1) {
            //batchservice

        }

        insertCompartimentTrace(
                req,
                useremail.get(),
                String.join("\n", infos),
                "A partir du" + request.getGabaritSource(),
                "Int�gration donn�es N1 : " +(request.getIntegrerN1() == 1 ? "Oui" : "Non"),
                "Mode de d�clenchement demand� : " + (request.getModeDeclenchment() ==1? "Immediate" : "Planifier"),
                "Id Langue: " + (request.getIdLangue()),
                "Runs lanc�s" + (listeIdRunsFormatee.substring(0, Math.min(listeIdRunsFormatee.length(), 470))));

        return "ValidationAssociationRunTaches completed successfully";
    }

    /**
     * STEP 1
     */
    private void CheckIfRunsEnCours(
            TDBValidationAssociationRunTachesRequestDTO request) {

        List<TDBCheckIfRunsEnCours> duplicates =
                tdbCheckIfRunsEnCoursSerInterface
                        .checkIfRunsEnCours(
                                request.getSuiviIds(),
                                request.getUnitCodes(),
                                request.getIdLangue(),
                                request.getIdGabarit(),
                                request.getDateEcheance()
                        );

        if (!duplicates.isEmpty()) {

            String duplicateList =
                    duplicates.stream()
                            .map(item ->
                                    item.getIdFndCode()
                                            + " - "
                                            + item.getIdUnitCode()
                            )
                            .collect(
                                    Collectors.joining(", ")
                            );

            throw new RuntimeException( "The following portfolios/structures already have runs in progress: " + duplicateList);
        }
    }

    /**
     * STEP 5
     */

    private List<Long> InsertRun(
            TDBValidationAssociationRunTachesRequestDTO request) {

        try {

            List<Long> runIds = new ArrayList<>();

            Optional<String> userEmail =
                    authenticationService.getCurrentUserEmailId();

            for (String suiviId : request.getSuiviIds()) {

                Long idRun =
                        tdbInsertRunSerInterface.insertRun(
                                Long.valueOf(suiviId),
                                request.getDatePlanification(),
                                request.getGabaritSource().longValue(),
                                null,
                                userEmail.get(),
                                request.getIntegrerN1().longValue(),
                                request.getModeCompart().longValue(),
                                null
                        );

                tdbInsertRunTachesSerInterface.insertRunTaches(
                        idRun,
                        request.getTaskIds()
                );

                runIds.add(idRun);
            }

            return runIds;

        } catch (Exception ex) {

            throw new RuntimeException(
                    "Erreur lors de la création du (des) run(s) : "
                            + ex.getMessage(),
                    ex
            );
        }
    }
    
//    Step 6

    private void handleCompartiments(TDBValidationAssociationRunTachesRequestDTO request, HttpServletRequest req) {

        List<Long> newSuiviIds = new ArrayList<>();

        List<Long> runIds = new ArrayList<>();

        if (request.getModeCompart() == 1 || request.getModeCompart() == 3) {

            try {

                Optional<String> userEmail = authenticationService.getCurrentUserEmailId();

                for (String selectedSuiviId: request.getSuiviIds()) {

                    for (Long selectedTaskId: request.getTaskIds()) {

                        List<TDBGetListeSuivisCompartBySuivi> suiviComparts = tdbGetListeSuivisCompartBySuiviSerInterface.getListeSuivisCompartBySuivi(Long.valueOf(selectedSuiviId), selectedTaskId);

                        for (TDBGetListeSuivisCompartBySuivi suiviCompart: suiviComparts) {

                            Long effectiveSuiviId = suiviCompart.getIdSuivi();

                            if (effectiveSuiviId == null || effectiveSuiviId == 0) {

                                SuiviDTO suiviDTO = SuiviDTO.builder()
                                        .p_id_type_rapport(4L)
                                        .p_date_echeance(suiviCompart.getDateEcheance())
                                        .p_id_langue(request.getIdLangue())
                                        .p_id_maquettiste(suiviCompart.getIdMaquettiste())
                                        .p_id_gabarit(suiviCompart.getIdGabarit())
                                        .p_id_createur(null)
                                        .p_id_suivi(null)
                                        .p_id(suiviCompart.getIdFndCode())
                                        .p_id_unit_code(null)
                                        .p_date_echeance_exacte(suiviCompart.getDateEcheanceExacte())
                                        .build();

                                Long newSuiviId = insertSuiviSerInterface.insertSuivi(suiviDTO);

                                effectiveSuiviId = newSuiviId;

                                newSuiviIds.add(newSuiviId);
                            }

                            Long idRun = tdbInsertRunSerInterface.insertRun(
                                    effectiveSuiviId,
                                    request.getDatePlanification(),
                                    request.getGabaritSource().longValue(),
                                    null,
                                    userEmail.get(),
                                    request.getIntegrerN1().longValue(),
                                    request.getModeCompart().longValue(),
                                    null
                            );

                            List<TDBGetListeTachesByGabarit> taches = tdbGetListeTachesByGabaritSerInterface.getListeTachesByGabarit(suiviCompart.getIdGabarit());

                            Long[] idTaches = taches.stream().map(TDBGetListeTachesByGabarit::getIdTache).toArray(Long[]::new);

                            tdbInsertRunTachesSerInterface.insertRunTaches(effectiveSuiviId, idTaches);

                            runIds.add(effectiveSuiviId);

                        }
                    }
                }

                insertCompartimentTrace(
                            req,
                            userEmail.get(),
                        String.format("%s : %s", "Suivi(s) compart : ", newSuiviIds.stream().map(String::valueOf).collect(Collectors.joining(","))),
                            null,
                            null,
                            null,
                            null,
                            null);

                insertCompartimentTrace(
                        req,
                        userEmail.get(),
                        String.format("%s : %s", "Run(s) compart : ", runIds.stream().map(String::valueOf).collect(Collectors.joining(","))),
                        null,
                        null,
                        null,
                        null,
                        null);


            } catch (Exception ex) {

                throw new RuntimeException("Erreur lors de l'insertion automatique des suivis compartiment : " + ex.getMessage(), ex);
            }

        }
//        return new CompartimentResult(newSuiviIds, runIds);
    }

    private void insertCompartimentTrace(HttpServletRequest request, String userEmail, String param1, String param2, String param3, String param4, String param5, String message) {

        InsertTrace trace =
                InsertTrace.builder()
                        .p_ip(request != null ? request.getRemoteAddr() : null)
                        .p_startTime(LocalDate.now())
                        .p_endTime(LocalDate.now())
                        .p_page("Generation")
                        .p_login(userEmail)
                        .p_module("Generation")
                        .p_fonction("LANCEMENT_RUN")
                        .p_message(message)
                        .p_param1(param1)
                        .p_param2(param2)
                        .p_param3(param3)
                        .p_param4(param4)
                        .p_param5(param5)
                        .p_temps_reponse(0)
                        .p_statut(0)
                        .p_id_application(null)
                        .p_nom_application(null)
                        .build();

        suiviAuditDao.insertTrace(trace);
    }
}