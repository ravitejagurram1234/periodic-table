package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TDBWorkflowStatutSuivi;

import java.util.List;

public interface TDBWorkflowStatutSuiviDAO {

    List<TDBWorkflowStatutSuivi> getWorkflowSuiviStatut();

}