package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.GetListANO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GetListANODAO;
import com.socgen.sgs.api.quark.backend.api.service.GetListANOSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GetListANOService implements GetListANOSerInterface {

    private final GetListANODAO getListANODAO;

    @Autowired
    public GetListANOService(
            GetListANODAO getListANODAO) {

        this.getListANODAO = getListANODAO;
    }

    @Override
    public List<GetListANO> getListeANOByRun(
            Long p_id_run) {

        return getListANODAO.getListeANOByRun(
                p_id_run
        );
    }
}