package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditParSocieteDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AuditParSocieteBusiness {

    private final AuditParSocieteDao auditParSocieteDao;

    public AuditParSocieteBusiness(AuditParSocieteDao auditParSocieteDao) {
        this.auditParSocieteDao = auditParSocieteDao;
    }

    public Integer insertAudit(Audit audit) {
        return auditParSocieteDao.insertAudit(audit);
    }
}