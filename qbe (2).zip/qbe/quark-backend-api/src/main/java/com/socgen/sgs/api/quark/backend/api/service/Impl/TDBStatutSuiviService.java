package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBStatutSuivi;
import com.socgen.sgs.api.quark.backend.api.domain.TDBWorkflowStatutSuivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBStatutSuiviDAO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBWorkflowStatutSuiviDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBStatutSuiviSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class TDBStatutSuiviService
        implements TDBStatutSuiviSerInterface {

    private final TDBStatutSuiviDAO tdbStatutSuiviDAO;

    private final TDBWorkflowStatutSuiviDAO tdbWorkflowStatutSuiviDAO;

    @Autowired
    public TDBStatutSuiviService(
            TDBStatutSuiviDAO tdbStatutSuiviDAO,
            TDBWorkflowStatutSuiviDAO tdbWorkflowStatutSuiviDAO) {

        this.tdbStatutSuiviDAO = tdbStatutSuiviDAO;
        this.tdbWorkflowStatutSuiviDAO = tdbWorkflowStatutSuiviDAO;
    }

    @Override
    public List<TDBStatutSuivi> getStatutsSuivi(
            Long p_idTypeRapport) {

        List<TDBStatutSuivi> statuts =
                tdbStatutSuiviDAO.getListeStatutsSuivi();

        List<TDBWorkflowStatutSuivi> workflows =
                tdbWorkflowStatutSuiviDAO.getWorkflowSuiviStatut()
                        .stream()
                        .filter(workflow ->
                                workflow.getTypeRapport() != null
                                        && workflow.getTypeRapport().equals(p_idTypeRapport))
                        .toList();

        Set<Long> workflowStatusIds =
                workflows.stream()
                        .flatMap(workflow ->
                                Stream.of(
                                        workflow.getIdStatutFrom(),
                                        workflow.getIdStatutTo()
                                )
                        )
                        .collect(Collectors.toSet());

        return statuts.stream()
                .filter(statut ->
                        workflowStatusIds.contains(
                                statut.getIdStatutSuivi()
                        )
                )
                .toList();
    }
}