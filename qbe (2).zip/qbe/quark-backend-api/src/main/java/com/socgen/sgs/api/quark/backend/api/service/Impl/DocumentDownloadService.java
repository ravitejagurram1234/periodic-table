package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.DocumentDownloadBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.ReportDownload;
import com.socgen.sgs.api.quark.backend.api.service.DocumentDownloadSerInterface;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DocumentDownloadService implements DocumentDownloadSerInterface {

    private final DocumentDownloadBusiness business;

    @Override
    public ReportDownload download(long idSuivi, String requestedFormat) {
        return business.download(idSuivi, requestedFormat);
    }
}