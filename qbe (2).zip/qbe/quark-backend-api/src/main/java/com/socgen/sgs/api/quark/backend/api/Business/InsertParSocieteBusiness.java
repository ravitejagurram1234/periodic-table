package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertParSocieteDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class InsertParSocieteBusiness {

    private final InsertParSocieteDao insertParSocieteDao;

    public InsertParSocieteBusiness(InsertParSocieteDao insertParSocieteDao) {
        this.insertParSocieteDao = insertParSocieteDao;
    }

    public void InsertParSociete(Document document) {
        insertParSocieteDao.InsertParSociete(document);
    }
}