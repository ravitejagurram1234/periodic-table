package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;


import com.socgen.sgs.api.quark.backend.api.Mapper.TDBDocumentMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBDocumentDAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCTDBDocument implements TDBDocumentDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBDocument(DataSource dataSource) {

        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetContenuDocument")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(
                                "RETURN_VALUE",
                                OracleTypes.CURSOR,
                                (rs, rowNum) -> TDBDocumentMapper.mapResult(rs)
                        ),
                        new SqlParameter("p_idSuivi", Types.NUMERIC),
                        new SqlParameter("p_idTypeDocument", Types.NUMERIC)
                );
    }

    @Override
    public TDBDocument getContenuDocument(
            Long p_idSuivi,
            Long p_idTypeDocument) {

        Map<String, Object> params = Map.of(
                "p_idSuivi", p_idSuivi,
                "p_idTypeDocument", p_idTypeDocument
        );

        try {

            Map<String, Object> result = simpleJdbcCall.execute(params);

            return ((List<TDBDocument>) result.get("RETURN_VALUE"))
                    .stream()
                    .findFirst()
                    .orElse(null);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}