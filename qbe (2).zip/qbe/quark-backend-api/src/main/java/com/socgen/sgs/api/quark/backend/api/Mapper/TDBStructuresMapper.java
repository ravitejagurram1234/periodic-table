package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBStructuresDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBStructures;
import org.h2.util.JSR310Utils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TDBStructuresMapper {

    public static TDBStructures mapResult(ResultSet rs) throws SQLException {

        TDBStructures structures = new TDBStructures();

        structures.setTrigramme(rs.getString("TRIGRAMME"));
        structures.setIdStructure(rs.getString("ID_STRUCTURE"));
        structures.setIdSuivi(rs.getLong("ID_SUIVI"));
        structures.setNomStructure(rs.getString("NOM_STRUCTURE"));
        structures.setIdGabarit(rs.getLong("ID_GABARIT"));
        structures.setNomGabarit(rs.getString("NOM_GABARIT"));
        structures.setTypeSuivi(rs.getInt("TYPE_SUIVI"));

        if (rs.getDate("DATE_ECHEANCE") != null) {
            structures.setDateEcheance(
                    rs.getDate("DATE_ECHEANCE").toLocalDate());
        }

//        if (rs.getDate("DATE_LAST_ECHEANCE") != null) {
//            structures.setDateLastEcheance(
//                    rs.getDate("DATE_LAST_ECHEANCE").toLocalDate());
//        }

        String dateLastEcheance = rs.getString("DATE_LAST_ECHEANCE");

        if (dateLastEcheance != null && !dateLastEcheance.isBlank()) {
            structures.setDateLastEcheance(
                    LocalDate.parse(
                            dateLastEcheance.substring(0, 10),
                            DateTimeFormatter.ofPattern("MM/dd/yyyy")
                    )
            );
        }

        structures.setFndLegalType(rs.getString("FND_LEGAL_TYPE"));
        structures.setFndMngtCompany(rs.getString("FND_MNGT_COMPANY"));
        structures.setFndClassification(rs.getString("FND_CLASSIFICATION"));
        structures.setIdStatutGeneration(rs.getLong("ID_STATUT_GENERATION"));
        structures.setIdRunPrecedent(rs.getLong("ID_RUN_PRECEDENT"));
        structures.setIdRunAno(rs.getLong("ID_RUN_ANO"));
        structures.setFndAccountant(rs.getString("FND_ACCOUNTANT"));
        structures.setFndAuditor(rs.getString("FND_AUDITOR"));
        structures.setTypeSuivi(rs.getInt("TYPE_SUIVI"));
        structures.setIsLocked(rs.getInt("IS_LOCKED"));
        structures.setIdStatutSuivi(rs.getInt("ID_STATUT_SUIVI"));

        return structures;
    }

    public static TDBStructuresDTO toDto(TDBStructures structures) {

        return new TDBStructuresDTO(
                structures.getTrigramme(),
                structures.getIdStructure(),
                structures.getIdSuivi(),
                structures.getNomStructure(),
                structures.getIdGabarit(),
                structures.getNomGabarit(),
                structures.getDateEcheance(),
                structures.getDateLastEcheance(),
                structures.getFndLegalType(),
                structures.getFndMngtCompany(),
                structures.getFndClassification(),
                structures.getIdStatutGeneration(),
                structures.getIdRunPrecedent(),
                structures.getIdRunAno(),
                structures.getFndAccountant(),
                structures.getFndAuditor(),
                structures.getTypeSuivi(),
                structures.getIsLocked(),
                structures.getIdStatutSuivi()
        );
    }
}