package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TDBGetListeSuivisCompartBySuiviDTO {

    private Long idSuivi;
    private String idFndCode;
    private LocalDate dateEcheance;
    private String dateEcheanceExacte;
    private Long idMaquettiste;
    private Long idGabarit;
    private Long idTypeRapport;
}