package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBGetListeEventsByGabaritDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeEventsByGabarit;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TDBGetListeEventsByGabaritMapper {

    public static TDBGetListeEventsByGabarit mapResult(
            ResultSet rs) throws SQLException {

        TDBGetListeEventsByGabarit event =
                new TDBGetListeEventsByGabarit();

        event.setIdEvent(
                rs.getObject("ID_EVENT", Long.class)
        );

        return event;
    }

    public static TDBGetListeEventsByGabaritDTO toDto(
            TDBGetListeEventsByGabarit domain) {

        return new TDBGetListeEventsByGabaritDTO(
                domain.getIdEvent()
        );
    }
}