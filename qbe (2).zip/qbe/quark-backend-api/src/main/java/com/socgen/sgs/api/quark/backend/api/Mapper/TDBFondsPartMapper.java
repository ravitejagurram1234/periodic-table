package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBFondsPartDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBFondsPart;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TDBFondsPartMapper {

    public static TDBFondsPart mapResult(ResultSet rs) throws SQLException {

        TDBFondsPart fondsPart = new TDBFondsPart();

        fondsPart.setIdFndCode(rs.getString("ID_FND_CODE"));
        fondsPart.setIdSuivi(rs.getLong("ID_SUIVI"));
        fondsPart.setIdRunPrecedent(rs.getLong("ID_RUN_PRECEDENT"));
        fondsPart.setIdRunAno(rs.getLong("ID_RUN_ANO"));
        fondsPart.setFndShtDescription(rs.getString("FND_SHT_DESCRIPTION"));
        fondsPart.setIdGabarit(rs.getLong("ID_GABARIT"));
        fondsPart.setNomGabarit(rs.getString("NOM_GABARIT"));
        fondsPart.setTypeSuivi(rs.getInt("TYPE_SUIVI"));

        if (rs.getDate("DATE_ECHEANCE") != null) {
            fondsPart.setDateEcheance(
                    rs.getDate("DATE_ECHEANCE").toLocalDate());
        }

        fondsPart.setTrigramme(rs.getString("TRIGRAMME"));

        System.out.println(
                "DATE_LAST_ECHEANCE = "
                        + rs.getString("DATE_LAST_ECHEANCE")
        );

        String dateLastEcheance = rs.getString("DATE_LAST_ECHEANCE");

        if (dateLastEcheance != null && !dateLastEcheance.isBlank()) {
            fondsPart.setDateLastEcheance(
                    LocalDate.parse(
                            dateLastEcheance.substring(0, 10),
                            DateTimeFormatter.ofPattern("MM/dd/yyyy")
                    )
            );
        }



//        if (rs.getDate("DATE_LAST_ECHEANCE") != null) {
//            fondsPart.setDateLastEcheance(
//                    rs.getDate("DATE_LAST_ECHEANCE").toLocalDate());
//        }

        fondsPart.setLibelleFond(rs.getString("LIBELLE_FOND"));
        fondsPart.setFndMngtCompany(rs.getString("FND_MNGT_COMPANY"));
        fondsPart.setUnitIdInsCode(rs.getString("UNIT_ID_INS_CODE"));
        fondsPart.setLibelleClasse(rs.getString("LIBELLE_CLASSE"));
        fondsPart.setFndAccountant(rs.getString("FND_ACCOUNTANT"));
        fondsPart.setFndAuditor(rs.getString("FND_AUDITOR"));
        fondsPart.setIdStatutGeneration(rs.getLong("ID_STATUT_GENERATION"));
        fondsPart.setIsLocked(rs.getInt("IS_LOCKED"));
        fondsPart.setIdStatutSuivi(rs.getInt("ID_STATUT_SUIVI"));

        return fondsPart;
    }

    public static TDBFondsPartDTO toDto(TDBFondsPart fondsPart) {

        return new TDBFondsPartDTO(
                fondsPart.getIdFndCode(),
                fondsPart.getIdSuivi(),
                fondsPart.getIdRunPrecedent(),
                fondsPart.getIdRunAno(),
                fondsPart.getFndShtDescription(),
                fondsPart.getIdGabarit(),
                fondsPart.getNomGabarit(),
                fondsPart.getDateEcheance(),
                fondsPart.getTrigramme(),
                fondsPart.getDateLastEcheance(),
                fondsPart.getLibelleFond(),
                fondsPart.getFndMngtCompany(),
                fondsPart.getUnitIdInsCode(),
                fondsPart.getLibelleClasse(),
                fondsPart.getTypeSuivi(),
                fondsPart.getFndAccountant(),
                fondsPart.getFndAuditor(),
                fondsPart.getIdStatutGeneration(),
                fondsPart.getIsLocked(),
                fondsPart.getIdStatutSuivi()
        );
    }
}