package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class GabaritTemplateBusiness {

    private final GabaritTemplateDao gabaritTemplateDao;

    public GabaritTemplateBusiness(GabaritTemplateDao gabaritTemplateDao) {
        this.gabaritTemplateDao = gabaritTemplateDao;
    }

    public List<GabaritTemplate> getTemplates() {
        return gabaritTemplateDao.getTemplates();
    }
}