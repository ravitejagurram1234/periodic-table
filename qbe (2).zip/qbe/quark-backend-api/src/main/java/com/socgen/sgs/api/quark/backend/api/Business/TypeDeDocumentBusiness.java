package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TypeDeDocumentDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class TypeDeDocumentBusiness {

    private final TypeDeDocumentDao typeDeDocumentDao;

    public TypeDeDocumentBusiness(TypeDeDocumentDao typeDeDocumentDao) {
        this.typeDeDocumentDao = typeDeDocumentDao;
    }

    public List<TypeDeDocument> getTypeDocument(String p_id_fnd_code, Long p_typeCategorieDocument) {
        return typeDeDocumentDao.getTypeDocument(p_id_fnd_code, p_typeCategorieDocument);
    }
}