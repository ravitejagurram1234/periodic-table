package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.FeatureExceptions.FeatureConfigurationException;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.AmundiFilenameMatch;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.DocumentFormat;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.ReportNamingContext;
import com.socgen.sgs.api.quark.backend.api.infra.dao.DocumentDownloadDao;
import oracle.jdbc.internal.OracleTypes;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.Types;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class SimpleJDBCDocumentDownload implements DocumentDownloadDao {

    private static final String NAMING_CONTEXT_SQL = """
            SELECT DISTINCT
                s.ID_SUIVI,
                s.ID_FND_CODE,
                s.ID_UNIT_CODE,
                s.ID_TYPE_RAPPORT,
                s.ID_STATUT_SUIVI,
                NVL(TO_DATE(sp.VALEUR, 'MM/DD/YYYY HH24:MI:SS'), s.DATE_ECHEANCE) AS REPORT_DATE,
                NVL(rf.FND_LNG_DESCRIPTION, NVL(qs.NOM, s.ID_FND_CODE)) AS FUND_NAME,
                rf.FND_CURRENCY,
                UPPER(ld.VALEUR_LANGUE) AS REPORT_LANGUAGE,
                CASE WHEN rf.ID_FND_CODE IS NULL THEN 0 ELSE 1 END AS FUND_BASED_SUIVI
            FROM QXP_SUIVI s
            LEFT JOIN OWB_DWH.REF_FUND rf
              ON rf.ID_FND_CODE = s.ID_FND_CODE
             AND rf.FND_END_VALIDITY = TO_DATE('31/12/2199', 'DD/MM/YYYY')
            LEFT JOIN QXP_STRUCTURE qs
              ON qs.ID_STRUCTURE = s.ID_FND_CODE
            LEFT JOIN QXP_REF_LANGUE_DOCUMENT ld
              ON ld.ID_LANGUE_DOCUMENT = s.ID_LANGUE
            LEFT JOIN QXP_ASSO_SUIVI_PARAMETRES sp
              ON sp.ID_SUIVI = s.ID_SUIVI
             AND sp.ID_PARAMETRE = 2
            WHERE s.ID_SUIVI = ?
            """;

    private static final String AMUNDI_MATCH_SQL = """
            SELECT ap.REPORT_DATE, ap.REPORT_LANGUAGE, ap.CODE_PARAPLUIE
            FROM QXP_AMUNDI_PERIMETER ap
            WHERE ap.FUND_NAME = :fundCode
              AND ap.REPORT_TYPE = :reportType
              AND ap.REPORT_DATE >= :monthStart
              AND ap.REPORT_DATE < :nextMonth
              AND UPPER(TRIM(ap.REPORT_LANGUAGE)) = :language
            """;

    private final JdbcTemplate jdbcTemplate;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    private final SimpleJdbcCall getContentCall;
    private final SimpleJdbcCall updateVisitedCall;

    public SimpleJDBCDocumentDownload(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
        this.getContentCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetContenuDocument")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(
                                "RETURN_VALUE",
                                OracleTypes.CURSOR,
                                (resultSet, rowNumber) -> resultSet.getBytes("CONTENU")),
                        new SqlParameter("p_idSuivi", Types.NUMERIC),
                        new SqlParameter("p_idTypeDocument", Types.NUMERIC));
        this.updateVisitedCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withProcedureName("UpdateStatutDocument")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_idSuivi", Types.NUMERIC),
                        new SqlParameter("p_idTypeDocument", Types.NUMERIC));
    }

    @Override
    public Optional<ReportNamingContext> findNamingContext(long idSuivi) {
        List<ReportNamingContext> rows = jdbcTemplate.query(
                NAMING_CONTEXT_SQL,
                (resultSet, rowNumber) -> new ReportNamingContext(
                        resultSet.getLong("ID_SUIVI"),
                        resultSet.getString("ID_FND_CODE"),
                        resultSet.getString("ID_UNIT_CODE"),
                        resultSet.getInt("ID_TYPE_RAPPORT"),
                        resultSet.getInt("ID_STATUT_SUIVI"),
                        toLocalDate(resultSet.getDate("REPORT_DATE")),
                        resultSet.getString("FUND_NAME"),
                        resultSet.getString("FND_CURRENCY"),
                        resultSet.getString("REPORT_LANGUAGE"),
                        resultSet.getInt("FUND_BASED_SUIVI") == 1),
                idSuivi);

        if (rows.size() > 1) {
            throw new FeatureConfigurationException(
                    "More than one naming context was returned for idSuivi=" + idSuivi);
        }
        return rows.stream().findFirst();
    }

    @Override
    public List<AmundiFilenameMatch> findAmundiMatches(
            ReportNamingContext context,
            String perimeterReportType) {

        LocalDate monthStart = context.reportDate().withDayOfMonth(1);
        MapSqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("fundCode", context.fundCode())
                .addValue("reportType", perimeterReportType)
                .addValue("monthStart", Date.valueOf(monthStart))
                .addValue("nextMonth", Date.valueOf(monthStart.plusMonths(1)))
                .addValue("language", context.language());

        return namedParameterJdbcTemplate.query(
                AMUNDI_MATCH_SQL,
                parameters,
                (resultSet, rowNumber) -> new AmundiFilenameMatch(
                        toLocalDate(resultSet.getDate("REPORT_DATE")),
                        resultSet.getString("REPORT_LANGUAGE"),
                        resultSet.getString("CODE_PARAPLUIE")));
    }

    @Override
    @SuppressWarnings("unchecked")
    public Optional<byte[]> findContent(long idSuivi, DocumentFormat format) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("p_idSuivi", idSuivi);
        parameters.put("p_idTypeDocument", format.oracleValue());

        Map<String, Object> result = getContentCall.execute(parameters);
        List<byte[]> rows = (List<byte[]>) result.get("RETURN_VALUE");
        if (rows == null || rows.isEmpty() || rows.getFirst() == null) {
            return Optional.empty();
        }
        return Optional.of(rows.getFirst());
    }

    @Override
    public void markVisited(long idSuivi, DocumentFormat format) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("p_idSuivi", idSuivi);
        parameters.put("p_idTypeDocument", format.oracleValue());
        updateVisitedCall.execute(parameters);
    }

    private LocalDate toLocalDate(java.sql.Date value) {
        return value == null ? null : value.toLocalDate();
    }
}