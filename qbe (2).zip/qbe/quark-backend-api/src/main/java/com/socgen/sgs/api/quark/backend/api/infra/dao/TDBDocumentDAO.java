package com.socgen.sgs.api.quark.backend.api.infra.dao;


import com.socgen.sgs.api.quark.backend.api.domain.TDBDocument;

public interface TDBDocumentDAO {

    TDBDocument getContenuDocument(
            Long p_idSuivi,
            Long p_idTypeDocument
    );
}