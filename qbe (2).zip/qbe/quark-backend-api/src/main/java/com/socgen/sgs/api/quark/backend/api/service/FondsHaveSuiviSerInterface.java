package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.Dto.FondsHaveSuiviDto;

import java.time.LocalDate;
import java.util.List;

public interface FondsHaveSuiviSerInterface {

    List<FondsHaveSuiviDto> getListeFondsHaveSuivi(
            Long idLangue,
            LocalDate dateEcheance,
            Long idTypeRapport
    );
}
