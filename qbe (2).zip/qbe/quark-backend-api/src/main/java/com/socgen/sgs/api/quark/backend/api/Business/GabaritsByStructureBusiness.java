package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritByStructure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritsByStructureDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GabaritsByStructureBusiness {

    private final GabaritsByStructureDao gabaritsByStructureDao;

    public GabaritsByStructureBusiness(GabaritsByStructureDao gabaritsByStructureDao) {
        this.gabaritsByStructureDao = gabaritsByStructureDao;
    }

    public List<GabaritByStructure> getGabaritsByStructure(String p_idStructure) {
        return gabaritsByStructureDao.getGabaritsByStructure(p_idStructure);
    }
}
