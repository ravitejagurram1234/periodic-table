package com.socgen.sgs.api.quark.backend.api.infra.dao;
import com.socgen.sgs.api.quark.backend.api.domain.FondsHaveSuivi;

import java.time.LocalDate;
import java.util.List;

public interface FondsHaveSuiviDao {

    List<FondsHaveSuivi> getListeFondsHaveSuivi(
            Long idLangue,
            LocalDate dateEcheance,
            Long idTypeRapport
    );
}