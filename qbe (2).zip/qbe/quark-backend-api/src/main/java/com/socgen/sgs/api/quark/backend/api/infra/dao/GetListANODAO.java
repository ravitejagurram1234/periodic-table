package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.GetListANO;

import java.util.List;

public interface GetListANODAO {

    List<GetListANO> getListeANOByRun(Long p_id_run);

}