package com.socgen.sgs.api.quark.backend.api.domain;

import java.time.LocalDate;
import java.util.Locale;
import java.util.Objects;

public final class ReportDownloadModels {

    private ReportDownloadModels() {
    }

    public enum DocumentFormat {
        QXP(1, "qxp", "application/quark-ps"),
        PDF(2, "pdf", "application/pdf"),
        DOC(3, "doc", "application/msword");

        private final int oracleValue;
        private final String extension;
        private final String mediaType;

        DocumentFormat(int oracleValue, String extension, String mediaType) {
            this.oracleValue = oracleValue;
            this.extension = extension;
            this.mediaType = mediaType;
        }

        public static DocumentFormat fromPath(String value) {
            try {
                return valueOf(Objects.requireNonNull(value, "format")
                        .trim().toUpperCase(Locale.ROOT));
            } catch (RuntimeException exception) {
                throw new IllegalArgumentException("format must be qxp, pdf, or doc", exception);
            }
        }

        public int oracleValue() {
            return oracleValue;
        }

        public String extension() {
            return extension;
        }

        public String mediaType() {
            return mediaType;
        }
    }

    public record ReportNamingContext(
            long idSuivi,
            String fundCode,
            String unitCode,
            int reportTypeId,
            int statusId,
            LocalDate reportDate,
            String fundName,
            String currency,
            String language,
            boolean fundBasedSuivi) {
    }

    public record AmundiFilenameMatch(
            LocalDate reportDate,
            String reportLanguage,
            String codeParapluie) {
    }

    public record ReportDownload(byte[] content, String filename, String mediaType) {
        public ReportDownload {
            content = Objects.requireNonNull(content, "content").clone();
            filename = Objects.requireNonNull(filename, "filename");
            mediaType = Objects.requireNonNull(mediaType, "mediaType");
        }

        @Override
        public byte[] content() {
            return content.clone();
        }
    }
}