package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateInsertDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class GabaritTemplateInsertBusiness {

    private final GabaritTemplateInsertDao gabaritTemplateInsertDao;

    public GabaritTemplateInsertBusiness(GabaritTemplateInsertDao gabaritTemplateInsertDao) {
        this.gabaritTemplateInsertDao = gabaritTemplateInsertDao;
    }

    public Integer insertGabaritTemplate(Chargement_gabarit gabarit) {
        return gabaritTemplateInsertDao.insertGabaritTemplate(gabarit);
    }
}