package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AmundiPerimeterImportBusiness;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiDateFormat;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportMode;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportTemplateConfiguration;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportValidationResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.UploadedFile;
import com.socgen.sgs.api.quark.backend.api.service.AmundiPerimeterImportSerInterface;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AmundiPerimeterImportService implements AmundiPerimeterImportSerInterface {

    private final AmundiPerimeterImportBusiness business;

    @Override
    public AmundiImportTemplateConfiguration configuration() {
        return business.configuration();
    }

    @Override
    public AmundiImportValidationResult validate(
            UploadedFile file,
            AmundiDateFormat dateFormat,
            String userEmail,
            String clientIp) {
        return business.validate(file, dateFormat, userEmail, clientIp);
    }

    @Override
    public AmundiImportResult importFile(
            UploadedFile file,
            AmundiDateFormat dateFormat,
            AmundiImportMode mode,
            String expectedChecksum,
            String userEmail,
            String clientIp) {
        return business.importFile(file, dateFormat, mode, expectedChecksum, userEmail, clientIp);
    }
}