package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritTemplate;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GetGabaritTemplateDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class GetGabaritTemplatesBusiness {

    private final GetGabaritTemplateDao getGabaritTemplateDao;

    public GetGabaritTemplatesBusiness(GetGabaritTemplateDao getGabaritTemplateDao) {
        this.getGabaritTemplateDao = getGabaritTemplateDao;
    }

    public GabaritTemplate getGabaritTemplates(Long p_idGabaritTemplate) {
        return getGabaritTemplateDao.getGabaritTemplates(p_idGabaritTemplate);
    }
}