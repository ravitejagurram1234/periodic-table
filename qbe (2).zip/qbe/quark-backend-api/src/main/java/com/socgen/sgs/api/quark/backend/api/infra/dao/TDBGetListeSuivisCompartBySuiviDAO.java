package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeSuivisCompartBySuivi;

import java.util.List;

public interface TDBGetListeSuivisCompartBySuiviDAO {

    List<TDBGetListeSuivisCompartBySuivi> getListeSuivisCompartBySuivi(
            Long p_idSuivi,
            Long p_idTache
    );
}