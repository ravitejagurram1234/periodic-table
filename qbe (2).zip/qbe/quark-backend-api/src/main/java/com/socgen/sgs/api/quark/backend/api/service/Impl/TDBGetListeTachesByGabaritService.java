package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeTachesByGabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBGetListeTachesByGabaritDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBGetListeTachesByGabaritSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TDBGetListeTachesByGabaritService
        implements TDBGetListeTachesByGabaritSerInterface {

    @Autowired
    private TDBGetListeTachesByGabaritDAO dao;

    @Override
    public List<TDBGetListeTachesByGabarit>
    getListeTachesByGabarit(
            Long p_idGabarit) {

        return dao.getListeTachesByGabarit(
                p_idGabarit
        );
    }
}