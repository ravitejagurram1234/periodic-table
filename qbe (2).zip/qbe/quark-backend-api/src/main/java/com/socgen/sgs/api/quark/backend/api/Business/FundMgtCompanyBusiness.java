package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.FundMgtCompany;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FundMgtCompanyDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class FundMgtCompanyBusiness {

    private final FundMgtCompanyDao dao;

    public FundMgtCompanyBusiness(FundMgtCompanyDao dao) {
        this.dao = dao;
    }

    public List<FundMgtCompany> getFundMgtCompany() {
        return dao.getListFundMgtCompanies();
    }
}