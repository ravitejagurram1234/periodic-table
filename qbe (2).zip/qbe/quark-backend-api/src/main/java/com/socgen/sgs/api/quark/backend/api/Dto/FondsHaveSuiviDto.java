package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FondsHaveSuiviDto {

    private Long keyRefFund;
    private String idFndCode;
    private LocalDate idFndStartValidity;
    private LocalDate fndEndValidity;
    private String fndShtDescription;
    private String fndLngDescription;
    private String fndFlgMultiMngr;
    private String actSocioClass;
    private String idMngCode;
    private String mngLngDescription;
    private String mngShtDescription;
    private String idMfmManagerCode;
    private String idActCode;
}
