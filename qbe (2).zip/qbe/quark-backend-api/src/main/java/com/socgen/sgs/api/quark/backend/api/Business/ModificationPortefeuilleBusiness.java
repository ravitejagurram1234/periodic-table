package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationPortefeuilleDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ModificationPortefeuilleBusiness {

    private final ModificationPortefeuilleDao modificationPortefeuilleDao;

    public ModificationPortefeuilleBusiness(
            ModificationPortefeuilleDao modificationPortefeuilleDao) {
        this.modificationPortefeuilleDao = modificationPortefeuilleDao;
    }

    public List<portefeuille> getListPortefeuille(int p_id_sous_categorie) {
        return modificationPortefeuilleDao.getListPortefeuille(p_id_sous_categorie);
    }
}