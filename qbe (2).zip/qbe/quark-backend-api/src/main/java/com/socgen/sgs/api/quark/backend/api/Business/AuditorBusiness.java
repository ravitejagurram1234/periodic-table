package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Auditor;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditorDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class AuditorBusiness {

    private final AuditorDao dao;

    public AuditorBusiness(AuditorDao dao) {
        this.dao = dao;
    }

    public List<Auditor> getAuditors() {
        return dao.getListAuditors();
    }
}