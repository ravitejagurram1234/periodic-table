package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;
import com.socgen.sgs.api.quark.backend.api.Dto.TDBStatutSuiviDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.TDBWorkflowStatutRequestDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.TDBStatutSuiviMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBStatutSuivi;
import com.socgen.sgs.api.quark.backend.api.domain.TDBWorkflowStatutSuivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBStatutSuiviDAO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBWorkflowStatutSuiviDAO;
import com.socgen.sgs.api.quark.backend.api.service.IAuthenticationService;
import com.socgen.sgs.api.quark.backend.api.service.TDBWorkflowStatutSerInterface;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TDBWorkflowStatutService
        implements TDBWorkflowStatutSerInterface {

    private final TDBWorkflowStatutSuiviDAO tdbWorkflowStatutSuiviDAO;

    private final TDBStatutSuiviDAO tdbStatutSuiviDAO;

    private final IAuthenticationService authenticationService;

    public TDBWorkflowStatutService(
            TDBWorkflowStatutSuiviDAO tdbWorkflowStatutSuiviDAO,
            TDBStatutSuiviDAO tdbStatutSuiviDAO,
            IAuthenticationService authenticationService) {

        this.tdbWorkflowStatutSuiviDAO =
                tdbWorkflowStatutSuiviDAO;

        this.tdbStatutSuiviDAO =
                tdbStatutSuiviDAO;

        this.authenticationService =
                authenticationService;
    }

    @Override
    public List<TDBStatutSuiviDTO> getStatuts(
            TDBWorkflowStatutRequestDTO request) {

        List<TDBWorkflowStatutSuivi> workflows =
                tdbWorkflowStatutSuiviDAO
                        .getWorkflowSuiviStatut();

        List<Long> roleIds =
                getCurrentUserRoles();

        List<Long> statutIds =
                workflows.stream()
                        .filter(workflow ->
                                workflow.getIdStatutFrom()
                                        .equals(
                                                request.getIdStatutFrom()
                                        ))
                        .filter(workflow ->
                                workflow.getTypeRapport()
                                        .equals(
                                                request.getTypeRapport()
                                        ))
                        .filter(workflow ->
                                workflow.getIdRole() != null
                                        && roleIds.contains(
                                        workflow.getIdRole()
                                ))
                        .map(
                                TDBWorkflowStatutSuivi::getIdStatutTo
                        )
                        .distinct()
                        .toList();

        if (statutIds.isEmpty()) {

            statutIds =
                    workflows.stream()
                            .filter(workflow ->
                                    workflow.getIdStatutFrom()
                                            .equals(
                                                    request.getIdStatutFrom()
                                            ))
                            .filter(workflow ->
                                    workflow.getTypeRapport()
                                            .equals(
                                                    (long) Enums.TypeRapport.All.getValue()
                                            ))
                            .filter(workflow ->
                                    workflow.getIdRole() != null
                                            && roleIds.contains(
                                            workflow.getIdRole()
                                    ))
                            .map(
                                    TDBWorkflowStatutSuivi::getIdStatutTo
                            )
                            .distinct()
                            .toList();
        }

        List<Long> orderedStatutIds =
                new ArrayList<>();

        orderedStatutIds.add(
                request.getIdStatutFrom()
        );

        statutIds.stream()
                .filter(id ->
                        !id.equals(
                                request.getIdStatutFrom()
                        ))
                .forEach(
                        orderedStatutIds::add
                );

        final List<Long> finalStatutIds =
                orderedStatutIds;

        List<TDBStatutSuivi> statuts =
                tdbStatutSuiviDAO
                        .getListeStatutsSuivi();

        return statuts.stream()
                .filter(statut ->
                        finalStatutIds.contains(
                                statut.getIdStatutSuivi()
                        ))
                .filter(statut ->
                        statut.getTypeSuivi() != null
                                && statut.getTypeSuivi().equals(
                                request.getTypeSuivi()
                        ))
                .map(
                        TDBStatutSuiviMapper::toDto
                )
                .toList();
    }

    private List<Long> getCurrentUserRoles() {

        List<String> authorities =
                authenticationService
                        .getAuthorities();

        List<Long> roleIds = new ArrayList<>();

        if (authorities.contains("api.quark_Utilisateur Permission")) {
            roleIds.add((long) Enums.Roles.Utilisateur.getValue());
        }

        if (authorities.contains("api.quark_Maquettiste Permission")) {
            roleIds.add((long) Enums.Roles.Maquettiste.getValue());
        }

        if (authorities.contains("api.quark_Admin Permission")) {
            roleIds.add((long) Enums.Roles.Admin.getValue()
            );
        }

        if (authorities.contains("api.quark_Fiscalite Permission")) {
            roleIds.add(4L);
        }

        return roleIds;
    }
}