package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.AmundiFilenameMatch;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.DocumentFormat;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.ReportNamingContext;

import java.util.List;
import java.util.Optional;

public interface DocumentDownloadDao {

    Optional<ReportNamingContext> findNamingContext(long idSuivi);

    List<AmundiFilenameMatch> findAmundiMatches(
            ReportNamingContext context,
            String perimeterReportType);

    Optional<byte[]> findContent(long idSuivi, DocumentFormat format);

    void markVisited(long idSuivi, DocumentFormat format);
}