package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBGetListeSuivisCompartBySuiviDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeSuivisCompartBySuivi;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TDBGetListeSuivisCompartBySuiviMapper {

    public static TDBGetListeSuivisCompartBySuivi mapResult(
            ResultSet rs) throws SQLException {

        TDBGetListeSuivisCompartBySuivi suiviCompart =
                new TDBGetListeSuivisCompartBySuivi();

        suiviCompart.setIdSuivi(
                rs.getObject("ID_SUIVI", Long.class)
        );

        suiviCompart.setIdFndCode(
                rs.getString("ID_FND_CODE")
        );

        if (rs.getDate("DATE_ECHEANCE") != null) {

            suiviCompart.setDateEcheance(
                    rs.getDate("DATE_ECHEANCE")
                            .toLocalDate()
            );
        }

        suiviCompart.setDateEcheanceExacte(
                rs.getString("DATE_ECHEANCE_EXACTE")
        );

        suiviCompart.setIdMaquettiste(
                rs.getObject("ID_MAQUETTISTE", Long.class)
        );

        suiviCompart.setIdGabarit(
                rs.getObject("ID_GABARIT", Long.class)
        );

        suiviCompart.setIdTypeRapport(
                rs.getObject("ID_TYPE_RAPPORT", Long.class)
        );

        return suiviCompart;
    }

    public static TDBGetListeSuivisCompartBySuiviDTO toDto(
            TDBGetListeSuivisCompartBySuivi domain) {

        return new TDBGetListeSuivisCompartBySuiviDTO(
                domain.getIdSuivi(),
                domain.getIdFndCode(),
                domain.getDateEcheance(),
                domain.getDateEcheanceExacte(),
                domain.getIdMaquettiste(),
                domain.getIdGabarit(),
                domain.getIdTypeRapport()
        );
    }
}