package com.socgen.sgs.api.quark.backend.api.domain;

public final class FeatureExceptions {

    private FeatureExceptions() {
    }

    public static final class ImportRejectedException extends RuntimeException {
        public ImportRejectedException(String message) {
            super(message);
        }

        public ImportRejectedException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    public static final class ResourceNotFoundException extends RuntimeException {
        public ResourceNotFoundException(String message) {
            super(message);
        }
    }

    public static final class FeatureConfigurationException extends RuntimeException {
        public FeatureConfigurationException(String message) {
            super(message);
        }
    }
}