package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.domain.SuiviDetails;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureDao;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviDetailsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
@Service
@Transactional
public class SuiviDetailsBusiness {

    private final SuiviDetailsDao suiviDetailsDao;

    public SuiviDetailsBusiness(SuiviDetailsDao suiviDetailsDao) {
        this.suiviDetailsDao = suiviDetailsDao;
    }

    public List<SuiviDetails> getListeNewSuivisByFondsPart(
            Long p_idTypeRapport,
            Long p_idLangue,
            Long p_idGabarit,
            Long p_typeGabarit,
            LocalDate p_dateEcheance,
            String p_portefeuilles,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        return suiviDetailsDao.getListeNewSuivisByFondsPart(
                p_idTypeRapport,
                p_idLangue,
                p_idGabarit,
                p_typeGabarit,
                p_dateEcheance,
                p_portefeuilles,
                p_auditor,
                p_accountant,
                p_fundMgtCompany);
    }
}
