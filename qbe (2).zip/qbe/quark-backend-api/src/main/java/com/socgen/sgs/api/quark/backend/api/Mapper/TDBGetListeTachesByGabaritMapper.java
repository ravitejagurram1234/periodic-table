package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBGetListeTachesByGabaritDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeTachesByGabarit;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TDBGetListeTachesByGabaritMapper {

    public static TDBGetListeTachesByGabarit mapResult(
            ResultSet rs) throws SQLException {

        TDBGetListeTachesByGabarit tache =
                new TDBGetListeTachesByGabarit();

        tache.setIdTache(
                rs.getObject("ID_TACHE", Long.class)
        );

        tache.setCommentaire(
                rs.getString("COMMENTAIRE")
        );

        tache.setIdStatutSuiviDebut(
                rs.getObject(
                        "ID_STATUT_SUIVI_DEBUT",
                        Long.class
                )
        );

        tache.setIdStatutSuiviFin(
                rs.getObject(
                        "ID_STATUT_SUIVI_FIN",
                        Long.class
                )
        );

        tache.setIdTypeTache(
                rs.getObject(
                        "ID_TYPE_TACHE",
                        Long.class
                )
        );

        return tache;
    }

    public static TDBGetListeTachesByGabaritDTO toDto(
            TDBGetListeTachesByGabarit domain) {

        return new TDBGetListeTachesByGabaritDTO(
                domain.getIdTache(),
                domain.getCommentaire(),
                domain.getIdStatutSuiviDebut(),
                domain.getIdStatutSuiviFin(),
                domain.getIdTypeTache()
        );
    }
}