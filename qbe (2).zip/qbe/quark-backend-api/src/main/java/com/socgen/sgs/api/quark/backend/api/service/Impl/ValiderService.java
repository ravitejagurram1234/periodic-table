package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.SuiviDetailsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.SuiviStructureBusiness;
import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.SuiviStructureDetailsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.ValiderDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.SuiviDetailsMapper;
import com.socgen.sgs.api.quark.backend.api.Mapper.SuiviStructureMapper;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.GabaritRepository;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import com.socgen.sgs.api.quark.backend.api.service.ValiderSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

@Service
public class ValiderService implements ValiderSerInterface {
    @Autowired
    private SuiviDetailsBusiness suiviDetailsBusiness;

    @Autowired
    private SuiviStructureBusiness structureBusiness;
    @Autowired
    private GabaritRepository gabaritRepository;
    @Override
    public ValiderDTO getSuivis(Long p_idTypeRapport, Long p_idLangue, Long p_idGabarit,
                                LocalDate p_dateEcheance, String p_portfeuilles, String p_auditor,
                                String p_accountant, String p_fundMgtCompany){
        List<SuiviDetailsDTO>fondsList= Collections.emptyList();
        List<SuiviStructureDetailsDTO> structureList=Collections.emptyList();


        // Fetch gabarit and extract type
        QxpGabarit gabarit = gabaritRepository.findByGabaritId(p_idGabarit);
        if (gabarit == null) {
            throw new IllegalArgumentException("Gabarit not found with ID: " + p_idGabarit);
        }
        Long gabaritType = Long.parseLong(gabarit.getType());

        if(gabaritType==0 || gabaritType==2) {
            fondsList = suiviDetailsBusiness.getListeNewSuivisByFondsPart(p_idTypeRapport, p_idLangue, p_idGabarit, gabaritType,
                            p_dateEcheance, p_portfeuilles, p_auditor, p_accountant, p_fundMgtCompany).stream()
                    .map(suivi-> SuiviDetailsMapper.toDto(suivi,gabaritType)).toList();
        }
        if(gabaritType==1) {
            structureList=structureBusiness.getListeStructuresForNewSuivi(p_idTypeRapport, p_idLangue, p_idGabarit, p_dateEcheance,
                    p_portfeuilles, p_auditor, p_accountant, p_fundMgtCompany).stream().map(SuiviStructureMapper::toDto).toList();
        }
        return new ValiderDTO(fondsList,structureList);

//        if(p_typeGabarit==0 || p_typeGabarit==2) {
//            fondsList = suiviDetailsBusiness.getListeNewSuivisByFondsPart(p_idTypeRapport, p_idLangue, p_idGabarit, p_typeGabarit,
//                    p_dateEcheance, p_portfeuilles, p_auditor, p_accountant, p_fundMgtCompany).stream()
//                    .map(suivi->SuiviDetailsMapper.toDto(suivi,p_typeGabarit)).toList();
//        }
//        if(p_typeGabarit==1) {
//            structureList=structureBusiness.getListeStructuresForNewSuivi(p_idTypeRapport, p_idLangue, p_idGabarit, p_dateEcheance,
//                    p_portfeuilles, p_auditor, p_accountant, p_fundMgtCompany).stream().map(SuiviStructureMapper::toDto).toList();
//        }
//        return new ValiderDTO(fondsList,structureList);
        }

    }

