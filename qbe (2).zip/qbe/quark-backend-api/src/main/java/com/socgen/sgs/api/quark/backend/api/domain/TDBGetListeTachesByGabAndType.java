package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TDBGetListeTachesByGabAndType {

    private Long idTache;
    private String commentaire;
    private Long idStatutSuiviDebut;
    private Long idStatutSuiviFin;

}