package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBStructures;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBStructuresDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBStructuresSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class TDBStructuresService implements TDBStructuresSerInterface {

    private final TDBStructuresDAO tdbStructuresDAO;

    @Autowired
    public TDBStructuresService(TDBStructuresDAO tdbStructuresDAO) {
        this.tdbStructuresDAO = tdbStructuresDAO;
    }

    @Override
    public List<TDBStructures> getListeSuivisTDBByStructures(
            Long p_idLangue,
            LocalDate p_dateEcheance,
            String p_structures,
            Long p_idMaquettiste,
            Long p_idStatutSuivi,
            Long p_idTypeRapport,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        return tdbStructuresDAO.getListeSuivisTDBByStructures(
                p_idLangue,
                p_dateEcheance,
                p_structures,
                p_idMaquettiste,
                p_idStatutSuivi,
                p_idTypeRapport,
                p_auditor,
                p_accountant,
                p_fundMgtCompany
        );
    }
}