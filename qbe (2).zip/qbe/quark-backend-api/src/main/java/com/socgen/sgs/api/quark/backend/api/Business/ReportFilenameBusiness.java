package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.FeatureExceptions.FeatureConfigurationException;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.AmundiFilenameMatch;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.DocumentFormat;
import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.ReportNamingContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

@Slf4j
@Component
public class ReportFilenameBusiness {

    private static final int ANNUAL_REPORT = 1;
    private static final int PLAQUETTE = 2;
    private static final int PROSPECTUS = 3;
    private static final int COMPARTMENT_REPORT = 4;
    private static final int DICI = 5;
    private static final int CERTIFIED_CAC_STATUS = 10;

    private static final DateTimeFormatter LEGACY_DATE = DateTimeFormatter.ofPattern("dd-MM-uuuu");
    private static final DateTimeFormatter AMUNDI_DATE = DateTimeFormatter.BASIC_ISO_DATE;

    private final boolean amundiNamingEnabled;

    public ReportFilenameBusiness(
            @Value("${quark.features.amundi-report-filename.enabled:true}")
            boolean amundiNamingEnabled) {
        this.amundiNamingEnabled = amundiNamingEnabled;
    }

    public boolean isAmundiCandidate(ReportNamingContext context) {
        return amundiNamingEnabled
                && context.fundBasedSuivi()
                && context.reportDate() != null
                && context.language() != null
                && (context.reportTypeId() == ANNUAL_REPORT
                || context.reportTypeId() == PLAQUETTE);
    }

    public String perimeterReportType(ReportNamingContext context) {
        return switch (context.reportTypeId()) {
            case ANNUAL_REPORT -> "RA";
            case PLAQUETTE -> "IS";
            default -> throw new IllegalArgumentException("Report is not an AMUNDI filename candidate");
        };
    }

    public String buildFilename(
            ReportNamingContext context,
            List<AmundiFilenameMatch> matches,
            DocumentFormat format) {

        if (isAmundiCandidate(context)) {
            if (matches.size() == 1 && isUsableAmundiMatch(context, matches.getFirst())) {
                return buildAmundiFilename(context, matches.getFirst(), format);
            }
            if (matches.size() > 1) {
                log.warn("AMUNDI filename fallback: duplicate matches for idSuivi={}", context.idSuivi());
            } else if (matches.size() == 1) {
                log.warn("AMUNDI filename fallback: unusable match for idSuivi={}", context.idSuivi());
            }
        }
        return buildLegacyFilename(context, format);
    }

    private boolean isUsableAmundiMatch(
            ReportNamingContext context,
            AmundiFilenameMatch match) {
        return match.reportDate() != null
                && isTwoLetterLanguage(match.reportLanguage())
                && hasText(context.fundName())
                && hasText(context.currency());
    }

    private String buildAmundiFilename(
            ReportNamingContext context,
            AmundiFilenameMatch match,
            DocumentFormat format) {

        String reportName = context.reportTypeId() == ANNUAL_REPORT
                ? "AnnualReport"
                : "PeriodicReport";
        String codeParapluie = match.codeParapluie() == null
                ? ""
                : sanitizeAmundiSegment(match.codeParapluie());

        if (codeParapluie.isEmpty()) {
            log.warn("AMUNDI filename contains an empty Code-Parapluie for idSuivi={}", context.idSuivi());
        }

        return reportName
                + "_" + sanitizeAmundiSegment(context.fundName())
                + "_" + codeParapluie
                + "_" + AMUNDI_DATE.format(match.reportDate())
                + "_FRA_" + match.reportLanguage().trim().toUpperCase(Locale.ROOT)
                + "_" + sanitizeAmundiSegment(context.currency().toUpperCase(Locale.ROOT))
                + "." + format.extension();
    }

    private String buildLegacyFilename(ReportNamingContext context, DocumentFormat format) {
        if (!hasText(context.fundCode()) || !hasText(context.fundName()) || context.reportDate() == null) {
            throw new FeatureConfigurationException(
                    "Required normal filename data is missing for idSuivi=" + context.idSuivi());
        }

        String separator = " - ";
        StringBuilder filename = new StringBuilder(sanitizeLegacyText(context.fundCode()));
        if (hasText(context.unitCode())) {
            filename.append(separator).append(sanitizeLegacyText(context.unitCode()));
        }
        filename.append(separator)
                .append(sanitizeLegacyText(context.fundName()))
                .append(separator)
                .append(LEGACY_DATE.format(context.reportDate()))
                .append(separator)
                .append(legacyReportCode(context.reportTypeId()));

        if (usesLanguage(context.reportTypeId())) {
            if (!hasText(context.language())) {
                throw new FeatureConfigurationException(
                        "Report language is missing for idSuivi=" + context.idSuivi());
            }
            filename.append(separator).append(sanitizeLegacyText(context.language()));
        }
        if (context.statusId() == CERTIFIED_CAC_STATUS) {
            filename.append(separator).append("C");
        }
        filename.append('.').append(format.extension());
        return filename.toString();
    }

    private String legacyReportCode(int reportTypeId) {
        return switch (reportTypeId) {
            case ANNUAL_REPORT -> "RA";
            case PLAQUETTE -> "IP";
            case PROSPECTUS -> "PB";
            case COMPARTMENT_REPORT -> "RC";
            case DICI -> "DICI";
            default -> throw new FeatureConfigurationException(
                    "Unsupported report type id=" + reportTypeId);
        };
    }

    private boolean usesLanguage(int reportTypeId) {
        return reportTypeId == ANNUAL_REPORT
                || reportTypeId == PLAQUETTE
                || reportTypeId == DICI;
    }

    private boolean isTwoLetterLanguage(String value) {
        return value != null && value.trim().toUpperCase(Locale.ROOT).matches("[A-Z]{2}");
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private String sanitizeLegacyText(String value) {
        return value.trim()
                .replace('/', '-')
                .replace('\\', '-')
                .replace('\r', ' ')
                .replace('\n', ' ');
    }

    private String sanitizeAmundiSegment(String value) {
        return value.trim()
                .replaceAll("[\\p{Cntrl}\\\\/:*?\"<>|]", "-")
                .replaceAll("[\\p{Z}\\s]+", "-")
                .replaceAll("-+", "-")
                .replaceAll("^-|-$", "");
    }
}