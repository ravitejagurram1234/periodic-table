package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBFondsPart;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBFondsPartDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBFondsPartSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class TDBFondsPartService implements TDBFondsPartSerInterface {

    private final TDBFondsPartDAO tdbFondsPartDAO;

    @Autowired
    public TDBFondsPartService(TDBFondsPartDAO tdbFondsPartDAO) {
        this.tdbFondsPartDAO = tdbFondsPartDAO;
    }

    @Override
    public List<TDBFondsPart> getListeSuivisTDBByFondsPart(
            Long p_idLangue,
            LocalDate p_dateEcheance,
            String p_portefeuilles,
            Long p_idMaquettiste,
            Long p_idStatutSuivi,
            Long p_idTypeRapport,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        return tdbFondsPartDAO.getListeSuivisTDBByFondsPart(
                p_idLangue,
                p_dateEcheance,
                p_portefeuilles,
                p_idMaquettiste,
                p_idStatutSuivi,
                p_idTypeRapport,
                p_auditor,
                p_accountant,
                p_fundMgtCompany
        );
    }
}