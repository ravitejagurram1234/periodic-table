package com.socgen.sgs.api.quark.backend.api.Constantes;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Enums {

    // Ressource section
    public enum RS {
        Global,
        TypeRapport
    }


    public enum StatutGeneration {
        Blanc(0),
        AGenerer(1),
        Genere(2),
        EnErreur(3);

        private final int value;

        StatutGeneration(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    // Roles possible des utilisateurs du site
    public enum Roles {
        Utilisateur(1),
        Maquettiste(2),
        Admin(3),
        Fiscalite(4);

        private final int value;

        Roles(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    // Type de document que le générateur peut produire
    public enum TypeDocument {
        QXP(1),
        PDF(2),
        DOC(3);

        private final int value;

        TypeDocument(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }


    public enum TypePublication {
        Aucune(Integer.MIN_VALUE),
        En_cours(1),
        En_cours_interne(2),
        Final(3);

        private final int value;

        TypePublication(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }


    public enum SuiviSortExpression {
        Choix,
        StatutSuivi,
        CodePortefeuille,
        LibelleLongPortefeuille,
        LibellePortefeuille,
        Part,
        CabinetGestion,
        GroupeComptable,
        DateClotureLast,
        DateClotureNext,
        Classification,
        SocieteGestion,
        TypeFonds,
        TypeRapport,
        DateDocument,
        DateEcheance,
        Langue,
        CAC,
        Maquettiste,
        Gabarit,
        Code
    }


    public enum TypeRapport {
        Undefined(-1),
        All(0),
        RapportAnnuel(1),
        Plaquette(2),
        Prospectus(3),
        RapportCompartiment(4),
        DICI(5);

        private final int value;

        TypeRapport(int value) {
            this.value = value;
        }

        public static TypeRapport fromValue(int value) {
            for (TypeRapport rapport : values()) {
                if (rapport.getValue() == value) {
                    return rapport;
                }
            }
            throw new IllegalArgumentException("Invalid rapport ID: " + value);
        }
        public int getValue() {
            return value;
        }
    }


    public enum TypeGabarit {
        Fonds_simple(0),
        Structure(1),
        FondsPart(2);

        private final int value;

        TypeGabarit(int value) {
            this.value = value;
        }

        public static TypeGabarit fromValue(int value) {
            for (TypeGabarit rapport : values()) {
                if (rapport.getValue() == value) {
                    return rapport;
                }
            }
            throw new IllegalArgumentException("Invalid rapport ID: " + value);
        }
        public int getValue() {
            return value;
        }
    }

    // Type de catégorie de document
    public enum TypeCategorieDocument {
        Portefeuille(1),
        Societe(2),
        Autre(99),
        Part(3);

        private final int value;

        TypeCategorieDocument(int value) {
            this.value = value;
        }

        public static TypeCategorieDocument fromString(String idCategorie) {
            if (idCategorie == null) {
                throw new IllegalArgumentException("Input cannot be null");
            }

            for (TypeCategorieDocument type : TypeCategorieDocument.values()) {
                if (type.name().equalsIgnoreCase(idCategorie)) {
                    return type;
                }
            }

            throw new IllegalArgumentException("No enum constant for input: " + idCategorie);
        }


        public int getValue() {
            return value;
        }
    }

    // Type de données de l'événement
    public enum EventDataType {
        Undefined(-1),
        SGSS(1),
        CLIENT(2);

        private final int value;

        EventDataType(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    // Enumeration des différentes dépendances des événements disponibles
    public enum EventDependency {
        Interne,
        Tiers,
        CAC
    }

    // Flags des différents types d'événements
    public enum EventType {
        Undefined(0),
        EventCheck(1),
        EventDateEcheance(2),
        ListEventDataType(4);

        private final int value;

        EventType(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }


    public static EventType fromValue(int value) {
        for (EventType type : EventType.values()) {
            if (type.getValue() == value) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown EventType value: " + value);
    }
    }

    public enum TypeSuivi {
        Undefined(0),
        Standard(1),
        Traduction(2);

        private final int value;

        TypeSuivi(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    public enum pagination {
        Simple(1),
        Double(2);



        private final int value;

        pagination(int value) {
            this.value = value;
        }

        public int getValue() { return value;
        }
    }





}

