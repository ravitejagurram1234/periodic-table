package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertParFondsDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class InsertParFondsBusiness {

    private final InsertParFondsDao insertParFondsDao;

    public InsertParFondsBusiness(InsertParFondsDao insertParFondsDao) {
        this.insertParFondsDao = insertParFondsDao;
    }

    public void InsertParFonds(Document document) {
        insertParFondsDao.insertParFonds(document);
    }
}