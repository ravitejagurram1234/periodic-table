package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.CompartimentsDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.CompartimentMapper;
import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateCompartimentsDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UpdateCompartimentsBusiness {

    private final UpdateCompartimentsDao updateCompartimentsDao;

    public UpdateCompartimentsBusiness(UpdateCompartimentsDao updateCompartimentsDao) {
        this.updateCompartimentsDao = updateCompartimentsDao;
    }

    public void updateCompartimentInfos(CompartimentsDTO dto) {
        Compartiment compartiment = CompartimentMapper.toDomain(dto);
        updateCompartimentsDao.updateCompartimentInfos(compartiment);
    }
}