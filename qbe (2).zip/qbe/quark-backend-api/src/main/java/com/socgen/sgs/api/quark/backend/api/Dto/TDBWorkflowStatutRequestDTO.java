package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TDBWorkflowStatutRequestDTO {

    private Long idStatutFrom;

    private Long typeRapport;

    private Long typeSuivi;
}