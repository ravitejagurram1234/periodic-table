package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.SuiviEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SuiviEventDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SuiviEventsBusiness {

    private final SuiviEventDao suiviEventDao;

    public SuiviEventsBusiness(SuiviEventDao suiviEventDao) {
        this.suiviEventDao = suiviEventDao;
    }

    public List<SuiviEvents> getSuiviEvents(Long p_idSuivi) {
        return suiviEventDao.getSuiviEvents(p_idSuivi);
    }
}
