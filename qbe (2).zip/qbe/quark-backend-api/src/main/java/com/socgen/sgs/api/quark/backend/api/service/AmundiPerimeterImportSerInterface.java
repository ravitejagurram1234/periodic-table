package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiDateFormat;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportMode;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportTemplateConfiguration;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportValidationResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.UploadedFile;

public interface AmundiPerimeterImportSerInterface {

    AmundiImportTemplateConfiguration configuration();

    AmundiImportValidationResult validate(
            UploadedFile file,
            AmundiDateFormat dateFormat,
            String userEmail,
            String clientIp);

    AmundiImportResult importFile(
            UploadedFile file,
            AmundiDateFormat dateFormat,
            AmundiImportMode mode,
            String expectedChecksum,
            String userEmail,
            String clientIp);
}