package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PortfolioSelectedDao;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.GabaritRepository;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class PortfolioSelectedBusiness {

    private final PortfolioSelectedDao portfolioSelectedDao;
    private final GabaritRepository gabaritRepository;

    public PortfolioSelectedBusiness(
            PortfolioSelectedDao portfolioSelectedDao,
            GabaritRepository gabaritRepository) {
        this.portfolioSelectedDao = portfolioSelectedDao;
        this.gabaritRepository = gabaritRepository;
    }

    public List<portefeuilleDTO> getSelectedPortfolios(
            Long p_idTypeRapport,
            Long p_idGabarit,
            Long p_idLangue,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        if (p_idTypeRapport == null) {
            throw new IllegalArgumentException("p_idTypeRapport is required");
        }
        if (p_idGabarit == null) {
            throw new IllegalArgumentException("p_idGabarit is required");
        }
        if (p_idLangue == null) {
            throw new IllegalArgumentException("p_idLangue is required");
        }

        if (p_idTypeRapport == 4L) {
            return portfolioSelectedDao.getListeCompartsByGabarit(
                    p_idTypeRapport, p_idGabarit, p_idLangue);
        }

        QxpGabarit gabarit = gabaritRepository.findByGabaritId(p_idGabarit);

        if (gabarit == null) {
            throw new IllegalArgumentException(
                    "Gabarit not found for p_idGabarit: " + p_idGabarit);
        }

        if (gabarit.getType() == null) {
            throw new IllegalArgumentException(
                    "Type not set for p_idGabarit: " + p_idGabarit);
        }

        int resolvedTypeGabarit = Integer.parseInt(gabarit.getType());

        if (resolvedTypeGabarit == 0 || resolvedTypeGabarit == 2) {
            return portfolioSelectedDao.getFondsSimplesByGabarit(
                    p_idTypeRapport,
                    p_idGabarit,
                    p_idLangue,
                    p_auditor,
                    p_accountant,
                    p_fundMgtCompany);
        }

        if (resolvedTypeGabarit == 1) {
            return portfolioSelectedDao.getListeStructuresByGabarit(
                    p_idTypeRapport,
                    p_idGabarit,
                    p_idLangue,
                    p_auditor,
                    p_accountant,
                    p_fundMgtCompany);
        }

        throw new IllegalArgumentException(
                "Unsupported typeGabarit: " + resolvedTypeGabarit +
                        " for p_idGabarit: " + p_idGabarit);
    }
}