package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.portefeuilleDTO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.PortfolioAccessibleDao;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository.GabaritRepository;
import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import jakarta.persistence.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

@Service
@Cacheable
@Transactional(readOnly = true)
public class PortfolioAccessibleBusiness {

    private final PortfolioAccessibleDao portfolioAccessibleDao;
    private final GabaritRepository gabaritRepository;

    public PortfolioAccessibleBusiness(
            PortfolioAccessibleDao portfolioAccessibleDao,
            GabaritRepository gabaritRepository) {
        this.portfolioAccessibleDao = portfolioAccessibleDao;
        this.gabaritRepository = gabaritRepository;
    }

    public List<portefeuilleDTO> getAccessiblePortfolios(
            Long p_idTypeRapport,
            Long p_idGabarit,
            Long p_idLangue,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        if (p_idTypeRapport == null) {
            throw new IllegalArgumentException("p_idTypeRapport is required");
        }
        if (p_idLangue == null) {
            throw new IllegalArgumentException("p_idLangue is required");
        }
        if (p_idGabarit == null) {
            throw new IllegalArgumentException("p_idGabarit is required");
        }

        if (p_idTypeRapport == 4L) {
            return portfolioAccessibleDao.getListeCompartNonDispos(
                    p_auditor,
                    p_accountant,
                    p_fundMgtCompany);
        }

        QxpGabarit gabarit = gabaritRepository.findByGabaritId(p_idGabarit);

        if (gabarit == null) {
            throw new IllegalArgumentException(
                    "Gabarit not found for p_idGabarit: " + p_idGabarit);
        }

        if (gabarit.getType() == null) {
            throw new IllegalArgumentException(
                    "Type not set for p_idGabarit: " + p_idGabarit);
        }

        int resolvedTypeGabarit = Integer.parseInt(gabarit.getType());

        if (resolvedTypeGabarit == 0 || resolvedTypeGabarit == 2) {
            List<portefeuilleDTO> fonds = portfolioAccessibleDao.getFondsSimples(
                    p_auditor,
                    p_accountant,
                    p_fundMgtCompany);

            fonds.sort(
                    Comparator.comparing(
                            portefeuilleDTO::getId_fnd_code,
                            FondsCodeComparator.INSTANCE));

            return fonds;
        }

        if (resolvedTypeGabarit == 1) {
            return portfolioAccessibleDao.getListeStructures(
                    p_auditor,
                    p_accountant,
                    p_fundMgtCompany);
        }

        throw new IllegalArgumentException(
                "Unsupported typeGabarit: " + resolvedTypeGabarit
                        + " for p_idGabarit: " + p_idGabarit);
    }
}