package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiPerimeterRecord;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AmundiPerimeterDao;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Repository
@RequiredArgsConstructor
public class SimpleJDBCAmundiPerimeter implements AmundiPerimeterDao {

    private static final int ORACLE_IN_LIMIT_SAFE_CHUNK = 900;

    private static final String COLUMN_METADATA_SQL = """
            SELECT COLUMN_NAME, CHAR_LENGTH
            FROM USER_TAB_COLUMNS
            WHERE TABLE_NAME = 'QXP_AMUNDI_PERIMETER'
            """;

    private static final String FUND_LOOKUP_SQL = """
            SELECT DISTINCT rf.ID_FND_CODE
            FROM OWB_DWH.REF_FUND rf
            WHERE rf.ID_FND_CODE IN (:fundCodes)
              AND rf.FND_END_VALIDITY = TO_DATE('31/12/2199', 'DD/MM/YYYY')
            """;

    private static final String DELETE_SQL = """
            DELETE FROM QXP_AMUNDI_PERIMETER
            WHERE FUND_NAME = ?
              AND REPORT_DATE = ?
              AND REPORT_LANGUAGE = ?
            """;

    private static final String INSERT_SQL = """
            INSERT INTO QXP_AMUNDI_PERIMETER (
                FUND_LABEL, ID_FUND_BWR, DECALOG, FUND_NAME, REPORT_TYPE,
                REPORT_DATE, REPORT_LANGUAGE, LEGAL_FORM, EUROPEAN_NORM,
                ENGAGEMENT_METHOD, CODE_PARAPLUIE
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

    private static final String UPDATE_SQL = """
            UPDATE QXP_AMUNDI_PERIMETER
            SET FUND_LABEL = ?,
                ID_FUND_BWR = ?,
                DECALOG = ?,
                REPORT_TYPE = ?,
                LEGAL_FORM = ?,
                EUROPEAN_NORM = ?,
                ENGAGEMENT_METHOD = ?,
                CODE_PARAPLUIE = ?
            WHERE FUND_NAME = ?
              AND REPORT_DATE = ?
              AND REPORT_LANGUAGE = ?
            """;

    private final JdbcTemplate jdbcTemplate;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public Map<String, Integer> findLiveColumnLengths() {
        Map<String, Integer> result = new HashMap<>();
        jdbcTemplate.query(COLUMN_METADATA_SQL, resultSet -> {
            Number length = (Number) resultSet.getObject("CHAR_LENGTH");
            result.put(resultSet.getString("COLUMN_NAME"), length == null ? null : length.intValue());
        });
        return result;
    }

    @Override
    public Set<String> findExistingFundCodes(Set<String> fundCodes) {
        if (fundCodes.isEmpty()) {
            return Set.of();
        }

        List<String> allCodes = new ArrayList<>(fundCodes);
        Set<String> existing = new HashSet<>();
        for (int start = 0; start < allCodes.size(); start += ORACLE_IN_LIMIT_SAFE_CHUNK) {
            int end = Math.min(start + ORACLE_IN_LIMIT_SAFE_CHUNK, allCodes.size());
            MapSqlParameterSource parameters = new MapSqlParameterSource(
                    "fundCodes", allCodes.subList(start, end));
            existing.addAll(namedParameterJdbcTemplate.queryForList(
                    FUND_LOOKUP_SQL, parameters, String.class));
        }
        return existing;
    }

    @Override
    public int deleteMatching(List<AmundiPerimeterRecord> records) {
        return affectedRows(jdbcTemplate.batchUpdate(DELETE_SQL, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement statement, int index) throws SQLException {
                AmundiPerimeterRecord row = records.get(index);
                statement.setString(1, row.fundName());
                statement.setDate(2, Date.valueOf(row.reportDate()));
                statement.setString(3, row.reportLanguage());
            }

            @Override
            public int getBatchSize() {
                return records.size();
            }
        }));
    }

    @Override
    public int insert(List<AmundiPerimeterRecord> records) {
        return affectedRows(jdbcTemplate.batchUpdate(INSERT_SQL, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement statement, int index) throws SQLException {
                AmundiPerimeterRecord row = records.get(index);
                statement.setString(1, row.fundLabel());
                statement.setString(2, row.idFundBwr());
                statement.setString(3, row.decalog());
                statement.setString(4, row.fundName());
                statement.setString(5, row.reportType());
                statement.setDate(6, Date.valueOf(row.reportDate()));
                statement.setString(7, row.reportLanguage());
                statement.setString(8, row.legalForm());
                statement.setString(9, row.europeanNorm());
                setNullableString(statement, 10, row.engagementMethod());
                setNullableString(statement, 11, row.codeParapluie());
            }

            @Override
            public int getBatchSize() {
                return records.size();
            }
        }));
    }

    @Override
    public int update(List<AmundiPerimeterRecord> records) {
        return affectedRows(jdbcTemplate.batchUpdate(UPDATE_SQL, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement statement, int index) throws SQLException {
                AmundiPerimeterRecord row = records.get(index);
                statement.setString(1, row.fundLabel());
                statement.setString(2, row.idFundBwr());
                statement.setString(3, row.decalog());
                statement.setString(4, row.reportType());
                statement.setString(5, row.legalForm());
                statement.setString(6, row.europeanNorm());
                setNullableString(statement, 7, row.engagementMethod());
                setNullableString(statement, 8, row.codeParapluie());
                statement.setString(9, row.fundName());
                statement.setDate(10, Date.valueOf(row.reportDate()));
                statement.setString(11, row.reportLanguage());
            }

            @Override
            public int getBatchSize() {
                return records.size();
            }
        }));
    }

    private void setNullableString(PreparedStatement statement, int position, String value)
            throws SQLException {
        if (value == null || value.isBlank()) {
            statement.setNull(position, Types.VARCHAR);
        } else {
            statement.setString(position, value);
        }
    }

    private int affectedRows(int[] counts) {
        int total = 0;
        for (int count : counts) {
            if (count > 0) {
                total += count;
            } else if (count == Statement.SUCCESS_NO_INFO) {
                total++;
            }
        }
        return total;
    }
}