package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TDBGetListeTachesByGabaritDTO {

    private Long idTache;
    private String commentaire;
    private Long idStatutSuiviDebut;
    private Long idStatutSuiviFin;
    private Long idTypeTache;
}