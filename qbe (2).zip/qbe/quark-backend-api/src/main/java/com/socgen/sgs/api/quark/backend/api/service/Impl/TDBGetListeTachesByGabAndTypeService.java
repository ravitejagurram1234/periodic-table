package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeTachesByGabAndType;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBGetListeTachesByGabAndTypeDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBGetListeTachesByGabAndTypeSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TDBGetListeTachesByGabAndTypeService
        implements TDBGetListeTachesByGabAndTypeSerInterface {

    private final TDBGetListeTachesByGabAndTypeDAO dao;

    @Autowired
    public TDBGetListeTachesByGabAndTypeService(
            TDBGetListeTachesByGabAndTypeDAO dao) {

        this.dao = dao;
    }

    @Override
    public List<TDBGetListeTachesByGabAndType>
    getListeTachesByGabAndType(
            Long p_idGabarit,
            Long p_idTypeTache) {

        return dao.getListeTachesByGabAndType(
                p_idGabarit,
                p_idTypeTache
        );
    }
}