package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class GabaritBusiness {

    private final GabaritDao gabaritDao;

    public GabaritBusiness(GabaritDao gabaritDao) {
        this.gabaritDao = gabaritDao;
    }

    public Gabarit getGabarit(Long p_idGabarit) {
        return gabaritDao.getGabarit(p_idGabarit);
    }
}