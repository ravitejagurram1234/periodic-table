package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TDBStructures;

import java.time.LocalDate;
import java.util.List;

public interface TDBStructuresDAO {

    List<TDBStructures> getListeSuivisTDBByStructures(
            Long p_idLangue,
            LocalDate p_dateEcheance,
            String p_structures,
            Long p_idMaquettiste,
            Long p_idStatutSuivi,
            Long p_idTypeRapport,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany
    );
}