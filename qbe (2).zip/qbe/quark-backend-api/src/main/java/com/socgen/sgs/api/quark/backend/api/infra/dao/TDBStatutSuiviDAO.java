package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TDBStatutSuivi;

import java.util.List;

public interface TDBStatutSuiviDAO {

    List<TDBStatutSuivi> getListeStatutsSuivi();

}