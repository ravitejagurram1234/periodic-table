package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteLangueDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class ModificationParSocieteLangueBusiness {

    private final ModificationParSocieteLangueDao modificationParSocieteLangueDao;

    public ModificationParSocieteLangueBusiness(
            ModificationParSocieteLangueDao modificationParSocieteLangueDao) {
        this.modificationParSocieteLangueDao = modificationParSocieteLangueDao;
    }

    public List<ModificationParFondsLangue> getLangues(
            String p_societe,
            int p_id_sous_categorie,
            LocalDate p_date_document) {

        return modificationParSocieteLangueDao.getLangues(
                p_societe,
                p_id_sous_categorie,
                p_date_document);
    }
}