package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TDBGetListeEventsByGabarit {

    private Long idEvent;

    private TDBGetListeEventsByGabarit(Builder builder) {
        this.idEvent = builder.idEvent;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {

        private Long idEvent;

        public Builder idEvent(Long idEvent) {
            this.idEvent = idEvent;
            return this;
        }

        public TDBGetListeEventsByGabarit build() {
            return new TDBGetListeEventsByGabarit(this);
        }
    }
}