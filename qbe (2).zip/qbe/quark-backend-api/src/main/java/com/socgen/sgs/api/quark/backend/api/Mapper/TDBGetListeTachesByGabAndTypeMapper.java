package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBGetListeTachesByGabAndTypeDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeTachesByGabAndType;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TDBGetListeTachesByGabAndTypeMapper {

    public static TDBGetListeTachesByGabAndType mapResult(ResultSet rs)
            throws SQLException {

        TDBGetListeTachesByGabAndType tache =
                new TDBGetListeTachesByGabAndType();

        tache.setIdTache(
                rs.getLong("ID_TACHE")
        );

        tache.setCommentaire(
                rs.getString("COMMENTAIRE")
        );

        tache.setIdStatutSuiviDebut(
                rs.getLong("ID_STATUT_SUIVI_DEBUT")
        );

        tache.setIdStatutSuiviFin(
                rs.getLong("ID_STATUT_SUIVI_FIN")
        );

        return tache;
    }

    public static TDBGetListeTachesByGabAndTypeDTO toDto(
            TDBGetListeTachesByGabAndType tache) {

        return new TDBGetListeTachesByGabAndTypeDTO(
                tache.getIdTache(),
                tache.getCommentaire(),
                tache.getIdStatutSuiviDebut(),
                tache.getIdStatutSuiviFin()
        );
    }
}