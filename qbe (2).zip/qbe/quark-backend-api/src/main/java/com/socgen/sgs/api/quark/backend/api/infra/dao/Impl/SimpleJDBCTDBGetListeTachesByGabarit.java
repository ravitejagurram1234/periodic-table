package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.TDBGetListeTachesByGabaritMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeTachesByGabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBGetListeTachesByGabaritDAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCTDBGetListeTachesByGabarit
        implements TDBGetListeTachesByGabaritDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBGetListeTachesByGabarit(
            DataSource dataSource) {

        this.simpleJdbcCall =
                new SimpleJdbcCall(dataSource)
                        .withCatalogName("QXP_PK_SUIVI")
                        .withFunctionName("GetListeTachesByGabarit")
                        .withoutProcedureColumnMetaDataAccess()
                        .declareParameters(
                                new SqlParameter(
                                        "p_idGabarit",
                                        Types.NUMERIC
                                ),
                                new SqlOutParameter(
                                        "RETURN_VALUE",
                                        OracleTypes.CURSOR,
                                        (rs, rowNum) ->
                                                TDBGetListeTachesByGabaritMapper
                                                        .mapResult(rs)
                                )
                        );
    }

    @Override
    public List<TDBGetListeTachesByGabarit>
    getListeTachesByGabarit(
            Long p_idGabarit) {

        Map<String, Object> result =
                simpleJdbcCall.execute(
                        Map.of(
                                "p_idGabarit",
                                p_idGabarit
                        )
                );

        return (List<TDBGetListeTachesByGabarit>)
                result.get("RETURN_VALUE");
    }
}