package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBInsertRunDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBInsertRunSerInterface;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class TDBInsertRunService
        implements TDBInsertRunSerInterface {

    private final TDBInsertRunDAO dao;

    public TDBInsertRunService(
            TDBInsertRunDAO dao) {

        this.dao = dao;
    }

    @Override
    public Long insertRun(
            Long p_idSuivi,
            LocalDateTime p_datePlanification,
            Long p_gabarit_source,
            Long p_idCreateur,
            String p_email,
            Long p_integrerN1,
            Long p_modeCompart,
            Long p_idSuiviSrc) {

        return dao.insertRun(
                p_idSuivi,
                p_datePlanification,
                p_gabarit_source,
                p_idCreateur,
                p_email,
                p_integrerN1,
                p_modeCompart,
                p_idSuiviSrc
        );
    }
}