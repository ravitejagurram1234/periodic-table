package com.socgen.sgs.api.quark.backend.api.service.Impl;



import com.socgen.sgs.api.quark.backend.api.domain.TDBDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBDocumentDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBDocumentSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TDBDocumentService implements TDBDocumentSerInterface {

    private final TDBDocumentDAO tdbDocumentDAO;

    @Autowired
    public TDBDocumentService(TDBDocumentDAO tdbDocumentDAO) {
        this.tdbDocumentDAO = tdbDocumentDAO;
    }

    @Override
    public TDBDocument getContenuDocument(
            Long p_idSuivi,
            Long p_idTypeDocument) {

        return tdbDocumentDAO.getContenuDocument(
                p_idSuivi,
                p_idTypeDocument
        );
    }
}