package com.socgen.sgs.api.quark.backend.api.infra.dao;

import java.time.LocalDateTime;

public interface TDBInsertRunDAO {

    Long insertRun(
            Long p_idSuivi,
            LocalDateTime p_datePlanification,
            Long p_gabarit_source,
            Long p_idCreateur,
            String p_email,
            Long p_integrerN1,
            Long p_modeCompart,
            Long p_idSuiviSrc
    );
}