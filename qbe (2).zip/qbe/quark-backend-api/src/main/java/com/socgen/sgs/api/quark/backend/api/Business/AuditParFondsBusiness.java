package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AuditParFondsDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AuditParFondsBusiness {

    private final AuditParFondsDao auditParFondsDao;

    public AuditParFondsBusiness(AuditParFondsDao auditParFondsDao) {
        this.auditParFondsDao = auditParFondsDao;
    }

    public Integer AuditParFonds(Audit audit) {
        return auditParFondsDao.insertAudit(audit);
    }
}