package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBUpdateMaquettisteDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.TDBUpdateMaquettisteMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBUpdateMaquettiste;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBUpdateMaquettisteDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBUpdateMaquettisteSerInterface;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TDBUpdateMaquettisteService
        implements TDBUpdateMaquettisteSerInterface {

    private final TDBUpdateMaquettisteDAO
            tdbUpdateMaquettisteDAO;

    public TDBUpdateMaquettisteService(
            TDBUpdateMaquettisteDAO tdbUpdateMaquettisteDAO) {

        this.tdbUpdateMaquettisteDAO =
                tdbUpdateMaquettisteDAO;
    }

    @Override
    @Transactional(
            rollbackFor = Exception.class
    )
    public void updateMaquettiste(
            TDBUpdateMaquettisteDTO request) {

        try {

            TDBUpdateMaquettiste domain =
                    TDBUpdateMaquettisteMapper
                            .toDomain(request);

            tdbUpdateMaquettisteDAO
                    .updateMaquettiste(domain);

        } catch (Exception ex) {

            throw new RuntimeException(
                    "Erreur lors de la mise à jour du maquettiste : "
                            + ex.getMessage(),
                    ex
            );
        }
    }
}