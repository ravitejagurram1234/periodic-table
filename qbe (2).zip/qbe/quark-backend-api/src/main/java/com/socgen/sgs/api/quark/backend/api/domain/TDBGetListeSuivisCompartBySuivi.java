package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TDBGetListeSuivisCompartBySuivi {

    private Long idSuivi;
    private String idFndCode;
    private LocalDate dateEcheance;
    private String dateEcheanceExacte;
    private Long idMaquettiste;
    private Long idGabarit;
    private Long idTypeRapport;

    private TDBGetListeSuivisCompartBySuivi(Builder builder) {
        this.idSuivi = builder.idSuivi;
        this.idFndCode = builder.idFndCode;
        this.dateEcheance = builder.dateEcheance;
        this.dateEcheanceExacte = builder.dateEcheanceExacte;
        this.idMaquettiste = builder.idMaquettiste;
        this.idGabarit = builder.idGabarit;
        this.idTypeRapport = builder.idTypeRapport;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {

        private Long idSuivi;
        private String idFndCode;
        private LocalDate dateEcheance;
        private String dateEcheanceExacte;
        private Long idMaquettiste;
        private Long idGabarit;
        private Long idTypeRapport;

        public Builder idSuivi(Long idSuivi) {
            this.idSuivi = idSuivi;
            return this;
        }

        public Builder idFndCode(String idFndCode) {
            this.idFndCode = idFndCode;
            return this;
        }

        public Builder dateEcheance(LocalDate dateEcheance) {
            this.dateEcheance = dateEcheance;
            return this;
        }

        public Builder dateEcheanceExacte(String dateEcheanceExacte) {
            this.dateEcheanceExacte = dateEcheanceExacte;
            return this;
        }

        public Builder idMaquettiste(Long idMaquettiste) {
            this.idMaquettiste = idMaquettiste;
            return this;
        }

        public Builder idGabarit(Long idGabarit) {
            this.idGabarit = idGabarit;
            return this;
        }

        public Builder idTypeRapport(Long idTypeRapport) {
            this.idTypeRapport = idTypeRapport;
            return this;
        }

        public TDBGetListeSuivisCompartBySuivi build() {
            return new TDBGetListeSuivisCompartBySuivi(this);
        }
    }
}