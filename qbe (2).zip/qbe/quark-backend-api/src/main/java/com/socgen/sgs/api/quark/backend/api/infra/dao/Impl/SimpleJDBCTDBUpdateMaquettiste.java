package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBUpdateMaquettiste;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBUpdateMaquettisteDAO;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Repository
public class SimpleJDBCTDBUpdateMaquettiste
        implements TDBUpdateMaquettisteDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    public SimpleJDBCTDBUpdateMaquettiste(
            DataSource dataSource) {

        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withProcedureName("UpdateMaquettiste");
    }

    @Override
    public void updateMaquettiste(
            TDBUpdateMaquettiste request) {

        Map<String, Object> params =
                new HashMap<>();

        params.put(
                "p_id_suivi",
                request.getIdSuivi()
        );

        params.put(
                "p_id_maquettiste",
                request.getIdMaquettiste()
        );

        simpleJdbcCall.execute(params);
    }
}