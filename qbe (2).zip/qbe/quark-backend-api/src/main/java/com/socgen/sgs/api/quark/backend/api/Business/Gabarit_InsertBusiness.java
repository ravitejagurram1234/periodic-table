package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.Gabarit_InsertDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class Gabarit_InsertBusiness {

    private final Gabarit_InsertDao gabaritInsertDao;

    public Gabarit_InsertBusiness(Gabarit_InsertDao gabaritInsertDao) {
        this.gabaritInsertDao = gabaritInsertDao;
    }

    public Integer insertGabarit(Chargement_gabarit gabarit) {
        return gabaritInsertDao.insertGabarit(gabarit);
    }
}