package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Societe;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SocieteDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SocieteBusiness {

    private final SocieteDao societeDao;

    public SocieteBusiness(SocieteDao societeDao) {
        this.societeDao = societeDao;
    }

    public List<Societe> getSociete() {
        return societeDao.getSociete();
    }
}