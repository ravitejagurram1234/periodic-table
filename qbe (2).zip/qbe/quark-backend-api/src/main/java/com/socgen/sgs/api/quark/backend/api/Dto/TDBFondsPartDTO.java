package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TDBFondsPartDTO {

    private String idFndCode;
    private Long idSuivi;
    private Long idRunPrecedent;
    private Long idRunAno;
    private String fndShtDescription;
    private Long idGabarit;
    private String nomGabarit;
    private LocalDate dateEcheance;
    private String trigramme;
    private LocalDate dateLastEcheance;
    private String libelleFond;
    private String fndMngtCompany;
    private String unitIdInsCode;
    private String libelleClasse;
    private Integer typeSuivi;
    private String fndAccountant;
    private String fndAuditor;
    private Long idStatutGeneration;
    private Integer isLocked;
    private Integer idStatutSuivi;

}