package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBInsertRunDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBInsertRun;

public class TDBInsertRunMapper {

    public static TDBInsertRunDTO toDto(
            TDBInsertRun run) {

        return new TDBInsertRunDTO(
                run.getIdRun()
        );
    }
}