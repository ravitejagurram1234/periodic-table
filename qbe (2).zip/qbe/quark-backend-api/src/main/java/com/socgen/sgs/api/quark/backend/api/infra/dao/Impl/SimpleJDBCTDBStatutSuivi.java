package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.TDBStatutSuiviMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBStatutSuivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBStatutSuiviDAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCTDBStatutSuivi implements TDBStatutSuiviDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBStatutSuivi(DataSource dataSource) {

        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetListeStatutsSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(
                                "RETURN_VALUE",
                                OracleTypes.CURSOR,
                                (rs, rowNum) ->
                                        TDBStatutSuiviMapper.mapResult(rs)
                        )
                );
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<TDBStatutSuivi> getListeStatutsSuivi() {

        try {

            Map<String, Object> result =
                    simpleJdbcCall.execute();

            return (List<TDBStatutSuivi>)
                    result.get("RETURN_VALUE");

        } catch (Exception e) {

            System.err.println(
                    "Error during JDBC call : "
                            + e.getMessage()
            );

            e.printStackTrace();

            return Collections.emptyList();
        }
    }
}