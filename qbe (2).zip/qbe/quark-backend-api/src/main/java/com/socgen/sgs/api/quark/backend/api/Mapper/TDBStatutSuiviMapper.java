package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBStatutSuiviDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBStatutSuivi;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TDBStatutSuiviMapper {

    public static TDBStatutSuivi mapResult(ResultSet rs) throws SQLException {

        TDBStatutSuivi statutSuivi = new TDBStatutSuivi();

        statutSuivi.setIdStatutSuivi(rs.getLong("ID_STATUT_SUIVI"));

        statutSuivi.setTraductionCode(rs.getString("TRADUCTION_CODE"));

        statutSuivi.setTypeSuivi(rs.getLong("TYPE_SUIVI"));

        return statutSuivi;
    }

    public static TDBStatutSuiviDTO toDto(
            TDBStatutSuivi statutSuivi) {

        return new TDBStatutSuiviDTO(
                statutSuivi.getIdStatutSuivi(),
                statutSuivi.getTraductionCode()

        );
    }
}