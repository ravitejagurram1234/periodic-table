package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBCheckIfRunsEnCoursDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBCheckIfRunsEnCours;

import java.sql.ResultSet;
import java.sql.SQLException;

public final class TDBCheckIfRunsEnCoursMapper {

    private TDBCheckIfRunsEnCoursMapper() {
    }

    public static TDBCheckIfRunsEnCours mapResult(
            ResultSet rs) throws SQLException {

        TDBCheckIfRunsEnCours result =
                new TDBCheckIfRunsEnCours();

        result.setIdFndCode(
                rs.getString("ID_FND_CODE")
        );

        result.setIdUnitCode(
                rs.getString("ID_UNIT_CODE")
        );

        return result;
    }

    public static TDBCheckIfRunsEnCoursDTO toDto(
            TDBCheckIfRunsEnCours domain) {

        return new TDBCheckIfRunsEnCoursDTO(
                domain.getIdFndCode(),
                domain.getIdUnitCode()
        );
    }
}