package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBFondsPartDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.TDBFondsPartStructuresDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.TDBStructuresDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBFondsPartStructures;

import java.util.List;

public class TDBFondsPartStructuresMapper {

    public static TDBFondsPartStructuresDTO toDto(
            TDBFondsPartStructures response) {

        List<TDBFondsPartDTO> fondsPart =
                response.getFondsPart()
                        .stream()
                        .map(TDBFondsPartMapper::toDto)
                        .toList();

        List<TDBStructuresDTO> structures =
                response.getStructures()
                        .stream()
                        .map(TDBStructuresMapper::toDto)
                        .toList();

        return new TDBFondsPartStructuresDTO(
                fondsPart,
                structures
        );
    }
}