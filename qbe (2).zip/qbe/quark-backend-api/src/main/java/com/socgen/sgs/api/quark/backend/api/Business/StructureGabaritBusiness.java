package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.domain.PresentationStructure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.StructureGabaritDao;
import com.socgen.sgs.api.quark.backend.api.service.StructureGabaritSerInterface;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class StructureGabaritBusiness implements StructureGabaritSerInterface {

    private final StructureGabaritDao structureGabaritDao;

    public StructureGabaritBusiness(StructureGabaritDao structureGabaritDao) {
        this.structureGabaritDao = structureGabaritDao;
    }

    @Override
    public List<PresentationStructure> getPresentationStructure(String idStructure, Long idGabarit) {
        if (idStructure == null || idStructure.isBlank()) {
            throw new IllegalArgumentException("idStructure is required");
        }
        if (idGabarit == null) {
            throw new IllegalArgumentException("idGabarit is required");
        }
        return structureGabaritDao.getPresentationStructure(idStructure, idGabarit);
    }

    @Override
    public List<Compartiment> getListeCompartsByStructGab(String idStructure, Long idGabarit) {
        if (idStructure == null || idStructure.isBlank()) {
            throw new IllegalArgumentException("idStructure is required");
        }
        if (idGabarit == null) {
            throw new IllegalArgumentException("idGabarit is required");
        }
        return structureGabaritDao.getListeCompartsByStructGab(idStructure, idGabarit);
    }
}