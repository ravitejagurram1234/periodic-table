package com.socgen.sgs.api.quark.backend.api.infra.dao;

public interface TDBInsertRunTachesDAO {

    void insertRunTaches(
            Long p_idRun,
            Long[] p_idTaches
    );
}