package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeTachesByGabAndType;

import java.util.List;

public interface TDBGetListeTachesByGabAndTypeDAO {

    List<TDBGetListeTachesByGabAndType>
    getListeTachesByGabAndType(
            Long p_idGabarit,
            Long p_idTypeTache
    );

}