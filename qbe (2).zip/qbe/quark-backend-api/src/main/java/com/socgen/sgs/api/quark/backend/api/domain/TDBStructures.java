package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TDBStructures {

    private String trigramme;
    private String idStructure;
    private Long idSuivi;
    private String nomStructure;
    private Long idGabarit;
    private String nomGabarit;
    private LocalDate dateEcheance;
    private LocalDate dateLastEcheance;
    private String fndLegalType;
    private String fndMngtCompany;
    private String fndClassification;
    private Long idStatutGeneration;
    private Long idRunPrecedent;
    private Long idRunAno;
    private String fndAccountant;
    private String fndAuditor;
    private Integer typeSuivi;
    private Integer isLocked;
    private Integer idStatutSuivi;

}