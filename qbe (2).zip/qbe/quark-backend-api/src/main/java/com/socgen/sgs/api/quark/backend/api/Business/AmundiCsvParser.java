package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiBusinessKey;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiDateFormat;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportRowError;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiPerimeterRecord;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.CsvParseResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.ParsedAmundiRow;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.UploadedFile;
import com.socgen.sgs.api.quark.backend.api.domain.FeatureExceptions.FeatureConfigurationException;
import com.socgen.sgs.api.quark.backend.api.domain.FeatureExceptions.ImportRejectedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import static com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.EXPECTED_HEADERS;

@Component
public class AmundiCsvParser {

    private static final List<String> DB_COLUMNS = List.of(
            "FUND_LABEL", "ID_FUND_BWR", "DECALOG", "FUND_NAME",
            "REPORT_TYPE", "REPORT_DATE", "REPORT_LANGUAGE", "LEGAL_FORM",
            "EUROPEAN_NORM", "ENGAGEMENT_METHOD", "CODE_PARAPLUIE"
    );

    private static final Set<Integer> OPTIONAL_COLUMNS = Set.of(9, 10);

    private final long maxFileSizeBytes;

    public AmundiCsvParser(
            @Value("${quark.referential.amundi.max-file-size-bytes:10485760}")
            long maxFileSizeBytes) {
        this.maxFileSizeBytes = maxFileSizeBytes;
    }

    public CsvParseResult parse(
            UploadedFile file,
            AmundiDateFormat dateFormat,
            Map<String, Integer> liveColumnLengths) {

        validateFile(file);
        verifyLiveSchema(liveColumnLengths);

        byte[] bytes = file.content();
        String checksum = sha256(bytes);
        String csv = decodeUtf8(bytes);
        if (!csv.isEmpty() && csv.charAt(0) == '\uFEFF') {
            csv = csv.substring(1);
        }

        List<List<String>> records = parseCsv(csv);
        records.removeIf(this::isCompletelyEmpty);
        if (records.isEmpty()) {
            throw new ImportRejectedException("The CSV file has no header row");
        }

        validateHeader(records.getFirst());

        List<ParsedAmundiRow> validRows = new ArrayList<>();
        List<AmundiImportRowError> errors = new ArrayList<>();
        Set<AmundiBusinessKey> keys = new HashSet<>();
        int duplicateRows = 0;
        int totalRows = 0;

        for (int index = 1; index < records.size(); index++) {
            List<String> values = records.get(index);
            long csvRowNumber = index + 1L;
            totalRows++;

            if (values.size() != EXPECTED_HEADERS.size()) {
                errors.add(new AmundiImportRowError(
                        csvRowNumber,
                        "_ROW",
                        Integer.toString(values.size()),
                        "Expected exactly 11 columns but found " + values.size()));
                continue;
            }

            List<AmundiImportRowError> rowErrors = new ArrayList<>();
            String[] normalized = values.stream()
                    .map(value -> value == null ? "" : value.trim())
                    .toArray(String[]::new);

            for (int columnIndex = 0; columnIndex < normalized.length; columnIndex++) {
                if (!OPTIONAL_COLUMNS.contains(columnIndex) && normalized[columnIndex].isBlank()) {
                    rowErrors.add(error(csvRowNumber, columnIndex, normalized[columnIndex], "Value is required"));
                }
                validateLength(csvRowNumber, columnIndex, normalized[columnIndex], liveColumnLengths, rowErrors);
            }

            String reportType = normalized[4].toUpperCase(Locale.ROOT);
            if (!reportType.equals("RA") && !reportType.equals("IS")) {
                rowErrors.add(error(csvRowNumber, 4, normalized[4], "Only RA and IS are supported"));
            }

            String language = normalized[6].toUpperCase(Locale.ROOT);
            if (!language.matches("[A-Z]{2}")) {
                rowErrors.add(error(csvRowNumber, 6, normalized[6], "Language must contain exactly two letters"));
            }

            LocalDate reportDate = null;
            try {
                reportDate = dateFormat.parse(normalized[5]);
            } catch (DateTimeParseException exception) {
                rowErrors.add(error(csvRowNumber, 5, normalized[5],
                        "Date does not match " + dateFormat));
            }

            if (!rowErrors.isEmpty()) {
                errors.addAll(rowErrors);
                continue;
            }

            AmundiPerimeterRecord record = new AmundiPerimeterRecord(
                    normalized[0],
                    normalized[1],
                    normalized[2],
                    normalized[3].toUpperCase(Locale.ROOT),
                    reportType,
                    reportDate,
                    language,
                    normalized[7],
                    normalized[8],
                    nullIfBlank(normalized[9]),
                    nullIfBlank(normalized[10])
            );

            if (!keys.add(record.key())) {
                duplicateRows++;
                errors.add(new AmundiImportRowError(
                        csvRowNumber,
                        "FUND_NAME/REPORT_DATE/REPORT_LANGUAGE",
                        record.fundName() + "/" + record.reportDate() + "/" + record.reportLanguage(),
                        "Duplicate business key in the uploaded file"));
                continue;
            }

            validRows.add(new ParsedAmundiRow(csvRowNumber, record));
        }

        return new CsvParseResult(checksum, totalRows, validRows, errors, duplicateRows);
    }

    private void validateFile(UploadedFile file) {
        String filename = file.originalFilename().toLowerCase(Locale.ROOT);
        if (!filename.endsWith(".csv")) {
            throw new ImportRejectedException("Only .csv files are accepted");
        }
        if (file.content().length == 0) {
            throw new ImportRejectedException("The CSV file is empty");
        }
        if (file.content().length > maxFileSizeBytes) {
            throw new ImportRejectedException(
                    "The CSV file exceeds the maximum size of " + maxFileSizeBytes + " bytes");
        }
    }

    private void verifyLiveSchema(Map<String, Integer> liveColumnLengths) {
        for (String column : DB_COLUMNS) {
            if (!liveColumnLengths.containsKey(column)) {
                throw new FeatureConfigurationException(
                        "Oracle column QXP_AMUNDI_PERIMETER." + column + " is missing");
            }
        }
    }

    private void validateHeader(List<String> actualHeader) {
        if (!EXPECTED_HEADERS.equals(actualHeader)) {
            throw new ImportRejectedException(
                    "CSV header must exactly match, in order: " + String.join(" | ", EXPECTED_HEADERS));
        }
    }

    private void validateLength(
            long rowNumber,
            int columnIndex,
            String value,
            Map<String, Integer> liveColumnLengths,
            List<AmundiImportRowError> errors) {

        if (value.isEmpty() || columnIndex == 5) {
            return;
        }
        Integer maximum = liveColumnLengths.get(DB_COLUMNS.get(columnIndex));
        if (maximum != null && maximum > 0 && value.length() > maximum) {
            errors.add(error(rowNumber, columnIndex, value,
                    "Maximum Oracle length is " + maximum + " characters"));
        }
    }

    private AmundiImportRowError error(long rowNumber, int columnIndex, String value, String reason) {
        return new AmundiImportRowError(
                rowNumber,
                EXPECTED_HEADERS.get(columnIndex),
                abbreviate(value),
                reason);
    }

    private String decodeUtf8(byte[] bytes) {
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes))
                    .toString();
        } catch (CharacterCodingException exception) {
            throw new ImportRejectedException("The CSV file must be valid UTF-8", exception);
        }
    }

    private String sha256(byte[] bytes) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is unavailable", exception);
        }
    }

    private List<List<String>> parseCsv(String csv) {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean inQuotes = false;
        boolean afterClosingQuote = false;
        boolean fieldStarted = false;
        int physicalLine = 1;

        for (int index = 0; index < csv.length(); index++) {
            char current = csv.charAt(index);

            if (inQuotes) {
                if (current == '"') {
                    if (index + 1 < csv.length() && csv.charAt(index + 1) == '"') {
                        field.append('"');
                        index++;
                    } else {
                        inQuotes = false;
                        afterClosingQuote = true;
                    }
                } else if (current == '\r' || current == '\n') {
                    if (current == '\r' && index + 1 < csv.length() && csv.charAt(index + 1) == '\n') {
                        index++;
                    }
                    field.append('\n');
                    physicalLine++;
                } else {
                    field.append(current);
                }
                continue;
            }

            if (current == ',') {
                row.add(field.toString());
                field.setLength(0);
                fieldStarted = false;
                afterClosingQuote = false;
            } else if (current == '\r' || current == '\n') {
                if (current == '\r' && index + 1 < csv.length() && csv.charAt(index + 1) == '\n') {
                    index++;
                }
                row.add(field.toString());
                rows.add(row);
                row = new ArrayList<>();
                field.setLength(0);
                fieldStarted = false;
                afterClosingQuote = false;
                physicalLine++;
            } else if (current == '"') {
                if (fieldStarted || field.length() > 0 || afterClosingQuote) {
                    throw new ImportRejectedException("Malformed quote near CSV line " + physicalLine);
                }
                inQuotes = true;
                fieldStarted = true;
            } else if (afterClosingQuote) {
                if (!Character.isWhitespace(current)) {
                    throw new ImportRejectedException(
                            "Unexpected character after closing quote near CSV line " + physicalLine);
                }
            } else {
                field.append(current);
                fieldStarted = true;
            }
        }

        if (inQuotes) {
            throw new ImportRejectedException("Unclosed quoted field at end of CSV");
        }
        if (!row.isEmpty() || field.length() > 0 || fieldStarted || afterClosingQuote) {
            row.add(field.toString());
            rows.add(row);
        }
        return rows;
    }

    private boolean isCompletelyEmpty(List<String> row) {
        return row.stream().allMatch(value -> value == null || value.isBlank());
    }

    private String nullIfBlank(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    private String abbreviate(String value) {
        if (value == null || value.length() <= 200) {
            return value;
        }
        return value.substring(0, 197) + "...";
    }
}