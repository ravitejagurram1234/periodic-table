package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TDBGetListeTachesByGabAndTypeDTO {

    private Long idTache;
    private String commentaire;
    private Long idStatutSuiviDebut;
    private Long idStatutSuiviFin;

}