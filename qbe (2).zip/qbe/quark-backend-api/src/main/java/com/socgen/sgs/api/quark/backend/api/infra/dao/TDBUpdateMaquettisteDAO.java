package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TDBUpdateMaquettiste;

public interface TDBUpdateMaquettisteDAO {

    void updateMaquettiste(
            TDBUpdateMaquettiste request);
}