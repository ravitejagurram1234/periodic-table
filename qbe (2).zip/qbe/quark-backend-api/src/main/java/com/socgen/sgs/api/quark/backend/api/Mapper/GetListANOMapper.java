package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.GetListANODTO;
import com.socgen.sgs.api.quark.backend.api.domain.GetListANO;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GetListANOMapper {

    public static GetListANO mapResult(ResultSet rs) throws SQLException {

        GetListANO ano = new GetListANO();

        ano.setMessage(
                rs.getString("MESSAGE")
        );

        return ano;
    }

    public static GetListANODTO toDto(GetListANO ano) {

        return new GetListANODTO(
                ano.getMessage()
        );
    }
}