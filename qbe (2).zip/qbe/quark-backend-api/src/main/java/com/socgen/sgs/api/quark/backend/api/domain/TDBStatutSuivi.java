package com.socgen.sgs.api.quark.backend.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TDBStatutSuivi {

    private Long idStatutSuivi;

    private String traductionCode;

    private Long typeSuivi;

}
