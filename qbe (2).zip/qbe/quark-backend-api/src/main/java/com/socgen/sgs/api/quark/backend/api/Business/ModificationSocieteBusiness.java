package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationSocieteDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ModificationSocieteBusiness {

    private final ModificationSocieteDao modificationSocieteDao;

    public ModificationSocieteBusiness(ModificationSocieteDao modificationSocieteDao) {
        this.modificationSocieteDao = modificationSocieteDao;
    }

    public List<String> getListSociete() {
        return modificationSocieteDao.getListSociete();
    }
}
