package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.TDBGetListeTachesByGabAndTypeMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeTachesByGabAndType;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBGetListeTachesByGabAndTypeDAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCTDBGetListeTachesByGabAndType
        implements TDBGetListeTachesByGabAndTypeDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBGetListeTachesByGabAndType(
            DataSource dataSource) {

        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetListeTachesByGabAndType")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(
                                "RETURN_VALUE",
                                OracleTypes.CURSOR,
                                (rs, rowNum) ->
                                        TDBGetListeTachesByGabAndTypeMapper.mapResult(rs)
                        ),
                        new SqlParameter(
                                "p_idGabarit",
                                Types.NUMERIC
                        ),
                        new SqlParameter(
                                "p_idTypeTache",
                                Types.NUMERIC
                        )
                );
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<TDBGetListeTachesByGabAndType>
    getListeTachesByGabAndType(
            Long p_idGabarit,
            Long p_idTypeTache) {

        try {

            Map<String, Object> params =
                    new HashMap<>();

            params.put(
                    "p_idGabarit",
                    p_idGabarit
            );

            params.put(
                    "p_idTypeTache",
                    p_idTypeTache
            );

            Map<String, Object> result =
                    simpleJdbcCall.execute(params);

            return (List<TDBGetListeTachesByGabAndType>)
                    result.get("RETURN_VALUE");

        } catch (Exception e) {

            System.err.println(
                    "Error during JDBC call : "
                            + e.getMessage()
            );

            e.printStackTrace();

            return Collections.emptyList();
        }
    }
}