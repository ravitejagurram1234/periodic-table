package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeEventsByGabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBGetListeEventsByGabaritDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBGetListeEventsByGabaritSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TDBGetListeEventsByGabaritService
        implements TDBGetListeEventsByGabaritSerInterface {

    @Autowired
    private TDBGetListeEventsByGabaritDAO dao;

    @Override
    public List<TDBGetListeEventsByGabarit>
    getListeEventsByGabarit(
            Long p_idGabarit) {

        return dao.getListeEventsByGabarit(
                p_idGabarit
        );
    }
}