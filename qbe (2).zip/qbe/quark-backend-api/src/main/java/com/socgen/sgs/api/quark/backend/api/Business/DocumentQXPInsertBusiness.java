package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.DocumentQXPInsertDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class DocumentQXPInsertBusiness {

    private final DocumentQXPInsertDao documentQXPInsertDao;

    public DocumentQXPInsertBusiness(DocumentQXPInsertDao documentQXPInsertDao) {
        this.documentQXPInsertDao = documentQXPInsertDao;
    }

    public Integer DocumentQXPInsert(byte[] p_contenu, int p_taille_document) {
        return documentQXPInsertDao.DocumentQXPInsert(p_contenu, p_taille_document);
    }
}