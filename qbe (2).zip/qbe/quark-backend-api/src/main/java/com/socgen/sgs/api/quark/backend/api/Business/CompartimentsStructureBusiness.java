package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Structure;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentsStructureDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CompartimentsStructureBusiness {

    private final CompartimentsStructureDao compartimentsStructureDao;

    public CompartimentsStructureBusiness(CompartimentsStructureDao compartimentsStructureDao) {
        this.compartimentsStructureDao = compartimentsStructureDao;
    }

    public List<Structure> getStructures(
            int p_withAtLeastOneCompatiment,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        return compartimentsStructureDao.getStructures(
                p_withAtLeastOneCompatiment,
                p_auditor,
                p_accountant,
                p_fundMgtCompany);
    }
}