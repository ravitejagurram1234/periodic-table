package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.categorieDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class categorieBusiness {

    private final categorieDao dao;

    public categorieBusiness(categorieDao dao) {
        this.dao = dao;
    }

    public List<TypeDeDocument> getListeSousCategorie(
            int p_idCategorie,
            int p_checkAtLeastOneDocument) {

        return dao.getListeSousCategorie(
                p_idCategorie,
                p_checkAtLeastOneDocument);
    }
}