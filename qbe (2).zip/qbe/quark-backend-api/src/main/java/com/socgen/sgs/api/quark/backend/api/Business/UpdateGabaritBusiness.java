package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateGabaritDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UpdateGabaritBusiness {

    private final UpdateGabaritDao updateGabaritDao;

    public UpdateGabaritBusiness(UpdateGabaritDao updateGabaritDao) {
        this.updateGabaritDao = updateGabaritDao;
    }

    public void updateGabarit(Gabarit gabarit, Long p_idGabarit) {
        updateGabaritDao.updateGabarit(gabarit, p_idGabarit);
    }
}