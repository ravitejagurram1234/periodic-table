package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBInsertRunTachesDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBInsertRunTachesSerInterface;
import org.springframework.stereotype.Service;

@Service
public class TDBInsertRunTachesService
        implements TDBInsertRunTachesSerInterface {

    private final TDBInsertRunTachesDAO dao;

    public TDBInsertRunTachesService(
            TDBInsertRunTachesDAO dao) {

        this.dao = dao;
    }

    @Override
    public void insertRunTaches(
            Long p_idRun,
            Long[] p_idTaches) {

        dao.insertRunTaches(
                p_idRun,
                p_idTaches
        );
    }
}