package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.Dto.SuiviDTO;
import com.socgen.sgs.api.quark.backend.api.Mapper.SuiviMapper;
import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;
import com.socgen.sgs.api.quark.backend.api.domain.Suivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.InsertSuiviDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class InsertSuiviBusiness {

    private final InsertSuiviDao suiviDao;

    public InsertSuiviBusiness(InsertSuiviDao suiviDao) {
        this.suiviDao = suiviDao;
    }

    public Long insertSuivi(SuiviDTO suivi) {
        Suivi domain = SuiviMapper.toDomain(suivi);
        return suiviDao.insertSuivi(domain);
    }
}