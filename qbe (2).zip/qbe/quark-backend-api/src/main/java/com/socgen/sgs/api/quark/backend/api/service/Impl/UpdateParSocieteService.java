package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.Business.AuditParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.UpdateParFondsBusiness;
import com.socgen.sgs.api.quark.backend.api.Business.UpdateParSocieteBusiness;
import com.socgen.sgs.api.quark.backend.api.Constantes.Chargement_constantes;
import com.socgen.sgs.api.quark.backend.api.Constantes.Performance;
import com.socgen.sgs.api.quark.backend.api.Dto.DocumentDTO;
import com.socgen.sgs.api.quark.backend.api.domain.Audit;
import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.service.UpdateParFondsSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.UpdateParSocieteSerInterface;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class UpdateParSocieteService implements UpdateParSocieteSerInterface {

        @Autowired
        private UpdateParSocieteBusiness updateParSocieteBusiness;

        @Autowired
        private AuditParFondsBusiness auditParFondsBusiness;

    public void updateDocument(MultipartFile file, DocumentDTO dto) {
        String originalFilename = file.getOriginalFilename();
        int taille_document = (int) file.getSize();
        String p_nom_document = originalFilename.substring(0, originalFilename.lastIndexOf('.'));
        String fileExtension = "";

        if (originalFilename != null && originalFilename.lastIndexOf('.') > 0) {
            int dotIndex = originalFilename.lastIndexOf('.');
            fileExtension = originalFilename.substring(dotIndex + 1);
        }
        LocalDate withOneMonth = dto.getP_date_document().withDayOfMonth(1);
        try {
            Document document = Document.builder()
                    .p_societe(dto.getP_societe())
                    .p_id_sous_categorie(dto.getP_id_sous_categorie())
                    .p_date_document(withOneMonth)
                    .p_id_langue(dto.getP_id_langue())
                    .p_contenu(file.getBytes())
                    .p_taille_document(taille_document)
                    .p_nom_document(p_nom_document)
                    .p_format(fileExtension)
                    .p_id_utilisateur(dto.getP_id_utilisateur())
                    .p_is_actif(dto.getP_is_actif())
                    .build();

            updateParSocieteBusiness.updateParSociete(document);
        } catch (IOException e) {
            throw new RuntimeException("Error reading file bytes", e);
        }
    }


    public String getClientIp(HttpServletRequest request) {
            String ipAddress = request.getHeader("X-Forwarded-For");
            if (ipAddress == null || ipAddress.isEmpty() || "unknown".equalsIgnoreCase(ipAddress)) {
                ipAddress = request.getRemoteAddr();
            }
            return ipAddress;
        }

    public Integer AuditUpdateParSociete(MultipartFile file, DocumentDTO dto, String page, String user, HttpServletRequest request) {
        Performance performance = new Performance();
        LocalDate start = LocalDate.now();
        LocalDate end = LocalDate.now();


        BigDecimal responseTime = performance.getSecondsAndMilliseconds();
        String clientIp = getClientIp(request);
        LocalDateTime now = LocalDateTime.now();
        String param1 = "Societe : " + dto.getP_societe();
        String param2 = "Id sous-cat : " + dto.getP_id_sous_categorie();
        String param3 = "Id langue : " + dto.getP_id_langue();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String formattedDateTime = now.format(formatter);
        String param4 = "Date document : " + formattedDateTime;
        String p_message="Mise à jour du document par société effectuée avec succès";
        Audit audit = new Audit(clientIp, start, end, page, user, Chargement_constantes.MODULE_NAME,Chargement_constantes.MODIFICATION_DOCUMENT_PAR_SOCIETE,
                p_message, param1, param2, param3, param4, "", responseTime, 0, 0, "");

        return auditParFondsBusiness.AuditParFonds(audit);
    }
}

