package com.socgen.sgs.api.quark.backend.api.infra.jpa.Repository;

//package com.socgen.sgs.api.quark.backend.api.infra.jpa.persistence.repository;

import com.socgen.sgs.api.quark.backend.api.infra.jpa.entity.QxpGabarit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * Repository interface for managing QXP_GABARIT entity.
 * Provides data access operations for gabarit templates.
 *
 * @author SGSS-FVS Team
 * @version 1.0
 * @since 2026-02-01
 */
@Repository
public interface GabaritRepository extends JpaRepository<QxpGabarit, Long> {

    /*
     * Commented out - previous implementation using native query
     * Retrieves the type of a gabarit by its ID.
     */
//    @Query(value = "SELECT type FROM qxp_gabarit WHERE id_gabarit = :idGabarit", nativeQuery = true)
//    Optional<String> findTypeByIdGabarit(@Param("idGabarit") Long idGabarit);

    /**
     * Retrieves a gabarit entity by its ID (alternative to findById).
     *
     * @param gabaritId the gabarit identifier
     * @return the QxpGabarit entity if found, null otherwise
     */
    QxpGabarit findByGabaritId(Long gabaritId);
}
