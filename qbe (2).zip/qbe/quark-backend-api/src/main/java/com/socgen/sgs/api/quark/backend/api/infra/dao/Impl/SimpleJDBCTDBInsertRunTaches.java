package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBInsertRunTachesDAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

@Repository
public class SimpleJDBCTDBInsertRunTaches
        implements TDBInsertRunTachesDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBInsertRunTaches(
            DataSource dataSource) {

        this.simpleJdbcCall =
                new SimpleJdbcCall(dataSource)
                        .withCatalogName("QXP_PK_SUIVI")
                        .withProcedureName("InsertRunTaches")
                        .withoutProcedureColumnMetaDataAccess()
                        .declareParameters(
                                new SqlParameter(
                                        "p_idRun",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_idTaches",
                                        OracleTypes.ARRAY
                                )
                        );
    }

    @Override
    public void insertRunTaches(
            Long p_idRun,
            Long[] p_idTaches) {

        Map<String, Object> params =
                new HashMap<>();

        params.put(
                "p_idRun",
                p_idRun
        );

        params.put(
                "p_idTaches",
                p_idTaches
        );

        simpleJdbcCall.execute(params);
    }
}