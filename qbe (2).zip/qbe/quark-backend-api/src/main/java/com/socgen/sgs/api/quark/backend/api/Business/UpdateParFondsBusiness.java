package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateParFondsDao;
import com.socgen.sgs.api.quark.backend.api.service.Impl.UpdateParFondsService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UpdateParFondsBusiness {

    private final UpdateParFondsDao updateParFondsDao;

    public UpdateParFondsBusiness(UpdateParFondsDao updateParFondsDao) {
        this.updateParFondsDao = updateParFondsDao;
    }

    public void updateDocument(Document document) {
        updateParFondsDao.updateDocument(document);
    }
}
