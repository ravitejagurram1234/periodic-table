package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TDBCheckIfRunsEnCours;

import java.time.LocalDate;
import java.util.List;

public interface TDBCheckIfRunsEnCoursDAO {

    List<TDBCheckIfRunsEnCours> checkIfRunsEnCours(
            String[] p_ids,
            String[] p_id_unit_codes,
            Long p_idLangue,
            Long p_idGabarit,
            LocalDate p_dateEcheance
    );
}
