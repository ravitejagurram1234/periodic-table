package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.ModificationParFondsLangue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationGabaritLangueDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ModificationGabaritLangueBusiness {

    private final ModificationGabaritLangueDao modificationGabaritLangueDao;

    public ModificationGabaritLangueBusiness(
            ModificationGabaritLangueDao modificationGabaritLangueDao) {
        this.modificationGabaritLangueDao = modificationGabaritLangueDao;
    }

    public List<ModificationParFondsLangue> getListLangue(int p_id_type_rapport) {
        return modificationGabaritLangueDao.getListLangue(p_id_type_rapport);
    }
}
