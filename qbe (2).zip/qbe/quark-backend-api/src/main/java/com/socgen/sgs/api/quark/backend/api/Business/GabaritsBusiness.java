package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Gabarits;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritsDao;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GabaritsBusiness {

    private final GabaritsDao gabaritDao;

    public GabaritsBusiness(GabaritsDao gabaritDao) {
        this.gabaritDao = gabaritDao;
    }

    public List<Gabarits> getGabarits(Long p_idTypeRapport, Long p_idLangue, int p_onlyActive) {
        return gabaritDao.getGabarits(p_idTypeRapport, p_idLangue, p_onlyActive);
    }
}
