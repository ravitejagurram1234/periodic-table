package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteDateDocumentDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Transactional
public class ModificationParSocieteDateDocumentBusiness {

    private final ModificationParSocieteDateDocumentDao modificationParSocieteDateDocumentDao;

    public ModificationParSocieteDateDocumentBusiness(
            ModificationParSocieteDateDocumentDao modificationParSocieteDateDocumentDao) {
        this.modificationParSocieteDateDocumentDao = modificationParSocieteDateDocumentDao;
    }

    public List<LocalDate> getDateDocuments(String p_societe, int p_id_sous_categorie) {

        List<java.sql.Date> port =
                modificationParSocieteDateDocumentDao.getDateDocuments(
                        p_societe,
                        p_id_sous_categorie);

        return port.stream()
                .filter(Objects::nonNull)
                .map(java.sql.Date::toLocalDate)
                .collect(Collectors.toList());
    }
}