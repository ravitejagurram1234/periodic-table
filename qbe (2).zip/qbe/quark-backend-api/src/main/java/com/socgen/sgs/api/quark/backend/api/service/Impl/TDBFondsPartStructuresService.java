package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBFondsPart;
import com.socgen.sgs.api.quark.backend.api.domain.TDBFondsPartStructures;
import com.socgen.sgs.api.quark.backend.api.domain.TDBStructures;
import com.socgen.sgs.api.quark.backend.api.service.TDBFondsPartSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.TDBFondsPartStructuresSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.TDBStructuresSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class TDBFondsPartStructuresService
        implements TDBFondsPartStructuresSerInterface {

    private final TDBFondsPartSerInterface tdbFondsPartSerInterface;

    private final TDBStructuresSerInterface tdbStructuresSerInterface;

    @Autowired
    public TDBFondsPartStructuresService(
            TDBFondsPartSerInterface tdbFondsPartSerInterface,
            TDBStructuresSerInterface tdbStructuresSerInterface) {

        this.tdbFondsPartSerInterface = tdbFondsPartSerInterface;
        this.tdbStructuresSerInterface = tdbStructuresSerInterface;
    }

    @Override
    public TDBFondsPartStructures getListeSuivis(
            Long p_idLangue,
            LocalDate p_dateEcheance,
            String p_portfolio,
            Long p_idMaquettiste,
            Long p_idStatutSuivi,
            Long p_idTypeRapport,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        List<TDBFondsPart> fondsPart =
                tdbFondsPartSerInterface.getListeSuivisTDBByFondsPart(
                        p_idLangue,
                        p_dateEcheance,
                        p_portfolio,
                        p_idMaquettiste,
                        p_idStatutSuivi,
                        p_idTypeRapport,
                        p_auditor,
                        p_accountant,
                        p_fundMgtCompany
                );

        List<TDBStructures> structures =
                tdbStructuresSerInterface.getListeSuivisTDBByStructures(
                        p_idLangue,
                        p_dateEcheance,
                        p_portfolio,
                        p_idMaquettiste,
                        p_idStatutSuivi,
                        p_idTypeRapport,
                        p_auditor,
                        p_accountant,
                        p_fundMgtCompany
                );

        return new TDBFondsPartStructures(
                fondsPart,
                structures
        );
    }
}