package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.FondsHaveSuiviDto;
import com.socgen.sgs.api.quark.backend.api.domain.FondsHaveSuivi;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FondsHaveSuiviMapper {

    public static FondsHaveSuivi mapResult(ResultSet rs) throws SQLException {

        FondsHaveSuivi fonds = new FondsHaveSuivi();

        fonds.setKeyRefFund(rs.getLong("KEY_REF_FUND"));
        fonds.setIdFndCode(rs.getString("ID_FND_CODE"));

        if (rs.getDate("ID_FND_START_VALIDITY") != null) {
            fonds.setIdFndStartValidity(
                    rs.getDate("ID_FND_START_VALIDITY").toLocalDate()
            );
        }

        if (rs.getDate("FND_END_VALIDITY") != null) {
            fonds.setFndEndValidity(
                    rs.getDate("FND_END_VALIDITY").toLocalDate()
            );
        }

        fonds.setFndShtDescription(rs.getString("FND_SHT_DESCRIPTION"));
        fonds.setFndLngDescription(rs.getString("FND_LNG_DESCRIPTION"));
        fonds.setFndFlgMultiMngr(rs.getString("FND_FLG_MULTI_MNGR"));
        fonds.setActSocioClass(rs.getString("ACT_SOCIO_CLASS"));
        fonds.setIdMngCode(rs.getString("ID_MNG_CODE"));
        fonds.setMngLngDescription(rs.getString("MNG_LNG_DESCRIPTION"));
        fonds.setMngShtDescription(rs.getString("MNG_SHT_DESCRIPTION"));
        fonds.setIdMfmManagerCode(rs.getString("ID_MFM_MANAGER_CODE"));
        fonds.setIdActCode(rs.getString("ID_ACT_CODE"));

        return fonds;
    }

    public static FondsHaveSuiviDto toDto(FondsHaveSuivi fonds) {

        return new FondsHaveSuiviDto(
                fonds.getKeyRefFund(),
                fonds.getIdFndCode(),
                fonds.getIdFndStartValidity(),
                fonds.getFndEndValidity(),
                fonds.getFndShtDescription(),
                fonds.getFndLngDescription(),
                fonds.getFndFlgMultiMngr(),
                fonds.getActSocioClass(),
                fonds.getIdMngCode(),
                fonds.getMngLngDescription(),
                fonds.getMngShtDescription(),
                fonds.getIdMfmManagerCode(),
                fonds.getIdActCode()
        );
    }
}