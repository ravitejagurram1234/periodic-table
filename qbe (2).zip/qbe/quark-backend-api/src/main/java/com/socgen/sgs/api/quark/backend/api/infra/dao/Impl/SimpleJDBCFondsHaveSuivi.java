package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.FondsHaveSuiviMapper;
import com.socgen.sgs.api.quark.backend.api.domain.FondsHaveSuivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FondsHaveSuiviDao;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCFondsHaveSuivi implements FondsHaveSuiviDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCFondsHaveSuivi(DataSource dataSource) {

        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withFunctionName("GetListeFondsHaveSuivi")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(
                                "RETURN_VALUE",
                                OracleTypes.CURSOR,
                                (rs, rowNum) -> FondsHaveSuiviMapper.mapResult(rs)
                        ),
                        new SqlParameter("p_idLangue", Types.NUMERIC),
                        new SqlParameter("p_dateEcheance", Types.DATE),
                        new SqlParameter("p_idTypeRapport", Types.NUMERIC)
                );
    }

    @Override
    public List<FondsHaveSuivi> getListeFondsHaveSuivi(
            Long p_idLangue,
            LocalDate p_dateEcheance,
            Long p_idTypeRapport) {

        java.sql.Date sqlDate = java.sql.Date.valueOf(p_dateEcheance);

        Map<String, Object> params = Map.of(
                "p_idLangue", p_idLangue,
                "p_dateEcheance", sqlDate,
                "p_idTypeRapport", p_idTypeRapport
        );

        try {

            Map<String, Object> result = simpleJdbcCall.execute(params);

            return (List<FondsHaveSuivi>) result.get("RETURN_VALUE");

        } catch (Exception e) {

            System.err.println("Error during JDBC call: " + e.getMessage());
            e.printStackTrace();

            return Collections.emptyList();
        }
    }
}