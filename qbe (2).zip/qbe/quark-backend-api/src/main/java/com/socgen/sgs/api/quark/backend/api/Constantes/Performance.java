package com.socgen.sgs.api.quark.backend.api.Constantes;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
@Getter
@Setter
@AllArgsConstructor
public class Performance {
    private LocalDateTime start;

    public Performance() {
        reset();
    }

    public BigDecimal getSecondsAndMilliseconds() {
        Duration interval = Duration.between(start, LocalDateTime.now());
        return BigDecimal.valueOf(interval.getSeconds())
                .add(BigDecimal.valueOf(interval.getNano()).divide(BigDecimal.valueOf(1_000_000_000)));
    }

    private void reset() {
        start = LocalDateTime.now();
    }

    public static void main(String[] args) {
        Performance performance = new Performance();

        // Start measuring time
        performance.reset();

        // Simulate some operation
        performSomeOperation();

        // Get the response time
        BigDecimal responseTime = performance.getSecondsAndMilliseconds();

        // Output the response time
        System.out.println("Response Time: " + responseTime + " seconds");
    }

    private static void performSomeOperation() {

        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
