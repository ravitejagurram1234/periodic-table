package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Accountants;
import com.socgen.sgs.api.quark.backend.api.infra.dao.AccountantsDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class AccountantBusiness {

    private final AccountantsDao dao;

    public AccountantBusiness(AccountantsDao dao) {
        this.dao = dao;
    }

    public List<Accountants> getAccountants() {
        return dao.getListAccountants();
    }
}