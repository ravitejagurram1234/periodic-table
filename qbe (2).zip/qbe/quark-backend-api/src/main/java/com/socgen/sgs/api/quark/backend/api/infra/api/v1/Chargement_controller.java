package com.socgen.sgs.api.quark.backend.api.infra.api.v1;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import com.socgen.sgs.api.quark.backend.api.Dto.ValidateStructureGabaritFondsDTO;
import com.socgen.sgs.api.quark.backend.api.Dto.StructureGabaritFondsResponseDTO;
import com.socgen.sgs.api.quark.backend.api.service.ValidateStructureGabaritFondsSerInterface;

import com.socgen.apibank.http.ratelimiter.RateLimiter;
import com.socgen.sgs.api.quark.backend.api.Constantes.Enums;
import com.socgen.sgs.api.quark.backend.api.Dto.*;
import com.socgen.sgs.api.quark.backend.api.Mapper.*;
import com.socgen.sgs.api.quark.backend.api.domain.*;
import com.socgen.sgs.api.quark.backend.api.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.Problem;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.Comparator;

import static org.springframework.http.MediaType.APPLICATION_PROBLEM_JSON_VALUE;
import static org.springframework.http.ResponseEntity.ok;
import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;

@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})

@RestController
@RequestMapping(value = "/api/v1/")
public class Chargement_controller {

    private static final String QUOTA_EXCEEDED_EXAMPLE = "";

    @Autowired
    private portefeuilleSerInterface portefeuilleSerInterface;

    @Autowired
    private UpdateParSocieteSerInterface updateParSocieteSerInterface;

    @GetMapping("/portefeuille")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<portefeuilleDTO>> getPortefeuille() {

        List<portefeuille> port = portefeuilleSerInterface.getPortefeuille();
        List<portefeuilleDTO> dtoList = port.stream().map(portefeuilleMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private TypeDeDocumentSerInterface typeDeDocumentSerInterface;

    @GetMapping("/TypeDeDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getTypeDeDocument(@RequestParam String p_id_fnd_code, @RequestParam Long p_typeCategorieDocument) {

        List<TypeDeDocument> port = typeDeDocumentSerInterface.getTypeDocument(p_id_fnd_code, p_typeCategorieDocument);
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @PostMapping(value = "/Document", consumes = "multipart/form-data")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(file.getOriginalFilename());
    }


    @Autowired
    private ValiderParFondsSerInterface validerParFondsSerInterface;
    @Autowired
    private IAuthenticationService authenticationService;

    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
    @Operation(summary = "Fetches FundAllocation items", description = "Fetches FundAllocation items")
    @PostMapping(value = "/ValiderParFonds", produces = APPLICATION_JSON_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)

    public ResponseEntity<String> getValider(@ModelAttribute DocumentDTO dto, @RequestParam String page, HttpServletRequest request) {
        MultipartFile file = dto.getFile();
        validerParFondsSerInterface.InsertParFonds(file, dto);
        Optional<String> user_email = authenticationService.getCurrentUserEmailId();
        int id = validerParFondsSerInterface.AuditParFonds(file, dto, page, user_email.get(), request);
        return ResponseEntity.ok("success");
    }


    @Autowired
    private SocieteSerInterface societeSerInterface;

    @GetMapping("/Societe")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<SocieteDTO>> getSociete() {

        List<Societe> port = societeSerInterface.getSociete();
        List<SocieteDTO> dtoList = port.stream().map(SocieteMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private SocieteDocumentSerInterface societeDocumentSerInterface;

    @GetMapping("/SocieteDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getSocieteDocument(@RequestParam String p_societe) {

        List<TypeDeDocument> port = societeDocumentSerInterface.getSocieteDocument(p_societe);
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private ValiderParSocieteSerInterface validerParSocieteSerInterface;

    @PostMapping(value = "/ValiderParSociete", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getValiderParSociete(@ModelAttribute DocumentDTO dto, @RequestParam String page, HttpServletRequest request) {
        MultipartFile file = dto.getFile();
        validerParSocieteSerInterface.InsertParSociete(file, dto);
        Optional<String> user_email = authenticationService.getCurrentUserEmailId();
        int id = validerParSocieteSerInterface.AuditParSociete(file, dto, page, user_email.get(), request);
        return ResponseEntity.ok("success");

    }

    @Autowired
    private Chargement_gabaritSerInterface gabarit;

    @GetMapping("/type-gabarits")
    public List<Enums.TypeGabarit> getTypeGabarits() {
        return gabarit.getAllTypeGabarits();
    }

    @GetMapping("/pagination")
    public List<Enums.pagination> getPagination() {

        return gabarit.getPagination();
    }

    @Autowired
    private categorieSerInterface categorieSerInterface;

    @GetMapping("/categorie")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getSocieteDocument(@RequestParam int p_idCategorie, @RequestParam int p_checkAtLeastOneDocument) {
        List<TypeDeDocument> port = categorieSerInterface.getListeSousCategorie(p_idCategorie, p_checkAtLeastOneDocument);
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private GabaritTemplateSerInterface gabaritTemplateSerInterface;

    @GetMapping("/gabarit-template")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<gabaritTemplateDTO>> getGabaritTemplate() {
        List<GabaritTemplate> port = gabaritTemplateSerInterface.getTemplates();
        List<gabaritTemplateDTO> dtoList = port.stream().map(GabaritTemplateMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }



    @Autowired
    private ValiderGabarit_InsertSerInterface validerGabaritSerInterface;

    @PostMapping(value = "/ValiderGabarit", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getValiderGabarit(@ModelAttribute Chargement_gabaritDTO dto, @RequestParam String page, HttpServletRequest request) {
        MultipartFile file = dto.getFile();
        int gabarit_id = validerGabaritSerInterface.insertGabarit(dto, file);
        if (gabarit_id != 0) {
            Optional<String> user_email = authenticationService.getCurrentUserEmailId();
            int id = validerGabaritSerInterface.AuditGabarit(file, dto, page, user_email.get(), gabarit_id, request);
        }
        return ResponseEntity.ok("success");

    }

    @Autowired
    private ValiderGabaritTemplateSerInterface validerGabaritTemplateSerInterface;

    @Autowired
    private UpdateGabaritTemplateSerInterface updateGabaritTemplateSerInterface;

    @PostMapping(value = "/GabaritTemplate", consumes = "multipart/form-data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = "application/json", examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getValiderGabaritTemplate(@RequestPart("file") MultipartFile file, @RequestParam String commentaire,
                                                            @RequestParam String page, HttpServletRequest request) {

        int gabarit_id = validerGabaritTemplateSerInterface.insertGabaritTemplate(file, commentaire);
        if (gabarit_id != 0) {
            Optional<String> user_email = authenticationService.getCurrentUserEmailId();
            int id = validerGabaritTemplateSerInterface.AuditGabaritTemplate(file, commentaire, page, user_email.get(), gabarit_id, request);
        }
        return ResponseEntity.ok("success");
    }

    @PutMapping(value = "/GabaritTemplate/{id}", consumes = "multipart/form-data")
    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
    @Operation(summary = "Update Gabarit Template", description = "Updates an existing gabarit template with new file and details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Gabarit Template successfully updated"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = "application/json", examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> updateGabaritTemplate(@PathVariable int id, @RequestPart("file") MultipartFile file, @RequestParam String commentaire,
                                                        @RequestParam String page, HttpServletRequest request) {
        try {
            gabaritTemplateDTO dto = new gabaritTemplateDTO();
            dto.setId_gabarit_template(id);
            dto.setNom(file.getOriginalFilename());
            dto.setFile(file);

            updateGabaritTemplateSerInterface.updateGabaritTemplate(file, dto, commentaire);

            Optional<String> user_email = authenticationService.getCurrentUserEmailId();
            Integer auditId = updateGabaritTemplateSerInterface.auditUpdateGabaritTemplate(file, dto, page, user_email.orElse("unknown"), request);

            return ResponseEntity.ok("Gabarit template updated successfully");
        } catch (Exception e) {
            log.error("Error updating gabarit template: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error updating gabarit template: " + e.getMessage());
        }
    }


    @Autowired
    private DocumentQXPInsertSerInterface documentQXPInsertSerInterface;

    @PostMapping(value = "/DocumentQXP", consumes = "multipart/form-data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getValiderDocumentQXP(@RequestPart("file") MultipartFile file, @RequestParam String page, HttpServletRequest request) {

        Integer gabarit_id = documentQXPInsertSerInterface.DocumentQXPInsert(file);
        if (gabarit_id != 0) {
            Optional<String> user_email = authenticationService.getCurrentUserEmailId();
            int id = documentQXPInsertSerInterface.DocumentQXPaudit(file, page, user_email.get(), gabarit_id, request);
        }
        return ResponseEntity.ok("success");


    }

    @Autowired
    private ModificationTypeDeDocumentSerInterface modificationTypeDeDocumentSerInterface;

    @GetMapping("/ModificationTypeDeDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getTypeDeDocument() {

        List<TypeDeDocument> port = modificationTypeDeDocumentSerInterface.getListTypeDocuments();
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private ModificationPortefeuilleSerInterface modificationPortefeuilleSerInterface;

    @GetMapping("/ModificationPortefeuille")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<portefeuilleDTO>> getPortefeuille(@RequestParam int p_id_sous_categorie) {

        List<portefeuille> port = modificationPortefeuilleSerInterface.getListPortefeuille(p_id_sous_categorie);
        List<portefeuilleDTO> dtoList = port.stream().map(portefeuilleMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private ModificationDateDocumentSerInterface modificationDateDocumentSerInterface;






    @GetMapping("/ModificationDateDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<LocalDate>> getDateDocument(@RequestParam int p_id_sous_categorie, @RequestParam String p_id_fnd_code, @RequestParam(required = false) String p_id_unit_code) {

        List<LocalDate> port = modificationDateDocumentSerInterface.getDateDocuments(p_id_sous_categorie, p_id_fnd_code, p_id_unit_code);

        return ok().cacheControl(CacheControl.noCache()).body(port);
    }

    @Autowired
    private ModificationParFondsLangueSerInterface modificationParFondsLangueSerInterface;

    @GetMapping("/ModificationParFondsLangue")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<ModificationParFondsLangueDTO>> getLangues(@RequestParam int p_id_sous_categorie, @RequestParam String p_id_fnd_code, @RequestParam(required = false) String p_id_unit_code, @RequestParam LocalDate p_date_document) {
        List<ModificationParFondsLangue> port = modificationParFondsLangueSerInterface.getLangues(p_id_sous_categorie, p_id_fnd_code, p_id_unit_code, p_date_document);
        List<ModificationParFondsLangueDTO> dtoList = port.stream().map(ModificationLangueMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }


    @Autowired
    private ModificationParFondsDocumentSerInterfce modificationParFondsDocumentSerInterfce;

    @GetMapping("/ModificationParFondsDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<ModificationParFondsDocumentDTO>> getDocuments(@RequestParam String p_id_fnd_code, @RequestParam(required = false) String p_id_unit_code, @RequestParam int p_id_sous_categorie, @RequestParam int p_id_langue, @RequestParam LocalDate p_date_document) {
        List<ModificationParFondsDocument> port = modificationParFondsDocumentSerInterfce.getDocumentName(p_id_fnd_code, p_id_unit_code, p_id_sous_categorie, p_id_langue, p_date_document);
        List<ModificationParFondsDocumentDTO> dtoList = port.stream().map(ModificationParFondsDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private ModificationSocieteSerInterface modificationSocieteSerInterface;

    @GetMapping("/ModificationSociete")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<String>> getModificationSociete() {
        List<String> societe = modificationSocieteSerInterface.getListSociete();
        return ok().cacheControl(CacheControl.noCache()).body(societe);

    }

    @Autowired
    private ModificationParSocieteTypeDocumentSerInterface modificationParSocieteTypeDocumentSerInterface;

    @GetMapping("/ModificationParSocieteTypeDeDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TypeDeDocumentDTO>> getParSocietetTypeDocuments(@RequestParam String p_societe) {
        List<TypeDeDocument> port = modificationParSocieteTypeDocumentSerInterface.getListeTypesDocumentsDispos(p_societe);
        List<TypeDeDocumentDTO> dtoList = port.stream().map(TypeDeDocumentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private ModificationParSocieteDateDocumentSerInterface modificationParSocieteDateDocumentSerInterface;

    @GetMapping("/ModificationParSocieteDateDocument")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<LocalDate>> getParSocieteDateDocuments(@RequestParam String p_societe, @RequestParam int p_id_sous_categorie) {
        List<LocalDate> dates = modificationParSocieteDateDocumentSerInterface.getDateDocuments(p_societe, p_id_sous_categorie);
        return ok().cacheControl(CacheControl.noCache()).body(dates);

    }

    @Autowired
    private ModificationParSocieteLangueSerInterface modificationParSocieteLangueSerInterface;

    @GetMapping("/ModificationParSocieteLangue")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<ModificationParFondsLangueDTO>> getLangues(@RequestParam String p_societe, @RequestParam int p_id_sous_categorie, @RequestParam LocalDate p_date_document) {
        List<ModificationParFondsLangue> port = modificationParSocieteLangueSerInterface.getLangues(p_societe, p_id_sous_categorie, p_date_document);
        List<ModificationParFondsLangueDTO> dtoList = port.stream().map(ModificationLangueMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }


    @Autowired
    private ModificationGabaritLangueSerInterface modificationGabaritLangueSerInterface;

    @GetMapping("/ModificationGabaritLangue")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<ModificationParFondsLangueDTO>> getGabaritLangues(@RequestParam int p_id_type_rapport) {
        List<ModificationParFondsLangue> port = modificationGabaritLangueSerInterface.getListLangue(p_id_type_rapport);
        List<ModificationParFondsLangueDTO> dtoList = port.stream().map(ModificationLangueMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private GabaritSerInterface gabaritSerInterface;

//    @GetMapping("/GetGabarit")
//
//    @ApiResponses(value = {
//            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
//            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
//                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
//            @ApiResponse(responseCode = "404", description = "Not found", content = {
//                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
//            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
//                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
//                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
//    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
//    public ResponseEntity<ModificationGabaritDTO> getGabarit(@RequestParam Long p_idGabarit) {
//        Gabarit gabarit = gabaritSerInterface.getGabarit(p_idGabarit);
//        ModificationGabaritDTO dtoList = GabaritMapper.toDto(gabarit);
//        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
//
//    }

    @GetMapping("/GetGabarit")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<?> getGabarit(@RequestParam Long p_idGabarit, @RequestParam(defaultValue = "false") boolean download) {
        Gabarit gabarit = gabaritSerInterface.getGabarit(p_idGabarit);

        if (download) {
            // Return file for download
            if (gabarit == null || gabarit.getContenu() == null) {
                return ResponseEntity.notFound().build();
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDisposition(ContentDisposition.attachment()
                    .filename(gabarit.getNom() != null ? gabarit.getNom() : "gabarit")
                    .build());
            headers.setContentLength(gabarit.getContenu().length);

            return new ResponseEntity<>(gabarit.getContenu(), headers, HttpStatus.OK);
        } else {
            // Return DTO with metadata
            ModificationGabaritDTO dtoList = GabaritMapper.toDto(gabarit);
            return ok().cacheControl(CacheControl.noCache()).body(dtoList);
        }
    }

    @Autowired
    private GetGabaritTemplateSerInterface getGabaritTemplateSerInterface;

    @GetMapping("/GetGabaritTemplates")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<?> getGabaritTemplate(@RequestParam Long p_idGabaritTemplate, @RequestParam(defaultValue = "false") boolean download) {
        GabaritTemplate gabaritTemplate = getGabaritTemplateSerInterface.getGabaritTemplate(p_idGabaritTemplate);

        if(download){
            if(gabaritTemplate == null || gabaritTemplate.getContenu() == null) {
                return ResponseEntity.notFound().build();
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDisposition(ContentDisposition.attachment()
                    .filename(gabaritTemplate.getNom() != null ? gabaritTemplate.getNom() : "gabarit_template")
                    .build());
            headers.setContentLength(gabaritTemplate.getContenu().length);

            return new ResponseEntity<>(gabaritTemplate.getContenu(), headers, HttpStatus.OK);
        }
        else {
            gabaritTemplateDTO dtoList = GabaritTemplateMapper.toDto(gabaritTemplate);
            return ok().cacheControl(CacheControl.noCache()).body(dtoList);
        }
    }


    @Autowired
    private CompartimentsStructureSerInterface compartimentsStructureSerInterface;

    @GetMapping("/CompartimentsStructure")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<StructureDTO>> getStructures(@RequestParam int p_withAtLeastOneCompatiment, @RequestParam(required = false) String p_auditor, @RequestParam(required = false) String p_accountant, @RequestParam(required = false) String p_fundMgtCompany) {
        List<Structure> structure = compartimentsStructureSerInterface.getStructures(p_withAtLeastOneCompatiment, p_auditor, p_accountant, p_fundMgtCompany);
        List<StructureDTO> dtoList = structure.stream().map(StructureMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    @Autowired
    private CompartimentsSerInterface compartimentsSerInterface;

    @GetMapping("/Compartiments")

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<CompartimentsDTO>> getCompartiments(@RequestParam String p_idStructure, @RequestParam(required = false) String p_auditor, @RequestParam(required = false) String p_accountant, @RequestParam(required = false) String p_fundMgtCompany) {
        List<Compartiment> structure = compartimentsSerInterface.getStructures(p_idStructure, p_auditor, p_accountant, p_fundMgtCompany);
        List<CompartimentsDTO> dtoList = structure.stream().map(CompartimentMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);

    }

    //**
    @GetMapping("/structures/accessibleportfoliosforstructuregabarit")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Accessible portfolios fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(
                            schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE,
                            examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)
                    )},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    }
            )
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<AccessiblePortfolioForStructureResponseDTO> getAccessiblePortfoliosForStructure(
            @RequestParam(name = "p_idStructure") final String idStructure,
            @RequestParam(name = "p_idGabarit") final Long idGabarit,
            @RequestParam(name = "p_auditor", required = false) final String auditor,
            @RequestParam(name = "p_accountant", required = false) final String accountant,
            @RequestParam(name = "p_fundMgtCompany", required = false) final String fundMgtCompany) {

        final String normalizedIdStructure = idStructure == null ? "" : idStructure.trim();

        // Legacy parity for CreationLiensStructureGabaritFonds:
        // base list must be loaded by structure only (no optional filters).
        final List<Compartiment> baseList = compartimentsSerInterface.getStructures(
                normalizedIdStructure, null, null, null);

        // selected list for structure + gabarit
        final List<Compartiment> selectedRaw = structureGabaritService.getListeCompartsByStructGab(
                normalizedIdStructure, idGabarit);

        // Temporary debug logs to validate environment behavior
        log.info("accessible-portfolios input idStructure={}, idGabarit={}", normalizedIdStructure, idGabarit);
        log.info("ignored filters for base list: auditor={}, accountant={}, fundMgtCompany={}", auditor, accountant, fundMgtCompany);
        log.info("baseList size={}, selectedRaw size={}", baseList.size(), selectedRaw.size());
        log.info("base codes raw={}", baseList.stream().map(Compartiment::getId_fnd_code).toList());
        log.info("selected codes raw={}", selectedRaw.stream().map(Compartiment::getId_fnd_code).toList());

        final Set<String> selectedNorm = selectedRaw.stream()
                .map(Compartiment::getId_fnd_code)
                .map(Chargement_controller::norm)
                .filter(value -> !value.isBlank())
                .collect(Collectors.toSet());

        // Preserve base order and deduplicate by normalized code
        final LinkedHashMap<String, AccessiblePortfolioForStructureResponseDTO.PortfolioItemDTO> baseByNorm = new LinkedHashMap<>();
        for (final Compartiment compartiment : baseList) {
            final String rawCode = compartiment.getId_fnd_code();
            final String normalizedCode = norm(rawCode);
            if (normalizedCode.isBlank()) {
                continue;
            }

            baseByNorm.putIfAbsent(
                    normalizedCode,
                    new AccessiblePortfolioForStructureResponseDTO.PortfolioItemDTO(
                            rawCode == null ? "" : rawCode.trim(),
                            firstNonBlank(compartiment.getFnd_sht_description(), "")
                    )
            );
        }

        // Split strictly from base list only
        final List<AccessiblePortfolioForStructureResponseDTO.PortfolioItemDTO> selected = baseByNorm.entrySet().stream()
                .filter(entry -> selectedNorm.contains(entry.getKey()))
                .map(Map.Entry::getValue)
                .toList();

        final List<AccessiblePortfolioForStructureResponseDTO.PortfolioItemDTO> available = baseByNorm.entrySet().stream()
                .filter(entry -> !selectedNorm.contains(entry.getKey()))
                .map(Map.Entry::getValue)
                .toList();

        return ok().cacheControl(CacheControl.noCache())
                .body(new AccessiblePortfolioForStructureResponseDTO(available, null));

    }

    private static String norm(final String value) {
        return value == null ? "" : value.trim().toUpperCase(java.util.Locale.ROOT);
    }

    private static String firstNonBlank(final String firstCandidate, final String secondCandidate) {
        if (Objects.nonNull(firstCandidate) && !firstCandidate.isBlank()) {
            return firstCandidate;
        }
        return secondCandidate;
    }




    @Autowired
    private UpdateParFondsSerInterface updateParFondsSerInterface;

    @PostMapping(value = "/UpdateParFonds", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getUpdateParFonds(@ModelAttribute DocumentDTO dto, @RequestParam String page, HttpServletRequest request) {
        MultipartFile file = dto.getFile();
        updateParFondsSerInterface.updateDocument(file, dto);

        Optional<String> user_email = authenticationService.getCurrentUserEmailId();
        updateParFondsSerInterface.AuditUpdateParFonds(file, dto, page, user_email.get(), request);
        return ResponseEntity.ok("success");

    }




    @PostMapping(value = "/UpdateParSociete", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getUpdateParSociete(@ModelAttribute DocumentDTO dto,@RequestParam String page, HttpServletRequest request) {
        MultipartFile file = dto.getFile();
        Optional<String> user_email = authenticationService.getCurrentUserEmailId();
        updateParSocieteSerInterface.updateDocument(file,dto);
        updateParSocieteSerInterface.AuditUpdateParSociete(file,dto,page,user_email.get(),request);
        return ResponseEntity.ok("success");
    }

    @Autowired
    private UpdateGabaritSerInterface updateGabaritSerInterface;

    @PostMapping(value = "/UpdateGabarit", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<String> getUpdateGabarit(@ModelAttribute ModificationGabaritDTO dto,@RequestParam String page, HttpServletRequest request) {
        MultipartFile file = dto.getFile();
        Optional<String>  user_email = authenticationService.getCurrentUserEmailId();
        updateGabaritSerInterface.updateGabarit(file,dto);
        updateGabaritSerInterface.AuditUpdateGabarit(file,dto,page,user_email.get(),request);
        return ResponseEntity.ok("success");
    }

    @Autowired
    private UpdateCompartimentsSerInterface updateCompartimentsSerInterface;

    @PostMapping(value = "/UpdateCompartiments", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")

    public ResponseEntity<String> getUpdateCompartiments(@ModelAttribute CompartimentsDTO dto,@RequestParam String page, HttpServletRequest request) {
        Optional<String> user_email = authenticationService.getCurrentUserEmailId();
        updateCompartimentsSerInterface.updateCompartimentInfos(dto);
        updateCompartimentsSerInterface.AuditUpdateCompartiments(dto,page,user_email.get(),request);
        return ResponseEntity.ok("success");
    }

    @Autowired
    private PortfolioAccessibleSerInterface portfolioAccessibleService;

    @Autowired
    private PortfolioSelectedSerInterface portfolioSelectedService;
    /**
     * Purpose: Return Portefeuille(s) accessible
     * Rules:
     * - If TypeRapport == RapportCompartiment (4): Load compartiments (ignore TypeGabarit)
     * - If TypeGabarit == Fonds (0) or FondsPart (2): Load Fonds
     * - If TypeGabarit == Structure (1): Load Structures
     */
    /**
     * Purpose: Return Portefeuille(s) accessible
     * Rules:
     * - If TypeRapport == RapportCompartiment (4): Load compartiments (ignore TypeGabarit)
     * - If TypeGabarit == Fonds (0) or FondsPart (2): Load Fonds
     * - If TypeGabarit == Structure (1): Load Structures
     * TypeGabarit is resolved server-side from p_idGabarit (DB field: type)
     */
    @GetMapping("/portfolio/accessible")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Accessible portfolios successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request - Missing required parameters",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
            @ApiResponse(responseCode = "429", description = "Quota exceeded",
                    content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE,
                            examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")})
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<?> getAccessiblePortfolios(
            @RequestParam(name = "p_idTypeRapport") Long p_idTypeRapport,
            @RequestParam(name = "p_idGabarit") Long p_idGabarit,
            @RequestParam(name = "p_idLangue") Long p_idLangue,
            @RequestParam(name = "p_auditor", required = false) String p_auditor,
            @RequestParam(name = "p_accountant", required = false) String p_accountant,
            @RequestParam(name = "p_fundMgtCompany", required = false) String p_fundMgtCompany) {

        List<portefeuilleDTO> portfolios = portfolioAccessibleService.getAccessiblePortfolios(
                p_idTypeRapport, p_idGabarit, p_idLangue, p_auditor, p_accountant, p_fundMgtCompany);

        return ok().cacheControl(CacheControl.noCache()).body(portfolios);
    }





    /**
     * Purpose: Return Portefeuille(s) sélectionné(s) (already linked to a gabarit)
     * - If TypeRapport == RapportCompartiment (4): Use GetListeCompartsByGabarit
     * - If TypeGabarit == Fonds (0) or FondsPart (2): Use GetFondsSimplesByGabarit
     * - If TypeGabarit == Structure (1): Use GetListeStructuresByGabarit
     */
    @GetMapping("/portfolio/selected")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Selected portfolios successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request - Missing required parameters",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
            @ApiResponse(responseCode = "429", description = "Quota exceeded",
                    content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE,
                            examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")})
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<?> getSelectedPortfolios(
            @RequestParam(name = "p_idTypeRapport") Long p_idTypeRapport,
            @RequestParam(name = "p_idGabarit") Long p_idGabarit,
            @RequestParam(name = "p_idLangue") Long p_idLangue,
            @RequestParam(name = "p_auditor", required = false) String p_auditor,
            @RequestParam(name = "p_accountant", required = false) String p_accountant,
            @RequestParam(name = "p_fundMgtCompany", required = false) String p_fundMgtCompany) {

        List<portefeuilleDTO> portfolios = portfolioSelectedService.getSelectedPortfolios(
                p_idTypeRapport, p_idGabarit, p_idLangue, p_auditor, p_accountant, p_fundMgtCompany);

        return ok().cacheControl(CacheControl.noCache()).body(portfolios);
    }




    @Autowired
    private StructureSerInterface structureSerInterface;

    @GetMapping("/structures")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Structures successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)})
    })
    public ResponseEntity<List<StructureDTO>> getListeStructures(
            @RequestParam(required = false) String p_auditor,
            @RequestParam(required = false) String p_accountant,
            @RequestParam(required = false) String p_fundMgtCompany) {

        List<Structure> structures = structureSerInterface.getListeStructures(p_auditor, p_accountant, p_fundMgtCompany);
        List<StructureDTO> dtoList = structures.stream()
                .map(StructureMapper::toDto)
                .toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private DeviseSerInterface deviseSerInterface;

    @GetMapping("/devises")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Devises successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE,
                            examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<DeviseDTO>> getListeDevises() {
        List<Devise> devises = deviseSerInterface.getListeDevises();
        List<DeviseDTO> dtoList = devises.stream().map(DeviseMapper::toDto).toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private ValidateLiensFondsGabaritSerInterface validateLiensFondsGabaritService;

    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
    @Operation(
            summary = "Validate Gabarit — link fonds",
            description = "Calls QXP_PK_CHARGEMENT.InsertLiensFondsGabarit. " +
                    "Deletes existing links and inserts the new list into QXP_ASSO_FOND_GABARIT.",
            security = @SecurityRequirement(name = "sgconnect", scopes = {"api.ast-link-app.v1"})
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Gabarit validated and fonds linked"),
            @ApiResponse(responseCode = "400", description = "Invalid request body",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE))
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    @PostMapping(value = "/ValidateLienGabaritFonds", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<LiensFondsGabaritResponseDTO> validateGabarit(
            @RequestBody ValidateLiensFondsGabaritDTO dto,
            HttpServletRequest request) {

        LiensFondsGabaritResponseDTO response =
                validateLiensFondsGabaritService.validateAndLinkFonds(dto, request);

        if (response.isSuccess()) {
            Optional<String> user_email = authenticationService.getCurrentUserEmailId();
            validateLiensFondsGabaritService.auditLiensFondsGabarit(
                    dto, "gabarits/validate", user_email.orElse("UNKNOWN"), request);
            return ok().cacheControl(CacheControl.noCache()).body(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }


    @Autowired
    private StructureCreationSerInterface structureCreationService;

    /**
     * GET compartments available for structure creation.
     * p_id_structure: specific structure ID or "%" for all
     */
    @GetMapping("/compartiments-dispos")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Compartiments dispos fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE))
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<CompartimentDispoDTO>> getCompartimentsDispos(
            @RequestParam(name = "p_id_structure", defaultValue = "%") String idStructure) {

        List<CompartimentDispoDTO> compartiments = structureCreationService.getCompartimentsDispos(idStructure);
        return ok().cacheControl(CacheControl.noCache()).body(compartiments);
    }

    /**
     * GET structure details by ID.
     * If idStructure = "NOUVELLE_STRUCTURE", returns empty structure for creation form.
     */
    @GetMapping("/structures/{idStructure}")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Structure details fetched"),
            @ApiResponse(responseCode = "404", description = "Structure not found",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE))
    })
    public ResponseEntity<StructureDTO> getStructureDetails(@PathVariable String idStructure) {
        try {
            StructureDTO dto = structureCreationService.getStructureDetails(idStructure);
            return ok().cacheControl(CacheControl.noCache()).body(dto);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * POST create new structure.
     * Validates that structure doesn't already exist.
     */
    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
    @PostMapping(value = "/structures", produces = APPLICATION_JSON_VALUE)
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Structure created successfully"),
            @ApiResponse(responseCode = "400", description = "Bad Request - Structure already exists or invalid data",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE))
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<?> createStructure(@RequestBody StructureDTO dto) {
        try {
            StructureDTO created = structureCreationService.createStructure(dto);
            return ok().cacheControl(CacheControl.noCache()).body(created);
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @Autowired
    private GabaritsByStructureSerInterface gabaritsByStructureSerInterface;

    @GetMapping("/GabaritsByStructure")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Service Activity Info successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"), @Header(name = "X-RateLimit-Reset")})})
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<GabaritByStructureDTO>> getGabaritsByStructure(@RequestParam String p_idStructure) {
        List<GabaritByStructure> gabarits = gabaritsByStructureSerInterface.getGabaritsByStructure(p_idStructure);
        List<GabaritByStructureDTO> dtoList = gabarits.stream()
                .sorted(Comparator.comparingLong(g -> {
                    try {
                        return Long.parseLong(g.getNom().trim().split("\\s+")[0].replaceAll("[^0-9]", ""));
                    } catch (NumberFormatException e) {
                        return Long.MAX_VALUE;
                    }
                }))
                .map(GabaritByStructureMapper::toDto)
                .toList();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private StructureValidateSerInterface structureValidateService;

    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
    @PostMapping(value = "/ValidateLienStructureFonds", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> validateStructure(@RequestBody ValidateStructureRequestDTO dto) {
        try {
            ValidateStructureResponseDTO response = structureValidateService.validateStructure(dto);
            return ok().cacheControl(CacheControl.noCache()).body(response);
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }


    @Autowired
    private StructureGabaritSerInterface structureGabaritService;

    /**
     * GET /api/v1/structures/presentation
     * Returns id_presentation_patrimoine + id_presentation_compte_res
     * for the given structure + gabarit combination.
     * Calls QXP_PK_CHARGEMENT.GetPresentationStructure(p_idStructure, p_idGabarit)
     */
    @GetMapping("/structures/presentation")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Presentation structure fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
            @ApiResponse(responseCode = "429", description = "Quota exceeded",
                    content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE,
                            examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")})
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<PresentationStructureDTO>> getPresentationStructure(
            @RequestParam(name = "p_idStructure") String idStructure,
            @RequestParam(name = "p_idGabarit")   Long idGabarit) {

        List<PresentationStructure> results =
                structureGabaritService.getPresentationStructure(idStructure, idGabarit);

        List<PresentationStructureDTO> dtoList = results.stream()
                .map(PresentationStructureMapper::toDto)
                .toList();

        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    /**
     * GET /api/v1/portfolio/selected-by-struct-gab
     * Returns compartments already linked to the given structure + gabarit,
     * ordered by position. Used for the structure-gabarit-fonds page.
     * Calls QXP_PK_CHARGEMENT.GetListeCompartsByStructGab(p_idStructure, p_idGabarit)
     */
    @GetMapping("/portfolio/selected-by-struct-gab")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Compartments for structure-gabarit fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
            @ApiResponse(responseCode = "429", description = "Quota exceeded",
                    content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE,
                            examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")})
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<CompartimentsDTO>> getListeCompartsByStructGab(
            @RequestParam(name = "p_idStructure") String idStructure,
            @RequestParam(name = "p_idGabarit")   Long idGabarit) {

        List<Compartiment> results =
                structureGabaritService.getListeCompartsByStructGab(idStructure, idGabarit);

        List<CompartimentsDTO> dtoList = results.stream()
                .map(CompartimentMapper::toDto)
                .toList();

        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }


    @Autowired
    private ValidateStructureGabaritFondsSerInterface validateStructureGabaritFondsService;

    /**
     * POST /api/v1/ValidateStructureGabaritFonds
     *
     * Deletes all existing compartiment associations for the given structure+gabarit,
     * then re-inserts the supplied list with position ordering.
     * Calls QXP_PK_GP.InsertLiensStructGabComparts(
     *     p_idStructure, p_idGabarit, p_listeCompartiments,
     *     p_idPresentationPatrimoine, p_idPresentationCompteRes)
     */
    @PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
    @Operation(
            summary = "Validate Structure-Gabarit-Fonds links",
            description = "Replaces compartiment associations for a structure+gabarit combination. " +
                    "Deletes existing rows in QXP_ASSO_STRUCT_GABARIT_COMP then inserts the new list " +
                    "with position ordering.",
            security = @SecurityRequirement(name = "sgconnect", scopes = {"api.ast-link-app.v1"})
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Compartiments linked successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request body",
                    content = @Content(schema = @Schema(implementation = Problem.class),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE)),
            @ApiResponse(responseCode = "429", description = "Quota exceeded",
                    content = @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"),
                            mediaType = APPLICATION_PROBLEM_JSON_VALUE,
                            examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE)),
                    headers = {@Header(name = "X-RateLimit-Limit"), @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")})
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    @PostMapping(value = "/ValidateStructureGabaritFonds", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<StructureGabaritFondsResponseDTO> validateStructureGabaritFonds(
            @RequestBody ValidateStructureGabaritFondsDTO dto,
            HttpServletRequest request) {

        StructureGabaritFondsResponseDTO response =
                validateStructureGabaritFondsService.validateAndLinkCompartiments(dto, request);

        if (response.isSuccess()) {
            return ok().cacheControl(CacheControl.noCache()).body(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }


    /**
     * Helper method to convert domain objects to DTOs for portfolios
     */
    private List<?> sortPortfoliosNumerically(List<?> portfolios) {
        if (portfolios.isEmpty()) {
            return portfolios;
        }

        Object first = portfolios.get(0);
        if (first instanceof Fonds) {
            return ((List<Fonds>) (List<?>) portfolios).stream()
                    .sorted(Comparator.comparingLong(f -> {
                        try { return Long.parseLong(f.getId_fnd_code()); }
                        catch (NumberFormatException e) { return Long.MAX_VALUE; }
                    }))
                    .toList();
        } else if (first instanceof Structure) {
            return ((List<Structure>) (List<?>) portfolios).stream()
                    .sorted(Comparator.comparingLong(s -> {
                        try { return Long.parseLong(s.getIdStructure()); }
                        catch (NumberFormatException e) { return Long.MAX_VALUE; }
                    }))
                    .toList();
        } else if (first instanceof Compartiment) {
            return ((List<Compartiment>) (List<?>) portfolios).stream()
                    .sorted(Comparator.comparingLong(c -> {
                        try { return Long.parseLong(c.getId_fnd_code()); }
                        catch (NumberFormatException e) { return Long.MAX_VALUE; }
                    }))
                    .toList();
        }

        return portfolios;
    }

    private List<?> convertToPortfolioDTO(List<?> portfolios) {
        if (portfolios.isEmpty()) {
            return List.of();
        }

        Object first = portfolios.get(0);
        if (first instanceof Fonds) {
            return ((List<Fonds>) (List<?>) portfolios).stream()
                    .map(FondsMapper::toDto)
                    .toList();
        } else if (first instanceof Structure) {
            return ((List<Structure>) (List<?>) portfolios).stream()
                    .map(StructureMapper::toDto)
                    .toList();
        } else if (first instanceof Compartiment) {
            return ((List<Compartiment>) (List<?>) portfolios).stream()
                    .map(CompartimentMapper::toDto)
                    .toList();
        }

        return List.of();
    }


}