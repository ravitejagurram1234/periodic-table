package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateParSocieteDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
@Repository
public class SimpleJDBCupdateParSociete implements UpdateParSocieteDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCupdateParSociete(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_CHARGEMENT")
                .withProcedureName("UpdateDocumentParSociete")
                .declareParameters(
                        new SqlParameter("p_societe", Types.VARCHAR),
                        new SqlParameter("p_id_sous_categorie", Types.NUMERIC),
                        new SqlParameter("p_date_document", Types.DATE),
                        new SqlParameter("p_id_langue", Types.NUMERIC),
                        new SqlParameter("p_contenu", Types.VARBINARY),
                        new SqlParameter("p_taille_document", Types.NUMERIC),
                        new SqlParameter("p_nom_document", Types.VARCHAR),
                        new SqlParameter("p_format", Types.VARCHAR),
                        new SqlParameter("p_email", Types.VARCHAR),
                        new SqlParameter("p_is_actif", Types.NUMERIC)

                );
    }

    public void updateParSociete(Document document) {

        Date sqlDate1= (document.getP_date_document()!=null)?java.sql.Date.valueOf(document.getP_date_document()):null;

        Map<String, Object> params = new HashMap<>();
        params.put("p_societe", document.getP_societe());
        params.put("p_id_sous_categorie",document.getP_id_sous_categorie());
        params.put("p_date_document", sqlDate1);
        params.put("p_id_langue", document.getP_id_langue());
        params.put("p_contenu", document.getP_contenu());
        params.put("p_taille_document", document.getP_taille_document());
        params.put("p_nom_document", document.getP_nom_document());
        params.put("p_format",document.getP_format());
        params.put("p_email", document.getP_email());
        params.put("p_is_actif",document.getP_is_actif());

        simpleJdbcCall.execute(params);
    }
}
