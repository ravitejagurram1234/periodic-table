package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Maquettiste;
import com.socgen.sgs.api.quark.backend.api.infra.dao.MaquettisteDao;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MaquettisteBusiness {

    private final MaquettisteDao dao;

    public MaquettisteBusiness(MaquettisteDao dao) {
        this.dao = dao;
    }

    public List<Maquettiste> getMaquettiste() {
        return dao.getMaquettiste();
    }
}