package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.GetListANOMapper;
import com.socgen.sgs.api.quark.backend.api.domain.GetListANO;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GetListANODAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCGetListANO implements GetListANODAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCGetListANO(DataSource dataSource) {

        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetListeANOByRun")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(
                                "RETURN_VALUE",
                                OracleTypes.CURSOR,
                                (rs, rowNum) -> GetListANOMapper.mapResult(rs)
                        ),
                        new SqlParameter(
                                "p_id_run",
                                Types.NUMERIC
                        )
                );
    }

    @Override
    public List<GetListANO> getListeANOByRun(Long p_id_run) {

        Map<String, Object> params =
                Map.of("p_id_run", p_id_run);

        try {

            Map<String, Object> result =
                    simpleJdbcCall.execute(params);

            List<GetListANO> anoList =
                    (List<GetListANO>) result.get("RETURN_VALUE");

            return (List<GetListANO>) result.get("RETURN_VALUE");

        } catch (Exception e) {

            System.err.println(
                    "Error during JDBC call : "
                            + e.getMessage()
            );

            e.printStackTrace();

            return null;
        }
    }
}