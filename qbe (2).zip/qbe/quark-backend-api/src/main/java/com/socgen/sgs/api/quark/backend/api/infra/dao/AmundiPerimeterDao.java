package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiPerimeterRecord;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface AmundiPerimeterDao {

    Map<String, Integer> findLiveColumnLengths();

    Set<String> findExistingFundCodes(Set<String> fundCodes);

    int deleteMatching(List<AmundiPerimeterRecord> records);

    int insert(List<AmundiPerimeterRecord> records);

    int update(List<AmundiPerimeterRecord> records);
}