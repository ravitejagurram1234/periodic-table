package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeSuivisCompartBySuivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBGetListeSuivisCompartBySuiviDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBGetListeSuivisCompartBySuiviSerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TDBGetListeSuivisCompartBySuiviService
        implements TDBGetListeSuivisCompartBySuiviSerInterface {

    @Autowired
    private TDBGetListeSuivisCompartBySuiviDAO dao;

    @Override
    public List<TDBGetListeSuivisCompartBySuivi>
    getListeSuivisCompartBySuivi(
            Long p_idSuivi,
            Long p_idTache) {

        return dao.getListeSuivisCompartBySuivi(
                p_idSuivi,
                p_idTache
        );
    }
}