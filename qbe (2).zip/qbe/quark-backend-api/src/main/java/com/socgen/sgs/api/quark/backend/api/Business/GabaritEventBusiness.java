package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.GabaritEvents;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritEventDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class GabaritEventBusiness {

    private final GabaritEventDao gabaritEventDao;

    public GabaritEventBusiness(GabaritEventDao gabaritEventDao) {
        this.gabaritEventDao = gabaritEventDao;
    }

    public List<GabaritEvents> getGabaritEvents(Long p_idGabarit) {
        return gabaritEventDao.getGabaritEvent(p_idGabarit);
    }
}