package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.portefeuille;
import com.socgen.sgs.api.quark.backend.api.infra.dao.portefeuilleDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class portefeuilleBusiness {

    private final portefeuilleDao portefeuilleDao;

    public portefeuilleBusiness(portefeuilleDao portefeuilleDao) {
        this.portefeuilleDao = portefeuilleDao;
    }

    public List<portefeuille> getPortefeuille() {
        return portefeuilleDao.getPortefeuille();
    }
}