package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.domain.TDBWorkflowStatutSuivi;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TDBWorkflowStatutSuiviMapper {

    public static TDBWorkflowStatutSuivi mapResult(
            ResultSet rs) throws SQLException {

        TDBWorkflowStatutSuivi workflow = new TDBWorkflowStatutSuivi();

        workflow.setIdStatutFrom(rs.getLong("ID_STATUT_FROM"));

        workflow.setIdStatutTo(rs.getLong("ID_STATUT_TO"));

        workflow.setTypeRapport(rs.getLong("TYPE_RAPPORT"));

        workflow.setIdRole(rs.getLong("ID_ROLE"));

        return workflow;
    }
}