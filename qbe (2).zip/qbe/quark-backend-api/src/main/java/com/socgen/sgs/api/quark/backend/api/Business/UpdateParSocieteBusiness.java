package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.UpdateParSocieteDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UpdateParSocieteBusiness {

    private final UpdateParSocieteDao updateParSocieteDao;

    public UpdateParSocieteBusiness(UpdateParSocieteDao updateParSocieteDao) {
        this.updateParSocieteDao = updateParSocieteDao;
    }

    public void updateParSociete(Document document) {
        updateParSocieteDao.updateParSociete(document);
    }
}