package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.TDBGetListeEventsByGabaritMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeEventsByGabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBGetListeEventsByGabaritDAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCTDBGetListeEventsByGabarit
        implements TDBGetListeEventsByGabaritDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBGetListeEventsByGabarit(
            DataSource dataSource) {

        this.simpleJdbcCall =
                new SimpleJdbcCall(dataSource)
                        .withCatalogName("QXP_PK_SUIVI")
                        .withFunctionName("GetListeEventsByGabarit")
                        .withoutProcedureColumnMetaDataAccess()
                        .declareParameters(
                                new SqlParameter(
                                        "p_idGabarit",
                                        Types.NUMERIC
                                ),
                                new SqlOutParameter(
                                        "RETURN_VALUE",
                                        OracleTypes.CURSOR,
                                        (rs, rowNum) ->
                                                TDBGetListeEventsByGabaritMapper
                                                        .mapResult(rs)
                                )
                        );
    }

    @Override
    public List<TDBGetListeEventsByGabarit>
    getListeEventsByGabarit(
            Long p_idGabarit) {

        Map<String, Object> result =
                simpleJdbcCall.execute(
                        Map.of(
                                "p_idGabarit",
                                p_idGabarit
                        )
                );

        return (List<TDBGetListeEventsByGabarit>)
                result.get("RETURN_VALUE");
    }
}