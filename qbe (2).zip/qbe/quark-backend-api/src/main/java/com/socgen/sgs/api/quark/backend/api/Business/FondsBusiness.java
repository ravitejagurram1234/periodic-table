package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Fonds;
import com.socgen.sgs.api.quark.backend.api.infra.dao.FondsDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class FondsBusiness {

    private final FondsDao fondsDao;

    public FondsBusiness(FondsDao fondsDao) {
        this.fondsDao = fondsDao;
    }

    public List<Fonds> getListeFondsForNewSuivi(
            Long p_idTypeRapport,
            Long p_idLangue,
            Long p_idGabarit,
            LocalDate p_dateEcheance) {

        return fondsDao.getListeFondsForNewSuivi(
                p_idTypeRapport,
                p_idLangue,
                p_idGabarit,
                p_dateEcheance);
    }
}