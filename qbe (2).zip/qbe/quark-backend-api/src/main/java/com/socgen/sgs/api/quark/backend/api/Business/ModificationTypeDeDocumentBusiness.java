package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationTypeDeDocumentDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ModificationTypeDeDocumentBusiness {

    private final ModificationTypeDeDocumentDao modificationTypeDeDocumentDao;

    public ModificationTypeDeDocumentBusiness(
            ModificationTypeDeDocumentDao modificationTypeDeDocumentDao) {
        this.modificationTypeDeDocumentDao = modificationTypeDeDocumentDao;
    }

    public List<TypeDeDocument> getListTypeDocuments() {
        return modificationTypeDeDocumentDao.getListTypeDocuments();
    }
}