package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TDBFondsPartStructuresDTO {

    private List<TDBFondsPartDTO> fondsPart;
    private List<TDBStructuresDTO> structures;

}