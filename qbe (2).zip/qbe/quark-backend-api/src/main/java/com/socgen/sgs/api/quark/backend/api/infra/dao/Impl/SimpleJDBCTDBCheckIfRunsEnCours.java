package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.TDBCheckIfRunsEnCoursMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBCheckIfRunsEnCours;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBCheckIfRunsEnCoursDAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCTDBCheckIfRunsEnCours
        implements TDBCheckIfRunsEnCoursDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBCheckIfRunsEnCours(
            DataSource dataSource) {

        this.simpleJdbcCall =
                new SimpleJdbcCall(dataSource)
                        .withCatalogName("QXP_PK_SUIVI")
                        .withFunctionName("CheckIfRunsEnCours")
                        .withoutProcedureColumnMetaDataAccess()
                        .declareParameters(
                                new SqlOutParameter(
                                        "RETURN_VALUE",
                                        OracleTypes.CURSOR,
                                        (rs, rowNum) ->
                                                TDBCheckIfRunsEnCoursMapper
                                                        .mapResult(rs)
                                ),
                                new SqlParameter(
                                        "p_ids",
                                        OracleTypes.ARRAY
                                ),
                                new SqlParameter(
                                        "p_id_unit_codes",
                                        OracleTypes.ARRAY
                                ),
                                new SqlParameter(
                                        "p_idLangue",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_idGabarit",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_dateEcheance",
                                        Types.DATE
                                )
                        );
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<TDBCheckIfRunsEnCours> checkIfRunsEnCours(
            String[] p_ids,
            String[] p_id_unit_codes,
            Long p_idLangue,
            Long p_idGabarit,
            LocalDate p_dateEcheance) {

        try {

            Map<String, Object> result =
                    simpleJdbcCall.execute(
                            Map.of(
                                    "p_ids", p_ids,
                                    "p_id_unit_codes", p_id_unit_codes,
                                    "p_idLangue", p_idLangue,
                                    "p_idGabarit", p_idGabarit,
                                    "p_dateEcheance",
                                    java.sql.Date.valueOf(
                                            p_dateEcheance
                                    )
                            )
                    );

            return (List<TDBCheckIfRunsEnCours>)
                    result.get("RETURN_VALUE");

        } catch (Exception ex) {

            ex.printStackTrace();

            return Collections.emptyList();
        }
    }
}