package com.socgen.sgs.api.quark.backend.api.domain;


import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TDBDocument {

    private byte[] contenu;

}