package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.GetListANO;

import java.util.List;

public interface GetListANOSerInterface {

    List<GetListANO> getListeANOByRun(Long p_id_run);

}