package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBInsertRunDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.Map;

@Repository
public class SimpleJDBCTDBInsertRun
        implements TDBInsertRunDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBInsertRun(
            DataSource dataSource) {

        this.simpleJdbcCall =
                new SimpleJdbcCall(dataSource)
                        .withCatalogName("QXP_PK_SUIVI")
                        .withFunctionName("InsertRun")
                        .withoutProcedureColumnMetaDataAccess()
                        .declareParameters(
                                new SqlOutParameter(
                                        "RETURN_VALUE",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_idSuivi",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_datePlanification",
                                        Types.TIMESTAMP
                                ),
                                new SqlParameter(
                                        "p_gabarit_source",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_idCreateur",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_email",
                                        Types.VARCHAR
                                ),
                                new SqlParameter(
                                        "p_integrerN1",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_modeCompart",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_idSuiviSrc",
                                        Types.NUMERIC
                                )
                        );
    }

    @Override
    public Long insertRun(
            Long p_idSuivi,
            LocalDateTime p_datePlanification,
            Long p_gabarit_source,
            Long p_idCreateur,
            String p_email,
            Long p_integrerN1,
            Long p_modeCompart,
            Long p_idSuiviSrc) {

        Map<String, Object> result =
                simpleJdbcCall.execute(
                        Map.of(
                                "p_idSuivi", p_idSuivi,
                                "p_datePlanification",
                                p_datePlanification,
                                "p_gabarit_source",
                                p_gabarit_source,
                                "p_idCreateur",
                                p_idCreateur,
                                "p_email",
                                p_email,
                                "p_integrerN1",
                                p_integrerN1,
                                "p_modeCompart",
                                p_modeCompart,
                                "p_idSuiviSrc",
                                p_idSuiviSrc
                        )
                );

        return ((Number)
                result.get("RETURN_VALUE"))
                .longValue();
    }
}