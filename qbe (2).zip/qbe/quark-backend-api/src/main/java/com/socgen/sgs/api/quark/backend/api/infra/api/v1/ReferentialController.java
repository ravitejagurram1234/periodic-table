package com.socgen.sgs.api.quark.backend.api.infra.api.v1;

import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiDateFormat;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportMode;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportTemplateConfiguration;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.AmundiImportValidationResult;
import com.socgen.sgs.api.quark.backend.api.domain.AmundiImportModels.UploadedFile;
import com.socgen.sgs.api.quark.backend.api.domain.FeatureExceptions.ImportRejectedException;
import com.socgen.sgs.api.quark.backend.api.service.AmundiPerimeterImportSerInterface;
import com.socgen.sgs.api.quark.backend.api.service.IAuthenticationService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

@RestController
@RequestMapping("/api/v1/referential")
@PreAuthorize("hasAuthority('SCOPE_api.quark.v1')")
@RequiredArgsConstructor
public class ReferentialController {

    private static final String EXTERNAL_API = "external_api";

    private final AmundiPerimeterImportSerInterface importService;
    private final IAuthenticationService authenticationService;

    @GetMapping("/import-templates")
    public ResponseEntity<List<AmundiImportTemplateConfiguration>> importTemplates() {
        return ResponseEntity.ok()
                .cacheControl(CacheControl.noStore())
                .body(List.of(importService.configuration()));
    }

    @PostMapping(value = "/amundi-perimeter/validate", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<AmundiImportValidationResult> validate(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "dateFormat", defaultValue = "DD_MM_YYYY")
            AmundiDateFormat dateFormat,
            HttpServletRequest request) {

        AmundiImportValidationResult result = importService.validate(
                uploadedFile(file), dateFormat, currentHumanEmail(), clientIp(request));
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(result);
    }

    @PostMapping(value = "/amundi-perimeter/import", consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<AmundiImportResult> importFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "dateFormat", defaultValue = "DD_MM_YYYY")
            AmundiDateFormat dateFormat,
            @RequestParam(value = "mode", defaultValue = "DELETE_AND_INSERT")
            AmundiImportMode mode,
            @RequestParam("expectedChecksum") String expectedChecksum,
            HttpServletRequest request) {

        AmundiImportResult result = importService.importFile(
                uploadedFile(file), dateFormat, mode, expectedChecksum,
                currentHumanEmail(), clientIp(request));
        return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(result);
    }

    private UploadedFile uploadedFile(MultipartFile file) {
        try {
            return new UploadedFile(file.getOriginalFilename(), file.getBytes());
        } catch (IOException exception) {
            throw new ImportRejectedException("Unable to read the uploaded CSV file", exception);
        }
    }

    private String currentHumanEmail() {
        String email = authenticationService.getCurrentUserEmailId()
                .filter(value -> !value.isBlank())
                .orElseThrow(() -> new AccessDeniedException(
                        "The authenticated SGIAM/SG Connect token has no mail claim"));
        if (EXTERNAL_API.equalsIgnoreCase(email)) {
            throw new AccessDeniedException(
                    "A human SGIAM/SG Connect identity is required for an interactive import");
        }
        return email;
    }

    private String clientIp(HttpServletRequest request) {
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        String realIp = request.getHeader("X-Real-IP");
        return realIp == null || realIp.isBlank() ? request.getRemoteAddr() : realIp.trim();
    }
}