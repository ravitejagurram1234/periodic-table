package com.socgen.sgs.api.quark.backend.api.infra.api.v1;

import com.socgen.apibank.http.ratelimiter.RateLimiter;
import com.socgen.sgs.api.quark.backend.api.Dto.*;
import com.socgen.sgs.api.quark.backend.api.Mapper.*;
import com.socgen.sgs.api.quark.backend.api.domain.TDBCheckIfRunsEnCours;
import com.socgen.sgs.api.quark.backend.api.domain.TDBDocument;
import com.socgen.sgs.api.quark.backend.api.domain.TDBFondsPartStructures;
import com.socgen.sgs.api.quark.backend.api.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.Problem;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_PROBLEM_JSON_VALUE;
import static org.springframework.http.ResponseEntity.ok;

@Slf4j
@RestController
@RequestMapping(value = "/api/v1/")
public class TableDeBoard_controller {

    private static final String QUOTA_EXCEEDED_EXAMPLE = "";

    @Autowired
    private FondsHaveSuiviSerInterface fondsHaveSuiviService;

    @GetMapping("/fonds-have-suivi")
    @Operation(
            summary = "Retrieve accessible portfolios",
            description = "Retrieves the accessible portfolios displayed on the Tableau de Bord - Page 1 screen."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Funds having suivi successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    })
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<FondsHaveSuiviDto>> getListeFondsHaveSuivi(
            @RequestParam Long p_idLangue,
            @RequestParam LocalDate p_dateEcheance,
            @RequestParam Long p_idTypeRapport) {

        List<FondsHaveSuiviDto> result =
                fondsHaveSuiviService.getListeFondsHaveSuivi(
                        p_idLangue,
                        p_dateEcheance,
                        p_idTypeRapport
                );

        return ok().cacheControl(CacheControl.noCache()).body(result);
    }

    @Autowired TDBDocumentSerInterface tdbDocumentSerInterface;
    @GetMapping("/getDocument")
    @Operation(
            summary = "Retrieve documents (.qxp, .pdf, and .doc)",
            description = "Retrieves one of the available document formats used in Tableau de Bord - Page 2. " +
                    "The p_idSuivi parameter represents the suivi identifier, and p_idTypeDocument specifies the document type to return:\n" +
                    "• 1 = QXP document (.qxp)\n" +
                    "• 2 = PDF document (.pdf)\n" +
                    "• 3 = Word document (.doc)"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Document content successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    })
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<TDBDocumentDTO> getDocument(
            @RequestParam Long p_idSuivi,
            @RequestParam Long p_idTypeDocument) {

        TDBDocument document =
                tdbDocumentSerInterface.getContenuDocument(
                        p_idSuivi,
                        p_idTypeDocument
                );

        if(document == null)
            return ResponseEntity.noContent().build();

        TDBDocumentDTO dto = TDBDocumentMapper.toDto(document);

        return ok().cacheControl(CacheControl.noCache()).body(dto);
    }


    @Autowired
    private TDBFondsPartStructuresSerInterface tdbFondsPartStructuresSerInterface;
    @GetMapping("/TDBFondsPart_Structures")
    @Operation(
            summary = "Retrieve Tableau de Bord Page 2 suivi records",
            description = "Retrieves the suivi records displayed in Tableau de Bord - Page 2. " +
                    "The API returns both Fonds/Parts and Structures data associated with the selected portfolios. " +
                    "The p_portfolio parameter accepts one or more portfolio identifiers."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Suivi records successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    })
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<TDBFondsPartStructuresDTO> getListeSuivisTDB(
            @RequestParam Long p_idLangue,
            @RequestParam LocalDate p_dateEcheance,
            @RequestParam String p_portfolio,
            @RequestParam(required = false) Long p_idMaquettiste,
            @RequestParam(required = false) Long p_idStatutSuivi,
            @RequestParam Long p_idTypeRapport,
            @RequestParam(required = false) String p_auditor,
            @RequestParam(required = false) String p_accountant,
            @RequestParam(required = false) String p_fundMgtCompany) {

        TDBFondsPartStructures response = tdbFondsPartStructuresSerInterface.getListeSuivis(
                        p_idLangue,
                        p_dateEcheance,
                        p_portfolio,
                        p_idMaquettiste,
                        p_idStatutSuivi,
                        p_idTypeRapport,
                        p_auditor,
                        p_accountant,
                        p_fundMgtCompany
                );

        TDBFondsPartStructuresDTO dto = TDBFondsPartStructuresMapper.toDto(response);

        return ok().cacheControl(CacheControl.noCache()).body(dto);
    }

    @Autowired
    private GetListANOSerInterface getListANOSerInterface;
    @GetMapping("/anolink")
    @Operation(
            summary = "Retrieve ANO message",
            description = "Retrieves the ANO message associated with the specified run identifier. " +
                    "The parameter p_id_run corresponds to either ID_RUN_ANO or ID_RUN_PRECEDENT " +
                    "used in the Tableau de Bord - Page 2 screen."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "ANO message successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    })
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<GetListANODTO>> getAnoLink(
            @RequestParam Long p_id_run) {

        List<GetListANODTO> dtoList = getListANOSerInterface.getListeANOByRun(p_id_run)
                        .stream()
                        .map(GetListANOMapper::toDto)
                        .toList();
        if(dtoList==null || dtoList.isEmpty())
            return ResponseEntity.noContent().build();
        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private TDBStatutSuiviSerInterface tdbStatutSuiviSerInterface;
    @GetMapping("/statutsuivi")
    @Operation(
            summary = "Retrieve suivi statuses",
            description = "Retrieves the list of suivi statuses used in Tableau de Bord. " +
                    "The result is built by combining the data returned by GetListeStatutsSuivi " +
                    "and GetWorkflowSuiviStatut from package QXP_PK_SUIVI. " +
                    "The workflow result is filtered using the supplied p_idTypeRapport value " +
                    "against the TYPE_RAPPORT column. " +
                    "A status is included when its ID_STATUT_SUIVI matches either " +
                    "ID_STATUT_FROM or ID_STATUT_TO from the workflow definition. " +
                    "The final result contains distinct status values only."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Suivi statuses successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    })
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TDBStatutSuiviDTO>> getStatutsSuivi(
            @RequestParam Long p_idTypeRapport) {

        List<TDBStatutSuiviDTO> dtoList = tdbStatutSuiviSerInterface.getStatutsSuivi(p_idTypeRapport)
                        .stream()
                        .map(TDBStatutSuiviMapper::toDto)
                        .toList();

        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private TDBWorkflowStatutSerInterface tdbWorkflowStatutSerInterface;
    @Operation(
            summary = "Get available workflow statuses",
            description =
                    "Returns the list of available target statuses according to the source status, report type and connected user role."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Statuses retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    })
    })

    @GetMapping("/statut")
    public ResponseEntity<List<TDBStatutSuiviDTO>> getStatuts(@RequestParam Long idStatutFrom, @RequestParam Long typeRapport, @RequestParam Long typeSuivi) {

        TDBWorkflowStatutRequestDTO request = new TDBWorkflowStatutRequestDTO(idStatutFrom, typeRapport, typeSuivi);

        return ResponseEntity.ok(tdbWorkflowStatutSerInterface.getStatuts(request));

    }

    @Autowired
    private TDBGetListeTachesByGabAndTypeSerInterface tdbGetListeTachesByGabAndTypeSerInterface;
    @GetMapping("/GetListeTachesByGabAndType")
    @Operation(
            summary = "Retrieve tasks by gabarit and report type",
            description = "Retrieves the list of tasks used in Tableau de Bord - Page 3. <br>" +
                    "The endpoint supports four use cases based on the p_idTypeTache parameter: <br>" +
                    "&nbsp;&nbsp;&nbsp;&nbsp;• 'Eléments chiffrés' (p_idTypeTache = 1), <br>" +
                    "&nbsp;&nbsp;&nbsp;&nbsp;• 'Document' (p_idTypeTache = 2), <br>" +
                    "&nbsp;&nbsp;&nbsp;&nbsp;• 'Intégration d''éléments à partir du document précédent' (p_idTypeTache = 3), and <br>" +
                    "&nbsp;&nbsp;&nbsp;&nbsp;• 'Dynamics' (p_idTypeTache = 4). <br>" +

                    "Tasks are returned according to the selected gabarit, report type and task type."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Tasks successfully fetched"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    })
    })
    @RateLimiter(throttlingPolicyName = "READ_SOME_OPERATION")
    public ResponseEntity<List<TDBGetListeTachesByGabAndTypeDTO>>
    getListeTachesByGabAndType(
            @RequestParam Long p_idGabarit,
            @RequestParam Long p_idTypeTache) {

        List<TDBGetListeTachesByGabAndTypeDTO> dtoList =
                tdbGetListeTachesByGabAndTypeSerInterface
                        .getListeTachesByGabAndType(
                                p_idGabarit,
                                p_idTypeTache
                        )
                        .stream()
                        .map(TDBGetListeTachesByGabAndTypeMapper::toDto)
                        .toList();

        return ok().cacheControl(CacheControl.noCache()).body(dtoList);
    }

    @Autowired
    private TDBValidationAssociationRunTachesSerInterface tdbValidationAssociationRunTachesSerInterface;

    @PostMapping("/ValidationAssociationRunTaches")
    @Operation(
            summary = "Validation Association Run Taches"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Tasks successfully Validated"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    })
    })
    public ResponseEntity<String>
    validationAssociationRunTaches(
            @RequestBody
            TDBValidationAssociationRunTachesRequestDTO request, HttpServletRequest req) {

        String result = tdbValidationAssociationRunTachesSerInterface.validationAssociationRunTaches(request, req);

        if (result.startsWith("The following portfolios/structures")) {

            return ResponseEntity.badRequest().body(result);
        }

        return ResponseEntity.ok(result);
    }


    @Autowired
    TDBUpdateMaquettisteSerInterface tdbUpdateMaquettisteSerInterface;
    @Operation(
            summary = "Update Maquettiste",
            description = "Updates the maquettiste assigned to a suivi."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Maquettiste updated successfully"),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(schema = @Schema(implementation = Problem.class), mediaType = APPLICATION_PROBLEM_JSON_VALUE)}),
            @ApiResponse(responseCode = "429", description = "Quota exceeded", content = {
                    @Content(schema = @Schema(ref = "#/components/schemas/ProblemDetail"), mediaType = APPLICATION_PROBLEM_JSON_VALUE, examples = @ExampleObject(name = "429", ref = QUOTA_EXCEEDED_EXAMPLE))},
                    headers = {
                            @Header(name = "X-RateLimit-Limit"),
                            @Header(name = "X-RateLimit-Remaining"),
                            @Header(name = "X-RateLimit-Reset")
                    })
    })
    @PutMapping("/updateMaquettiste")
    public ResponseEntity<String> updateMaquettiste(
            @RequestBody
            TDBUpdateMaquettisteDTO request) {

        tdbUpdateMaquettisteSerInterface.updateMaquettiste(request);

        return ok().cacheControl(CacheControl.noCache()).body("Maquettiste updated successfully");
    }
}