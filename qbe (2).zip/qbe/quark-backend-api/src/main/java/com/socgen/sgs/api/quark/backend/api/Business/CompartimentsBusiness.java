package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Compartiment;
import com.socgen.sgs.api.quark.backend.api.infra.dao.CompartimentsDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CompartimentsBusiness {

    private final CompartimentsDao compartimentsDao;

    public CompartimentsBusiness(CompartimentsDao compartimentsDao) {
        this.compartimentsDao = compartimentsDao;
    }

    public List<Compartiment> getStructures(
            String p_idStructure,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        return compartimentsDao.getStructures(
                p_idStructure,
                p_auditor,
                p_accountant,
                p_fundMgtCompany);
    }
}
