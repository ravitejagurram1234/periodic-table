package com.socgen.sgs.api.quark.backend.api.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TDBValidationAssociationRunTachesRequestDTO {

    private String[] suiviIds;
    private String[] unitCodes;
    private Long idLangue;
    private Long idGabarit;
    private LocalDate dateEcheance;
    private LocalDateTime datePlanification;
    private Integer gabaritSource;
    private Integer integrerN1;
    private Integer modeCompart ;
    private Long[] taskIds;
    private Integer modeDeclenchment;

}