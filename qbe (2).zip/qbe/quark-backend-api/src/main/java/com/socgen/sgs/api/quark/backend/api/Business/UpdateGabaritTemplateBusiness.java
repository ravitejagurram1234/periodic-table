package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Chargement_gabarit;
import com.socgen.sgs.api.quark.backend.api.infra.dao.GabaritTemplateUpdateDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UpdateGabaritTemplateBusiness {

    private final GabaritTemplateUpdateDao gabaritTemplateUpdateDao;

    public UpdateGabaritTemplateBusiness(GabaritTemplateUpdateDao gabaritTemplateUpdateDao) {
        this.gabaritTemplateUpdateDao = gabaritTemplateUpdateDao;
    }

    public void updateGabaritTemplate(Chargement_gabarit gabarit) {
        gabaritTemplateUpdateDao.updateGabaritTemplate(gabarit);
    }
}