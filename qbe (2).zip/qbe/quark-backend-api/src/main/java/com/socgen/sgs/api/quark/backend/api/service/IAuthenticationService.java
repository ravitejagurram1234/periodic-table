package com.socgen.sgs.api.quark.backend.api.service;

import org.springframework.security.core.Authentication;

import java.util.List;
import java.util.Optional;

public interface IAuthenticationService {

    Authentication getAuthentication();

    Optional<String> getUserProperty(String propertyName);

    Optional<String> getCurrentUserSesameId();

    List<String> getAuthorities();

    Optional<String> getCurrentUserEmailId();

    public Optional<String> getCurrentUserFirstName();

    public Optional<String> getCurrentUserLastName();

    public Optional<String>  getCurrentUserFullName();
}