package com.socgen.sgs.api.quark.backend.api.service.Impl;

import com.socgen.sgs.api.quark.backend.api.domain.TDBCheckIfRunsEnCours;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBCheckIfRunsEnCoursDAO;
import com.socgen.sgs.api.quark.backend.api.service.TDBCheckIfRunsEnCoursSerInterface;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class TDBCheckIfRunsEnCoursService
        implements TDBCheckIfRunsEnCoursSerInterface {

    private final TDBCheckIfRunsEnCoursDAO dao;

    public TDBCheckIfRunsEnCoursService(
            TDBCheckIfRunsEnCoursDAO dao) {

        this.dao = dao;
    }

    @Override
    public List<TDBCheckIfRunsEnCours> checkIfRunsEnCours(
            String[] p_ids,
            String[] p_id_unit_codes,
            Long p_idLangue,
            Long p_idGabarit,
            LocalDate p_dateEcheance) {

        return dao.checkIfRunsEnCours(
                p_ids,
                p_id_unit_codes,
                p_idLangue,
                p_idGabarit,
                p_dateEcheance
        );
    }
}