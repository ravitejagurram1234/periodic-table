package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.TDBGetListeSuivisCompartBySuiviMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeSuivisCompartBySuivi;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBGetListeSuivisCompartBySuiviDAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCTDBGetListeSuivisCompartBySuivi
        implements TDBGetListeSuivisCompartBySuiviDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBGetListeSuivisCompartBySuivi(
            DataSource dataSource) {

        this.simpleJdbcCall =
                new SimpleJdbcCall(dataSource)
                        .withCatalogName("QXP_PK_SUIVI")
                        .withFunctionName("GetListeSuivisCompartBySuivi")
                        .withoutProcedureColumnMetaDataAccess()
                        .declareParameters(
                                new SqlParameter(
                                        "p_idSuivi",
                                        Types.NUMERIC
                                ),
                                new SqlParameter(
                                        "p_idTache",
                                        Types.NUMERIC
                                ),
                                new SqlOutParameter(
                                        "RETURN_VALUE",
                                        OracleTypes.CURSOR,
                                        (rs, rowNum) ->
                                                TDBGetListeSuivisCompartBySuiviMapper
                                                        .mapResult(rs)
                                )
                        );
    }

    @Override
    public List<TDBGetListeSuivisCompartBySuivi>
    getListeSuivisCompartBySuivi(
            Long p_idSuivi,
            Long p_idTache) {

        Map<String, Object> result =
                simpleJdbcCall.execute(
                        Map.of(
                                "p_idSuivi", p_idSuivi,
                                "p_idTache", p_idTache
                        )
                );

        return (List<TDBGetListeSuivisCompartBySuivi>)
                result.get("RETURN_VALUE");
    }
}