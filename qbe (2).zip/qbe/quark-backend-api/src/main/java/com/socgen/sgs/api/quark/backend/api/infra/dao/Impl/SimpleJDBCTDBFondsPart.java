package com.socgen.sgs.api.quark.backend.api.infra.dao.Impl;

import com.socgen.sgs.api.quark.backend.api.Mapper.TDBFondsPartMapper;
import com.socgen.sgs.api.quark.backend.api.domain.TDBFondsPart;
import com.socgen.sgs.api.quark.backend.api.infra.dao.TDBFondsPartDAO;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SimpleJDBCTDBFondsPart implements TDBFondsPartDAO {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public SimpleJDBCTDBFondsPart(DataSource dataSource) {

        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_SUIVI")
                .withFunctionName("GetListeSuivisTDBByFondsPart")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(
                                "RETURN_VALUE",
                                OracleTypes.CURSOR,
                                (rs, rowNum) -> TDBFondsPartMapper.mapResult(rs)
                        ),
                        new SqlParameter("p_idLangue", Types.NUMERIC),
                        new SqlParameter("p_dateEcheance", Types.DATE),
                        new SqlParameter("p_portefeuilles", Types.VARCHAR),
                        new SqlParameter("p_idMaquettiste", Types.NUMERIC),
                        new SqlParameter("p_idStatutSuivi", Types.NUMERIC),
                        new SqlParameter("p_idTypeRapport", Types.NUMERIC),
                        new SqlParameter("p_auditor", Types.VARCHAR),
                        new SqlParameter("p_accountant", Types.VARCHAR),
                        new SqlParameter("p_fundMgtCompany", Types.VARCHAR)
                );
    }

    @Override
    public List<TDBFondsPart> getListeSuivisTDBByFondsPart(
            Long p_idLangue,
            LocalDate p_dateEcheance,
            String p_portefeuilles,
            Long p_idMaquettiste,
            Long p_idStatutSuivi,
            Long p_idTypeRapport,
            String p_auditor,
            String p_accountant,
            String p_fundMgtCompany) {

        java.sql.Date sqlDate = java.sql.Date.valueOf(p_dateEcheance);

        System.out.println("p_idLangue=" + p_idLangue);
        System.out.println("p_dateEcheance=" + p_dateEcheance);
        System.out.println("p_portefeuilles=" + p_portefeuilles);
        System.out.println("p_idMaquettiste=" + p_idMaquettiste);
        System.out.println("p_idStatutSuivi=" + p_idStatutSuivi);
        System.out.println("p_idTypeRapport=" + p_idTypeRapport);
        System.out.println("p_auditor=" + p_auditor);
        System.out.println("p_accountant=" + p_accountant);
        System.out.println("p_fundMgtCompany=" + p_fundMgtCompany);


        Map<String, Object> params = new HashMap<>();

        params.put("p_idLangue", p_idLangue);
        params.put("p_dateEcheance", sqlDate);
        params.put("p_portefeuilles", p_portefeuilles);
        params.put("p_idMaquettiste", p_idMaquettiste);
        params.put("p_idStatutSuivi", p_idStatutSuivi);
        params.put("p_idTypeRapport", p_idTypeRapport);
        params.put("p_auditor", p_auditor);
        params.put("p_accountant", p_accountant);
        params.put("p_fundMgtCompany", p_fundMgtCompany);

        try {

            Map<String, Object> result = simpleJdbcCall.execute(params);

            return (List<TDBFondsPart>) result.get("RETURN_VALUE");

        } catch (Exception e) {

            System.err.println("Error during JDBC call : " + e.getMessage());
            e.printStackTrace();

            return Collections.emptyList();
        }
    }
}