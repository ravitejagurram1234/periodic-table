package com.socgen.sgs.api.quark.backend.api.service;

import com.socgen.sgs.api.quark.backend.api.domain.ReportDownloadModels.ReportDownload;

public interface DocumentDownloadSerInterface {
    ReportDownload download(long idSuivi, String requestedFormat);
}