package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationParSocieteTypesDocumentDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ModificationParSocieteTypeDocumentBusiness {

    private final ModificationParSocieteTypesDocumentDao modificationParSocieteTypesDocumentDao;

    public ModificationParSocieteTypeDocumentBusiness(
            ModificationParSocieteTypesDocumentDao modificationParSocieteTypesDocumentDao) {
        this.modificationParSocieteTypesDocumentDao = modificationParSocieteTypesDocumentDao;
    }

    public List<TypeDeDocument> getListeTypesDocumentsDispos(String p_societe) {
        return modificationParSocieteTypesDocumentDao.getListeTypesDocumentsDispos(p_societe);
    }
}