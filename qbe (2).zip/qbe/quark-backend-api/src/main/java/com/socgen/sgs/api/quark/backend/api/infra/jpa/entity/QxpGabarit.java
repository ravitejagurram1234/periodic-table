package com.socgen.sgs.api.quark.backend.api.infra.jpa.entity;

//package com.socgen.sgs.api.quark.backend.api.infra.jpa.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "QXP_GABARIT")
public class QxpGabarit {

    @Id
    @Column(name = "ID_GABARIT")
    private Long gabaritId;

    @Column(name = "TYPE")
    private String type;
}

