package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.TypeDeDocument;
import com.socgen.sgs.api.quark.backend.api.infra.dao.SocieteDocumentDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SocieteDocumentBusiness {

    private final SocieteDocumentDao societeDocumentDao;

    public SocieteDocumentBusiness(SocieteDocumentDao societeDocumentDao) {
        this.societeDocumentDao = societeDocumentDao;
    }

    public List<TypeDeDocument> getSocieteDocument(String p_societe) {
        return societeDocumentDao.getSocieteDocument(p_societe);
    }
}