package com.socgen.sgs.api.quark.backend.api.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.List;
import java.util.Objects;

public final class AmundiImportModels {

    public static final String TEMPLATE_NAME = "IT_AMUNDI_PERIMETER";

    public static final List<String> EXPECTED_HEADERS = List.of(
            "Nom \"Fonds\"",
            "Code BWR",
            "Code \"Decalog\"",
            "Code Comptable",
            "Type de rapport",
            "Date de clotûre",
            "Langues",
            "Type de fonds",
            "Normes Européennes",
            "Méthode calcul d'engagement",
            "Code Parapluie"
    );

    private AmundiImportModels() {
    }

    public enum AmundiDateFormat {
        DD_MM_YYYY("dd/MM/uuuu"),
        MM_DD_YYYY("MM/dd/uuuu");

        private final DateTimeFormatter formatter;

        AmundiDateFormat(String pattern) {
            this.formatter = DateTimeFormatter.ofPattern(pattern)
                    .withResolverStyle(ResolverStyle.STRICT);
        }

        public LocalDate parse(String value) {
            return LocalDate.parse(value, formatter);
        }
    }

    public enum AmundiImportMode {
        DELETE,
        DELETE_AND_INSERT,
        UPDATE
    }

    public record UploadedFile(String originalFilename, byte[] content) {
        public UploadedFile {
            originalFilename = Objects.requireNonNullElse(originalFilename, "").trim();
            content = Objects.requireNonNull(content, "content").clone();
        }

        @Override
        public byte[] content() {
            return content.clone();
        }
    }

    public record AmundiPerimeterRecord(
            String fundLabel,
            String idFundBwr,
            String decalog,
            String fundName,
            String reportType,
            LocalDate reportDate,
            String reportLanguage,
            String legalForm,
            String europeanNorm,
            String engagementMethod,
            String codeParapluie) {

        public AmundiBusinessKey key() {
            return new AmundiBusinessKey(fundName, reportDate, reportLanguage);
        }
    }

    public record AmundiBusinessKey(
            String fundName,
            LocalDate reportDate,
            String reportLanguage) {
    }

    public record ParsedAmundiRow(long rowNumber, AmundiPerimeterRecord value) {
    }

    public record AmundiImportRowError(
            long rowNumber,
            String column,
            String rejectedValue,
            String reason) {
    }

    public record CsvParseResult(
            String checksumSha256,
            int totalRows,
            List<ParsedAmundiRow> validRows,
            List<AmundiImportRowError> errors,
            int duplicateRows) {
        public CsvParseResult {
            validRows = List.copyOf(validRows);
            errors = List.copyOf(errors);
        }
    }

    public record AmundiImportValidationResult(
            String templateName,
            String originalFilename,
            String checksumSha256,
            int totalRows,
            int validRows,
            int invalidRows,
            int duplicateRows,
            List<AmundiImportRowError> errors) {
        public AmundiImportValidationResult {
            errors = List.copyOf(errors);
        }
    }

    public record AmundiImportResult(
            AmundiImportValidationResult validation,
            AmundiImportMode mode,
            int deletedRows,
            int insertedRows,
            int updatedRows,
            int unchangedRows) {
    }

    public record AmundiImportTemplateConfiguration(
            String templateName,
            String acceptedFileExtension,
            String charset,
            String columnSeparator,
            boolean headerRequired,
            List<String> expectedHeaders,
            List<AmundiDateFormat> dateFormats,
            AmundiDateFormat defaultDateFormat,
            List<AmundiImportMode> importModes,
            AmundiImportMode defaultImportMode,
            boolean decimalSeparatorApplicable,
            boolean customLineSeparatorApplicable) {
        public AmundiImportTemplateConfiguration {
            expectedHeaders = List.copyOf(expectedHeaders);
            dateFormats = List.copyOf(dateFormats);
            importModes = List.copyOf(importModes);
        }
    }
}