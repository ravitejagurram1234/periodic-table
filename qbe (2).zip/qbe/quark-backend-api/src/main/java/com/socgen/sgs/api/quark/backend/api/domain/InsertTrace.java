package com.socgen.sgs.api.quark.backend.api.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InsertTrace {
    private String p_ip;
    private LocalDate p_startTime;
    private LocalDate p_endTime;
    private String p_page;
    private String p_login;
    private String p_module;
    private String p_fonction;
    private String p_message;
    private String p_param1;
    private String p_param2;
    private String p_param3;
    private String p_param4;
    private String p_param5;
    private Integer p_temps_reponse;
    private Integer p_statut;
    private Long p_id_application;
    private String p_nom_application;

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String p_ip;
        private LocalDate p_startTime;
        private LocalDate p_endTime;
        private String p_page;
        private String p_login;
        private String p_module;
        private String p_fonction;
        private String p_message;
        private String p_param1;
        private String p_param2;
        private String p_param3;
        private String p_param4;
        private String p_param5;
        private Integer p_temps_reponse;
        private Integer p_statut;
        private Long p_id_application;
        private String p_nom_application;

        public Builder p_ip(String p_ip) {
            this.p_ip = p_ip;
            return this;
        }

        public Builder p_startTime(LocalDate p_startTime) {
            this.p_startTime = p_startTime;
            return this;
        }

        public Builder p_endTime(LocalDate p_endTime) {
            this.p_endTime = p_endTime;
            return this;
        }

        public Builder p_page(String p_page) {
            this.p_page = p_page;
            return this;
        }

        public Builder p_login(String p_login) {
            this.p_login = p_login;
            return this;
        }

        public Builder p_module(String p_module) {
            this.p_module = p_module;
            return this;
        }

        public Builder p_fonction(String p_fonction) {
            this.p_fonction = p_fonction;
            return this;
        }

        public Builder p_message(String p_message) {
            this.p_message = p_message;
            return this;
        }

        public Builder p_param1(String p_param1) {
            this.p_param1 = p_param1;
            return this;
        }

        public Builder p_param2(String p_param2) {
            this.p_param2 = p_param2;
            return this;
        }

        public Builder p_param3(String p_param3) {
            this.p_param3 = p_param3;
            return this;
        }

        public Builder p_param4(String p_param4) {
            this.p_param4 = p_param4;
            return this;
        }

        public Builder p_param5(String p_param5) {
            this.p_param5 = p_param5;
            return this;
        }

        public Builder p_temps_reponse(Integer p_temps_reponse) {
            this.p_temps_reponse = p_temps_reponse;
            return this;
        }

        public Builder p_statut(Integer p_statut) {
            this.p_statut = p_statut;
            return this;
        }

        public Builder p_id_application(Long p_id_application) {
            this.p_id_application = p_id_application;
            return this;
        }

        public Builder p_nom_application(String p_nom_application) {
            this.p_nom_application = p_nom_application;
            return this;
        }

        public InsertTrace build() {
            InsertTrace insertTrace = new InsertTrace();
            insertTrace.p_ip = this.p_ip;
            insertTrace.p_startTime = this.p_startTime;
            insertTrace.p_endTime = this.p_endTime;
            insertTrace.p_page = this.p_page;
            insertTrace.p_login = this.p_login;
            insertTrace.p_module = this.p_module;
            insertTrace.p_fonction = this.p_fonction;
            insertTrace.p_message = this.p_message;
            insertTrace.p_param1 = this.p_param1;
            insertTrace.p_param2 = this.p_param2;
            insertTrace.p_param3 = this.p_param3;
            insertTrace.p_param4 = this.p_param4;
            insertTrace.p_param5 = this.p_param5;
            insertTrace.p_temps_reponse = this.p_temps_reponse;
            insertTrace.p_statut = this.p_statut;
            insertTrace.p_id_application = this.p_id_application;
            insertTrace.p_nom_application = this.p_nom_application;
            return insertTrace;
        }
    }


}
