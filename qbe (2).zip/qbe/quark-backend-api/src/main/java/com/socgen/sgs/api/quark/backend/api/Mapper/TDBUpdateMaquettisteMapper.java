package com.socgen.sgs.api.quark.backend.api.Mapper;

import com.socgen.sgs.api.quark.backend.api.Dto.TDBUpdateMaquettisteDTO;
import com.socgen.sgs.api.quark.backend.api.domain.TDBUpdateMaquettiste;

public class TDBUpdateMaquettisteMapper {

    private TDBUpdateMaquettisteMapper() {
    }

    public static TDBUpdateMaquettiste toDomain(
            TDBUpdateMaquettisteDTO dto) {

        return new TDBUpdateMaquettiste(
                dto.getIdSuivi(),
                dto.getIdMaquettiste()
        );
    }
}