package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Langue;
import com.socgen.sgs.api.quark.backend.api.infra.dao.LangueDao;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LangueBusiness {

    private final LangueDao dao;

    public LangueBusiness(LangueDao dao) {
        this.dao = dao;
    }

    public List<Langue> getLangue() {
        return this.dao.getLangue();
    }
}