package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.domain.Document;
import com.socgen.sgs.api.quark.backend.api.infra.dao.checkDoublOnDocumentDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class checkDoublOnDocumentBusiness {

    private final checkDoublOnDocumentDao checkDoublOnDocument;

    public checkDoublOnDocumentBusiness(checkDoublOnDocumentDao checkDoublOnDocument) {
        this.checkDoublOnDocument = checkDoublOnDocument;
    }

    public Integer checkDoublOnDocument(Document document1) {
        return checkDoublOnDocument.checkDoublonDocument(document1);
    }
}