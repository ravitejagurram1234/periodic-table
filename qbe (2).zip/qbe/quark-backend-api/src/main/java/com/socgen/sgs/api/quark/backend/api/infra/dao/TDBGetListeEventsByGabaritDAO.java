package com.socgen.sgs.api.quark.backend.api.infra.dao;

import com.socgen.sgs.api.quark.backend.api.domain.TDBGetListeEventsByGabarit;

import java.util.List;

public interface TDBGetListeEventsByGabaritDAO {

    List<TDBGetListeEventsByGabarit>
    getListeEventsByGabarit(
            Long p_idGabarit
    );
}
