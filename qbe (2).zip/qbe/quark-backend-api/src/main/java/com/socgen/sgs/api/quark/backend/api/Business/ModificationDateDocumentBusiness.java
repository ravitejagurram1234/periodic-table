package com.socgen.sgs.api.quark.backend.api.Business;

import com.socgen.sgs.api.quark.backend.api.infra.dao.ModificationDateDocumentDao;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Transactional
public class ModificationDateDocumentBusiness {

    private final ModificationDateDocumentDao modificationDateDocumentDao;

    public ModificationDateDocumentBusiness(
            ModificationDateDocumentDao modificationDateDocumentDao) {
        this.modificationDateDocumentDao = modificationDateDocumentDao;
    }

    public List<LocalDate> getDateDocuments(
            int p_id_sous_categorie,
            String p_id_fnd_code,
            String p_id_unit_code) {

        List<java.sql.Date> port =
                modificationDateDocumentDao.getDateDocuments(
                        p_id_sous_categorie,
                        p_id_fnd_code,
                        p_id_unit_code);

        return port.stream()
                .filter(Objects::nonNull)
                .map(java.sql.Date::toLocalDate)
                .collect(Collectors.toList());
    }
}