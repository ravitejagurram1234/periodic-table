package com.socgen.sgs.api.quark.batch.dto;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CreateRunUploadResultDTOTest {

    @Test
    void isSuccess_positiveResult() {
        CreateRunUploadResultDTO dto = new CreateRunUploadResultDTO(100);
        assertThat(dto.isSuccess()).isTrue();
        assertThat(dto.getRunId()).isEqualTo(100);
    }

    @Test
    void isSuccess_zero_false() {
        CreateRunUploadResultDTO dto = new CreateRunUploadResultDTO(0);
        assertThat(dto.isSuccess()).isFalse();
        assertThat(dto.getRunId()).isNull();
    }

    @Test
    void isRunInExecution() {
        CreateRunUploadResultDTO dto = new CreateRunUploadResultDTO(-1);
        assertThat(dto.isRunInExecution()).isTrue();
        assertThat(dto.isSuccess()).isFalse();
        assertThat(dto.isSuiviLocked()).isFalse();
    }

    @Test
    void isSuiviLocked() {
        CreateRunUploadResultDTO dto = new CreateRunUploadResultDTO(-2);
        assertThat(dto.isSuiviLocked()).isTrue();
        assertThat(dto.isRunInExecution()).isFalse();
    }

    @Test
    void nullResult_allFalse() {
        CreateRunUploadResultDTO dto = new CreateRunUploadResultDTO(null);
        assertThat(dto.isSuccess()).isFalse();
        assertThat(dto.isRunInExecution()).isFalse();
        assertThat(dto.isSuiviLocked()).isFalse();
        assertThat(dto.getRunId()).isNull();
    }
}
