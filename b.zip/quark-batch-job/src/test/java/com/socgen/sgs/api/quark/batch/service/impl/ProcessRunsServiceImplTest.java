package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class ProcessRunsServiceImplTest {

    private final ProcessRunsServiceImpl service = new ProcessRunsServiceImpl();

    @Test
    void processRuns_doesNotThrow() {
        assertDoesNotThrow(() -> service.processRuns(List.of(new RunIdDto(1))));
    }

    @Test
    void processRuns_emptyList_doesNotThrow() {
        assertDoesNotThrow(() -> service.processRuns(List.of()));
    }
}
