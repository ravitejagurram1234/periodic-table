package com.socgen.sgs.api.quark.batch.scheduler;

import com.socgen.sgs.api.quark.batch.service.CheckUploadsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CheckUploadsSchedulerTest {

    @Mock private CheckUploadsService checkUploadsService;
    @InjectMocks private CheckUploadsScheduler scheduler;

    @Test
    void checkUploads_callsService() {
        scheduler.checkUploads();
        verify(checkUploadsService).checkUploads();
    }

    @Test
    void checkUploads_exceptionHandled() {
        doThrow(new RuntimeException("err")).when(checkUploadsService).checkUploads();
        scheduler.checkUploads();
    }
}
