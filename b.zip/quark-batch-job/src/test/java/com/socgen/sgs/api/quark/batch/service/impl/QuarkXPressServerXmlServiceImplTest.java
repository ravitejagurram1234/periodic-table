package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.config.QuarkXPressServerProperties;
import com.socgen.sgs.api.quark.batch.domain.DocumentIdentity;
import com.socgen.sgs.api.quark.batch.exception.QuarkXPressServerException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class QuarkXPressServerXmlServiceImplTest {

    private QuarkXPressServerXmlServiceImpl service;

    @BeforeEach
    void setUp() {
        QuarkXPressServerProperties props = new QuarkXPressServerProperties();
        props.setBaseUrl("http://localhost");
        props.setPort(8080);
        props.setUploadDirectory("Upload");
        service = new QuarkXPressServerXmlServiceImpl(props);
    }

    @Test
    void parseDocumentIdentity_validWith7Parts() {
        String input = "101|975|747|49|12/01/2024 00:00:00|06/25/2025 06:31:36|101223";
        DocumentIdentity identity = service.parseDocumentIdentity(input);
        assertThat(identity.getIdFndCode()).isEqualTo("101");
        assertThat(identity.getIdSuivi()).isEqualTo("975");
        assertThat(identity.getIdRun()).isEqualTo("747");
        assertThat(identity.getIdLangue()).isEqualTo("49");
        assertThat(identity.getIdUnitCode()).isEqualTo("101223");
        assertThat(identity.hasUnitCode()).isTrue();
    }

    @Test
    void parseDocumentIdentity_validWith6Parts_noUnitCode() {
        String input = "78|001764|15308|1|12/01/2009 00:00:00|04/12/2010 17:39:29";
        DocumentIdentity identity = service.parseDocumentIdentity(input);
        assertThat(identity.getIdFndCode()).isEqualTo("78");
        assertThat(identity.getIdUnitCode()).isNull();
        assertThat(identity.hasUnitCode()).isFalse();
    }

    @Test
    void parseDocumentIdentity_nullInput_throwsNPE() {
        assertThatThrownBy(() -> service.parseDocumentIdentity(null))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    void parseDocumentIdentity_emptyInput_throwsException() {
        assertThatThrownBy(() -> service.parseDocumentIdentity("  "))
                .isInstanceOf(QuarkXPressServerException.class)
                .hasMessageContaining("must not be empty");
    }

    @Test
    void parseDocumentIdentity_tooFewParts_throwsException() {
        assertThatThrownBy(() -> service.parseDocumentIdentity("a|b|c"))
                .isInstanceOf(QuarkXPressServerException.class)
                .hasMessageContaining("at least");
    }

    @Test
    void parseDocumentIdentity_invalidDate_throwsException() {
        String input = "101|975|747|49|INVALID|06/25/2025 06:31:36|101223";
        assertThatThrownBy(() -> service.parseDocumentIdentity(input))
                .isInstanceOf(QuarkXPressServerException.class);
    }

    @Test
    void getElementValueByIdName_nullXml_throwsNPE() {
        assertThatThrownBy(() -> service.getElementValueByIdName(null, "DID"))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    void getElementValueByIdName_nullIdName_throwsNPE() {
        assertThatThrownBy(() -> service.getElementValueByIdName("<xml/>", null))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    void getElementValueByIdName_validXmlWithDID_returnsValue() {
        String xml = "<?xml version=\"1.0\"?><DOCUMENT><BOX><ID NAME=\"DID\"/><RICHTEXT>testValue</RICHTEXT></BOX></DOCUMENT>";
        String result = service.getElementValueByIdName(xml, "DID");
        assertThat(result).isEqualTo("testValue");
    }

    @Test
    void getElementValueByIdName_noMatchingId_returnsNull() {
        String xml = "<?xml version=\"1.0\"?><DOCUMENT><BOX><ID NAME=\"OTHER\"/><RICHTEXT>val</RICHTEXT></BOX></DOCUMENT>";
        String result = service.getElementValueByIdName(xml, "DID");
        assertThat(result).isNull();
    }

    @Test
    void getElementValueByIdName_invalidXml_throwsException() {
        assertThatThrownBy(() -> service.getElementValueByIdName("not xml at all", "DID"))
                .isInstanceOf(QuarkXPressServerException.class);
    }

    @Test
    void getElementValueByIdName_xmlWithBOM_handledCorrectly() {
        String xml = "\uFEFF<?xml version=\"1.0\"?><DOCUMENT><BOX><ID NAME=\"DID\"/><RICHTEXT>val</RICHTEXT></BOX></DOCUMENT>";
        String result = service.getElementValueByIdName(xml, "DID");
        assertThat(result).isEqualTo("val");
    }

    @Test
    void fetchXmlContent_nullDocumentName_throwsNPE() {
        assertThatThrownBy(() -> service.fetchXmlContent(null))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    void constructorNullProperties_throwsNPE() {
        assertThatThrownBy(() -> new QuarkXPressServerXmlServiceImpl(null))
                .isInstanceOf(NullPointerException.class);
    }
}
