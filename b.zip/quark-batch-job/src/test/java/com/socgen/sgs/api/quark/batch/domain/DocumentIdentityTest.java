package com.socgen.sgs.api.quark.batch.domain;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;

class DocumentIdentityTest {

    @Test
    void builder_createsFullObject() {
        LocalDateTime now = LocalDateTime.now();
        DocumentIdentity identity = DocumentIdentity.builder()
                .idFndCode("101").idSuivi("200").idRun("300").idLangue("1")
                .dueDate(now).generationDateTime(now).idUnitCode("UC1").build();
        assertThat(identity.getIdFndCode()).isEqualTo("101");
        assertThat(identity.getIdSuivi()).isEqualTo("200");
        assertThat(identity.getIdRun()).isEqualTo("300");
        assertThat(identity.getIdLangue()).isEqualTo("1");
        assertThat(identity.getDueDate()).isEqualTo(now);
        assertThat(identity.getGenerationDateTime()).isEqualTo(now);
        assertThat(identity.getIdUnitCode()).isEqualTo("UC1");
        assertThat(identity.hasUnitCode()).isTrue();
    }

    @Test
    void hasUnitCode_null_returnsFalse() {
        DocumentIdentity identity = DocumentIdentity.builder().idUnitCode(null).build();
        assertThat(identity.hasUnitCode()).isFalse();
    }

    @Test
    void hasUnitCode_blank_returnsFalse() {
        DocumentIdentity identity = DocumentIdentity.builder().idUnitCode("  ").build();
        assertThat(identity.hasUnitCode()).isFalse();
    }

    @Test
    void equals_sameValues_true() {
        LocalDateTime dt = LocalDateTime.of(2024, 1, 1, 0, 0);
        DocumentIdentity a = DocumentIdentity.builder().idFndCode("1").idSuivi("2").idRun("3").idLangue("4").dueDate(dt).generationDateTime(dt).idUnitCode("5").build();
        DocumentIdentity b = DocumentIdentity.builder().idFndCode("1").idSuivi("2").idRun("3").idLangue("4").dueDate(dt).generationDateTime(dt).idUnitCode("5").build();
        assertThat(a).isEqualTo(b);
        assertThat(a.hashCode()).isEqualTo(b.hashCode());
    }

    @Test
    void equals_differentValues_false() {
        DocumentIdentity a = DocumentIdentity.builder().idFndCode("1").build();
        DocumentIdentity b = DocumentIdentity.builder().idFndCode("2").build();
        assertThat(a).isNotEqualTo(b);
    }

    @Test
    void equals_null_false() {
        DocumentIdentity a = DocumentIdentity.builder().build();
        assertThat(a).isNotEqualTo(null);
    }

    @Test
    void equals_sameInstance_true() {
        DocumentIdentity a = DocumentIdentity.builder().build();
        assertThat(a).isEqualTo(a);
    }

    @Test
    void toString_containsFields() {
        DocumentIdentity identity = DocumentIdentity.builder().idFndCode("101").idSuivi("200").build();
        assertThat(identity.toString()).contains("101").contains("200");
    }
}
