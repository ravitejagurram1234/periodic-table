package com.socgen.sgs.api.quark.batch;

import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.syntax.ArchRuleDefinition;

@AnalyzeClasses(packages = CleanArchitectureLayersTest.PACKAGE_TO_SCAN, importOptions = {
    ImportOption.DoNotIncludeTests.class })
class CleanArchitectureLayersTest {

  public static final String PACKAGE_TO_SCAN = "com.socgen.sgs.api.quark.batch";

  @ArchTest
  static final ArchRule domain_should_not_depend_on_services_or_infra = ArchRuleDefinition.noClasses()
      .that()
      .resideInAPackage(PACKAGE_TO_SCAN + ".domain..")
      .should()
      .dependOnClassesThat().resideInAnyPackage(PACKAGE_TO_SCAN + ".service..", PACKAGE_TO_SCAN + ".infra..");

  @ArchTest
  static final ArchRule services_should_not_depend_on_infra = ArchRuleDefinition.noClasses()
      .that()
      .resideInAPackage(PACKAGE_TO_SCAN + ".service..")
      .should()
      .dependOnClassesThat().resideInAPackage(PACKAGE_TO_SCAN + ".infra..");

  @ArchTest
  static final ArchRule non_infra_code_should_not_depend_on_non_core_frameworks_or_io = ArchRuleDefinition.noClasses()
      .that()
      .resideInAnyPackage(PACKAGE_TO_SCAN + ".service..", PACKAGE_TO_SCAN + ".domain..")
      .should()
      .dependOnClassesThat().resideInAnyPackage(
          // api, json, web…
          "com.fasterxml.jackson..", "com.socgen.apibank..", "io.swagger..", "javax.servlet..", "jakarta.servlet..",
          "org.springframework.http..", "org.springframework.web..",
          // input/output, jpa…
          "java.sql..", "jakarta.persistence..", "org.springframework.data..", "org.springframework.transaction..",
          // misc. other…
          "org.springframework.scheduling..", "org.springframework.security..", "org.springframework.validation..");
}
