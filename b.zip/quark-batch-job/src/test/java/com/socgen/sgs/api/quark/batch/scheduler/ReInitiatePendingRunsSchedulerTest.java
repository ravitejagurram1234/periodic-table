package com.socgen.sgs.api.quark.batch.scheduler;

import com.socgen.sgs.api.quark.batch.service.ReInitiatePendingRunsService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReInitiatePendingRunsSchedulerTest {

    @Mock private ReInitiatePendingRunsService reInitiatePendingRunsService;
    @InjectMocks private ReInitiatePendingRunsScheduler scheduler;

    @Test
    void reInitiatePendingRuns_callsService() {
        when(reInitiatePendingRunsService.reInitiatePendingRuns()).thenReturn(List.of());
        scheduler.reInitiatePendingRuns();
        verify(reInitiatePendingRunsService).reInitiatePendingRuns();
    }

    @Test
    void reInitiatePendingRuns_exceptionHandled() {
        when(reInitiatePendingRunsService.reInitiatePendingRuns()).thenThrow(new RuntimeException("err"));
        scheduler.reInitiatePendingRuns();
    }
}
