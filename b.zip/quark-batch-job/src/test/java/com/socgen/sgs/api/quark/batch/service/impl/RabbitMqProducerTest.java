package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.config.RabbitMqConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class RabbitMqProducerTest {

    @Mock
    private RabbitTemplate rabbitTemplate;

    @InjectMocks
    private RabbitMqProducer rabbitMqProducer;

    @Test
    void sendRunId_sendsToCorrectQueue() throws Exception {
        RabbitMqConfig.BATCH_RUN_QUEUE = "test-queue";
        rabbitMqProducer.sendRunId(42);
        verify(rabbitTemplate).convertAndSend("", "test-queue", 42);
    }
}
