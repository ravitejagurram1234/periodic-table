package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.PlannedRunsDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PlannedRunsBusinessTest {

    @Mock private PlannedRunsDao dao;
    @InjectMocks private PlannedRunsBusiness business;

    @Test
    void getPlannedRuns_delegatesToDao() {
        List<RunDomain> expected = List.of(new RunDomain(1));
        when(dao.getPlannedRuns()).thenReturn(expected);
        assertThat(business.getPlannedRuns()).isEqualTo(expected);
    }
}
