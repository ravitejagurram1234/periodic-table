package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.RunResetAndInitiateDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RunResetAndInitiateBusinessTest {

    @Mock private RunResetAndInitiateDao dao;
    @InjectMocks private RunResetAndInitiateBusiness business;

    @Test
    void resetRunsStatus_delegatesToDao() {
        business.resetRunsStatus();
        verify(dao).resetRunsStatus();
    }

    @Test
    void getRunsToBeInitiated_delegatesToDao() {
        List<RunDomain> expected = List.of(new RunDomain(5));
        when(dao.getRunsToBeInitiated()).thenReturn(expected);
        assertThat(business.getRunsToBeInitiated()).isEqualTo(expected);
    }
}
