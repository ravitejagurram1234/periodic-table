package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.dto.CreateRunUploadResultDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.CreateRunUploadDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreateRunUploadBusinessTest {

    @Mock private CreateRunUploadDao dao;
    @InjectMocks private CreateRunUploadBusiness business;

    @Test
    void createRunUpload_delegatesToDao() {
        CreateRunUploadResultDTO expected = new CreateRunUploadResultDTO(100);
        when(dao.createRunUpload(1, 2)).thenReturn(expected);
        assertThat(business.createRunUpload(1, 2)).isEqualTo(expected);
    }
}
