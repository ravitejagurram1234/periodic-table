package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.NewUploadDocumentsDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NewUploadsBusinessTest {

    @Mock private NewUploadDocumentsDao dao;
    @InjectMocks private NewUploadsBusiness business;

    @Test
    void getNewUploadDocuments_delegatesToDao() {
        List<UploadDocumentDomain> expected = List.of(new UploadDocumentDomain(1, null));
        when(dao.getNewUploadDocuments()).thenReturn(expected);
        assertThat(business.getNewUploadDocuments()).isEqualTo(expected);
    }
}
