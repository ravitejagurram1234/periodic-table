package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.UploadDocumentDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.UploadDocumentDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UploadDocumentBusinessTest {

    @Mock private UploadDocumentDao dao;
    @InjectMocks private UploadDocumentBusiness business;

    @Test
    void getUploadDocument_delegatesToDao() {
        UploadDocumentDTO dto = new UploadDocumentDTO(1, null);
        UploadDocumentDomain expected = new UploadDocumentDomain(1, new byte[]{1});
        when(dao.getUploadDocument(dto)).thenReturn(expected);
        assertThat(business.getUploadDocument(dto)).isEqualTo(expected);
    }
}
