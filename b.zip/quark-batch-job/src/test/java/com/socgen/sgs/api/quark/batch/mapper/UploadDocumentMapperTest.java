package com.socgen.sgs.api.quark.batch.mapper;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.UploadDocumentDTO;
import org.junit.jupiter.api.Test;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class UploadDocumentMapperTest {

    @Test
    void mapResult_extractsUploadId() throws SQLException {
        ResultSet rs = mock(ResultSet.class);
        when(rs.getInt("id_upload")).thenReturn(7);
        UploadDocumentDomain domain = UploadDocumentMapper.mapResult(rs);
        assertThat(domain.getUploadId()).isEqualTo(7);
    }

    @Test
    void mapResultWithContenu_extractsBoth() throws SQLException {
        ResultSet rs = mock(ResultSet.class);
        when(rs.getInt("id_upload")).thenReturn(7);
        when(rs.getBytes("CONTENU")).thenReturn(new byte[]{1, 2});
        UploadDocumentDomain domain = UploadDocumentMapper.mapResultWithContenu(rs);
        assertThat(domain.getUploadId()).isEqualTo(7);
        assertThat(domain.getContenu()).containsExactly(1, 2);
    }

    @Test
    void toDto_convertsCorrectly() {
        UploadDocumentDomain domain = new UploadDocumentDomain(5, new byte[]{3});
        UploadDocumentDTO dto = UploadDocumentMapper.toDto(domain);
        assertThat(dto.getUploadId()).isEqualTo(5);
        assertThat(dto.getContenu()).containsExactly(3);
    }
}
