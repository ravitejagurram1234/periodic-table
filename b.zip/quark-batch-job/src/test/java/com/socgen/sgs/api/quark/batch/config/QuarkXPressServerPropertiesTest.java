package com.socgen.sgs.api.quark.batch.config;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class QuarkXPressServerPropertiesTest {

    @Test
    void getFullBaseUrl_combinesBaseUrlAndPort() {
        QuarkXPressServerProperties props = new QuarkXPressServerProperties();
        props.setBaseUrl("http://server");
        props.setPort(9090);
        assertThat(props.getFullBaseUrl()).isEqualTo("http://server:9090");
    }
}
