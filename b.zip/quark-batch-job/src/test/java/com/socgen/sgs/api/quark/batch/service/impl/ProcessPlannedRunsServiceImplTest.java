package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.business.PlannedRunsBusiness;
import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpIOException;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProcessPlannedRunsServiceImplTest {

    @Mock
    private PlannedRunsBusiness plannedRunsBusiness;

    @Mock
    private RabbitMqProducer rabbitMqProducer;

    @InjectMocks
    private ProcessPlannedRunsServiceImpl service;

    @Test
    void processPlannedRuns_withRuns_sendsToRabbitMq() throws Exception {
        RunDomain run1 = new RunDomain(1);
        RunDomain run2 = new RunDomain(2);
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(Arrays.asList(run1, run2));

        List<RunIdDto> result = service.ProcessPlannedRuns();

        assertThat(result).hasSize(2);
        verify(rabbitMqProducer).sendRunId(1);
        verify(rabbitMqProducer).sendRunId(2);
    }

    @Test
    void processPlannedRuns_emptyList_returnsEmpty() {
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(Collections.emptyList());

        List<RunIdDto> result = service.ProcessPlannedRuns();

        assertThat(result).isEmpty();
        verifyNoInteractions(rabbitMqProducer);
    }

    @Test
    void processPlannedRuns_nullList_returnsEmpty() {
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(null);

        List<RunIdDto> result = service.ProcessPlannedRuns();

        assertThat(result).isEmpty();
        verifyNoInteractions(rabbitMqProducer);
    }

    @Test
    void processPlannedRuns_rabbitMqAmqpIOException_continuesProcessing() throws Exception {
        RunDomain run1 = new RunDomain(1);
        RunDomain run2 = new RunDomain(2);
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(Arrays.asList(run1, run2));
        doThrow(new AmqpIOException(new java.io.IOException("connection error"))).when(rabbitMqProducer).sendRunId(1);

        List<RunIdDto> result = service.ProcessPlannedRuns();

        assertThat(result).hasSize(2);
        verify(rabbitMqProducer).sendRunId(2);
    }

    @Test
    void processPlannedRuns_rabbitMqGenericException_continuesProcessing() throws Exception {
        RunDomain run1 = new RunDomain(1);
        RunDomain run2 = new RunDomain(2);
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(Arrays.asList(run1, run2));
        doThrow(new RuntimeException("generic error")).when(rabbitMqProducer).sendRunId(1);

        List<RunIdDto> result = service.ProcessPlannedRuns();

        assertThat(result).hasSize(2);
        verify(rabbitMqProducer).sendRunId(2);
    }

    @Test
    void processPlannedRuns_nullRunDomainInList_filtersOut() {
        List<RunDomain> runs = Arrays.asList(new RunDomain(1), null, new RunDomain(null));
        when(plannedRunsBusiness.getPlannedRuns()).thenReturn(runs);

        List<RunIdDto> result = service.ProcessPlannedRuns();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getRunId()).isEqualTo(1);
    }
}

