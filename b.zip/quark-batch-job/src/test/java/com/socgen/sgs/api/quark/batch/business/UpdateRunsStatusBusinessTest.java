package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.infra.dao.UpdateRunsStatusDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UpdateRunsStatusBusinessTest {

    @Mock private UpdateRunsStatusDao dao;
    @InjectMocks private UpdateRunsStatusBusiness business;

    @Test
    void updateRunsStatus_withValidList_callsDao() {
        List<RunIdDto> runs = List.of(new RunIdDto(1), new RunIdDto(2));
        business.updateRunsStatus(runs);
        verify(dao).updateRunsStatus(List.of(1, 2));
    }

    @Test
    void updateRunsStatus_nullList_doesNotCallDao() {
        business.updateRunsStatus(null);
        verifyNoInteractions(dao);
    }

    @Test
    void updateRunsStatus_emptyList_doesNotCallDao() {
        business.updateRunsStatus(List.of());
        verifyNoInteractions(dao);
    }
}
