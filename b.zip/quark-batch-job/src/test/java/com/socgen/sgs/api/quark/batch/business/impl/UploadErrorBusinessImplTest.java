package com.socgen.sgs.api.quark.batch.business.impl;

import com.socgen.sgs.api.quark.batch.dto.UploadErrorDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.UploadErrorDao;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UploadErrorBusinessImplTest {

    @Mock private UploadErrorDao dao;
    @InjectMocks private UploadErrorBusinessImpl business;

    @Test
    void updateUploadsWithErrors_delegatesToDao() {
        List<UploadErrorDTO> errors = List.of(new UploadErrorDTO(1, "err"));
        when(dao.updateUploadsWithErrors(errors)).thenReturn(1);
        assertThat(business.updateUploadsWithErrors(errors)).isEqualTo(1);
    }
}
