package com.socgen.sgs.api.quark.batch.infra.interop.qxps;

import com.socgen.sgs.api.quark.batch.config.QuarkXPressServerProperties;
import com.socgen.sgs.api.quark.batch.exception.QuarkXPressServerException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class QxpsDocumentPoolServiceTest {

    @Mock private RestTemplate restTemplate;
    private QxpsDocumentPoolService service;

    @BeforeEach
    void setUp() {
        QuarkXPressServerProperties props = new QuarkXPressServerProperties();
        props.setBaseUrl("http://localhost");
        props.setPort(8080);
        props.setUploadDirectory("Upload");
        service = new QxpsDocumentPoolService(restTemplate, props);
    }

    @Test
    void addFileToPool_success() {
        ResponseEntity<String> response = new ResponseEntity<>("ok", HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(String.class))).thenReturn(response);
        service.addFileToPool("doc.qxp", new byte[]{1});
    }

    @Test
    void addFileToPool_nonSuccess_throws() {
        ResponseEntity<String> response = new ResponseEntity<>("err", HttpStatus.INTERNAL_SERVER_ERROR);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(String.class))).thenReturn(response);
        assertThatThrownBy(() -> service.addFileToPool("doc.qxp", new byte[]{1}))
                .isInstanceOf(QuarkXPressServerException.class);
    }

    @Test
    void addFileToPool_exception_throws() {
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(String.class))).thenThrow(new RuntimeException("fail"));
        assertThatThrownBy(() -> service.addFileToPool("doc.qxp", new byte[]{1}))
                .isInstanceOf(QuarkXPressServerException.class);
    }

    @Test
    void fetchXmlForBox_success() {
        ResponseEntity<String> response = new ResponseEntity<>("<xml/>", HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(response);
        String result = service.fetchXmlForBox("doc.qxp", "DID");
        assertThat(result).isEqualTo("<xml/>");
    }

    @Test
    void fetchXmlForBox_nonSuccess_throws() {
        ResponseEntity<String> response = new ResponseEntity<>("err", HttpStatus.BAD_REQUEST);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(response);
        assertThatThrownBy(() -> service.fetchXmlForBox("doc.qxp", "DID"))
                .isInstanceOf(QuarkXPressServerException.class);
    }

    @Test
    void fetchXmlForBox_exception_throws() {
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class))).thenThrow(new RuntimeException("fail"));
        assertThatThrownBy(() -> service.fetchXmlForBox("doc.qxp", "DID"))
                .isInstanceOf(QuarkXPressServerException.class);
    }

    @Test
    void fetchFullXml_success() {
        ResponseEntity<String> response = new ResponseEntity<>("<full/>", HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(response);
        String result = service.fetchFullXml("doc.qxp");
        assertThat(result).isEqualTo("<full/>");
    }

    @Test
    void fetchFullXml_nonSuccess_throws() {
        ResponseEntity<String> response = new ResponseEntity<>("err", HttpStatus.NOT_FOUND);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(), eq(String.class))).thenReturn(response);
        assertThatThrownBy(() -> service.fetchFullXml("doc.qxp"))
                .isInstanceOf(QuarkXPressServerException.class);
    }

    @Test
    void deleteFileFromPool_success() {
        ResponseEntity<String> response = new ResponseEntity<>("ok", HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(String.class))).thenReturn(response);
        service.deleteFileFromPool("doc.qxp");
    }

    @Test
    void deleteFileFromPool_nonSuccess_throws() {
        ResponseEntity<String> response = new ResponseEntity<>("err", HttpStatus.INTERNAL_SERVER_ERROR);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(String.class))).thenReturn(response);
        assertThatThrownBy(() -> service.deleteFileFromPool("doc.qxp"))
                .isInstanceOf(QuarkXPressServerException.class);
    }

    @Test
    void deleteFileFromPool_exception_throws() {
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(), eq(String.class))).thenThrow(new RuntimeException("fail"));
        assertThatThrownBy(() -> service.deleteFileFromPool("doc.qxp"))
                .isInstanceOf(QuarkXPressServerException.class);
    }
}
