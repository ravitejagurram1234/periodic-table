package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.config.S3Properties;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

@ExtendWith(MockitoExtension.class)
class S3UploadServiceImplTest {

    @Test
    void constructor_nullProperties_throwsNPE() {
        assertThatThrownBy(() -> new S3UploadServiceImpl(null))
                .isInstanceOf(NullPointerException.class);
    }
}
