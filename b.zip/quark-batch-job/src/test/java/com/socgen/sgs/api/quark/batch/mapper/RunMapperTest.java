package com.socgen.sgs.api.quark.batch.mapper;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import org.junit.jupiter.api.Test;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class RunMapperTest {

    @Test
    void mapResult_extractsRunId() throws SQLException {
        ResultSet rs = mock(ResultSet.class);
        when(rs.getInt("id_run")).thenReturn(42);
        RunDomain domain = RunMapper.mapResult(rs);
        assertThat(domain.getRunId()).isEqualTo(42);
    }

    @Test
    void toDto_convertsCorrectly() {
        RunDomain domain = new RunDomain(99);
        RunIdDto dto = RunMapper.toDto(domain);
        assertThat(dto.getRunId()).isEqualTo(99);
    }
}
