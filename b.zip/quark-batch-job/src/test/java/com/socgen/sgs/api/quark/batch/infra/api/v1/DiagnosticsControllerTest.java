package com.socgen.sgs.api.quark.batch.infra.api.v1;

import com.socgen.sgs.api.quark.batch.domain.DocumentIdentity;
import com.socgen.sgs.api.quark.batch.service.CheckUploadsService;
import com.socgen.sgs.api.quark.batch.service.DocumentPoolService;
import com.socgen.sgs.api.quark.batch.service.QuarkXPressServerXmlService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DiagnosticsControllerTest {

    @Mock private CheckUploadsService checkUploadsService;
    @Mock private DocumentPoolService documentPoolService;
    @Mock private QuarkXPressServerXmlService quarkXPressServerXmlService;
    @InjectMocks private DiagnosticsController controller;

    @Test
    void triggerCheckUploads_success() {
        ResponseEntity<String> response = controller.triggerCheckUploads();
        assertThat(response.getStatusCode().value()).isEqualTo(200);
        verify(checkUploadsService).checkUploads();
    }

    @Test
    void triggerCheckUploads_exception_returns500() {
        doThrow(new RuntimeException("err")).when(checkUploadsService).checkUploads();
        ResponseEntity<String> response = controller.triggerCheckUploads();
        assertThat(response.getStatusCode().value()).isEqualTo(500);
    }

    @Test
    void addFileToPool_emptyFile_returns400() {
        MockMultipartFile file = new MockMultipartFile("file", new byte[0]);
        ResponseEntity<String> response = controller.addFileToPool(file, null);
        assertThat(response.getStatusCode().value()).isEqualTo(400);
    }

    @Test
    void addFileToPool_nullFile_returns400() {
        ResponseEntity<String> response = controller.addFileToPool(null, null);
        assertThat(response.getStatusCode().value()).isEqualTo(400);
    }

    @Test
    void addFileToPool_success() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.qxp", "application/octet-stream", new byte[]{1, 2});
        ResponseEntity<String> response = controller.addFileToPool(file, "doc.qxp");
        assertThat(response.getStatusCode().value()).isEqualTo(200);
        verify(documentPoolService).addFileToPool("doc.qxp", new byte[]{1, 2});
    }

    @Test
    void addFileToPool_exception_returns500() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.qxp", "application/octet-stream", new byte[]{1});
        doThrow(new RuntimeException("fail")).when(documentPoolService).addFileToPool(anyString(), any());
        ResponseEntity<String> response = controller.addFileToPool(file, "doc.qxp");
        assertThat(response.getStatusCode().value()).isEqualTo(500);
    }

    @Test
    void fetchDocumentIdentity_emptyXml_returns400() {
        when(documentPoolService.fetchXmlForBox("doc.qxp", "DID")).thenReturn("");
        ResponseEntity<?> response = controller.fetchDocumentIdentity("doc.qxp");
        assertThat(response.getStatusCode().value()).isEqualTo(400);
    }

    @Test
    void fetchDocumentIdentity_nullDid_returns400() {
        when(documentPoolService.fetchXmlForBox("doc.qxp", "DID")).thenReturn("<xml/>");
        when(quarkXPressServerXmlService.getElementValueByIdName("<xml/>", "DID")).thenReturn(null);
        ResponseEntity<?> response = controller.fetchDocumentIdentity("doc.qxp");
        assertThat(response.getStatusCode().value()).isEqualTo(400);
    }

    @Test
    void fetchDocumentIdentity_success_returnsIdentity() {
        when(documentPoolService.fetchXmlForBox("doc.qxp", "DID")).thenReturn("<xml/>");
        when(quarkXPressServerXmlService.getElementValueByIdName("<xml/>", "DID")).thenReturn("val");
        DocumentIdentity identity = DocumentIdentity.builder().idSuivi("1").build();
        when(quarkXPressServerXmlService.parseDocumentIdentity("val")).thenReturn(identity);
        ResponseEntity<?> response = controller.fetchDocumentIdentity("doc.qxp");
        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isEqualTo(identity);
    }

    @Test
    void fetchDocumentIdentity_exception_returns500() {
        when(documentPoolService.fetchXmlForBox("doc.qxp", "DID")).thenThrow(new RuntimeException("fail"));
        ResponseEntity<?> response = controller.fetchDocumentIdentity("doc.qxp");
        assertThat(response.getStatusCode().value()).isEqualTo(500);
    }
}
