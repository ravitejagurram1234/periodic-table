package com.socgen.sgs.api.quark.batch.exception;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class QuarkXPressServerExceptionTest {

    @Test
    void constructorWithMessage() {
        QuarkXPressServerException ex = new QuarkXPressServerException("msg");
        assertThat(ex.getMessage()).isEqualTo("msg");
    }

    @Test
    void constructorWithMessageAndCause() {
        RuntimeException cause = new RuntimeException("cause");
        QuarkXPressServerException ex = new QuarkXPressServerException("msg", cause);
        assertThat(ex.getMessage()).isEqualTo("msg");
        assertThat(ex.getCause()).isEqualTo(cause);
    }

    @Test
    void constructorWithCause() {
        RuntimeException cause = new RuntimeException("cause");
        QuarkXPressServerException ex = new QuarkXPressServerException(cause);
        assertThat(ex.getCause()).isEqualTo(cause);
    }
}
