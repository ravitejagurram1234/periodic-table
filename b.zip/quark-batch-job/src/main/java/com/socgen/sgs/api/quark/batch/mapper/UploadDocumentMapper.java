package com.socgen.sgs.api.quark.batch.mapper;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.UploadDocumentDTO;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UploadDocumentMapper {
    public static UploadDocumentDomain mapResult(ResultSet rs) throws SQLException {
        UploadDocumentDomain uploadDocumentDomain = new UploadDocumentDomain();
        uploadDocumentDomain.setUploadId(rs.getInt("id_upload"));
        return uploadDocumentDomain;
    }

    public static UploadDocumentDomain mapResultWithContenu(ResultSet rs) throws SQLException {
        UploadDocumentDomain uploadDocumentDomain = new UploadDocumentDomain();
        uploadDocumentDomain.setUploadId(rs.getInt("id_upload"));
        uploadDocumentDomain.setContenu(rs.getBytes("CONTENU"));
        return uploadDocumentDomain;
    }

    public static UploadDocumentDTO toDto(UploadDocumentDomain domain) {
        return new UploadDocumentDTO(domain.getUploadId(), domain.getContenu());
    }
}
