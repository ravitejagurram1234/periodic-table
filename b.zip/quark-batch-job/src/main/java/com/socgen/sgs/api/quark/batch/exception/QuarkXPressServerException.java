package com.socgen.sgs.api.quark.batch.exception;

public class QuarkXPressServerException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public QuarkXPressServerException(String message) {
        super(message);
    }
    public QuarkXPressServerException(String message, Throwable cause) {
        super(message, cause);
    }
    public QuarkXPressServerException(Throwable cause) {
        super(cause);
    }
}

