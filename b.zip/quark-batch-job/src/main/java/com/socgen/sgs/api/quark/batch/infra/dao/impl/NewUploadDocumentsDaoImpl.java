package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.NewUploadDocumentsDao;
import com.socgen.sgs.api.quark.batch.mapper.UploadDocumentMapper;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;

@Repository
public class NewUploadDocumentsDaoImpl implements NewUploadDocumentsDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public NewUploadDocumentsDaoImpl(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_BATCH")
                .withFunctionName("Get_New_Upload")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> UploadDocumentMapper.mapResult(rs))
                );
    }

    @Override
    public List<UploadDocumentDomain> getNewUploadDocuments() {
        // Call the Oracle function and get the result as List directly
        @SuppressWarnings("unchecked")
        List<UploadDocumentDomain> uploadDocuments = simpleJdbcCall.executeFunction(List.class);
        return uploadDocuments;
    }
}
