package com.socgen.sgs.api.quark.batch.service;

import com.socgen.sgs.api.quark.batch.dto.RunIdDto;

import java.util.List;

public interface ProcessPlannedRunsService {
    List<RunIdDto> processPlannedRuns();
}
