package com.socgen.sgs.api.quark.batch.infra.dao;

import java.util.List;

public interface UpdateRunsStatusDao {
    void updateRunsStatus(List<Integer> runIds);
}
