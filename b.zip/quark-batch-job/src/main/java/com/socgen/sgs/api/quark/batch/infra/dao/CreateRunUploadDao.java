package com.socgen.sgs.api.quark.batch.infra.dao;

import com.socgen.sgs.api.quark.batch.dto.CreateRunUploadResultDTO;

public interface CreateRunUploadDao {
    CreateRunUploadResultDTO createRunUpload(Integer idSuivi, Integer idQxpUpload);
}
