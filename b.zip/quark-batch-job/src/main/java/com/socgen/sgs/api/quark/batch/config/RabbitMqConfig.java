package com.socgen.sgs.api.quark.batch.config;

import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ Configuration for Quark Batch Job.
 * Queue must already exist on the RabbitMQ server — this app only publishes to it.
 * Auto-declaration is disabled since user lacks 'configure' permission.
 */
@Configuration
public class RabbitMqConfig {

    private static String BATCH_RUN_QUEUE;

    @Value("${queue.runqueue}")
    public void setBatchRunQueue(String queueName) {
        BATCH_RUN_QUEUE = queueName;
    }

    public static String getBatchRunQueue() {
        return BATCH_RUN_QUEUE;
    }

    @Value("${spring.rabbitmq.host}")
    private String host;

    @Value("${spring.rabbitmq.port}")
    private int port;

    @Value("${spring.rabbitmq.username}")
    private String username;

    @Value("${spring.rabbitmq.password}")
    private String password;

    @Value("${spring.rabbitmq.virtual-host}")
    private String virtualHost;

    @Value("${spring.rabbitmq.ssl.enabled:false}")
    private boolean sslEnabled;

    @Value("${spring.rabbitmq.connection-timeout:30000}")
    private int connectionTimeout;

    @Value("${spring.rabbitmq.requested-heartbeat:60}")
    private int requestedHeartbeat;

    /**
     * Configure RabbitMQ connection factory
     */
    @Bean
    public ConnectionFactory connectionFactory() {
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
        connectionFactory.setHost(host);
        connectionFactory.setPort(port);
        connectionFactory.setUsername(username);
        connectionFactory.setPassword(password);
        connectionFactory.setVirtualHost(virtualHost);

        // Set connection timeout (in milliseconds)
        connectionFactory.setConnectionTimeout(connectionTimeout);

        // Set requested heartbeat (in seconds)
        connectionFactory.setRequestedHeartBeat(requestedHeartbeat);

        if (sslEnabled) {
            try {
                connectionFactory.getRabbitConnectionFactory().useSslProtocol();
            } catch (Exception e) {
                throw new RuntimeException("Failed to enable SSL for RabbitMQ connection", e);
            }
        }

        return connectionFactory;
    }

    /**
     * Configure message converter to use JSON
     */
    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    /**
     * Configure RabbitTemplate for sending messages
     */
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        rabbitTemplate.setMessageConverter(jsonMessageConverter());
        return rabbitTemplate;
    }

    /**
     * Disable RabbitAdmin auto-declaration.
     * The queue already exists on the server and user lacks 'configure' permission.
     */
    @Bean
    public RabbitAdmin rabbitAdmin(ConnectionFactory connectionFactory) {
        RabbitAdmin admin = new RabbitAdmin(connectionFactory);
        admin.setAutoStartup(false);
        return admin;
    }
}

