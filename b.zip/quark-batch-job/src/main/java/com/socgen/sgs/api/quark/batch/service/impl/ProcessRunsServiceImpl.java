package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.service.ProcessRunsService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProcessRunsServiceImpl implements ProcessRunsService {


    @Override
    public void processRuns(List<RunIdDto> runIdDtos) {
        // Implementation goes here
        //status update
        //call for uploads check
        //add it in rabbitMQ.
    }
}
