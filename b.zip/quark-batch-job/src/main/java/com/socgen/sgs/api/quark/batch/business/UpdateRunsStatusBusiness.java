package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.infra.dao.UpdateRunsStatusDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class UpdateRunsStatusBusiness {
    private static final Logger logger = LoggerFactory.getLogger(UpdateRunsStatusBusiness.class);

    private final UpdateRunsStatusDao updateRunsStatusDao;

    public UpdateRunsStatusBusiness(UpdateRunsStatusDao updateRunsStatusDao) {
        this.updateRunsStatusDao = updateRunsStatusDao;
    }

    /**
     * Update runs status to 5 (ID_STATUT_GENERATION) for the provided new uploads
     * @param newUploads List of RunIdDto whose status needs to be updated
     */
    public void updateRunsStatus(List<RunIdDto> newUploads) {
        if (newUploads == null || newUploads.isEmpty()) {
            logger.warn("No run IDs provided for status update");
            return;
        }

        List<Integer> runIds = newUploads.stream()
                .map(RunIdDto::getRunId)
                .toList();

        logger.info("Updating status for {} runs", runIds.size());
        updateRunsStatusDao.updateRunsStatus(runIds);
        logger.info("Successfully updated status for {} runs", runIds.size());
    }
}

