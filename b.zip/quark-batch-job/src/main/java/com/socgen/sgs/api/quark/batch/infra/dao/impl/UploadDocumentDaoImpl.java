package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.UploadDocumentDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.UploadDocumentDao;
import com.socgen.sgs.api.quark.batch.mapper.UploadDocumentMapper;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;

@Repository
public class UploadDocumentDaoImpl implements UploadDocumentDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public UploadDocumentDaoImpl(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_BATCH")
                .withFunctionName("Get_Upload_Document")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> UploadDocumentMapper.mapResultWithContenu(rs)),
                        new SqlParameter("p_id_upload", Types.NUMERIC)
                );
    }

    @Override
    public UploadDocumentDomain getUploadDocument(UploadDocumentDTO uploadId) {
        @SuppressWarnings("unchecked")
        List<UploadDocumentDomain> uploadDocuments = simpleJdbcCall.executeFunction(List.class, uploadId.getUploadId());
        return !uploadDocuments.isEmpty() ? uploadDocuments.get(0) : null;
    }
}
