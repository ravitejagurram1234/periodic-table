package com.socgen.sgs.api.quark.batch.scheduler;

import com.socgen.sgs.api.quark.batch.service.CheckUploadsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Scheduled job to check for new uploads every hour.
 */
@Component
public class CheckUploadsScheduler {

    private static final Logger logger = LoggerFactory.getLogger(CheckUploadsScheduler.class);

    private final CheckUploadsService checkUploadsService;

    public CheckUploadsScheduler(CheckUploadsService checkUploadsService) {
        this.checkUploadsService = checkUploadsService;
    }

    @Scheduled(cron = "${scheduler.check-uploads.cron}")
    public void checkUploads() {
        try {
            checkUploadsService.checkUploads();
            logger.info("Scheduled job CheckUploads completed successfully");
        } catch (Exception e) {
            logger.error("Error occurred during scheduled CheckUploads job", e);
        }
    }
}
