package com.socgen.sgs.api.quark.batch.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;

@Configuration
@ConfigurationProperties(prefix = "s3")
@Validated
@Getter
@Setter
public class S3Properties {

    @NotBlank(message = "S3 access key is required")
    private String accessKey;

    @NotBlank(message = "S3 secret key is required")
    private String secretKey;

    @NotBlank(message = "S3 endpoint is required")
    private String endpoint;

    private Bucket bucket = new Bucket();

    @Getter
    @Setter
    public static class Bucket {
        @NotBlank(message = "S3 bucket name is required")
        private String name;
    }
}

