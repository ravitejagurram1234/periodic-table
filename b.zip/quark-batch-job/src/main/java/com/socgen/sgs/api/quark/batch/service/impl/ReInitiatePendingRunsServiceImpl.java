package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.business.RunResetAndInitiateBusiness;
import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.mapper.RunMapper;
import com.socgen.sgs.api.quark.batch.service.ReInitiatePendingRunsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReInitiatePendingRunsServiceImpl implements ReInitiatePendingRunsService {

    private static final Logger logger = LoggerFactory.getLogger(ReInitiatePendingRunsServiceImpl.class);

    private final RunResetAndInitiateBusiness runResetAndInitiateBusiness;
    private final RabbitMqProducer rabbitMqProducer;

    public ReInitiatePendingRunsServiceImpl(RunResetAndInitiateBusiness runResetAndInitiateBusiness, RabbitMqProducer rabbitMqProducer) {
        this.runResetAndInitiateBusiness = runResetAndInitiateBusiness;
        this.rabbitMqProducer = rabbitMqProducer;
    }

    @Override
    public List<RunIdDto> reInitiatePendingRuns() {
        List<RunIdDto> runsToBeInitiated = getPlannedRuns();

        if (runsToBeInitiated != null && !runsToBeInitiated.isEmpty()) {
            rabbitMqProducer.sendRunIds(runsToBeInitiated);
        } else {
            logger.info("No planned runs to process");
        }
        return runsToBeInitiated;
    }

    public List<RunIdDto> getPlannedRuns() {
        logger.info("Starting to reset runs status...");
        try {
            runResetAndInitiateBusiness.resetRunsStatus();
            logger.info("Successfully reset runs status");
        } catch (Exception e) {
            logger.error("Failed to reset runs status", e);
            throw e;
        }
        
        logger.info("Fetching runs to be initiated...");
        List<RunDomain> runsToBeInitiated;
        try {
            runsToBeInitiated = runResetAndInitiateBusiness.getRunsToBeInitiated();
            logger.info("Successfully fetched {} run(s) to be initiated", 
                       runsToBeInitiated != null ? runsToBeInitiated.size() : 0);
        } catch (Exception e) {
            logger.error("Failed to fetch runs to be initiated", e);
            throw e;
        }
        
        if (runsToBeInitiated == null) {
            logger.warn("getRunsToBeInitiated returned null, returning empty list");
            return List.of();
        }
        
        return runsToBeInitiated.stream().map(RunMapper::toDto).toList();
    }
}
