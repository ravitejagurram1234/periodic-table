package com.socgen.sgs.api.quark.batch.infra.dao;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.UploadDocumentDTO;

public interface UploadDocumentDao {
    UploadDocumentDomain getUploadDocument(UploadDocumentDTO uploadId);
}
