package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.RunResetAndInitiateDao;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class RunResetAndInitiateBusiness {

    private final RunResetAndInitiateDao runResetAndInitiateDao;

    public RunResetAndInitiateBusiness(RunResetAndInitiateDao runResetAndInitiateDao) {
        this.runResetAndInitiateDao = runResetAndInitiateDao;
    }

    public void resetRunsStatus() {
        runResetAndInitiateDao.resetRunsStatus();
    }

    public List<RunDomain> getRunsToBeInitiated() {
        return runResetAndInitiateDao.getRunsToBeInitiated();
    }
}
