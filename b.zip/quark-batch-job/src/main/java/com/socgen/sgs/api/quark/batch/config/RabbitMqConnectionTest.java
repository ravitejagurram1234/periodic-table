package com.socgen.sgs.api.quark.batch.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Profile;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * RabbitMQ Connection Test Utility
 * Tests connectivity to RabbitMQ server on application startup
 */
@Component
@Profile("!test")
public class RabbitMqConnectionTest {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqConnectionTest.class);

    @Value("${spring.rabbitmq.host}")
    private String host;

    @Value("${spring.rabbitmq.port}")
    private int port;

    @Value("${spring.rabbitmq.connection-timeout:5000}")
    private int connectionTimeout;

    @EventListener(ApplicationReadyEvent.class)
    public void testConnection() {
        logger.info("Testing RabbitMQ connectivity to {}:{}", host, port);

        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), connectionTimeout);
            logger.info("✓ Successfully connected to RabbitMQ server {}:{}", host, port);
            logger.info("  Connection established, RabbitMQ server is reachable");
        } catch (IOException e) {
            logger.error("✗ Failed to connect to RabbitMQ server {}:{}", host, port);
            logger.error("  Error: {}", e.getMessage());
            logger.error("  Possible causes:");
            logger.error("    1. RabbitMQ server is not running or not accessible");
            logger.error("    2. Firewall is blocking port {}", port);
            logger.error("    3. Not connected to corporate VPN");
            logger.error("    4. Network routing issues");
            logger.error("  Application will continue but RabbitMQ features will not work");
        }
    }
}

