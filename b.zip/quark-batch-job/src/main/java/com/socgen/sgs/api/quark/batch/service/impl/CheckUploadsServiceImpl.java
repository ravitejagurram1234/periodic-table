package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.business.CreateRunUploadBusiness;
import com.socgen.sgs.api.quark.batch.business.NewUploadsBusiness;
import com.socgen.sgs.api.quark.batch.business.UploadDocumentBusiness;
import com.socgen.sgs.api.quark.batch.business.UploadErrorBusiness;
import com.socgen.sgs.api.quark.batch.domain.DocumentIdentity;
import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.CreateRunUploadResultDTO;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.dto.UploadDocumentDTO;
import com.socgen.sgs.api.quark.batch.dto.UploadErrorDTO;
import com.socgen.sgs.api.quark.batch.service.DocumentPoolService;
import com.socgen.sgs.api.quark.batch.mapper.UploadDocumentMapper;
import com.socgen.sgs.api.quark.batch.service.CheckUploadsService;
import com.socgen.sgs.api.quark.batch.service.QuarkXPressServerXmlService;
import com.socgen.sgs.api.quark.batch.service.S3UploadService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CheckUploadsServiceImpl implements CheckUploadsService {

    private static final Logger logger = LoggerFactory.getLogger(CheckUploadsServiceImpl.class);

    private final NewUploadsBusiness newUploadsBusiness;
    private final UploadDocumentBusiness uploadDocumentBusiness;
    private final S3UploadService s3UploadService;
    private final QuarkXPressServerXmlService quarkXPressServerXmlService;
    private final DocumentPoolService qxpsDocumentPoolService;
    private final CreateRunUploadBusiness createRunUploadBusiness;
    private final RabbitMqProducer rabbitMqProducer;
    private final UploadErrorBusiness uploadErrorBusiness;

    public CheckUploadsServiceImpl(NewUploadsBusiness newUploadsBusiness,
                                   UploadDocumentBusiness uploadDocumentBusiness,
                                   S3UploadService s3UploadService,
                                   QuarkXPressServerXmlService quarkXPressServerXmlService,
                                   DocumentPoolService qxpsDocumentPoolService,
                                   CreateRunUploadBusiness createRunUploadBusiness,
                                   RabbitMqProducer rabbitMqProducer,
                                   UploadErrorBusiness uploadErrorBusiness) {
        this.newUploadsBusiness = newUploadsBusiness;
        this.uploadDocumentBusiness = uploadDocumentBusiness;
        this.s3UploadService = s3UploadService;
        this.quarkXPressServerXmlService = quarkXPressServerXmlService;
        this.qxpsDocumentPoolService = qxpsDocumentPoolService;
        this.createRunUploadBusiness = createRunUploadBusiness;
        this.rabbitMqProducer = rabbitMqProducer;
        this.uploadErrorBusiness = uploadErrorBusiness;
    }

    @Override
    public List<RunIdDto> checkUploads() {
        // 1–3: Get new uploads, log, exit if empty
        List<UploadDocumentDTO> newUploads = getNewUploads();
        logger.info("Found {} new upload(s)", newUploads.size());
        if (newUploads.isEmpty()) {
            return List.of();
        }

        // 4: Fetch blob content from DB
        List<UploadDocumentDTO> uploadDocuments = getUploadDocuments(newUploads);
        logger.info("Processing {} uploads with content", uploadDocuments.size());

        // 5: Accumulators for successful run IDs and errors
        List<RunIdDto> runIdsToBeLaunched = new ArrayList<>();
        List<UploadErrorDTO> uploadErrors = new ArrayList<>();
        int successCount = 0;
        int failureCount = 0;

        // 6: Per-upload processing loop
        for (UploadDocumentDTO doc : uploadDocuments) {
            Integer uploadId = doc.getUploadId();
            try {
                // 6a: Upload to S3
                String s3Key = s3UploadService.uploadDocument(uploadId, doc.getContenu());
                logger.info("Uploaded to S3. Upload ID: {}, S3 Key: {}", uploadId, s3Key);

                // 6a2: Add file to QuarkXPress Server document pool
                String documentName = constructDocumentName(uploadId);
                qxpsDocumentPoolService.addFileToPool(documentName, doc.getContenu());

                // 6b: Fetch XML metadata (DID box) from QuarkXPress Server
                String xmlContent = qxpsDocumentPoolService.fetchXmlForBox(documentName, "DID");
                if (xmlContent == null || xmlContent.isBlank()) {
                    String errorMsg = "Empty XML response from QXPS";
                    logger.error("{}. Upload ID: {}", errorMsg, uploadId);
                    uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                    failureCount++;
                    continue;
                }
                logger.debug("XML content received for Upload ID {}: length={}", uploadId, xmlContent.length());
                String didValue = quarkXPressServerXmlService.getElementValueByIdName(xmlContent, "DID");
                if (didValue == null || didValue.isBlank()) {
                    String errorMsg = "DID not found in XML";
                    logger.error("{}. Upload ID: {}", errorMsg, uploadId);
                    uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                    failureCount++;
                    continue;
                }
                DocumentIdentity identity = quarkXPressServerXmlService.parseDocumentIdentity(didValue);
                Integer idSuivi = Integer.parseInt(identity.getIdSuivi());
                logger.info("Extracted metadata. Upload ID: {}, Suivi ID: {}", uploadId, idSuivi);

                // 6c: Create run via stored procedure
                CreateRunUploadResultDTO result = createRunUploadBusiness.createRunUpload(idSuivi, uploadId);

                // 6d: Handle result codes
                if (result.isSuccess()) {
                    logger.info("Run created. Upload ID: {}, Run ID: {}", uploadId, result.getRunId());
                    runIdsToBeLaunched.add(new RunIdDto(result.getRunId()));
                    successCount++;
                } else if (result.isRunInExecution()) {
                    String errorMsg = "Run already in execution";
                    logger.error("{}. Upload ID: {}, Suivi ID: {}", errorMsg, uploadId, idSuivi);
                    uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                    failureCount++;
                } else if (result.isSuiviLocked()) {
                    String errorMsg = "Follow-up is locked";
                    logger.error("{}. Upload ID: {}, Suivi ID: {}", errorMsg, uploadId, idSuivi);
                    uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                    failureCount++;
                } else {
                    String errorMsg = "Error creating run";
                    logger.error("{}. Upload ID: {}, Suivi ID: {}", errorMsg, uploadId, idSuivi);
                    uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                    failureCount++;
                }
            } catch (Exception e) {
                String errorMsg = "Failed processing: " + e.getMessage();
                logger.error("{}. Upload ID: {}. Continuing.", errorMsg, uploadId, e);
                uploadErrors.add(new UploadErrorDTO(uploadId, errorMsg));
                failureCount++;
            }
        }

        // 7: Update database with all errors (if any)
        if (!uploadErrors.isEmpty()) {
            try {
                Integer rowsUpdated = uploadErrorBusiness.updateUploadsWithErrors(uploadErrors);
                logger.info("Updated {} upload records with error status", rowsUpdated);
            } catch (Exception e) {
                logger.error("Failed to update error uploads in database", e);
            }
        }

        // 8: Send successful run IDs to RabbitMQ
        for (RunIdDto runIdDto : runIdsToBeLaunched) {
            try {
                rabbitMqProducer.sendRunId(runIdDto.getRunId());
                logger.info("Run ID {} queued to RabbitMQ", runIdDto.getRunId());
            } catch (Exception e) {
                logger.error("Failed to queue Run ID {}.", runIdDto.getRunId(), e);
            }
        }

        logger.info("Completed: {} successful, {} failed", successCount, failureCount);
        return runIdsToBeLaunched;
    }

    private String constructDocumentName(Integer uploadId) {
        return String.format("UP_%d.qxp", uploadId);
    }

    private List<UploadDocumentDTO> getNewUploads() {
        List<UploadDocumentDomain> uploadDocumentDomains = newUploadsBusiness.getNewUploadDocuments();
        return uploadDocumentDomains.stream().map(UploadDocumentMapper:: toDto).toList();
    }

    private List<UploadDocumentDTO> getUploadDocuments(List<UploadDocumentDTO> uploadIds) {
        return uploadIds.stream()
                .map(uploadId -> {
                    UploadDocumentDomain domain = uploadDocumentBusiness.getUploadDocument(uploadId);
                    return UploadDocumentMapper.toDto(domain);
                })
                .toList();
    }
}
