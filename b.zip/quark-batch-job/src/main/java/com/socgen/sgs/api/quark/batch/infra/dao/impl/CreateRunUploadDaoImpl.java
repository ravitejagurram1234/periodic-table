package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.dto.CreateRunUploadResultDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.CreateRunUploadDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;

@Repository
public class CreateRunUploadDaoImpl implements CreateRunUploadDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public CreateRunUploadDaoImpl(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_BATCH")
                .withFunctionName("Create_Run_Upload")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", Types.NUMERIC),
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_id_qxp_upload", Types.NUMERIC)
                );
    }

    @Override
    public CreateRunUploadResultDTO createRunUpload(Integer idSuivi, Integer idQxpUpload) {
        java.math.BigDecimal result = simpleJdbcCall.executeFunction(java.math.BigDecimal.class, idSuivi, idQxpUpload);
        return new CreateRunUploadResultDTO(result != null ? result.intValue() : null);
    }
}
