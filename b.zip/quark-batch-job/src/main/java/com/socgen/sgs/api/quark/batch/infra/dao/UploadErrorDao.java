package com.socgen.sgs.api.quark.batch.infra.dao;

import com.socgen.sgs.api.quark.batch.dto.UploadErrorDTO;

import java.util.List;

public interface UploadErrorDao {

    /**
     * Update uploads in database with error status
     * @param uploadErrors list of uploads with error information
     * @return number of rows updated
     */
    Integer updateUploadsWithErrors(List<UploadErrorDTO> uploadErrors);
}

