package com.socgen.sgs.api.quark.batch.service;

import com.socgen.sgs.api.quark.batch.domain.DocumentIdentity;

/**
 * Service for fetching and parsing XML content from QuarkXPress Server.
 */
public interface QuarkXPressServerXmlService {

    /**
     * Fetches XML content for a given document name.
     */
    String fetchXmlContent(String documentName);

    /**
     * Extracts text content from XML by ID NAME attribute.
     */
    String getElementValueByIdName(String xmlContent, String idName);

    /**
     * Parses pipe-separated identity string into DocumentIdentity.
     * Format: ID_Fnd_Code|ID_Suivi|ID_Run|ID_Langue|Due_Date|Generation_DateTime|ID_Unit_Code(optional)
     */
    DocumentIdentity parseDocumentIdentity(String identityString);
}

