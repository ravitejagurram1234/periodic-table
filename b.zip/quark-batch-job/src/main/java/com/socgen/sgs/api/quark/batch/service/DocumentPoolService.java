package com.socgen.sgs.api.quark.batch.service;

/**
 * Port interface for interacting with QuarkXPress Server document pool.
 * Implementations reside in the infra layer.
 */
public interface DocumentPoolService {

    /**
     * Adds a file to the document pool.
     */
    void addFileToPool(String documentName, byte[] fileContent);

    /**
     * Fetches XML content for a given box from the document pool.
     */
    String fetchXmlForBox(String documentName, String boxName);
}

