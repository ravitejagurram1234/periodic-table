package com.socgen.sgs.api.quark.batch.service;

import com.socgen.sgs.api.quark.batch.dto.RunIdDto;

import java.util.List;

public interface ProcessRunsService {
    public void processRuns(List<RunIdDto> runIdDtos);
}
