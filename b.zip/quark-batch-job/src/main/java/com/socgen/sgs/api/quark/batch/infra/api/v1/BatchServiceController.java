package com.socgen.sgs.api.quark.batch.infra.api.v1;

import com.socgen.sgs.api.quark.batch.business.UpdateRunsStatusBusiness;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.service.CheckUploadsService;
import com.socgen.sgs.api.quark.batch.service.ProcessPlannedRunsService;
import com.socgen.sgs.api.quark.batch.service.ReInitiatePendingRunsService;
import com.socgen.sgs.api.quark.batch.service.impl.RabbitMqProducer;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "api/v1/batchService")
//@PreAuthorize("hasAuthority('api.quark.v1')")
@Tag(name = "All operations of Batch service", description = "All operations of Batch service")
public class BatchServiceController {

    private static final Logger logger = LoggerFactory.getLogger(BatchServiceController.class);

    private final CheckUploadsService checkUploadsService;
    private final ProcessPlannedRunsService processPlannedRunsService;
    private final ReInitiatePendingRunsService reInitiatePendingRunsService;
    private final UpdateRunsStatusBusiness updateRunsStatusBusiness;
    private final RabbitMqProducer rabbitMqProducer;

    public BatchServiceController(CheckUploadsService checkUploadsService,
                                  ProcessPlannedRunsService processPlannedRunsService,
                                  ReInitiatePendingRunsService reInitiatePendingRunsService,
                                  UpdateRunsStatusBusiness updateRunsStatusBusiness,
                                  RabbitMqProducer rabbitMqProducer) {
        this.checkUploadsService = checkUploadsService;
        this.processPlannedRunsService = processPlannedRunsService;
        this.reInitiatePendingRunsService = reInitiatePendingRunsService;
        this.updateRunsStatusBusiness = updateRunsStatusBusiness;
        this.rabbitMqProducer = rabbitMqProducer;
    }

    @GetMapping(path = "/newUploads")
    @Operation(summary = "Get new upload documents", description = "Triggers checkUploads process and returns the list of run IDs created")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved new uploads"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<List<RunIdDto>> getNewUploads() {
        List<RunIdDto> createdRunIds = checkUploadsService.checkUploads();
        return ResponseEntity.ok(createdRunIds);
    }

    @GetMapping(path = "/fetchPlannedRuns")
    @Operation(summary = "Get planned runs", description = "Retrieves a list of new planned runs that need to be processed")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved new planned runs"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<List<RunIdDto>> fetchPlannedRuns() {
        List<RunIdDto> plannedRuns = processPlannedRunsService.processPlannedRuns();
        return ResponseEntity.ok(plannedRuns);
    }

    @GetMapping(path = "/reInitiatePendingRuns")
    @Operation(summary = "Re Initiate pending runs", description = "Retrieves a list of runs that fell into pending state and need to be re-initiated")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved runs to be re-initiated"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<List<RunIdDto>> reInitiatePendingRuns() {
        List<RunIdDto> runsToBeInitiated = reInitiatePendingRunsService.reInitiatePendingRuns();
        return ResponseEntity.ok(runsToBeInitiated);
    }

    @PostMapping(path = "/executeRuns")
    @Operation(summary = "Execute runs", description = "Execute processing runs for the provided run IDs")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Runs executed successfully"),
            @ApiResponse(responseCode = "400", description = "Bad request"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<String> executeRuns(@RequestBody List<Integer> runIds) {
        // Convert Integer runIds to RunIdDto objects
        List<RunIdDto> runIdDtos = runIds.stream()
                .map(RunIdDto::new)
                .toList();

        // Update runs status through business layer
        updateRunsStatusBusiness.updateRunsStatus(runIdDtos);

        // Send run IDs to RabbitMQ queue
        rabbitMqProducer.sendRunIds(runIdDtos);

        return ResponseEntity.ok().body("Runs executed successfully for " + runIds.size() + " run IDs");
    }
}
