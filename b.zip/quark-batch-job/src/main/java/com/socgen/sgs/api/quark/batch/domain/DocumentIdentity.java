package com.socgen.sgs.api.quark.batch.domain;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Domain class representing the identity information extracted from QuarkXPress XML documents.
 * <p>
 * The identity string is a pipe-separated value containing document metadata:
 * ID_Fnd_Code|ID_Suivi|ID_Run|ID_Langue|Due_Date|Generation_DateTime|ID_Unit_Code(optional)
 * </p>
 * <p>
 * Examples:
 * <ul>
 *   <li>101009|75747|493152|1|12/01/2024 00:00:00|06/25/2025 06:31:36|101223</li>
 *   <li>78001|7641|53081|1|12/01/2009 00:00:00|04/12/2010 17:39:29|</li>
 *   <li>78001|7641|53081|1|12/01/2009 00:00:00|04/12/2010 17:39:29</li>
 * </ul>
 * </p>
 *
 * @author quark-batch-job
 * @since 1.0.0
 */
public class DocumentIdentity {

    /**
     * Fund Code identifier
     */
    private final String idFndCode;

    /**
     * Suivi (Follow-up) identifier
     */
    private final String idSuivi;

    /**
     * Run identifier
     */
    private final String idRun;

    /**
     * Language identifier
     */
    private final String idLangue;

    /**
     * Due date of the Suivi
     */
    private final LocalDateTime dueDate;

    /**
     * Generation date and time
     */
    private final LocalDateTime generationDateTime;

    /**
     * Unit Code identifier (optional - may be null or empty)
     */
    private final String idUnitCode;

    /**
     * Constructs a new DocumentIdentity with all fields.
     *
     * @param idFndCode          the Fund Code identifier
     * @param idSuivi            the Suivi identifier
     * @param idRun              the Run identifier
     * @param idLangue           the Language identifier
     * @param dueDate            the due date of the Suivi
     * @param generationDateTime the generation date and time
     * @param idUnitCode         the Unit Code identifier (optional)
     */
    public DocumentIdentity(String idFndCode, String idSuivi, String idRun, String idLangue,
                            LocalDateTime dueDate, LocalDateTime generationDateTime, String idUnitCode) {
        this.idFndCode = idFndCode;
        this.idSuivi = idSuivi;
        this.idRun = idRun;
        this.idLangue = idLangue;
        this.dueDate = dueDate;
        this.generationDateTime = generationDateTime;
        this.idUnitCode = idUnitCode;
    }

    public String getIdFndCode() {
        return idFndCode;
    }

    public String getIdSuivi() {
        return idSuivi;
    }

    public String getIdRun() {
        return idRun;
    }

    public String getIdLangue() {
        return idLangue;
    }

    public LocalDateTime getDueDate() {
        return dueDate;
    }

    public LocalDateTime getGenerationDateTime() {
        return generationDateTime;
    }

    public String getIdUnitCode() {
        return idUnitCode;
    }

    /**
     * Checks if the Unit Code is present.
     *
     * @return true if idUnitCode is not null and not empty, false otherwise
     */
    public boolean hasUnitCode() {
        return idUnitCode != null && !idUnitCode.trim().isEmpty();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DocumentIdentity that = (DocumentIdentity) o;
        return Objects.equals(idFndCode, that.idFndCode) &&
                Objects.equals(idSuivi, that.idSuivi) &&
                Objects.equals(idRun, that.idRun) &&
                Objects.equals(idLangue, that.idLangue) &&
                Objects.equals(dueDate, that.dueDate) &&
                Objects.equals(generationDateTime, that.generationDateTime) &&
                Objects.equals(idUnitCode, that.idUnitCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idFndCode, idSuivi, idRun, idLangue, dueDate, generationDateTime, idUnitCode);
    }

    @Override
    public String toString() {
        return "DocumentIdentity{" +
                "idFndCode='" + idFndCode + '\'' +
                ", idSuivi='" + idSuivi + '\'' +
                ", idRun='" + idRun + '\'' +
                ", idLangue='" + idLangue + '\'' +
                ", dueDate=" + dueDate +
                ", generationDateTime=" + generationDateTime +
                ", idUnitCode='" + idUnitCode + '\'' +
                '}';
    }

    /**
     * Builder class for creating DocumentIdentity instances.
     */
    public static class Builder {
        private String idFndCode;
        private String idSuivi;
        private String idRun;
        private String idLangue;
        private LocalDateTime dueDate;
        private LocalDateTime generationDateTime;
        private String idUnitCode;

        public Builder idFndCode(String idFndCode) {
            this.idFndCode = idFndCode;
            return this;
        }

        public Builder idSuivi(String idSuivi) {
            this.idSuivi = idSuivi;
            return this;
        }

        public Builder idRun(String idRun) {
            this.idRun = idRun;
            return this;
        }

        public Builder idLangue(String idLangue) {
            this.idLangue = idLangue;
            return this;
        }

        public Builder dueDate(LocalDateTime dueDate) {
            this.dueDate = dueDate;
            return this;
        }

        public Builder generationDateTime(LocalDateTime generationDateTime) {
            this.generationDateTime = generationDateTime;
            return this;
        }

        public Builder idUnitCode(String idUnitCode) {
            this.idUnitCode = idUnitCode;
            return this;
        }

        public DocumentIdentity build() {
            return new DocumentIdentity(idFndCode, idSuivi, idRun, idLangue,
                    dueDate, generationDateTime, idUnitCode);
        }
    }

    /**
     * Creates a new Builder instance.
     *
     * @return a new Builder
     */
    public static Builder builder() {
        return new Builder();
    }
}

