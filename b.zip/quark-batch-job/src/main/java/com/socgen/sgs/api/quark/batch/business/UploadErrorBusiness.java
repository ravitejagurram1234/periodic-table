package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.dto.UploadErrorDTO;

import java.util.List;

public interface UploadErrorBusiness {
    Integer updateUploadsWithErrors(List<UploadErrorDTO> uploadErrors);
}

