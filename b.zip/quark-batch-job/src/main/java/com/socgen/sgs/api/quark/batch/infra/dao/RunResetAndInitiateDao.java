package com.socgen.sgs.api.quark.batch.infra.dao;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;

import java.util.List;

public interface RunResetAndInitiateDao {
    void resetRunsStatus();
    List<RunDomain> getRunsToBeInitiated();
}
