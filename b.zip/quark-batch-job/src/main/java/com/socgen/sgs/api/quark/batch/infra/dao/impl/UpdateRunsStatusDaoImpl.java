package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.infra.dao.UpdateRunsStatusDao;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.List;

@Repository
public class UpdateRunsStatusDaoImpl implements UpdateRunsStatusDao {
    private static final Logger logger = LoggerFactory.getLogger(UpdateRunsStatusDaoImpl.class);

    private final DataSource dataSource;

    @Autowired
    public UpdateRunsStatusDaoImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void updateRunsStatus(List<Integer> runIds) {
        if (runIds == null || runIds.isEmpty()) {
            logger.info("No run IDs provided for status update");
            return;
        }

        logger.info("Updating status for {} runs", runIds.size());

        try (Connection conn = dataSource.getConnection();
             CallableStatement cs = conn.prepareCall("{call QXP_PK_BATCH.UPDATE_RUNS_STATUS(?)}")) {

            OracleCallableStatement oraCs = cs.unwrap(OracleCallableStatement.class);

            // Convert List<Integer> to int[] for setPlsqlIndexTable
            int[] runIdArray = runIds.stream().mapToInt(Integer::intValue).toArray();

            // Use setPlsqlIndexTable for PL/SQL associative array (INDEX BY) types
            oraCs.setPlsqlIndexTable(1, runIdArray, runIdArray.length, runIdArray.length,
                    OracleTypes.NUMBER, 0);

            oraCs.execute();
            logger.info("Successfully updated status for {} runs", runIds.size());
        } catch (Exception e) {
            logger.error("Error updating runs status", e);
            throw new RuntimeException("Failed to update runs status", e);
        }
    }
}
