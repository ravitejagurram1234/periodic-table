package com.socgen.sgs.api.quark.batch.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreateRunUploadResultDTO {

    public static final int ERR_RUN_IN_EXECUTION = -1;  // Run déjà en exécution
    public static final int ERR_SUIVI_LOCKED = -2;      // Suivi locké => à ne pas générer

    private Integer result;

    public boolean isSuccess() {
        return result != null && result > 0;
    }

    public boolean isRunInExecution() {
        return result != null && result == ERR_RUN_IN_EXECUTION;
    }

    public boolean isSuiviLocked() {
        return result != null && result == ERR_SUIVI_LOCKED;
    }

    public Integer getRunId() {
        return isSuccess() ? result : null;
    }
}

