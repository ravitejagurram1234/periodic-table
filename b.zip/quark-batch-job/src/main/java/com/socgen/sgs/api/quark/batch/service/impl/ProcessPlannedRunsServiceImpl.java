package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.business.PlannedRunsBusiness;
import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.mapper.RunMapper;
import com.socgen.sgs.api.quark.batch.service.ProcessPlannedRunsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProcessPlannedRunsServiceImpl implements ProcessPlannedRunsService {

    private static final Logger logger = LoggerFactory.getLogger(ProcessPlannedRunsServiceImpl.class);

    private final PlannedRunsBusiness plannedRunsBusiness;
    private final RabbitMqProducer rabbitMqProducer;

    public ProcessPlannedRunsServiceImpl(PlannedRunsBusiness plannedRunsBusiness, RabbitMqProducer rabbitMqProducer) {
        this.plannedRunsBusiness = plannedRunsBusiness;
        this.rabbitMqProducer = rabbitMqProducer;
    }

    @Override
    public List<RunIdDto> processPlannedRuns() {
        List<RunIdDto> plannedRuns = getPlannedRuns();
        logger.info("Found {} planned runs to process", plannedRuns.size());

        if (!plannedRuns.isEmpty()) {
            rabbitMqProducer.sendRunIds(plannedRuns);
        }
        return plannedRuns;
    }

    public List<RunIdDto> getPlannedRuns() {
        List<RunDomain> plannedRuns = plannedRunsBusiness.getPlannedRuns();

        if (plannedRuns == null) {
            return List.of();
        }

        return plannedRuns.stream()
                .filter(run -> run != null && run.getRunId() != null)
                .map(RunMapper::toDto)
                .toList();
    }
}
