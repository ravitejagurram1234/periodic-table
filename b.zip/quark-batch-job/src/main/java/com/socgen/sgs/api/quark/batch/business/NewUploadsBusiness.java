package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.NewUploadDocumentsDao;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class NewUploadsBusiness {

    private final NewUploadDocumentsDao newUploadDocumentsDao;

    public NewUploadsBusiness(NewUploadDocumentsDao newUploadDocumentsDao) {
        this.newUploadDocumentsDao = newUploadDocumentsDao;
    }

    public List<UploadDocumentDomain> getNewUploadDocuments() {
        return newUploadDocumentsDao.getNewUploadDocuments();
    }
}
