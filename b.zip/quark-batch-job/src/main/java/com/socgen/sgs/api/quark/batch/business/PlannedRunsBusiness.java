package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.PlannedRunsDao;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class PlannedRunsBusiness {

    private final PlannedRunsDao plannedRunsDao;

    public PlannedRunsBusiness(PlannedRunsDao plannedRunsDao) {
        this.plannedRunsDao = plannedRunsDao;
    }

    public List<RunDomain> getPlannedRuns() {
        return plannedRunsDao.getPlannedRuns();
    }
}
