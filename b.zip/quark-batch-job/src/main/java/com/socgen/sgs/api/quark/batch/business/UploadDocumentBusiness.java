package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;
import com.socgen.sgs.api.quark.batch.dto.UploadDocumentDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.UploadDocumentDao;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class UploadDocumentBusiness {

    private final UploadDocumentDao uploadDocumentDao;

    public UploadDocumentBusiness(UploadDocumentDao uploadDocumentDao) {
        this.uploadDocumentDao = uploadDocumentDao;
    }

    public UploadDocumentDomain getUploadDocument(UploadDocumentDTO uploadId) {
        return uploadDocumentDao.getUploadDocument(uploadId);
    }
}
