package com.socgen.sgs.api.quark.batch.service.impl;

import com.socgen.sgs.api.quark.batch.config.RabbitMqConfig;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpIOException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service to send run IDs to RabbitMQ queue
 */
@Service
public class RabbitMqProducer {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqProducer.class);

    private final RabbitTemplate rabbitTemplate;

    public RabbitMqProducer(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    /**
     * Send run ID to the batch run queue
     * @param runId the run ID to send
     * @throws Exception if there is an error sending the message
     */
    public void sendRunId(Integer runId) throws Exception {
        logger.info("Sending run ID to queue: {}, runId: {}", RabbitMqConfig.getBatchRunQueue(), runId);
        rabbitTemplate.convertAndSend("", RabbitMqConfig.getBatchRunQueue(), runId);
        logger.info("Run ID sent successfully: {}", runId);
    }

    /**
     * Send a batch of run IDs to RabbitMQ, logging success/failure counts.
     * @param runs the list of run IDs to send
     */
    public void sendRunIds(List<RunIdDto> runs) {
        if (runs == null || runs.isEmpty()) {
            return;
        }
        int successCount = 0;
        int failureCount = 0;
        for (RunIdDto run : runs) {
            try {
                sendRunId(run.getRunId());
                successCount++;
            } catch (AmqpIOException e) {
                failureCount++;
                logger.error("AMQP I/O error for run ID {}: {}", run.getRunId(), e.getMessage(), e);
            } catch (Exception e) {
                failureCount++;
                logger.error("Failed to send run ID {} to RabbitMQ: {}", run.getRunId(), e.getMessage(), e);
            }
        }
        logger.info("RabbitMQ processing completed: {} successful, {} failed out of {} total runs",
                successCount, failureCount, runs.size());
    }
}

