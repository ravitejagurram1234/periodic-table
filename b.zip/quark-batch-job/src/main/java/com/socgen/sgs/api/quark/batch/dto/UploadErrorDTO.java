package com.socgen.sgs.api.quark.batch.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO for tracking upload errors to be updated in database
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UploadErrorDTO {
    private Integer uploadId;
    private String errorMessage;
}

