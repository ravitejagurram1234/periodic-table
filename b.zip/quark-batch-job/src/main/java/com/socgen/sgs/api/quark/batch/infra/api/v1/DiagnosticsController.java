package com.socgen.sgs.api.quark.batch.infra.api.v1;

import com.socgen.sgs.api.quark.batch.domain.DocumentIdentity;
import com.socgen.sgs.api.quark.batch.service.CheckUploadsService;
import com.socgen.sgs.api.quark.batch.service.DocumentPoolService;
import com.socgen.sgs.api.quark.batch.service.QuarkXPressServerXmlService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping(value = "api/v1/diagnostics")
@Tag(name = "Diagnostics Operations", description = "Operations for testing, debugging, and helpful utilities")
public class DiagnosticsController {

    private static final Logger logger = LoggerFactory.getLogger(DiagnosticsController.class);

    @Autowired
    private CheckUploadsService checkUploadsService;

    @Autowired
    private DocumentPoolService documentPoolService;

    @Autowired
    private QuarkXPressServerXmlService quarkXPressServerXmlService;

    @PostMapping(path = "/trigger")
    @Operation(summary = "Trigger check uploads", description = "Triggers the checkUploads process to find and process new uploads")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Check uploads process triggered successfully"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    public ResponseEntity<String> triggerCheckUploads() {
        logger.info("Triggering checkUploads process via REST endpoint");
        try {
            checkUploadsService.checkUploads();
            return ResponseEntity.ok("Check uploads process completed successfully");
        } catch (Exception e) {
            logger.error("Error during checkUploads execution", e);
            return ResponseEntity.internalServerError().body("Check uploads process failed: " + e.getMessage());
        }
    }

    @PostMapping(path = "/pool/add-file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Add file to QXPS document pool",
               description = "Uploads a document (up to 100MB) to the QuarkXPress Server document pool. The document name is derived from the original filename.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "File added to document pool successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request - file is empty or missing"),
            @ApiResponse(responseCode = "500", description = "Internal server error while adding file to pool")
    })
    public ResponseEntity<String> addFileToPool(@RequestParam("file") MultipartFile file,
                                                @RequestParam(value = "documentName", required = false) String documentName) {
        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest().body("File must not be empty");
        }
        String resolvedDocumentName = (documentName != null && !documentName.isBlank())
                ? documentName
                : file.getOriginalFilename();
        logger.info("Adding file to QXPS document pool. Document name: {}, Size: {} bytes", resolvedDocumentName, file.getSize());
        try {
            byte[] fileContent = file.getBytes();
            documentPoolService.addFileToPool(resolvedDocumentName, fileContent);
            logger.info("File successfully added to document pool. Document name: {}", resolvedDocumentName);
            return ResponseEntity.ok("File '" + resolvedDocumentName + "' added to document pool successfully");
        } catch (Exception e) {
            logger.error("Failed to add file to document pool. Document name: {}", resolvedDocumentName, e);
            return ResponseEntity.internalServerError().body("Failed to add file to document pool: " + e.getMessage());
        }
    }

    @GetMapping(path = "/pool/fetch-identity")
    @Operation(summary = "Fetch document identity from QXPS",
               description = "Fetches XML from the QuarkXPress Server document pool for the given document name and parses the DID box into DocumentIdentity fields.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Document identity retrieved successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request or missing DID in XML"),
            @ApiResponse(responseCode = "500", description = "Internal server error while fetching identity")
    })
    public ResponseEntity<?> fetchDocumentIdentity(@RequestParam("documentName") String documentName) {
        logger.info("Fetching document identity from QXPS. Document name: {}", documentName);
        try {
            String xmlContent = documentPoolService.fetchXmlForBox(documentName, "DID");
            if (xmlContent == null || xmlContent.isBlank()) {
                logger.error("Empty XML response from QXPS for document: {}", documentName);
                return ResponseEntity.badRequest().body("Empty XML response from QXPS for document: " + documentName);
            }
            logger.debug("XML content received for document '{}': length={}", documentName, xmlContent.length());

            String didValue = quarkXPressServerXmlService.getElementValueByIdName(xmlContent, "DID");
            if (didValue == null || didValue.isBlank()) {
                logger.error("DID not found in XML for document: {}", documentName);
                return ResponseEntity.badRequest().body("DID not found in XML for document: " + documentName);
            }

            DocumentIdentity identity = quarkXPressServerXmlService.parseDocumentIdentity(didValue);
            logger.info("Document identity successfully parsed for document: {}", documentName);
            return ResponseEntity.ok(identity);
        } catch (Exception e) {
            logger.error("Failed to fetch document identity for document: {}", documentName, e);
            return ResponseEntity.internalServerError().body("Failed to fetch document identity: " + e.getMessage());
        }
    }
}
