package com.socgen.sgs.api.quark.batch.infra.dao;

import com.socgen.sgs.api.quark.batch.domain.UploadDocumentDomain;

import java.util.List;

public interface NewUploadDocumentsDao {
    public List<UploadDocumentDomain> getNewUploadDocuments();
}
