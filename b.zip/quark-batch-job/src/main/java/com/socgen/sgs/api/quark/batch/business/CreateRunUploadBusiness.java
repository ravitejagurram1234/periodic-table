package com.socgen.sgs.api.quark.batch.business;

import com.socgen.sgs.api.quark.batch.dto.CreateRunUploadResultDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.CreateRunUploadDao;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class CreateRunUploadBusiness {

    private final CreateRunUploadDao createRunUploadDao;

    public CreateRunUploadBusiness(CreateRunUploadDao createRunUploadDao) {
        this.createRunUploadDao = createRunUploadDao;
    }

    public CreateRunUploadResultDTO createRunUpload(Integer idSuivi, Integer idQxpUpload) {
        return createRunUploadDao.createRunUpload(idSuivi, idQxpUpload);
    }
}

