package com.socgen.sgs.api.quark.batch.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RunIdDto {
    Integer runId;
}
