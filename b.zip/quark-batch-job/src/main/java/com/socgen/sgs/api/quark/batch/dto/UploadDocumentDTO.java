package com.socgen.sgs.api.quark.batch.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UploadDocumentDTO {
    Integer uploadId;
    byte[] contenu;
}
