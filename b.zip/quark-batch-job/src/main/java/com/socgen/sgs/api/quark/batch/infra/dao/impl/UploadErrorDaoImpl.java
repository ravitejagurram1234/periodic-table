package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.dto.UploadErrorDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.UploadErrorDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;

@Repository
public class UploadErrorDaoImpl implements UploadErrorDao {

    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public UploadErrorDaoImpl(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_BATCH")
                .withFunctionName("Update_Upload_With_Errors")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", Types.NUMERIC),
                        new SqlParameter("p_error_ids", Types.ARRAY, "NUMBER_ARRAY"),
                        new SqlParameter("p_error_msgs", Types.ARRAY, "VARCHAR_ARRAY")
                );
    }

    @Override
    public Integer updateUploadsWithErrors(List<UploadErrorDTO> uploadErrors) {
        if (uploadErrors == null || uploadErrors.isEmpty()) {
            return 0;
        }

        // Build arrays from upload errors
        Integer[] errorIds = new Integer[uploadErrors.size()];
        String[] errorMessages = new String[uploadErrors.size()];

        for (int i = 0; i < uploadErrors.size(); i++) {
            errorIds[i] = uploadErrors.get(i).getUploadId();
            errorMessages[i] = uploadErrors.get(i).getErrorMessage();
        }

        // Call the Oracle stored procedure
        return simpleJdbcCall.executeFunction(Integer.class, errorIds, errorMessages);
    }
}

