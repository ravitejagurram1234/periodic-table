package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.infra.dao.RunResetAndInitiateDao;
import com.socgen.sgs.api.quark.batch.mapper.RunMapper;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;

@Repository
public class RunResetAndInitiateDaoImpl implements RunResetAndInitiateDao {
    private final SimpleJdbcCall resetRunsStatusCall;
    private final SimpleJdbcCall getRunsInitialsCall;

    @Autowired
    public RunResetAndInitiateDaoImpl(DataSource dataSource) {
        // Reset_Runs_Status is a PROCEDURE - use withProcedureName
        this.resetRunsStatusCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_BATCH")
                .withProcedureName("Reset_Runs_Status")
                .withoutProcedureColumnMetaDataAccess();

        // Get_Runs_Initials is a FUNCTION that returns a cursor - same pattern as Get_Runs
        this.getRunsInitialsCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_BATCH")
                .withFunctionName("Get_Runs_Initials")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> RunMapper.mapResult(rs))
                );
    }

    @Override
    public void resetRunsStatus(){
        // Execute procedure (no return value)
        resetRunsStatusCall.execute();
    }

    @Override
    public List<RunDomain> getRunsToBeInitiated(){
        // Call the Oracle function and get the result as List directly (same as PlannedRunsDaoImpl)
        @SuppressWarnings("unchecked")
        List<RunDomain> runsToBeInitiated = getRunsInitialsCall.executeFunction(List.class);
        return runsToBeInitiated;
    }
}
