package com.socgen.sgs.api.quark.batch.business.impl;

import com.socgen.sgs.api.quark.batch.business.UploadErrorBusiness;
import com.socgen.sgs.api.quark.batch.dto.UploadErrorDTO;
import com.socgen.sgs.api.quark.batch.infra.dao.UploadErrorDao;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UploadErrorBusinessImpl implements UploadErrorBusiness {

    private final UploadErrorDao uploadErrorDao;

    public UploadErrorBusinessImpl(UploadErrorDao uploadErrorDao) {
        this.uploadErrorDao = uploadErrorDao;
    }

    @Override
    public Integer updateUploadsWithErrors(List<UploadErrorDTO> uploadErrors) {
        return uploadErrorDao.updateUploadsWithErrors(uploadErrors);
    }
}

