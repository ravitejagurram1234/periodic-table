package com.socgen.sgs.api.quark.batch.mapper;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RunMapper {
    public static RunDomain mapResult(ResultSet rs) throws SQLException {
        RunDomain runDomain = new RunDomain();
        runDomain.setRunId(rs.getInt("id_run"));
        return runDomain;
    }

    public static RunIdDto toDto(RunDomain domain) {
        return new RunIdDto(domain.getRunId());
    }
}