package com.socgen.sgs.api.quark.batch.infra.interop.qxps;

import com.socgen.sgs.api.quark.batch.config.QuarkXPressServerProperties;
import com.socgen.sgs.api.quark.batch.exception.QuarkXPressServerException;
import com.socgen.sgs.api.quark.batch.service.DocumentPoolService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.core.io.ByteArrayResource;

/**
 * Service to interact with QuarkXPress Server document pool.
 * Handles adding files (POST /addfile/Upload/doc.qxp) and
 * fetching XML/DID (GET /xml/Upload/doc.qxp?box=DID).
 */
@Service
public class QxpsDocumentPoolService implements DocumentPoolService {

    private static final Logger logger = LoggerFactory.getLogger(QxpsDocumentPoolService.class);

    private final RestTemplate restTemplate;
    private final QuarkXPressServerProperties serverProperties;

    public QxpsDocumentPoolService(RestTemplate restTemplate, QuarkXPressServerProperties serverProperties) {
        this.restTemplate = restTemplate;
        this.serverProperties = serverProperties;
    }

    /**
     * Adds a file to the QuarkXPress Server document pool.
     * POST http://host:port/addfile/Upload/{documentName}
     */
    @Override
    public void addFileToPool(String documentName, byte[] fileContent) {
        String url = String.format("%s:%d/addfile/%s/%s",
                serverProperties.getBaseUrl(),
                serverProperties.getPort(),
                serverProperties.getUploadDirectory(),
                documentName);

        logger.info("Adding file to QXPS document pool: {}", url);

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            ByteArrayResource resource = new ByteArrayResource(fileContent) {
                @Override
                public String getFilename() {
                    return "fileData.bin";
                }
            };

            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            body.add("file", resource);

            HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);

            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new QuarkXPressServerException(
                        String.format("Failed to add file to pool. HTTP %d, URL: %s", response.getStatusCode().value(), url));
            }

            logger.info("File added to QXPS document pool: {}", documentName);
        } catch (QuarkXPressServerException e) {
            throw e;
        } catch (Exception e) {
            throw new QuarkXPressServerException("Failed to add file to QXPS document pool: " + documentName, e);
        }
    }

    /**
     * Fetches XML content for a specific box from a document in the pool.
     * GET http://host:port/xml/Upload/{documentName}?box={boxName}
     */
    @Override
    public String fetchXmlForBox(String documentName, String boxName) {
        String url = String.format("%s:%d/xml/%s/%s?box=%s",
                serverProperties.getBaseUrl(),
                serverProperties.getPort(),
                serverProperties.getUploadDirectory(),
                documentName,
                boxName);

        logger.info("Fetching XML from QXPS: {}", url);

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Accept", "application/xml");
            HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);

            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new QuarkXPressServerException(
                        String.format("Failed to fetch XML. HTTP %d, URL: %s", response.getStatusCode().value(), url));
            }

            return response.getBody();
        } catch (QuarkXPressServerException e) {
            throw e;
        } catch (Exception e) {
            throw new QuarkXPressServerException("Failed to fetch XML from QXPS for: " + documentName, e);
        }
    }

    /**
     * Fetches full XML content for a document (no box filter).
     * GET http://host:port/xml/Upload/{documentName}
     */
    public String fetchFullXml(String documentName) {
        String url = String.format("%s:%d/xml/%s/%s",
                serverProperties.getBaseUrl(),
                serverProperties.getPort(),
                serverProperties.getUploadDirectory(),
                documentName);

        logger.info("Fetching full XML from QXPS: {}", url);

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("Accept", "application/xml");
            HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);

            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new QuarkXPressServerException(
                        String.format("Failed to fetch XML. HTTP %d, URL: %s", response.getStatusCode().value(), url));
            }

            return response.getBody();
        } catch (QuarkXPressServerException e) {
            throw e;
        } catch (Exception e) {
            throw new QuarkXPressServerException("Failed to fetch full XML from QXPS for: " + documentName, e);
        }
    }

    /**
     * Deletes a file from the QuarkXPress Server document pool.
     * POST http://host:port/delete/Upload/{documentName}
     */
    public void deleteFileFromPool(String documentName) {
        String url = String.format("%s:%d/delete/%s/%s",
                serverProperties.getBaseUrl(),
                serverProperties.getPort(),
                serverProperties.getUploadDirectory(),
                documentName);

        logger.info("Deleting file from QXPS document pool: {}", url);

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);

            if (!response.getStatusCode().is2xxSuccessful()) {
                throw new QuarkXPressServerException(
                        String.format("Failed to delete file. HTTP %d, URL: %s", response.getStatusCode().value(), url));
            }

            logger.info("File deleted from QXPS document pool: {}", documentName);
        } catch (QuarkXPressServerException e) {
            throw e;
        } catch (Exception e) {
            throw new QuarkXPressServerException("Failed to delete file from QXPS pool: " + documentName, e);
        }
    }
}

