package com.socgen.sgs.api.quark.batch.scheduler;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.service.ReInitiatePendingRunsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.util.List;

/**
 * Scheduled job to re-initiate pending runs daily at midnight.
 */
@Component
public class ReInitiatePendingRunsScheduler {
    private static final Logger logger = LoggerFactory.getLogger(ReInitiatePendingRunsScheduler.class);

    private final ReInitiatePendingRunsService reInitiatePendingRunsService;

    public ReInitiatePendingRunsScheduler(ReInitiatePendingRunsService reInitiatePendingRunsService) {
        this.reInitiatePendingRunsService = reInitiatePendingRunsService;
    }

    @Scheduled(cron = "${scheduler.re-initiate-pending-runs.cron}")
    public void reInitiatePendingRuns() {
        try {
            List<RunIdDto> runs = reInitiatePendingRunsService.reInitiatePendingRuns();
            logger.info("Scheduled job ReInitiatePendingRuns completed. Processed {} runs", runs != null ? runs.size() : 0);
        } catch (Exception e) {
            logger.error("Error occurred during scheduled ReInitiatePendingRuns job", e);
        }
    }
}
