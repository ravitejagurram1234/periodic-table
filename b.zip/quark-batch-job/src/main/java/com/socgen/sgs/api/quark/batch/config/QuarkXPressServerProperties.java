package com.socgen.sgs.api.quark.batch.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Configuration
@ConfigurationProperties(prefix = "quarkxpress.server")
@Validated
@Getter
@Setter
public class QuarkXPressServerProperties {

    @NotBlank(message = "QuarkXPress server base URL is required")
    private String baseUrl;

    @NotNull(message = "QuarkXPress server port is required")
    private Integer port;

    @NotBlank(message = "QuarkXPress server upload directory is required")
    private String uploadDirectory;

    /**
     * Returns the full base URL including port
     * @return full base URL (e.g., http://srvcldqxpu001.dns43.socgen:8080)
     */
    public String getFullBaseUrl() {
        return baseUrl + ":" + port;
    }
}

