package com.socgen.sgs.api.quark.batch.service;

public interface S3UploadService {
    String uploadDocument(Integer uploadId, byte[] content);
}

