package com.socgen.sgs.api.quark.batch.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UploadDocumentDomain {
    Integer uploadId;
    byte[] contenu;
}
