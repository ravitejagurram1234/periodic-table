package com.socgen.sgs.api.quark.batch.scheduler;

import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.service.ProcessPlannedRunsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Scheduled job to process planned runs daily.
 * This job runs once per day at midnight (00:00:00).
 */
@Component
public class ProcessPlannedRunsScheduler {

    private static final Logger logger = LoggerFactory.getLogger(ProcessPlannedRunsScheduler.class);

    private final ProcessPlannedRunsService processPlannedRunsService;

    public ProcessPlannedRunsScheduler(ProcessPlannedRunsService processPlannedRunsService) {
        this.processPlannedRunsService = processPlannedRunsService;
    }

    /**
     * Scheduled method to process planned runs daily.
     * The cron expression is configured in application.yaml under scheduler.planned-runs.cron
     * Default: "0 0 0 * * ?" - Runs at 00:00:00 (midnight) every day
     * Cron format: second minute hour day month weekday
     */
    @Scheduled(cron = "${scheduler.planned-runs.cron}")
    public void processPlannedRuns() {
        try {
            List<RunIdDto> processedRuns = processPlannedRunsService.processPlannedRuns();
            logger.info("Scheduled job completed successfully. Processed {} runs",
                processedRuns != null ? processedRuns.size() : 0);
        } catch (Exception e) {
            logger.error("Error occurred while processing planned runs in scheduled job", e);
        }
    }
}

