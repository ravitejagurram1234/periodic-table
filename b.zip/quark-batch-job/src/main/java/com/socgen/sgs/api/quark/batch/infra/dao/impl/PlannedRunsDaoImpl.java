package com.socgen.sgs.api.quark.batch.infra.dao.impl;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;
import com.socgen.sgs.api.quark.batch.dto.RunIdDto;
import com.socgen.sgs.api.quark.batch.infra.dao.PlannedRunsDao;
import com.socgen.sgs.api.quark.batch.mapper.RunMapper;
import com.socgen.sgs.api.quark.batch.mapper.UploadDocumentMapper;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;

@Repository
public class PlannedRunsDaoImpl implements PlannedRunsDao {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public PlannedRunsDaoImpl(DataSource dataSource) {
        this.simpleJdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_BATCH")
                .withFunctionName("Get_Runs")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("RETURN_VALUE", OracleTypes.CURSOR, (rs, rowNum) -> RunMapper.mapResult(rs))
                );
    }

    @Override
    public List<RunDomain> getPlannedRuns() {
        // Call the Oracle function and get the result as List directly
        @SuppressWarnings("unchecked")
        List<RunDomain> plannedRuns = simpleJdbcCall.executeFunction(List.class);
        return plannedRuns;
    }
}
