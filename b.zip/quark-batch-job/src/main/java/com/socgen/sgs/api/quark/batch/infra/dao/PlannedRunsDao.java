package com.socgen.sgs.api.quark.batch.infra.dao;

import com.socgen.sgs.api.quark.batch.domain.RunDomain;

import java.util.List;

public interface PlannedRunsDao {
    public List<RunDomain> getPlannedRuns();
}
