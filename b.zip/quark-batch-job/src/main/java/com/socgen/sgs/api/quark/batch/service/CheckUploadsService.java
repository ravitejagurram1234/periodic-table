package com.socgen.sgs.api.quark.batch.service;

import com.socgen.sgs.api.quark.batch.dto.RunIdDto;

import java.util.List;

public interface CheckUploadsService {
    List<RunIdDto> checkUploads();
}
