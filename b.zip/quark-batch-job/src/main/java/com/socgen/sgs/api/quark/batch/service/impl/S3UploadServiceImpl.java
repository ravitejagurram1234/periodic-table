package com.socgen.sgs.api.quark.batch.service.impl;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.socgen.sgs.api.quark.batch.config.S3Properties;
import com.socgen.sgs.api.quark.batch.service.S3UploadService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.io.ByteArrayInputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

@Service
public class S3UploadServiceImpl implements S3UploadService {

    private static final Logger logger = LoggerFactory.getLogger(S3UploadServiceImpl.class);
    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private final S3Properties s3Properties;
    private AmazonS3 s3Client;

    public S3UploadServiceImpl(S3Properties s3Properties) {
        this.s3Properties = Objects.requireNonNull(s3Properties, "S3 properties must not be null");
    }

    @PostConstruct
    public void initializeS3Client() {
        BasicAWSCredentials credentials = new BasicAWSCredentials(
                s3Properties.getAccessKey(),
                s3Properties.getSecretKey()
        );

        this.s3Client = AmazonS3ClientBuilder.standard()
                .withEndpointConfiguration(
                        new AwsClientBuilder.EndpointConfiguration(
                                s3Properties.getEndpoint(),
                                "eu-west-1"
                        )
                )
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withPathStyleAccessEnabled(true)
                .build();

        logger.info("S3 client initialized. Endpoint: {}, Bucket: {}",
                s3Properties.getEndpoint(), s3Properties.getBucket().getName());
    }

    @Override
    public String uploadDocument(Integer uploadId, byte[] content) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        String s3Key = String.format("uploads/%d_%s.qxp", uploadId, timestamp);
        String bucketName = s3Properties.getBucket().getName();

        logger.info("Uploading document to S3. Upload ID: {}, S3 Key: {}, Size: {} bytes",
                uploadId, s3Key, content.length);

        try {
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(content.length);

            s3Client.putObject(
                    bucketName,
                    s3Key,
                    new ByteArrayInputStream(content),
                    metadata
            );

            logger.info("Successfully uploaded to S3. Upload ID: {}, S3 Key: {}", uploadId, s3Key);
            return s3Key;

        } catch (AmazonServiceException e) {
            String errorMsg = String.format(
                    "S3 service error uploading document. Upload ID: %d, S3 Key: %s, Error: %s",
                    uploadId, s3Key, e.getErrorMessage());
            logger.error(errorMsg, e);
            throw new RuntimeException(errorMsg, e);
        } catch (SdkClientException e) {
            String errorMsg = String.format(
                    "S3 client error uploading document. Upload ID: %d, S3 Key: %s",
                    uploadId, s3Key);
            logger.error(errorMsg, e);
            throw new RuntimeException(errorMsg, e);
        }
    }
}

