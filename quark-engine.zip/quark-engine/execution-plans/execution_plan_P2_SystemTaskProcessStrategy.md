# Execution Plan: SystemTaskProcessStrategy

## 1. CURRENT CODE ANALYSIS

**File:** `C:\Users\rgurram062722\Documents\GitHub\gallery-qxp\QXP\QXP.Engine.Core\Business\Task\Process_System.cs`  
**Lines:** 1–84 (entire file)

```csharp
// Lines 39-76: The Process method
public static void Process(Task_System task)
{
    Bloc_Box __bloc;

    //Checks Task
    if (QXPFrk.Validation.IsNotSet(task.DestinationBlocName))          // Line 44
    {
        task.Run.Errors.Add(Constantes.Error_Messages.MissingBlocNameInTask, task.Debug_Info);
        return;                                                         // Line 47
    }

    //C'est une tache system Box (mise à jour d'une Box (contenu/position etc)
    if(QXPFrk.Validation.IsSet(task.TBox))                             // Line 52
    {
        task.Sub_Task_Type = Sub_Task_Type.Box;                         // Line 54

        __bloc = new Bloc_Box(task, task.TBox.SrcBox.name, task.TBox);  // Line 56

        //Indique un deplacement de bloc
        __bloc.Action     = task.TBox_Action;                           // Line 59
        __bloc.Pagination = task.TBox_Pagination;                       // Line 60
        task.Blocs_Modify.Add(__bloc.Name, __bloc);                     // Line 61
    }
    //C'est une tache system valeur (mise à jour de la valeur d'un bloc)
    else                                                                // Line 65
    {
        task.Sub_Task_Type = Sub_Task_Type.Value;                       // Line 68

        Data_Type_Helper __data_Type_Helper = new Data_Type_Helper(task.Run.Properties);  // Line 70

        __bloc = new Bloc_Box(task, task.DestinationBlocName,
            __data_Type_Helper.OutputToString(task.Value, task.Data_Type, task.NbDecimal,
                task.ShowZero, task.NullString, task.Decimal_Significative));  // Line 72
        task.Blocs_Update.Add(__bloc.Name, __bloc);                     // Line 73
    }
}
```

**Supporting .NET class:** `Task_System.cs` (Lines 1–178)  
Key properties: `TBox`, `TBox_Action` (Bloc_Action), `TBox_Pagination` (bool), `Value` (object), `Data_Type`, `NbDecimal`, `ShowZero`, `Decimal_Significative`, `DestinationBlocName`, `NullString`

---

## 2. MAPPED BEHAVIOR TO JAVA

| # | .NET Behavior (Line) | Java Implementation |
|---|---|---|
| 1 | Line 44: `IsNotSet(task.DestinationBlocName)` → error + return | `if (task.getDestinationBlocName() == null \|\| task.getDestinationBlocName().isBlank())` → log error + return |
| 2 | Line 52: `IsSet(task.TBox)` → Box mode | `if (task has TBox set)` → Box mode. **NOTE:** Java `TaskSystem` currently has NO TBox field — needs to be added or this mode deferred (see Section 5) |
| 3 | Line 54: `task.Sub_Task_Type = Sub_Task_Type.Box` | `task.setSubTaskType(SubTaskTypeEnum.BOX)` |
| 4 | Line 56: `new Bloc_Box(task, task.TBox.SrcBox.name, task.TBox)` | `new BlocBox(task, srcBoxName, srcBox, srcExtraBox)` using the Box constructor |
| 5 | Line 59-60: set Action and Pagination on bloc | `bloc.setAction(task.getAction())` and `bloc.setPagination(task.isPagination())` |
| 6 | Line 61: `task.Blocs_Modify.Add(...)` | `task.getBlocsModify().put(bloc.getName(), bloc)` |
| 7 | Line 68: `task.Sub_Task_Type = Sub_Task_Type.Value` | `task.setSubTaskType(SubTaskTypeEnum.VALUE)` |
| 8 | Line 70-72: `Data_Type_Helper.OutputToString(...)` | `DataTypeHelper.outputToString(task.getValue(), task.getDataType(), task.getNbDecimal(), task.isShowZero(), task.getNullString(), task.isDecimalSignificative())` |
| 9 | Line 73: `task.Blocs_Update.Add(...)` | `task.getBlocsUpdate().put(bloc.getName(), bloc)` |

---

## 3. CLASS DESIGN

- **Package:** `com.socgen.sgs.api.quark.engine.service.task.impl`
- **Class name:** `SystemTaskProcessStrategy`
- **Implements:** `TaskProcessStrategy<TaskSystem>`
- **Annotations:** `@Component`, `@Slf4j`
- **Dependencies to inject:** None (all logic is self-contained using domain objects and static helper)
- **Methods:**
  - `Class<TaskSystem> getTaskType()` — returns `TaskSystem.class`
  - `void process(TaskSystem task)` — main processing logic

---

## 4. MODE 1: VALUE MODE LOGIC

### .NET Code (Lines 65–74):
```csharp
else
{
    task.Sub_Task_Type = Sub_Task_Type.Value;
    Data_Type_Helper __data_Type_Helper = new Data_Type_Helper(task.Run.Properties);
    __bloc = new Bloc_Box(task, task.DestinationBlocName,
        __data_Type_Helper.OutputToString(task.Value, task.Data_Type, task.NbDecimal,
            task.ShowZero, task.NullString, task.Decimal_Significative));
    task.Blocs_Update.Add(__bloc.Name, __bloc);
}
```

### Java Implementation:
1. **Condition:** TBox is NOT set (null) → value mode
2. **Set sub-task type:** `task.setSubTaskType(SubTaskTypeEnum.VALUE)`
3. **Format value:** Call `DataTypeHelper.outputToString(task.getValue(), task.getDataType(), task.getNbDecimal(), task.isShowZero(), task.getNullString(), task.isDecimalSignificative())`
4. **Create BlocBox:** `new BlocBox(task, task.getDestinationBlocName(), formattedValue)`
5. **Store:** `task.getBlocsUpdate().put(bloc.getName(), bloc)`

**Note:** Java `DataTypeHelper` is static and does NOT take `RunProperties` as constructor arg (unlike .NET). The static `outputToString` method already exists with the correct signature.

---

## 5. MODE 2: BOX MODE LOGIC

### .NET Code (Lines 52–62):
```csharp
if(QXPFrk.Validation.IsSet(task.TBox))
{
    task.Sub_Task_Type = Sub_Task_Type.Box;
    __bloc = new Bloc_Box(task, task.TBox.SrcBox.name, task.TBox);
    __bloc.Action     = task.TBox_Action;
    __bloc.Pagination = task.TBox_Pagination;
    task.Blocs_Modify.Add(__bloc.Name, __bloc);
}
```

### Java Implementation:

**IMPORTANT PREREQUISITE:** The Java `TaskSystem` class currently does NOT have a TBox-equivalent field. We need to add fields to `TaskSystem.java`:
- `private Box tBoxSrcBox;` — the source box reference
- `private Box tBoxSrcExtraBox;` — optional extra box

OR a wrapper class. For now, we can use the existing `BlocBox(task, name, srcBox, srcExtraBox)` constructor.

**Steps:**
1. **Condition:** `task.getTBoxSrcBox() != null` → box mode
2. **Set sub-task type:** `task.setSubTaskType(SubTaskTypeEnum.BOX)`
3. **Create BlocBox:** `new BlocBox(task, task.getTBoxSrcBox().getName(), task.getTBoxSrcBox(), task.getTBoxSrcExtraBox())`
4. **Set action:** `bloc.setAction(task.getAction())`
5. **Set pagination:** `bloc.setPagination(task.isPagination())`
6. **Store:** `task.getBlocsModify().put(bloc.getName(), bloc)`

**Fields to add to `TaskSystem.java`:**
```java
private Box tBoxSrcBox;       // maps to .NET task.TBox.SrcBox
private Box tBoxSrcExtraBox;  // maps to .NET task.TBox extra box (if applicable)
```

---

## 6. ERROR HANDLING

### From .NET Code (Lines 44–48):
```csharp
if (QXPFrk.Validation.IsNotSet(task.DestinationBlocName))
{
    task.Run.Errors.Add(Constantes.Error_Messages.MissingBlocNameInTask, task.Debug_Info);
    return;
}
```

### Java Implementation:
- **If destinationBlocName is null or blank:** Log a warning with task debug info and **return early** (do not throw exception)
- **Execution continues** for other tasks; this task is simply skipped
- **If source bloc not found (box mode):** Log warning and return (defensive null check on `tBoxSrcBox`)
- **Logging:** Use `log.warn("Missing destinationBlocName for task [{}]", task.getId())`

---

## 7. CROSS-REFERENCE CHECKLIST

- [x] Value mode checks if TBox is null (line 52 inverted: `IsSet(task.TBox)` means box mode; else = value mode)
- [x] Value mode calls `DataTypeHelper.outputToString()` (line 72 in .NET → static call in Java)
- [x] Value mode stores in `blocsUpdate` with implicit action (no explicit action set in value mode in .NET)
- [x] Box mode uses TBox source box name as bloc name (line 56: `task.TBox.SrcBox.name`)
- [x] Box mode creates BlocBox with TBox reference (line 56)
- [x] Box mode stores in `blocsModify` with action from `task.TBox_Action` (line 59, 61)
- [x] Logging shows which mode was used (via `log.debug`)
- [x] Null check on `destinationBlocName` prevents exceptions (line 44–47)

---

## 8. .NET CODE REFERENCES

| File | Lines | Key Methods/Properties |
|------|-------|----------------------|
| `gallery-qxp\QXP\QXP.Engine.Core\Business\Task\Process_System.cs` | 1–84 | `Process(Task_System task)` |
| `gallery-qxp\QXP\QXP.Engine.Core\BusinessObject\Run\Task\Task_System.cs` | 1–178 | `TBox`, `TBox_Action`, `TBox_Pagination`, `Value`, `Data_Type`, `NbDecimal`, `ShowZero`, `Decimal_Significative`, `DestinationBlocName`, `NullString`, `Process()` |

---

## 9. IMPLEMENTATION NOTES

### Files to Create:
1. `src/main/java/com/socgen/sgs/api/quark/engine/service/task/impl/SystemTaskProcessStrategy.java`

### Files to Modify:
1. `src/main/java/com/socgen/sgs/api/quark/engine/domain/task/TaskSystem.java` — add `tBoxSrcBox` and `tBoxSrcExtraBox` fields (Box type from SOAP generated classes)

### Existing Classes Used:
- `DataTypeHelper` (static, already exists at `domain.helper.DataTypeHelper`)
- `BlocBox` (already exists at `domain.bloc.BlocBox`)
- `TaskBase.blocsUpdate` / `TaskBase.blocsModify` (already exist as `Map<String, BlocBase>`)
- `SubTaskTypeEnum` (needs `BOX` and `VALUE` values — verify existence)
- `BlocActionEnum` (already exists with NONE, UPDATE, CREATE, REMOVE, MOVE)
- `BlocBase.action` and `BlocBase.pagination` fields (verify `pagination` exists on BlocBase)

### Pre-Implementation Verification Needed:
1. Confirm `SubTaskTypeEnum` has `BOX` and `VALUE` values
2. Confirm `BlocBase` has `setPagination(boolean)` method
3. Confirm `Box` class has a `getName()` or `name` field (from SOAP generated code)

