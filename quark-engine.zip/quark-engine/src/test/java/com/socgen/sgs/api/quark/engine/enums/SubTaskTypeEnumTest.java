package com.socgen.sgs.api.quark.engine.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("SubTaskTypeEnum Tests")
class SubTaskTypeEnumTest {

    @Test
    @DisplayName("Should have all enum values")
    void shouldHaveAllEnumValues() {
        assertTrue(SubTaskTypeEnum.values().length > 0);
    }

    @Test
    @DisplayName("Should convert valid name")
    void shouldConvertValidName() {
        assertEquals(SubTaskTypeEnum.VALUE, SubTaskTypeEnum.fromName("VALUE"));
        assertEquals(SubTaskTypeEnum.SQL, SubTaskTypeEnum.fromName("SQL"));
    }

    @Test
    @DisplayName("Should handle case-insensitive conversion")
    void shouldHandleCaseInsensitiveConversion() {
        assertEquals(SubTaskTypeEnum.VALUE, SubTaskTypeEnum.fromName("value"));
    }

    @Test
    @DisplayName("Should return UNKNOWN for invalid")
    void shouldReturnUnknownForInvalid() {
        assertEquals(SubTaskTypeEnum.UNKNOWN, SubTaskTypeEnum.fromName("INVALID"));
        assertEquals(SubTaskTypeEnum.UNKNOWN, SubTaskTypeEnum.fromName(null));
    }
}

