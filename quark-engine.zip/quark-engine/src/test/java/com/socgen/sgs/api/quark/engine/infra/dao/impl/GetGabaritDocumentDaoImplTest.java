package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDocumentDao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.util.ReflectionTestUtils;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("GetGabaritDocumentDaoImpl Tests")
class GetGabaritDocumentDaoImplTest {

    @Mock
    private DataSource dataSource;

    @Mock
    private SimpleJdbcCall simpleJdbcCall;

    private GetGabaritDocumentDao dao;

    @BeforeEach
    void setUp() {
        dao = new GetGabaritDocumentDaoImpl(dataSource);
        ReflectionTestUtils.setField(dao, "getGabaritDocumentCall", simpleJdbcCall);
    }

    @Test
    @DisplayName("Should return first DocumentDomain from cursor")
    void shouldReturnDocumentDomain() {
        DocumentDomain doc = new DocumentDomain();
        doc.setId(10);
        doc.setName("GabaritDoc");

        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of(doc));
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        DocumentDomain returned = dao.getGabaritDocument(200);

        assertNotNull(returned);
        assertEquals(10, returned.getId());
        assertEquals("GabaritDoc", returned.getName());
    }

    @Test
    @DisplayName("Should throw IllegalArgumentException when cursor returns empty list")
    void shouldThrowWhenEmpty() {
        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of());
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        assertThrows(IllegalArgumentException.class, () -> dao.getGabaritDocument(200));
    }

    @Test
    @DisplayName("Should throw IllegalArgumentException when cursor value is null")
    void shouldThrowWhenCursorNull() {
        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", null);
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        assertThrows(IllegalArgumentException.class, () -> dao.getGabaritDocument(200));
    }

    @Test
    @DisplayName("Should wrap unexpected exceptions in RuntimeException")
    void shouldWrapRuntimeException() {
        when(simpleJdbcCall.execute(any(SqlParameterSource.class)))
                .thenThrow(new RuntimeException("db error"));

        assertThrows(RuntimeException.class, () -> dao.getGabaritDocument(200));
    }
}
