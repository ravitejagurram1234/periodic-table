package com.socgen.sgs.api.quark.engine.domain.task;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TaskImagePosition Tests")
class TaskImagePositionTest {

    @Test
    @DisplayName("Should create TaskImagePosition with valid values")
    void shouldCreateTaskImagePositionWithValidValues() {
        TaskImagePosition position = new TaskImagePosition("100;200;300;400");

        assertEquals("100", position.getLeft());
        assertEquals("200", position.getTop());
        assertEquals("300", position.getRight());
        assertEquals("400", position.getBottom());
    }

    @Test
    @DisplayName("Should use default values when not exactly 4 values provided")
    void shouldUseDefaultValuesWhenNotExactly4Values() {
        TaskImagePosition position = new TaskImagePosition("100;200;300");

        String[] defaults = TaskImagePosition.DEFAULT_IMAGE_POSITION_VALUES.split(";");
        assertEquals(defaults[0], position.getLeft());
        assertEquals(defaults[1], position.getTop());
        assertEquals(defaults[2], position.getRight());
        assertEquals(defaults[3], position.getBottom());
    }

    @Test
    @DisplayName("Should use default values when null is provided")
    void shouldUseDefaultValuesWhenNullProvided() {
        TaskImagePosition position = new TaskImagePosition(null);

        String[] defaults = TaskImagePosition.DEFAULT_IMAGE_POSITION_VALUES.split(";");
        assertEquals(defaults[0], position.getLeft());
        assertEquals(defaults[1], position.getTop());
        assertEquals(defaults[2], position.getRight());
        assertEquals(defaults[3], position.getBottom());
    }

    @Test
    @DisplayName("Should use default values when empty string provided")
    void shouldUseDefaultValuesWhenEmptyStringProvided() {
        TaskImagePosition position = new TaskImagePosition("");

        String[] defaults = TaskImagePosition.DEFAULT_IMAGE_POSITION_VALUES.split(";");
        assertEquals(defaults[0], position.getLeft());
        assertEquals(defaults[1], position.getTop());
        assertEquals(defaults[2], position.getRight());
        assertEquals(defaults[3], position.getBottom());
    }

    @Test
    @DisplayName("Should use default values when too many values provided")
    void shouldUseDefaultValuesWhenTooManyValuesProvided() {
        TaskImagePosition position = new TaskImagePosition("1;2;3;4;5;6");

        String[] defaults = TaskImagePosition.DEFAULT_IMAGE_POSITION_VALUES.split(";");
        assertEquals(defaults[0], position.getLeft());
        assertEquals(defaults[1], position.getTop());
        assertEquals(defaults[2], position.getRight());
        assertEquals(defaults[3], position.getBottom());
    }

    @Test
    @DisplayName("Should have correct default constant")
    void shouldHaveCorrectDefaultConstant() {
        assertEquals("42,52;56,693;552,756;785,197", TaskImagePosition.DEFAULT_IMAGE_POSITION_VALUES);
    }

    @Test
    @DisplayName("Should handle single value - use default")
    void shouldHandleSingleValue() {
        TaskImagePosition position = new TaskImagePosition("100");

        String[] defaults = TaskImagePosition.DEFAULT_IMAGE_POSITION_VALUES.split(";");
        assertEquals(defaults[0], position.getLeft());
        assertEquals(defaults[1], position.getTop());
        assertEquals(defaults[2], position.getRight());
        assertEquals(defaults[3], position.getBottom());
    }

    @Test
    @DisplayName("Should handle two values - use default")
    void shouldHandleTwoValues() {
        TaskImagePosition position = new TaskImagePosition("100;200");

        String[] defaults = TaskImagePosition.DEFAULT_IMAGE_POSITION_VALUES.split(";");
        assertEquals(defaults[0], position.getLeft());
        assertEquals(defaults[1], position.getTop());
        assertEquals(defaults[2], position.getRight());
        assertEquals(defaults[3], position.getBottom());
    }

    @Test
    @DisplayName("Should handle numeric position values")
    void shouldHandleNumericPositionValues() {
        TaskImagePosition position = new TaskImagePosition("10,5;20,10;30,15;40,20");

        assertEquals("10,5", position.getLeft());
        assertEquals("20,10", position.getTop());
        assertEquals("30,15", position.getRight());
        assertEquals("40,20", position.getBottom());
    }

    @Test
    @DisplayName("Should handle floating point position values")
    void shouldHandleFloatingPointPositionValues() {
        TaskImagePosition position = new TaskImagePosition("10.5;20.5;30.5;40.5");

        assertEquals("10.5", position.getLeft());
        assertEquals("20.5", position.getTop());
        assertEquals("30.5", position.getRight());
        assertEquals("40.5", position.getBottom());
    }

    @Test
    @DisplayName("Should be read-only - no setters for position values")
    void shouldBeReadOnly() {
        TaskImagePosition position = new TaskImagePosition("100;200;300;400");

        assertEquals("100", position.getLeft());
        assertEquals("200", position.getTop());
        assertEquals("300", position.getRight());
        assertEquals("400", position.getBottom());
    }

    @Test
    @DisplayName("Should handle default case consistently")
    void shouldHandleDefaultCaseConsistently() {
        TaskImagePosition pos1 = new TaskImagePosition(null);
        TaskImagePosition pos2 = new TaskImagePosition("");
        TaskImagePosition pos3 = new TaskImagePosition("invalid");

        assertEquals(pos1.getLeft(), pos2.getLeft());
        assertEquals(pos2.getLeft(), pos3.getLeft());
    }
}
