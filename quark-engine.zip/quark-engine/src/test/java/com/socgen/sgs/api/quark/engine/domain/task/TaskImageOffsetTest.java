package com.socgen.sgs.api.quark.engine.domain.task;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TaskImageOffset Tests")
class TaskImageOffsetTest {

    @Test
    @DisplayName("Should create TaskImageOffset with pipe-separated values")
    void shouldCreateTaskImageOffsetWithPipeSeparatedValues() {
        TaskImageOffset offset = new TaskImageOffset("100|130|150");

        assertEquals("100", offset.getOffset(0));
        assertEquals("130", offset.getOffset(1));
        assertEquals("150", offset.getOffset(2));
    }

    @Test
    @DisplayName("Should return empty string when no values")
    void shouldReturnEmptyStringWhenNoValues() {
        TaskImageOffset offset = new TaskImageOffset(null);

        assertEquals("", offset.getOffset(0));
        assertEquals("", offset.getOffset(1));
    }

    @Test
    @DisplayName("Should return last value for index beyond array bounds")
    void shouldReturnLastValueForIndexBeyondArrayBounds() {
        TaskImageOffset offset = new TaskImageOffset("100|130|150");

        assertEquals("150", offset.getOffset(10));
        assertEquals("150", offset.getOffset(100));
    }

    @Test
    @DisplayName("Should handle single value")
    void shouldHandleSingleValue() {
        TaskImageOffset offset = new TaskImageOffset("200");

        assertEquals("200", offset.getOffset(0));
        assertEquals("200", offset.getOffset(1));
        assertEquals("200", offset.getOffset(10));
    }

    @Test
    @DisplayName("Should handle two values")
    void shouldHandleTwoValues() {
        TaskImageOffset offset = new TaskImageOffset("100|200");

        assertEquals("100", offset.getOffset(0));
        assertEquals("200", offset.getOffset(1));
        assertEquals("200", offset.getOffset(5));
    }

    @Test
    @DisplayName("Should handle many values")
    void shouldHandleManyValues() {
        TaskImageOffset offset = new TaskImageOffset("10|20|30|40|50|60|70|80|90");

        assertEquals("10", offset.getOffset(0));
        assertEquals("50", offset.getOffset(4));
        assertEquals("90", offset.getOffset(8));
        assertEquals("90", offset.getOffset(10));
    }

    @Test
    @DisplayName("Should handle empty string")
    void shouldHandleEmptyString() {
        TaskImageOffset offset = new TaskImageOffset("");

        assertEquals("", offset.getOffset(0));
    }

    @Test
    @DisplayName("Should handle null string")
    void shouldHandleNullString() {
        TaskImageOffset offset = new TaskImageOffset(null);

        assertEquals("", offset.getOffset(0));
        assertEquals("", offset.getOffset(5));
    }

    @Test
    @DisplayName("Should handle numeric offset values")
    void shouldHandleNumericOffsetValues() {
        TaskImageOffset offset = new TaskImageOffset("123|456|789|1000");

        assertEquals("123", offset.getOffset(0));
        assertEquals("456", offset.getOffset(1));
        assertEquals("789", offset.getOffset(2));
        assertEquals("1000", offset.getOffset(3));
    }

    @Test
    @DisplayName("Should access by zero index")
    void shouldAccessByZeroIndex() {
        TaskImageOffset offset = new TaskImageOffset("first|second|third");

        assertEquals("first", offset.getOffset(0));
    }

    @Test
    @DisplayName("Should access by negative index")
    void shouldAccessByNegativeIndex() {
        TaskImageOffset offset = new TaskImageOffset("100|200|300");

        // Negative index should still work as it will be out of bounds
        assertEquals("300", offset.getOffset(-1));
    }
}

