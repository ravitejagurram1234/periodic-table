package com.socgen.sgs.api.quark.engine.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("DataTypeEnum Tests")
class DataTypeEnumTest {

    @Test
    @DisplayName("Should have correct codes")
    void shouldHaveCorrectCodes() {
        assertEquals(0, DataTypeEnum.UNSPECIFIED.getCode());
        assertEquals(1, DataTypeEnum.TEXT.getCode());
        assertEquals(2, DataTypeEnum.INT.getCode());
        assertEquals(99, DataTypeEnum.CUSTOM.getCode());
    }

    @Test
    @DisplayName("Should get from valid code")
    void shouldGetFromValidCode() {
        assertEquals(DataTypeEnum.TEXT, DataTypeEnum.fromCode(1));
        assertEquals(DataTypeEnum.INT, DataTypeEnum.fromCode(2));
    }

    @Test
    @DisplayName("Should return UNSPECIFIED for invalid code")
    void shouldReturnUnspecifiedForInvalidCode() {
        assertEquals(DataTypeEnum.UNSPECIFIED, DataTypeEnum.fromCode(999));
    }
}

