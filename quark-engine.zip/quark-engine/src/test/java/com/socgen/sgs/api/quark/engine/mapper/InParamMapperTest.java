package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.InParam;
import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("InParamMapper Tests")
class InParamMapperTest {

    private InParamMapper mapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    void setUp() {
        mapper = new InParamMapper();
    }

    @Test
    @DisplayName("Should map ResultSet to InParam")
    void shouldMapResultSetToInParam() throws SQLException {
        when(resultSet.getString("nom_parametre")).thenReturn("testParam");
        when(resultSet.getInt("input_data_type")).thenReturn(1);
        when(resultSet.getString("valeur")).thenReturn("testValue");

        InParam result = mapper.mapFromResultSet(resultSet);

        assertNotNull(result);
        assertEquals("testParam", result.getName());
        assertEquals(DataTypeEnum.TEXT, result.getType());
        assertEquals("testValue", result.getStringValue());
    }

    @Test
    @DisplayName("Should map integer type correctly")
    void shouldMapIntegerTypeCorrectly() throws SQLException {
        when(resultSet.getString("nom_parametre")).thenReturn("intParam");
        when(resultSet.getInt("input_data_type")).thenReturn(2);
        when(resultSet.getString("valeur")).thenReturn("100");

        InParam result = mapper.mapFromResultSet(resultSet);

        assertEquals(DataTypeEnum.INT, result.getType());
        assertEquals("100", result.getStringValue());
    }

    @Test
    @DisplayName("Should handle null values")
    void shouldHandleNullValues() throws SQLException {
        when(resultSet.getString("nom_parametre")).thenReturn(null);
        when(resultSet.getInt("input_data_type")).thenReturn(0);
        when(resultSet.getString("valeur")).thenReturn(null);

        InParam result = mapper.mapFromResultSet(resultSet);

        assertNull(result.getName());
        assertNull(result.getStringValue());
    }
}
