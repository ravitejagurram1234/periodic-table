package com.socgen.sgs.api.quark.engine.domain;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("DataNameValue Tests")
class DataNameValueTest {

    @Test
    @DisplayName("Should create DataNameValue with name and value only")
    void shouldCreateDataNameValueWithNameAndValue() {
        DataNameValue data = new DataNameValue("testName", "testValue");

        assertEquals("testName", data.getName());
        assertEquals("testValue", data.getValue());
        assertEquals("", data.getDescriptif());
        assertEquals("", data.getInfo());
    }

    @Test
    @DisplayName("Should create DataNameValue with all parameters")
    void shouldCreateDataNameValueWithAllParameters() {
        String name = "parameter";
        String value = "paramValue";
        String descriptif = "This is a description";
        String info = "Additional info";

        DataNameValue data = new DataNameValue(name, value, descriptif, info);

        assertEquals(name, data.getName());
        assertEquals(value, data.getValue());
        assertEquals(descriptif, data.getDescriptif());
        assertEquals(info, data.getInfo());
    }

    @Test
    @DisplayName("Should handle null descriptif by converting to empty string")
    void shouldHandleNullDescriptif() {
        DataNameValue data = new DataNameValue("name", "value", null, "info");

        assertEquals("name", data.getName());
        assertEquals("value", data.getValue());
        assertEquals("", data.getDescriptif());
        assertEquals("info", data.getInfo());
    }

    @Test
    @DisplayName("Should handle null info by converting to empty string")
    void shouldHandleNullInfo() {
        DataNameValue data = new DataNameValue("name", "value", "descriptif", null);

        assertEquals("name", data.getName());
        assertEquals("value", data.getValue());
        assertEquals("descriptif", data.getDescriptif());
        assertEquals("", data.getInfo());
    }

    @Test
    @DisplayName("Should handle both null descriptif and info")
    void shouldHandleNullDescriptifAndInfo() {
        DataNameValue data = new DataNameValue("name", "value", null, null);

        assertEquals("name", data.getName());
        assertEquals("value", data.getValue());
        assertEquals("", data.getDescriptif());
        assertEquals("", data.getInfo());
    }

    @Test
    @DisplayName("Should generate proper toString representation")
    void shouldGenerateProperToString() {
        DataNameValue data = new DataNameValue("name", "value", "desc", "info");
        String result = data.toString();

        assertNotNull(result);
        assertTrue(result.contains("name"));
        assertTrue(result.contains("value"));
        assertTrue(result.contains("desc"));
        assertTrue(result.contains("info"));
    }

    @Test
    @DisplayName("Should be immutable - no setter methods exist")
    void shouldBeImmutable() {
        DataNameValue data = new DataNameValue("name", "value");

        assertEquals("name", data.getName());
        assertEquals("value", data.getValue());
        // Verify immutability by confirming no public setter methods exist on the class
        long setterCount = java.util.Arrays.stream(DataNameValue.class.getMethods())
                .filter(m -> m.getName().startsWith("set"))
                .count();
        assertEquals(0, setterCount, "DataNameValue should have no setter methods");
    }
}

