package com.socgen.sgs.api.quark.engine;

import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.syntax.ArchRuleDefinition;

@AnalyzeClasses(packages = "com.socgen.sgs.api.quark.engine", importOptions = {
    ImportOption.DoNotIncludeTests.class })
class WrongFrameworksTest {

  @ArchTest
  static final ArchRule Transactional_annotation_comes_from_Spring = ArchRuleDefinition.noClasses()
      .should()
      .dependOnClassesThat().haveFullyQualifiedName("jakarta.transaction.Transaction");

  @ArchTest
  static final ArchRule joda_time_is_obsolete_since_java8 = ArchRuleDefinition.noClasses()
      .should()
      .dependOnClassesThat().resideInAPackage("org.joda.time..");

  @ArchTest
  static final ArchRule jackson_is_now_in_package_fasterxml = ArchRuleDefinition.noClasses()
      .should()
      .dependOnClassesThat().resideInAPackage("org.codehaus.jackson..");

  @ArchTest
  static final ArchRule logging_is_done_through_slf4j = ArchRuleDefinition.noClasses()
      .should()
      .dependOnClassesThat().resideInAnyPackage(
          // log4j
          "org.apache.log4j", "org.apache.logging..",
          // logback
          "ch.qos.logback..",
          // java common logging
          "java.util.logging..",
          // other frameworks
          "org.apache.commons.logging..", "org.jboss.logging..", "liquibase.logging..");
}
