package com.socgen.sgs.api.quark.engine.domain;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("RunId Tests")
class RunIdTest {

    @Test
    @DisplayName("Should create RunId with no arguments")
    void shouldCreateRunIdWithNoArguments() {
        RunId runId = new RunId();

        assertNull(runId.getRunId());
    }

    @Test
    @DisplayName("Should create RunId with runId argument")
    void shouldCreateRunIdWithArgument() {
        RunId runId = new RunId(42);

        assertEquals(42, runId.getRunId());
    }

    @Test
    @DisplayName("Should set and get runId")
    void shouldSetAndGetRunId() {
        RunId runId = new RunId();
        runId.setRunId(100);

        assertEquals(100, runId.getRunId());
    }

    @Test
    @DisplayName("Should handle zero runId")
    void shouldHandleZeroRunId() {
        RunId runId = new RunId(0);

        assertEquals(0, runId.getRunId());
    }

    @Test
    @DisplayName("Should handle negative runId")
    void shouldHandleNegativeRunId() {
        RunId runId = new RunId(-1);

        assertEquals(-1, runId.getRunId());
    }

    @Test
    @DisplayName("Should handle large runId values")
    void shouldHandleLargeRunIdValues() {
        int largeValue = Integer.MAX_VALUE;
        RunId runId = new RunId(largeValue);

        assertEquals(largeValue, runId.getRunId());
    }

    @Test
    @DisplayName("Should be mutable via setter")
    void shouldBeMutableViaSetter() {
        RunId runId = new RunId(10);
        assertEquals(10, runId.getRunId());

        runId.setRunId(20);
        assertEquals(20, runId.getRunId());

        runId.setRunId(null);
        assertNull(runId.getRunId());
    }
}

