package com.socgen.sgs.api.quark.engine.domain.helper;

import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.text.DecimalFormatSymbols;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("DataTypeHelper formatting Tests")
class DataTypeHelperTest {

    // Use the JVM's actual fr-FR symbols so assertions survive CLDR grouping-char changes
    // (the grouping separator may be NBSP U+00A0 or NNBSP U+202F depending on the JDK/CLDR).
    private static final DecimalFormatSymbols FR = new DecimalFormatSymbols(Locale.FRANCE);
    private static final char GRP = FR.getGroupingSeparator();
    private static final char DEC = FR.getDecimalSeparator();
    private static final String CUR = FR.getCurrencySymbol();

    @Test
    @DisplayName("#12 INT output is grouped (thousands separators)")
    void intIsGrouped() {
        assertEquals("1" + GRP + "234" + GRP + "567",
                DataTypeHelper.outputToString("1234567", DataTypeEnum.INT, 0, true, "-", false));
    }

    @Test
    @DisplayName("INT zero with showZero=false returns nullString")
    void intZeroNotShown() {
        assertEquals("N/A", DataTypeHelper.outputToString("0", DataTypeEnum.INT, 0, false, "N/A", false));
    }

    @Test
    @DisplayName("#13 decimalSignificative=true keeps fixed trailing zeros")
    void decimalSignificativeKeepsZeros() {
        assertEquals("12" + DEC + "50",
                DataTypeHelper.outputToString("12.5", DataTypeEnum.DECIMAL, 2, true, "-", true));
    }

    @Test
    @DisplayName("#13 decimalSignificative=false suppresses trailing zeros")
    void decimalNotSignificativeSuppressesZeros() {
        assertEquals("12" + DEC + "5",
                DataTypeHelper.outputToString("12.50", DataTypeEnum.DECIMAL, 2, true, "-", false));
        assertEquals("12",
                DataTypeHelper.outputToString("12", DataTypeEnum.DECIMAL, 2, true, "-", false));
    }

    @Test
    @DisplayName("Decimal rounding is HALF_UP (away from zero)")
    void decimalRoundsHalfUp() {
        assertEquals("2" + DEC + "35",
                DataTypeHelper.outputToString("2.345", DataTypeEnum.DECIMAL, 2, true, "-", true));
    }

    @Test
    @DisplayName("#14 CURRENCY appends the currency symbol, no ×100")
    void currencyAppendsSymbol() {
        assertEquals("1" + GRP + "234" + DEC + "50 " + CUR,
                DataTypeHelper.outputToString("1234.5", DataTypeEnum.CURRENCY, 2, true, "-", true));
    }

    @Test
    @DisplayName("#14 POURCENTAGE appends single ' %' and does NOT multiply by 100 (data is scaled)")
    void percentScaledSinglePercent() {
        // 15 means 15% — must render "15,00 %", NOT "1 500,00 % %"
        assertEquals("15" + DEC + "00 %",
                DataTypeHelper.outputToString("15", DataTypeEnum.POURCENTAGE, 2, true, "-", true));
        // significative=false suppresses the trailing zeros
        assertEquals("15 %",
                DataTypeHelper.outputToString("15", DataTypeEnum.POURCENTAGE, 2, true, "-", false));
    }

    @Test
    @DisplayName("CURRENCY/POURCENTAGE zero with showZero=false returns nullString (no suffix)")
    void zeroNotShownHasNoSuffix() {
        assertEquals("-", DataTypeHelper.outputToString("0", DataTypeEnum.CURRENCY, 2, false, "-", true));
        assertEquals("-", DataTypeHelper.outputToString("0", DataTypeEnum.POURCENTAGE, 2, false, "-", true));
    }
}