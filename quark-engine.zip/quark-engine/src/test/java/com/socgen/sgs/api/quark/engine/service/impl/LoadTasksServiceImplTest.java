package com.socgen.sgs.api.quark.engine.service.impl;

import com.socgen.sgs.api.quark.engine.business.GetTaskExceptionsBusiness;
import com.socgen.sgs.api.quark.engine.business.GetTasksBusiness;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.task.TaskException;
import com.socgen.sgs.api.quark.engine.domain.task.TaskSql;
import com.socgen.sgs.api.quark.engine.enums.TaskExceptionTypeEnum;
import com.socgen.sgs.api.quark.engine.mapper.TaskExceptionMapper;
import com.socgen.sgs.api.quark.engine.mapper.TaskMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("LoadTasksServiceImpl Tests")
class LoadTasksServiceImplTest {

    @InjectMocks
    private LoadTasksServiceImpl loadTasksService;

    @Mock
    private GetTasksBusiness getTasksBusiness;

    @Mock
    private GetTaskExceptionsBusiness getTaskExceptionsBusiness;

    @Mock
    private TaskMapper taskMapper;

    @Mock
    private TaskExceptionMapper taskExceptionMapper;

    private Run run;

    @BeforeEach
    void setUp() {
        run = new Run();
        run.setId(100);
    }

    // --- loadTasks: task loading ---

    @Test

    @DisplayName("Should load tasks and populate run.tasks map")
    void shouldLoadTasksAndPopulate() {
        Map<String, Object> row1 = Map.of("ID_TACHE", 10, "ID_TYPE_TACHE", 1);
        Map<String, Object> row2 = Map.of("ID_TACHE", 20, "ID_TYPE_TACHE", 2);
        when(getTasksBusiness.execute(100)).thenReturn(List.of(row1, row2));

        TaskSql task1 = new TaskSql(10, run);
        TaskSql task2 = new TaskSql(20, run);
        when(taskMapper.mapToTask(row1, run)).thenReturn(task1);
        when(taskMapper.mapToTask(row2, run)).thenReturn(task2);
        when(getTaskExceptionsBusiness.execute(100)).thenReturn(Collections.emptyList());

        loadTasksService.loadTasks(run);

        assertEquals(3, run.getTasks().size());
        assertSame(task1, run.getTasks().get(10));
        assertSame(task2, run.getTasks().get(20));
        verify(getTasksBusiness, times(1)).execute(100);
    }

    @Test
    @DisplayName("Should skip null tasks returned by mapper")
    void shouldSkipNullTasks() {
        Map<String, Object> row1 = Map.of("ID_TACHE", 10, "ID_TYPE_TACHE", 0);
        when(getTasksBusiness.execute(100)).thenReturn(List.of(row1));
        when(taskMapper.mapToTask(row1, run)).thenReturn(null);
        when(getTaskExceptionsBusiness.execute(100)).thenReturn(Collections.emptyList());

        loadTasksService.loadTasks(run);

        assertEquals(1, run.getTasks().size());
        assertTrue(run.getTasks().containsKey(0)); // DID task
    }

    @Test
    @DisplayName("Should handle empty task list from DAO")
    void shouldHandleEmptyTaskList() {
        when(getTasksBusiness.execute(100)).thenReturn(Collections.emptyList());
        when(getTaskExceptionsBusiness.execute(100)).thenReturn(Collections.emptyList());

        loadTasksService.loadTasks(run);

        assertEquals(1, run.getTasks().size());
        assertTrue(run.getTasks().containsKey(0)); // only DID task
        verify(getTaskExceptionsBusiness, times(1)).execute(100);
    }

    // --- loadTasks: exception loading ---

    @Test
    @DisplayName("Should load task exceptions and add to task's exceptions map")
    void shouldLoadTaskExceptions() {
        TaskSql task = new TaskSql(10, run);

        Map<String, Object> taskRow = new HashMap<>();
        taskRow.put("ID_TACHE", 10);
        taskRow.put("ID_TYPE_TACHE", 1);

        Map<String, Object> excRow = new HashMap<>();
        excRow.put("ID_TACHE", 10);
        excRow.put("NOM_BLOC", "BLOC_A");
        excRow.put("NOM_TABLEAU", "TABLE_X");
        excRow.put("INDEX_LIGNES", "1|2");

        when(getTasksBusiness.execute(100)).thenReturn(List.of(taskRow));
        when(taskMapper.mapToTask(taskRow, run)).thenReturn(task);
        when(getTaskExceptionsBusiness.execute(100)).thenReturn(List.of(excRow));
        when(taskExceptionMapper.getIdTache(excRow)).thenReturn(10);
        when(taskExceptionMapper.getNomBloc(excRow)).thenReturn("BLOC_A");
        TaskException taskException = new TaskException("TABLE_X", "BLOC_A", new int[]{1, 2}, TaskExceptionTypeEnum.LINE);
        when(taskExceptionMapper.mapToTaskException(excRow)).thenReturn(taskException);

        loadTasksService.loadTasks(run);

        assertEquals(1, task.getExceptions().size());
        assertSame(taskException, task.getExceptions().get("BLOC_A"));
    }

    @Test
    @DisplayName("Should skip exception when task not found in run")
    void shouldSkipExceptionWhenTaskNotFound() {
        when(getTasksBusiness.execute(100)).thenReturn(Collections.emptyList());

        Map<String, Object> excRow = new HashMap<>();
        excRow.put("ID_TACHE", 999);
        excRow.put("NOM_BLOC", "BLOC_MISSING");

        when(getTaskExceptionsBusiness.execute(100)).thenReturn(List.of(excRow));
        when(taskExceptionMapper.getIdTache(excRow)).thenReturn(999);
        when(taskExceptionMapper.getNomBloc(excRow)).thenReturn("BLOC_MISSING");

        loadTasksService.loadTasks(run);

        assertEquals(1, run.getTasks().size());
        assertTrue(run.getTasks().containsKey(0)); // only DID task, task 999 not found
    }

    @Test
    @DisplayName("Should warn on duplicate bloc exception and not overwrite")
    void shouldWarnOnDuplicateBlocException() {
        TaskSql task = new TaskSql(10, run);
        TaskException existingExc = new TaskException("TABLE_OLD", "BLOC_DUP", new int[0], TaskExceptionTypeEnum.TABLE);
        task.getExceptions().put("BLOC_DUP", existingExc);

        Map<String, Object> taskRow = new HashMap<>();
        taskRow.put("ID_TACHE", 10);
        taskRow.put("ID_TYPE_TACHE", 1);

        Map<String, Object> excRow = new HashMap<>();
        excRow.put("ID_TACHE", 10);
        excRow.put("NOM_BLOC", "BLOC_DUP");

        when(getTasksBusiness.execute(100)).thenReturn(List.of(taskRow));
        when(taskMapper.mapToTask(taskRow, run)).thenReturn(task);
        when(getTaskExceptionsBusiness.execute(100)).thenReturn(List.of(excRow));
        when(taskExceptionMapper.getIdTache(excRow)).thenReturn(10);
        when(taskExceptionMapper.getNomBloc(excRow)).thenReturn("BLOC_DUP");

        loadTasksService.loadTasks(run);

        assertEquals(1, task.getExceptions().size());
        assertSame(existingExc, task.getExceptions().get("BLOC_DUP"));
    }

    @Test
    @DisplayName("Should reuse cached task for same task id in consecutive exception rows")
    void shouldReuseCachedTask() {
        TaskSql task = new TaskSql(10, run);

        Map<String, Object> taskRow = new HashMap<>();
        taskRow.put("ID_TACHE", 10);
        taskRow.put("ID_TYPE_TACHE", 1);

        Map<String, Object> excRow1 = new HashMap<>();
        excRow1.put("ID_TACHE", 10);
        excRow1.put("NOM_BLOC", "BLOC_1");
        Map<String, Object> excRow2 = new HashMap<>();
        excRow2.put("ID_TACHE", 10);
        excRow2.put("NOM_BLOC", "BLOC_2");

        when(getTasksBusiness.execute(100)).thenReturn(List.of(taskRow));
        when(taskMapper.mapToTask(taskRow, run)).thenReturn(task);
        when(getTaskExceptionsBusiness.execute(100)).thenReturn(List.of(excRow1, excRow2));
        when(taskExceptionMapper.getIdTache(excRow1)).thenReturn(10);
        when(taskExceptionMapper.getNomBloc(excRow1)).thenReturn("BLOC_1");
        when(taskExceptionMapper.getIdTache(excRow2)).thenReturn(10);
        when(taskExceptionMapper.getNomBloc(excRow2)).thenReturn("BLOC_2");

        TaskException exc1 = new TaskException("T1", "BLOC_1", new int[]{1}, TaskExceptionTypeEnum.LINE);
        TaskException exc2 = new TaskException("T2", "BLOC_2", new int[0], TaskExceptionTypeEnum.TABLE);
        when(taskExceptionMapper.mapToTaskException(excRow1)).thenReturn(exc1);
        when(taskExceptionMapper.mapToTaskException(excRow2)).thenReturn(exc2);

        loadTasksService.loadTasks(run);

        assertEquals(2, task.getExceptions().size());
        assertSame(exc1, task.getExceptions().get("BLOC_1"));
        assertSame(exc2, task.getExceptions().get("BLOC_2"));
    }

    @Test
    @DisplayName("Should handle switching between different task ids in exceptions")
    void shouldHandleSwitchingBetweenTasks() {
        TaskSql task1 = new TaskSql(10, run);
        TaskSql task2 = new TaskSql(20, run);

        Map<String, Object> taskRow1 = new HashMap<>();
        taskRow1.put("ID_TACHE", 10);
        taskRow1.put("ID_TYPE_TACHE", 1);
        Map<String, Object> taskRow2 = new HashMap<>();
        taskRow2.put("ID_TACHE", 20);
        taskRow2.put("ID_TYPE_TACHE", 1);

        Map<String, Object> excRow1 = new HashMap<>();
        excRow1.put("ID_TACHE", 10);
        excRow1.put("NOM_BLOC", "BLOC_A");
        Map<String, Object> excRow2 = new HashMap<>();
        excRow2.put("ID_TACHE", 20);
        excRow2.put("NOM_BLOC", "BLOC_B");

        when(getTasksBusiness.execute(100)).thenReturn(List.of(taskRow1, taskRow2));
        when(taskMapper.mapToTask(taskRow1, run)).thenReturn(task1);
        when(taskMapper.mapToTask(taskRow2, run)).thenReturn(task2);
        when(getTaskExceptionsBusiness.execute(100)).thenReturn(List.of(excRow1, excRow2));
        when(taskExceptionMapper.getIdTache(excRow1)).thenReturn(10);
        when(taskExceptionMapper.getNomBloc(excRow1)).thenReturn("BLOC_A");
        when(taskExceptionMapper.getIdTache(excRow2)).thenReturn(20);
        when(taskExceptionMapper.getNomBloc(excRow2)).thenReturn("BLOC_B");

        TaskException exc1 = new TaskException("T1", "BLOC_A", new int[]{1}, TaskExceptionTypeEnum.LINE);
        TaskException exc2 = new TaskException("T2", "BLOC_B", new int[0], TaskExceptionTypeEnum.TABLE);
        when(taskExceptionMapper.mapToTaskException(excRow1)).thenReturn(exc1);
        when(taskExceptionMapper.mapToTaskException(excRow2)).thenReturn(exc2);

        loadTasksService.loadTasks(run);

        assertEquals(1, task1.getExceptions().size());
        assertEquals(1, task2.getExceptions().size());
        assertSame(exc1, task1.getExceptions().get("BLOC_A"));
        assertSame(exc2, task2.getExceptions().get("BLOC_B"));
    }

    @Test
    @DisplayName("Should handle empty exception list from DAO")
    void shouldHandleEmptyExceptionList() {
        TaskSql task = new TaskSql(10, run);

        Map<String, Object> taskRow = new HashMap<>();
        taskRow.put("ID_TACHE", 10);
        taskRow.put("ID_TYPE_TACHE", 1);

        when(getTasksBusiness.execute(100)).thenReturn(List.of(taskRow));
        when(taskMapper.mapToTask(taskRow, run)).thenReturn(task);
        when(getTaskExceptionsBusiness.execute(100)).thenReturn(Collections.emptyList());

        loadTasksService.loadTasks(run);

        assertTrue(task.getExceptions().isEmpty());
    }

    @Test
    @DisplayName("Should skip exception row after task-not-found and process next valid row")
    void shouldSkipMissingTaskAndContinue() {
        TaskSql task20 = new TaskSql(20, run);

        Map<String, Object> taskRow = new HashMap<>();
        taskRow.put("ID_TACHE", 20);
        taskRow.put("ID_TYPE_TACHE", 1);

        Map<String, Object> excRow1 = new HashMap<>();
        excRow1.put("ID_TACHE", 999);
        excRow1.put("NOM_BLOC", "BLOC_MISSING");
        Map<String, Object> excRow2 = new HashMap<>();
        excRow2.put("ID_TACHE", 20);
        excRow2.put("NOM_BLOC", "BLOC_OK");

        when(getTasksBusiness.execute(100)).thenReturn(List.of(taskRow));
        when(taskMapper.mapToTask(taskRow, run)).thenReturn(task20);
        when(getTaskExceptionsBusiness.execute(100)).thenReturn(List.of(excRow1, excRow2));
        when(taskExceptionMapper.getIdTache(excRow1)).thenReturn(999);
        when(taskExceptionMapper.getNomBloc(excRow1)).thenReturn("BLOC_MISSING");
        when(taskExceptionMapper.getIdTache(excRow2)).thenReturn(20);
        when(taskExceptionMapper.getNomBloc(excRow2)).thenReturn("BLOC_OK");

        TaskException exc = new TaskException("T2", "BLOC_OK", new int[]{5}, TaskExceptionTypeEnum.LINE);
        when(taskExceptionMapper.mapToTaskException(excRow2)).thenReturn(exc);

        loadTasksService.loadTasks(run);

        assertEquals(1, task20.getExceptions().size());
        assertSame(exc, task20.getExceptions().get("BLOC_OK"));
    }
}
