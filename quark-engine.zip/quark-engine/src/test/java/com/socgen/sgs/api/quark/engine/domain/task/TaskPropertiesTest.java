package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.enums.TaskActionTypeEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TaskProperties Tests")
class TaskPropertiesTest {

    private TaskProperties taskProperties;

    @BeforeEach
    void setUp() {
        taskProperties = new TaskProperties();
    }

    @Test
    @DisplayName("Should create TaskProperties with default values")
    void shouldCreateTaskPropertiesWithDefaults() {
        assertNull(taskProperties.getLayoutName());
        assertEquals(0, taskProperties.getPageNum());
        assertEquals(Integer.MIN_VALUE, taskProperties.getIndexLigne());
        assertEquals(Integer.MIN_VALUE, taskProperties.getNbLigne());
        assertEquals(TaskActionTypeEnum.NONE, taskProperties.getTaskAction());
        assertNull(taskProperties.getTableName());
    }

    @Test
    @DisplayName("Should set and get layout name")
    void shouldSetAndGetLayoutName() {
        taskProperties.setLayoutName("layout1");

        assertEquals("layout1", taskProperties.getLayoutName());
    }

    @Test
    @DisplayName("Should set and get page number")
    void shouldSetAndGetPageNumber() {
        taskProperties.setPageNum(42);

        assertEquals(42, taskProperties.getPageNum());
    }

    @Test
    @DisplayName("Should set and get index ligne")
    void shouldSetAndGetIndexLigne() {
        taskProperties.setIndexLigne(5);

        assertEquals(5, taskProperties.getIndexLigne());
    }

    @Test
    @DisplayName("Should set and get nb ligne")
    void shouldSetAndGetNbLigne() {
        taskProperties.setNbLigne(3);

        assertEquals(3, taskProperties.getNbLigne());
    }

    @Test
    @DisplayName("Should set and get task action")
    void shouldSetAndGetTaskAction() {
        taskProperties.setTaskAction(TaskActionTypeEnum.UPDATE);

        assertEquals(TaskActionTypeEnum.UPDATE, taskProperties.getTaskAction());
    }

    @Test
    @DisplayName("Should set and get table name")
    void shouldSetAndGetTableName() {
        taskProperties.setTableName("tableData");

        assertEquals("tableData", taskProperties.getTableName());
    }

    @Test
    @DisplayName("Should handle all task action types")
    void shouldHandleAllTaskActionTypes() {
        taskProperties.setTaskAction(TaskActionTypeEnum.NONE);
        assertEquals(TaskActionTypeEnum.NONE, taskProperties.getTaskAction());

        taskProperties.setTaskAction(TaskActionTypeEnum.UPDATE);
        assertEquals(TaskActionTypeEnum.UPDATE, taskProperties.getTaskAction());

        taskProperties.setTaskAction(TaskActionTypeEnum.CREATE);
        assertEquals(TaskActionTypeEnum.CREATE, taskProperties.getTaskAction());

        taskProperties.setTaskAction(TaskActionTypeEnum.REMOVE);
        assertEquals(TaskActionTypeEnum.REMOVE, taskProperties.getTaskAction());
    }

    @Test
    @DisplayName("Should set all properties and retrieve them")
    void shouldSetAllPropertiesAndRetrieveThem() {
        taskProperties.setLayoutName("customLayout");
        taskProperties.setPageNum(100);
        taskProperties.setIndexLigne(10);
        taskProperties.setNbLigne(5);
        taskProperties.setTaskAction(TaskActionTypeEnum.CREATE);
        taskProperties.setTableName("tableX");

        assertEquals("customLayout", taskProperties.getLayoutName());
        assertEquals(100, taskProperties.getPageNum());
        assertEquals(10, taskProperties.getIndexLigne());
        assertEquals(5, taskProperties.getNbLigne());
        assertEquals(TaskActionTypeEnum.CREATE, taskProperties.getTaskAction());
        assertEquals("tableX", taskProperties.getTableName());
    }

    @Test
    @DisplayName("Should handle MIN_VALUE for index and nb ligne")
    void shouldHandleMinValueForIndexAndNbLigne() {
        assertEquals(Integer.MIN_VALUE, taskProperties.getIndexLigne());
        assertEquals(Integer.MIN_VALUE, taskProperties.getNbLigne());

        taskProperties.setIndexLigne(Integer.MIN_VALUE);
        taskProperties.setNbLigne(Integer.MIN_VALUE);

        assertEquals(Integer.MIN_VALUE, taskProperties.getIndexLigne());
        assertEquals(Integer.MIN_VALUE, taskProperties.getNbLigne());
    }

    @Test
    @DisplayName("Should handle zero page number")
    void shouldHandleZeroPageNumber() {
        taskProperties.setPageNum(0);

        assertEquals(0, taskProperties.getPageNum());
    }

    @Test
    @DisplayName("Should handle negative page number")
    void shouldHandleNegativePageNumber() {
        taskProperties.setPageNum(-1);

        assertEquals(-1, taskProperties.getPageNum());
    }
}

