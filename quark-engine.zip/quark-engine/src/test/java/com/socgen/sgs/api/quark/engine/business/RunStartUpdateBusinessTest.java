package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.infra.dao.RunStartUpdateDao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("RunStartUpdateBusiness Tests")
class RunStartUpdateBusinessTest {

    @InjectMocks
    private RunStartUpdateBusiness runStartUpdateBusiness;

    @Mock
    private RunStartUpdateDao runStartUpdateDao;

    private Run run;

    @BeforeEach
    void setUp() {
        run = new Run();
        run.setId(77);
    }

    @Test
    @DisplayName("Should delegate to DAO and call startRun once")
    void shouldDelegateToDao() {
        runStartUpdateBusiness.execute(run);

        verify(runStartUpdateDao, times(1)).startRun(run);
    }

    @Test
    @DisplayName("Should pass the exact run instance to DAO")
    void shouldPassExactRunToDao() {
        runStartUpdateBusiness.execute(run);

        verify(runStartUpdateDao).startRun(same(run));
    }
}
