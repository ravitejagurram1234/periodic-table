package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.domain.StoreDataType;
import com.socgen.sgs.api.quark.engine.enums.GabaritSourceEnum;
import com.socgen.sgs.api.quark.engine.enums.TypeRapportEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("RunPropertiesMapper Tests")
class RunPropertiesMapperTest {

    private RunPropertiesMapper mapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    void setUp() {
        mapper = new RunPropertiesMapper();
    }

    @Test
    @DisplayName("Should map ResultSet to RunProperties")
    void shouldMapResultSetToRunProperties() throws SQLException {
        when(resultSet.getInt("id_type_rapport")).thenReturn(1);
        when(resultSet.getString("id_fnd_code")).thenReturn("FND001");
        when(resultSet.getString("id_unit_code")).thenReturn("UNIT001");
        when(resultSet.getDate("date_echeance")).thenReturn(Date.valueOf(LocalDate.of(2024, 12, 31)));
        when(resultSet.getInt("id_suivi")).thenReturn(100);
        when(resultSet.getInt("id_langue")).thenReturn(1);
        when(resultSet.getString("societe")).thenReturn("SocGen");
        when(resultSet.getString("code_langue")).thenReturn("FR");
        when(resultSet.getInt("gabarit_source")).thenReturn(2);
        when(resultSet.getInt("id_suivi_gabarit_source")).thenReturn(50);
        when(resultSet.getInt("integrer_n1")).thenReturn(1);
        when(resultSet.getInt("mode_compart")).thenReturn(1);
        when(resultSet.getString("runtype")).thenReturn("Manual");
        when(resultSet.getInt("generate_to_word")).thenReturn(1);
        when(resultSet.getInt("id_gabarit")).thenReturn(200);
        when(resultSet.getInt("id_gabarit_template")).thenReturn(300);
        when(resultSet.getInt("id_doc_pdf")).thenReturn(111);
        when(resultSet.getInt("id_doc_qxp")).thenReturn(222);
        when(resultSet.getInt("id_doc_doc")).thenReturn(333);
        when(resultSet.getInt("pagination_double")).thenReturn(0);
        when(resultSet.getInt("store_data_type")).thenReturn(1);
        when(resultSet.wasNull()).thenReturn(false);

        RunProperties props = mapper.mapFromResultSet(resultSet);

        assertNotNull(props);
        assertEquals(TypeRapportEnum.RAPPORT_ANNUEL, props.getTypeRapport());
        assertEquals("FND001", props.getIdFndCode());
    }

    @Test
    @DisplayName("Should map gabarit source correctly")
    void shouldMapGabaritSourceCorrectly() throws SQLException {
        when(resultSet.getInt("id_type_rapport")).thenReturn(1);
        when(resultSet.getString("id_fnd_code")).thenReturn("FND001");
        when(resultSet.getString("id_unit_code")).thenReturn("UNIT001");
        when(resultSet.getDate("date_echeance")).thenReturn(null);
        when(resultSet.getInt("id_suivi")).thenReturn(100);
        when(resultSet.getInt("id_langue")).thenReturn(1);
        when(resultSet.getString("societe")).thenReturn("SocGen");
        when(resultSet.getString("code_langue")).thenReturn("FR");
        when(resultSet.getInt("gabarit_source")).thenReturn(1);
        when(resultSet.getInt("id_suivi_gabarit_source")).thenReturn(50);
        when(resultSet.getInt("integrer_n1")).thenReturn(1);
        when(resultSet.getInt("mode_compart")).thenReturn(1);
        when(resultSet.getString("runtype")).thenReturn("Manual");
        when(resultSet.getInt("generate_to_word")).thenReturn(1);
        when(resultSet.getInt("id_gabarit")).thenReturn(200);
        when(resultSet.getInt("id_gabarit_template")).thenReturn(300);
        when(resultSet.getInt("id_doc_pdf")).thenReturn(111);
        when(resultSet.getInt("id_doc_qxp")).thenReturn(222);
        when(resultSet.getInt("id_doc_doc")).thenReturn(333);
        when(resultSet.getInt("pagination_double")).thenReturn(0);
        when(resultSet.getInt("store_data_type")).thenReturn(1);
        when(resultSet.wasNull()).thenReturn(false);

        RunProperties props = mapper.mapFromResultSet(resultSet);

        assertEquals(GabaritSourceEnum.GABARIT, props.getGabaritSource());
    }

    @Test
    @DisplayName("Should map pagination double correctly")
    void shouldMapPaginationValuesCorrectly() throws SQLException {
        when(resultSet.getInt("id_type_rapport")).thenReturn(1);
        when(resultSet.getString("id_fnd_code")).thenReturn("FND001");
        when(resultSet.getString("id_unit_code")).thenReturn("UNIT001");
        when(resultSet.getDate("date_echeance")).thenReturn(null);
        when(resultSet.getInt("id_suivi")).thenReturn(100);
        when(resultSet.getInt("id_langue")).thenReturn(1);
        when(resultSet.getString("societe")).thenReturn("SocGen");
        when(resultSet.getString("code_langue")).thenReturn("FR");
        when(resultSet.getInt("gabarit_source")).thenReturn(2);
        when(resultSet.getInt("id_suivi_gabarit_source")).thenReturn(50);
        when(resultSet.getInt("integrer_n1")).thenReturn(1);
        when(resultSet.getInt("mode_compart")).thenReturn(1);
        when(resultSet.getString("runtype")).thenReturn("Manual");
        when(resultSet.getInt("generate_to_word")).thenReturn(1);
        when(resultSet.getInt("id_gabarit")).thenReturn(200);
        when(resultSet.getInt("id_gabarit_template")).thenReturn(300);
        when(resultSet.getInt("id_doc_pdf")).thenReturn(111);
        when(resultSet.getInt("id_doc_qxp")).thenReturn(222);
        when(resultSet.getInt("id_doc_doc")).thenReturn(333);
        when(resultSet.getInt("pagination_double")).thenReturn(1);
        when(resultSet.getInt("store_data_type")).thenReturn(1);
        when(resultSet.wasNull()).thenReturn(false);

        RunProperties props = mapper.mapFromResultSet(resultSet);

        assertEquals(RunProperties.PAGINATION_DOUBLE, props.getNbPageBySpread());
    }

    @Test
    @DisplayName("Should map store data type correctly")
    void shouldMapStoreDataTypeCorrectly() throws SQLException {
        when(resultSet.getInt("id_type_rapport")).thenReturn(1);
        when(resultSet.getString("id_fnd_code")).thenReturn("FND001");
        when(resultSet.getString("id_unit_code")).thenReturn("UNIT001");
        when(resultSet.getDate("date_echeance")).thenReturn(null);
        when(resultSet.getInt("id_suivi")).thenReturn(100);
        when(resultSet.getInt("id_langue")).thenReturn(1);
        when(resultSet.getString("societe")).thenReturn("SocGen");
        when(resultSet.getString("code_langue")).thenReturn("FR");
        when(resultSet.getInt("gabarit_source")).thenReturn(2);
        when(resultSet.getInt("id_suivi_gabarit_source")).thenReturn(50);
        when(resultSet.getInt("integrer_n1")).thenReturn(1);
        when(resultSet.getInt("mode_compart")).thenReturn(1);
        when(resultSet.getString("runtype")).thenReturn("Manual");
        when(resultSet.getInt("generate_to_word")).thenReturn(1);
        when(resultSet.getInt("id_gabarit")).thenReturn(200);
        when(resultSet.getInt("id_gabarit_template")).thenReturn(300);
        when(resultSet.getInt("id_doc_pdf")).thenReturn(111);
        when(resultSet.getInt("id_doc_qxp")).thenReturn(222);
        when(resultSet.getInt("id_doc_doc")).thenReturn(333);
        when(resultSet.getInt("pagination_double")).thenReturn(0);
        when(resultSet.getInt("store_data_type")).thenReturn(2);
        when(resultSet.wasNull()).thenReturn(false);

        RunProperties props = mapper.mapFromResultSet(resultSet);

        assertEquals(StoreDataType.DOCUMENT, props.getStoreDataType());
    }

    private void setupBasicResultSet() throws SQLException {
        when(resultSet.getInt("id_type_rapport")).thenReturn(1);
        when(resultSet.getString("id_fnd_code")).thenReturn("FND001");
        when(resultSet.getString("id_unit_code")).thenReturn("UNIT001");
        when(resultSet.getDate("date_echeance")).thenReturn(Date.valueOf(LocalDate.of(2024, 12, 31)));
        when(resultSet.getInt("id_suivi")).thenReturn(100);
        when(resultSet.getInt("id_langue")).thenReturn(1);
        when(resultSet.getString("societe")).thenReturn("SocGen");
        when(resultSet.getString("code_langue")).thenReturn("FR");
        when(resultSet.getInt("gabarit_source")).thenReturn(2);
        when(resultSet.getInt("id_suivi_gabarit_source")).thenReturn(50);
        when(resultSet.getInt("integrer_n1")).thenReturn(1);
        when(resultSet.getInt("mode_compart")).thenReturn(1);
        when(resultSet.getString("runtype")).thenReturn("Manual");
        when(resultSet.getInt("generate_to_word")).thenReturn(1);
        when(resultSet.getInt("id_gabarit")).thenReturn(200);
        when(resultSet.getInt("id_gabarit_template")).thenReturn(300);
        when(resultSet.getInt("id_doc_pdf")).thenReturn(111);
        when(resultSet.getInt("id_doc_qxp")).thenReturn(222);
        when(resultSet.getInt("id_doc_doc")).thenReturn(333);
        when(resultSet.getInt("pagination_double")).thenReturn(0);
        when(resultSet.getInt("store_data_type")).thenReturn(1);
        when(resultSet.wasNull()).thenReturn(false);
    }
}
