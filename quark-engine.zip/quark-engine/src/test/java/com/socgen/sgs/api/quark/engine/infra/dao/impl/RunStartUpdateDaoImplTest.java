package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunStatus;
import com.socgen.sgs.api.quark.engine.infra.dao.RunStartUpdateDao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.util.ReflectionTestUtils;

import javax.sql.DataSource;
import java.time.LocalDateTime;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("RunStartUpdateDaoImpl Tests")
class RunStartUpdateDaoImplTest {

    @Mock
    private DataSource dataSource;

    @Mock
    private SimpleJdbcCall simpleJdbcCall;

    private RunStartUpdateDao dao;
    private Run run;

    @BeforeEach
    void setUp() {
        dao = new RunStartUpdateDaoImpl(dataSource);
        ReflectionTestUtils.setField(dao, "startRunCall", simpleJdbcCall);

        run = new Run();
        run.setId(77);
        run.setStatus(RunStatus.RUNNING);
        run.setStartDate(LocalDateTime.now());
    }

    @Test
    @DisplayName("Should execute startRun procedure successfully")
    void shouldExecuteStartRunProcedure() {
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(Map.of());

        assertDoesNotThrow(() -> dao.startRun(run));

        verify(simpleJdbcCall, times(1)).execute(any(SqlParameterSource.class));
    }

    @Test
    @DisplayName("Should use current time when run startDate is null")
    void shouldUseCurrentTimeWhenStartDateNull() {
        run.setStartDate(null);
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(Map.of());

        assertDoesNotThrow(() -> dao.startRun(run));

        verify(simpleJdbcCall, times(1)).execute(any(SqlParameterSource.class));
    }

    @Test
    @DisplayName("Should throw RuntimeException when procedure call fails")
    void shouldThrowRuntimeExceptionOnFailure() {
        when(simpleJdbcCall.execute(any(SqlParameterSource.class)))
                .thenThrow(new RuntimeException("db error"));

        assertThrows(RuntimeException.class, () -> dao.startRun(run));
    }

    @Test
    @DisplayName("Should include correct status code in parameters")
    void shouldIncludeStatusCodeInParams() {
        run.setStatus(RunStatus.TO_GENERATE);
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(Map.of());

        dao.startRun(run);

        verify(simpleJdbcCall).execute(any(SqlParameterSource.class));
    }
}
