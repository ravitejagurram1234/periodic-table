package com.socgen.sgs.api.quark.engine.domain;

import com.socgen.sgs.api.quark.engine.enums.GabaritSourceEnum;
import com.socgen.sgs.api.quark.engine.enums.TypeRapportEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("RunProperties Tests")
class RunPropertiesTest {

    private RunProperties runProperties;

    @BeforeEach
    void setUp() {
        runProperties = new RunProperties();
    }

    @Test
    @DisplayName("Should create RunProperties with default values")
    void shouldCreateRunPropertiesWithDefaults() {
        assertEquals(TypeRapportEnum.UNKNOWN, runProperties.getTypeRapport());
        assertEquals(GabaritSourceEnum.DOCUMENT_COURANT, runProperties.getGabaritSource());
        assertEquals(RunProperties.PAGINATION_SIMPLE, runProperties.getNbPageBySpread());
        assertTrue(runProperties.isIntegrerN1());
        assertFalse(runProperties.isGenerateToWord());
        assertEquals(StoreDataType.NONE.getCode(), runProperties.getStoreDataTypeCode());
    }

    @Test
    @DisplayName("Should set and get all properties")
    void shouldSetAndGetAllProperties() {
        runProperties.setTypeRapport(TypeRapportEnum.RAPPORT_ANNUEL);
        runProperties.setIdFndCode("FND123");
        runProperties.setIdUnitCode("UNIT456");
        runProperties.setIdSuivi(100);
        runProperties.setDateEcheance(LocalDate.of(2024, 12, 31));
        runProperties.setIdLangue(2);
        runProperties.setSociete("SocGen");
        runProperties.setCodeLangue("FR");
        runProperties.setGabaritSource(GabaritSourceEnum.GABARIT);
        runProperties.setIdGabarit(999);
        runProperties.setRunId(5000);

        assertEquals(TypeRapportEnum.RAPPORT_ANNUEL, runProperties.getTypeRapport());
        assertEquals("FND123", runProperties.getIdFndCode());
        assertEquals("UNIT456", runProperties.getIdUnitCode());
        assertEquals(100, runProperties.getIdSuivi());
        assertEquals(LocalDate.of(2024, 12, 31), runProperties.getDateEcheance());
        assertEquals(2, runProperties.getIdLangue());
        assertEquals("SocGen", runProperties.getSociete());
        assertEquals("FR", runProperties.getCodeLangue());
        assertEquals(GabaritSourceEnum.GABARIT, runProperties.getGabaritSource());
        assertEquals(999, runProperties.getIdGabarit());
        assertEquals(5000, runProperties.getRunId());
    }

    @Test
    @DisplayName("Should handle pagination constants")
    void shouldHandlePaginationConstants() {
        assertEquals(1, RunProperties.PAGINATION_SIMPLE);
        assertEquals(2, RunProperties.PAGINATION_DOUBLE);
    }

    @Test
    @DisplayName("Should set pagination double")
    void shouldSetPaginationDouble() {
        runProperties.setNbPageBySpread(RunProperties.PAGINATION_DOUBLE);

        assertEquals(RunProperties.PAGINATION_DOUBLE, runProperties.getNbPageBySpread());
    }

    @Test
    @DisplayName("Should calculate pool path correctly")
    void shouldCalculatePoolPathCorrectly() {
        runProperties.setRunId(4546);

        String poolPath = runProperties.getPoolPath("D_432.pdf");

        assertEquals("R_4546/D_432.pdf", poolPath);
    }

    @Test
    @DisplayName("Should calculate pool path with null runId")
    void shouldCalculatePoolPathWithNullRunId() {
        runProperties.setRunId(null);

        String poolPath = runProperties.getPoolPath("D_432.pdf");

        assertEquals("D_432.pdf", poolPath);
    }

    @Test
    @DisplayName("Should calculate pool path with null fileName")
    void shouldCalculatePoolPathWithNullFileName() {
        runProperties.setRunId(4546);

        String poolPath = runProperties.getPoolPath(null);

        assertNull(poolPath);
    }

    @Test
    @DisplayName("Should calculate absolute pool path correctly")
    void shouldCalculateAbsolutePoolPathCorrectly() {
        runProperties.setRunId(4546);

        String absolutePath = runProperties.getPoolPathAbsolute("D_432.pdf", "D:\\Documents");

        assertEquals("D:\\Documents\\R_4546\\D_432.pdf", absolutePath);
    }

    @Test
    @DisplayName("Should calculate absolute pool path with null parameters")
    void shouldCalculateAbsolutePoolPathWithNullParameters() {
        String result1 = runProperties.getPoolPathAbsolute("D_432.pdf", null);
        assertEquals("D_432.pdf", result1);

        String result2 = runProperties.getPoolPathAbsolute(null, "D:\\Documents");
        assertEquals(null, result2);

        String result3 = runProperties.getPoolPathAbsolute(null, null);
        assertEquals(null, result3);
    }

    @Test
    @DisplayName("Should handle MIN_VALUE for ids")
    void shouldHandleMinValueForIds() {
        assertEquals(Integer.MIN_VALUE, runProperties.getIdSuiviGabaritSource());
        assertEquals(Integer.MIN_VALUE, runProperties.getIdGabarit());
        assertEquals(Integer.MIN_VALUE, runProperties.getIdGabaritTemplate());
        assertEquals(Integer.MIN_VALUE, runProperties.getIdLastPdf());
        assertEquals(Integer.MIN_VALUE, runProperties.getIdLastQxp());
        assertEquals(Integer.MIN_VALUE, runProperties.getIdLastDoc());
    }

    @Test
    @DisplayName("Should set and get run type")
    void shouldSetAndGetRunType() {
        runProperties.setRunType("Manual");

        assertEquals("Manual", runProperties.getRunType());
    }

    @Test
    @DisplayName("Should set and get file tracking properties")
    void shouldSetAndGetFileTrackingProperties() {
        runProperties.setIdLastPdf(111);
        runProperties.setIdLastQxp(222);
        runProperties.setIdLastDoc(333);

        assertEquals(111, runProperties.getIdLastPdf());
        assertEquals(222, runProperties.getIdLastQxp());
        assertEquals(333, runProperties.getIdLastDoc());
    }

    @Test
    @DisplayName("Should set store data type code")
    void shouldSetStoreDataType() {
        runProperties.setStoreDataTypeCode(StoreDataType.DOCUMENT.getCode());

        assertEquals(StoreDataType.DOCUMENT.getCode(), runProperties.getStoreDataTypeCode());
    }

    @Test
    @DisplayName("Combined store type 0x03 enables both SQL and DOCUMENT (no collapse to NONE)")
    void shouldHonourCombinedStoreType() {
        runProperties.setStoreDataTypeCode(0x03);

        assertTrue(StoreDataType.hasFlag(runProperties.getStoreDataTypeCode(), StoreDataType.SQL));
        assertTrue(StoreDataType.hasFlag(runProperties.getStoreDataTypeCode(), StoreDataType.DOCUMENT));
    }

    @Test
    @DisplayName("Should set compartiment mode")
    void shouldSetCompartimentMode() {
        runProperties.setCompartimentMode(TaskCompartimentMode.GENERATE);

        assertEquals(TaskCompartimentMode.GENERATE, runProperties.getCompartimentMode());
    }
}

