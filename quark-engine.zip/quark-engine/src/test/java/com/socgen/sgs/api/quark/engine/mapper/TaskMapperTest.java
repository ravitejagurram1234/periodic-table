package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DBreakRules;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DMasterPage;
import com.socgen.sgs.api.quark.engine.domain.task.*;
import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

@DisplayName("TaskMapper Tests")
class TaskMapperTest {

    private TaskMapper mapper;
    private Run run;

    @BeforeEach
    void setUp() {
        mapper = new TaskMapper(mock(com.socgen.sgs.api.quark.engine.domain.port.FilePoolPort.class));
        run = new Run();
        run.setId(100);
    }

    // --- SQL task mapping ---

    @Test
    @DisplayName("Should map SQL task with all fields")
    void shouldMapSqlTask() {
        Map<String, Object> row = buildBaseRow(10, 1);
        row.put("SQL", "SELECT 1 FROM DUAL");
        row.put("AFFICHER_ZERO", 1);
        row.put("NB_DECIMAL", 2);
        row.put("DECIMAL_SIGNIFICATIVE", 1);
        row.put("STORE_DATA", 0);
        row.put("OUTPUT_DATA_TYPE", 1);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertInstanceOf(TaskSql.class, result);
        TaskSql task = (TaskSql) result;
        assertEquals(10, task.getId());
        assertEquals("SELECT 1 FROM DUAL", task.getSql());
        assertTrue(task.isShowZero());
        assertEquals(2, task.getNbDecimal());
        assertTrue(task.isDecimalSignificative());
        assertFalse(task.isStoreData());
        assertEquals(DataTypeEnum.TEXT, task.getDataType());
    }

    @Test
    @DisplayName("Should map SQL task with unknown data type gracefully")
    void shouldHandleUnknownDataTypeInSqlTask() {
        Map<String, Object> row = buildBaseRow(11, 1);
        row.put("SQL", "");
        row.put("AFFICHER_ZERO", 0);
        row.put("NB_DECIMAL", 0);
        row.put("DECIMAL_SIGNIFICATIVE", 0);
        row.put("STORE_DATA", 0);
        row.put("OUTPUT_DATA_TYPE", 999);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertInstanceOf(TaskSql.class, result);
        // fromCode(999) returns UNSPECIFIED — no exception thrown
        assertEquals(DataTypeEnum.UNSPECIFIED, ((TaskSql) result).getDataType());
    }

    // --- DOC_EOS task mapping ---

    @Test
    @DisplayName("Should map DOC_EOS task with all fields")
    void shouldMapDocEosTask() {
        Map<String, Object> row = buildBaseRow(20, 2);
        row.put("FORMAT", "PDF");
        row.put("ROTATION_IMAGE", 1);
        row.put("ID_SOUS_CATEGORIE", 5);
        row.put("CROP_IMAGE_VALUES", "10,20,30,40");
        row.put("CONSERVER_STYLE", 0);
        row.put("BLOC_SOURCE", "src_bloc");
        row.put("BLOC_DESTINATION", "dest_bloc");
        row.put("POSITION_IMAGE", "0,0,100,100");

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertInstanceOf(TaskDocument.class, result);
        TaskDocument task = (TaskDocument) result;
        assertEquals(20, task.getId());
        assertEquals("PDF", task.getFormatDocument());
        assertTrue(task.isRotationImage());
        assertEquals(5, task.getIdSousCategorie());
        assertEquals("10,20,30,40", task.getOffsetValues());
        assertFalse(task.isConserverStyle());
        assertEquals("src_bloc", task.getSourceBlocName());
        assertEquals("dest_bloc", task.getDestinationBlocName());
        assertEquals("0,0,100,100", task.getPositionValues());
    }

    // --- DOC_QXP task mapping ---

    @Test
    @DisplayName("Should map DOC_QXP task with all fields")
    void shouldMapDocQxpTask() {
        Map<String, Object> row = buildBaseRow(30, 3);
        row.put("CONSERVER_STYLE", 1);
        row.put("PREVIOUS_TYPE_RAPPORT", "PREV_TYPE");
        row.put("BLOC_SOURCE", "qxp_src");
        row.put("BLOC_DESTINATION", "qxp_dest");

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertInstanceOf(TaskQxpPrevious.class, result);
        TaskQxpPrevious task = (TaskQxpPrevious) result;
        assertEquals(30, task.getId());
        assertTrue(task.isConserverStyle());
        assertEquals("PREV_TYPE", task.getPreviousTypeRapport());
        assertEquals("qxp_src", task.getSourceBlocName());
        assertEquals("qxp_dest", task.getDestinationBlocName());
    }

    // --- SQL_DYNAMIQUE task mapping ---

    @Test
    @DisplayName("Should map SQL_DYNAMIQUE task with all fields including rules and master page")
    void shouldMapDynamiqueTaskWithRules() {
        Map<String, Object> row = buildBaseRow(40, 4);
        row.put("SQL", "SELECT * FROM TABLE");
        row.put("BLOC_DESTINATION", "dyn_dest");
        row.put("CONTROL_OVERFLOW", 1);
        row.put("NEW_PAGE_TABLE", 1);
        row.put("NB_COLUMN", 3);
        row.put("COLUMN_SPACE", new BigDecimal("2.5"));
        row.put("CODE_MASTER_PAGE", "5|6");
        row.put("PAGE_BREAK_RULES", "1:2|3:4");
        row.put("COLUMN_BREAK_RULES", "5:6");
        row.put("STORE_DATA", 1);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertInstanceOf(TaskDynamique.class, result);
        TaskDynamique task = (TaskDynamique) result;
        assertEquals(40, task.getId());
        assertEquals("SELECT * FROM TABLE", task.getSql());
        assertEquals("dyn_dest", task.getDestinationBlocName());
        assertTrue(task.isControlOverflow());
        assertTrue(task.isNewPageTable());
        assertEquals(3, task.getNbColumn());
        assertEquals(new BigDecimal("2.5"), task.getColumnSpace());
        assertNotSame(DMasterPage.DEFAULT, task.getMasterPage());
        assertNotSame(DBreakRules.DEFAULT, task.getPageBreakRules());
        assertNotSame(DBreakRules.DEFAULT, task.getColumnBreakRules());
        assertTrue(task.isStoreData());
    }

    @Test
    @DisplayName("Should map SQL_DYNAMIQUE task with defaults when optional fields are null")
    void shouldMapDynamiqueTaskWithDefaults() {
        Map<String, Object> row = buildBaseRow(41, 4);
        row.put("SQL", "SELECT 1");
        row.put("BLOC_DESTINATION", "dest");
        row.put("CONTROL_OVERFLOW", 0);
        row.put("NEW_PAGE_TABLE", 0);
        row.put("NB_COLUMN", 1);
        row.put("STORE_DATA", 0);
        // CODE_MASTER_PAGE, PAGE_BREAK_RULES, COLUMN_BREAK_RULES, COLUMN_SPACE not set

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        TaskDynamique task = (TaskDynamique) result;
        assertSame(DMasterPage.DEFAULT, task.getMasterPage());
        assertSame(DBreakRules.DEFAULT, task.getPageBreakRules());
        assertSame(DBreakRules.DEFAULT, task.getColumnBreakRules());
    }

    @Test
    @DisplayName("Should map SQL_DYNAMIQUE task with Number column space (not BigDecimal)")
    void shouldMapDynamiqueTaskWithNumberColumnSpace() {
        Map<String, Object> row = buildBaseRow(42, 4);
        row.put("SQL", "SELECT 1");
        row.put("BLOC_DESTINATION", "dest");
        row.put("CONTROL_OVERFLOW", 0);
        row.put("NEW_PAGE_TABLE", 0);
        row.put("NB_COLUMN", 1);
        row.put("STORE_DATA", 0);
        row.put("COLUMN_SPACE", 3.0);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        TaskDynamique task = (TaskDynamique) result;
        assertEquals(0, BigDecimal.valueOf(3.0).compareTo(task.getColumnSpace()));
    }

    // --- COMPARTIMENTS task mapping ---

    @Test
    @DisplayName("Should map COMPARTIMENTS task with master page")
    void shouldMapCompartimentTask() {
        Map<String, Object> row = buildBaseRow(50, 5);
        row.put("BLOC_DESTINATION", "comp_dest");
        row.put("ID_GABARIT_FILS", 77);
        row.put("CODE_MASTER_PAGE", "9");

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertInstanceOf(TaskCompartiment.class, result);
        TaskCompartiment task = (TaskCompartiment) result;
        assertEquals(50, task.getId());
        assertEquals("comp_dest", task.getDestinationBlocName());
        assertEquals(77, task.getIdGabaritFils());
        assertNotSame(DMasterPage.DEFAULT, task.getMasterPage());
    }

    @Test
    @DisplayName("Should map COMPARTIMENTS task with default master page when null")
    void shouldMapCompartimentTaskWithDefaultMasterPage() {
        Map<String, Object> row = buildBaseRow(51, 5);
        row.put("BLOC_DESTINATION", "comp_dest");
        row.put("ID_GABARIT_FILS", 88);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        TaskCompartiment task = (TaskCompartiment) result;
        assertSame(DMasterPage.DEFAULT, task.getMasterPage());
    }

    // --- Unknown/SYSTEM task type ---

    @Test
    @DisplayName("Should return null for unknown task type (SYSTEM = 0)")
    void shouldReturnNullForUnknownTaskType() {
        Map<String, Object> row = buildBaseRow(99, 0);

        TaskBase result = mapper.mapToTask(row, run);

        assertNull(result);
    }

    @Test
    @DisplayName("Should return null for unmapped task type code")
    void shouldReturnNullForUnmappedCode() {
        Map<String, Object> row = buildBaseRow(99, 999);

        TaskBase result = mapper.mapToTask(row, run);

        assertNull(result);
    }

    // --- Common fields mapping ---

    @Test
    @DisplayName("Should map common fields (CHAMPS_VIDE, TODO, COMMENTAIRE)")
    void shouldMapCommonFields() {
        Map<String, Object> row = buildBaseRow(10, 1);
        row.put("SQL", "SELECT 1");
        row.put("AFFICHER_ZERO", 0);
        row.put("NB_DECIMAL", 0);
        row.put("DECIMAL_SIGNIFICATIVE", 0);
        row.put("STORE_DATA", 0);
        row.put("OUTPUT_DATA_TYPE", 0);
        row.put("CHAMPS_VIDE", "N/A");
        row.put("TODO", 1);
        row.put("COMMENTAIRE", "test comment");

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertEquals("N/A", result.getNullString());
        assertTrue(result.isTodo());
        assertEquals("test comment", result.getCommentaire());
    }

    @Test
    @DisplayName("Should keep default nullString when CHAMPS_VIDE is blank or null")
    void shouldKeepDefaultNullStringWhenBlank() {
        Map<String, Object> row = buildBaseRow(10, 1);
        row.put("SQL", "");
        row.put("AFFICHER_ZERO", 0);
        row.put("NB_DECIMAL", 0);
        row.put("DECIMAL_SIGNIFICATIVE", 0);
        row.put("STORE_DATA", 0);
        row.put("OUTPUT_DATA_TYPE", 0);
        row.put("CHAMPS_VIDE", "   ");
        row.put("TODO", 0);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertEquals(" ", result.getNullString());
    }

    // --- Utility method edge cases ---

    @Test
    @DisplayName("Should handle Boolean type in getBoolean")
    void shouldHandleBooleanType() {
        Map<String, Object> row = buildBaseRow(10, 1);
        row.put("SQL", "");
        row.put("AFFICHER_ZERO", Boolean.TRUE);
        row.put("NB_DECIMAL", 0);
        row.put("DECIMAL_SIGNIFICATIVE", 0);
        row.put("STORE_DATA", 0);
        row.put("OUTPUT_DATA_TYPE", 0);
        row.put("TODO", 0);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertTrue(((TaskSql) result).isShowZero());
    }

    @Test
    @DisplayName("Should return false for non-number non-boolean in getBoolean")
    void shouldReturnFalseForStringInBooleanField() {
        Map<String, Object> row = buildBaseRow(10, 1);
        row.put("SQL", "");
        row.put("AFFICHER_ZERO", "not_a_number");
        row.put("NB_DECIMAL", 0);
        row.put("DECIMAL_SIGNIFICATIVE", 0);
        row.put("STORE_DATA", 0);
        row.put("OUTPUT_DATA_TYPE", 0);
        row.put("TODO", 0);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertFalse(((TaskSql) result).isShowZero());
    }

    @Test
    @DisplayName("Should return 0 for non-number in getInt")
    void shouldReturnZeroForNonNumberInGetInt() {
        Map<String, Object> row = new HashMap<>();
        row.put("ID_TACHE", "not_a_number");
        row.put("ID_TYPE_TACHE", 1);
        row.put("SQL", "");
        row.put("AFFICHER_ZERO", 0);
        row.put("NB_DECIMAL", 0);
        row.put("DECIMAL_SIGNIFICATIVE", 0);
        row.put("STORE_DATA", 0);
        row.put("OUTPUT_DATA_TYPE", 0);
        row.put("TODO", 0);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertEquals(0, result.getId());
    }

    @Test
    @DisplayName("Should return null string for null value in getString")
    void shouldReturnNullForNullStringField() {
        Map<String, Object> row = buildBaseRow(10, 1);
        row.put("SQL", null);
        row.put("AFFICHER_ZERO", 0);
        row.put("NB_DECIMAL", 0);
        row.put("DECIMAL_SIGNIFICATIVE", 0);
        row.put("STORE_DATA", 0);
        row.put("OUTPUT_DATA_TYPE", 0);
        row.put("TODO", 0);

        TaskBase result = mapper.mapToTask(row, run);

        assertNotNull(result);
        assertNull(((TaskSql) result).getSql());
    }

    // --- Helper ---

    private Map<String, Object> buildBaseRow(int idTache, int idTypeTache) {
        Map<String, Object> row = new HashMap<>();
        row.put("ID_TACHE", idTache);
        row.put("ID_TYPE_TACHE", idTypeTache);
        row.put("CHAMPS_VIDE", null);
        row.put("TODO", 0);
        row.put("COMMENTAIRE", null);
        return row;
    }
}

