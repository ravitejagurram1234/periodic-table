package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;
import com.socgen.sgs.api.quark.engine.infra.dao.GetRunPropertiesDao;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("GetRunPropertiesBusiness Tests")
class GetRunPropertiesBusinessTest {

    @InjectMocks
    private GetRunPropertiesBusiness getRunPropertiesBusiness;

    @Mock
    private GetRunPropertiesDao getRunPropertiesDao;

    @Test
    @DisplayName("Should return run properties from DAO")
    void shouldReturnRunPropertiesFromDao() {
        RunIdDto runIdDto = new RunIdDto(100);
        RunProperties expected = new RunProperties();
        expected.setRunId(100);
        when(getRunPropertiesDao.getRunProperties(runIdDto)).thenReturn(expected);

        RunProperties result = getRunPropertiesBusiness.execute(runIdDto);

        assertNotNull(result);
        assertSame(expected, result);
        verify(getRunPropertiesDao, times(1)).getRunProperties(runIdDto);
    }

    @Test
    @DisplayName("Should delegate to DAO with the exact RunIdDto")
    void shouldDelegateDaoWithExactDto() {
        RunIdDto runIdDto = new RunIdDto(55);
        RunProperties props = new RunProperties();
        when(getRunPropertiesDao.getRunProperties(runIdDto)).thenReturn(props);

        getRunPropertiesBusiness.execute(runIdDto);

        verify(getRunPropertiesDao).getRunProperties(same(runIdDto));
    }
}
