package com.socgen.sgs.api.quark.engine.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("DocumentFormatEnum Tests")
class DocumentFormatEnumTest {

    @Test
    @DisplayName("Should have correct format values")
    void shouldHaveCorrectFormatValues() {
        assertEquals("PDF", DocumentFormatEnum.PDF.getFormat());
        assertEquals("QXP", DocumentFormatEnum.QXP.getFormat());
        assertEquals("DOC", DocumentFormatEnum.DOC.getFormat());
    }

    @Test
    @DisplayName("Should get from format string")
    void shouldGetFromFormatString() {
        assertEquals(DocumentFormatEnum.PDF, DocumentFormatEnum.fromFormat("PDF"));
        assertEquals(DocumentFormatEnum.QXP, DocumentFormatEnum.fromFormat("QXP"));
    }

    @Test
    @DisplayName("Should handle case-insensitive format")
    void shouldHandleCaseInsensitiveFormat() {
        assertEquals(DocumentFormatEnum.PDF, DocumentFormatEnum.fromFormat("pdf"));
    }

    @Test
    @DisplayName("Should return null for invalid format")
    void shouldReturnNullForInvalidFormat() {
        assertNull(DocumentFormatEnum.fromFormat("INVALID"));
        assertNull(DocumentFormatEnum.fromFormat(null));
    }
}

