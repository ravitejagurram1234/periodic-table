package com.socgen.sgs.api.quark.engine.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TaskActionTypeEnum Tests")
class TaskActionTypeEnumTest {

    @Test
    @DisplayName("Should have correct enum values")
    void shouldHaveCorrectEnumValues() {
        assertEquals(4, TaskActionTypeEnum.values().length);
    }

    @Test
    @DisplayName("Should convert valid name")
    void shouldConvertValidName() {
        assertEquals(TaskActionTypeEnum.UPDATE, TaskActionTypeEnum.fromName("UPDATE"));
        assertEquals(TaskActionTypeEnum.CREATE, TaskActionTypeEnum.fromName("CREATE"));
    }

    @Test
    @DisplayName("Should handle case-insensitive conversion")
    void shouldHandleCaseInsensitiveConversion() {
        assertEquals(TaskActionTypeEnum.UPDATE, TaskActionTypeEnum.fromName("update"));
    }

    @Test
    @DisplayName("Should return NONE for invalid")
    void shouldReturnNoneForInvalid() {
        assertEquals(TaskActionTypeEnum.NONE, TaskActionTypeEnum.fromName("INVALID"));
        assertEquals(TaskActionTypeEnum.NONE, TaskActionTypeEnum.fromName(null));
    }
}

