package com.socgen.sgs.api.quark.engine.domain.bloc;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("BlocBase Tests")
class BlocBaseTest {

    private BlocBase bloc;
    private TaskBase stubTask;

    @BeforeEach
    void setUp() {
        Run run = new Run();
        RunProperties props = new RunProperties();
        props.setNbPageBySpread(RunProperties.PAGINATION_DOUBLE);
        run.setRunProperties(props);

        stubTask = new TaskBase(1, run) {
            @Override public void prepare() {}
        };

        bloc = new BlocBase(stubTask, "testBloc");
    }

    @Test
    @DisplayName("Should create BlocBase with name")
    void shouldCreateBlocBaseWithName() {
        assertEquals("testBloc", bloc.getName());
    }

    @Test
    @DisplayName("Should have default values")
    void shouldHaveDefaultValues() {
        assertEquals("", bloc.getParentName());
        assertEquals(BlocActionEnum.NONE, bloc.getAction());
        assertEquals("", bloc.getCondName());
        assertEquals(0, bloc.getRelativePage());
        assertEquals(Integer.MIN_VALUE, bloc.getPageId());
        assertEquals(Integer.MIN_VALUE, bloc.getPageIdOriginale());
        assertFalse(bloc.isPagination());
        assertEquals(4, bloc.getIndexMaquette());
        assertFalse(bloc.isLagSpread());
        assertFalse(bloc.isExclude());
    }

    @Test
    @DisplayName("Should set and get all properties")
    void shouldSetAndGetAllProperties() {
        bloc.setParentName("parentBloc");
        bloc.setAction(BlocActionEnum.CREATE);
        bloc.setCondName("condBloc");
        bloc.setRelativePage(5);
        bloc.setPageId(10);
        bloc.setPageIdOriginale(10);
        bloc.setPagination(true);
        bloc.setIndexMaquette(2);
        bloc.setLagSpread(true);
        bloc.setExclude(true);

        assertEquals("parentBloc", bloc.getParentName());
        assertEquals(BlocActionEnum.CREATE, bloc.getAction());
        assertEquals("condBloc", bloc.getCondName());
        assertEquals(5, bloc.getRelativePage());
        assertEquals(10, bloc.getPageId());
        assertEquals(10, bloc.getPageIdOriginale());
        assertTrue(bloc.isPagination());
        assertEquals(2, bloc.getIndexMaquette());
        assertTrue(bloc.isLagSpread());
        assertTrue(bloc.isExclude());
    }

    @Test
    @DisplayName("Should get default number of boxes")
    void shouldGetDefaultNumberOfBoxes() {
        assertEquals(1, bloc.getNbBox());
    }

    @Test
    @DisplayName("Should calculate spread ID correctly")
    void shouldCalculateSpreadIdCorrectly() {
        bloc.setPageId(1);
        assertEquals(1, bloc.getSpreadId());

        bloc.setPageId(2);
        assertEquals(2, bloc.getSpreadId());

        bloc.setPageId(3);
        assertEquals(2, bloc.getSpreadId());

        bloc.setPageId(4);
        assertEquals(3, bloc.getSpreadId());

        bloc.setPageId(5);
        assertEquals(3, bloc.getSpreadId());
    }

    @Test
    @DisplayName("Should handle different bloc actions")
    void shouldHandleDifferentBlocActions() {
        bloc.setAction(BlocActionEnum.NONE);
        assertEquals(BlocActionEnum.NONE, bloc.getAction());

        bloc.setAction(BlocActionEnum.UPDATE);
        assertEquals(BlocActionEnum.UPDATE, bloc.getAction());

        bloc.setAction(BlocActionEnum.CREATE);
        assertEquals(BlocActionEnum.CREATE, bloc.getAction());

        bloc.setAction(BlocActionEnum.REMOVE);
        assertEquals(BlocActionEnum.REMOVE, bloc.getAction());

        bloc.setAction(BlocActionEnum.MOVE);
        assertEquals(BlocActionEnum.MOVE, bloc.getAction());
    }

    @Test
    @DisplayName("Should handle MIN_VALUE page IDs")
    void shouldHandleMinValuePageIds() {
        assertEquals(Integer.MIN_VALUE, bloc.getPageId());
        assertEquals(Integer.MIN_VALUE, bloc.getPageIdOriginale());

        bloc.setPageId(Integer.MIN_VALUE);
        bloc.setPageIdOriginale(Integer.MIN_VALUE);

        assertEquals(Integer.MIN_VALUE, bloc.getPageId());
        assertEquals(Integer.MIN_VALUE, bloc.getPageIdOriginale());
    }

    @Test
    @DisplayName("Should handle various index maquette values")
    void shouldHandleVariousIndexMaquetteValues() {
        bloc.setIndexMaquette(1);
        assertEquals(1, bloc.getIndexMaquette());

        bloc.setIndexMaquette(10);
        assertEquals(10, bloc.getIndexMaquette());

        bloc.setIndexMaquette(0);
        assertEquals(0, bloc.getIndexMaquette());
    }
}

