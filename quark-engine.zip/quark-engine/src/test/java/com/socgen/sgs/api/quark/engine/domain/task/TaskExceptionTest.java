package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.enums.TaskExceptionTypeEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TaskException Tests")
class TaskExceptionTest {

    @Test
    @DisplayName("Should create TaskException with all parameters")
    void shouldCreateTaskExceptionWithAllParameters() {
        int[] indexLignes = {1, 2, 3};
        TaskException exception = new TaskException("tableName", "blocName", indexLignes, TaskExceptionTypeEnum.LINE);

        assertEquals("tableName", exception.getTableName());
        assertEquals("blocName", exception.getName());
        assertArrayEquals(indexLignes, exception.getIndexLignes());
        assertEquals(TaskExceptionTypeEnum.LINE, exception.getType());
    }

    @Test
    @DisplayName("Should set and get table name")
    void shouldSetAndGetTableName() {
        TaskException exception = new TaskException("table1", "bloc1", new int[]{1}, TaskExceptionTypeEnum.LINE);
        exception.setTableName("newTable");

        assertEquals("newTable", exception.getTableName());
    }

    @Test
    @DisplayName("Should set and get name")
    void shouldSetAndGetName() {
        TaskException exception = new TaskException("table1", "bloc1", new int[]{1}, TaskExceptionTypeEnum.LINE);
        exception.setName("newBloc");

        assertEquals("newBloc", exception.getName());
    }

    @Test
    @DisplayName("Should set and get index lignes")
    void shouldSetAndGetIndexLignes() {
        int[] originalIndexes = {1, 2};
        TaskException exception = new TaskException("table1", "bloc1", originalIndexes, TaskExceptionTypeEnum.LINE);

        int[] newIndexes = {5, 6, 7};
        exception.setIndexLignes(newIndexes);

        assertArrayEquals(newIndexes, exception.getIndexLignes());
    }

    @Test
    @DisplayName("Should set and get exception type")
    void shouldSetAndGetExceptionType() {
        TaskException exception = new TaskException("table1", "bloc1", new int[]{1}, TaskExceptionTypeEnum.LINE);
        exception.setType(TaskExceptionTypeEnum.TABLE);

        assertEquals(TaskExceptionTypeEnum.TABLE, exception.getType());
    }

    @Test
    @DisplayName("Should handle empty index lignes array")
    void shouldHandleEmptyIndexLignesArray() {
        int[] emptyIndexes = {};
        TaskException exception = new TaskException("table1", "bloc1", emptyIndexes, TaskExceptionTypeEnum.LINE);

        assertEquals(0, exception.getIndexLignes().length);
    }

    @Test
    @DisplayName("Should handle single index ligne")
    void shouldHandleSingleIndexLigne() {
        int[] singleIndex = {1};
        TaskException exception = new TaskException("table1", "bloc1", singleIndex, TaskExceptionTypeEnum.TABLE);

        assertEquals(1, exception.getIndexLignes().length);
        assertEquals(1, exception.getIndexLignes()[0]);
    }

    @Test
    @DisplayName("Should handle multiple index lignes")
    void shouldHandleMultipleIndexLignes() {
        int[] multipleIndexes = {1, 2, 3, 4, 5};
        TaskException exception = new TaskException("table1", "bloc1", multipleIndexes, TaskExceptionTypeEnum.LINE);

        assertEquals(5, exception.getIndexLignes().length);
    }

    @Test
    @DisplayName("Should handle different exception types")
    void shouldHandleDifferentExceptionTypes() {
        int[] indexes = {1};

        TaskException lineException = new TaskException("table1", "bloc1", indexes, TaskExceptionTypeEnum.LINE);
        assertEquals(TaskExceptionTypeEnum.LINE, lineException.getType());

        TaskException tableException = new TaskException("table1", "bloc1", indexes, TaskExceptionTypeEnum.TABLE);
        assertEquals(TaskExceptionTypeEnum.TABLE, tableException.getType());

        TaskException groupException = new TaskException("table1", "bloc1", indexes, TaskExceptionTypeEnum.GROUP);
        assertEquals(TaskExceptionTypeEnum.GROUP, groupException.getType());

        TaskException noneException = new TaskException("table1", "bloc1", indexes, TaskExceptionTypeEnum.NONE);
        assertEquals(TaskExceptionTypeEnum.NONE, noneException.getType());
    }

    @Test
    @DisplayName("Should handle null array reference")
    void shouldHandleNullArrayReference() {
        TaskException exception = new TaskException("table1", "bloc1", null, TaskExceptionTypeEnum.LINE);

        assertNull(exception.getIndexLignes());
    }

    @Test
    @DisplayName("Should handle empty strings")
    void shouldHandleEmptyStrings() {
        TaskException exception = new TaskException("", "", new int[]{1}, TaskExceptionTypeEnum.LINE);

        assertEquals("", exception.getTableName());
        assertEquals("", exception.getName());
    }

    @Test
    @DisplayName("Should handle null strings")
    void shouldHandleNullStrings() {
        TaskException exception = new TaskException(null, null, new int[]{1}, TaskExceptionTypeEnum.LINE);

        assertNull(exception.getTableName());
        assertNull(exception.getName());
    }
}

