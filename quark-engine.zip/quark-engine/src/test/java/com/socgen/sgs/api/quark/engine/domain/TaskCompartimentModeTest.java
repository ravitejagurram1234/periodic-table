package com.socgen.sgs.api.quark.engine.domain;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TaskCompartimentMode Tests")
class TaskCompartimentModeTest {

    @Test
    @DisplayName("Should have correct codes for all enum values")
    void shouldHaveCorrectCodes() {
        assertEquals(0, TaskCompartimentMode.UNKNOWN.getCode());
        assertEquals(1, TaskCompartimentMode.GENERATE.getCode());
        assertEquals(2, TaskCompartimentMode.INCORPORATE.getCode());
        assertEquals(3, TaskCompartimentMode.GENERATE_AND_INCORPORATE.getCode());
    }

    @Test
    @DisplayName("Should get TaskCompartimentMode from valid code")
    void shouldGetTaskCompartimentModeFromValidCode() {
        assertEquals(TaskCompartimentMode.UNKNOWN, TaskCompartimentMode.fromCode(0));
        assertEquals(TaskCompartimentMode.GENERATE, TaskCompartimentMode.fromCode(1));
        assertEquals(TaskCompartimentMode.INCORPORATE, TaskCompartimentMode.fromCode(2));
        assertEquals(TaskCompartimentMode.GENERATE_AND_INCORPORATE, TaskCompartimentMode.fromCode(3));
    }

    @Test
    @DisplayName("Should return UNKNOWN for invalid code")
    void shouldReturnUnknownForInvalidCode() {
        assertEquals(TaskCompartimentMode.UNKNOWN, TaskCompartimentMode.fromCode(99));
        assertEquals(TaskCompartimentMode.UNKNOWN, TaskCompartimentMode.fromCode(-1));
        assertEquals(TaskCompartimentMode.UNKNOWN, TaskCompartimentMode.fromCode(100));
    }

    @Test
    @DisplayName("Should have all enum values")
    void shouldHaveAllEnumValues() {
        TaskCompartimentMode[] values = TaskCompartimentMode.values();

        assertEquals(4, values.length);
    }

    @Test
    @DisplayName("Should have correct enum ordering")
    void shouldHaveCorrectEnumOrdering() {
        TaskCompartimentMode[] values = TaskCompartimentMode.values();

        assertEquals(TaskCompartimentMode.UNKNOWN, values[0]);
        assertEquals(TaskCompartimentMode.GENERATE, values[1]);
        assertEquals(TaskCompartimentMode.INCORPORATE, values[2]);
        assertEquals(TaskCompartimentMode.GENERATE_AND_INCORPORATE, values[3]);
    }
}

