package com.socgen.sgs.api.quark.engine.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("BlocActionEnum Tests")
class BlocActionEnumTest {

    @Test
    @DisplayName("Should have 5 enum values")
    void shouldHave5EnumValues() {
        assertEquals(5, BlocActionEnum.values().length);
    }

    @Test
    @DisplayName("Should convert UPDATE name")
    void shouldConvertUpdateName() {
        assertEquals(BlocActionEnum.UPDATE, BlocActionEnum.fromName("UPDATE"));
    }

    @Test
    @DisplayName("Should return NONE for null")
    void shouldReturnNoneForNull() {
        assertEquals(BlocActionEnum.NONE, BlocActionEnum.fromName(null));
    }
}

