package com.socgen.sgs.api.quark.engine.service.impl;

import com.socgen.sgs.api.quark.engine.business.GetGabaritBusiness;
import com.socgen.sgs.api.quark.engine.business.GetInParamsBusiness;
import com.socgen.sgs.api.quark.engine.business.GetRunPropertiesBusiness;
import com.socgen.sgs.api.quark.engine.business.RunStartUpdateBusiness;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.domain.RunStatus;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;
import com.socgen.sgs.api.quark.engine.enums.GabaritSourceEnum;
import com.socgen.sgs.api.quark.engine.service.LoadTasksService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("ProcessRunServiceImpl Tests")
class ProcessRunServiceImplTest {

    @InjectMocks
    private ProcessRunServiceImpl processRunService;

    @Mock
    private RunStartUpdateBusiness runStartUpdateBusiness;
    @Mock
    private GetRunPropertiesBusiness getRunPropertiesBusiness;
    @Mock
    private GetGabaritBusiness getGabaritBusiness;
    @Mock
    private GetInParamsBusiness getInParamsBusiness;
    @Mock
    private LoadTasksService loadTasksService;
    @Mock
    private com.socgen.sgs.api.quark.engine.domain.port.FilePoolPort filePoolPort;
    @Mock
    private com.socgen.sgs.api.quark.engine.domain.port.DocumentIdentityPort documentIdentityPort;
    @Mock
    private com.socgen.sgs.api.quark.engine.service.ProcessTasksService processTasksService;

    private RunProperties runProperties;

    @BeforeEach
    void setUp() {
        runProperties = new RunProperties();
        runProperties.setGabaritSource(GabaritSourceEnum.GABARIT);
        runProperties.setIdGabarit(10);
    }

    // --- runProcessor ---

    @Test
    @DisplayName("Should initialise run with correct id, status and startDate then call load")
    void shouldInitialiseRunAndCallLoad() {
        when(getRunPropertiesBusiness.execute(any(RunIdDto.class))).thenReturn(runProperties);
        when(getGabaritBusiness.getAndPrepareGabarit(any(), any())).thenReturn(null);

        processRunService.runProcessor(new RunIdDto(42));

        ArgumentCaptor<Run> runCaptor = ArgumentCaptor.forClass(Run.class);
        verify(runStartUpdateBusiness).execute(runCaptor.capture());
        Run captured = runCaptor.getValue();

        assertEquals(42, captured.getId());
        assertEquals(RunStatus.TO_GENERATE, captured.getStatus());
        assertNotNull(captured.getStartDate());
    }

    @Test
    @DisplayName("Should call runStartUpdateBusiness before load")
    void shouldCallStartUpdateBeforeLoad() {
        when(getRunPropertiesBusiness.execute(any(RunIdDto.class))).thenReturn(runProperties);
        when(getGabaritBusiness.getAndPrepareGabarit(any(), any())).thenReturn(null);

        processRunService.runProcessor(new RunIdDto(1));

        verify(runStartUpdateBusiness, times(1)).execute(any(Run.class));
        verify(getRunPropertiesBusiness, times(1)).execute(any(RunIdDto.class));
        verify(loadTasksService, times(1)).loadTasks(any(Run.class));
    }

    // --- load ---

    @Test
    @DisplayName("Should set run properties and runId on the run")
    void shouldSetRunPropertiesAndRunId() {
        when(getRunPropertiesBusiness.execute(any(RunIdDto.class))).thenReturn(runProperties);
        when(getGabaritBusiness.getAndPrepareGabarit(any(), any())).thenReturn(null);

        Run run = new Run();
        run.setId(55);
        processRunService.load(run);

        assertEquals(55, run.getRunProperties().getRunId());
        assertSame(runProperties, run.getRunProperties());
    }

    @Test
    @DisplayName("Should call all four load steps in order")
    void shouldCallAllLoadStepsInOrder() {
        when(getRunPropertiesBusiness.execute(any(RunIdDto.class))).thenReturn(runProperties);
        when(getGabaritBusiness.getAndPrepareGabarit(any(), any())).thenReturn(null);

        Run run = new Run();
        run.setId(10);
        processRunService.load(run);

        var order = inOrder(getRunPropertiesBusiness, getGabaritBusiness, getInParamsBusiness, loadTasksService);
        order.verify(getRunPropertiesBusiness).execute(any(RunIdDto.class));
        order.verify(getGabaritBusiness).getAndPrepareGabarit(any(), any());
        order.verify(getInParamsBusiness).execute(run);
        order.verify(loadTasksService).loadTasks(run);
    }

    @Test
    @DisplayName("Should propagate exception thrown by runStartUpdateBusiness")
    void shouldPropagateExceptionFromStartUpdate() {
        doThrow(new RuntimeException("start failed")).when(runStartUpdateBusiness).execute(any(Run.class));

        assertThrows(RuntimeException.class, () -> processRunService.runProcessor(new RunIdDto(1)));
        verify(getRunPropertiesBusiness, never()).execute(any());
    }

    @Test
    @DisplayName("Should propagate exception thrown during load")
    void shouldPropagateExceptionFromLoad() {
        when(getRunPropertiesBusiness.execute(any(RunIdDto.class)))
                .thenThrow(new RuntimeException("properties failed"));

        Run run = new Run();
        run.setId(1);
        assertThrows(RuntimeException.class, () -> processRunService.load(run));
    }

    // --- getRunProperties ---

    @Test
    @DisplayName("Should return RunProperties from business layer")
    void shouldReturnRunPropertiesFromBusiness() {
        RunIdDto dto = new RunIdDto(99);
        when(getRunPropertiesBusiness.execute(dto)).thenReturn(runProperties);

        RunProperties result = processRunService.getRunProperties(dto);

        assertNotNull(result);
        assertSame(runProperties, result);
        verify(getRunPropertiesBusiness, times(1)).execute(dto);
    }

    // --- fetchActiveRunIds ---

    @Test
    @DisplayName("Should return empty list for fetchActiveRunIds")
    void shouldReturnEmptyListForFetchActiveRunIds() {
        List<Integer> result = processRunService.fetchActiveRunIds();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
}
