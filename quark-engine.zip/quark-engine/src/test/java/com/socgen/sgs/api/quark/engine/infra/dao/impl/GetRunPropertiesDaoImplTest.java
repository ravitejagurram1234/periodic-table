package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;
import com.socgen.sgs.api.quark.engine.infra.dao.GetRunPropertiesDao;
import com.socgen.sgs.api.quark.engine.mapper.RunPropertiesMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.util.ReflectionTestUtils;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("GetRunPropertiesDaoImpl Tests")
class GetRunPropertiesDaoImplTest {

    @Mock
    private DataSource dataSource;

    @Mock
    private RunPropertiesMapper runPropertiesMapper;

    @Mock
    private SimpleJdbcCall simpleJdbcCall;

    private GetRunPropertiesDao dao;

    @BeforeEach
    void setUp() {
        dao = new GetRunPropertiesDaoImpl(dataSource, runPropertiesMapper);
        ReflectionTestUtils.setField(dao, "getRunPropertiesCall", simpleJdbcCall);
    }

    @Test
    @DisplayName("Should return RunProperties from cursor")
    void shouldReturnRunProperties() {
        RunProperties props = new RunProperties();
        props.setRunId(100);

        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of(props));
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        RunProperties returned = dao.getRunProperties(new RunIdDto(100));

        assertNotNull(returned);
        assertEquals(100, returned.getRunId());
    }

    @Test
    @DisplayName("Should return first element when multiple rows returned")
    void shouldReturnFirstElement() {
        RunProperties first = new RunProperties();
        first.setRunId(1);
        RunProperties second = new RunProperties();
        second.setRunId(2);

        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of(first, second));
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        RunProperties returned = dao.getRunProperties(new RunIdDto(1));

        assertSame(first, returned);
    }

    @Test
    @DisplayName("Should throw IllegalArgumentException when cursor returns empty list")
    void shouldThrowWhenEmpty() {
        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of());
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        assertThrows(IllegalArgumentException.class, () -> dao.getRunProperties(new RunIdDto(99)));
    }

    @Test
    @DisplayName("Should throw IllegalArgumentException when cursor value is null")
    void shouldThrowWhenCursorNull() {
        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", null);
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        assertThrows(IllegalArgumentException.class, () -> dao.getRunProperties(new RunIdDto(99)));
    }

    @Test
    @DisplayName("Should wrap unexpected exceptions in RuntimeException")
    void shouldWrapRuntimeException() {
        when(simpleJdbcCall.execute(any(SqlParameterSource.class)))
                .thenThrow(new RuntimeException("db error"));

        assertThrows(RuntimeException.class, () -> dao.getRunProperties(new RunIdDto(1)));
    }
}
