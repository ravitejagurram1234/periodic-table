package com.socgen.sgs.api.quark.engine.performance;

import io.gatling.app.Gatling;
import io.gatling.core.config.GatlingPropertiesBuilder;
import io.gatling.core.scenario.Simulation;

public class GatlingRunner {

  public static void main(String[] args) {
    GatlingPropertiesBuilder gatlingPropertiesBuilder = new GatlingPropertiesBuilder();
    gatlingPropertiesBuilder.simulationClass(Simulation.class.getName());
    Gatling.fromMap(gatlingPropertiesBuilder.build());
  }
}
