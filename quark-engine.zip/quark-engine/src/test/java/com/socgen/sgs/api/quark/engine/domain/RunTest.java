package com.socgen.sgs.api.quark.engine.domain;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.domain.dynamic.template.Template;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Run Tests")
class RunTest {

    private Run run;

    @BeforeEach
    void setUp() {
        run = new Run();
    }

    @Test
    @DisplayName("Should create Run with no arguments")
    void shouldCreateRunWithNoArguments() {
        assertNull(run.getId());
        assertNull(run.getName());
        assertNull(run.getStatus());
        assertNull(run.getStartDate());
        assertNull(run.getRunProperties());
        assertNull(run.getGabarit());
        assertNotNull(run.getInParams());
        assertNotNull(run.getTasks());
    }

    @Test
    @DisplayName("Should create Run with all arguments")
    void shouldCreateRunWithAllArguments() {
        RunStatus status = RunStatus.TO_GENERATE;
        LocalDateTime startDate = LocalDateTime.now();
        RunProperties props = new RunProperties();
        DocumentDomain gabarit = new DocumentDomain();
        Map<String, InParam> inParams = new LinkedHashMap<>();
        Map<Integer, TaskBase> tasks = new LinkedHashMap<>();
        Map<String, Template> templates = new LinkedHashMap<>();

        Run fullRun = new Run();
        fullRun.setId(1);
        fullRun.setName("TestRun");
        fullRun.setStatus(status);
        fullRun.setStartDate(startDate);
        fullRun.setRunProperties(props);
        fullRun.setGabarit(gabarit);
        fullRun.setInParams(inParams);
        fullRun.setTasks(tasks);
        fullRun.setTemplates(templates);

        assertEquals(1, fullRun.getId());
        assertEquals("TestRun", fullRun.getName());
        assertEquals(status, fullRun.getStatus());
        assertEquals(startDate, fullRun.getStartDate());
        assertEquals(props, fullRun.getRunProperties());
        assertEquals(gabarit, fullRun.getGabarit());
    }

    @Test
    @DisplayName("Should set and get id")
    void shouldSetAndGetId() {
        run.setId(42);
        assertEquals(42, run.getId());
    }

    @Test
    @DisplayName("Should set and get name")
    void shouldSetAndGetName() {
        run.setName("MyRun");
        assertEquals("MyRun", run.getName());
    }

    @Test
    @DisplayName("Should set and get status")
    void shouldSetAndGetStatus() {
        run.setStatus(RunStatus.RUNNING);
        assertEquals(RunStatus.RUNNING, run.getStatus());
    }

    @Test
    @DisplayName("Should set and get start date")
    void shouldSetAndGetStartDate() {
        LocalDateTime now = LocalDateTime.now();
        run.setStartDate(now);
        assertEquals(now, run.getStartDate());
    }

    @Test
    @DisplayName("Should set and get run properties")
    void shouldSetAndGetRunProperties() {
        RunProperties props = new RunProperties();
        run.setRunProperties(props);
        assertEquals(props, run.getRunProperties());
    }

    @Test
    @DisplayName("Should set and get gabarit")
    void shouldSetAndGetGabarit() {
        DocumentDomain gabarit = new DocumentDomain();
        run.setGabarit(gabarit);
        assertEquals(gabarit, run.getGabarit());
    }

    @Test
    @DisplayName("Should manage in params map")
    void shouldManageInParamsMap() {
        InParam param = new InParam("param1", 1, "value1");
        run.getInParams().put("param1", param);

        assertTrue(run.getInParams().containsKey("param1"));
        assertEquals(param, run.getInParams().get("param1"));
    }

    @Test
    @DisplayName("Should have ordered in params map")
    void shouldHaveOrderedInParamsMap() {
        run.getInParams().put("param1", new InParam("p1", 1, "v1"));
        run.getInParams().put("param2", new InParam("p2", 1, "v2"));
        run.getInParams().put("param3", new InParam("p3", 1, "v3"));

        Map<String, InParam> params = run.getInParams();
        assertEquals(3, params.size());
    }

    @Test
    @DisplayName("Should throw exception when preparing gabarit without run properties")
    void shouldThrowExceptionWhenPreparingGabaritWithoutRunProperties() {
        run.setId(100);
        run.setRunProperties(null);

        assertThrows(IllegalStateException.class, () -> run.prepareGabarit(null, null, null));
    }
}

