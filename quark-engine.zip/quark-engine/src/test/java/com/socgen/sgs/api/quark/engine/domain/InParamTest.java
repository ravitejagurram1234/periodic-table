package com.socgen.sgs.api.quark.engine.domain;

import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("InParam Tests")
class InParamTest {

    @Test
    @DisplayName("Should create InParam with int type code and string value")
    void shouldCreateInParamWithIntTypeCode() {
        InParam param = new InParam("paramName", 1, "testValue");

        assertEquals("paramName", param.getName());
        assertEquals(DataTypeEnum.TEXT, param.getType());
        assertEquals("testValue", param.getStringValue());
    }

    @Test
    @DisplayName("Should create InParam with DataTypeEnum and string value")
    void shouldCreateInParamWithDataTypeEnum() {
        InParam param = new InParam("paramName", DataTypeEnum.TEXT, "testValue");

        assertEquals("paramName", param.getName());
        assertEquals(DataTypeEnum.TEXT, param.getType());
        assertEquals("testValue", param.getStringValue());
    }

    @Test
    @DisplayName("Should store numeric string as-is for INT type")
    void shouldStoreNumericStringForIntType() {
        InParam param = new InParam("intParam", DataTypeEnum.INT, "42");

        assertEquals("intParam", param.getName());
        assertEquals(DataTypeEnum.INT, param.getType());
        assertEquals("42", param.getStringValue());
    }

    @Test
    @DisplayName("Should store decimal string as-is for DECIMAL type")
    void shouldStoreDecimalString() {
        InParam param = new InParam("decimalParam", DataTypeEnum.DECIMAL, "3.14");

        assertEquals("decimalParam", param.getName());
        assertEquals(DataTypeEnum.DECIMAL, param.getType());
        assertEquals("3.14", param.getStringValue());
    }

    @Test
    @DisplayName("Should store currency string as-is for CURRENCY type")
    void shouldStoreCurrencyString() {
        InParam param = new InParam("currencyParam", DataTypeEnum.CURRENCY, "99.99");

        assertEquals("currencyParam", param.getName());
        assertEquals(DataTypeEnum.CURRENCY, param.getType());
        assertEquals("99.99", param.getStringValue());
    }

    @Test
    @DisplayName("Should store pourcentage string as-is for POURCENTAGE type")
    void shouldStorePourcentageString() {
        InParam param = new InParam("pourcentageParam", DataTypeEnum.POURCENTAGE, "25.5");

        assertEquals("pourcentageParam", param.getName());
        assertEquals(DataTypeEnum.POURCENTAGE, param.getType());
        assertEquals("25.5", param.getStringValue());
    }

    @Test
    @DisplayName("Should store non-numeric string for INT type without error")
    void shouldStoreNonNumericStringForIntType() {
        InParam param = new InParam("invalidIntParam", DataTypeEnum.INT, "notANumber");

        assertEquals("invalidIntParam", param.getName());
        assertEquals(DataTypeEnum.INT, param.getType());
        assertEquals("notANumber", param.getStringValue());
    }

    @Test
    @DisplayName("Should handle null string value")
    void shouldHandleNullStringValue() {
        InParam param = new InParam("nullParam", DataTypeEnum.TEXT, null);

        assertEquals("nullParam", param.getName());
        assertEquals(DataTypeEnum.TEXT, param.getType());
        assertNull(param.getStringValue());
    }

    @Test
    @DisplayName("Should handle empty string value")
    void shouldHandleEmptyStringValue() {
        InParam param = new InParam("emptyParam", DataTypeEnum.TEXT, "");

        assertEquals("emptyParam", param.getName());
        assertEquals(DataTypeEnum.TEXT, param.getType());
        assertEquals("", param.getStringValue());
    }

    @Test
    @DisplayName("Should keep string value as-is for TEXT type")
    void shouldKeepStringValueAsIsForTextType() {
        InParam param = new InParam("textParam", DataTypeEnum.TEXT, "some text 123");

        assertEquals("textParam", param.getName());
        assertEquals(DataTypeEnum.TEXT, param.getType());
        assertEquals("some text 123", param.getStringValue());
    }

    @Test
    @DisplayName("Should keep date string as-is for DATE type - Oracle handles conversion")
    void shouldKeepDateStringAsIsForDateType() {
        InParam param = new InParam("dateParam", DataTypeEnum.DATE, "2024-01-15");

        assertEquals("dateParam", param.getName());
        assertEquals(DataTypeEnum.DATE, param.getType());
        assertEquals("2024-01-15", param.getStringValue());
    }

    @Test
    @DisplayName("Should keep datetime string as-is for DATE_TIME type - Oracle handles conversion")
    void shouldKeepDateTimeStringAsIsForDateTimeType() {
        InParam param = new InParam("dtParam", DataTypeEnum.DATE_TIME, "2024-01-15T10:30:00");

        assertEquals("dtParam", param.getName());
        assertEquals(DataTypeEnum.DATE_TIME, param.getType());
        assertEquals("2024-01-15T10:30:00", param.getStringValue());
    }

    @Test
    @DisplayName("Should keep dd/MM/yyyy format as-is for DATE type")
    void shouldKeepSlashDateFormatAsIs() {
        InParam param = new InParam("dateParam", DataTypeEnum.DATE, "15/01/2024");

        assertEquals(DataTypeEnum.DATE, param.getType());
        assertEquals("15/01/2024", param.getStringValue());
    }

    @Test
    @DisplayName("Should keep any date string as-is even if unparseable")
    void shouldKeepUnparseableDateAsIs() {
        InParam param = new InParam("dateParam", DataTypeEnum.DATE, "not-a-date");

        assertEquals("not-a-date", param.getStringValue());
    }

    @Test
    @DisplayName("Should be immutable")
    void shouldBeImmutable() {
        InParam param = new InParam("param", DataTypeEnum.TEXT, "value");

        assertEquals("param", param.getName());
        assertEquals("value", param.getStringValue());
    }
}

