package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDocumentCertifieDao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.util.ReflectionTestUtils;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("GetGabaritDocumentCertifieDaoImpl Tests")
class GetGabaritDocumentCertifieDaoImplTest {

    @Mock
    private DataSource dataSource;

    @Mock
    private SimpleJdbcCall simpleJdbcCall;

    private GetGabaritDocumentCertifieDao dao;

    @BeforeEach
    void setUp() {
        dao = new GetGabaritDocumentCertifieDaoImpl(dataSource);
        ReflectionTestUtils.setField(dao, "getGabaritDocumentCertifieCall", simpleJdbcCall);
    }

    @Test
    @DisplayName("Should return first DocumentDomain from cursor")
    void shouldReturnDocumentDomain() {
        DocumentDomain doc = new DocumentDomain();
        doc.setId(20);
        doc.setName("CertifiedDoc");

        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of(doc));
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        DocumentDomain returned = dao.getGabaritDocumentCertifie(300);

        assertNotNull(returned);
        assertEquals(20, returned.getId());
        assertEquals("CertifiedDoc", returned.getName());
    }

    @Test
    @DisplayName("Should throw IllegalArgumentException when cursor returns empty list")
    void shouldThrowWhenEmpty() {
        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of());
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        assertThrows(IllegalArgumentException.class, () -> dao.getGabaritDocumentCertifie(300));
    }

    @Test
    @DisplayName("Should throw IllegalArgumentException when cursor value is null")
    void shouldThrowWhenCursorNull() {
        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", null);
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        assertThrows(IllegalArgumentException.class, () -> dao.getGabaritDocumentCertifie(300));
    }

    @Test
    @DisplayName("Should wrap unexpected exceptions in RuntimeException")
    void shouldWrapRuntimeException() {
        when(simpleJdbcCall.execute(any(SqlParameterSource.class)))
                .thenThrow(new RuntimeException("db error"));

        assertThrows(RuntimeException.class, () -> dao.getGabaritDocumentCertifie(300));
    }
}
