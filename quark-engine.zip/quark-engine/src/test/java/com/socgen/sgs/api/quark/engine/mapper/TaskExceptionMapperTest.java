package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.task.TaskException;
import com.socgen.sgs.api.quark.engine.enums.TaskExceptionTypeEnum;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TaskExceptionMapper Tests")
class TaskExceptionMapperTest {

    private TaskExceptionMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new TaskExceptionMapper();
    }

    @Test
    @DisplayName("Should return task id from row")
    void shouldReturnIdTache() {
        Map<String, Object> row = new HashMap<>();
        row.put("ID_TACHE", 42);
        assertEquals(42, mapper.getIdTache(row));
    }

    @Test
    @DisplayName("Should return 0 when ID_TACHE is null")
    void shouldReturnZeroWhenIdTacheNull() {
        Map<String, Object> row = new HashMap<>();
        row.put("ID_TACHE", null);
        assertEquals(0, mapper.getIdTache(row));
    }

    @Test
    @DisplayName("Should return 0 when ID_TACHE is not a number")
    void shouldReturnZeroWhenIdTacheNotNumber() {
        Map<String, Object> row = new HashMap<>();
        row.put("ID_TACHE", "abc");
        assertEquals(0, mapper.getIdTache(row));
    }

    @Test
    @DisplayName("Should return 0 when ID_TACHE key is missing")
    void shouldReturnZeroWhenIdTacheMissing() {
        Map<String, Object> row = new HashMap<>();
        assertEquals(0, mapper.getIdTache(row));
    }

    @Test
    @DisplayName("Should return bloc name from row")
    void shouldReturnNomBloc() {
        Map<String, Object> row = new HashMap<>();
        row.put("NOM_BLOC", "BLOC_A");
        assertEquals("BLOC_A", mapper.getNomBloc(row));
    }

    @Test
    @DisplayName("Should return empty string when NOM_BLOC is null")
    void shouldReturnEmptyWhenNomBlocNull() {
        Map<String, Object> row = new HashMap<>();
        row.put("NOM_BLOC", null);
        assertEquals("", mapper.getNomBloc(row));
    }

    @Test
    @DisplayName("Should return empty string when NOM_BLOC key is missing")
    void shouldReturnEmptyWhenNomBlocMissing() {
        Map<String, Object> row = new HashMap<>();
        assertEquals("", mapper.getNomBloc(row));
    }

    @Test
    @DisplayName("Should map to LINE type when INDEX_LIGNES has values")
    void shouldMapToLineType() {
        Map<String, Object> row = buildRow("BLOC_X", "TABLE_Y", "1|2|3");
        TaskException result = mapper.mapToTaskException(row);

        assertNotNull(result);
        assertEquals("TABLE_Y", result.getTableName());
        assertEquals("BLOC_X", result.getName());
        assertArrayEquals(new int[]{1, 2, 3}, result.getIndexLignes());
        assertEquals(TaskExceptionTypeEnum.LINE, result.getType());
    }

    @Test
    @DisplayName("Should map single index to LINE type")
    void shouldMapSingleIndexToLineType() {
        Map<String, Object> row = buildRow("BLOC_A", "TABLE_B", "7");
        TaskException result = mapper.mapToTaskException(row);

        assertArrayEquals(new int[]{7}, result.getIndexLignes());
        assertEquals(TaskExceptionTypeEnum.LINE, result.getType());
    }

    @Test
    @DisplayName("Should map to TABLE type when INDEX_LIGNES is null")
    void shouldMapToTableTypeWhenNull() {
        Map<String, Object> row = buildRow("BLOC_C", "TABLE_D", null);
        TaskException result = mapper.mapToTaskException(row);

        assertNotNull(result);
        assertEquals("TABLE_D", result.getTableName());
        assertEquals("BLOC_C", result.getName());
        assertEquals(0, result.getIndexLignes().length);
        assertEquals(TaskExceptionTypeEnum.TABLE, result.getType());
    }

    @Test
    @DisplayName("Should map to TABLE type when INDEX_LIGNES is empty")
    void shouldMapToTableTypeWhenEmpty() {
        Map<String, Object> row = buildRow("BLOC_E", "TABLE_F", "");
        TaskException result = mapper.mapToTaskException(row);

        assertEquals(0, result.getIndexLignes().length);
        assertEquals(TaskExceptionTypeEnum.TABLE, result.getType());
    }

    @Test
    @DisplayName("Should map to TABLE type when INDEX_LIGNES is blank")
    void shouldMapToTableTypeWhenBlank() {
        Map<String, Object> row = buildRow("BLOC_G", "TABLE_H", "   ");
        TaskException result = mapper.mapToTaskException(row);

        assertEquals(0, result.getIndexLignes().length);
        assertEquals(TaskExceptionTypeEnum.TABLE, result.getType());
    }

    @Test
    @DisplayName("Should handle null NOM_TABLEAU")
    void shouldHandleNullTableName() {
        Map<String, Object> row = buildRow("BLOC_I", null, "1|2");
        TaskException result = mapper.mapToTaskException(row);

        assertNull(result.getTableName());
        assertEquals(TaskExceptionTypeEnum.LINE, result.getType());
    }

    private Map<String, Object> buildRow(String nomBloc, String nomTableau, String indexLignes) {
        Map<String, Object> row = new HashMap<>();
        row.put("ID_TACHE", 1);
        row.put("NOM_BLOC", nomBloc);
        row.put("NOM_TABLEAU", nomTableau);
        row.put("INDEX_LIGNES", indexLignes);
        return row;
    }
}
