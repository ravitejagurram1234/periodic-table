package com.socgen.sgs.api.quark.engine.domain;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("StoreDataType Tests")
class StoreDataTypeTest {

    @Test
    @DisplayName("Should have correct codes for all enum values")
    void shouldHaveCorrectCodes() {
        assertEquals(0, StoreDataType.NONE.getCode());
        assertEquals(1, StoreDataType.SQL.getCode());
        assertEquals(2, StoreDataType.DOCUMENT.getCode());
        assertEquals(255, StoreDataType.ALL.getCode());
    }

    @Test
    @DisplayName("Should get StoreDataType from valid code")
    void shouldGetStoreDataTypeFromValidCode() {
        assertEquals(StoreDataType.NONE, StoreDataType.fromCode(0));
        assertEquals(StoreDataType.SQL, StoreDataType.fromCode(1));
        assertEquals(StoreDataType.DOCUMENT, StoreDataType.fromCode(2));
        assertEquals(StoreDataType.ALL, StoreDataType.fromCode(255));
    }

    @Test
    @DisplayName("Should return NONE for invalid code")
    void shouldReturnNoneForInvalidCode() {
        assertEquals(StoreDataType.NONE, StoreDataType.fromCode(99));
        assertEquals(StoreDataType.NONE, StoreDataType.fromCode(-1));
        assertEquals(StoreDataType.NONE, StoreDataType.fromCode(100));
    }

    @Test
    @DisplayName("Should have all enum values")
    void shouldHaveAllEnumValues() {
        StoreDataType[] values = StoreDataType.values();

        assertEquals(4, values.length);
    }

    @Test
    @DisplayName("Should have correct enum ordering")
    void shouldHaveCorrectEnumOrdering() {
        StoreDataType[] values = StoreDataType.values();

        assertEquals(StoreDataType.NONE, values[0]);
        assertEquals(StoreDataType.SQL, values[1]);
        assertEquals(StoreDataType.DOCUMENT, values[2]);
        assertEquals(StoreDataType.ALL, values[3]);
    }
}

