package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.infra.dao.GetTaskExceptionsDao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.util.ReflectionTestUtils;

import javax.sql.DataSource;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("GetTaskExceptionsDaoImpl Tests")
class GetTaskExceptionsDaoImplTest {

    @Mock
    private DataSource dataSource;

    @Mock
    private SimpleJdbcCall simpleJdbcCall;

    private GetTaskExceptionsDao dao;

    @BeforeEach
    void setUp() {
        dao = new GetTaskExceptionsDaoImpl(dataSource);
        ReflectionTestUtils.setField(dao, "getTaskExceptionsCall", simpleJdbcCall);
    }

    @Test
    @DisplayName("Should return mapped list when cursor has results")
    void shouldReturnMappedList() {
        List<Map<String, Object>> expected = List.of(
                Map.of("ID_TACHE", 1, "NOM_BLOC", "BLOC_A"),
                Map.of("ID_TACHE", 2, "NOM_BLOC", "BLOC_B")
        );
        when(simpleJdbcCall.execute(any(SqlParameterSource.class)))
                .thenReturn(Map.of("result_cursor", expected));

        List<Map<String, Object>> result = dao.getTaskExceptions(100);

        assertNotNull(result);
        assertEquals(2, result.size());
    }

    @Test
    @DisplayName("Should return empty list when cursor key is missing")
    void shouldReturnEmptyListWhenKeyMissing() {
        when(simpleJdbcCall.execute(any(SqlParameterSource.class)))
                .thenReturn(Map.of());

        List<Map<String, Object>> result = dao.getTaskExceptions(100);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("Should return empty list when cursor value is null")
    void shouldReturnEmptyListWhenCursorValueNull() {
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("result_cursor", null);
        when(simpleJdbcCall.execute(any(SqlParameterSource.class)))
                .thenReturn(resultMap);

        List<Map<String, Object>> result = dao.getTaskExceptions(100);

        assertNotNull(result);
        assertEquals(Collections.emptyList(), result);
    }
}
