package com.socgen.sgs.api.quark.engine.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("GabaritSourceEnum Tests")
class GabaritSourceEnumTest {

    @Test
    @DisplayName("Should have correct codes")
    void shouldHaveCorrectCodes() {
        assertEquals(1, GabaritSourceEnum.GABARIT.getCode());
        assertEquals(2, GabaritSourceEnum.DOCUMENT_COURANT.getCode());
        assertEquals(0, GabaritSourceEnum.UNKNOWN.getCode());
    }

    @Test
    @DisplayName("Should get from valid code")
    void shouldGetFromValidCode() {
        assertEquals(GabaritSourceEnum.GABARIT, GabaritSourceEnum.fromCode(1));
        assertEquals(GabaritSourceEnum.DOCUMENT_COURANT, GabaritSourceEnum.fromCode(2));
    }

    @Test
    @DisplayName("Should get from label")
    void shouldGetFromLabel() {
        assertEquals(GabaritSourceEnum.GABARIT, GabaritSourceEnum.fromLabel("Gabarit"));
    }

    @Test
    @DisplayName("Should return UNKNOWN for invalid")
    void shouldReturnUnknownForInvalid() {
        assertEquals(GabaritSourceEnum.UNKNOWN, GabaritSourceEnum.fromCode(99));
        assertEquals(GabaritSourceEnum.UNKNOWN, GabaritSourceEnum.fromLabel(null));
    }
}

