package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDao;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDocumentCertifieDao;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDocumentDao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("GetGabaritBusiness Tests")
class GetGabaritBusinessTest {

    @InjectMocks
    private GetGabaritBusiness getGabaritBusiness;

    @Mock
    private GetGabaritDao getGabaritDao;

    @Mock
    private GetGabaritDocumentDao getGabaritDocumentDao;

    @Mock
    private GetGabaritDocumentCertifieDao getGabaritDocumentCertifieDao;

    private RunProperties runProperties;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(getGabaritBusiness, "documentPoolBasePath", "D:\\Documents");
        runProperties = new RunProperties();
        runProperties.setRunId(10);
    }

    // --- getAndPrepareGabarit ---

    @Test
    @DisplayName("Should fetch gabarit and set pool paths")
    void shouldFetchGabaritAndSetPaths() {
        DocumentDomain gabarit = gabaritWithFileName("G_1.QXP");
        when(getGabaritDao.getGabarit(5)).thenReturn(gabarit);

        DocumentDomain result = getGabaritBusiness.getAndPrepareGabarit(runProperties, 5);

        assertNotNull(result);
        assertEquals("R_10/G_1.QXP", result.getFilePoolPath());
        assertEquals("D:\\Documents\\R_10\\G_1.QXP", result.getFileFullPath());
        verify(getGabaritDao, times(1)).getGabarit(5);
    }

    @Test
    @DisplayName("Should skip path preparation when fileName is null")
    void shouldSkipPathsWhenFileNameNull() {
        DocumentDomain gabarit = new DocumentDomain();
        gabarit.setFileName(null);
        when(getGabaritDao.getGabarit(5)).thenReturn(gabarit);

        DocumentDomain result = getGabaritBusiness.getAndPrepareGabarit(runProperties, 5);

        assertNotNull(result);
        assertNull(result.getFilePoolPath());
        assertNull(result.getFileFullPath());
    }

    // --- getAndPrepareGabaritDocumentCourant ---

    @Test
    @DisplayName("Should fetch gabarit document courant and set pool paths")
    void shouldFetchGabaritDocumentCourantAndSetPaths() {
        DocumentDomain gabarit = gabaritWithFileName("G_200.QXP");
        when(getGabaritDocumentDao.getGabaritDocument(200)).thenReturn(gabarit);

        DocumentDomain result = getGabaritBusiness.getAndPrepareGabaritDocumentCourant(runProperties, 200);

        assertNotNull(result);
        assertEquals("R_10/G_200.QXP", result.getFilePoolPath());
        assertEquals("D:\\Documents\\R_10\\G_200.QXP", result.getFileFullPath());
        verify(getGabaritDocumentDao, times(1)).getGabaritDocument(200);
    }

    @Test
    @DisplayName("Should skip paths for document courant when fileName is null")
    void shouldSkipPathsForDocumentCourantWhenFileNameNull() {
        DocumentDomain gabarit = new DocumentDomain();
        when(getGabaritDocumentDao.getGabaritDocument(200)).thenReturn(gabarit);

        DocumentDomain result = getGabaritBusiness.getAndPrepareGabaritDocumentCourant(runProperties, 200);

        assertNull(result.getFilePoolPath());
        assertNull(result.getFileFullPath());
    }

    // --- getAndPrepareGabaritDocumentCertifie ---

    @Test
    @DisplayName("Should fetch certified gabarit document and set pool paths")
    void shouldFetchCertifiedGabaritAndSetPaths() {
        DocumentDomain gabarit = gabaritWithFileName("G_300.QXP");
        when(getGabaritDocumentCertifieDao.getGabaritDocumentCertifie(300)).thenReturn(gabarit);

        DocumentDomain result = getGabaritBusiness.getAndPrepareGabaritDocumentCertifie(runProperties, 300);

        assertNotNull(result);
        assertEquals("R_10/G_300.QXP", result.getFilePoolPath());
        assertEquals("D:\\Documents\\R_10\\G_300.QXP", result.getFileFullPath());
        verify(getGabaritDocumentCertifieDao, times(1)).getGabaritDocumentCertifie(300);
    }

    @Test
    @DisplayName("Should skip paths for certified document when fileName is null")
    void shouldSkipPathsForCertifiedDocumentWhenFileNameNull() {
        DocumentDomain gabarit = new DocumentDomain();
        when(getGabaritDocumentCertifieDao.getGabaritDocumentCertifie(300)).thenReturn(gabarit);

        DocumentDomain result = getGabaritBusiness.getAndPrepareGabaritDocumentCertifie(runProperties, 300);

        assertNull(result.getFilePoolPath());
        assertNull(result.getFileFullPath());
    }

    // --- getAndPrepareGabaritDocumentSuivi ---

    @Test
    @DisplayName("Should fetch gabarit document suivi and set pool paths")
    void shouldFetchGabaritDocumentSuiviAndSetPaths() {
        DocumentDomain gabarit = gabaritWithFileName("G_400.QXP");
        when(getGabaritDocumentDao.getGabaritDocument(400)).thenReturn(gabarit);

        DocumentDomain result = getGabaritBusiness.getAndPrepareGabaritDocumentSuivi(runProperties, 400);

        assertNotNull(result);
        assertEquals("R_10/G_400.QXP", result.getFilePoolPath());
        assertEquals("D:\\Documents\\R_10\\G_400.QXP", result.getFileFullPath());
        verify(getGabaritDocumentDao, times(1)).getGabaritDocument(400);
    }

    @Test
    @DisplayName("Should skip paths for document suivi when fileName is null")
    void shouldSkipPathsForDocumentSuiviWhenFileNameNull() {
        DocumentDomain gabarit = new DocumentDomain();
        when(getGabaritDocumentDao.getGabaritDocument(400)).thenReturn(gabarit);

        DocumentDomain result = getGabaritBusiness.getAndPrepareGabaritDocumentSuivi(runProperties, 400);

        assertNull(result.getFilePoolPath());
        assertNull(result.getFileFullPath());
    }

    // --- Helper ---

    private DocumentDomain gabaritWithFileName(String fileName) {
        DocumentDomain doc = new DocumentDomain();
        doc.setFileName(fileName);
        return doc;
    }
}

