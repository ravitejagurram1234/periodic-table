package com.socgen.sgs.api.quark.engine.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TypeRapportEnum Tests")
class TypeRapportEnumTest {

    @Test
    @DisplayName("Should have correct codes")
    void shouldHaveCorrectCodes() {
        assertEquals(0, TypeRapportEnum.UNKNOWN.getCode());
        assertEquals(1, TypeRapportEnum.RAPPORT_ANNUEL.getCode());
        assertEquals(5, TypeRapportEnum.DICI.getCode());
    }

    @Test
    @DisplayName("Should get from valid code")
    void shouldGetFromValidCode() {
        assertEquals(TypeRapportEnum.RAPPORT_ANNUEL, TypeRapportEnum.fromCode(1));
        assertEquals(TypeRapportEnum.PLAQUETTE, TypeRapportEnum.fromCode(2));
    }

    @Test
    @DisplayName("Should get from label")
    void shouldGetFromLabel() {
        assertEquals(TypeRapportEnum.RAPPORT_ANNUEL, TypeRapportEnum.fromLabel("Rapport_Annuel"));
    }

    @Test
    @DisplayName("Should have correct labels")
    void shouldHaveCorrectLabels() {
        assertEquals("Rapport_Annuel", TypeRapportEnum.RAPPORT_ANNUEL.getLabel());
        assertEquals("DICI", TypeRapportEnum.DICI.getLabel());
    }

    @Test
    @DisplayName("Should return UNKNOWN for invalid")
    void shouldReturnUnknownForInvalid() {
        assertEquals(TypeRapportEnum.UNKNOWN, TypeRapportEnum.fromCode(99));
        assertEquals(TypeRapportEnum.UNKNOWN, TypeRapportEnum.fromLabel(null));
    }
}

