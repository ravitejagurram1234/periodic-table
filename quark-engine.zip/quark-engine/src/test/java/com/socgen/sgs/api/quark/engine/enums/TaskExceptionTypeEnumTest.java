package com.socgen.sgs.api.quark.engine.enums;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TaskExceptionTypeEnum Tests")
class TaskExceptionTypeEnumTest {

    @Test
    @DisplayName("Should have correct enum values")
    void shouldHaveCorrectEnumValues() {
        assertEquals(4, TaskExceptionTypeEnum.values().length);
    }

    @Test
    @DisplayName("Should convert valid name")
    void shouldConvertValidName() {
        assertEquals(TaskExceptionTypeEnum.LINE, TaskExceptionTypeEnum.fromName("LINE"));
        assertEquals(TaskExceptionTypeEnum.TABLE, TaskExceptionTypeEnum.fromName("TABLE"));
    }

    @Test
    @DisplayName("Should handle case-insensitive conversion")
    void shouldHandleCaseInsensitiveConversion() {
        assertEquals(TaskExceptionTypeEnum.LINE, TaskExceptionTypeEnum.fromName("line"));
    }

    @Test
    @DisplayName("Should return NONE for invalid")
    void shouldReturnNoneForInvalid() {
        assertEquals(TaskExceptionTypeEnum.NONE, TaskExceptionTypeEnum.fromName("INVALID"));
        assertEquals(TaskExceptionTypeEnum.NONE, TaskExceptionTypeEnum.fromName(null));
    }
}

