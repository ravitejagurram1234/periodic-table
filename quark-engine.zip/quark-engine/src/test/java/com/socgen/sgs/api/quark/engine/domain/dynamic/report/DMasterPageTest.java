package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("DMasterPage Tests")
class DMasterPageTest {

    private DMasterPage masterPage;

    @BeforeEach
    void setUp() {
        masterPage = new DMasterPage("1|2|3|4");
    }

    @Test
    @DisplayName("Should create DMasterPage with code")
    void shouldCreateDMasterPageWithCode() {
        assertEquals("1|2|3|4", masterPage.getCode());
    }

    @Test
    @DisplayName("Should have default name")
    void shouldHaveDefaultName() {
        assertEquals("Default", masterPage.getName());
    }

    @Test
    @DisplayName("Should split code into list IDs")
    void shouldSplitCodeIntoListIds() {
        assertNotNull(masterPage.getListIds());
        assertEquals(4, masterPage.getListIds().length);
        assertEquals("1", masterPage.getListIds()[0]);
        assertEquals("2", masterPage.getListIds()[1]);
        assertEquals("3", masterPage.getListIds()[2]);
        assertEquals("4", masterPage.getListIds()[3]);
    }

    @Test
    @DisplayName("Should get master page ID at valid position")
    void shouldGetMasterPageIdAtValidPosition() {
        assertEquals("1", masterPage.getMasterPageId(0));
        assertEquals("2", masterPage.getMasterPageId(1));
        assertEquals("3", masterPage.getMasterPageId(2));
        assertEquals("4", masterPage.getMasterPageId(3));
    }

    @Test
    @DisplayName("Should return default code for position beyond array length")
    void shouldReturnDefaultCodeForPositionBeyondArrayLength() {
        assertEquals("4", masterPage.getMasterPageId(10));
        assertEquals("4", masterPage.getMasterPageId(100));
    }

    @Test
    @DisplayName("Should return default code for negative position")
    void shouldReturnDefaultCodeForNegativePosition() {
        assertEquals("4", masterPage.getMasterPageId(-1));
        assertEquals("4", masterPage.getMasterPageId(-10));
    }

    @Test
    @DisplayName("Should handle single value code")
    void shouldHandleSingleValueCode() {
        DMasterPage singlePage = new DMasterPage("5");

        assertEquals("5", singlePage.getCode());
        assertEquals(1, singlePage.getListIds().length);
        assertEquals("5", singlePage.getMasterPageId(0));
        assertEquals("4", singlePage.getMasterPageId(1));
    }

    @Test
    @DisplayName("Should handle two value code")
    void shouldHandleTwoValueCode() {
        DMasterPage twoPage = new DMasterPage("6|7");

        assertEquals("6|7", twoPage.getCode());
        assertEquals(2, twoPage.getListIds().length);
        assertEquals("6", twoPage.getMasterPageId(0));
        assertEquals("7", twoPage.getMasterPageId(1));
        assertEquals("4", twoPage.getMasterPageId(2));
    }

    @Test
    @DisplayName("Should handle null code")
    void shouldHandleNullCode() {
        DMasterPage nullPage = new DMasterPage(null);

        assertNull(nullPage.getCode());
        assertEquals(0, nullPage.getListIds().length);
        assertEquals("4", nullPage.getMasterPageId(0));
    }

    @Test
    @DisplayName("Should handle empty code")
    void shouldHandleEmptyCode() {
        DMasterPage emptyPage = new DMasterPage("");

        assertEquals("", emptyPage.getCode());
        assertEquals(1, emptyPage.getListIds().length);
    }

    @Test
    @DisplayName("Should have DEFAULT constant with code 4")
    void shouldHaveDEFAULTConstant() {
        assertNotNull(DMasterPage.DEFAULT);
        assertEquals("4", DMasterPage.DEFAULT.getCode());
    }

    @Test
    @DisplayName("Should set and get name")
    void shouldSetAndGetName() {
        masterPage.setName("CustomName");

        assertEquals("CustomName", masterPage.getName());
    }

    @Test
    @DisplayName("Should handle code with spacing")
    void shouldHandleCodeWithSpacing() {
        DMasterPage spacedPage = new DMasterPage("1 | 2 | 3");

        assertEquals(3, spacedPage.getListIds().length);
        assertEquals("1 ", spacedPage.getListIds()[0]);
        assertEquals(" 2 ", spacedPage.getListIds()[1]);
        assertEquals(" 3", spacedPage.getListIds()[2]);
    }
}

