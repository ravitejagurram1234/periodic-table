package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.infra.dao.GetInParamsDao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("GetInParamsBusiness Tests")
class GetInParamsBusinessTest {

    @InjectMocks
    private GetInParamsBusiness getInParamsBusiness;

    @Mock
    private GetInParamsDao getInParamsDao;

    private Run run;

    @BeforeEach
    void setUp() {
        run = new Run();
        run.setId(42);
    }

    @Test
    @DisplayName("Should delegate to DAO and call getInParams once")
    void shouldDelegateToDao() {
        getInParamsBusiness.execute(run);

        verify(getInParamsDao, times(1)).getInParams(run);
    }

    @Test
    @DisplayName("Should pass the exact run instance to DAO")
    void shouldPassExactRunToDao() {
        getInParamsBusiness.execute(run);

        verify(getInParamsDao).getInParams(same(run));
    }
}
