package com.socgen.sgs.api.quark.engine.dto;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("RunIdDto Tests")
class RunIdDtoTest {

    private RunIdDto runIdDto;

    @BeforeEach
    void setUp() {
        runIdDto = new RunIdDto();
    }

    @Test
    @DisplayName("Should create RunIdDto with no arguments")
    void shouldCreateRunIdDtoWithNoArguments() {
        assertNull(runIdDto.getRunId());
    }

    @Test
    @DisplayName("Should create RunIdDto with runId argument")
    void shouldCreateRunIdDtoWithArgument() {
        RunIdDto dto = new RunIdDto(42);

        assertEquals(42, dto.getRunId());
    }

    @Test
    @DisplayName("Should set and get runId")
    void shouldSetAndGetRunId() {
        runIdDto.setRunId(100);

        assertEquals(100, runIdDto.getRunId());
    }

    @Test
    @DisplayName("Should handle zero runId")
    void shouldHandleZeroRunId() {
        runIdDto.setRunId(0);

        assertEquals(0, runIdDto.getRunId());
    }

    @Test
    @DisplayName("Should handle negative runId")
    void shouldHandleNegativeRunId() {
        runIdDto.setRunId(-1);

        assertEquals(-1, runIdDto.getRunId());
    }

    @Test
    @DisplayName("Should handle large runId values")
    void shouldHandleLargeRunIdValues() {
        runIdDto.setRunId(Integer.MAX_VALUE);

        assertEquals(Integer.MAX_VALUE, runIdDto.getRunId());
    }

    @Test
    @DisplayName("Should handle null runId")
    void shouldHandleNullRunId() {
        runIdDto.setRunId(null);

        assertNull(runIdDto.getRunId());
    }

    @Test
    @DisplayName("Should be mutable")
    void shouldBeMutable() {
        runIdDto.setRunId(10);
        assertEquals(10, runIdDto.getRunId());

        runIdDto.setRunId(20);
        assertEquals(20, runIdDto.getRunId());
    }
}

