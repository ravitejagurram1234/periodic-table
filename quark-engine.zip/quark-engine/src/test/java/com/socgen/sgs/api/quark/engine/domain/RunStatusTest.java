package com.socgen.sgs.api.quark.engine.domain;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("RunStatus Tests")
class RunStatusTest {

    @Test
    @DisplayName("Should have correct status codes")
    void shouldHaveCorrectStatusCodes() {
        assertEquals(1, RunStatus.TO_GENERATE.getStatusCode());
        assertEquals(2, RunStatus.GENERATED.getStatusCode());
        assertEquals(3, RunStatus.ERROR.getStatusCode());
        assertEquals(4, RunStatus.RUNNING.getStatusCode());
    }

    @Test
    @DisplayName("Should get RunStatus from valid code")
    void shouldGetRunStatusFromValidCode() {
        assertEquals(RunStatus.TO_GENERATE, RunStatus.fromCode(1));
        assertEquals(RunStatus.GENERATED, RunStatus.fromCode(2));
        assertEquals(RunStatus.ERROR, RunStatus.fromCode(3));
        assertEquals(RunStatus.RUNNING, RunStatus.fromCode(4));
    }

    @Test
    @DisplayName("Should throw exception for invalid code")
    void shouldThrowExceptionForInvalidCode() {
        assertThrows(IllegalArgumentException.class, () -> RunStatus.fromCode(99));
        assertThrows(IllegalArgumentException.class, () -> RunStatus.fromCode(0));
        assertThrows(IllegalArgumentException.class, () -> RunStatus.fromCode(-1));
    }

    @Test
    @DisplayName("Should have all enum values")
    void shouldHaveAllEnumValues() {
        RunStatus[] values = RunStatus.values();

        assertEquals(4, values.length);
    }

    @Test
    @DisplayName("Should be comparable by ordinal")
    void shouldBeComparableByOrdinal() {
        RunStatus[] values = RunStatus.values();

        assertEquals(RunStatus.TO_GENERATE, values[0]);
        assertEquals(RunStatus.GENERATED, values[1]);
        assertEquals(RunStatus.ERROR, values[2]);
        assertEquals(RunStatus.RUNNING, values[3]);
    }
}

