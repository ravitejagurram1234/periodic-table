package com.socgen.sgs.api.quark.engine.domain;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("DocumentDomain Tests")
class DocumentDomainTest {

    private byte[] testData;

    @BeforeEach
    void setUp() {
        testData = "test content".getBytes();
    }

    @Test
    @DisplayName("Should create DocumentDomain with no arguments")
    void shouldCreateEmptyDocumentDomain() {
        DocumentDomain doc = new DocumentDomain();

        assertNull(doc.getId());
        assertNull(doc.getFileName());
        assertFalse(doc.isGabarit());
    }

    @Test
    @DisplayName("Should create DocumentDomain with all constructor parameters")
    void shouldCreateDocumentDomainWithAllParameters() {
        Integer id = 123;
        String name = "TestDoc";
        String format = "QXP";
        String prefix = "D";

        DocumentDomain doc = new DocumentDomain(id, name, format, prefix, testData);

        assertEquals(id, doc.getId());
        assertEquals(name, doc.getName());
        assertEquals(format, doc.getFormat());
        assertEquals(prefix, doc.getPrefix());
        assertEquals(testData, doc.getData());
        assertEquals(1, doc.getIdLangue());
        assertFalse(doc.isGabarit());
    }

    @Test
    @DisplayName("Should generate fileName correctly")
    void shouldGenerateFileNameCorrectly() {
        DocumentDomain doc = new DocumentDomain(432, "TestDoc", "pdf", "D", testData);

        assertEquals("D_432.pdf", doc.getFileName());
    }

    @Test
    @DisplayName("Should set and get properties")
    void shouldSetAndGetProperties() {
        DocumentDomain doc = new DocumentDomain();

        doc.setId(100);
        doc.setName("DocumentName");
        doc.setFormat("QXP");
        doc.setPrefix("G");
        doc.setIdLangue(2);
        doc.setGabarit(true);
        doc.setFilePoolPath("R_100/G_100.qxp");
        doc.setFileFullPath("D:/Documents/R_100/G_100.qxp");

        assertEquals(100, doc.getId());
        assertEquals("DocumentName", doc.getName());
        assertEquals("QXP", doc.getFormat());
        assertEquals("G", doc.getPrefix());
        assertEquals(2, doc.getIdLangue());
        assertTrue(doc.isGabarit());
        assertEquals("R_100/G_100.qxp", doc.getFilePoolPath());
        assertEquals("D:/Documents/R_100/G_100.qxp", doc.getFileFullPath());
    }

    @Test
    @DisplayName("Should verify all file prefix constants")
    void shouldVerifyFilePrefixConstants() {
        assertEquals("D", DocumentDomain.FILE_DOCUMENT_PREFIX);
        assertEquals("G", DocumentDomain.FILE_GABARIT_PREFIX);
        assertEquals("DG", DocumentDomain.FILE_DOCUMENT_GABARIT_PREFIX);
        assertEquals("DCG", DocumentDomain.FILE_DOCUMENT_CERTIFIE_GABARIT_PREFIX);
        assertEquals("DF", DocumentDomain.FILE_DOCUMENT_FINAL_PREFIX);
        assertEquals("GT", DocumentDomain.FILE_GABARIT_TEMPLATE_PREFIX);
    }

    @Test
    @DisplayName("Should handle various formats")
    void shouldHandleVariousFormats() {
        assertNotNull(new DocumentDomain(1, "doc1", "PDF", "D", testData));
        assertNotNull(new DocumentDomain(2, "doc2", "QXP", "G", testData));
        assertNotNull(new DocumentDomain(3, "doc3", "JPG", "D", testData));
        assertNotNull(new DocumentDomain(4, "doc4", "DOC", "DG", testData));
    }

    @Test
    @DisplayName("Should handle null data")
    void shouldHandleNullData() {
        DocumentDomain doc = new DocumentDomain(100, "TestDoc", "QXP", "G", null);

        assertEquals(100, doc.getId());
        assertNull(doc.getData());
        // Extension is now the format VERBATIM (no lowercasing) — matches .NET. Finding #57.
        assertEquals("G_100.QXP", doc.getFileName());
    }

    @Test
    @DisplayName("Should have default language ID of 1")
    void shouldHaveDefaultLanguageId() {
        DocumentDomain doc = new DocumentDomain(100, "test", "QXP", "G", testData);

        assertEquals(1, doc.getIdLangue());
    }

    @Test
    @DisplayName("Should set gabarit flag correctly")
    void shouldSetGabaritFlagCorrectly() {
        DocumentDomain doc = new DocumentDomain(100, "test", "QXP", "G", testData);

        assertFalse(doc.isGabarit());

        doc.setGabarit(true);
        assertTrue(doc.isGabarit());
    }
}
