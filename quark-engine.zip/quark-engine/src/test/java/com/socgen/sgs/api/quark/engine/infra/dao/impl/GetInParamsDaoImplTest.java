package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.InParam;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.infra.dao.GetInParamsDao;
import com.socgen.sgs.api.quark.engine.mapper.InParamMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.util.ReflectionTestUtils;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("GetInParamsDaoImpl Tests")
class GetInParamsDaoImplTest {

    @Mock
    private DataSource dataSource;

    @Mock
    private InParamMapper inParamMapper;

    @Mock
    private SimpleJdbcCall simpleJdbcCall;

    private GetInParamsDao dao;
    private Run run;

    @BeforeEach
    void setUp() {
        dao = new GetInParamsDaoImpl(dataSource, inParamMapper);
        ReflectionTestUtils.setField(dao, "getInParamsCall", simpleJdbcCall);

        RunProperties props = new RunProperties();
        props.setIdSuivi(55);
        run = new Run();
        run.setId(1);
        run.setRunProperties(props);
    }

    @Test
    @DisplayName("Should populate run inParams from cursor results")
    void shouldPopulateInParams() {
        InParam param1 = new InParam("P1", 1, "val1");
        InParam param2 = new InParam("P2", 2, "100");

        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of(param1, param2));
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        dao.getInParams(run);

        assertEquals(2, run.getInParams().size());
        assertSame(param1, run.getInParams().get("P1"));
        assertSame(param2, run.getInParams().get("P2"));
    }

    @Test
    @DisplayName("Should clear existing inParams before loading")
    void shouldClearExistingInParams() {
        run.getInParams().put("OLD", new InParam("OLD", 1, "old"));

        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of(new InParam("NEW", 1, "new")));
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        dao.getInParams(run);

        assertFalse(run.getInParams().containsKey("OLD"));
        assertTrue(run.getInParams().containsKey("NEW"));
    }

    @Test
    @DisplayName("Should leave inParams empty when cursor returns null")
    void shouldLeaveEmptyWhenCursorNull() {
        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", null);
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        dao.getInParams(run);

        assertTrue(run.getInParams().isEmpty());
    }

    @Test
    @DisplayName("Should leave inParams empty when cursor returns empty list")
    void shouldLeaveEmptyWhenCursorEmpty() {
        Map<String, Object> result = new HashMap<>();
        result.put("result_cursor", List.of());
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(result);

        dao.getInParams(run);

        assertTrue(run.getInParams().isEmpty());
    }

    @Test
    @DisplayName("Should throw RuntimeException when DAO call fails")
    void shouldThrowRuntimeExceptionOnFailure() {
        when(simpleJdbcCall.execute(any(SqlParameterSource.class)))
                .thenThrow(new RuntimeException("db error"));

        assertThrows(RuntimeException.class, () -> dao.getInParams(run));
    }
}
