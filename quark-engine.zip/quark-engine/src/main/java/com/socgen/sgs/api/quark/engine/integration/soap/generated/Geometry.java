/**
 * Geometry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Geometry  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String allowBoxOffPage;

    private java.lang.String allowBoxOnToPasteboard;

    private java.lang.String angle;

    private java.lang.String cornerRadius;

    private java.lang.String cornerStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Fit fit;

    private java.lang.String growAcross;

    private java.lang.String growDown;

    private java.lang.String layer;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LineStyle linestyle;

    private java.lang.String moveDown;

    private java.lang.String moveLeft;

    private java.lang.String moveRight;

    private java.lang.String moveUp;

    private java.lang.String page;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Position position;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RelPosition relPosition;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround runaround;

    private java.lang.String shape;

    private java.lang.String shrinkAcross;

    private java.lang.String shrinkDown;

    private java.lang.String skew;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.SplineShape splineShape;

    private java.lang.String stackingOrder;

    private java.lang.String suppressOutput;

    public Geometry() {
    }

    public Geometry(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String allowBoxOffPage,
           java.lang.String allowBoxOnToPasteboard,
           java.lang.String angle,
           java.lang.String cornerRadius,
           java.lang.String cornerStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Fit fit,
           java.lang.String growAcross,
           java.lang.String growDown,
           java.lang.String layer,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LineStyle linestyle,
           java.lang.String moveDown,
           java.lang.String moveLeft,
           java.lang.String moveRight,
           java.lang.String moveUp,
           java.lang.String page,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Position position,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RelPosition relPosition,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround runaround,
           java.lang.String shape,
           java.lang.String shrinkAcross,
           java.lang.String shrinkDown,
           java.lang.String skew,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.SplineShape splineShape,
           java.lang.String stackingOrder,
           java.lang.String suppressOutput) {
        super(
            request);
        this.allowBoxOffPage = allowBoxOffPage;
        this.allowBoxOnToPasteboard = allowBoxOnToPasteboard;
        this.angle = angle;
        this.cornerRadius = cornerRadius;
        this.cornerStyle = cornerStyle;
        this.fit = fit;
        this.growAcross = growAcross;
        this.growDown = growDown;
        this.layer = layer;
        this.linestyle = linestyle;
        this.moveDown = moveDown;
        this.moveLeft = moveLeft;
        this.moveRight = moveRight;
        this.moveUp = moveUp;
        this.page = page;
        this.position = position;
        this.relPosition = relPosition;
        this.runaround = runaround;
        this.shape = shape;
        this.shrinkAcross = shrinkAcross;
        this.shrinkDown = shrinkDown;
        this.skew = skew;
        this.splineShape = splineShape;
        this.stackingOrder = stackingOrder;
        this.suppressOutput = suppressOutput;
    }


    /**
     * Gets the allowBoxOffPage value for this Geometry.
     * 
     * @return allowBoxOffPage
     */
    public java.lang.String getAllowBoxOffPage() {
        return allowBoxOffPage;
    }


    /**
     * Sets the allowBoxOffPage value for this Geometry.
     * 
     * @param allowBoxOffPage
     */
    public void setAllowBoxOffPage(java.lang.String allowBoxOffPage) {
        this.allowBoxOffPage = allowBoxOffPage;
    }


    /**
     * Gets the allowBoxOnToPasteboard value for this Geometry.
     * 
     * @return allowBoxOnToPasteboard
     */
    public java.lang.String getAllowBoxOnToPasteboard() {
        return allowBoxOnToPasteboard;
    }


    /**
     * Sets the allowBoxOnToPasteboard value for this Geometry.
     * 
     * @param allowBoxOnToPasteboard
     */
    public void setAllowBoxOnToPasteboard(java.lang.String allowBoxOnToPasteboard) {
        this.allowBoxOnToPasteboard = allowBoxOnToPasteboard;
    }


    /**
     * Gets the angle value for this Geometry.
     * 
     * @return angle
     */
    public java.lang.String getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this Geometry.
     * 
     * @param angle
     */
    public void setAngle(java.lang.String angle) {
        this.angle = angle;
    }


    /**
     * Gets the cornerRadius value for this Geometry.
     * 
     * @return cornerRadius
     */
    public java.lang.String getCornerRadius() {
        return cornerRadius;
    }


    /**
     * Sets the cornerRadius value for this Geometry.
     * 
     * @param cornerRadius
     */
    public void setCornerRadius(java.lang.String cornerRadius) {
        this.cornerRadius = cornerRadius;
    }


    /**
     * Gets the cornerStyle value for this Geometry.
     * 
     * @return cornerStyle
     */
    public java.lang.String getCornerStyle() {
        return cornerStyle;
    }


    /**
     * Sets the cornerStyle value for this Geometry.
     * 
     * @param cornerStyle
     */
    public void setCornerStyle(java.lang.String cornerStyle) {
        this.cornerStyle = cornerStyle;
    }


    /**
     * Gets the fit value for this Geometry.
     * 
     * @return fit
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Fit getFit() {
        return fit;
    }


    /**
     * Sets the fit value for this Geometry.
     * 
     * @param fit
     */
    public void setFit(com.socgen.sgs.api.quark.engine.integration.soap.generated.Fit fit) {
        this.fit = fit;
    }


    /**
     * Gets the growAcross value for this Geometry.
     * 
     * @return growAcross
     */
    public java.lang.String getGrowAcross() {
        return growAcross;
    }


    /**
     * Sets the growAcross value for this Geometry.
     * 
     * @param growAcross
     */
    public void setGrowAcross(java.lang.String growAcross) {
        this.growAcross = growAcross;
    }


    /**
     * Gets the growDown value for this Geometry.
     * 
     * @return growDown
     */
    public java.lang.String getGrowDown() {
        return growDown;
    }


    /**
     * Sets the growDown value for this Geometry.
     * 
     * @param growDown
     */
    public void setGrowDown(java.lang.String growDown) {
        this.growDown = growDown;
    }


    /**
     * Gets the layer value for this Geometry.
     * 
     * @return layer
     */
    public java.lang.String getLayer() {
        return layer;
    }


    /**
     * Sets the layer value for this Geometry.
     * 
     * @param layer
     */
    public void setLayer(java.lang.String layer) {
        this.layer = layer;
    }


    /**
     * Gets the linestyle value for this Geometry.
     * 
     * @return linestyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LineStyle getLinestyle() {
        return linestyle;
    }


    /**
     * Sets the linestyle value for this Geometry.
     * 
     * @param linestyle
     */
    public void setLinestyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.LineStyle linestyle) {
        this.linestyle = linestyle;
    }


    /**
     * Gets the moveDown value for this Geometry.
     * 
     * @return moveDown
     */
    public java.lang.String getMoveDown() {
        return moveDown;
    }


    /**
     * Sets the moveDown value for this Geometry.
     * 
     * @param moveDown
     */
    public void setMoveDown(java.lang.String moveDown) {
        this.moveDown = moveDown;
    }


    /**
     * Gets the moveLeft value for this Geometry.
     * 
     * @return moveLeft
     */
    public java.lang.String getMoveLeft() {
        return moveLeft;
    }


    /**
     * Sets the moveLeft value for this Geometry.
     * 
     * @param moveLeft
     */
    public void setMoveLeft(java.lang.String moveLeft) {
        this.moveLeft = moveLeft;
    }


    /**
     * Gets the moveRight value for this Geometry.
     * 
     * @return moveRight
     */
    public java.lang.String getMoveRight() {
        return moveRight;
    }


    /**
     * Sets the moveRight value for this Geometry.
     * 
     * @param moveRight
     */
    public void setMoveRight(java.lang.String moveRight) {
        this.moveRight = moveRight;
    }


    /**
     * Gets the moveUp value for this Geometry.
     * 
     * @return moveUp
     */
    public java.lang.String getMoveUp() {
        return moveUp;
    }


    /**
     * Sets the moveUp value for this Geometry.
     * 
     * @param moveUp
     */
    public void setMoveUp(java.lang.String moveUp) {
        this.moveUp = moveUp;
    }


    /**
     * Gets the page value for this Geometry.
     * 
     * @return page
     */
    public java.lang.String getPage() {
        return page;
    }


    /**
     * Sets the page value for this Geometry.
     * 
     * @param page
     */
    public void setPage(java.lang.String page) {
        this.page = page;
    }


    /**
     * Gets the position value for this Geometry.
     * 
     * @return position
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Position getPosition() {
        return position;
    }


    /**
     * Sets the position value for this Geometry.
     * 
     * @param position
     */
    public void setPosition(com.socgen.sgs.api.quark.engine.integration.soap.generated.Position position) {
        this.position = position;
    }


    /**
     * Gets the relPosition value for this Geometry.
     * 
     * @return relPosition
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RelPosition getRelPosition() {
        return relPosition;
    }


    /**
     * Sets the relPosition value for this Geometry.
     * 
     * @param relPosition
     */
    public void setRelPosition(com.socgen.sgs.api.quark.engine.integration.soap.generated.RelPosition relPosition) {
        this.relPosition = relPosition;
    }


    /**
     * Gets the runaround value for this Geometry.
     * 
     * @return runaround
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround getRunaround() {
        return runaround;
    }


    /**
     * Sets the runaround value for this Geometry.
     * 
     * @param runaround
     */
    public void setRunaround(com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround runaround) {
        this.runaround = runaround;
    }


    /**
     * Gets the shape value for this Geometry.
     * 
     * @return shape
     */
    public java.lang.String getShape() {
        return shape;
    }


    /**
     * Sets the shape value for this Geometry.
     * 
     * @param shape
     */
    public void setShape(java.lang.String shape) {
        this.shape = shape;
    }


    /**
     * Gets the shrinkAcross value for this Geometry.
     * 
     * @return shrinkAcross
     */
    public java.lang.String getShrinkAcross() {
        return shrinkAcross;
    }


    /**
     * Sets the shrinkAcross value for this Geometry.
     * 
     * @param shrinkAcross
     */
    public void setShrinkAcross(java.lang.String shrinkAcross) {
        this.shrinkAcross = shrinkAcross;
    }


    /**
     * Gets the shrinkDown value for this Geometry.
     * 
     * @return shrinkDown
     */
    public java.lang.String getShrinkDown() {
        return shrinkDown;
    }


    /**
     * Sets the shrinkDown value for this Geometry.
     * 
     * @param shrinkDown
     */
    public void setShrinkDown(java.lang.String shrinkDown) {
        this.shrinkDown = shrinkDown;
    }


    /**
     * Gets the skew value for this Geometry.
     * 
     * @return skew
     */
    public java.lang.String getSkew() {
        return skew;
    }


    /**
     * Sets the skew value for this Geometry.
     * 
     * @param skew
     */
    public void setSkew(java.lang.String skew) {
        this.skew = skew;
    }


    /**
     * Gets the splineShape value for this Geometry.
     * 
     * @return splineShape
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SplineShape getSplineShape() {
        return splineShape;
    }


    /**
     * Sets the splineShape value for this Geometry.
     * 
     * @param splineShape
     */
    public void setSplineShape(com.socgen.sgs.api.quark.engine.integration.soap.generated.SplineShape splineShape) {
        this.splineShape = splineShape;
    }


    /**
     * Gets the stackingOrder value for this Geometry.
     * 
     * @return stackingOrder
     */
    public java.lang.String getStackingOrder() {
        return stackingOrder;
    }


    /**
     * Sets the stackingOrder value for this Geometry.
     * 
     * @param stackingOrder
     */
    public void setStackingOrder(java.lang.String stackingOrder) {
        this.stackingOrder = stackingOrder;
    }


    /**
     * Gets the suppressOutput value for this Geometry.
     * 
     * @return suppressOutput
     */
    public java.lang.String getSuppressOutput() {
        return suppressOutput;
    }


    /**
     * Sets the suppressOutput value for this Geometry.
     * 
     * @param suppressOutput
     */
    public void setSuppressOutput(java.lang.String suppressOutput) {
        this.suppressOutput = suppressOutput;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Geometry)) return false;
        Geometry other = (Geometry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.allowBoxOffPage==null && other.getAllowBoxOffPage()==null) || 
             (this.allowBoxOffPage!=null &&
              this.allowBoxOffPage.equals(other.getAllowBoxOffPage()))) &&
            ((this.allowBoxOnToPasteboard==null && other.getAllowBoxOnToPasteboard()==null) || 
             (this.allowBoxOnToPasteboard!=null &&
              this.allowBoxOnToPasteboard.equals(other.getAllowBoxOnToPasteboard()))) &&
            ((this.angle==null && other.getAngle()==null) || 
             (this.angle!=null &&
              this.angle.equals(other.getAngle()))) &&
            ((this.cornerRadius==null && other.getCornerRadius()==null) || 
             (this.cornerRadius!=null &&
              this.cornerRadius.equals(other.getCornerRadius()))) &&
            ((this.cornerStyle==null && other.getCornerStyle()==null) || 
             (this.cornerStyle!=null &&
              this.cornerStyle.equals(other.getCornerStyle()))) &&
            ((this.fit==null && other.getFit()==null) || 
             (this.fit!=null &&
              this.fit.equals(other.getFit()))) &&
            ((this.growAcross==null && other.getGrowAcross()==null) || 
             (this.growAcross!=null &&
              this.growAcross.equals(other.getGrowAcross()))) &&
            ((this.growDown==null && other.getGrowDown()==null) || 
             (this.growDown!=null &&
              this.growDown.equals(other.getGrowDown()))) &&
            ((this.layer==null && other.getLayer()==null) || 
             (this.layer!=null &&
              this.layer.equals(other.getLayer()))) &&
            ((this.linestyle==null && other.getLinestyle()==null) || 
             (this.linestyle!=null &&
              this.linestyle.equals(other.getLinestyle()))) &&
            ((this.moveDown==null && other.getMoveDown()==null) || 
             (this.moveDown!=null &&
              this.moveDown.equals(other.getMoveDown()))) &&
            ((this.moveLeft==null && other.getMoveLeft()==null) || 
             (this.moveLeft!=null &&
              this.moveLeft.equals(other.getMoveLeft()))) &&
            ((this.moveRight==null && other.getMoveRight()==null) || 
             (this.moveRight!=null &&
              this.moveRight.equals(other.getMoveRight()))) &&
            ((this.moveUp==null && other.getMoveUp()==null) || 
             (this.moveUp!=null &&
              this.moveUp.equals(other.getMoveUp()))) &&
            ((this.page==null && other.getPage()==null) || 
             (this.page!=null &&
              this.page.equals(other.getPage()))) &&
            ((this.position==null && other.getPosition()==null) || 
             (this.position!=null &&
              this.position.equals(other.getPosition()))) &&
            ((this.relPosition==null && other.getRelPosition()==null) || 
             (this.relPosition!=null &&
              this.relPosition.equals(other.getRelPosition()))) &&
            ((this.runaround==null && other.getRunaround()==null) || 
             (this.runaround!=null &&
              this.runaround.equals(other.getRunaround()))) &&
            ((this.shape==null && other.getShape()==null) || 
             (this.shape!=null &&
              this.shape.equals(other.getShape()))) &&
            ((this.shrinkAcross==null && other.getShrinkAcross()==null) || 
             (this.shrinkAcross!=null &&
              this.shrinkAcross.equals(other.getShrinkAcross()))) &&
            ((this.shrinkDown==null && other.getShrinkDown()==null) || 
             (this.shrinkDown!=null &&
              this.shrinkDown.equals(other.getShrinkDown()))) &&
            ((this.skew==null && other.getSkew()==null) || 
             (this.skew!=null &&
              this.skew.equals(other.getSkew()))) &&
            ((this.splineShape==null && other.getSplineShape()==null) || 
             (this.splineShape!=null &&
              this.splineShape.equals(other.getSplineShape()))) &&
            ((this.stackingOrder==null && other.getStackingOrder()==null) || 
             (this.stackingOrder!=null &&
              this.stackingOrder.equals(other.getStackingOrder()))) &&
            ((this.suppressOutput==null && other.getSuppressOutput()==null) || 
             (this.suppressOutput!=null &&
              this.suppressOutput.equals(other.getSuppressOutput())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAllowBoxOffPage() != null) {
            _hashCode += getAllowBoxOffPage().hashCode();
        }
        if (getAllowBoxOnToPasteboard() != null) {
            _hashCode += getAllowBoxOnToPasteboard().hashCode();
        }
        if (getAngle() != null) {
            _hashCode += getAngle().hashCode();
        }
        if (getCornerRadius() != null) {
            _hashCode += getCornerRadius().hashCode();
        }
        if (getCornerStyle() != null) {
            _hashCode += getCornerStyle().hashCode();
        }
        if (getFit() != null) {
            _hashCode += getFit().hashCode();
        }
        if (getGrowAcross() != null) {
            _hashCode += getGrowAcross().hashCode();
        }
        if (getGrowDown() != null) {
            _hashCode += getGrowDown().hashCode();
        }
        if (getLayer() != null) {
            _hashCode += getLayer().hashCode();
        }
        if (getLinestyle() != null) {
            _hashCode += getLinestyle().hashCode();
        }
        if (getMoveDown() != null) {
            _hashCode += getMoveDown().hashCode();
        }
        if (getMoveLeft() != null) {
            _hashCode += getMoveLeft().hashCode();
        }
        if (getMoveRight() != null) {
            _hashCode += getMoveRight().hashCode();
        }
        if (getMoveUp() != null) {
            _hashCode += getMoveUp().hashCode();
        }
        if (getPage() != null) {
            _hashCode += getPage().hashCode();
        }
        if (getPosition() != null) {
            _hashCode += getPosition().hashCode();
        }
        if (getRelPosition() != null) {
            _hashCode += getRelPosition().hashCode();
        }
        if (getRunaround() != null) {
            _hashCode += getRunaround().hashCode();
        }
        if (getShape() != null) {
            _hashCode += getShape().hashCode();
        }
        if (getShrinkAcross() != null) {
            _hashCode += getShrinkAcross().hashCode();
        }
        if (getShrinkDown() != null) {
            _hashCode += getShrinkDown().hashCode();
        }
        if (getSkew() != null) {
            _hashCode += getSkew().hashCode();
        }
        if (getSplineShape() != null) {
            _hashCode += getSplineShape().hashCode();
        }
        if (getStackingOrder() != null) {
            _hashCode += getStackingOrder().hashCode();
        }
        if (getSuppressOutput() != null) {
            _hashCode += getSuppressOutput().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Geometry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Geometry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowBoxOffPage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "allowBoxOffPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowBoxOnToPasteboard");
        elemField.setXmlName(new javax.xml.namespace.QName("", "allowBoxOnToPasteboard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("angle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "angle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cornerRadius");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cornerRadius"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cornerStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cornerStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Fit"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("growAcross");
        elemField.setXmlName(new javax.xml.namespace.QName("", "growAcross"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("growDown");
        elemField.setXmlName(new javax.xml.namespace.QName("", "growDown"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("linestyle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "linestyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LineStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moveDown");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moveDown"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moveLeft");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moveLeft"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moveRight");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moveRight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moveUp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moveUp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("page");
        elemField.setXmlName(new javax.xml.namespace.QName("", "page"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("position");
        elemField.setXmlName(new javax.xml.namespace.QName("", "position"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Position"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relPosition");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relPosition"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RelPosition"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("runaround");
        elemField.setXmlName(new javax.xml.namespace.QName("", "runaround"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Runaround"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shape");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shape"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shrinkAcross");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shrinkAcross"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shrinkDown");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shrinkDown"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("skew");
        elemField.setXmlName(new javax.xml.namespace.QName("", "skew"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("splineShape");
        elemField.setXmlName(new javax.xml.namespace.QName("", "splineShape"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SplineShape"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stackingOrder");
        elemField.setXmlName(new javax.xml.namespace.QName("", "stackingOrder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppressOutput");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suppressOutput"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
