/**
 * Header.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Header  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedHeader continuedHeader;

    private java.lang.String headerRows;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] rows;

    public Header() {
    }

    public Header(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedHeader continuedHeader,
           java.lang.String headerRows,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] rows) {
        super(
            request);
        this.continuedHeader = continuedHeader;
        this.headerRows = headerRows;
        this.rows = rows;
    }


    /**
     * Gets the continuedHeader value for this Header.
     * 
     * @return continuedHeader
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedHeader getContinuedHeader() {
        return continuedHeader;
    }


    /**
     * Sets the continuedHeader value for this Header.
     * 
     * @param continuedHeader
     */
    public void setContinuedHeader(com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedHeader continuedHeader) {
        this.continuedHeader = continuedHeader;
    }


    /**
     * Gets the headerRows value for this Header.
     * 
     * @return headerRows
     */
    public java.lang.String getHeaderRows() {
        return headerRows;
    }


    /**
     * Sets the headerRows value for this Header.
     * 
     * @param headerRows
     */
    public void setHeaderRows(java.lang.String headerRows) {
        this.headerRows = headerRows;
    }


    /**
     * Gets the rows value for this Header.
     * 
     * @return rows
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] getRows() {
        return rows;
    }


    /**
     * Sets the rows value for this Header.
     * 
     * @param rows
     */
    public void setRows(com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] rows) {
        this.rows = rows;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Row getRows(int i) {
        return this.rows[i];
    }

    public void setRows(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Row _value) {
        this.rows[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Header)) return false;
        Header other = (Header) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.continuedHeader==null && other.getContinuedHeader()==null) || 
             (this.continuedHeader!=null &&
              this.continuedHeader.equals(other.getContinuedHeader()))) &&
            ((this.headerRows==null && other.getHeaderRows()==null) || 
             (this.headerRows!=null &&
              this.headerRows.equals(other.getHeaderRows()))) &&
            ((this.rows==null && other.getRows()==null) || 
             (this.rows!=null &&
              java.util.Arrays.equals(this.rows, other.getRows())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getContinuedHeader() != null) {
            _hashCode += getContinuedHeader().hashCode();
        }
        if (getHeaderRows() != null) {
            _hashCode += getHeaderRows().hashCode();
        }
        if (getRows() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRows());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRows(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Header.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Header"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("continuedHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "continuedHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ContinuedHeader"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headerRows");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "headerRows"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rows");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rows"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Row"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
