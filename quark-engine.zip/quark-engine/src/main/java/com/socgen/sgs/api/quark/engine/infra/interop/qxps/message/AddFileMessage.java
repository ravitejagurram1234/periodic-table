package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class AddFileMessage implements QxpsMessage {

    private static final String MESSAGE_PATH = "addfile";

    private final byte[] data;

    @Override
    public String getCommandPath() {
        return MESSAGE_PATH;
    }

    @Override
    public String getCommandQuery() {
        return null;
    }

    @Override
    public boolean isPost() {
        return true;
    }

    @Override
    public MessagePriority getPriority() {
        return MessagePriority.LOWEST;
    }
}
