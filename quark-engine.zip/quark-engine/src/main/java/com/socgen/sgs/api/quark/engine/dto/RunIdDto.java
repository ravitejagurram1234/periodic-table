package com.socgen.sgs.api.quark.engine.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RunIdDto {
    Integer runId;
}
