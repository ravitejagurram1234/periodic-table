package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.domain.task.TaskDid;
import com.socgen.sgs.api.quark.engine.service.task.TaskProcessStrategy;
import org.springframework.stereotype.Component;

/** DID task has no processing logic — all happens in post-process. */
@Component
public class DidTaskProcessStrategy implements TaskProcessStrategy<TaskDid> {

    @Override
    public Class<TaskDid> getTaskType() {
        return TaskDid.class;
    }

    @Override
    public void process(TaskDid task) {
        // Nothing at process time — the DID is computed in post-process, after every other
        // task's pagination is known. Cross-reference: .NET Task_DID.Process() (empty body).
    }
}
