/**
 * QxpsmsdkSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class QxpsmsdkSoapBindingStub extends org.apache.axis.client.Stub implements com.socgen.sgs.api.quark.engine.integration.soap.generated.QManagerSDKSvc {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[19];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("createSession");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "timeout"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"), long.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "createSessionReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getErrorObject");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "errorString"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://exception.manager.quark.com", "QException"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.QException.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getErrorObjectReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("closeAllDocs");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("closeDoc");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "docName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("closeSession");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getOpenDocs");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns3_QOpenDocData"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getOpenDocsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getOpenSessions");
        oper.setReturnType(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_xsd_string"));
        oper.setReturnClass(java.lang.String[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getOpenSessionsReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getPreferences");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "server"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "port"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "password"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Preferences"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getPreferencesReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getXMLFromXPressDOM");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "dom"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Project"), com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getXMLFromXPressDOMReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getXPressDOM");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "documentName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Project"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getXPressDOMReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getXPressDOMEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "documentName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "options"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://webservice.manager.quark.com", "QXPressDOMOptions"), com.socgen.sgs.api.quark.engine.integration.soap.generated.QXPressDOMOptions.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Project"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getXPressDOMExReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getXPressDOMFromXML");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "documentXML"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Project"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getXPressDOMFromXMLReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("newDoc");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "docName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "jobJacketName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "jobTicketName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "host"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "port"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("openDoc");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "docName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "host"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "port"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("processRequest");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "requestCmd"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "QRequestContext"), com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://command.manager.quark.com", "QContentData"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "processRequestReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("processRequestEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "reqContextObj"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "QRequestContext"), com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://command.manager.quark.com", "QContentData"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "processRequestExReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("saveAllDocs");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "relativePath"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("saveDoc");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "docName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "newName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "relativePath"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setPreferences");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "server"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "port"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "password"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "prefs"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Preferences"), com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[18] = oper;

    }

    public QxpsmsdkSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public QxpsmsdkSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public QxpsmsdkSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.1");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
        addBindings2();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://command.manager.quark.com", "QContentData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://command.manager.quark.com", "QResponseHeader");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QResponseHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://docmanager.manager.quark.com", "QOpenDocData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exception.manager.quark.com", "QException");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AddCells");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AddCells.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AddFileRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AddFileRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AllowAddFile");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AllowAddFile.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AllowBoxOffPage");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AllowBoxOffPage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AllowBoxOnToPasteboard");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AllowBoxOnToPasteboard.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AllowByDefault");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AllowByDefault.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AllowMemoryCaching");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AllowMemoryCaching.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AnchoredBoxReference");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Article");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Article.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Bottom");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Bottom.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Box");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Box.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "BoxRef");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "CacheSize");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CacheSize.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Cell");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ChildID");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ChildID.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Clipping");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Clipping.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ColSpec");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ColSpec.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Column");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Column.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ColumnGuides");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnGuides.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Component");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Component.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "CompositionZone");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CompositionZone.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConfirmPassword");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConfirmPassword.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterConfig");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterConfig.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterItem");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterItemAddress");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterItemAddress.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterItemAllow");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterItemAllow.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterItemMask");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterItemMask.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionTimeout");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionTimeout.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConstructFileRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConstructFileRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConstructRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConstructRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConstructStreamRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConstructStreamRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Content");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Content.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ContentLoadingTimeout");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentLoadingTimeout.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ContentPlaceholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Contour");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Contour.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Contours");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Contours.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "CopyDeskDocRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyDeskDocRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "CopyDeskRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyDeskRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "CopyFit");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Count");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Count.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DefaultBufferSize");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DefaultBufferSize.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DefaultDoc");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DefaultDoc.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DefaultRenderType");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DefaultRenderType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DeleteCells");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DeleteRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DisableQXDReturn");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DisableQXDReturn.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DocumentRootFolder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DocumentRootFolder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DropCap");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DropCap.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "EmailFrom");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EmailFrom.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "EMailPreferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "EmailTo");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EmailTo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "EnableFileSystemDocPool");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EnableFileSystemDocPool.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "EnableHTTPInterface");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EnableHTTPInterface.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "EPSRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EPSRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ErrorDoc");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ErrorDoc.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "FileInfoRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FileInfoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Fit");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Fit.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "FlushAllRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FlushAllRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "FlushRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FlushRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Footer");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Footer.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ForceServedDocumentsClosed");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ForceServedDocumentsClosed.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Format");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Format.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Frame");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GenerateHierarchyOnAddfile");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GenerateHierarchyOnAddfile.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Geometry");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GetDocInfoRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GetDocInfoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GetDocPoolListRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GetDocPoolListRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GetProjectInfoRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GetProjectInfoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GetServerInfoRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GetServerInfoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Grid");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Grid.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GridLine");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Group");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Group.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GroupCharacters");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GrowAcross");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GrowAcross.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GrowDown");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GrowDown.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Header");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Header.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Height");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Height.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "HiddenData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "HTTPPreferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.HTTPPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ID");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ID.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Inset");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "JPEGRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.JPEGRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "KeepLinesTogether");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.KeepLinesTogether.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "KeyValue");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.KeyValue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Layer");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LayersRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LayersRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Layout");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LayoutProperty");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutProperty.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Left");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Left.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LeftControlPoint");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftControlPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LineStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LineStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LinkedBox");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "List");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.List.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LiteralRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LiteralRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Location");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Location.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LockToGrid");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LockToGrid.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LogBadSXTDialogs");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LogBadSXTDialogs.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LogDocProblems");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LogDocProblems.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LogErrors");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LogErrors.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LogEvents");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LogEvents.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LogFolder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LogFolder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LoggingEnabled");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingEnabled.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LoggingPreferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LogTiming");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LogTiming.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LogTransactions");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LogTransactions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Margins");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Margins.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Max");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Max.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "MaxConnections");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MaxConnections.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "MaxListens");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MaxListens.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "MetaData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Min");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Min.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ModifierFileRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ModifierFileRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ModifierRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ModifierRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ModifierStreamRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ModifierStreamRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "MoveDown");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MoveDown.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "MoveLeft");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MoveLeft.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "MoveRight");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MoveRight.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "MoveUp");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MoveUp.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "NameValueParam");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "NoAccessDoc");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.NoAccessDoc.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Origin");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Origin.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "OverMatter");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Page");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Page.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Paragraph");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ParentTable");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ParentTable.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "PDFRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PDFRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Picture");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Placeholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "PNGRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PNGRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "PortNumber");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PortNumber.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Position");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Position.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "PostScriptRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PostScriptRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "PPMLRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PPMLRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Preferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "PreFlightRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PreFlightRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Project");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ProjectRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ProjectRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "QRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "QRequestContext");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "QuarkXPressRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QuarkXPressRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RawCustomRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RawCustomRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RelPosition");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RelPosition.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RequestParameters");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RequestParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RequestSettings");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RequestSettings.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RequireAdminVerification");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RequireAdminVerification.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RGBColor");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RichText");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Right");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Right.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RightControlPoint");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RightControlPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RLERawCustomRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RLERawCustomRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Row");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Row.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Rubi");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RubiText");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RubiText.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Rule");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Runaround");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SaveAs");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SaveAsRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Scale");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Scale.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ScaleTo");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ScaleTo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ScreenPDFRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ScreenPDFRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Section");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Section.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ServerPreferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Shadow");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ShrinkAcross");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ShrinkAcross.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ShrinkDown");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ShrinkDown.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ShutdownRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ShutdownRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Size");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Size.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SmtpConfiguration");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SmtpConfiguration.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SmtpPort");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SmtpPort.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SmtpServerIP");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SmtpServerIP.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SplineShape");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SplineShape.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Spread");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "StackingOrder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StackingOrder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "StatusMonitorOpenOption");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonitorOpenOption.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "StatusMonitorPosition");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonitorPosition.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "StatusMonPosH");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonPosH.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "StatusMonPosW");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonPosW.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "StatusMonPosX");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonPosX.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "StatusMonPosY");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonPosY.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Story");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Story.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "StructVersion");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StructVersion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SuppressOutput");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SuppressOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SWFRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SWFRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Tab");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Tab.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Table");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Table.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TableBreak");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TableBreak.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TabSpec");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Text");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Text.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TextNodePlaceholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TextPlaceholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Top");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Top.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "UpdateGeometryRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.UpdateGeometryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "UseConnectionFilters");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.UseConnectionFilters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "VerboseStatusMonitoring");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.VerboseStatusMonitoring.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "VerificationPassword");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.VerificationPassword.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "VerificationUsername");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.VerificationUsername.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings2() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Vertex");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Vertex.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "VertexPoint");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.VertexPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Vertices");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Vertices.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "VistaRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.VistaRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Width");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Width.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "XMLImportRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.XMLImportRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "XMLRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.XMLRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns2_QContentData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://command.manager.quark.com", "QContentData");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns2_QResponseHeader");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QResponseHeader[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://command.manager.quark.com", "QResponseHeader");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns3_QOpenDocData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://docmanager.manager.quark.com", "QOpenDocData");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_AddCells");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AddCells[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AddCells");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_AnchoredBoxReference");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AnchoredBoxReference");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Article");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Article[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Article");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Box");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Box");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_BoxRef");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "BoxRef");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Cell");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Cell");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_ChildID");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ChildID[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ChildID");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Column");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Column[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Column");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Component");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Component[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Component");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_CompositionZone");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CompositionZone[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "CompositionZone");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_ConnectionFilterItem");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterItem[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterItem");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Contour");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Contour[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Contour");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_DeleteCells");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DeleteCells");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_GridLine");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GridLine");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Group");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Group[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Group");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_GroupCharacters");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GroupCharacters");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_HiddenData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "HiddenData");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_KeyValue");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.KeyValue[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "KeyValue");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Layer");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Layer");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Layout");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Layout");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_LinkedBox");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LinkedBox");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_List");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.List[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "List");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_NameValueParam");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "NameValueParam");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Page");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Page[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Page");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Paragraph");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Paragraph");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Placeholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Placeholder");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_RichText");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RichText");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Row");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Row");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Rubi");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Rubi");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Rule");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Rule");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Spread");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Spread");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Tab");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Tab[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Tab");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Table");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Table");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_TabSpec");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TabSpec");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_TextNodePlaceholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TextNodePlaceholder");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_TextPlaceholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TextPlaceholder");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_tns5_Vertex");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Vertex[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Vertex");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "ArrayOf_xsd_string");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://webservice.manager.quark.com", "QXPressDOMOptions");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QXPressDOMOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
                    _call.setEncodingStyle(org.apache.axis.Constants.URI_SOAP11_ENC);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public java.lang.String createSession(long timeout) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "createSession"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Long(timeout)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QException getErrorObject(java.lang.String errorString) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "getErrorObject"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {errorString});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QException) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QException) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.QException.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void closeAllDocs(java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "closeAllDocs"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void closeDoc(java.lang.String docName, java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "closeDoc"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {docName, sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void closeSession(java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "closeSession"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[] getOpenDocs(java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "getOpenDocs"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String[] getOpenSessions() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "getOpenSessions"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences getPreferences(java.lang.String server, int port, java.lang.String user, java.lang.String password) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "getPreferences"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {server, new java.lang.Integer(port), user, password});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String getXMLFromXPressDOM(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project dom) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "getXMLFromXPressDOM"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {dom});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOM(java.lang.String documentName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "getXPressDOM"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {documentName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOMEx(java.lang.String documentName, com.socgen.sgs.api.quark.engine.integration.soap.generated.QXPressDOMOptions options) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "getXPressDOMEx"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {documentName, options});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOMFromXML(java.lang.String documentXML) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "getXPressDOMFromXML"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {documentXML});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void newDoc(java.lang.String docName, java.lang.String jobJacketName, java.lang.String jobTicketName, java.lang.String host, int port, java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "newDoc"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {docName, jobJacketName, jobTicketName, host, new java.lang.Integer(port), sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void openDoc(java.lang.String docName, java.lang.String host, int port, java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "openDoc"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {docName, host, new java.lang.Integer(port), sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData processRequest(com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext requestCmd) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "processRequest"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {requestCmd});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData processRequestEx(com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext reqContextObj, java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "processRequestEx"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {reqContextObj, sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void saveAllDocs(java.lang.String relativePath, java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "saveAllDocs"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {relativePath, sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void saveDoc(java.lang.String docName, java.lang.String newName, java.lang.String relativePath, java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "saveDoc"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {docName, newName, relativePath, sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void setPreferences(java.lang.String server, int port, java.lang.String user, java.lang.String password, com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences prefs) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "setPreferences"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {server, new java.lang.Integer(port), user, password, prefs});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
