package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DCell;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DMasterPage;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DPoint;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DReport;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DRow;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DSection;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DTable;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DZone;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.PrepareReportParameters;

import com.socgen.sgs.api.quark.engine.domain.dynamic.template.Template;

import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBase;

import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox;

import com.socgen.sgs.api.quark.engine.domain.bloc.BlocPage;

import com.socgen.sgs.api.quark.engine.domain.element.TElement;

import com.socgen.sgs.api.quark.engine.domain.helper.DynamiqueGeometryHelper;

import com.socgen.sgs.api.quark.engine.domain.helper.DynamiquePageBreakHelper;

import com.socgen.sgs.api.quark.engine.domain.helper.MathHelper;

import com.socgen.sgs.api.quark.engine.domain.helper.TElementHelper;

import com.socgen.sgs.api.quark.engine.domain.port.DynamicQueryPort;

import com.socgen.sgs.api.quark.engine.domain.project.QxpProject;

import com.socgen.sgs.api.quark.engine.domain.task.TaskDynamique;

import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;

import com.socgen.sgs.api.quark.engine.enums.AbsoluteRepeatType;

import com.socgen.sgs.api.quark.engine.service.task.TaskProcessStrategy;

import lombok.RequiredArgsConstructor;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;

import java.util.ArrayList;

import java.util.Iterator;

import java.util.List;

import java.util.Map;

import java.util.stream.Collectors;

/**

 * Strategy for processing TaskDynamique (dynamic SQL-driven report generation).

 * Handles 4 stages:

 * <ol>

 *   <li>Get_Report: Execute SQL, build DReport structure from result rows</li>

 *   <li>Check_Report: Verify each DCell has a valid TElement from gabarit template</li>

 *   <li>Prepare_Report: Calculate geometry (position, page, column) for all elements</li>

 *   <li>Render_Boxes: Convert DReport elements into BlocBox/BlocPage for QXPS Modifier</li>

 * </ol>

 *

 * Cross-reference: QXP.Engine.Core.Business.Process_Dynamique

 */

@Component

@Slf4j

@RequiredArgsConstructor

public class DynamiqueTaskProcessStrategy implements TaskProcessStrategy<TaskDynamique> {

    // SQL column names matching .NET constants

    private static final String ID_SECTION_COL = "ID_SECTION";

    private static final String ID_TABLE_COL = "ID_TABLE";

    private static final String ID_GROUP_COL = "ID_GROUPE";

    private static final String ID_LIGNE_COL = "ID_LIGNE";

    private static final String NOM_BLOC_COL = "NOM_BLOC";

    private static final String VALEUR_BLOC_COL = "VALEUR_BLOC";

    private static final String TEMPLATE_COL = "TEMPLATE";

    private static final String ROW_LEVEL_COL = "ROW_LEVEL";

    private static final String DESCRIPTION_BLOC_COL = "DESCRIPTION_BLOC";

    private static final String INFO_BLOC_COL = "INFO_BLOC";

    // Naming patterns

    private static final String NEW_PAGE_PATTERN = "%s_P%d";

    private final DynamicQueryPort dynamicQueryPort;

    @Override

    public Class<TaskDynamique> getTaskType() {

        return TaskDynamique.class;

    }

    @Override

    public void process(TaskDynamique task) {

        log.debug("DynamiqueTaskProcessStrategy processing task [{}]", task.getId());

        DReport report = null;

        PrepareReportParameters prp = new PrepareReportParameters(task);

        if (task.getRun().getGabarit() == null) {

            log.error("Gabarit template is null for dynamic task [{}]", task.getId());

            return;

        }

        // ================================================================

        // Stage 1: Get_Report — Execute SQL and build DReport

        // ================================================================

        try {

            List<Map<String, Object>> rows = dynamicQueryPort.executeQuery(

                    task.getSql(), task.getRun().getInParams());

            if (rows != null && !rows.isEmpty()) {

                report = getReport(prp, rows);

            } else {

                log.info("No SQL data for dynamic task [{}]", task.getId());

            }

        } catch (Exception ex) {

            log.error("Error executing SQL for dynamic task [{}]: {}", task.getId(), ex.getMessage(), ex);

            return;

        }

        // ================================================================

        // Stage 2: Check_Report — Verify TElements exist

        // ================================================================

        if (report != null) {

            checkReport(prp, report);

        }

        // ================================================================

        // Stage 3: Prepare_Report — Calculate geometry

        // ================================================================

        if (report != null) {

            prepareReport(prp, report);

        }

        // ================================================================

        // Stage 4: Render_Boxes — Build blocs from report

        // ================================================================

        renderBoxes(prp, report);

    }

    // ========================================================================

    // Stage 1: Get_Report

    // Cross-reference: Process_Dynamique.Get_Report() lines 95-220

    // ========================================================================

    private DReport getReport(PrepareReportParameters prp, List<Map<String, Object>> rows) {

        DReport report = new DReport();

        TaskDynamique task = prp.getTask();

        report.setPageBreakRules(task.getPageBreakRules());

        report.setColumnBreakRules(task.getColumnBreakRules());

        // Check which optional columns exist

        boolean includeRowLevel = dynamicQueryPort.existColumn(ROW_LEVEL_COL, rows);

        boolean includeIdTable = dynamicQueryPort.existColumn(ID_TABLE_COL, rows);

        boolean includeIdSection = dynamicQueryPort.existColumn(ID_SECTION_COL, rows);

        boolean includeDescriptionBloc = dynamicQueryPort.existColumn(DESCRIPTION_BLOC_COL, rows);

        boolean includeInfoBloc = dynamicQueryPort.existColumn(INFO_BLOC_COL, rows);

        // Store data flag — bitwise SQL test so combined values (0x03 = SQL|DOCUMENT) and ALL (0xFF)
        // are both honoured. (.NET Run_Base.cs:677 (Store_Type & SQL) == SQL.) Finding #1.

        boolean storeData = task.isStoreData()
                && com.socgen.sgs.api.quark.engine.domain.StoreDataType.hasFlag(
                task.getRun().getRunProperties().getStoreDataTypeCode(),
                com.socgen.sgs.api.quark.engine.domain.StoreDataType.SQL);
        // Tracking state

        int lastIdSection = Integer.MIN_VALUE;

        int lastIdGroupe = Integer.MIN_VALUE;

        int lastIdTable = Integer.MIN_VALUE;

        int lastIdLigne = Integer.MIN_VALUE;

        DSection currentDSection = null;

        DCell currentDCell = null;

        DRow currentDRow = null;

        DTable currentDTable = null;

        Template currentTemplate = null;

        for (Map<String, Object> row : rows) {

            int idGroupe = getIntValue(row, ID_GROUP_COL);

            int idLigne = getIntValue(row, ID_LIGNE_COL);

            String newName = getStringValue(row, NOM_BLOC_COL);

            String data = getStringValue(row, VALEUR_BLOC_COL);

            String templateName = getStringValue(row, TEMPLATE_COL);

            int rowLevel = includeRowLevel ? getIntValue(row, ROW_LEVEL_COL) : Integer.MIN_VALUE;

            int idTable = includeIdTable ? getIntValue(row, ID_TABLE_COL) : Integer.MIN_VALUE;

            int idSection = includeIdSection ? getIntValue(row, ID_SECTION_COL) : Integer.MIN_VALUE;

            String descriptionBloc = includeDescriptionBloc ? getStringValue(row, DESCRIPTION_BLOC_COL) : "";

            String infoBloc = includeInfoBloc ? getStringValue(row, INFO_BLOC_COL) : "";

            // Change detection

            boolean newSection = (idSection != lastIdSection);

            boolean newGroup = (idGroupe != lastIdGroupe);

            boolean newLigne = (idLigne != lastIdLigne);

            boolean newTable = (idTable != lastIdTable);

            lastIdSection = idSection;

            lastIdGroupe = idGroupe;

            lastIdLigne = idLigne;

            lastIdTable = idTable;

            // New section

            if (currentDSection == null || newSection) {

                currentDSection = new DSection();

                report.getSections().add(currentDSection);

                newTable = true;

                newGroup = true;

                currentDTable = null;

            }

            // New group → resolve template

            if (newGroup) {

                if (task.getRun().getTemplates().containsKey(templateName)) {

                    currentTemplate = task.getRun().getTemplates().get(templateName);

                } else {

                    Template newTemplate = new Template();

                    newTemplate.setName(templateName);

                    newTemplate.setSrcName(templateName);

                    task.getRun().getTemplates().put(templateName, newTemplate);

                    currentTemplate = newTemplate;

                }

            }

            // New line or new group → create cell

            if (newLigne || newGroup) {

                currentDCell = new DCell(currentTemplate);

                if (currentTemplate.isAbsolute()) {

                    // Absolute: add directly to section cells

                    currentDSection.getCells().add(currentDCell);

                } else {

                    // Relative: add to table

                    if (currentDTable == null || newTable) {

                        currentDTable = new DTable();

                        currentDTable.setNewPage(task.isNewPageTable());

                        currentDSection.getTables().add(currentDTable);

                        newLigne = true;

                    }

                    if (newLigne) {

                        currentDRow = new DRow();

                        currentDTable.getRows().add(currentDRow);

                        if (rowLevel != Integer.MIN_VALUE) {

                            currentDRow.setLevel(rowLevel);

                        }

                    }

                    currentDRow.getCells().add(currentDCell);

                }

            }

            // Add value and name to current cell

            currentDCell.getValues().add(data);

            currentDCell.getNewNames().add(newName);

            // Store data if configured

            if (storeData) {

                task.getDataNamesValues().add(

                        new com.socgen.sgs.api.quark.engine.domain.DataNameValue(

                                newName, data, descriptionBloc, infoBloc));

            }

        }

        return report;

    }

    // ========================================================================

    // Stage 2: Check_Report

    // Cross-reference: Process_Dynamique.Check_Report() lines 225-295

    // ========================================================================

    private void checkReport(PrepareReportParameters prp, DReport report) {

        TaskDynamique task = prp.getTask();

        boolean activeOverflowTemplate = !task.getOverflowBoxes().isEmpty();

        QxpProject qxpProject = task.getRun().getGabarit().getQxpProject();

        qxpProject.analyse(task, true);

        List<DSection> sections2Remove = new ArrayList<>();

        for (DSection section : report.getSections()) {

            // Check absolute cells

            List<DCell> cells2Remove = new ArrayList<>();

            for (DCell cell : section.getCells()) {

                cell.setOverflow(activeOverflowTemplate && cell.containsOneNewName(task.getOverflowBoxes()));

                cell.setTElement(evaluateTElement(task, cell));

                if (cell.getTElement() == null) {

                    cells2Remove.add(cell);

                }

            }

            section.getCells().removeAll(cells2Remove);

            // Check relative cells in tables

            List<DTable> tables2Remove = new ArrayList<>();

            for (DTable table : section.getTables()) {

                List<DRow> rows2Remove = new ArrayList<>();

                for (DRow row : table.getRows()) {

                    cells2Remove = new ArrayList<>();

                    for (DCell cell : row.getCells()) {

                        cell.setOverflow(activeOverflowTemplate && cell.containsOneNewName(task.getOverflowBoxes()));

                        cell.setTElement(evaluateTElement(task, cell));

                        if (cell.getTElement() == null) {

                            cells2Remove.add(cell);

                        }

                    }

                    row.getCells().removeAll(cells2Remove);

                    if (row.getCells().isEmpty()) {

                        rows2Remove.add(row);

                    }

                }

                table.getRows().removeAll(rows2Remove);

                if (table.getRows().isEmpty()) {

                    tables2Remove.add(table);

                }

            }

            section.getTables().removeAll(tables2Remove);

            if (section.getTables().isEmpty() && section.getCells().isEmpty()) {

                sections2Remove.add(section);

            }

        }

        report.getSections().removeAll(sections2Remove);

    }

    /**

     * Evaluate the TElement for a cell from the gabarit template project.

     * Selects srcName or srcNameOverflow based on cell.overflow flag.

     *

     * Cross-reference: TElement_Helper.Evaluate_TElement()

     */

    private TElement evaluateTElement(TaskDynamique task, DCell cell) {

        String srcName;

        if (cell.isOverflow()) {

            srcName = cell.getTemplate().getSrcNameOverflow();

        } else {

            srcName = cell.getTemplate().getSrcName();

        }

        if (srcName == null || srcName.isBlank()) {

            return null;

        }

        QxpProject qxpProject = task.getRun().getGabarit().getQxpProject();

        Map<String, TElement> elements = qxpProject.getElements();

        if (elements != null && elements.containsKey(srcName)) {

            return elements.get(srcName);

        } else {

            log.warn("Template element [{}] not found for cell names [{}]",

                    srcName, String.join("/", cell.getNewNames()));

            return null;

        }

    }

    // ========================================================================

    // Stage 3: Prepare_Report

    // Cross-reference: Process_Dynamique.Prepare_Report() lines 300-530

    // ========================================================================

    private void prepareReport(PrepareReportParameters prp, DReport report) {

        TaskDynamique task = prp.getTask();

        // Evaluate available height between anchors

        if (task.getStartAnchor() != null && task.getEndAnchor() != null) {

            if (task.getStartAnchor().getBottom().compareTo(task.getEndAnchor().getTop()) < 0
                    && task.getStartAnchor().getLeft().compareTo(task.getStartAnchor().getRight()) < 0) {

                prp.setAvailableHeight(task.getEndAnchor().getTop().subtract(task.getStartAnchor().getBottom()));

                prp.setAvailableWidth(task.getEndAnchor().getLeft().subtract(task.getStartAnchor().getRight()));

            } else {

                log.error("Incoherent anchor positions for task [{}]: start={}, end={}",

                        task.getId(), task.getStartAnchor().getName(), task.getEndAnchor().getName());

                return;

            }

        }

        for (DSection section : report.getSections()) {

            prepareReportSection(prp, report, section);

        }

        // If control overflow, memorize box names

        if (task.isControlOverflow()) {

            task.getBoxNames().clear();

            for (DSection section : report.getSections()) {

                for (DCell cell : section.getCells()) {

                    task.getBoxNames().addAll(cell.getNewNames());

                }

                for (DTable table : section.getTables()) {

                    for (DRow row : table.getRows()) {

                        for (DCell cell : row.getCells()) {

                            task.getBoxNames().addAll(cell.getNewNames());

                        }

                    }

                }

            }

        }

        report.getInfo().setNbPage(prp.getPage());

    }

    private void prepareReportSection(PrepareReportParameters prp, DReport report, DSection section) {

        TaskDynamique task = prp.getTask();

        int cellLogicalId = 0;

        boolean firstTable = true;

        BigDecimal tableHeight = BigDecimal.ZERO;

        BigDecimal tableWidth = BigDecimal.ZERO;

        BigDecimal maxWidth = BigDecimal.ZERO;

        DPoint cursor = new DPoint(task.getStartAnchor().getRight(), task.getStartAnchor().getBottom());

        DPoint cursorBreak = new DPoint(cursor);

        prp.reset();

        prp.setPage(prp.getPage() + 1);

        DMasterPage master = DMasterPage.DEFAULT;

        section.getInfo().setMasterPage(master);

        List<DRow> currentPageBreakRows = new ArrayList<>();

        List<DRow> currentColumnBreakRows = new ArrayList<>();

        // ---- Prepare absolute cells ----

        for (DCell cell : section.getCells()) {

            cell.getInfo().setPage(prp.getPage());

            cell.setLogicalId(++cellLogicalId);

            cell.getInfo().setZone(DynamiqueGeometryHelper.getZone(null, cell));

            int absRepeat = cell.getTemplate().getAbsoluteRepeat();

            if (AbsoluteRepeatType.hasOtherPage(absRepeat)) {

                prp.getRepeatedCells().add(cell);

                if (!AbsoluteRepeatType.hasFirstPage(absRepeat)
                        && absRepeat != 0) {

                    cell.downgradeGeneration();

                }

            }

            if (AbsoluteRepeatType.hasLastPage(absRepeat)) {

                prp.getLastCells().add(cell);

            }

        }

        // Remove absolute cells not on first page or default (raw 0 == .NET Absolute_Repeat_Type.Default)

        section.getCells().removeIf(cell ->

                !(AbsoluteRepeatType.hasFirstPage(cell.getTemplate().getAbsoluteRepeat())

                        || cell.getTemplate().getAbsoluteRepeat() == 0));
        // ---- Process relative cells in tables ----

        for (DTable table : section.getTables()) {

            if (!firstTable) {

                if (table.isNewPage()) {

                    prp.setPage(prp.getPage() + 1);

                    tableHeight = BigDecimal.ZERO;

                    prp.setColumn(1);

                    tableWidth = BigDecimal.ZERO;

                    maxWidth = BigDecimal.ZERO;

                    addAbsoluteCells(prp, section);

                    cursor.reset(task.getStartAnchor().getRight(), task.getStartAnchor().getBottom());

                }

            } else {

                firstTable = false;

                prp.setColumn(1);

                tableWidth = BigDecimal.ZERO;

                maxWidth = BigDecimal.ZERO;

            }

            int maxRows = table.getRows().size();

            for (int indexRow = 0; indexRow < maxRows; indexRow++) {

                DRow row = table.getRows().get(indexRow);

                // Handle break rows (page/column header repetition)

                if (row.isPageBreak() || row.isColumnBreak()) {

                    prp.getRows2Remove().add(row);

                    if (row.isPageBreak()) {

                        int existingIndex = findBreakRowByLevel(currentPageBreakRows, row.getLevel());

                        if (existingIndex >= 0) {

                            DRow oldRow = currentPageBreakRows.get(existingIndex);

                            transferRowCellsInfo(oldRow, row);

                            currentPageBreakRows = new ArrayList<>(currentPageBreakRows);

                            currentPageBreakRows.set(existingIndex, row);

                        } else {

                            prepareReportCells(prp, row, cursorBreak);

                            currentPageBreakRows = new ArrayList<>(currentPageBreakRows);

                            currentPageBreakRows.add(row);

                            cursorBreak.setLeft(task.getStartAnchor().getRight());

                            cursorBreak.setTop(cursorBreak.getTop().add(row.getInfo().getHeight()));

                        }

                    }

                    if (row.isColumnBreak()) {

                        int existingIndex = findBreakRowByLevel(currentColumnBreakRows, row.getLevel());

                        if (existingIndex >= 0) {

                            DRow oldRow = currentColumnBreakRows.get(existingIndex);

                            transferRowCellsInfo(oldRow, row);

                            currentColumnBreakRows = new ArrayList<>(currentColumnBreakRows);

                            currentColumnBreakRows.set(existingIndex, row);

                        } else {

                            prepareReportCells(prp, row, cursorBreak);

                            currentColumnBreakRows = new ArrayList<>(currentColumnBreakRows);

                            currentColumnBreakRows.add(row);

                            cursorBreak.setLeft(task.getStartAnchor().getRight());

                            cursorBreak.setTop(cursorBreak.getTop().add(row.getInfo().getHeight()));

                        }

                    }

                    downgradeReportCells(row);

                    continue;

                }

                // Normal row processing

                row.setPageBreakRows(currentPageBreakRows);

                row.setColumnBreakRows(currentColumnBreakRows);

                prepareReportCells(prp, row, cursor);

                tableHeight = tableHeight.add(row.getInfo().getHeight());

                // Check if overflow

                if (tableHeight.compareTo(prp.getAvailableHeight()) > 0) {

                    if (prp.getColumn() < task.getNbColumn()) {

                        // New column

                        prp.setColumn(prp.getColumn() + 1);

                        tableWidth = tableWidth.add(maxWidth).add(task.getColumnSpace());

                        DynamiquePageBreakHelper.updateRows(report, table.getRows(), row, prp, false, tableWidth);

                        tableHeight = prp.getCurrentTableHeight();

                        maxWidth = prp.getCurrentTableWidth();

                        indexRow += prp.getNbRowsAdded();

                        maxRows += prp.getNbRowsAdded();

                    } else {

                        // New page

                        prp.setPage(prp.getPage() + 1);

                        prp.setColumn(1);

                        DynamiquePageBreakHelper.updateRows(report, table.getRows(), row, prp, true, BigDecimal.ZERO);

                        tableHeight = prp.getCurrentTableHeight();

                        tableWidth = BigDecimal.ZERO;

                        maxWidth = prp.getCurrentTableWidth();

                        indexRow += prp.getNbRowsAdded();

                        maxRows += prp.getNbRowsAdded();

                        addAbsoluteCells(prp, section);

                    }

                } else {

                    maxWidth = maxWidth.max(row.getInfo().getWidth());

                }

                cursor.setLeft(task.getStartAnchor().getRight().add(tableWidth));

                cursor.setTop(task.getStartAnchor().getBottom().add(tableHeight));

            }

            // Remove break rows from table

            table.getRows().removeAll(prp.getRows2Remove());

        }

        // Add last absolute cells

        addLastAbsoluteCells(prp, section);

    }

    private void prepareReportCells(PrepareReportParameters prp, DRow row, DPoint cursor) {

        BigDecimal rowHeight = BigDecimal.ZERO;

        BigDecimal rowWidth = BigDecimal.ZERO;

        boolean heightPercent = row.getInfo().getHeight().compareTo(BigDecimal.ZERO) != 0;

        for (DCell cell : row.getCells()) {

            cell.getInfo().setPage(prp.getPage());

            BigDecimal cellHeight;

            if (heightPercent) {

                cellHeight = MathHelper.getValPercent(row.getInfo().getHeight(), cell.getTemplate().getHeightPercent());

            } else {

                cellHeight = DynamiqueGeometryHelper.getCellHeightWithTop(cell);

            }

            rowHeight = rowHeight.max(cellHeight);

            rowWidth = rowWidth.add(DynamiqueGeometryHelper.getCellWidthWithLeft(cell));

            cell.getInfo().setZone(DynamiqueGeometryHelper.getZoneAndUpdateCursor(cursor, cell));

        }

        row.getInfo().setHeight(rowHeight);

        row.getInfo().setWidth(rowWidth);

        row.getInfo().setPage(prp.getPage());

        row.getInfo().setColumn(prp.getColumn());

    }

    private void downgradeReportCells(DRow row) {

        for (DCell cell : row.getCells()) {

            cell.downgradeGeneration();

        }

    }

    private void transferRowCellsInfo(DRow oldRow, DRow newRow) {

        newRow.setInfo(oldRow.getInfo());

        for (int i = 0; i < oldRow.getCells().size() && i < newRow.getCells().size(); i++) {

            newRow.getCells().get(i).setInfo(oldRow.getCells().get(i).getInfo());

        }

    }

    private void addAbsoluteCells(PrepareReportParameters prp, DSection section) {

        for (DCell srcCell : prp.getRepeatedCells()) {

            DCell newCell = srcCell.cloneCell();

            newCell.getInfo().setPage(prp.getPage());

            section.getCells().add(newCell);

        }

    }

    private void addLastAbsoluteCells(PrepareReportParameters prp, DSection section) {

        List<DCell> cellsInLastPage = section.getCells().stream()

                .filter(c -> c.getInfo().getPage() == prp.getPage())

                .collect(Collectors.toList());

        for (DCell srcCell : prp.getLastCells()) {

            boolean alreadyExists = cellsInLastPage.stream()

                    .anyMatch(c -> c.equalsCell(srcCell));

            if (!alreadyExists) {

                DCell newCell = srcCell.cloneCell();

                newCell.getInfo().setPage(prp.getPage());

                section.getCells().add(newCell);

            }

        }

    }

    private int findBreakRowByLevel(List<DRow> breakRows, int level) {

        for (int i = 0; i < breakRows.size(); i++) {

            if (breakRows.get(i).getLevel() == level) {

                return i;

            }

        }

        return -1;

    }

    // ========================================================================

    // Stage 4: Render_Boxes

    // Cross-reference: Process_Dynamique.Render_Boxes() lines 535-610

    // ========================================================================

    private void renderBoxes(PrepareReportParameters prp, DReport report) {

        TaskDynamique task = prp.getTask();

        int nbNewPage;

        if (report == null) {

            nbNewPage = 1;

        } else {

            nbNewPage = report.getInfo().getNbPage();

        }

        // 1. Create new pages

        for (int i = 0; i < nbNewPage; i++) {

            BlocPage blocPage = new BlocPage(task,

                    String.format(NEW_PAGE_PATTERN, task.getDestinationBlocName(), i));

            blocPage.setAction(BlocActionEnum.CREATE);

            blocPage.setRelativePage(i);

            task.getBlocsModify().put(blocPage.getName(), blocPage);

        }

        // 2. Remove old pages

        int nbAnciennePage = task.getNbAnciennePage();

        for (int i = 0; i < nbAnciennePage; i++) {

            int relativeRemovePage = nbNewPage + i;

            BlocPage blocPage = new BlocPage(task,

                    String.format(NEW_PAGE_PATTERN, task.getDestinationBlocName(), relativeRemovePage));

            blocPage.setAction(BlocActionEnum.REMOVE);

            blocPage.setRelativePage(relativeRemovePage);

            task.getBlocsModify().put(blocPage.getName(), blocPage);

        }

        // 3. Move start anchor to first new page

        BlocBox blocStart = TElementHelper.getMoveAnchor(task, task.getStartAnchor(), 0);

        if (blocStart != null) {

            blocStart.setPagination(true);

            task.getBlocsModify().put(blocStart.getName(), blocStart);

        }

        // 4. Move end anchor to last new page

        BlocBox blocEnd = TElementHelper.getMoveAnchor(task, task.getEndAnchor(), nbNewPage - 1);

        if (blocEnd != null) {

            blocEnd.setPagination(true);

            task.getBlocsModify().put(blocEnd.getName(), blocEnd);

        }

        // 5. Create blocs from report cells

        if (report != null) {

            for (DSection section : report.getSections()) {

                // Absolute cells

                for (DCell cell : section.getCells()) {

                    addDCellBlocs(cell, task);

                }

                // Relative cells

                for (DTable table : section.getTables()) {

                    for (DRow row : table.getRows()) {

                        for (DCell cell : row.getCells()) {

                            addDCellBlocs(cell, task);

                        }

                    }

                }

            }

        }

    }

    /**

     * Convert a DCell into bloc(s) and add to the task.

     *

     * Cross-reference: Process_Dynamique.Add_DCell_Blocs()

     */

    private void addDCellBlocs(DCell dCell, TaskDynamique task) {

        try {

            BlocBase bloc = TElementHelper.getBloc(dCell, task);

            if (bloc != null) {

                if (task.getBlocsModify().containsKey(bloc.getName())) {

                    log.warn("Duplicate bloc name [{}] in task [{}]", bloc.getName(), task.getId());

                } else {

                    task.getBlocsModify().put(bloc.getName(), bloc);

                }

            } else {

                log.warn("Null bloc generated for cell in task [{}]", task.getId());

            }

        } catch (Exception ex) {

            log.error("Error adding DCell bloc in task [{}]: {}", task.getId(), ex.getMessage());

        }

    }

    // ========================================================================

    // Utility methods

    // ========================================================================

    private int getIntValue(Map<String, Object> row, String column) {

        Object val = row.get(column);

        if (val == null) return Integer.MIN_VALUE;

        if (val instanceof Number) return ((Number) val).intValue();

        try {

            return Integer.parseInt(val.toString().trim());

        } catch (NumberFormatException e) {

            return Integer.MIN_VALUE;

        }

    }

    private String getStringValue(Map<String, Object> row, String column) {

        Object val = row.get(column);

        return val != null ? val.toString() : "";

    }

}
