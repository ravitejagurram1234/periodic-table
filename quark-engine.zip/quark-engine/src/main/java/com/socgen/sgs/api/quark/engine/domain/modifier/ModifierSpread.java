package com.socgen.sgs.api.quark.engine.domain.modifier;

import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Page;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Table;
import com.socgen.sgs.api.quark.engine.enums.SubTaskTypeEnum;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents a spread in a modifier project hierarchy.
 * Aggregates boxes, pages, tables, and groups, then converts them to SOAP SDK objects.
 *
 * Cross-reference: QXP.Engine.Core.Spread (Modifier namespace)
 */
@Getter
@Setter
public class ModifierSpread {

    private static final String BLOC_OPERATION_CREATE = "CREATE";
    private static final String BLOC_OPERATION_DELETE = "DELETE";

    private String uid;
    private final Map<String, ModifierBox> boxes = new LinkedHashMap<>();
    private final Map<String, ModifierBox> boxesExtra = new LinkedHashMap<>();
    private final Map<String, ModifierGroup> groups = new LinkedHashMap<>();
    private final Map<String, ModifierTable> tables = new LinkedHashMap<>();
    private final Map<String, ModifierPage> pages = new LinkedHashMap<>();
    private boolean create = false;

    public ModifierSpread() {
    }

    /**
     * Build SDK Box array from normal boxes.
     * Cross-reference: .NET Spread.GetSDKBoxes()
     */
    public Box[] getSdkBoxes() {
        List<Box> destBoxes = new ArrayList<>();

        // Normal boxes
        destBoxes.addAll(evaluateSdkBoxes(boxes, false));

        // Groups
        for (ModifierGroup grp : groups.values()) {
            if (grp.getSrcBoxes() != null) {
                for (Box newBox : grp.getSrcBoxes()) {
                    newBox.setOperation(BLOC_OPERATION_CREATE);
                    newBox.setUID("");
                    destBoxes.add(newBox);
                    if (newBox.getGeometry() == null) {
                        newBox.setGeometry(new Geometry());
                    }
                    newBox.getGeometry().setPage(String.valueOf(grp.getPageId()));
                }
            }
        }

        return destBoxes.toArray(new Box[0]);
    }

    /**
     * Build SDK Box array from extra boxes.
     * Cross-reference: .NET Spread.GetSDKBoxesExtra()
     */
    public Box[] getSdkBoxesExtra() {
        List<Box> destBoxes = new ArrayList<>(evaluateSdkBoxes(boxesExtra, true));
        return destBoxes.toArray(new Box[0]);
    }

    private List<Box> evaluateSdkBoxes(Map<String, ModifierBox> boxMap, boolean ignoreOperation) {
        List<Box> destBoxes = new ArrayList<>();
        for (ModifierBox bx : boxMap.values()) {
            Box box = bx.getSrcBox();
            switch (bx.getAction()) {
                case CREATE:
                    if (!ignoreOperation) {
                        box.setOperation(BLOC_OPERATION_CREATE);
                    }
                    box.setUID("");
                    if (box.getGeometry() == null) {
                        box.setGeometry(new Geometry());
                    }
                    box.getGeometry().setPage(String.valueOf(bx.getPageId()));
                    break;
                case MOVE:
                    if (box.getGeometry() != null) {
                        box.getGeometry().setPage(String.valueOf(bx.getPageId()));
                    }
                    break;
                default:
                    break;
            }
            destBoxes.add(box);
        }
        return destBoxes;
    }

    /**
     * Build SDK Table array.
     * Cross-reference: .NET Spread.GetSDKTables()
     */
    public Table[] getSdkTables() {
        List<Table> sdkTables = new ArrayList<>();

        for (ModifierTable tab : tables.values()) {
            if (tab.getAction() == BlocActionEnum.REMOVE) {
                Table table = new Table();
                table.setName(tab.getName());
                table.setOperation(BLOC_OPERATION_DELETE);
                sdkTables.add(table);
            } else if (tab.getTask() != null
                    && tab.getTask().getSubTaskType() == SubTaskTypeEnum.FILE_QXP_PREVIOUS
                    && tab.getSrcTable() != null) {
                Table table = tab.getSrcTable();
                table.setName(tab.getName());
                sdkTables.add(table);
            } else {
                Table table = new Table();
                table.setName(tab.getName());

                List<ModifierLigne> lignes = new ArrayList<>(tab.getLignes().values());
                lignes.sort(Comparator.comparingInt(ModifierLigne::getIndex).reversed());

                List<DeleteCells> deleteCellsList = new ArrayList<>();
                for (ModifierLigne ligne : lignes) {
                    DeleteCells dc = new DeleteCells();
                    dc.setType("ROW");
                    dc.setBaseIndex(String.valueOf(ligne.getIndex()));
                    dc.setDeleteCount("1");
                    deleteCellsList.add(dc);
                }
                if (!deleteCellsList.isEmpty()) {
                    table.setDeleteCells(deleteCellsList.toArray(new DeleteCells[0]));
                    sdkTables.add(table);
                }
            }
        }

        return sdkTables.toArray(new Table[0]);
    }

    /**
     * Build SDK Page array.
     * Cross-reference: .NET Spread.GetSDKPages()
     */
    public Page[] getSdkPages() {
        List<Page> sdkPages = new ArrayList<>();

        for (ModifierPage pg : pages.values()) {
            Page page = new Page();
            page.setUID(pg.getUid());

            // Determine operation from task action or bloc action
            String operation = null;
            switch (pg.getAction()) {
                case REMOVE:
                    operation = BLOC_OPERATION_DELETE;
                    break;
                case CREATE:
                    operation = BLOC_OPERATION_CREATE;
                    break;
                default:
                    break;
            }

            page.setOperation(operation);

            if (BLOC_OPERATION_CREATE.equals(operation)) {
                if (pg.getTask() != null && pg.getTask().getMasterPage() != null) {
                    page.setMaster(pg.getTask().getMasterPage().getMasterPageId(0));
                }
                page.setPosition(pg.getPosition());

                if (pg.getIndexPosition() == 0) {
                    this.create = true;
                }
            }
            sdkPages.add(page);

            // Dummy page handling for double-page layouts
            if (pg.isCreateDummyNextPage()) {
                String nextPageId = String.valueOf(Integer.parseInt(pg.getUid()) + 1);

                Page dummyCreate = new Page();
                dummyCreate.setUID(nextPageId);
                dummyCreate.setOperation(BLOC_OPERATION_CREATE);
                sdkPages.add(dummyCreate);

                Page dummyDelete = new Page();
                dummyDelete.setUID(nextPageId);
                dummyDelete.setOperation(BLOC_OPERATION_DELETE);
                sdkPages.add(dummyDelete);
            }
        }

        return sdkPages.toArray(new Page[0]);
    }
}