/**
 * Separators.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Separators  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String beforeCrossReference;

    private java.lang.String betweenEntry;

    private java.lang.String betweenPageNumbers;

    private java.lang.String betweenPageRange;

    private java.lang.String crossReferenceStyle;

    private java.lang.String followingEntry;

    private java.lang.String levelFormat;

    private java.lang.String range;

    public Separators() {
    }

    public Separators(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String beforeCrossReference,
           java.lang.String betweenEntry,
           java.lang.String betweenPageNumbers,
           java.lang.String betweenPageRange,
           java.lang.String crossReferenceStyle,
           java.lang.String followingEntry,
           java.lang.String levelFormat,
           java.lang.String range) {
        super(
            request);
        this.beforeCrossReference = beforeCrossReference;
        this.betweenEntry = betweenEntry;
        this.betweenPageNumbers = betweenPageNumbers;
        this.betweenPageRange = betweenPageRange;
        this.crossReferenceStyle = crossReferenceStyle;
        this.followingEntry = followingEntry;
        this.levelFormat = levelFormat;
        this.range = range;
    }


    /**
     * Gets the beforeCrossReference value for this Separators.
     * 
     * @return beforeCrossReference
     */
    public java.lang.String getBeforeCrossReference() {
        return beforeCrossReference;
    }


    /**
     * Sets the beforeCrossReference value for this Separators.
     * 
     * @param beforeCrossReference
     */
    public void setBeforeCrossReference(java.lang.String beforeCrossReference) {
        this.beforeCrossReference = beforeCrossReference;
    }


    /**
     * Gets the betweenEntry value for this Separators.
     * 
     * @return betweenEntry
     */
    public java.lang.String getBetweenEntry() {
        return betweenEntry;
    }


    /**
     * Sets the betweenEntry value for this Separators.
     * 
     * @param betweenEntry
     */
    public void setBetweenEntry(java.lang.String betweenEntry) {
        this.betweenEntry = betweenEntry;
    }


    /**
     * Gets the betweenPageNumbers value for this Separators.
     * 
     * @return betweenPageNumbers
     */
    public java.lang.String getBetweenPageNumbers() {
        return betweenPageNumbers;
    }


    /**
     * Sets the betweenPageNumbers value for this Separators.
     * 
     * @param betweenPageNumbers
     */
    public void setBetweenPageNumbers(java.lang.String betweenPageNumbers) {
        this.betweenPageNumbers = betweenPageNumbers;
    }


    /**
     * Gets the betweenPageRange value for this Separators.
     * 
     * @return betweenPageRange
     */
    public java.lang.String getBetweenPageRange() {
        return betweenPageRange;
    }


    /**
     * Sets the betweenPageRange value for this Separators.
     * 
     * @param betweenPageRange
     */
    public void setBetweenPageRange(java.lang.String betweenPageRange) {
        this.betweenPageRange = betweenPageRange;
    }


    /**
     * Gets the crossReferenceStyle value for this Separators.
     * 
     * @return crossReferenceStyle
     */
    public java.lang.String getCrossReferenceStyle() {
        return crossReferenceStyle;
    }


    /**
     * Sets the crossReferenceStyle value for this Separators.
     * 
     * @param crossReferenceStyle
     */
    public void setCrossReferenceStyle(java.lang.String crossReferenceStyle) {
        this.crossReferenceStyle = crossReferenceStyle;
    }


    /**
     * Gets the followingEntry value for this Separators.
     * 
     * @return followingEntry
     */
    public java.lang.String getFollowingEntry() {
        return followingEntry;
    }


    /**
     * Sets the followingEntry value for this Separators.
     * 
     * @param followingEntry
     */
    public void setFollowingEntry(java.lang.String followingEntry) {
        this.followingEntry = followingEntry;
    }


    /**
     * Gets the levelFormat value for this Separators.
     * 
     * @return levelFormat
     */
    public java.lang.String getLevelFormat() {
        return levelFormat;
    }


    /**
     * Sets the levelFormat value for this Separators.
     * 
     * @param levelFormat
     */
    public void setLevelFormat(java.lang.String levelFormat) {
        this.levelFormat = levelFormat;
    }


    /**
     * Gets the range value for this Separators.
     * 
     * @return range
     */
    public java.lang.String getRange() {
        return range;
    }


    /**
     * Sets the range value for this Separators.
     * 
     * @param range
     */
    public void setRange(java.lang.String range) {
        this.range = range;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Separators)) return false;
        Separators other = (Separators) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.beforeCrossReference==null && other.getBeforeCrossReference()==null) || 
             (this.beforeCrossReference!=null &&
              this.beforeCrossReference.equals(other.getBeforeCrossReference()))) &&
            ((this.betweenEntry==null && other.getBetweenEntry()==null) || 
             (this.betweenEntry!=null &&
              this.betweenEntry.equals(other.getBetweenEntry()))) &&
            ((this.betweenPageNumbers==null && other.getBetweenPageNumbers()==null) || 
             (this.betweenPageNumbers!=null &&
              this.betweenPageNumbers.equals(other.getBetweenPageNumbers()))) &&
            ((this.betweenPageRange==null && other.getBetweenPageRange()==null) || 
             (this.betweenPageRange!=null &&
              this.betweenPageRange.equals(other.getBetweenPageRange()))) &&
            ((this.crossReferenceStyle==null && other.getCrossReferenceStyle()==null) || 
             (this.crossReferenceStyle!=null &&
              this.crossReferenceStyle.equals(other.getCrossReferenceStyle()))) &&
            ((this.followingEntry==null && other.getFollowingEntry()==null) || 
             (this.followingEntry!=null &&
              this.followingEntry.equals(other.getFollowingEntry()))) &&
            ((this.levelFormat==null && other.getLevelFormat()==null) || 
             (this.levelFormat!=null &&
              this.levelFormat.equals(other.getLevelFormat()))) &&
            ((this.range==null && other.getRange()==null) || 
             (this.range!=null &&
              this.range.equals(other.getRange())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBeforeCrossReference() != null) {
            _hashCode += getBeforeCrossReference().hashCode();
        }
        if (getBetweenEntry() != null) {
            _hashCode += getBetweenEntry().hashCode();
        }
        if (getBetweenPageNumbers() != null) {
            _hashCode += getBetweenPageNumbers().hashCode();
        }
        if (getBetweenPageRange() != null) {
            _hashCode += getBetweenPageRange().hashCode();
        }
        if (getCrossReferenceStyle() != null) {
            _hashCode += getCrossReferenceStyle().hashCode();
        }
        if (getFollowingEntry() != null) {
            _hashCode += getFollowingEntry().hashCode();
        }
        if (getLevelFormat() != null) {
            _hashCode += getLevelFormat().hashCode();
        }
        if (getRange() != null) {
            _hashCode += getRange().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Separators.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Separators"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beforeCrossReference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "beforeCrossReference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("betweenEntry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "betweenEntry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("betweenPageNumbers");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "betweenPageNumbers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("betweenPageRange");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "betweenPageRange"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("crossReferenceStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "crossReferenceStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("followingEntry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "followingEntry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("levelFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "levelFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("range");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "range"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
