package com.socgen.sgs.api.quark.engine.domain.element;

import com.socgen.sgs.api.quark.engine.enums.TBoxTypeEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Represents a template box element available for dynamic tasks.
 * Wraps a SOAP-generated {@link Box} with geometry and type metadata.
 *
 * <p>Never work directly on a TBox without cloning it first (via TElementHelper.clone()),
 * as modifications would affect all tasks sharing the same template.
 *
 * Cross-reference: QXP.Engine.Core.TBox
 */
@Getter
@Setter
public class TBox extends TElement {

    private static final String UNKNOWN_PAGE = "?";

    /** Source SOAP box (the main box definition). */
    private Box srcBox;

    /** Extra SOAP box (used for certain operations like PDF offset). */
    private Box srcExtraBox;

    /** Box content type (CT_TEXT, CT_PICT, CT_NONE, CT_UNKNOWN). */
    private TBoxTypeEnum type = TBoxTypeEnum.CT_UNKNOWN;

    /** Page containing this element ("?" if not evaluated). */
    private String page = UNKNOWN_PAGE;

    /**
     * No-arg constructor for serialization/deserialization.
     */
    public TBox() {
        super();
    }

    /**
     * Create a TBox from a SOAP Box.
     * Extracts name, type, and page from the box properties.
     *
     * @param box the SOAP-generated Box
     */
    public TBox(Box box) {
        super(box.getName());
        this.srcBox = box;

        // Extract box type
        if (box.getBoxType() != null && !box.getBoxType().isBlank()) {
            this.type = TBoxTypeEnum.fromString(box.getBoxType());
        }

        // Extract page from geometry
        if (box.getGeometry() != null && box.getGeometry().getPage() != null) {
            this.page = box.getGeometry().getPage();
        }
    }

    /**
     * Create a TBox from a SOAP Box with an extra box.
     * The extra box enables certain operations (e.g., PDF image offset).
     *
     * @param box the main SOAP-generated Box
     * @param srcExtraBox the extra SOAP-generated Box
     */
    public TBox(Box box, Box srcExtraBox) {
        this(box);
        this.srcExtraBox = srcExtraBox;
    }

    /**
     * Evaluate geometry (left, top, right, bottom, width, height) from the source box.
     *
     * @param qxpProject the QXP project (not used directly for TBox — geometry comes from srcBox)
     */
    @Override
    public void evaluate(Object qxpProject) {
        if (isEvaluated()) {
            return;
        }

        if (srcBox != null && srcBox.getGeometry() != null
                && srcBox.getGeometry().getPosition() != null) {

            String leftStr = srcBox.getGeometry().getPosition().getLeft();
            String topStr = srcBox.getGeometry().getPosition().getTop();
            String rightStr = srcBox.getGeometry().getPosition().getRight();
            String bottomStr = srcBox.getGeometry().getPosition().getBottom();

            setLeft(parseBigDecimal(leftStr));
            setTop(parseBigDecimal(topStr));
            setRight(parseBigDecimal(rightStr));
            setBottom(parseBigDecimal(bottomStr));

            setWidth(getRight().subtract(getLeft()));
            setHeight(getBottom().subtract(getTop()));
        }

        setEvaluated(true);
    }

    /**
     * Parse a string to BigDecimal safely.
     * Handles comma-separated decimals (French locale).
     */
    private BigDecimal parseBigDecimal(String value) {
        if (value == null || value.isBlank()) {
            return BigDecimal.ZERO;
        }
        try {
            String normalized = value.replace(',', '.');
            return new BigDecimal(normalized);
        } catch (NumberFormatException e) {
            return BigDecimal.ZERO;
        }
    }
}