package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

/**
 * QXPS POST message for deleting a file from the document pool.
 *
 * URL: {baseUrl}/delete/{documentName}
 *
 * Cross-reference: .NET QXPS_Message_Delete
 */
public class DeleteMessage implements QxpsMessage {

    private static final String MESSAGE_PATH = "delete";

    @Override
    public String getCommandPath() {
        return MESSAGE_PATH;
    }

    @Override
    public String getCommandQuery() {
        return null;
    }

    @Override
    public byte[] getData() {
        return null;
    }

    @Override
    public boolean isPost() {
        return true;
    }
}