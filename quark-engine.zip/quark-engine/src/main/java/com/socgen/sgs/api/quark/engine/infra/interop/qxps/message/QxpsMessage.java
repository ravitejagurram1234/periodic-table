package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

/**
 * Contract for a message that can be sent to QuarkXPress Server.
 * URL pattern: {baseUrl}/{path}/{documentName}?{query}
 * When path is null: {baseUrl}/{documentName}?{query}
 *
 * Cross-reference: .NET QXPS_Message_Base
 */
public interface QxpsMessage {

    /** Path segment before document name. Null means no path segment. */
    String getCommandPath();

    /** Query string after the ?. Null means no query. */
    String getCommandQuery();

    /** Binary data for POST requests. Null for GET. */
    byte[] getData();

    /** True = HTTP POST, False = HTTP GET. */
    boolean isPost();

    /**
     * Priority that determines the message's position when several messages are
     * combined into a single QuarkXPress Server URL (ascending = earlier in the URL).
     *
     * Cross-reference: .NET QXPS_Message_Base.Priority
     */
    MessagePriority getPriority();

    /**
     * Optional document-name override. When set (non-null/non-empty), it replaces the
     * caller-supplied document name in the combined URL. Defaults to no override.
     *
     * Cross-reference: .NET QXPS_Message_Base.Get_Document()
     */
    default String getCommandDocument() {
        return null;
    }
}