/**
 * DropCap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class DropCap  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String charCount;

    private java.lang.String lineCount;

    public DropCap() {
    }

    public DropCap(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String charCount,
           java.lang.String lineCount) {
        super(
            request);
        this.charCount = charCount;
        this.lineCount = lineCount;
    }


    /**
     * Gets the charCount value for this DropCap.
     * 
     * @return charCount
     */
    public java.lang.String getCharCount() {
        return charCount;
    }


    /**
     * Sets the charCount value for this DropCap.
     * 
     * @param charCount
     */
    public void setCharCount(java.lang.String charCount) {
        this.charCount = charCount;
    }


    /**
     * Gets the lineCount value for this DropCap.
     * 
     * @return lineCount
     */
    public java.lang.String getLineCount() {
        return lineCount;
    }


    /**
     * Sets the lineCount value for this DropCap.
     * 
     * @param lineCount
     */
    public void setLineCount(java.lang.String lineCount) {
        this.lineCount = lineCount;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DropCap)) return false;
        DropCap other = (DropCap) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.charCount==null && other.getCharCount()==null) || 
             (this.charCount!=null &&
              this.charCount.equals(other.getCharCount()))) &&
            ((this.lineCount==null && other.getLineCount()==null) || 
             (this.lineCount!=null &&
              this.lineCount.equals(other.getLineCount())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCharCount() != null) {
            _hashCode += getCharCount().hashCode();
        }
        if (getLineCount() != null) {
            _hashCode += getLineCount().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DropCap.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DropCap"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("charCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "charCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lineCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lineCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
