package com.socgen.sgs.api.quark.engine.domain;

import com.socgen.sgs.api.quark.engine.domain.project.QxpProject;
import com.socgen.sgs.api.quark.engine.domain.xml.QxpXml;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Project;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.AccessLevel;

/**
 * Domain entity representing a Document.
 * Encapsulates document metadata and content.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentDomain {

    // File prefix constants
    public static final String FILE_DOCUMENT_PREFIX = "D";
    public static final String FILE_GABARIT_PREFIX = "G";
    public static final String FILE_DOCUMENT_GABARIT_PREFIX = "DG";
    public static final String FILE_DOCUMENT_CERTIFIE_GABARIT_PREFIX = "DCG";
    public static final String FILE_DOCUMENT_FINAL_PREFIX = "DF";
    public static final String FILE_GABARIT_TEMPLATE_PREFIX = "GT";

    // File naming patterns
    private static final String FILE_NAME_PREFIX_PATTERN = "%s_%d.%s";

    // Document properties
    private Integer id;
    private byte[] data;
    private String name;
    private String format;
    private String prefix;
    private Integer idLangue;
    private String fileName;
    private String filePoolPath;
    private String fileFullPath;
    private boolean gabarit;
    private boolean modeDegrade = false;
    private DocumentIdentity documentIdentity;

    // ========================================================================
    // XML and Project structure (lazy-loaded)
    // Cross-reference: .NET Document._xml, Document._project, Document._pdfs
    // ========================================================================

    /** Parsed XML structure of this QXP document (lazy-loaded). */
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private QxpXml qxpXml;

    /** Parsed project structure for element analysis (lazy-loaded). */
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private QxpProject qxpProject;

    /** List of PDF page file paths (for multi-page PDF documents). */
    private List<String> pdfFiles = new ArrayList<>();

    /**
     * Constructor for creating a document with full details.
     *
     * @param id the document ID
     * @param name the document name
     * @param format the document format (e.g., QXP, PDF)
     * @param prefix the file prefix
     * @param data the document content
     */
    public DocumentDomain(Integer id, String name, String format, String prefix, byte[] data) {
        this.id = id;
        this.name = name;
        this.format = format;
        this.prefix = prefix;
        this.data = data;
        this.idLangue = 1;  // Default language ID
        this.gabarit = false;
        generateFileNames();
    }

    // ========================================================================
    // XML access (lazy-loaded from QXPS server)
    // Cross-reference: .NET Document.XML property
    // ========================================================================

    /**
     * Get the parsed XML structure of this document.
     * In the .NET code, this is lazy-loaded via QXPS_File_Manager.Get_XML(this).
     * In Java, the XML content must be set externally (via setQxpXml or initXmlFromContent).
     *
     * @return the QxpXml instance, or QxpXml.EMPTY if not available
     */
    public QxpXml getQxpXml() {
        if (this.qxpXml == null) {
            return QxpXml.EMPTY;
        }
        return this.qxpXml;
    }

    /**
     * Set the parsed XML structure.
     *
     * @param qxpXml the QxpXml instance
     */
    public void setQxpXml(QxpXml qxpXml) {
        this.qxpXml = qxpXml;
    }

    /**
     * Initialize QxpXml from a raw XML string.
     * Convenience method to create and set the QxpXml in one call.
     *
     * @param xmlContent the raw XML content from QXPS server
     */
    public void initXmlFromContent(String xmlContent) {
        this.qxpXml = QxpXml.createFromXml(xmlContent);
    }

    // ========================================================================
    // Project access (lazy-loaded from QXPS server)
    // Cross-reference: .NET Document.QXPProject property
    // ========================================================================

    /**
     * Get the parsed project structure for element analysis.
     * In the .NET code, this is lazy-loaded via QXPS_File_Manager.Get_Project(this).
     * In Java, the project must be set externally (via setQxpProject or initProjectFromSoap).
     *
     * @return the QxpProject instance, or QxpProject.EMPTY if not available
     */
    public QxpProject getQxpProject() {
        if (this.qxpProject == null) {
            return QxpProject.EMPTY;
        }
        return this.qxpProject;
    }

    /**
     * Set the parsed project structure.
     *
     * @param qxpProject the QxpProject instance
     */
    public void setQxpProject(QxpProject qxpProject) {
        this.qxpProject = qxpProject;
    }

    /**
     * Initialize QxpProject from a SOAP Project object.
     * Convenience method to create and set the QxpProject in one call.
     *
     * @param soapProject the SOAP-generated Project from QXPS server
     */
    public void initProjectFromSoap(Project soapProject) {
        this.qxpProject = new QxpProject(soapProject);
    }

    // ========================================================================
    // PDF files (for multi-page PDF documents)
    // Cross-reference: .NET Document.PDFFiles property
    // ========================================================================

    /**
     * Get the list of PDF page file paths.
     *
     * @return the list of PDF file paths
     */
    public List<String> getPdfFiles() {
        return this.pdfFiles;
    }

    /**
     * Set the list of PDF page file paths.
     *
     * @param pdfFiles the list of PDF file paths
     */
    public void setPdfFiles(List<String> pdfFiles) {
        this.pdfFiles = pdfFiles;
    }

    /**
     * Get the absolute pool path for a PDF page file.
     * Used by Process_Document PDF handling.
     *
     * Cross-reference: .NET Document.GetPDFFileAbsolutePath(file)
     *
     * @param pdfFileName the PDF file name
     * @param documentPoolBasePath the base path for document pool
     * @return the absolute path to the PDF file
     */
    public String getPdfFileAbsolutePath(String pdfFileName, String documentPoolBasePath) {
        if (pdfFileName == null || documentPoolBasePath == null) {
            return pdfFileName;
        }
        return documentPoolBasePath + "/" + pdfFileName;
    }

    /**
     * Purge cached XML and project data.
     * Called when the document content changes (e.g., after Change_Document).
     *
     * Cross-reference: .NET Document.Change_Document() — purges _xml and _project
     */
    public void purgeXmlAndProject() {
        this.qxpXml = null;
        this.qxpProject = null;
    }

    /**
     * Generate file names from document properties.
     */
    private void generateFileNames() {
        if (this.id != null && this.prefix != null && this.format != null) {
            this.fileName = String.format(FILE_NAME_PREFIX_PATTERN, this.prefix, this.id, this.format.toLowerCase());
        }
    }
}

