/**
 * ConnectionFilterConfig.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ConnectionFilterConfig  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private boolean allowByDefault;

    private int count;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterItem[] items;

    public ConnectionFilterConfig() {
    }

    public ConnectionFilterConfig(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           boolean allowByDefault,
           int count,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterItem[] items) {
        super(
            request);
        this.allowByDefault = allowByDefault;
        this.count = count;
        this.items = items;
    }


    /**
     * Gets the allowByDefault value for this ConnectionFilterConfig.
     * 
     * @return allowByDefault
     */
    public boolean isAllowByDefault() {
        return allowByDefault;
    }


    /**
     * Sets the allowByDefault value for this ConnectionFilterConfig.
     * 
     * @param allowByDefault
     */
    public void setAllowByDefault(boolean allowByDefault) {
        this.allowByDefault = allowByDefault;
    }


    /**
     * Gets the count value for this ConnectionFilterConfig.
     * 
     * @return count
     */
    public int getCount() {
        return count;
    }


    /**
     * Sets the count value for this ConnectionFilterConfig.
     * 
     * @param count
     */
    public void setCount(int count) {
        this.count = count;
    }


    /**
     * Gets the items value for this ConnectionFilterConfig.
     * 
     * @return items
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterItem[] getItems() {
        return items;
    }


    /**
     * Sets the items value for this ConnectionFilterConfig.
     * 
     * @param items
     */
    public void setItems(com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterItem[] items) {
        this.items = items;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConnectionFilterConfig)) return false;
        ConnectionFilterConfig other = (ConnectionFilterConfig) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.allowByDefault == other.isAllowByDefault() &&
            this.count == other.getCount() &&
            ((this.items==null && other.getItems()==null) || 
             (this.items!=null &&
              java.util.Arrays.equals(this.items, other.getItems())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isAllowByDefault() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getCount();
        if (getItems() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getItems());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getItems(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConnectionFilterConfig.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterConfig"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowByDefault");
        elemField.setXmlName(new javax.xml.namespace.QName("", "allowByDefault"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("count");
        elemField.setXmlName(new javax.xml.namespace.QName("", "count"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("items");
        elemField.setXmlName(new javax.xml.namespace.QName("", "items"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterItem"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
