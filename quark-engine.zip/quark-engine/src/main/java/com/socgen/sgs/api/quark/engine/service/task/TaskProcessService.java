package com.socgen.sgs.api.quark.engine.service.task;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;

/** Processes a single task — creates blocs needed for document modifications. */
public interface TaskProcessService {
    void process(TaskBase task);
}

