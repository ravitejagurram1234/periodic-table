/**
 * InlineItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class InlineItem  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ItemEntry[] itemEntries;

    private java.lang.String itemRef;

    public InlineItem() {
    }

    public InlineItem(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ItemEntry[] itemEntries,
           java.lang.String itemRef) {
        super(
            request);
        this.boxes = boxes;
        this.index = index;
        this.itemEntries = itemEntries;
        this.itemRef = itemRef;
    }


    /**
     * Gets the boxes value for this InlineItem.
     * 
     * @return boxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] getBoxes() {
        return boxes;
    }


    /**
     * Sets the boxes value for this InlineItem.
     * 
     * @param boxes
     */
    public void setBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes) {
        this.boxes = boxes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Box getBoxes(int i) {
        return this.boxes[i];
    }

    public void setBoxes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Box _value) {
        this.boxes[i] = _value;
    }


    /**
     * Gets the index value for this InlineItem.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this InlineItem.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the itemEntries value for this InlineItem.
     * 
     * @return itemEntries
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ItemEntry[] getItemEntries() {
        return itemEntries;
    }


    /**
     * Sets the itemEntries value for this InlineItem.
     * 
     * @param itemEntries
     */
    public void setItemEntries(com.socgen.sgs.api.quark.engine.integration.soap.generated.ItemEntry[] itemEntries) {
        this.itemEntries = itemEntries;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ItemEntry getItemEntries(int i) {
        return this.itemEntries[i];
    }

    public void setItemEntries(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.ItemEntry _value) {
        this.itemEntries[i] = _value;
    }


    /**
     * Gets the itemRef value for this InlineItem.
     * 
     * @return itemRef
     */
    public java.lang.String getItemRef() {
        return itemRef;
    }


    /**
     * Sets the itemRef value for this InlineItem.
     * 
     * @param itemRef
     */
    public void setItemRef(java.lang.String itemRef) {
        this.itemRef = itemRef;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof InlineItem)) return false;
        InlineItem other = (InlineItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.boxes==null && other.getBoxes()==null) || 
             (this.boxes!=null &&
              java.util.Arrays.equals(this.boxes, other.getBoxes()))) &&
            this.index == other.getIndex() &&
            ((this.itemEntries==null && other.getItemEntries()==null) || 
             (this.itemEntries!=null &&
              java.util.Arrays.equals(this.itemEntries, other.getItemEntries()))) &&
            ((this.itemRef==null && other.getItemRef()==null) || 
             (this.itemRef!=null &&
              this.itemRef.equals(other.getItemRef())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getIndex();
        if (getItemEntries() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getItemEntries());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getItemEntries(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getItemRef() != null) {
            _hashCode += getItemRef().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InlineItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Box"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("itemEntries");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "itemEntries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ItemEntry"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("itemRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "itemRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
