package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Contains geometry information for a DRow.
 *
 * Cross-reference: QXP.Engine.Core.DRow_Info
 */
@Getter
@Setter
public class DRowInfo {

    /** Current height of the row in points. */
    private BigDecimal height = BigDecimal.ZERO;

    /** Current width of the row in points. */
    private BigDecimal width = BigDecimal.ZERO;

    /** Page number of the row. */
    private int page;

    /** Column number of the row. */
    private int column;

    public DRowInfo() {
    }

    /**
     * Clone this row info to create an independent copy.
     *
     * @return a new DRowInfo with the same values
     */
    public DRowInfo cloneInfo() {
        DRowInfo newInfo = new DRowInfo();
        newInfo.setHeight(this.height);
        newInfo.setPage(this.page);
        return newInfo;
    }
}