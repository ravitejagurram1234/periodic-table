package com.socgen.sgs.api.quark.engine.business;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.infra.dao.GetInParamsDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
/** Orchestrates retrieval and population of input parameters for a run. */
@Component
@RequiredArgsConstructor
@Slf4j
public class GetInParamsBusiness {
    private final GetInParamsDao getInParamsDao;
    public void execute(Run run) {
        log.info("Business layer: loading in-params for runId: {}", run.getId());
        getInParamsDao.getInParams(run);
    }
}
