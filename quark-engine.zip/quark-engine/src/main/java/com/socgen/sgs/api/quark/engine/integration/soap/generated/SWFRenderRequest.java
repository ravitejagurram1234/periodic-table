/**
 * SWFRenderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class SWFRenderRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String JPEGQuality;

    private java.lang.String afterPage;

    private java.lang.String compressAudio;

    private java.lang.String compressSWF;

    private java.lang.String download;

    private java.lang.String embedAllFonts;

    private java.lang.String fullScreen;

    private java.lang.String layout;

    private java.lang.String movePages;

    private java.lang.String page;

    private java.lang.String pages;

    private java.lang.String spreads;

    private java.lang.String updateFullRes;

    private java.lang.String version;

    public SWFRenderRequest() {
    }

    public SWFRenderRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String JPEGQuality,
           java.lang.String afterPage,
           java.lang.String compressAudio,
           java.lang.String compressSWF,
           java.lang.String download,
           java.lang.String embedAllFonts,
           java.lang.String fullScreen,
           java.lang.String layout,
           java.lang.String movePages,
           java.lang.String page,
           java.lang.String pages,
           java.lang.String spreads,
           java.lang.String updateFullRes,
           java.lang.String version) {
        super(
            request);
        this.JPEGQuality = JPEGQuality;
        this.afterPage = afterPage;
        this.compressAudio = compressAudio;
        this.compressSWF = compressSWF;
        this.download = download;
        this.embedAllFonts = embedAllFonts;
        this.fullScreen = fullScreen;
        this.layout = layout;
        this.movePages = movePages;
        this.page = page;
        this.pages = pages;
        this.spreads = spreads;
        this.updateFullRes = updateFullRes;
        this.version = version;
    }


    /**
     * Gets the JPEGQuality value for this SWFRenderRequest.
     * 
     * @return JPEGQuality
     */
    public java.lang.String getJPEGQuality() {
        return JPEGQuality;
    }


    /**
     * Sets the JPEGQuality value for this SWFRenderRequest.
     * 
     * @param JPEGQuality
     */
    public void setJPEGQuality(java.lang.String JPEGQuality) {
        this.JPEGQuality = JPEGQuality;
    }


    /**
     * Gets the afterPage value for this SWFRenderRequest.
     * 
     * @return afterPage
     */
    public java.lang.String getAfterPage() {
        return afterPage;
    }


    /**
     * Sets the afterPage value for this SWFRenderRequest.
     * 
     * @param afterPage
     */
    public void setAfterPage(java.lang.String afterPage) {
        this.afterPage = afterPage;
    }


    /**
     * Gets the compressAudio value for this SWFRenderRequest.
     * 
     * @return compressAudio
     */
    public java.lang.String getCompressAudio() {
        return compressAudio;
    }


    /**
     * Sets the compressAudio value for this SWFRenderRequest.
     * 
     * @param compressAudio
     */
    public void setCompressAudio(java.lang.String compressAudio) {
        this.compressAudio = compressAudio;
    }


    /**
     * Gets the compressSWF value for this SWFRenderRequest.
     * 
     * @return compressSWF
     */
    public java.lang.String getCompressSWF() {
        return compressSWF;
    }


    /**
     * Sets the compressSWF value for this SWFRenderRequest.
     * 
     * @param compressSWF
     */
    public void setCompressSWF(java.lang.String compressSWF) {
        this.compressSWF = compressSWF;
    }


    /**
     * Gets the download value for this SWFRenderRequest.
     * 
     * @return download
     */
    public java.lang.String getDownload() {
        return download;
    }


    /**
     * Sets the download value for this SWFRenderRequest.
     * 
     * @param download
     */
    public void setDownload(java.lang.String download) {
        this.download = download;
    }


    /**
     * Gets the embedAllFonts value for this SWFRenderRequest.
     * 
     * @return embedAllFonts
     */
    public java.lang.String getEmbedAllFonts() {
        return embedAllFonts;
    }


    /**
     * Sets the embedAllFonts value for this SWFRenderRequest.
     * 
     * @param embedAllFonts
     */
    public void setEmbedAllFonts(java.lang.String embedAllFonts) {
        this.embedAllFonts = embedAllFonts;
    }


    /**
     * Gets the fullScreen value for this SWFRenderRequest.
     * 
     * @return fullScreen
     */
    public java.lang.String getFullScreen() {
        return fullScreen;
    }


    /**
     * Sets the fullScreen value for this SWFRenderRequest.
     * 
     * @param fullScreen
     */
    public void setFullScreen(java.lang.String fullScreen) {
        this.fullScreen = fullScreen;
    }


    /**
     * Gets the layout value for this SWFRenderRequest.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this SWFRenderRequest.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the movePages value for this SWFRenderRequest.
     * 
     * @return movePages
     */
    public java.lang.String getMovePages() {
        return movePages;
    }


    /**
     * Sets the movePages value for this SWFRenderRequest.
     * 
     * @param movePages
     */
    public void setMovePages(java.lang.String movePages) {
        this.movePages = movePages;
    }


    /**
     * Gets the page value for this SWFRenderRequest.
     * 
     * @return page
     */
    public java.lang.String getPage() {
        return page;
    }


    /**
     * Sets the page value for this SWFRenderRequest.
     * 
     * @param page
     */
    public void setPage(java.lang.String page) {
        this.page = page;
    }


    /**
     * Gets the pages value for this SWFRenderRequest.
     * 
     * @return pages
     */
    public java.lang.String getPages() {
        return pages;
    }


    /**
     * Sets the pages value for this SWFRenderRequest.
     * 
     * @param pages
     */
    public void setPages(java.lang.String pages) {
        this.pages = pages;
    }


    /**
     * Gets the spreads value for this SWFRenderRequest.
     * 
     * @return spreads
     */
    public java.lang.String getSpreads() {
        return spreads;
    }


    /**
     * Sets the spreads value for this SWFRenderRequest.
     * 
     * @param spreads
     */
    public void setSpreads(java.lang.String spreads) {
        this.spreads = spreads;
    }


    /**
     * Gets the updateFullRes value for this SWFRenderRequest.
     * 
     * @return updateFullRes
     */
    public java.lang.String getUpdateFullRes() {
        return updateFullRes;
    }


    /**
     * Sets the updateFullRes value for this SWFRenderRequest.
     * 
     * @param updateFullRes
     */
    public void setUpdateFullRes(java.lang.String updateFullRes) {
        this.updateFullRes = updateFullRes;
    }


    /**
     * Gets the version value for this SWFRenderRequest.
     * 
     * @return version
     */
    public java.lang.String getVersion() {
        return version;
    }


    /**
     * Sets the version value for this SWFRenderRequest.
     * 
     * @param version
     */
    public void setVersion(java.lang.String version) {
        this.version = version;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SWFRenderRequest)) return false;
        SWFRenderRequest other = (SWFRenderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.JPEGQuality==null && other.getJPEGQuality()==null) || 
             (this.JPEGQuality!=null &&
              this.JPEGQuality.equals(other.getJPEGQuality()))) &&
            ((this.afterPage==null && other.getAfterPage()==null) || 
             (this.afterPage!=null &&
              this.afterPage.equals(other.getAfterPage()))) &&
            ((this.compressAudio==null && other.getCompressAudio()==null) || 
             (this.compressAudio!=null &&
              this.compressAudio.equals(other.getCompressAudio()))) &&
            ((this.compressSWF==null && other.getCompressSWF()==null) || 
             (this.compressSWF!=null &&
              this.compressSWF.equals(other.getCompressSWF()))) &&
            ((this.download==null && other.getDownload()==null) || 
             (this.download!=null &&
              this.download.equals(other.getDownload()))) &&
            ((this.embedAllFonts==null && other.getEmbedAllFonts()==null) || 
             (this.embedAllFonts!=null &&
              this.embedAllFonts.equals(other.getEmbedAllFonts()))) &&
            ((this.fullScreen==null && other.getFullScreen()==null) || 
             (this.fullScreen!=null &&
              this.fullScreen.equals(other.getFullScreen()))) &&
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.movePages==null && other.getMovePages()==null) || 
             (this.movePages!=null &&
              this.movePages.equals(other.getMovePages()))) &&
            ((this.page==null && other.getPage()==null) || 
             (this.page!=null &&
              this.page.equals(other.getPage()))) &&
            ((this.pages==null && other.getPages()==null) || 
             (this.pages!=null &&
              this.pages.equals(other.getPages()))) &&
            ((this.spreads==null && other.getSpreads()==null) || 
             (this.spreads!=null &&
              this.spreads.equals(other.getSpreads()))) &&
            ((this.updateFullRes==null && other.getUpdateFullRes()==null) || 
             (this.updateFullRes!=null &&
              this.updateFullRes.equals(other.getUpdateFullRes()))) &&
            ((this.version==null && other.getVersion()==null) || 
             (this.version!=null &&
              this.version.equals(other.getVersion())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getJPEGQuality() != null) {
            _hashCode += getJPEGQuality().hashCode();
        }
        if (getAfterPage() != null) {
            _hashCode += getAfterPage().hashCode();
        }
        if (getCompressAudio() != null) {
            _hashCode += getCompressAudio().hashCode();
        }
        if (getCompressSWF() != null) {
            _hashCode += getCompressSWF().hashCode();
        }
        if (getDownload() != null) {
            _hashCode += getDownload().hashCode();
        }
        if (getEmbedAllFonts() != null) {
            _hashCode += getEmbedAllFonts().hashCode();
        }
        if (getFullScreen() != null) {
            _hashCode += getFullScreen().hashCode();
        }
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getMovePages() != null) {
            _hashCode += getMovePages().hashCode();
        }
        if (getPage() != null) {
            _hashCode += getPage().hashCode();
        }
        if (getPages() != null) {
            _hashCode += getPages().hashCode();
        }
        if (getSpreads() != null) {
            _hashCode += getSpreads().hashCode();
        }
        if (getUpdateFullRes() != null) {
            _hashCode += getUpdateFullRes().hashCode();
        }
        if (getVersion() != null) {
            _hashCode += getVersion().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SWFRenderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SWFRenderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JPEGQuality");
        elemField.setXmlName(new javax.xml.namespace.QName("", "JPEGQuality"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("afterPage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "afterPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compressAudio");
        elemField.setXmlName(new javax.xml.namespace.QName("", "compressAudio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compressSWF");
        elemField.setXmlName(new javax.xml.namespace.QName("", "compressSWF"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("download");
        elemField.setXmlName(new javax.xml.namespace.QName("", "download"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("embedAllFonts");
        elemField.setXmlName(new javax.xml.namespace.QName("", "embedAllFonts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fullScreen");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fullScreen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("movePages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "movePages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("page");
        elemField.setXmlName(new javax.xml.namespace.QName("", "page"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spreads");
        elemField.setXmlName(new javax.xml.namespace.QName("", "spreads"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateFullRes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateFullRes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
