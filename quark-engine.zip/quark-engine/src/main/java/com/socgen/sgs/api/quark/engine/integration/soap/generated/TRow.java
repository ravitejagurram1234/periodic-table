/**
 * TRow.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class TRow  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignment;

    private java.lang.String angle;

    private java.lang.String blendMode;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.BottomGrid bottomGrid;

    private java.lang.String breakRowAcrossPages;

    private java.lang.String color;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Entry[] entries;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset;

    private java.lang.String opacity;

    private java.lang.String rowHeight;

    private java.lang.String shade;

    private java.lang.String storyDirection;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TopGrid topGrid;

    private java.lang.String valign;

    public TRow() {
    }

    public TRow(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignment,
           java.lang.String angle,
           java.lang.String blendMode,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.BottomGrid bottomGrid,
           java.lang.String breakRowAcrossPages,
           java.lang.String color,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Entry[] entries,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset,
           java.lang.String opacity,
           java.lang.String rowHeight,
           java.lang.String shade,
           java.lang.String storyDirection,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TopGrid topGrid,
           java.lang.String valign) {
        super(
            request);
        this.alignment = alignment;
        this.angle = angle;
        this.blendMode = blendMode;
        this.border = border;
        this.bottomGrid = bottomGrid;
        this.breakRowAcrossPages = breakRowAcrossPages;
        this.color = color;
        this.entries = entries;
        this.inset = inset;
        this.opacity = opacity;
        this.rowHeight = rowHeight;
        this.shade = shade;
        this.storyDirection = storyDirection;
        this.topGrid = topGrid;
        this.valign = valign;
    }


    /**
     * Gets the alignment value for this TRow.
     * 
     * @return alignment
     */
    public java.lang.String getAlignment() {
        return alignment;
    }


    /**
     * Sets the alignment value for this TRow.
     * 
     * @param alignment
     */
    public void setAlignment(java.lang.String alignment) {
        this.alignment = alignment;
    }


    /**
     * Gets the angle value for this TRow.
     * 
     * @return angle
     */
    public java.lang.String getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this TRow.
     * 
     * @param angle
     */
    public void setAngle(java.lang.String angle) {
        this.angle = angle;
    }


    /**
     * Gets the blendMode value for this TRow.
     * 
     * @return blendMode
     */
    public java.lang.String getBlendMode() {
        return blendMode;
    }


    /**
     * Sets the blendMode value for this TRow.
     * 
     * @param blendMode
     */
    public void setBlendMode(java.lang.String blendMode) {
        this.blendMode = blendMode;
    }


    /**
     * Gets the border value for this TRow.
     * 
     * @return border
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Border getBorder() {
        return border;
    }


    /**
     * Sets the border value for this TRow.
     * 
     * @param border
     */
    public void setBorder(com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border) {
        this.border = border;
    }


    /**
     * Gets the bottomGrid value for this TRow.
     * 
     * @return bottomGrid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.BottomGrid getBottomGrid() {
        return bottomGrid;
    }


    /**
     * Sets the bottomGrid value for this TRow.
     * 
     * @param bottomGrid
     */
    public void setBottomGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.BottomGrid bottomGrid) {
        this.bottomGrid = bottomGrid;
    }


    /**
     * Gets the breakRowAcrossPages value for this TRow.
     * 
     * @return breakRowAcrossPages
     */
    public java.lang.String getBreakRowAcrossPages() {
        return breakRowAcrossPages;
    }


    /**
     * Sets the breakRowAcrossPages value for this TRow.
     * 
     * @param breakRowAcrossPages
     */
    public void setBreakRowAcrossPages(java.lang.String breakRowAcrossPages) {
        this.breakRowAcrossPages = breakRowAcrossPages;
    }


    /**
     * Gets the color value for this TRow.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this TRow.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the entries value for this TRow.
     * 
     * @return entries
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Entry[] getEntries() {
        return entries;
    }


    /**
     * Sets the entries value for this TRow.
     * 
     * @param entries
     */
    public void setEntries(com.socgen.sgs.api.quark.engine.integration.soap.generated.Entry[] entries) {
        this.entries = entries;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Entry getEntries(int i) {
        return this.entries[i];
    }

    public void setEntries(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Entry _value) {
        this.entries[i] = _value;
    }


    /**
     * Gets the inset value for this TRow.
     * 
     * @return inset
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset getInset() {
        return inset;
    }


    /**
     * Sets the inset value for this TRow.
     * 
     * @param inset
     */
    public void setInset(com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset) {
        this.inset = inset;
    }


    /**
     * Gets the opacity value for this TRow.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this TRow.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the rowHeight value for this TRow.
     * 
     * @return rowHeight
     */
    public java.lang.String getRowHeight() {
        return rowHeight;
    }


    /**
     * Sets the rowHeight value for this TRow.
     * 
     * @param rowHeight
     */
    public void setRowHeight(java.lang.String rowHeight) {
        this.rowHeight = rowHeight;
    }


    /**
     * Gets the shade value for this TRow.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this TRow.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the storyDirection value for this TRow.
     * 
     * @return storyDirection
     */
    public java.lang.String getStoryDirection() {
        return storyDirection;
    }


    /**
     * Sets the storyDirection value for this TRow.
     * 
     * @param storyDirection
     */
    public void setStoryDirection(java.lang.String storyDirection) {
        this.storyDirection = storyDirection;
    }


    /**
     * Gets the topGrid value for this TRow.
     * 
     * @return topGrid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TopGrid getTopGrid() {
        return topGrid;
    }


    /**
     * Sets the topGrid value for this TRow.
     * 
     * @param topGrid
     */
    public void setTopGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.TopGrid topGrid) {
        this.topGrid = topGrid;
    }


    /**
     * Gets the valign value for this TRow.
     * 
     * @return valign
     */
    public java.lang.String getValign() {
        return valign;
    }


    /**
     * Sets the valign value for this TRow.
     * 
     * @param valign
     */
    public void setValign(java.lang.String valign) {
        this.valign = valign;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TRow)) return false;
        TRow other = (TRow) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignment==null && other.getAlignment()==null) || 
             (this.alignment!=null &&
              this.alignment.equals(other.getAlignment()))) &&
            ((this.angle==null && other.getAngle()==null) || 
             (this.angle!=null &&
              this.angle.equals(other.getAngle()))) &&
            ((this.blendMode==null && other.getBlendMode()==null) || 
             (this.blendMode!=null &&
              this.blendMode.equals(other.getBlendMode()))) &&
            ((this.border==null && other.getBorder()==null) || 
             (this.border!=null &&
              this.border.equals(other.getBorder()))) &&
            ((this.bottomGrid==null && other.getBottomGrid()==null) || 
             (this.bottomGrid!=null &&
              this.bottomGrid.equals(other.getBottomGrid()))) &&
            ((this.breakRowAcrossPages==null && other.getBreakRowAcrossPages()==null) || 
             (this.breakRowAcrossPages!=null &&
              this.breakRowAcrossPages.equals(other.getBreakRowAcrossPages()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.entries==null && other.getEntries()==null) || 
             (this.entries!=null &&
              java.util.Arrays.equals(this.entries, other.getEntries()))) &&
            ((this.inset==null && other.getInset()==null) || 
             (this.inset!=null &&
              this.inset.equals(other.getInset()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.rowHeight==null && other.getRowHeight()==null) || 
             (this.rowHeight!=null &&
              this.rowHeight.equals(other.getRowHeight()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.storyDirection==null && other.getStoryDirection()==null) || 
             (this.storyDirection!=null &&
              this.storyDirection.equals(other.getStoryDirection()))) &&
            ((this.topGrid==null && other.getTopGrid()==null) || 
             (this.topGrid!=null &&
              this.topGrid.equals(other.getTopGrid()))) &&
            ((this.valign==null && other.getValign()==null) || 
             (this.valign!=null &&
              this.valign.equals(other.getValign())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignment() != null) {
            _hashCode += getAlignment().hashCode();
        }
        if (getAngle() != null) {
            _hashCode += getAngle().hashCode();
        }
        if (getBlendMode() != null) {
            _hashCode += getBlendMode().hashCode();
        }
        if (getBorder() != null) {
            _hashCode += getBorder().hashCode();
        }
        if (getBottomGrid() != null) {
            _hashCode += getBottomGrid().hashCode();
        }
        if (getBreakRowAcrossPages() != null) {
            _hashCode += getBreakRowAcrossPages().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getEntries() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEntries());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEntries(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInset() != null) {
            _hashCode += getInset().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getRowHeight() != null) {
            _hashCode += getRowHeight().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getStoryDirection() != null) {
            _hashCode += getStoryDirection().hashCode();
        }
        if (getTopGrid() != null) {
            _hashCode += getTopGrid().hashCode();
        }
        if (getValign() != null) {
            _hashCode += getValign().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TRow.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TRow"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("angle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "angle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("border");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "border"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Border"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bottomGrid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "bottomGrid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "BottomGrid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("breakRowAcrossPages");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "breakRowAcrossPages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("entries");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "entries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Entry"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Inset"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rowHeight");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rowHeight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("storyDirection");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "storyDirection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topGrid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "topGrid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TopGrid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valign");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "valign"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
