package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a section (group of boxes) in a dynamic report.
 * Contains both relative cells (in tables) and absolute cells (positioned directly).
 *
 * Cross-reference: QXP.Engine.Core.DSection
 */
@Getter
@Setter
public class DSection {

    /** ID of the master page to use. */
    private int idMasterPage;

    /** Tables containing relative cells. */
    private final List<DTable> tables = new ArrayList<>();

    /** Absolute cells positioned directly in the section. */
    private final List<DCell> cells = new ArrayList<>();

    /** Section information (master page reference). */
    private final DSectionInfo info = new DSectionInfo();

    public DSection() {
    }
}