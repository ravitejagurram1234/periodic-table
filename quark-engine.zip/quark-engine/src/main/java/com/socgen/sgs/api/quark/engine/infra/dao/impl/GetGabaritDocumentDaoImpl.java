package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDocumentDao;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

/**
 * DAO implementation that calls Oracle function QXP_PK_RUN.Get_Gabarit_Document.
 * Used for both DOCUMENT_COURANT (id_suivi) and DOCUMENT_SUIVI (id_suivi_gabarit_source).
 */
@Repository
@Slf4j
public class GetGabaritDocumentDaoImpl implements GetGabaritDocumentDao {

    private static final String RESULT_KEY = "result_cursor";
    private final SimpleJdbcCall getGabaritDocumentCall;

    @Autowired
    public GetGabaritDocumentDaoImpl(DataSource dataSource) {
        this.getGabaritDocumentCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_Gabarit_Document")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR,
                                (rs, rowNum) -> mapFromResultSet(rs)),
                        new SqlParameter("p_id_suivi", Types.NUMERIC)
                );
    }

    @Override
    public DocumentDomain getGabaritDocument(Integer idSuivi) {
        log.info("Fetching gabarit document for idSuivi: {}", idSuivi);

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_suivi", idSuivi);

        try {
            Map<String, Object> result = getGabaritDocumentCall.execute(params);

            @SuppressWarnings("unchecked")
            List<DocumentDomain> rows = (List<DocumentDomain>) result.get(RESULT_KEY);

            if (rows == null || rows.isEmpty()) {
                log.error("No gabarit document found for idSuivi: {}", idSuivi);
                throw new IllegalArgumentException(
                        "No gabarit document found for idSuivi: " + idSuivi);
            }

            log.info("Successfully retrieved gabarit document for idSuivi: {}", idSuivi);
            return rows.get(0);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error fetching gabarit document for idSuivi: {}", idSuivi, e);
            throw new RuntimeException("Failed to fetch gabarit document for idSuivi: " + idSuivi, e);
        }
    }

    private DocumentDomain mapFromResultSet(ResultSet rs) throws SQLException {
        DocumentDomain doc = new DocumentDomain();
        doc.setId(rs.getInt("id_document"));
        doc.setName(rs.getString("nom"));
        doc.setFormat("QXP");
        doc.setPrefix(DocumentDomain.FILE_DOCUMENT_GABARIT_PREFIX);
        doc.setData(rs.getBytes("contenu"));
        doc.setIdLangue(rs.getInt("id_langue"));
        doc.setGabarit(true);
        doc.setFileName(String.format("%s_%d.%s", doc.getPrefix(), doc.getId(), doc.getFormat()));
        return doc;
    }
}

