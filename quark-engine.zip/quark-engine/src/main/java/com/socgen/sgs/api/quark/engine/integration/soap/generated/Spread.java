/**
 * Spread.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Spread  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String UID;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.CompositionZone[] compositionZones;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Group[] groups;

    private java.lang.String name;

    private java.lang.String operation;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Page[] pages;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] tables;

    public Spread() {
    }

    public Spread(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String UID,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.CompositionZone[] compositionZones,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Group[] groups,
           java.lang.String name,
           java.lang.String operation,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Page[] pages,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] tables) {
        super(
            request);
        this.UID = UID;
        this.boxes = boxes;
        this.compositionZones = compositionZones;
        this.groups = groups;
        this.name = name;
        this.operation = operation;
        this.pages = pages;
        this.tables = tables;
    }


    /**
     * Gets the UID value for this Spread.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Spread.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the boxes value for this Spread.
     * 
     * @return boxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] getBoxes() {
        return boxes;
    }


    /**
     * Sets the boxes value for this Spread.
     * 
     * @param boxes
     */
    public void setBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes) {
        this.boxes = boxes;
    }


    /**
     * Gets the compositionZones value for this Spread.
     * 
     * @return compositionZones
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CompositionZone[] getCompositionZones() {
        return compositionZones;
    }


    /**
     * Sets the compositionZones value for this Spread.
     * 
     * @param compositionZones
     */
    public void setCompositionZones(com.socgen.sgs.api.quark.engine.integration.soap.generated.CompositionZone[] compositionZones) {
        this.compositionZones = compositionZones;
    }


    /**
     * Gets the groups value for this Spread.
     * 
     * @return groups
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Group[] getGroups() {
        return groups;
    }


    /**
     * Sets the groups value for this Spread.
     * 
     * @param groups
     */
    public void setGroups(com.socgen.sgs.api.quark.engine.integration.soap.generated.Group[] groups) {
        this.groups = groups;
    }


    /**
     * Gets the name value for this Spread.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Spread.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the operation value for this Spread.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this Spread.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the pages value for this Spread.
     * 
     * @return pages
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Page[] getPages() {
        return pages;
    }


    /**
     * Sets the pages value for this Spread.
     * 
     * @param pages
     */
    public void setPages(com.socgen.sgs.api.quark.engine.integration.soap.generated.Page[] pages) {
        this.pages = pages;
    }


    /**
     * Gets the tables value for this Spread.
     * 
     * @return tables
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] getTables() {
        return tables;
    }


    /**
     * Sets the tables value for this Spread.
     * 
     * @param tables
     */
    public void setTables(com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] tables) {
        this.tables = tables;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Spread)) return false;
        Spread other = (Spread) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.boxes==null && other.getBoxes()==null) || 
             (this.boxes!=null &&
              java.util.Arrays.equals(this.boxes, other.getBoxes()))) &&
            ((this.compositionZones==null && other.getCompositionZones()==null) || 
             (this.compositionZones!=null &&
              java.util.Arrays.equals(this.compositionZones, other.getCompositionZones()))) &&
            ((this.groups==null && other.getGroups()==null) || 
             (this.groups!=null &&
              java.util.Arrays.equals(this.groups, other.getGroups()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.pages==null && other.getPages()==null) || 
             (this.pages!=null &&
              java.util.Arrays.equals(this.pages, other.getPages()))) &&
            ((this.tables==null && other.getTables()==null) || 
             (this.tables!=null &&
              java.util.Arrays.equals(this.tables, other.getTables())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCompositionZones() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCompositionZones());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCompositionZones(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGroups() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGroups());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGroups(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getPages() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPages());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPages(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTables() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTables());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTables(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Spread.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Spread"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "boxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Box"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compositionZones");
        elemField.setXmlName(new javax.xml.namespace.QName("", "compositionZones"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "CompositionZone"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groups");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groups"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Group"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Page"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tables");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tables"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Table"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
