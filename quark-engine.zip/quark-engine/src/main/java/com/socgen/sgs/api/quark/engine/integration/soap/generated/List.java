/**
 * List.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class List  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters;

    private int index;

    private java.lang.String listStyle;

    private java.lang.String operation;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    public List() {
    }

    public List(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters,
           int index,
           java.lang.String listStyle,
           java.lang.String operation,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        super(
            request);
        this.groupCharacters = groupCharacters;
        this.index = index;
        this.listStyle = listStyle;
        this.operation = operation;
        this.overMatter = overMatter;
        this.paragraphs = paragraphs;
        this.richText = richText;
    }


    /**
     * Gets the groupCharacters value for this List.
     * 
     * @return groupCharacters
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] getGroupCharacters() {
        return groupCharacters;
    }


    /**
     * Sets the groupCharacters value for this List.
     * 
     * @param groupCharacters
     */
    public void setGroupCharacters(com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters) {
        this.groupCharacters = groupCharacters;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters getGroupCharacters(int i) {
        return this.groupCharacters[i];
    }

    public void setGroupCharacters(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters _value) {
        this.groupCharacters[i] = _value;
    }


    /**
     * Gets the index value for this List.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this List.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the listStyle value for this List.
     * 
     * @return listStyle
     */
    public java.lang.String getListStyle() {
        return listStyle;
    }


    /**
     * Sets the listStyle value for this List.
     * 
     * @param listStyle
     */
    public void setListStyle(java.lang.String listStyle) {
        this.listStyle = listStyle;
    }


    /**
     * Gets the operation value for this List.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this List.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the overMatter value for this List.
     * 
     * @return overMatter
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter getOverMatter() {
        return overMatter;
    }


    /**
     * Sets the overMatter value for this List.
     * 
     * @param overMatter
     */
    public void setOverMatter(com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter) {
        this.overMatter = overMatter;
    }


    /**
     * Gets the paragraphs value for this List.
     * 
     * @return paragraphs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] getParagraphs() {
        return paragraphs;
    }


    /**
     * Sets the paragraphs value for this List.
     * 
     * @param paragraphs
     */
    public void setParagraphs(com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs) {
        this.paragraphs = paragraphs;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph getParagraphs(int i) {
        return this.paragraphs[i];
    }

    public void setParagraphs(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph _value) {
        this.paragraphs[i] = _value;
    }


    /**
     * Gets the richText value for this List.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this List.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText getRichText(int i) {
        return this.richText[i];
    }

    public void setRichText(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText _value) {
        this.richText[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof List)) return false;
        List other = (List) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.groupCharacters==null && other.getGroupCharacters()==null) || 
             (this.groupCharacters!=null &&
              java.util.Arrays.equals(this.groupCharacters, other.getGroupCharacters()))) &&
            this.index == other.getIndex() &&
            ((this.listStyle==null && other.getListStyle()==null) || 
             (this.listStyle!=null &&
              this.listStyle.equals(other.getListStyle()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.overMatter==null && other.getOverMatter()==null) || 
             (this.overMatter!=null &&
              this.overMatter.equals(other.getOverMatter()))) &&
            ((this.paragraphs==null && other.getParagraphs()==null) || 
             (this.paragraphs!=null &&
              java.util.Arrays.equals(this.paragraphs, other.getParagraphs()))) &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getGroupCharacters() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGroupCharacters());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGroupCharacters(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getIndex();
        if (getListStyle() != null) {
            _hashCode += getListStyle().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getOverMatter() != null) {
            _hashCode += getOverMatter().hashCode();
        }
        if (getParagraphs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParagraphs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParagraphs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(List.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "List"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupCharacters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "groupCharacters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "GroupCharacters"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("listStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "listStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overMatter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "overMatter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OverMatter"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paragraphs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "paragraphs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Paragraph"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RichText"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
