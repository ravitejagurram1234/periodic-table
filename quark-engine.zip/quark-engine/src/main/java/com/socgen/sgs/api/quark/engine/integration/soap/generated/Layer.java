/**
 * Layer.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Layer  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String keepRunaround;

    private java.lang.String locked;

    private java.lang.String name;

    private java.lang.String operation;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor RGBColor;

    private java.lang.String suppress;

    private java.lang.String UID;

    private java.lang.String visible;

    public Layer() {
    }

    public Layer(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String keepRunaround,
           java.lang.String locked,
           java.lang.String name,
           java.lang.String operation,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor RGBColor,
           java.lang.String suppress,
           java.lang.String UID,
           java.lang.String visible) {
        super(
            request);
        this.keepRunaround = keepRunaround;
        this.locked = locked;
        this.name = name;
        this.operation = operation;
        this.RGBColor = RGBColor;
        this.suppress = suppress;
        this.UID = UID;
        this.visible = visible;
    }


    /**
     * Gets the keepRunaround value for this Layer.
     * 
     * @return keepRunaround
     */
    public java.lang.String getKeepRunaround() {
        return keepRunaround;
    }


    /**
     * Sets the keepRunaround value for this Layer.
     * 
     * @param keepRunaround
     */
    public void setKeepRunaround(java.lang.String keepRunaround) {
        this.keepRunaround = keepRunaround;
    }


    /**
     * Gets the locked value for this Layer.
     * 
     * @return locked
     */
    public java.lang.String getLocked() {
        return locked;
    }


    /**
     * Sets the locked value for this Layer.
     * 
     * @param locked
     */
    public void setLocked(java.lang.String locked) {
        this.locked = locked;
    }


    /**
     * Gets the name value for this Layer.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Layer.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the operation value for this Layer.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this Layer.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the RGBColor value for this Layer.
     * 
     * @return RGBColor
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor getRGBColor() {
        return RGBColor;
    }


    /**
     * Sets the RGBColor value for this Layer.
     * 
     * @param RGBColor
     */
    public void setRGBColor(com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor RGBColor) {
        this.RGBColor = RGBColor;
    }


    /**
     * Gets the suppress value for this Layer.
     * 
     * @return suppress
     */
    public java.lang.String getSuppress() {
        return suppress;
    }


    /**
     * Sets the suppress value for this Layer.
     * 
     * @param suppress
     */
    public void setSuppress(java.lang.String suppress) {
        this.suppress = suppress;
    }


    /**
     * Gets the UID value for this Layer.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Layer.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the visible value for this Layer.
     * 
     * @return visible
     */
    public java.lang.String getVisible() {
        return visible;
    }


    /**
     * Sets the visible value for this Layer.
     * 
     * @param visible
     */
    public void setVisible(java.lang.String visible) {
        this.visible = visible;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Layer)) return false;
        Layer other = (Layer) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.keepRunaround==null && other.getKeepRunaround()==null) || 
             (this.keepRunaround!=null &&
              this.keepRunaround.equals(other.getKeepRunaround()))) &&
            ((this.locked==null && other.getLocked()==null) || 
             (this.locked!=null &&
              this.locked.equals(other.getLocked()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.RGBColor==null && other.getRGBColor()==null) || 
             (this.RGBColor!=null &&
              this.RGBColor.equals(other.getRGBColor()))) &&
            ((this.suppress==null && other.getSuppress()==null) || 
             (this.suppress!=null &&
              this.suppress.equals(other.getSuppress()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.visible==null && other.getVisible()==null) || 
             (this.visible!=null &&
              this.visible.equals(other.getVisible())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getKeepRunaround() != null) {
            _hashCode += getKeepRunaround().hashCode();
        }
        if (getLocked() != null) {
            _hashCode += getLocked().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getRGBColor() != null) {
            _hashCode += getRGBColor().hashCode();
        }
        if (getSuppress() != null) {
            _hashCode += getSuppress().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getVisible() != null) {
            _hashCode += getVisible().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Layer.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Layer"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keepRunaround");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "keepRunaround"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locked");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "locked"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RGBColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RGBColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RGBColor"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "suppress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("visible");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "visible"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
