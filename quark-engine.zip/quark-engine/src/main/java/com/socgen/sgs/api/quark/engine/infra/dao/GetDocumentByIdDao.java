package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;

/**
 * DAO for loading a generated document by its id. Cross-reference: .NET QXPS_File_Manager.Get_Document
 * (which calls QXP_PK_RUN.Get_Document_ByID). Used by the Run_Previous compartiment path.
 */
public interface GetDocumentByIdDao {

    /**
     * Load a document (QXP) by its id.
     *
     * @param idDocument the document id (e.g. RunProperties.idLastQxp)
     * @return the document, or null if not found
     */
    DocumentDomain getDocumentById(int idDocument);
}