/**
 * Column.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Column  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String autofit;

    private java.lang.String autofitMaxLimit;

    private java.lang.String color;

    private java.lang.String columnCount;

    private java.lang.String columnWidth;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine[] gridLines;

    private java.lang.String mergeColSpan;

    private java.lang.String opacity;

    private java.lang.String shade;

    private java.lang.String split;

    public Column() {
    }

    public Column(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String autofit,
           java.lang.String autofitMaxLimit,
           java.lang.String color,
           java.lang.String columnCount,
           java.lang.String columnWidth,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine[] gridLines,
           java.lang.String mergeColSpan,
           java.lang.String opacity,
           java.lang.String shade,
           java.lang.String split) {
        super(
            request);
        this.autofit = autofit;
        this.autofitMaxLimit = autofitMaxLimit;
        this.color = color;
        this.columnCount = columnCount;
        this.columnWidth = columnWidth;
        this.gridLines = gridLines;
        this.mergeColSpan = mergeColSpan;
        this.opacity = opacity;
        this.shade = shade;
        this.split = split;
    }


    /**
     * Gets the autofit value for this Column.
     * 
     * @return autofit
     */
    public java.lang.String getAutofit() {
        return autofit;
    }


    /**
     * Sets the autofit value for this Column.
     * 
     * @param autofit
     */
    public void setAutofit(java.lang.String autofit) {
        this.autofit = autofit;
    }


    /**
     * Gets the autofitMaxLimit value for this Column.
     * 
     * @return autofitMaxLimit
     */
    public java.lang.String getAutofitMaxLimit() {
        return autofitMaxLimit;
    }


    /**
     * Sets the autofitMaxLimit value for this Column.
     * 
     * @param autofitMaxLimit
     */
    public void setAutofitMaxLimit(java.lang.String autofitMaxLimit) {
        this.autofitMaxLimit = autofitMaxLimit;
    }


    /**
     * Gets the color value for this Column.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this Column.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the columnCount value for this Column.
     * 
     * @return columnCount
     */
    public java.lang.String getColumnCount() {
        return columnCount;
    }


    /**
     * Sets the columnCount value for this Column.
     * 
     * @param columnCount
     */
    public void setColumnCount(java.lang.String columnCount) {
        this.columnCount = columnCount;
    }


    /**
     * Gets the columnWidth value for this Column.
     * 
     * @return columnWidth
     */
    public java.lang.String getColumnWidth() {
        return columnWidth;
    }


    /**
     * Sets the columnWidth value for this Column.
     * 
     * @param columnWidth
     */
    public void setColumnWidth(java.lang.String columnWidth) {
        this.columnWidth = columnWidth;
    }


    /**
     * Gets the gridLines value for this Column.
     * 
     * @return gridLines
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine[] getGridLines() {
        return gridLines;
    }


    /**
     * Sets the gridLines value for this Column.
     * 
     * @param gridLines
     */
    public void setGridLines(com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine[] gridLines) {
        this.gridLines = gridLines;
    }


    /**
     * Gets the mergeColSpan value for this Column.
     * 
     * @return mergeColSpan
     */
    public java.lang.String getMergeColSpan() {
        return mergeColSpan;
    }


    /**
     * Sets the mergeColSpan value for this Column.
     * 
     * @param mergeColSpan
     */
    public void setMergeColSpan(java.lang.String mergeColSpan) {
        this.mergeColSpan = mergeColSpan;
    }


    /**
     * Gets the opacity value for this Column.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this Column.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the shade value for this Column.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this Column.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the split value for this Column.
     * 
     * @return split
     */
    public java.lang.String getSplit() {
        return split;
    }


    /**
     * Sets the split value for this Column.
     * 
     * @param split
     */
    public void setSplit(java.lang.String split) {
        this.split = split;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Column)) return false;
        Column other = (Column) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.autofit==null && other.getAutofit()==null) || 
             (this.autofit!=null &&
              this.autofit.equals(other.getAutofit()))) &&
            ((this.autofitMaxLimit==null && other.getAutofitMaxLimit()==null) || 
             (this.autofitMaxLimit!=null &&
              this.autofitMaxLimit.equals(other.getAutofitMaxLimit()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.columnCount==null && other.getColumnCount()==null) || 
             (this.columnCount!=null &&
              this.columnCount.equals(other.getColumnCount()))) &&
            ((this.columnWidth==null && other.getColumnWidth()==null) || 
             (this.columnWidth!=null &&
              this.columnWidth.equals(other.getColumnWidth()))) &&
            ((this.gridLines==null && other.getGridLines()==null) || 
             (this.gridLines!=null &&
              java.util.Arrays.equals(this.gridLines, other.getGridLines()))) &&
            ((this.mergeColSpan==null && other.getMergeColSpan()==null) || 
             (this.mergeColSpan!=null &&
              this.mergeColSpan.equals(other.getMergeColSpan()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.split==null && other.getSplit()==null) || 
             (this.split!=null &&
              this.split.equals(other.getSplit())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAutofit() != null) {
            _hashCode += getAutofit().hashCode();
        }
        if (getAutofitMaxLimit() != null) {
            _hashCode += getAutofitMaxLimit().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getColumnCount() != null) {
            _hashCode += getColumnCount().hashCode();
        }
        if (getColumnWidth() != null) {
            _hashCode += getColumnWidth().hashCode();
        }
        if (getGridLines() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGridLines());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGridLines(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMergeColSpan() != null) {
            _hashCode += getMergeColSpan().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getSplit() != null) {
            _hashCode += getSplit().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Column.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Column"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("autofit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "autofit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("autofitMaxLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "autofitMaxLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "columnCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("", "columnWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gridLines");
        elemField.setXmlName(new javax.xml.namespace.QName("", "gridLines"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GridLine"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mergeColSpan");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mergeColSpan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("split");
        elemField.setXmlName(new javax.xml.namespace.QName("", "split"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
