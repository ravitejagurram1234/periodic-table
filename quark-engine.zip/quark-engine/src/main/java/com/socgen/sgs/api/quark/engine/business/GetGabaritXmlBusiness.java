package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.infra.interop.qxps.client.QxpsHttpClient;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.message.FetchXmlMessage;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.model.QxpsResponseInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

/**
 * Business bridge for fetching a document's full XML (Modifier schema) from QuarkXPress Server.
 * Keeps the service → business → infra boundary (the Check service must not call infra directly).
 *
 * <p>Cross-reference: .NET QXPS_Helper.Get_Xml (document XML, no box filter).
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class GetGabaritXmlBusiness {

    private final QxpsHttpClient qxpsHttpClient;

    /**
     * Fetch the full document XML from the QXPS pool. Returns "" on failure (logged), so the
     * caller can continue gracefully.
     *
     * @param documentName the pool path / document name
     * @return the document XML, or "" if it could not be fetched
     */
    public String fetchXml(String documentName) {
        try {
            QxpsResponseInfo response = qxpsHttpClient.execute(documentName, new FetchXmlMessage());
            // XML is a text response; fall back to decoding bytes if the server returned binary.
            if (response.getTextResponse() != null) {
                return response.getTextResponse();
            }
            byte[] bytes = response.getBinaryResponse();
            return bytes != null ? new String(bytes, StandardCharsets.UTF_8) : "";
        } catch (Exception e) {
            log.error("Failed to fetch XML for document [{}]: {}", documentName, e.getMessage(), e);
            return "";
        }
    }
}