/**
 * QXPressDOMOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class QXPressDOMOptions  implements java.io.Serializable {
    private java.lang.String boxes;

    private java.lang.String compositionZone;

    private java.lang.String compositionZones;

    private java.lang.String jobJacketPath;

    private java.lang.String layout;

    private java.lang.String opCode;

    private java.lang.String relativeGeometry;

    private java.lang.String relativeToPage;

    private java.lang.String sessionId;

    private java.lang.String updateFullRes;

    private java.lang.String updateImage;

    public QXPressDOMOptions() {
    }

    public QXPressDOMOptions(
           java.lang.String boxes,
           java.lang.String compositionZone,
           java.lang.String compositionZones,
           java.lang.String jobJacketPath,
           java.lang.String layout,
           java.lang.String opCode,
           java.lang.String relativeGeometry,
           java.lang.String relativeToPage,
           java.lang.String sessionId,
           java.lang.String updateFullRes,
           java.lang.String updateImage) {
           this.boxes = boxes;
           this.compositionZone = compositionZone;
           this.compositionZones = compositionZones;
           this.jobJacketPath = jobJacketPath;
           this.layout = layout;
           this.opCode = opCode;
           this.relativeGeometry = relativeGeometry;
           this.relativeToPage = relativeToPage;
           this.sessionId = sessionId;
           this.updateFullRes = updateFullRes;
           this.updateImage = updateImage;
    }


    /**
     * Gets the boxes value for this QXPressDOMOptions.
     * 
     * @return boxes
     */
    public java.lang.String getBoxes() {
        return boxes;
    }


    /**
     * Sets the boxes value for this QXPressDOMOptions.
     * 
     * @param boxes
     */
    public void setBoxes(java.lang.String boxes) {
        this.boxes = boxes;
    }


    /**
     * Gets the compositionZone value for this QXPressDOMOptions.
     * 
     * @return compositionZone
     */
    public java.lang.String getCompositionZone() {
        return compositionZone;
    }


    /**
     * Sets the compositionZone value for this QXPressDOMOptions.
     * 
     * @param compositionZone
     */
    public void setCompositionZone(java.lang.String compositionZone) {
        this.compositionZone = compositionZone;
    }


    /**
     * Gets the compositionZones value for this QXPressDOMOptions.
     * 
     * @return compositionZones
     */
    public java.lang.String getCompositionZones() {
        return compositionZones;
    }


    /**
     * Sets the compositionZones value for this QXPressDOMOptions.
     * 
     * @param compositionZones
     */
    public void setCompositionZones(java.lang.String compositionZones) {
        this.compositionZones = compositionZones;
    }


    /**
     * Gets the jobJacketPath value for this QXPressDOMOptions.
     * 
     * @return jobJacketPath
     */
    public java.lang.String getJobJacketPath() {
        return jobJacketPath;
    }


    /**
     * Sets the jobJacketPath value for this QXPressDOMOptions.
     * 
     * @param jobJacketPath
     */
    public void setJobJacketPath(java.lang.String jobJacketPath) {
        this.jobJacketPath = jobJacketPath;
    }


    /**
     * Gets the layout value for this QXPressDOMOptions.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this QXPressDOMOptions.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the opCode value for this QXPressDOMOptions.
     * 
     * @return opCode
     */
    public java.lang.String getOpCode() {
        return opCode;
    }


    /**
     * Sets the opCode value for this QXPressDOMOptions.
     * 
     * @param opCode
     */
    public void setOpCode(java.lang.String opCode) {
        this.opCode = opCode;
    }


    /**
     * Gets the relativeGeometry value for this QXPressDOMOptions.
     * 
     * @return relativeGeometry
     */
    public java.lang.String getRelativeGeometry() {
        return relativeGeometry;
    }


    /**
     * Sets the relativeGeometry value for this QXPressDOMOptions.
     * 
     * @param relativeGeometry
     */
    public void setRelativeGeometry(java.lang.String relativeGeometry) {
        this.relativeGeometry = relativeGeometry;
    }


    /**
     * Gets the relativeToPage value for this QXPressDOMOptions.
     * 
     * @return relativeToPage
     */
    public java.lang.String getRelativeToPage() {
        return relativeToPage;
    }


    /**
     * Sets the relativeToPage value for this QXPressDOMOptions.
     * 
     * @param relativeToPage
     */
    public void setRelativeToPage(java.lang.String relativeToPage) {
        this.relativeToPage = relativeToPage;
    }


    /**
     * Gets the sessionId value for this QXPressDOMOptions.
     * 
     * @return sessionId
     */
    public java.lang.String getSessionId() {
        return sessionId;
    }


    /**
     * Sets the sessionId value for this QXPressDOMOptions.
     * 
     * @param sessionId
     */
    public void setSessionId(java.lang.String sessionId) {
        this.sessionId = sessionId;
    }


    /**
     * Gets the updateFullRes value for this QXPressDOMOptions.
     * 
     * @return updateFullRes
     */
    public java.lang.String getUpdateFullRes() {
        return updateFullRes;
    }


    /**
     * Sets the updateFullRes value for this QXPressDOMOptions.
     * 
     * @param updateFullRes
     */
    public void setUpdateFullRes(java.lang.String updateFullRes) {
        this.updateFullRes = updateFullRes;
    }


    /**
     * Gets the updateImage value for this QXPressDOMOptions.
     * 
     * @return updateImage
     */
    public java.lang.String getUpdateImage() {
        return updateImage;
    }


    /**
     * Sets the updateImage value for this QXPressDOMOptions.
     * 
     * @param updateImage
     */
    public void setUpdateImage(java.lang.String updateImage) {
        this.updateImage = updateImage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QXPressDOMOptions)) return false;
        QXPressDOMOptions other = (QXPressDOMOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.boxes==null && other.getBoxes()==null) || 
             (this.boxes!=null &&
              this.boxes.equals(other.getBoxes()))) &&
            ((this.compositionZone==null && other.getCompositionZone()==null) || 
             (this.compositionZone!=null &&
              this.compositionZone.equals(other.getCompositionZone()))) &&
            ((this.compositionZones==null && other.getCompositionZones()==null) || 
             (this.compositionZones!=null &&
              this.compositionZones.equals(other.getCompositionZones()))) &&
            ((this.jobJacketPath==null && other.getJobJacketPath()==null) || 
             (this.jobJacketPath!=null &&
              this.jobJacketPath.equals(other.getJobJacketPath()))) &&
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.opCode==null && other.getOpCode()==null) || 
             (this.opCode!=null &&
              this.opCode.equals(other.getOpCode()))) &&
            ((this.relativeGeometry==null && other.getRelativeGeometry()==null) || 
             (this.relativeGeometry!=null &&
              this.relativeGeometry.equals(other.getRelativeGeometry()))) &&
            ((this.relativeToPage==null && other.getRelativeToPage()==null) || 
             (this.relativeToPage!=null &&
              this.relativeToPage.equals(other.getRelativeToPage()))) &&
            ((this.sessionId==null && other.getSessionId()==null) || 
             (this.sessionId!=null &&
              this.sessionId.equals(other.getSessionId()))) &&
            ((this.updateFullRes==null && other.getUpdateFullRes()==null) || 
             (this.updateFullRes!=null &&
              this.updateFullRes.equals(other.getUpdateFullRes()))) &&
            ((this.updateImage==null && other.getUpdateImage()==null) || 
             (this.updateImage!=null &&
              this.updateImage.equals(other.getUpdateImage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBoxes() != null) {
            _hashCode += getBoxes().hashCode();
        }
        if (getCompositionZone() != null) {
            _hashCode += getCompositionZone().hashCode();
        }
        if (getCompositionZones() != null) {
            _hashCode += getCompositionZones().hashCode();
        }
        if (getJobJacketPath() != null) {
            _hashCode += getJobJacketPath().hashCode();
        }
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getOpCode() != null) {
            _hashCode += getOpCode().hashCode();
        }
        if (getRelativeGeometry() != null) {
            _hashCode += getRelativeGeometry().hashCode();
        }
        if (getRelativeToPage() != null) {
            _hashCode += getRelativeToPage().hashCode();
        }
        if (getSessionId() != null) {
            _hashCode += getSessionId().hashCode();
        }
        if (getUpdateFullRes() != null) {
            _hashCode += getUpdateFullRes().hashCode();
        }
        if (getUpdateImage() != null) {
            _hashCode += getUpdateImage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QXPressDOMOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "QXPressDOMOptions"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "boxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compositionZone");
        elemField.setXmlName(new javax.xml.namespace.QName("", "compositionZone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compositionZones");
        elemField.setXmlName(new javax.xml.namespace.QName("", "compositionZones"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jobJacketPath");
        elemField.setXmlName(new javax.xml.namespace.QName("", "jobJacketPath"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "opCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relativeGeometry");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relativeGeometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relativeToPage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relativeToPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sessionId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sessionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateFullRes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateFullRes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateImage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateImage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
