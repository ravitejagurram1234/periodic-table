package com.socgen.sgs.api.quark.engine.infra.interop.qxps.identity;

import com.socgen.sgs.api.quark.engine.domain.DocumentIdentity;
import com.socgen.sgs.api.quark.engine.domain.port.DocumentIdentityPort;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.message.FetchXmlMessage;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.client.QxpsHttpClient;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.model.QxpsResponseInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Objects;

/**
 * Infra implementation of {@link DocumentIdentityPort}.
 * Fetches XML from QXPS and parses the document identity.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DocumentIdentityService implements DocumentIdentityPort {

    private static final String ID_TAG = "ID";
    private static final String NAME_ATTRIBUTE = "NAME";

    private static final String PIPE_DELIMITER = "\\|";
    private static final int MIN_IDENTITY_PARTS = 6;
    private static final int IDX_FND_CODE = 0;
    private static final int IDX_SUIVI = 1;
    private static final int IDX_RUN = 2;
    private static final int IDX_LANGUE = 3;
    private static final int IDX_DUE_DATE = 4;
    private static final int IDX_GENERATION_DATETIME = 5;
    private static final int IDX_UNIT_CODE = 6;
    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");

    private final QxpsHttpClient qxpsHttpClient;

    /**
     * Fetches XML content for a named box of a document already in the QXPS pool.
     *
     * @param documentName the document name in the pool
     * @param boxName      the box name (e.g. "DID")
     * @return raw XML string
     */
    @Override
    public String fetchXmlForBox(String documentName, String boxName) {
        Objects.requireNonNull(documentName, "documentName must not be null");
        Objects.requireNonNull(boxName, "boxName must not be null");

        log.info("Fetching XML for document: {}, box: {}", documentName, boxName);

        FetchXmlMessage message = new FetchXmlMessage(boxName);
        QxpsResponseInfo response = qxpsHttpClient.execute(documentName, message);

        String xmlContent = response.getTextResponse();
        log.debug("Received XML content length={} for document: {}", xmlContent != null ? xmlContent.length() : 0, documentName);
        return xmlContent;
    }

    /**
     * Extracts text content from an XML string by matching the NAME attribute on an ID element.
     *
     * @param xmlContent the raw XML string
     * @param idName     the value of NAME attribute to search for
     * @return the text value, or null if not found
     */
    @Override
    public String getElementValueByIdName(String xmlContent, String idName) {
        Objects.requireNonNull(xmlContent, "xmlContent must not be null");
        Objects.requireNonNull(idName, "idName must not be null");

        // Strip BOM and leading non-XML characters
        xmlContent = xmlContent.strip();
        if (xmlContent.startsWith("\uFEFF")) {
            xmlContent = xmlContent.substring(1).strip();
        }
        int xmlDeclIndex = xmlContent.indexOf("<?xml");
        int rootIndex = xmlContent.indexOf("<");
        if (xmlDeclIndex > 0) {
            xmlContent = xmlContent.substring(xmlDeclIndex);
        } else if (rootIndex > 0) {
            xmlContent = xmlContent.substring(rootIndex);
        }

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Security: disable external entities (XXE prevention)
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);

            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(xmlContent)));
            document.getDocumentElement().normalize();

            NodeList idElements = document.getElementsByTagName(ID_TAG);
            for (int i = 0; i < idElements.getLength(); i++) {
                Element idElement = (Element) idElements.item(i);
                if (idName.equals(idElement.getAttribute(NAME_ATTRIBUTE))) {
                    Element boxElement = (Element) idElement.getParentNode();
                    NodeList richTextElements = boxElement.getElementsByTagName("RICHTEXT");
                    if (richTextElements.getLength() > 0) {
                        String value = richTextElements.item(0).getTextContent();
                        log.debug("Found element value for ID NAME '{}': {}", idName, value);
                        return value;
                    }
                }
            }

            log.warn("No element found with ID NAME: {}", idName);
            return null;

        } catch (Exception e) {
            throw new IllegalStateException(
                    String.format("Error parsing XML content for ID NAME: %s", idName), e);
        }
    }

    /**
     * Parses a pipe-separated identity string into a {@link DocumentIdentity}.
     * Format: ID_Fnd_Code|ID_Suivi|ID_Run|ID_Langue|Due_Date|Generation_DateTime|ID_Unit_Code(optional)
     *
     * @param identityString the raw pipe-separated identity value
     * @return populated {@link DocumentIdentity}
     */
    @Override
    public DocumentIdentity parseDocumentIdentity(String identityString) {
        Objects.requireNonNull(identityString, "identityString must not be null");

        if (identityString.trim().isEmpty()) {
            throw new IllegalArgumentException("Identity string must not be empty");
        }

        log.debug("Parsing document identity string: {}", identityString);

        String[] parts = identityString.split(PIPE_DELIMITER, -1);

        if (parts.length < MIN_IDENTITY_PARTS) {
            throw new IllegalArgumentException(String.format(
                    "Invalid identity string format. Expected at least %d parts but found %d. Input: %s",
                    MIN_IDENTITY_PARTS, parts.length, identityString));
        }

        String idFndCode = parts[IDX_FND_CODE].trim();
        String idSuivi = parts[IDX_SUIVI].trim();
        String idRun = parts[IDX_RUN].trim();
        String idLangue = parts[IDX_LANGUE].trim();
        LocalDateTime dueDate = parseDateTime(parts[IDX_DUE_DATE].trim(), "Due Date");
        LocalDateTime generationDateTime = parseDateTime(parts[IDX_GENERATION_DATETIME].trim(), "Generation DateTime");

        String idUnitCode = null;
        if (parts.length > IDX_UNIT_CODE) {
            String unitCodeValue = parts[IDX_UNIT_CODE].trim();
            if (!unitCodeValue.isEmpty()) {
                idUnitCode = unitCodeValue;
            }
        }

        DocumentIdentity identity = DocumentIdentity.builder()
                .idFndCode(idFndCode)
                .idSuivi(idSuivi)
                .idRun(idRun)
                .idLangue(idLangue)
                .dueDate(dueDate)
                .generationDateTime(generationDateTime)
                .idUnitCode(idUnitCode)
                .build();

        log.info("Successfully parsed document identity: {}", identity);
        return identity;
    }

    private LocalDateTime parseDateTime(String dateTimeString, String fieldName) {
        if (dateTimeString == null || dateTimeString.isEmpty()) {
            throw new IllegalArgumentException(
                    String.format("%s is required but was empty or null", fieldName));
        }
        try {
            return LocalDateTime.parse(dateTimeString, DATE_TIME_FORMATTER);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException(String.format(
                    "Failed to parse %s. Expected format: MM/dd/yyyy HH:mm:ss, but got: %s",
                    fieldName, dateTimeString), e);
        }
    }
}





