package com.socgen.sgs.api.quark.engine.infra.api.v1;

import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;
import com.socgen.sgs.api.quark.engine.service.ProcessRunService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "ap/v1/EngineService")
@Tag(name = "All operations of Engine service", description = "All operations of Engine service")
@RequiredArgsConstructor
@Slf4j
public class EngineServiceController {

    private final ProcessRunService processRunService;

    @PostMapping("/processRun/{runId}")
    public ResponseEntity<String> processRun(@PathVariable Integer runId) {
        log.info("Processing run with runId: {}", runId);
        try {
            RunIdDto runIdDto = new RunIdDto(runId);
            processRunService.runProcessor(runIdDto);
            return ResponseEntity.status(HttpStatus.OK).body("Run processed successfully");
        } catch (Exception e) {
            log.error("Error processing run with runId: {}", runId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error processing run: " + e.getMessage());
        }
    }

    @GetMapping("/fetchRunProperties/{runId}")
    public ResponseEntity<RunProperties> fetchRunProperties(@PathVariable Integer runId) {
        log.info("Fetching run properties for runId: {}", runId);
        try {
            RunIdDto runIdDto = new RunIdDto(runId);
            RunProperties runProperties = processRunService.getRunProperties(runIdDto);
            return ResponseEntity.status(HttpStatus.OK).body(runProperties);
        } catch (Exception e) {
            log.error("Error fetching run properties for runId: {}", runId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}

