package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * QXPS GET message for rendering the document as JPEG.
 *
 * URL: {baseUrl}/jpeg/{documentName}?page=X&spread=Y&box=Z
 *
 * Cross-reference: .NET QXPS_Message_JPEG
 */
@Getter
@Setter
public class JpegRenderMessage implements QxpsMessage {

    private static final String MESSAGE_PATH = "jpeg";

    private String page;
    private String spread;
    private String box;

    public JpegRenderMessage() {
    }

    @Override
    public String getCommandPath() {
        return MESSAGE_PATH;
    }

    @Override
    public String getCommandQuery() {
        List<String> args = new ArrayList<>();
        if (page != null && !page.isEmpty()) {
            args.add("page=" + page);
        }
        if (spread != null && !spread.isEmpty()) {
            args.add("spread=" + spread);
        }
        if (box != null && !box.isEmpty()) {
            args.add("box=" + box);
        }
        return args.isEmpty() ? null : String.join("&", args);
    }

    @Override
    public byte[] getData() {
        return null;
    }

    @Override
    public boolean isPost() {
        return false;
    }

    @Override
    public MessagePriority getPriority() {
        return MessagePriority.ABOVE_NORMAL;
    }
}