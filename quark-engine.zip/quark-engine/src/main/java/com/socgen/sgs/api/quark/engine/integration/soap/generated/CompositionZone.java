/**
 * CompositionZone.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class CompositionZone  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String anchoredIn;

    private java.lang.String blendAngle;

    private java.lang.String blendColor;

    private java.lang.String blendOpacity;

    private java.lang.String blendShape;

    private java.lang.String blendStyle;

    private java.lang.String boxType;

    private java.lang.String color;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry;

    private java.lang.String horizontalBinding;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity interactivity;

    private java.lang.String layoutOpacity;

    private java.lang.String layoutRef;

    private java.lang.String name;

    private java.lang.String opacity;

    private java.lang.String operation;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.PageRef[] pageRefs;

    private java.lang.String path;

    private java.lang.String previewPage;

    private java.lang.String shade;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow;

    private java.lang.String suppressOutput;

    private java.lang.String type;

    private java.lang.String UID;

    private java.lang.String verticalBinding;

    public CompositionZone() {
    }

    public CompositionZone(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String anchoredIn,
           java.lang.String blendAngle,
           java.lang.String blendColor,
           java.lang.String blendOpacity,
           java.lang.String blendShape,
           java.lang.String blendStyle,
           java.lang.String boxType,
           java.lang.String color,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry,
           java.lang.String horizontalBinding,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity interactivity,
           java.lang.String layoutOpacity,
           java.lang.String layoutRef,
           java.lang.String name,
           java.lang.String opacity,
           java.lang.String operation,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.PageRef[] pageRefs,
           java.lang.String path,
           java.lang.String previewPage,
           java.lang.String shade,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow,
           java.lang.String suppressOutput,
           java.lang.String type,
           java.lang.String UID,
           java.lang.String verticalBinding) {
        super(
            request);
        this.anchoredIn = anchoredIn;
        this.blendAngle = blendAngle;
        this.blendColor = blendColor;
        this.blendOpacity = blendOpacity;
        this.blendShape = blendShape;
        this.blendStyle = blendStyle;
        this.boxType = boxType;
        this.color = color;
        this.frame = frame;
        this.geometry = geometry;
        this.horizontalBinding = horizontalBinding;
        this.index = index;
        this.interactivity = interactivity;
        this.layoutOpacity = layoutOpacity;
        this.layoutRef = layoutRef;
        this.name = name;
        this.opacity = opacity;
        this.operation = operation;
        this.pageRefs = pageRefs;
        this.path = path;
        this.previewPage = previewPage;
        this.shade = shade;
        this.shadow = shadow;
        this.suppressOutput = suppressOutput;
        this.type = type;
        this.UID = UID;
        this.verticalBinding = verticalBinding;
    }


    /**
     * Gets the anchoredIn value for this CompositionZone.
     * 
     * @return anchoredIn
     */
    public java.lang.String getAnchoredIn() {
        return anchoredIn;
    }


    /**
     * Sets the anchoredIn value for this CompositionZone.
     * 
     * @param anchoredIn
     */
    public void setAnchoredIn(java.lang.String anchoredIn) {
        this.anchoredIn = anchoredIn;
    }


    /**
     * Gets the blendAngle value for this CompositionZone.
     * 
     * @return blendAngle
     */
    public java.lang.String getBlendAngle() {
        return blendAngle;
    }


    /**
     * Sets the blendAngle value for this CompositionZone.
     * 
     * @param blendAngle
     */
    public void setBlendAngle(java.lang.String blendAngle) {
        this.blendAngle = blendAngle;
    }


    /**
     * Gets the blendColor value for this CompositionZone.
     * 
     * @return blendColor
     */
    public java.lang.String getBlendColor() {
        return blendColor;
    }


    /**
     * Sets the blendColor value for this CompositionZone.
     * 
     * @param blendColor
     */
    public void setBlendColor(java.lang.String blendColor) {
        this.blendColor = blendColor;
    }


    /**
     * Gets the blendOpacity value for this CompositionZone.
     * 
     * @return blendOpacity
     */
    public java.lang.String getBlendOpacity() {
        return blendOpacity;
    }


    /**
     * Sets the blendOpacity value for this CompositionZone.
     * 
     * @param blendOpacity
     */
    public void setBlendOpacity(java.lang.String blendOpacity) {
        this.blendOpacity = blendOpacity;
    }


    /**
     * Gets the blendShape value for this CompositionZone.
     * 
     * @return blendShape
     */
    public java.lang.String getBlendShape() {
        return blendShape;
    }


    /**
     * Sets the blendShape value for this CompositionZone.
     * 
     * @param blendShape
     */
    public void setBlendShape(java.lang.String blendShape) {
        this.blendShape = blendShape;
    }


    /**
     * Gets the blendStyle value for this CompositionZone.
     * 
     * @return blendStyle
     */
    public java.lang.String getBlendStyle() {
        return blendStyle;
    }


    /**
     * Sets the blendStyle value for this CompositionZone.
     * 
     * @param blendStyle
     */
    public void setBlendStyle(java.lang.String blendStyle) {
        this.blendStyle = blendStyle;
    }


    /**
     * Gets the boxType value for this CompositionZone.
     * 
     * @return boxType
     */
    public java.lang.String getBoxType() {
        return boxType;
    }


    /**
     * Sets the boxType value for this CompositionZone.
     * 
     * @param boxType
     */
    public void setBoxType(java.lang.String boxType) {
        this.boxType = boxType;
    }


    /**
     * Gets the color value for this CompositionZone.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this CompositionZone.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the frame value for this CompositionZone.
     * 
     * @return frame
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame getFrame() {
        return frame;
    }


    /**
     * Sets the frame value for this CompositionZone.
     * 
     * @param frame
     */
    public void setFrame(com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame) {
        this.frame = frame;
    }


    /**
     * Gets the geometry value for this CompositionZone.
     * 
     * @return geometry
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry getGeometry() {
        return geometry;
    }


    /**
     * Sets the geometry value for this CompositionZone.
     * 
     * @param geometry
     */
    public void setGeometry(com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry) {
        this.geometry = geometry;
    }


    /**
     * Gets the horizontalBinding value for this CompositionZone.
     * 
     * @return horizontalBinding
     */
    public java.lang.String getHorizontalBinding() {
        return horizontalBinding;
    }


    /**
     * Sets the horizontalBinding value for this CompositionZone.
     * 
     * @param horizontalBinding
     */
    public void setHorizontalBinding(java.lang.String horizontalBinding) {
        this.horizontalBinding = horizontalBinding;
    }


    /**
     * Gets the index value for this CompositionZone.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this CompositionZone.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the interactivity value for this CompositionZone.
     * 
     * @return interactivity
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity getInteractivity() {
        return interactivity;
    }


    /**
     * Sets the interactivity value for this CompositionZone.
     * 
     * @param interactivity
     */
    public void setInteractivity(com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity interactivity) {
        this.interactivity = interactivity;
    }


    /**
     * Gets the layoutOpacity value for this CompositionZone.
     * 
     * @return layoutOpacity
     */
    public java.lang.String getLayoutOpacity() {
        return layoutOpacity;
    }


    /**
     * Sets the layoutOpacity value for this CompositionZone.
     * 
     * @param layoutOpacity
     */
    public void setLayoutOpacity(java.lang.String layoutOpacity) {
        this.layoutOpacity = layoutOpacity;
    }


    /**
     * Gets the layoutRef value for this CompositionZone.
     * 
     * @return layoutRef
     */
    public java.lang.String getLayoutRef() {
        return layoutRef;
    }


    /**
     * Sets the layoutRef value for this CompositionZone.
     * 
     * @param layoutRef
     */
    public void setLayoutRef(java.lang.String layoutRef) {
        this.layoutRef = layoutRef;
    }


    /**
     * Gets the name value for this CompositionZone.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this CompositionZone.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the opacity value for this CompositionZone.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this CompositionZone.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the operation value for this CompositionZone.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this CompositionZone.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the pageRefs value for this CompositionZone.
     * 
     * @return pageRefs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageRef[] getPageRefs() {
        return pageRefs;
    }


    /**
     * Sets the pageRefs value for this CompositionZone.
     * 
     * @param pageRefs
     */
    public void setPageRefs(com.socgen.sgs.api.quark.engine.integration.soap.generated.PageRef[] pageRefs) {
        this.pageRefs = pageRefs;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageRef getPageRefs(int i) {
        return this.pageRefs[i];
    }

    public void setPageRefs(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.PageRef _value) {
        this.pageRefs[i] = _value;
    }


    /**
     * Gets the path value for this CompositionZone.
     * 
     * @return path
     */
    public java.lang.String getPath() {
        return path;
    }


    /**
     * Sets the path value for this CompositionZone.
     * 
     * @param path
     */
    public void setPath(java.lang.String path) {
        this.path = path;
    }


    /**
     * Gets the previewPage value for this CompositionZone.
     * 
     * @return previewPage
     */
    public java.lang.String getPreviewPage() {
        return previewPage;
    }


    /**
     * Sets the previewPage value for this CompositionZone.
     * 
     * @param previewPage
     */
    public void setPreviewPage(java.lang.String previewPage) {
        this.previewPage = previewPage;
    }


    /**
     * Gets the shade value for this CompositionZone.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this CompositionZone.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the shadow value for this CompositionZone.
     * 
     * @return shadow
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow getShadow() {
        return shadow;
    }


    /**
     * Sets the shadow value for this CompositionZone.
     * 
     * @param shadow
     */
    public void setShadow(com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow) {
        this.shadow = shadow;
    }


    /**
     * Gets the suppressOutput value for this CompositionZone.
     * 
     * @return suppressOutput
     */
    public java.lang.String getSuppressOutput() {
        return suppressOutput;
    }


    /**
     * Sets the suppressOutput value for this CompositionZone.
     * 
     * @param suppressOutput
     */
    public void setSuppressOutput(java.lang.String suppressOutput) {
        this.suppressOutput = suppressOutput;
    }


    /**
     * Gets the type value for this CompositionZone.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this CompositionZone.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }


    /**
     * Gets the UID value for this CompositionZone.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this CompositionZone.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the verticalBinding value for this CompositionZone.
     * 
     * @return verticalBinding
     */
    public java.lang.String getVerticalBinding() {
        return verticalBinding;
    }


    /**
     * Sets the verticalBinding value for this CompositionZone.
     * 
     * @param verticalBinding
     */
    public void setVerticalBinding(java.lang.String verticalBinding) {
        this.verticalBinding = verticalBinding;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CompositionZone)) return false;
        CompositionZone other = (CompositionZone) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.anchoredIn==null && other.getAnchoredIn()==null) || 
             (this.anchoredIn!=null &&
              this.anchoredIn.equals(other.getAnchoredIn()))) &&
            ((this.blendAngle==null && other.getBlendAngle()==null) || 
             (this.blendAngle!=null &&
              this.blendAngle.equals(other.getBlendAngle()))) &&
            ((this.blendColor==null && other.getBlendColor()==null) || 
             (this.blendColor!=null &&
              this.blendColor.equals(other.getBlendColor()))) &&
            ((this.blendOpacity==null && other.getBlendOpacity()==null) || 
             (this.blendOpacity!=null &&
              this.blendOpacity.equals(other.getBlendOpacity()))) &&
            ((this.blendShape==null && other.getBlendShape()==null) || 
             (this.blendShape!=null &&
              this.blendShape.equals(other.getBlendShape()))) &&
            ((this.blendStyle==null && other.getBlendStyle()==null) || 
             (this.blendStyle!=null &&
              this.blendStyle.equals(other.getBlendStyle()))) &&
            ((this.boxType==null && other.getBoxType()==null) || 
             (this.boxType!=null &&
              this.boxType.equals(other.getBoxType()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.frame==null && other.getFrame()==null) || 
             (this.frame!=null &&
              this.frame.equals(other.getFrame()))) &&
            ((this.geometry==null && other.getGeometry()==null) || 
             (this.geometry!=null &&
              this.geometry.equals(other.getGeometry()))) &&
            ((this.horizontalBinding==null && other.getHorizontalBinding()==null) || 
             (this.horizontalBinding!=null &&
              this.horizontalBinding.equals(other.getHorizontalBinding()))) &&
            this.index == other.getIndex() &&
            ((this.interactivity==null && other.getInteractivity()==null) || 
             (this.interactivity!=null &&
              this.interactivity.equals(other.getInteractivity()))) &&
            ((this.layoutOpacity==null && other.getLayoutOpacity()==null) || 
             (this.layoutOpacity!=null &&
              this.layoutOpacity.equals(other.getLayoutOpacity()))) &&
            ((this.layoutRef==null && other.getLayoutRef()==null) || 
             (this.layoutRef!=null &&
              this.layoutRef.equals(other.getLayoutRef()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.pageRefs==null && other.getPageRefs()==null) || 
             (this.pageRefs!=null &&
              java.util.Arrays.equals(this.pageRefs, other.getPageRefs()))) &&
            ((this.path==null && other.getPath()==null) || 
             (this.path!=null &&
              this.path.equals(other.getPath()))) &&
            ((this.previewPage==null && other.getPreviewPage()==null) || 
             (this.previewPage!=null &&
              this.previewPage.equals(other.getPreviewPage()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.shadow==null && other.getShadow()==null) || 
             (this.shadow!=null &&
              this.shadow.equals(other.getShadow()))) &&
            ((this.suppressOutput==null && other.getSuppressOutput()==null) || 
             (this.suppressOutput!=null &&
              this.suppressOutput.equals(other.getSuppressOutput()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.verticalBinding==null && other.getVerticalBinding()==null) || 
             (this.verticalBinding!=null &&
              this.verticalBinding.equals(other.getVerticalBinding())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAnchoredIn() != null) {
            _hashCode += getAnchoredIn().hashCode();
        }
        if (getBlendAngle() != null) {
            _hashCode += getBlendAngle().hashCode();
        }
        if (getBlendColor() != null) {
            _hashCode += getBlendColor().hashCode();
        }
        if (getBlendOpacity() != null) {
            _hashCode += getBlendOpacity().hashCode();
        }
        if (getBlendShape() != null) {
            _hashCode += getBlendShape().hashCode();
        }
        if (getBlendStyle() != null) {
            _hashCode += getBlendStyle().hashCode();
        }
        if (getBoxType() != null) {
            _hashCode += getBoxType().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getFrame() != null) {
            _hashCode += getFrame().hashCode();
        }
        if (getGeometry() != null) {
            _hashCode += getGeometry().hashCode();
        }
        if (getHorizontalBinding() != null) {
            _hashCode += getHorizontalBinding().hashCode();
        }
        _hashCode += getIndex();
        if (getInteractivity() != null) {
            _hashCode += getInteractivity().hashCode();
        }
        if (getLayoutOpacity() != null) {
            _hashCode += getLayoutOpacity().hashCode();
        }
        if (getLayoutRef() != null) {
            _hashCode += getLayoutRef().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getPageRefs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPageRefs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPageRefs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPath() != null) {
            _hashCode += getPath().hashCode();
        }
        if (getPreviewPage() != null) {
            _hashCode += getPreviewPage().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getShadow() != null) {
            _hashCode += getShadow().hashCode();
        }
        if (getSuppressOutput() != null) {
            _hashCode += getSuppressOutput().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getVerticalBinding() != null) {
            _hashCode += getVerticalBinding().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CompositionZone.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CompositionZone"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredIn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredIn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendAngle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendAngle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendShape");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendShape"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frame");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "frame"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Frame"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "geometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Geometry"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horizontalBinding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "horizontalBinding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interactivity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "interactivity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Interactivity"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layoutOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layoutRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageRefs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pageRefs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageRef"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("path");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "path"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("previewPage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "previewPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shadow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Shadow"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppressOutput");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "suppressOutput"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verticalBinding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "verticalBinding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
