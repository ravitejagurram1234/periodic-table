/**
 * CopyFit.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class CopyFit  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String fitAmount;

    private java.lang.String fitLineAmount;

    private java.lang.String numberOfCharacters;

    private java.lang.String numberOfLines;

    private java.lang.String numberOfWords;

    private java.lang.String state;

    private java.lang.String storyDepthAmount;

    public CopyFit() {
    }

    public CopyFit(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String fitAmount,
           java.lang.String fitLineAmount,
           java.lang.String numberOfCharacters,
           java.lang.String numberOfLines,
           java.lang.String numberOfWords,
           java.lang.String state,
           java.lang.String storyDepthAmount) {
        super(
            request);
        this.fitAmount = fitAmount;
        this.fitLineAmount = fitLineAmount;
        this.numberOfCharacters = numberOfCharacters;
        this.numberOfLines = numberOfLines;
        this.numberOfWords = numberOfWords;
        this.state = state;
        this.storyDepthAmount = storyDepthAmount;
    }


    /**
     * Gets the fitAmount value for this CopyFit.
     * 
     * @return fitAmount
     */
    public java.lang.String getFitAmount() {
        return fitAmount;
    }


    /**
     * Sets the fitAmount value for this CopyFit.
     * 
     * @param fitAmount
     */
    public void setFitAmount(java.lang.String fitAmount) {
        this.fitAmount = fitAmount;
    }


    /**
     * Gets the fitLineAmount value for this CopyFit.
     * 
     * @return fitLineAmount
     */
    public java.lang.String getFitLineAmount() {
        return fitLineAmount;
    }


    /**
     * Sets the fitLineAmount value for this CopyFit.
     * 
     * @param fitLineAmount
     */
    public void setFitLineAmount(java.lang.String fitLineAmount) {
        this.fitLineAmount = fitLineAmount;
    }


    /**
     * Gets the numberOfCharacters value for this CopyFit.
     * 
     * @return numberOfCharacters
     */
    public java.lang.String getNumberOfCharacters() {
        return numberOfCharacters;
    }


    /**
     * Sets the numberOfCharacters value for this CopyFit.
     * 
     * @param numberOfCharacters
     */
    public void setNumberOfCharacters(java.lang.String numberOfCharacters) {
        this.numberOfCharacters = numberOfCharacters;
    }


    /**
     * Gets the numberOfLines value for this CopyFit.
     * 
     * @return numberOfLines
     */
    public java.lang.String getNumberOfLines() {
        return numberOfLines;
    }


    /**
     * Sets the numberOfLines value for this CopyFit.
     * 
     * @param numberOfLines
     */
    public void setNumberOfLines(java.lang.String numberOfLines) {
        this.numberOfLines = numberOfLines;
    }


    /**
     * Gets the numberOfWords value for this CopyFit.
     * 
     * @return numberOfWords
     */
    public java.lang.String getNumberOfWords() {
        return numberOfWords;
    }


    /**
     * Sets the numberOfWords value for this CopyFit.
     * 
     * @param numberOfWords
     */
    public void setNumberOfWords(java.lang.String numberOfWords) {
        this.numberOfWords = numberOfWords;
    }


    /**
     * Gets the state value for this CopyFit.
     * 
     * @return state
     */
    public java.lang.String getState() {
        return state;
    }


    /**
     * Sets the state value for this CopyFit.
     * 
     * @param state
     */
    public void setState(java.lang.String state) {
        this.state = state;
    }


    /**
     * Gets the storyDepthAmount value for this CopyFit.
     * 
     * @return storyDepthAmount
     */
    public java.lang.String getStoryDepthAmount() {
        return storyDepthAmount;
    }


    /**
     * Sets the storyDepthAmount value for this CopyFit.
     * 
     * @param storyDepthAmount
     */
    public void setStoryDepthAmount(java.lang.String storyDepthAmount) {
        this.storyDepthAmount = storyDepthAmount;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CopyFit)) return false;
        CopyFit other = (CopyFit) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.fitAmount==null && other.getFitAmount()==null) || 
             (this.fitAmount!=null &&
              this.fitAmount.equals(other.getFitAmount()))) &&
            ((this.fitLineAmount==null && other.getFitLineAmount()==null) || 
             (this.fitLineAmount!=null &&
              this.fitLineAmount.equals(other.getFitLineAmount()))) &&
            ((this.numberOfCharacters==null && other.getNumberOfCharacters()==null) || 
             (this.numberOfCharacters!=null &&
              this.numberOfCharacters.equals(other.getNumberOfCharacters()))) &&
            ((this.numberOfLines==null && other.getNumberOfLines()==null) || 
             (this.numberOfLines!=null &&
              this.numberOfLines.equals(other.getNumberOfLines()))) &&
            ((this.numberOfWords==null && other.getNumberOfWords()==null) || 
             (this.numberOfWords!=null &&
              this.numberOfWords.equals(other.getNumberOfWords()))) &&
            ((this.state==null && other.getState()==null) || 
             (this.state!=null &&
              this.state.equals(other.getState()))) &&
            ((this.storyDepthAmount==null && other.getStoryDepthAmount()==null) || 
             (this.storyDepthAmount!=null &&
              this.storyDepthAmount.equals(other.getStoryDepthAmount())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getFitAmount() != null) {
            _hashCode += getFitAmount().hashCode();
        }
        if (getFitLineAmount() != null) {
            _hashCode += getFitLineAmount().hashCode();
        }
        if (getNumberOfCharacters() != null) {
            _hashCode += getNumberOfCharacters().hashCode();
        }
        if (getNumberOfLines() != null) {
            _hashCode += getNumberOfLines().hashCode();
        }
        if (getNumberOfWords() != null) {
            _hashCode += getNumberOfWords().hashCode();
        }
        if (getState() != null) {
            _hashCode += getState().hashCode();
        }
        if (getStoryDepthAmount() != null) {
            _hashCode += getStoryDepthAmount().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CopyFit.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CopyFit"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fitAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fitAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fitLineAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fitLineAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberOfCharacters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "numberOfCharacters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberOfLines");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "numberOfLines"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numberOfWords");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "numberOfWords"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "state"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("storyDepthAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "storyDepthAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
