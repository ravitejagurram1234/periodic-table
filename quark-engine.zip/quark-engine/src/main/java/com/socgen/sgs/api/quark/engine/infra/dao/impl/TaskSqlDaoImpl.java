package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.infra.dao.TaskSqlDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;

/** Executes task SQL using run InParams as named bind variables. */
@Repository
@Slf4j
public class TaskSqlDaoImpl implements TaskSqlDao {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public TaskSqlDaoImpl(DataSource dataSource) {
        this.jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    @Override
    public List<Map<String, Object>> executeSql(String sql, Map<String, Object> parameters) {
        log.debug("Executing task SQL with {} parameters", parameters.size());
        return jdbcTemplate.queryForList(sql, parameters);
    }
}

