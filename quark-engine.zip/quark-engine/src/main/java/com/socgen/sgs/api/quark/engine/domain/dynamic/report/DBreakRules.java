package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

/**
 * Contains all page/column break rules for a dynamic task.
 * Rules are parsed from a string like "2-4:1-3|5:3-4|6:5,3".
 */
@Getter
public class DBreakRules {

    public static final DBreakRules DEFAULT = new DBreakRules();

    private final String values;
    private final Map<Integer, DBreakRule> rules = new HashMap<>();

    public DBreakRules() {
        this.values = "";
    }

    public DBreakRules(String values) {
        this.values = values != null ? values : "";
        analyseRules(this.values);
    }

    private void analyseRules(String values) {
        if (values == null || values.isBlank()) {
            return;
        }
        String[] ruleStrings = values.split("\\|");
        for (String ruleStr : ruleStrings) {
            if (ruleStr != null && !ruleStr.isBlank()) {
                DBreakRule rule = new DBreakRule(ruleStr);
                addRule(rule);
            }
        }
    }

    private void addRule(DBreakRule rule) {
        for (int level : rule.getLevels()) {
            rules.putIfAbsent(level, rule);
        }
    }

    /** Returns the rule for the given level, or the default rule if not found. */
    public DBreakRule getRule(int level) {
        DBreakRule rule = rules.get(level);
        if (rule != null) {
            return rule;
        }
        DBreakRule wildcard = rules.get(Integer.MIN_VALUE);
        return wildcard != null ? wildcard : DBreakRule.DEFAULT;
    }
}

