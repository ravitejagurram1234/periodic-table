/**
 * XMLRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class XMLRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String box;

    private java.lang.String boxes;

    private java.lang.String compositionZone;

    private java.lang.String compositionZones;

    private java.lang.String copyFitInfo;

    private java.lang.String jobJacketPath;

    private java.lang.String layout;

    private java.lang.String opcode;

    private java.lang.String relativeGeometry;

    private java.lang.String relativeToPage;

    private java.lang.String updateFullRes;

    private java.lang.String updateImage;

    private java.lang.String XSL;

    public XMLRequest() {
    }

    public XMLRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String box,
           java.lang.String boxes,
           java.lang.String compositionZone,
           java.lang.String compositionZones,
           java.lang.String copyFitInfo,
           java.lang.String jobJacketPath,
           java.lang.String layout,
           java.lang.String opcode,
           java.lang.String relativeGeometry,
           java.lang.String relativeToPage,
           java.lang.String updateFullRes,
           java.lang.String updateImage,
           java.lang.String XSL) {
        super(
            request);
        this.box = box;
        this.boxes = boxes;
        this.compositionZone = compositionZone;
        this.compositionZones = compositionZones;
        this.copyFitInfo = copyFitInfo;
        this.jobJacketPath = jobJacketPath;
        this.layout = layout;
        this.opcode = opcode;
        this.relativeGeometry = relativeGeometry;
        this.relativeToPage = relativeToPage;
        this.updateFullRes = updateFullRes;
        this.updateImage = updateImage;
        this.XSL = XSL;
    }


    /**
     * Gets the box value for this XMLRequest.
     * 
     * @return box
     */
    public java.lang.String getBox() {
        return box;
    }


    /**
     * Sets the box value for this XMLRequest.
     * 
     * @param box
     */
    public void setBox(java.lang.String box) {
        this.box = box;
    }


    /**
     * Gets the boxes value for this XMLRequest.
     * 
     * @return boxes
     */
    public java.lang.String getBoxes() {
        return boxes;
    }


    /**
     * Sets the boxes value for this XMLRequest.
     * 
     * @param boxes
     */
    public void setBoxes(java.lang.String boxes) {
        this.boxes = boxes;
    }


    /**
     * Gets the compositionZone value for this XMLRequest.
     * 
     * @return compositionZone
     */
    public java.lang.String getCompositionZone() {
        return compositionZone;
    }


    /**
     * Sets the compositionZone value for this XMLRequest.
     * 
     * @param compositionZone
     */
    public void setCompositionZone(java.lang.String compositionZone) {
        this.compositionZone = compositionZone;
    }


    /**
     * Gets the compositionZones value for this XMLRequest.
     * 
     * @return compositionZones
     */
    public java.lang.String getCompositionZones() {
        return compositionZones;
    }


    /**
     * Sets the compositionZones value for this XMLRequest.
     * 
     * @param compositionZones
     */
    public void setCompositionZones(java.lang.String compositionZones) {
        this.compositionZones = compositionZones;
    }


    /**
     * Gets the copyFitInfo value for this XMLRequest.
     * 
     * @return copyFitInfo
     */
    public java.lang.String getCopyFitInfo() {
        return copyFitInfo;
    }


    /**
     * Sets the copyFitInfo value for this XMLRequest.
     * 
     * @param copyFitInfo
     */
    public void setCopyFitInfo(java.lang.String copyFitInfo) {
        this.copyFitInfo = copyFitInfo;
    }


    /**
     * Gets the jobJacketPath value for this XMLRequest.
     * 
     * @return jobJacketPath
     */
    public java.lang.String getJobJacketPath() {
        return jobJacketPath;
    }


    /**
     * Sets the jobJacketPath value for this XMLRequest.
     * 
     * @param jobJacketPath
     */
    public void setJobJacketPath(java.lang.String jobJacketPath) {
        this.jobJacketPath = jobJacketPath;
    }


    /**
     * Gets the layout value for this XMLRequest.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this XMLRequest.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the opcode value for this XMLRequest.
     * 
     * @return opcode
     */
    public java.lang.String getOpcode() {
        return opcode;
    }


    /**
     * Sets the opcode value for this XMLRequest.
     * 
     * @param opcode
     */
    public void setOpcode(java.lang.String opcode) {
        this.opcode = opcode;
    }


    /**
     * Gets the relativeGeometry value for this XMLRequest.
     * 
     * @return relativeGeometry
     */
    public java.lang.String getRelativeGeometry() {
        return relativeGeometry;
    }


    /**
     * Sets the relativeGeometry value for this XMLRequest.
     * 
     * @param relativeGeometry
     */
    public void setRelativeGeometry(java.lang.String relativeGeometry) {
        this.relativeGeometry = relativeGeometry;
    }


    /**
     * Gets the relativeToPage value for this XMLRequest.
     * 
     * @return relativeToPage
     */
    public java.lang.String getRelativeToPage() {
        return relativeToPage;
    }


    /**
     * Sets the relativeToPage value for this XMLRequest.
     * 
     * @param relativeToPage
     */
    public void setRelativeToPage(java.lang.String relativeToPage) {
        this.relativeToPage = relativeToPage;
    }


    /**
     * Gets the updateFullRes value for this XMLRequest.
     * 
     * @return updateFullRes
     */
    public java.lang.String getUpdateFullRes() {
        return updateFullRes;
    }


    /**
     * Sets the updateFullRes value for this XMLRequest.
     * 
     * @param updateFullRes
     */
    public void setUpdateFullRes(java.lang.String updateFullRes) {
        this.updateFullRes = updateFullRes;
    }


    /**
     * Gets the updateImage value for this XMLRequest.
     * 
     * @return updateImage
     */
    public java.lang.String getUpdateImage() {
        return updateImage;
    }


    /**
     * Sets the updateImage value for this XMLRequest.
     * 
     * @param updateImage
     */
    public void setUpdateImage(java.lang.String updateImage) {
        this.updateImage = updateImage;
    }


    /**
     * Gets the XSL value for this XMLRequest.
     * 
     * @return XSL
     */
    public java.lang.String getXSL() {
        return XSL;
    }


    /**
     * Sets the XSL value for this XMLRequest.
     * 
     * @param XSL
     */
    public void setXSL(java.lang.String XSL) {
        this.XSL = XSL;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof XMLRequest)) return false;
        XMLRequest other = (XMLRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.box==null && other.getBox()==null) || 
             (this.box!=null &&
              this.box.equals(other.getBox()))) &&
            ((this.boxes==null && other.getBoxes()==null) || 
             (this.boxes!=null &&
              this.boxes.equals(other.getBoxes()))) &&
            ((this.compositionZone==null && other.getCompositionZone()==null) || 
             (this.compositionZone!=null &&
              this.compositionZone.equals(other.getCompositionZone()))) &&
            ((this.compositionZones==null && other.getCompositionZones()==null) || 
             (this.compositionZones!=null &&
              this.compositionZones.equals(other.getCompositionZones()))) &&
            ((this.copyFitInfo==null && other.getCopyFitInfo()==null) || 
             (this.copyFitInfo!=null &&
              this.copyFitInfo.equals(other.getCopyFitInfo()))) &&
            ((this.jobJacketPath==null && other.getJobJacketPath()==null) || 
             (this.jobJacketPath!=null &&
              this.jobJacketPath.equals(other.getJobJacketPath()))) &&
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.opcode==null && other.getOpcode()==null) || 
             (this.opcode!=null &&
              this.opcode.equals(other.getOpcode()))) &&
            ((this.relativeGeometry==null && other.getRelativeGeometry()==null) || 
             (this.relativeGeometry!=null &&
              this.relativeGeometry.equals(other.getRelativeGeometry()))) &&
            ((this.relativeToPage==null && other.getRelativeToPage()==null) || 
             (this.relativeToPage!=null &&
              this.relativeToPage.equals(other.getRelativeToPage()))) &&
            ((this.updateFullRes==null && other.getUpdateFullRes()==null) || 
             (this.updateFullRes!=null &&
              this.updateFullRes.equals(other.getUpdateFullRes()))) &&
            ((this.updateImage==null && other.getUpdateImage()==null) || 
             (this.updateImage!=null &&
              this.updateImage.equals(other.getUpdateImage()))) &&
            ((this.XSL==null && other.getXSL()==null) || 
             (this.XSL!=null &&
              this.XSL.equals(other.getXSL())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBox() != null) {
            _hashCode += getBox().hashCode();
        }
        if (getBoxes() != null) {
            _hashCode += getBoxes().hashCode();
        }
        if (getCompositionZone() != null) {
            _hashCode += getCompositionZone().hashCode();
        }
        if (getCompositionZones() != null) {
            _hashCode += getCompositionZones().hashCode();
        }
        if (getCopyFitInfo() != null) {
            _hashCode += getCopyFitInfo().hashCode();
        }
        if (getJobJacketPath() != null) {
            _hashCode += getJobJacketPath().hashCode();
        }
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getOpcode() != null) {
            _hashCode += getOpcode().hashCode();
        }
        if (getRelativeGeometry() != null) {
            _hashCode += getRelativeGeometry().hashCode();
        }
        if (getRelativeToPage() != null) {
            _hashCode += getRelativeToPage().hashCode();
        }
        if (getUpdateFullRes() != null) {
            _hashCode += getUpdateFullRes().hashCode();
        }
        if (getUpdateImage() != null) {
            _hashCode += getUpdateImage().hashCode();
        }
        if (getXSL() != null) {
            _hashCode += getXSL().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(XMLRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "XMLRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("box");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "box"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compositionZone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "compositionZone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compositionZones");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "compositionZones"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("copyFitInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "copyFitInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jobJacketPath");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "jobJacketPath"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opcode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opcode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relativeGeometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "relativeGeometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relativeToPage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "relativeToPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateFullRes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "updateFullRes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateImage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "updateImage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("XSL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "XSL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
