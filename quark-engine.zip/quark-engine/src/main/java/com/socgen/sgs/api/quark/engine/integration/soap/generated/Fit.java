/**
 * Fit.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Fit  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String avoidBoxesBy;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Max max;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Min min;

    private java.lang.String point;

    private java.lang.String proportional;

    public Fit() {
    }

    public Fit(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String avoidBoxesBy,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Max max,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Min min,
           java.lang.String point,
           java.lang.String proportional) {
        super(
            request);
        this.avoidBoxesBy = avoidBoxesBy;
        this.max = max;
        this.min = min;
        this.point = point;
        this.proportional = proportional;
    }


    /**
     * Gets the avoidBoxesBy value for this Fit.
     * 
     * @return avoidBoxesBy
     */
    public java.lang.String getAvoidBoxesBy() {
        return avoidBoxesBy;
    }


    /**
     * Sets the avoidBoxesBy value for this Fit.
     * 
     * @param avoidBoxesBy
     */
    public void setAvoidBoxesBy(java.lang.String avoidBoxesBy) {
        this.avoidBoxesBy = avoidBoxesBy;
    }


    /**
     * Gets the max value for this Fit.
     * 
     * @return max
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Max getMax() {
        return max;
    }


    /**
     * Sets the max value for this Fit.
     * 
     * @param max
     */
    public void setMax(com.socgen.sgs.api.quark.engine.integration.soap.generated.Max max) {
        this.max = max;
    }


    /**
     * Gets the min value for this Fit.
     * 
     * @return min
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Min getMin() {
        return min;
    }


    /**
     * Sets the min value for this Fit.
     * 
     * @param min
     */
    public void setMin(com.socgen.sgs.api.quark.engine.integration.soap.generated.Min min) {
        this.min = min;
    }


    /**
     * Gets the point value for this Fit.
     * 
     * @return point
     */
    public java.lang.String getPoint() {
        return point;
    }


    /**
     * Sets the point value for this Fit.
     * 
     * @param point
     */
    public void setPoint(java.lang.String point) {
        this.point = point;
    }


    /**
     * Gets the proportional value for this Fit.
     * 
     * @return proportional
     */
    public java.lang.String getProportional() {
        return proportional;
    }


    /**
     * Sets the proportional value for this Fit.
     * 
     * @param proportional
     */
    public void setProportional(java.lang.String proportional) {
        this.proportional = proportional;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Fit)) return false;
        Fit other = (Fit) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.avoidBoxesBy==null && other.getAvoidBoxesBy()==null) || 
             (this.avoidBoxesBy!=null &&
              this.avoidBoxesBy.equals(other.getAvoidBoxesBy()))) &&
            ((this.max==null && other.getMax()==null) || 
             (this.max!=null &&
              this.max.equals(other.getMax()))) &&
            ((this.min==null && other.getMin()==null) || 
             (this.min!=null &&
              this.min.equals(other.getMin()))) &&
            ((this.point==null && other.getPoint()==null) || 
             (this.point!=null &&
              this.point.equals(other.getPoint()))) &&
            ((this.proportional==null && other.getProportional()==null) || 
             (this.proportional!=null &&
              this.proportional.equals(other.getProportional())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAvoidBoxesBy() != null) {
            _hashCode += getAvoidBoxesBy().hashCode();
        }
        if (getMax() != null) {
            _hashCode += getMax().hashCode();
        }
        if (getMin() != null) {
            _hashCode += getMin().hashCode();
        }
        if (getPoint() != null) {
            _hashCode += getPoint().hashCode();
        }
        if (getProportional() != null) {
            _hashCode += getProportional().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Fit.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Fit"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("avoidBoxesBy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "avoidBoxesBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("max");
        elemField.setXmlName(new javax.xml.namespace.QName("", "max"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Max"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("min");
        elemField.setXmlName(new javax.xml.namespace.QName("", "min"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Min"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("point");
        elemField.setXmlName(new javax.xml.namespace.QName("", "point"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("proportional");
        elemField.setXmlName(new javax.xml.namespace.QName("", "proportional"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
