package com.socgen.sgs.api.quark.engine.service.task;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;

/** Strategy for post-processing a specific task type. */
public interface TaskPostProcessStrategy<T extends TaskBase> {

    Class<T> getTaskType();

    void postProcess(T task);
}

