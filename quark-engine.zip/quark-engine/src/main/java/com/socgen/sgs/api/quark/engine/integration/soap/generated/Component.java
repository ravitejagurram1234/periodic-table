/**
 * Component.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Component  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String boxID;

    private java.lang.String boxName;

    private java.lang.String columnNumber;

    private java.lang.String componentClass;

    private java.lang.String componentIndex;

    private java.lang.String componentType;

    private java.lang.String name;

    private java.lang.String operation;

    private java.lang.String rowNumber;

    private java.lang.String UID;

    public Component() {
    }

    public Component(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String boxID,
           java.lang.String boxName,
           java.lang.String columnNumber,
           java.lang.String componentClass,
           java.lang.String componentIndex,
           java.lang.String componentType,
           java.lang.String name,
           java.lang.String operation,
           java.lang.String rowNumber,
           java.lang.String UID) {
        super(
            request);
        this.boxID = boxID;
        this.boxName = boxName;
        this.columnNumber = columnNumber;
        this.componentClass = componentClass;
        this.componentIndex = componentIndex;
        this.componentType = componentType;
        this.name = name;
        this.operation = operation;
        this.rowNumber = rowNumber;
        this.UID = UID;
    }


    /**
     * Gets the boxID value for this Component.
     * 
     * @return boxID
     */
    public java.lang.String getBoxID() {
        return boxID;
    }


    /**
     * Sets the boxID value for this Component.
     * 
     * @param boxID
     */
    public void setBoxID(java.lang.String boxID) {
        this.boxID = boxID;
    }


    /**
     * Gets the boxName value for this Component.
     * 
     * @return boxName
     */
    public java.lang.String getBoxName() {
        return boxName;
    }


    /**
     * Sets the boxName value for this Component.
     * 
     * @param boxName
     */
    public void setBoxName(java.lang.String boxName) {
        this.boxName = boxName;
    }


    /**
     * Gets the columnNumber value for this Component.
     * 
     * @return columnNumber
     */
    public java.lang.String getColumnNumber() {
        return columnNumber;
    }


    /**
     * Sets the columnNumber value for this Component.
     * 
     * @param columnNumber
     */
    public void setColumnNumber(java.lang.String columnNumber) {
        this.columnNumber = columnNumber;
    }


    /**
     * Gets the componentClass value for this Component.
     * 
     * @return componentClass
     */
    public java.lang.String getComponentClass() {
        return componentClass;
    }


    /**
     * Sets the componentClass value for this Component.
     * 
     * @param componentClass
     */
    public void setComponentClass(java.lang.String componentClass) {
        this.componentClass = componentClass;
    }


    /**
     * Gets the componentIndex value for this Component.
     * 
     * @return componentIndex
     */
    public java.lang.String getComponentIndex() {
        return componentIndex;
    }


    /**
     * Sets the componentIndex value for this Component.
     * 
     * @param componentIndex
     */
    public void setComponentIndex(java.lang.String componentIndex) {
        this.componentIndex = componentIndex;
    }


    /**
     * Gets the componentType value for this Component.
     * 
     * @return componentType
     */
    public java.lang.String getComponentType() {
        return componentType;
    }


    /**
     * Sets the componentType value for this Component.
     * 
     * @param componentType
     */
    public void setComponentType(java.lang.String componentType) {
        this.componentType = componentType;
    }


    /**
     * Gets the name value for this Component.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Component.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the operation value for this Component.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this Component.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the rowNumber value for this Component.
     * 
     * @return rowNumber
     */
    public java.lang.String getRowNumber() {
        return rowNumber;
    }


    /**
     * Sets the rowNumber value for this Component.
     * 
     * @param rowNumber
     */
    public void setRowNumber(java.lang.String rowNumber) {
        this.rowNumber = rowNumber;
    }


    /**
     * Gets the UID value for this Component.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Component.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Component)) return false;
        Component other = (Component) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.boxID==null && other.getBoxID()==null) || 
             (this.boxID!=null &&
              this.boxID.equals(other.getBoxID()))) &&
            ((this.boxName==null && other.getBoxName()==null) || 
             (this.boxName!=null &&
              this.boxName.equals(other.getBoxName()))) &&
            ((this.columnNumber==null && other.getColumnNumber()==null) || 
             (this.columnNumber!=null &&
              this.columnNumber.equals(other.getColumnNumber()))) &&
            ((this.componentClass==null && other.getComponentClass()==null) || 
             (this.componentClass!=null &&
              this.componentClass.equals(other.getComponentClass()))) &&
            ((this.componentIndex==null && other.getComponentIndex()==null) || 
             (this.componentIndex!=null &&
              this.componentIndex.equals(other.getComponentIndex()))) &&
            ((this.componentType==null && other.getComponentType()==null) || 
             (this.componentType!=null &&
              this.componentType.equals(other.getComponentType()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.rowNumber==null && other.getRowNumber()==null) || 
             (this.rowNumber!=null &&
              this.rowNumber.equals(other.getRowNumber()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBoxID() != null) {
            _hashCode += getBoxID().hashCode();
        }
        if (getBoxName() != null) {
            _hashCode += getBoxName().hashCode();
        }
        if (getColumnNumber() != null) {
            _hashCode += getColumnNumber().hashCode();
        }
        if (getComponentClass() != null) {
            _hashCode += getComponentClass().hashCode();
        }
        if (getComponentIndex() != null) {
            _hashCode += getComponentIndex().hashCode();
        }
        if (getComponentType() != null) {
            _hashCode += getComponentType().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getRowNumber() != null) {
            _hashCode += getRowNumber().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Component.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Component"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("componentClass");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "componentClass"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("componentIndex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "componentIndex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("componentType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "componentType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rowNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rowNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
