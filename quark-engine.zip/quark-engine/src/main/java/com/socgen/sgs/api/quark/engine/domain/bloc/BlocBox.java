package com.socgen.sgs.api.quark.engine.domain.bloc;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import lombok.Getter;

/** Represents a box bloc (single box) in a QuarkXPress document. */
@Getter
public class BlocBox extends BlocBase {

    private final String value;
    private final Box srcBox;
    private final Box srcExtraBox;

    public BlocBox(TaskBase task, String name, String value) {
        super(task, name);
        this.value = value;
        this.srcBox = null;
        this.srcExtraBox = null;
    }

    public BlocBox(TaskBase task, String name, Box srcBox, Box srcExtraBox) {
        super(task, name);
        this.value = null;
        this.srcBox = srcBox;
        this.srcExtraBox = srcExtraBox;
    }
}

