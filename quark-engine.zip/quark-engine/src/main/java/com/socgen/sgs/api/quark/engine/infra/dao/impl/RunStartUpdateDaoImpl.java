package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.infra.dao.RunStartUpdateDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;

/**
 * Implementation of RunStartUpdateDao that executes the Start_Run Oracle procedure
 */
@Repository
@Slf4j
public class RunStartUpdateDaoImpl implements RunStartUpdateDao {

    private final SimpleJdbcCall startRunCall;

    @Autowired
    public RunStartUpdateDaoImpl(DataSource dataSource) {
        // Start_Run is a PROCEDURE in QXP_PK_RUN catalog
        this.startRunCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withProcedureName("Start_Run")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_id_run", Types.NUMERIC),
                        new SqlParameter("p_run_status", Types.NUMERIC),
                        new SqlParameter("p_date_debut", Types.DATE)
                );
    }

    @Override
    public void startRun(Run run) {
        log.info("Starting run with ID: {}", run.getId());

        // Set start date to current time if not already set
        LocalDateTime startDate = run.getStartDate() != null ? run.getStartDate() : LocalDateTime.now();

        // Prepare parameters for the procedure
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_run", run.getId())
                .addValue("p_run_status", run.getStatus().getStatusCode())
                .addValue("p_date_debut", Timestamp.valueOf(startDate));

        try {
            // Execute the procedure
            startRunCall.execute(params);
            log.info("Successfully started run with ID: {}", run.getId());
        } catch (Exception e) {
            log.error("Error starting run with ID: {}", run.getId(), e);
            throw new RuntimeException("Failed to start run: " + run.getId(), e);
        }
    }
}