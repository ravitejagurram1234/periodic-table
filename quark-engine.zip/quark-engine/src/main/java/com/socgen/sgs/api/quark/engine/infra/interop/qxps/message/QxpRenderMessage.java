package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

import lombok.Getter;

/**
 * QXPS GET message for rendering the document as QXP binary (native QuarkXPress format).
 *
 * URL: {baseUrl}/qxpdoc/{documentName}
 * NOTE: path is "qxpdoc", NOT "qxp".
 *
 * Cross-reference: .NET QXPS_Message_QXP
 */
@Getter
public class QxpRenderMessage implements QxpsMessage {

    private static final String MESSAGE_PATH = "qxpdoc";

    @Override
    public String getCommandPath() {
        return MESSAGE_PATH;
    }

    @Override
    public String getCommandQuery() {
        return null;
    }

    @Override
    public byte[] getData() {
        return null;
    }

    @Override
    public boolean isPost() {
        return false;
    }
}
