/**
 * AlignVerSettings.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class AlignVerSettings  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignCallouts;

    private java.lang.String alignRelativeTo;

    private java.lang.String alignWith;

    private java.lang.String offset;

    public AlignVerSettings() {
    }

    public AlignVerSettings(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignCallouts,
           java.lang.String alignRelativeTo,
           java.lang.String alignWith,
           java.lang.String offset) {
        super(
            request);
        this.alignCallouts = alignCallouts;
        this.alignRelativeTo = alignRelativeTo;
        this.alignWith = alignWith;
        this.offset = offset;
    }


    /**
     * Gets the alignCallouts value for this AlignVerSettings.
     * 
     * @return alignCallouts
     */
    public java.lang.String getAlignCallouts() {
        return alignCallouts;
    }


    /**
     * Sets the alignCallouts value for this AlignVerSettings.
     * 
     * @param alignCallouts
     */
    public void setAlignCallouts(java.lang.String alignCallouts) {
        this.alignCallouts = alignCallouts;
    }


    /**
     * Gets the alignRelativeTo value for this AlignVerSettings.
     * 
     * @return alignRelativeTo
     */
    public java.lang.String getAlignRelativeTo() {
        return alignRelativeTo;
    }


    /**
     * Sets the alignRelativeTo value for this AlignVerSettings.
     * 
     * @param alignRelativeTo
     */
    public void setAlignRelativeTo(java.lang.String alignRelativeTo) {
        this.alignRelativeTo = alignRelativeTo;
    }


    /**
     * Gets the alignWith value for this AlignVerSettings.
     * 
     * @return alignWith
     */
    public java.lang.String getAlignWith() {
        return alignWith;
    }


    /**
     * Sets the alignWith value for this AlignVerSettings.
     * 
     * @param alignWith
     */
    public void setAlignWith(java.lang.String alignWith) {
        this.alignWith = alignWith;
    }


    /**
     * Gets the offset value for this AlignVerSettings.
     * 
     * @return offset
     */
    public java.lang.String getOffset() {
        return offset;
    }


    /**
     * Sets the offset value for this AlignVerSettings.
     * 
     * @param offset
     */
    public void setOffset(java.lang.String offset) {
        this.offset = offset;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlignVerSettings)) return false;
        AlignVerSettings other = (AlignVerSettings) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignCallouts==null && other.getAlignCallouts()==null) || 
             (this.alignCallouts!=null &&
              this.alignCallouts.equals(other.getAlignCallouts()))) &&
            ((this.alignRelativeTo==null && other.getAlignRelativeTo()==null) || 
             (this.alignRelativeTo!=null &&
              this.alignRelativeTo.equals(other.getAlignRelativeTo()))) &&
            ((this.alignWith==null && other.getAlignWith()==null) || 
             (this.alignWith!=null &&
              this.alignWith.equals(other.getAlignWith()))) &&
            ((this.offset==null && other.getOffset()==null) || 
             (this.offset!=null &&
              this.offset.equals(other.getOffset())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignCallouts() != null) {
            _hashCode += getAlignCallouts().hashCode();
        }
        if (getAlignRelativeTo() != null) {
            _hashCode += getAlignRelativeTo().hashCode();
        }
        if (getAlignWith() != null) {
            _hashCode += getAlignWith().hashCode();
        }
        if (getOffset() != null) {
            _hashCode += getOffset().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlignVerSettings.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AlignVerSettings"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignCallouts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignCallouts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignRelativeTo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignRelativeTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignWith");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignWith"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "offset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
