/**
 * RepeatableMasterPageAlternatives.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class RepeatableMasterPageAlternatives  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ConditionalMasterPageReference[] conditionalMasterPageReferences;

    private java.lang.String maxRepeats;

    public RepeatableMasterPageAlternatives() {
    }

    public RepeatableMasterPageAlternatives(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ConditionalMasterPageReference[] conditionalMasterPageReferences,
           java.lang.String maxRepeats) {
        super(
            request);
        this.conditionalMasterPageReferences = conditionalMasterPageReferences;
        this.maxRepeats = maxRepeats;
    }


    /**
     * Gets the conditionalMasterPageReferences value for this RepeatableMasterPageAlternatives.
     * 
     * @return conditionalMasterPageReferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ConditionalMasterPageReference[] getConditionalMasterPageReferences() {
        return conditionalMasterPageReferences;
    }


    /**
     * Sets the conditionalMasterPageReferences value for this RepeatableMasterPageAlternatives.
     * 
     * @param conditionalMasterPageReferences
     */
    public void setConditionalMasterPageReferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.ConditionalMasterPageReference[] conditionalMasterPageReferences) {
        this.conditionalMasterPageReferences = conditionalMasterPageReferences;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ConditionalMasterPageReference getConditionalMasterPageReferences(int i) {
        return this.conditionalMasterPageReferences[i];
    }

    public void setConditionalMasterPageReferences(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.ConditionalMasterPageReference _value) {
        this.conditionalMasterPageReferences[i] = _value;
    }


    /**
     * Gets the maxRepeats value for this RepeatableMasterPageAlternatives.
     * 
     * @return maxRepeats
     */
    public java.lang.String getMaxRepeats() {
        return maxRepeats;
    }


    /**
     * Sets the maxRepeats value for this RepeatableMasterPageAlternatives.
     * 
     * @param maxRepeats
     */
    public void setMaxRepeats(java.lang.String maxRepeats) {
        this.maxRepeats = maxRepeats;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RepeatableMasterPageAlternatives)) return false;
        RepeatableMasterPageAlternatives other = (RepeatableMasterPageAlternatives) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.conditionalMasterPageReferences==null && other.getConditionalMasterPageReferences()==null) || 
             (this.conditionalMasterPageReferences!=null &&
              java.util.Arrays.equals(this.conditionalMasterPageReferences, other.getConditionalMasterPageReferences()))) &&
            ((this.maxRepeats==null && other.getMaxRepeats()==null) || 
             (this.maxRepeats!=null &&
              this.maxRepeats.equals(other.getMaxRepeats())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getConditionalMasterPageReferences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getConditionalMasterPageReferences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getConditionalMasterPageReferences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMaxRepeats() != null) {
            _hashCode += getMaxRepeats().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RepeatableMasterPageAlternatives.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RepeatableMasterPageAlternatives"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conditionalMasterPageReferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "conditionalMasterPageReferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ConditionalMasterPageReference"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxRepeats");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "maxRepeats"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
