package com.socgen.sgs.api.quark.engine.domain.modifier;

import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import lombok.Getter;
import lombok.Setter;

/**
 * Represents a box in a modifier project hierarchy.
 *
 * Cross-reference: QXP.Engine.Core.Box (Modifier namespace)
 */
@Getter
@Setter
public class ModifierBox {

    private String uid;
    private String name;
    private String value;
    private Box srcBox;
    private int pageId;
    private BlocActionEnum action = BlocActionEnum.NONE;

    public ModifierBox() {
    }
}