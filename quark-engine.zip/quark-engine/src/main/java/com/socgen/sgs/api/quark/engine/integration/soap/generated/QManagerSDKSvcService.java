/**
 * QManagerSDKSvcService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public interface QManagerSDKSvcService extends javax.xml.rpc.Service {
    public java.lang.String getqxpsmsdkAddress();

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QManagerSDKSvc getqxpsmsdk() throws javax.xml.rpc.ServiceException;

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QManagerSDKSvc getqxpsmsdk(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
