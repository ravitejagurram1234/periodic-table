/**
 * Table.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Table  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AddCells[] addCells;

    private java.lang.String addToReflow;

    private java.lang.String anchoredGroupMember;

    private java.lang.String anchoredIn;

    private java.lang.String articleName;

    private java.lang.String autofit;

    private java.lang.String autofitMaxLimit;

    private java.lang.String blendAngle;

    private java.lang.String blendColor;

    private java.lang.String blendMode;

    private java.lang.String blendOpacity;

    private java.lang.String blendShape;

    private java.lang.String blendStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ColSpec colSpec;

    private java.lang.String color;

    private java.lang.String columnCount;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells[] deleteCells;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Grid grid;

    private int index;

    private java.lang.String maintainGeometry;

    private java.lang.String masterbox;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData;

    private java.lang.String name;

    private java.lang.String opacity;

    private java.lang.String operation;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ParentTable parentTable;

    private java.lang.String rowCount;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] rows;

    private java.lang.String shade;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TableBreak tableBreak;

    private java.lang.String tableStyleRef;

    private java.lang.String UID;

    public Table() {
    }

    public Table(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AddCells[] addCells,
           java.lang.String addToReflow,
           java.lang.String anchoredGroupMember,
           java.lang.String anchoredIn,
           java.lang.String articleName,
           java.lang.String autofit,
           java.lang.String autofitMaxLimit,
           java.lang.String blendAngle,
           java.lang.String blendColor,
           java.lang.String blendMode,
           java.lang.String blendOpacity,
           java.lang.String blendShape,
           java.lang.String blendStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ColSpec colSpec,
           java.lang.String color,
           java.lang.String columnCount,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells[] deleteCells,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Grid grid,
           int index,
           java.lang.String maintainGeometry,
           java.lang.String masterbox,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData,
           java.lang.String name,
           java.lang.String opacity,
           java.lang.String operation,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ParentTable parentTable,
           java.lang.String rowCount,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] rows,
           java.lang.String shade,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TableBreak tableBreak,
           java.lang.String tableStyleRef,
           java.lang.String UID) {
        super(
            request);
        this.addCells = addCells;
        this.addToReflow = addToReflow;
        this.anchoredGroupMember = anchoredGroupMember;
        this.anchoredIn = anchoredIn;
        this.articleName = articleName;
        this.autofit = autofit;
        this.autofitMaxLimit = autofitMaxLimit;
        this.blendAngle = blendAngle;
        this.blendColor = blendColor;
        this.blendMode = blendMode;
        this.blendOpacity = blendOpacity;
        this.blendShape = blendShape;
        this.blendStyle = blendStyle;
        this.colSpec = colSpec;
        this.color = color;
        this.columnCount = columnCount;
        this.deleteCells = deleteCells;
        this.frame = frame;
        this.geometry = geometry;
        this.grid = grid;
        this.index = index;
        this.maintainGeometry = maintainGeometry;
        this.masterbox = masterbox;
        this.metaData = metaData;
        this.name = name;
        this.opacity = opacity;
        this.operation = operation;
        this.parentTable = parentTable;
        this.rowCount = rowCount;
        this.rows = rows;
        this.shade = shade;
        this.shadow = shadow;
        this.tableBreak = tableBreak;
        this.tableStyleRef = tableStyleRef;
        this.UID = UID;
    }


    /**
     * Gets the addCells value for this Table.
     * 
     * @return addCells
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AddCells[] getAddCells() {
        return addCells;
    }


    /**
     * Sets the addCells value for this Table.
     * 
     * @param addCells
     */
    public void setAddCells(com.socgen.sgs.api.quark.engine.integration.soap.generated.AddCells[] addCells) {
        this.addCells = addCells;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AddCells getAddCells(int i) {
        return this.addCells[i];
    }

    public void setAddCells(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.AddCells _value) {
        this.addCells[i] = _value;
    }


    /**
     * Gets the addToReflow value for this Table.
     * 
     * @return addToReflow
     */
    public java.lang.String getAddToReflow() {
        return addToReflow;
    }


    /**
     * Sets the addToReflow value for this Table.
     * 
     * @param addToReflow
     */
    public void setAddToReflow(java.lang.String addToReflow) {
        this.addToReflow = addToReflow;
    }


    /**
     * Gets the anchoredGroupMember value for this Table.
     * 
     * @return anchoredGroupMember
     */
    public java.lang.String getAnchoredGroupMember() {
        return anchoredGroupMember;
    }


    /**
     * Sets the anchoredGroupMember value for this Table.
     * 
     * @param anchoredGroupMember
     */
    public void setAnchoredGroupMember(java.lang.String anchoredGroupMember) {
        this.anchoredGroupMember = anchoredGroupMember;
    }


    /**
     * Gets the anchoredIn value for this Table.
     * 
     * @return anchoredIn
     */
    public java.lang.String getAnchoredIn() {
        return anchoredIn;
    }


    /**
     * Sets the anchoredIn value for this Table.
     * 
     * @param anchoredIn
     */
    public void setAnchoredIn(java.lang.String anchoredIn) {
        this.anchoredIn = anchoredIn;
    }


    /**
     * Gets the articleName value for this Table.
     * 
     * @return articleName
     */
    public java.lang.String getArticleName() {
        return articleName;
    }


    /**
     * Sets the articleName value for this Table.
     * 
     * @param articleName
     */
    public void setArticleName(java.lang.String articleName) {
        this.articleName = articleName;
    }


    /**
     * Gets the autofit value for this Table.
     * 
     * @return autofit
     */
    public java.lang.String getAutofit() {
        return autofit;
    }


    /**
     * Sets the autofit value for this Table.
     * 
     * @param autofit
     */
    public void setAutofit(java.lang.String autofit) {
        this.autofit = autofit;
    }


    /**
     * Gets the autofitMaxLimit value for this Table.
     * 
     * @return autofitMaxLimit
     */
    public java.lang.String getAutofitMaxLimit() {
        return autofitMaxLimit;
    }


    /**
     * Sets the autofitMaxLimit value for this Table.
     * 
     * @param autofitMaxLimit
     */
    public void setAutofitMaxLimit(java.lang.String autofitMaxLimit) {
        this.autofitMaxLimit = autofitMaxLimit;
    }


    /**
     * Gets the blendAngle value for this Table.
     * 
     * @return blendAngle
     */
    public java.lang.String getBlendAngle() {
        return blendAngle;
    }


    /**
     * Sets the blendAngle value for this Table.
     * 
     * @param blendAngle
     */
    public void setBlendAngle(java.lang.String blendAngle) {
        this.blendAngle = blendAngle;
    }


    /**
     * Gets the blendColor value for this Table.
     * 
     * @return blendColor
     */
    public java.lang.String getBlendColor() {
        return blendColor;
    }


    /**
     * Sets the blendColor value for this Table.
     * 
     * @param blendColor
     */
    public void setBlendColor(java.lang.String blendColor) {
        this.blendColor = blendColor;
    }


    /**
     * Gets the blendMode value for this Table.
     * 
     * @return blendMode
     */
    public java.lang.String getBlendMode() {
        return blendMode;
    }


    /**
     * Sets the blendMode value for this Table.
     * 
     * @param blendMode
     */
    public void setBlendMode(java.lang.String blendMode) {
        this.blendMode = blendMode;
    }


    /**
     * Gets the blendOpacity value for this Table.
     * 
     * @return blendOpacity
     */
    public java.lang.String getBlendOpacity() {
        return blendOpacity;
    }


    /**
     * Sets the blendOpacity value for this Table.
     * 
     * @param blendOpacity
     */
    public void setBlendOpacity(java.lang.String blendOpacity) {
        this.blendOpacity = blendOpacity;
    }


    /**
     * Gets the blendShape value for this Table.
     * 
     * @return blendShape
     */
    public java.lang.String getBlendShape() {
        return blendShape;
    }


    /**
     * Sets the blendShape value for this Table.
     * 
     * @param blendShape
     */
    public void setBlendShape(java.lang.String blendShape) {
        this.blendShape = blendShape;
    }


    /**
     * Gets the blendStyle value for this Table.
     * 
     * @return blendStyle
     */
    public java.lang.String getBlendStyle() {
        return blendStyle;
    }


    /**
     * Sets the blendStyle value for this Table.
     * 
     * @param blendStyle
     */
    public void setBlendStyle(java.lang.String blendStyle) {
        this.blendStyle = blendStyle;
    }


    /**
     * Gets the colSpec value for this Table.
     * 
     * @return colSpec
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ColSpec getColSpec() {
        return colSpec;
    }


    /**
     * Sets the colSpec value for this Table.
     * 
     * @param colSpec
     */
    public void setColSpec(com.socgen.sgs.api.quark.engine.integration.soap.generated.ColSpec colSpec) {
        this.colSpec = colSpec;
    }


    /**
     * Gets the color value for this Table.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this Table.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the columnCount value for this Table.
     * 
     * @return columnCount
     */
    public java.lang.String getColumnCount() {
        return columnCount;
    }


    /**
     * Sets the columnCount value for this Table.
     * 
     * @param columnCount
     */
    public void setColumnCount(java.lang.String columnCount) {
        this.columnCount = columnCount;
    }


    /**
     * Gets the deleteCells value for this Table.
     * 
     * @return deleteCells
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells[] getDeleteCells() {
        return deleteCells;
    }


    /**
     * Sets the deleteCells value for this Table.
     * 
     * @param deleteCells
     */
    public void setDeleteCells(com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells[] deleteCells) {
        this.deleteCells = deleteCells;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells getDeleteCells(int i) {
        return this.deleteCells[i];
    }

    public void setDeleteCells(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells _value) {
        this.deleteCells[i] = _value;
    }


    /**
     * Gets the frame value for this Table.
     * 
     * @return frame
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame getFrame() {
        return frame;
    }


    /**
     * Sets the frame value for this Table.
     * 
     * @param frame
     */
    public void setFrame(com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame) {
        this.frame = frame;
    }


    /**
     * Gets the geometry value for this Table.
     * 
     * @return geometry
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry getGeometry() {
        return geometry;
    }


    /**
     * Sets the geometry value for this Table.
     * 
     * @param geometry
     */
    public void setGeometry(com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry) {
        this.geometry = geometry;
    }


    /**
     * Gets the grid value for this Table.
     * 
     * @return grid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Grid getGrid() {
        return grid;
    }


    /**
     * Sets the grid value for this Table.
     * 
     * @param grid
     */
    public void setGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.Grid grid) {
        this.grid = grid;
    }


    /**
     * Gets the index value for this Table.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this Table.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the maintainGeometry value for this Table.
     * 
     * @return maintainGeometry
     */
    public java.lang.String getMaintainGeometry() {
        return maintainGeometry;
    }


    /**
     * Sets the maintainGeometry value for this Table.
     * 
     * @param maintainGeometry
     */
    public void setMaintainGeometry(java.lang.String maintainGeometry) {
        this.maintainGeometry = maintainGeometry;
    }


    /**
     * Gets the masterbox value for this Table.
     * 
     * @return masterbox
     */
    public java.lang.String getMasterbox() {
        return masterbox;
    }


    /**
     * Sets the masterbox value for this Table.
     * 
     * @param masterbox
     */
    public void setMasterbox(java.lang.String masterbox) {
        this.masterbox = masterbox;
    }


    /**
     * Gets the metaData value for this Table.
     * 
     * @return metaData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData getMetaData() {
        return metaData;
    }


    /**
     * Sets the metaData value for this Table.
     * 
     * @param metaData
     */
    public void setMetaData(com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData) {
        this.metaData = metaData;
    }


    /**
     * Gets the name value for this Table.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Table.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the opacity value for this Table.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this Table.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the operation value for this Table.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this Table.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the parentTable value for this Table.
     * 
     * @return parentTable
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ParentTable getParentTable() {
        return parentTable;
    }


    /**
     * Sets the parentTable value for this Table.
     * 
     * @param parentTable
     */
    public void setParentTable(com.socgen.sgs.api.quark.engine.integration.soap.generated.ParentTable parentTable) {
        this.parentTable = parentTable;
    }


    /**
     * Gets the rowCount value for this Table.
     * 
     * @return rowCount
     */
    public java.lang.String getRowCount() {
        return rowCount;
    }


    /**
     * Sets the rowCount value for this Table.
     * 
     * @param rowCount
     */
    public void setRowCount(java.lang.String rowCount) {
        this.rowCount = rowCount;
    }


    /**
     * Gets the rows value for this Table.
     * 
     * @return rows
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] getRows() {
        return rows;
    }


    /**
     * Sets the rows value for this Table.
     * 
     * @param rows
     */
    public void setRows(com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] rows) {
        this.rows = rows;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Row getRows(int i) {
        return this.rows[i];
    }

    public void setRows(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Row _value) {
        this.rows[i] = _value;
    }


    /**
     * Gets the shade value for this Table.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this Table.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the shadow value for this Table.
     * 
     * @return shadow
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow getShadow() {
        return shadow;
    }


    /**
     * Sets the shadow value for this Table.
     * 
     * @param shadow
     */
    public void setShadow(com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow) {
        this.shadow = shadow;
    }


    /**
     * Gets the tableBreak value for this Table.
     * 
     * @return tableBreak
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TableBreak getTableBreak() {
        return tableBreak;
    }


    /**
     * Sets the tableBreak value for this Table.
     * 
     * @param tableBreak
     */
    public void setTableBreak(com.socgen.sgs.api.quark.engine.integration.soap.generated.TableBreak tableBreak) {
        this.tableBreak = tableBreak;
    }


    /**
     * Gets the tableStyleRef value for this Table.
     * 
     * @return tableStyleRef
     */
    public java.lang.String getTableStyleRef() {
        return tableStyleRef;
    }


    /**
     * Sets the tableStyleRef value for this Table.
     * 
     * @param tableStyleRef
     */
    public void setTableStyleRef(java.lang.String tableStyleRef) {
        this.tableStyleRef = tableStyleRef;
    }


    /**
     * Gets the UID value for this Table.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Table.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Table)) return false;
        Table other = (Table) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.addCells==null && other.getAddCells()==null) || 
             (this.addCells!=null &&
              java.util.Arrays.equals(this.addCells, other.getAddCells()))) &&
            ((this.addToReflow==null && other.getAddToReflow()==null) || 
             (this.addToReflow!=null &&
              this.addToReflow.equals(other.getAddToReflow()))) &&
            ((this.anchoredGroupMember==null && other.getAnchoredGroupMember()==null) || 
             (this.anchoredGroupMember!=null &&
              this.anchoredGroupMember.equals(other.getAnchoredGroupMember()))) &&
            ((this.anchoredIn==null && other.getAnchoredIn()==null) || 
             (this.anchoredIn!=null &&
              this.anchoredIn.equals(other.getAnchoredIn()))) &&
            ((this.articleName==null && other.getArticleName()==null) || 
             (this.articleName!=null &&
              this.articleName.equals(other.getArticleName()))) &&
            ((this.autofit==null && other.getAutofit()==null) || 
             (this.autofit!=null &&
              this.autofit.equals(other.getAutofit()))) &&
            ((this.autofitMaxLimit==null && other.getAutofitMaxLimit()==null) || 
             (this.autofitMaxLimit!=null &&
              this.autofitMaxLimit.equals(other.getAutofitMaxLimit()))) &&
            ((this.blendAngle==null && other.getBlendAngle()==null) || 
             (this.blendAngle!=null &&
              this.blendAngle.equals(other.getBlendAngle()))) &&
            ((this.blendColor==null && other.getBlendColor()==null) || 
             (this.blendColor!=null &&
              this.blendColor.equals(other.getBlendColor()))) &&
            ((this.blendMode==null && other.getBlendMode()==null) || 
             (this.blendMode!=null &&
              this.blendMode.equals(other.getBlendMode()))) &&
            ((this.blendOpacity==null && other.getBlendOpacity()==null) || 
             (this.blendOpacity!=null &&
              this.blendOpacity.equals(other.getBlendOpacity()))) &&
            ((this.blendShape==null && other.getBlendShape()==null) || 
             (this.blendShape!=null &&
              this.blendShape.equals(other.getBlendShape()))) &&
            ((this.blendStyle==null && other.getBlendStyle()==null) || 
             (this.blendStyle!=null &&
              this.blendStyle.equals(other.getBlendStyle()))) &&
            ((this.colSpec==null && other.getColSpec()==null) || 
             (this.colSpec!=null &&
              this.colSpec.equals(other.getColSpec()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.columnCount==null && other.getColumnCount()==null) || 
             (this.columnCount!=null &&
              this.columnCount.equals(other.getColumnCount()))) &&
            ((this.deleteCells==null && other.getDeleteCells()==null) || 
             (this.deleteCells!=null &&
              java.util.Arrays.equals(this.deleteCells, other.getDeleteCells()))) &&
            ((this.frame==null && other.getFrame()==null) || 
             (this.frame!=null &&
              this.frame.equals(other.getFrame()))) &&
            ((this.geometry==null && other.getGeometry()==null) || 
             (this.geometry!=null &&
              this.geometry.equals(other.getGeometry()))) &&
            ((this.grid==null && other.getGrid()==null) || 
             (this.grid!=null &&
              this.grid.equals(other.getGrid()))) &&
            this.index == other.getIndex() &&
            ((this.maintainGeometry==null && other.getMaintainGeometry()==null) || 
             (this.maintainGeometry!=null &&
              this.maintainGeometry.equals(other.getMaintainGeometry()))) &&
            ((this.masterbox==null && other.getMasterbox()==null) || 
             (this.masterbox!=null &&
              this.masterbox.equals(other.getMasterbox()))) &&
            ((this.metaData==null && other.getMetaData()==null) || 
             (this.metaData!=null &&
              this.metaData.equals(other.getMetaData()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.parentTable==null && other.getParentTable()==null) || 
             (this.parentTable!=null &&
              this.parentTable.equals(other.getParentTable()))) &&
            ((this.rowCount==null && other.getRowCount()==null) || 
             (this.rowCount!=null &&
              this.rowCount.equals(other.getRowCount()))) &&
            ((this.rows==null && other.getRows()==null) || 
             (this.rows!=null &&
              java.util.Arrays.equals(this.rows, other.getRows()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.shadow==null && other.getShadow()==null) || 
             (this.shadow!=null &&
              this.shadow.equals(other.getShadow()))) &&
            ((this.tableBreak==null && other.getTableBreak()==null) || 
             (this.tableBreak!=null &&
              this.tableBreak.equals(other.getTableBreak()))) &&
            ((this.tableStyleRef==null && other.getTableStyleRef()==null) || 
             (this.tableStyleRef!=null &&
              this.tableStyleRef.equals(other.getTableStyleRef()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAddCells() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAddCells());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAddCells(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAddToReflow() != null) {
            _hashCode += getAddToReflow().hashCode();
        }
        if (getAnchoredGroupMember() != null) {
            _hashCode += getAnchoredGroupMember().hashCode();
        }
        if (getAnchoredIn() != null) {
            _hashCode += getAnchoredIn().hashCode();
        }
        if (getArticleName() != null) {
            _hashCode += getArticleName().hashCode();
        }
        if (getAutofit() != null) {
            _hashCode += getAutofit().hashCode();
        }
        if (getAutofitMaxLimit() != null) {
            _hashCode += getAutofitMaxLimit().hashCode();
        }
        if (getBlendAngle() != null) {
            _hashCode += getBlendAngle().hashCode();
        }
        if (getBlendColor() != null) {
            _hashCode += getBlendColor().hashCode();
        }
        if (getBlendMode() != null) {
            _hashCode += getBlendMode().hashCode();
        }
        if (getBlendOpacity() != null) {
            _hashCode += getBlendOpacity().hashCode();
        }
        if (getBlendShape() != null) {
            _hashCode += getBlendShape().hashCode();
        }
        if (getBlendStyle() != null) {
            _hashCode += getBlendStyle().hashCode();
        }
        if (getColSpec() != null) {
            _hashCode += getColSpec().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getColumnCount() != null) {
            _hashCode += getColumnCount().hashCode();
        }
        if (getDeleteCells() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDeleteCells());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDeleteCells(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFrame() != null) {
            _hashCode += getFrame().hashCode();
        }
        if (getGeometry() != null) {
            _hashCode += getGeometry().hashCode();
        }
        if (getGrid() != null) {
            _hashCode += getGrid().hashCode();
        }
        _hashCode += getIndex();
        if (getMaintainGeometry() != null) {
            _hashCode += getMaintainGeometry().hashCode();
        }
        if (getMasterbox() != null) {
            _hashCode += getMasterbox().hashCode();
        }
        if (getMetaData() != null) {
            _hashCode += getMetaData().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getParentTable() != null) {
            _hashCode += getParentTable().hashCode();
        }
        if (getRowCount() != null) {
            _hashCode += getRowCount().hashCode();
        }
        if (getRows() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRows());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRows(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getShadow() != null) {
            _hashCode += getShadow().hashCode();
        }
        if (getTableBreak() != null) {
            _hashCode += getTableBreak().hashCode();
        }
        if (getTableStyleRef() != null) {
            _hashCode += getTableStyleRef().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Table.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Table"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addCells");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "addCells"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AddCells"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addToReflow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "addToReflow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredGroupMember");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredGroupMember"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredIn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredIn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("articleName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "articleName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("autofit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "autofit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("autofitMaxLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "autofitMaxLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendAngle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendAngle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendShape");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendShape"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("colSpec");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "colSpec"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColSpec"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deleteCells");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "deleteCells"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "DeleteCells"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frame");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "frame"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Frame"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "geometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Geometry"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "grid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Grid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maintainGeometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "maintainGeometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("masterbox");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "masterbox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metaData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "metaData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "MetaData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentTable");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "parentTable"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ParentTable"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rowCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rowCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rows");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rows"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Row"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shadow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Shadow"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tableBreak");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tableBreak"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TableBreak"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tableStyleRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tableStyleRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
