package com.socgen.sgs.api.quark.engine.domain.modifier;

import lombok.Getter;
import lombok.Setter;

/**
 * Represents a row in a table in a modifier project hierarchy.
 *
 * Cross-reference: QXP.Engine.Core.Ligne (Modifier namespace)
 */
@Getter
@Setter
public class ModifierLigne {

    private int index;

    public ModifierLigne() {
    }
}