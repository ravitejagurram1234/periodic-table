package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.infra.dao.GetTaskExceptionsDao;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Calls Oracle function QXP_PK_RUN.Get_Run_Taches_Exceptions and returns raw row maps. */
@Repository
@Slf4j
public class GetTaskExceptionsDaoImpl implements GetTaskExceptionsDao {

    private static final String RESULT_KEY = "result_cursor";
    private final SimpleJdbcCall getTaskExceptionsCall;

    @Autowired
    public GetTaskExceptionsDaoImpl(DataSource dataSource) {
        this.getTaskExceptionsCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_Run_Taches_Exceptions")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR, new ColumnMapRowMapper()),
                        new SqlParameter("p_id_run", Types.NUMERIC)
                );
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getTaskExceptions(int runId) {
        log.info("Fetching task exceptions for runId: {}", runId);
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_run", runId);

        Map<String, Object> result = getTaskExceptionsCall.execute(params);
        List<Map<String, Object>> rows = (List<Map<String, Object>>) result.get(RESULT_KEY);

        if (rows == null) {
            log.warn("No task exceptions returned for runId: {}", runId);
            return Collections.emptyList();
        }
        log.info("Fetched {} task exception rows for runId: {}", rows.size(), runId);
        return rows;
    }
}
