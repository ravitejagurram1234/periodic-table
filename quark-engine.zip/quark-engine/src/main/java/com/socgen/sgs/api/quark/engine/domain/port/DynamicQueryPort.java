package com.socgen.sgs.api.quark.engine.domain.port;

import com.socgen.sgs.api.quark.engine.domain.InParam;

import java.util.List;
import java.util.Map;

/**
 * Port interface for executing dynamic SQL queries.
 * Returns results as a list of row maps (column name → value).
 *
 * Cross-reference: .NET Proxy_Generic.GetReader() used in Process_Dynamique.Get_Report()
 */
public interface DynamicQueryPort {

    /**
     * Execute a SQL query with parameters and return results as a list of row maps.
     * Each map represents one row, keyed by column name (uppercase).
     *
     * @param sql        the SQL query to execute
     * @param parameters the query parameters
     * @return list of row maps, or empty list if no data
     */
    List<Map<String, Object>> executeQuery(String sql, Map<String, InParam> parameters);

    /**
     * Check if a column exists in the result set.
     *
     * @param columnName the column name to check
     * @param rows       the result rows
     * @return true if the column exists in at least one row
     */
    default boolean existColumn(String columnName, List<Map<String, Object>> rows) {
        if (rows == null || rows.isEmpty()) {
            return false;
        }
        return rows.get(0).containsKey(columnName);
    }
}