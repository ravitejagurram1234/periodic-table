package com.socgen.sgs.api.quark.engine.integration.soap.config;

import org.springframework.context.annotation.Configuration;

/**
 * Configuration for the Quark SOAP integration.
 * Provides beans needed to call the QManagerSDKSvc service (qxpsmsdk.wsdl).
 */
@Configuration
public class SoapConfig {
    // Bean definitions for the Axis-generated service locator and stub
    // will be added here once the generated classes are available after
    // the first 'mvn generate-sources' run.
}

