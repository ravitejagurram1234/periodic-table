package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

/**
 * Contains geometry information for a DCell.
 *
 * Cross-reference: QXP.Engine.Core.DCell_Info
 */
@Getter
@Setter
public class DCellInfo {

    /** Page number of the cell. */
    private int page;

    /** Column number of the cell. */
    private int column;

    /** Geometric zone of the cell after processing. */
    private DZone zone;

    public DCellInfo() {
    }

    /**
     * Clone this cell info to create an independent copy.
     *
     * @return a new DCellInfo with cloned zone
     */
    public DCellInfo cloneInfo() {
        DCellInfo newInfo = new DCellInfo();
        newInfo.setZone(this.zone != null ? this.zone.cloneZone() : null);
        newInfo.setPage(this.page);
        return newInfo;
    }
}