package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import com.socgen.sgs.api.quark.engine.domain.task.TaskDynamique;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Contains parameters used during the generation/preparation of a DReport.
 * Avoids passing too many parameters through successive method calls,
 * and allows parameters to be updated and retrieved by all callers.
 *
 * Cross-reference: QXP.Engine.Core.Prepare_Report_Parameters
 */
@Getter
@Setter
public class PrepareReportParameters {

    // ========================================================================
    // Global
    // ========================================================================

    /** Available height on the page (between start and end anchors). */
    private BigDecimal availableHeight = BigDecimal.ZERO;

    /** Available width on the page. */
    private BigDecimal availableWidth = BigDecimal.ZERO;

    /** Current page number (0-based initially, incremented during processing). */
    private int page = 0;

    /** Current column number (1-based). */
    private int column = 1;

    // ========================================================================
    // Table
    // ========================================================================

    /** Current table height (used when applying page break rules). */
    private BigDecimal currentTableHeight = BigDecimal.ZERO;

    /** Current table width. */
    private BigDecimal currentTableWidth = BigDecimal.ZERO;

    // ========================================================================
    // Rows
    // ========================================================================

    /** Rows to remove (page break / column break rows that are cloned instead). */
    private final List<DRow> rows2Remove = new ArrayList<>();

    // ========================================================================
    // Absolute Cells
    // ========================================================================

    /** Absolute cells to repeat on new pages. */
    private final List<DCell> repeatedCells = new ArrayList<>();

    /** Absolute cells to add on the last page only. */
    private final List<DCell> lastCells = new ArrayList<>();

    /** The associated dynamic task. */
    private final TaskDynamique task;

    // ========================================================================
    // Page Breaks
    // ========================================================================

    /** Number of rows added beyond initial count (due to page break row duplication). */
    private int nbRowsAdded = 0;

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Create parameters for a dynamic task.
     *
     * @param task the dynamic task
     */
    public PrepareReportParameters(TaskDynamique task) {
        this.task = task;
    }

    // ========================================================================
    // Methods
    // ========================================================================

    /**
     * Reset parameters to initial state for a new section.
     * Does NOT reset page or nbRowsAdded (they accumulate across sections).
     *
     * Cross-reference: .NET Prepare_Report_Parameters.Reset()
     */
    public void reset() {
        this.column = 1;
        this.rows2Remove.clear();
        this.repeatedCells.clear();
        this.lastCells.clear();
    }
}