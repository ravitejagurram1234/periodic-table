package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;
import com.socgen.sgs.api.quark.engine.enums.SubTaskTypeEnum;
import lombok.Getter;
import lombok.Setter;

/** Represents a SQL task that fills existing blocs with data. */
@Getter
@Setter
public class TaskSql extends TaskBase {

    private String sql;
    private boolean showZero = false;
    private int nbDecimal = 0;
    private boolean decimalSignificative = true;
    private DataTypeEnum dataType = DataTypeEnum.UNSPECIFIED;
    private boolean storeData = false;

    public TaskSql(int id, Run run) {
        super(id, run);
    }

    @Override
    public void prepare() {
        this.setSubTaskType(SubTaskTypeEnum.SQL);
    }
}

