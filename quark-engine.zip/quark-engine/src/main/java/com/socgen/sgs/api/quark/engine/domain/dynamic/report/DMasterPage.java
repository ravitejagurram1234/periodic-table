package com.socgen.sgs.api.quark.engine.domain.dynamic.report;
import lombok.Getter;
import lombok.Setter;
/** Represents a dynamic master page with code and identifiers. */
@Getter
@Setter
public class DMasterPage {
    private static final String DEFAULT_CODE = "4";
    private static final char SPLIT_CHAR = '|';
    public static final DMasterPage DEFAULT = new DMasterPage(DEFAULT_CODE);
    private String name = "Default";
    private String code;
    private String[] listIds;

    public DMasterPage(String code) {
        this.code = code;
        this.listIds = code != null ? code.split("\\" + SPLIT_CHAR) : new String[0];
    }

    public String getMasterPageId(int position) {
        if (position >= 0 && position < listIds.length) {
            return listIds[position];
        }
        return DEFAULT_CODE;
    }
}
