/**
 * ConstructStreamRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ConstructStreamRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String annotateErrors;

    private java.lang.String appendErrors;

    private byte[] contents;

    private java.lang.String insertErrorPageAtLast;

    private java.lang.String suppressErrors;

    public ConstructStreamRequest() {
    }

    public ConstructStreamRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String annotateErrors,
           java.lang.String appendErrors,
           byte[] contents,
           java.lang.String insertErrorPageAtLast,
           java.lang.String suppressErrors) {
        super(
            request);
        this.annotateErrors = annotateErrors;
        this.appendErrors = appendErrors;
        this.contents = contents;
        this.insertErrorPageAtLast = insertErrorPageAtLast;
        this.suppressErrors = suppressErrors;
    }


    /**
     * Gets the annotateErrors value for this ConstructStreamRequest.
     * 
     * @return annotateErrors
     */
    public java.lang.String getAnnotateErrors() {
        return annotateErrors;
    }


    /**
     * Sets the annotateErrors value for this ConstructStreamRequest.
     * 
     * @param annotateErrors
     */
    public void setAnnotateErrors(java.lang.String annotateErrors) {
        this.annotateErrors = annotateErrors;
    }


    /**
     * Gets the appendErrors value for this ConstructStreamRequest.
     * 
     * @return appendErrors
     */
    public java.lang.String getAppendErrors() {
        return appendErrors;
    }


    /**
     * Sets the appendErrors value for this ConstructStreamRequest.
     * 
     * @param appendErrors
     */
    public void setAppendErrors(java.lang.String appendErrors) {
        this.appendErrors = appendErrors;
    }


    /**
     * Gets the contents value for this ConstructStreamRequest.
     * 
     * @return contents
     */
    public byte[] getContents() {
        return contents;
    }


    /**
     * Sets the contents value for this ConstructStreamRequest.
     * 
     * @param contents
     */
    public void setContents(byte[] contents) {
        this.contents = contents;
    }


    /**
     * Gets the insertErrorPageAtLast value for this ConstructStreamRequest.
     * 
     * @return insertErrorPageAtLast
     */
    public java.lang.String getInsertErrorPageAtLast() {
        return insertErrorPageAtLast;
    }


    /**
     * Sets the insertErrorPageAtLast value for this ConstructStreamRequest.
     * 
     * @param insertErrorPageAtLast
     */
    public void setInsertErrorPageAtLast(java.lang.String insertErrorPageAtLast) {
        this.insertErrorPageAtLast = insertErrorPageAtLast;
    }


    /**
     * Gets the suppressErrors value for this ConstructStreamRequest.
     * 
     * @return suppressErrors
     */
    public java.lang.String getSuppressErrors() {
        return suppressErrors;
    }


    /**
     * Sets the suppressErrors value for this ConstructStreamRequest.
     * 
     * @param suppressErrors
     */
    public void setSuppressErrors(java.lang.String suppressErrors) {
        this.suppressErrors = suppressErrors;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConstructStreamRequest)) return false;
        ConstructStreamRequest other = (ConstructStreamRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.annotateErrors==null && other.getAnnotateErrors()==null) || 
             (this.annotateErrors!=null &&
              this.annotateErrors.equals(other.getAnnotateErrors()))) &&
            ((this.appendErrors==null && other.getAppendErrors()==null) || 
             (this.appendErrors!=null &&
              this.appendErrors.equals(other.getAppendErrors()))) &&
            ((this.contents==null && other.getContents()==null) || 
             (this.contents!=null &&
              java.util.Arrays.equals(this.contents, other.getContents()))) &&
            ((this.insertErrorPageAtLast==null && other.getInsertErrorPageAtLast()==null) || 
             (this.insertErrorPageAtLast!=null &&
              this.insertErrorPageAtLast.equals(other.getInsertErrorPageAtLast()))) &&
            ((this.suppressErrors==null && other.getSuppressErrors()==null) || 
             (this.suppressErrors!=null &&
              this.suppressErrors.equals(other.getSuppressErrors())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAnnotateErrors() != null) {
            _hashCode += getAnnotateErrors().hashCode();
        }
        if (getAppendErrors() != null) {
            _hashCode += getAppendErrors().hashCode();
        }
        if (getContents() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getContents());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getContents(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInsertErrorPageAtLast() != null) {
            _hashCode += getInsertErrorPageAtLast().hashCode();
        }
        if (getSuppressErrors() != null) {
            _hashCode += getSuppressErrors().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConstructStreamRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ConstructStreamRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("annotateErrors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "annotateErrors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appendErrors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "appendErrors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contents");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "contents"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insertErrorPageAtLast");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "insertErrorPageAtLast"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppressErrors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "suppressErrors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
