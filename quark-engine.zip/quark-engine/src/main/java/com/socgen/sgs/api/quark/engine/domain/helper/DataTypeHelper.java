package com.socgen.sgs.api.quark.engine.domain.helper;

import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Converts raw DB values to formatted strings based on DataTypeEnum configuration. */
public final class DataTypeHelper {

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter DATETIME_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    private DataTypeHelper() {
    }

    public static String outputToString(Object value, DataTypeEnum dataType, int nbDecimal,
                                        boolean showZero, String nullString, boolean decimalSignificative) {
        if (value == null) {
            return nullString;
        }

        String raw = value.toString().trim();
        if (raw.isEmpty()) {
            return nullString;
        }

        switch (dataType) {
            case INT:
                return formatInteger(raw, showZero, nullString);
            case DECIMAL:
            case CURRENCY:
            case POURCENTAGE:
                return formatDecimal(raw, nbDecimal, showZero, nullString, decimalSignificative);
            case DATE:
                return formatDate(raw, nullString);
            case DATE_TIME:
                return formatDateTime(raw, nullString);
            default:
                return raw;
        }
    }

    private static String formatInteger(String raw, boolean showZero, String nullString) {
        try {
            long val = Long.parseLong(raw);
            if (val == 0 && !showZero) return nullString;
            return String.valueOf(val);
        } catch (NumberFormatException e) {
            return raw;
        }
    }

    private static String formatDecimal(String raw, int nbDecimal, boolean showZero,
                                        String nullString, boolean decimalSignificative) {
        try {
            BigDecimal val = new BigDecimal(raw);
            if (val.compareTo(BigDecimal.ZERO) == 0 && !showZero) return nullString;

            if (decimalSignificative) {
                val = val.setScale(nbDecimal, RoundingMode.HALF_UP);
            }

            DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.FRANCE);
            StringBuilder pattern = new StringBuilder("#,##0");
            if (nbDecimal > 0) {
                pattern.append(".");
                for (int i = 0; i < nbDecimal; i++) pattern.append("0");
            }
            DecimalFormat df = new DecimalFormat(pattern.toString(), symbols);
            return df.format(val);
        } catch (NumberFormatException e) {
            return raw;
        }
    }

    private static String formatDate(String raw, String nullString) {
        try {
            LocalDate date = LocalDate.parse(raw.substring(0, 10));
            return date.format(DATE_FMT);
        } catch (Exception e) {
            return raw.isEmpty() ? nullString : raw;
        }
    }

    private static String formatDateTime(String raw, String nullString) {
        try {
            LocalDateTime dt = LocalDateTime.parse(raw.substring(0, 19));
            return dt.format(DATETIME_FMT);
        } catch (Exception e) {
            return raw.isEmpty() ? nullString : raw;
        }
    }
}

