package com.socgen.sgs.api.quark.engine.domain.helper;

import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Converts raw DB values to formatted strings based on DataTypeEnum configuration. */
public final class DataTypeHelper {

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter DATETIME_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    /**
     * fr-FR symbols (NBSP thousands grouping, ',' decimal, "€" currency). The .NET engine renders
     * under the French thread culture, matching the existing decimal formatting in this class.
     */
    private static final DecimalFormatSymbols FR_SYMBOLS = new DecimalFormatSymbols(Locale.FRANCE);

    private DataTypeHelper() {
    }

    public static String outputToString(Object value, DataTypeEnum dataType, int nbDecimal,
                                        boolean showZero, String nullString, boolean decimalSignificative) {
        if (value == null) {
            return nullString;
        }

        String raw = value.toString().trim();
        if (raw.isEmpty()) {
            return nullString;
        }

        switch (dataType) {
            case INT:
                return formatInteger(raw, showZero, nullString);
            case DECIMAL:
                return formatDecimal(raw, nbDecimal, showZero, nullString, decimalSignificative);
            case CURRENCY:
                // .NET CurrencyPattern "#,##0.{0} {1}" → number + " " + currency symbol (fr-FR → "€").
                // No ×100. Cross-reference: Data_Type_Helper.GetStringCurrency. Finding #14.
                return formatWithSuffix(raw, nbDecimal, showZero, nullString, decimalSignificative,
                        " " + FR_SYMBOLS.getCurrencySymbol());
            case POURCENTAGE:
                // Data is stored SCALED (15 == 15%), confirmed from QXP_PK_KII SQL ((montant/actif)*100
                // to produce, taux*vb/100 to consume). So append a single " %" WITHOUT multiplying by 100,
                // matching .NET's correct formatter QXP_Format_Helper (plain number + literal " %").
                // This is a deliberate, user-approved deviation from the engine's
                // Data_Type_Helper.GetStringPourcentage, which is bugged (×100 via the "%" specifier PLUS
                // a second appended " %", flagged "// TODO à voir si c'est correct") and would render 15
                // as "1 500,00 % %". Finding #14.
                return formatWithSuffix(raw, nbDecimal, showZero, nullString, decimalSignificative, " %");
            case DATE:
                return formatDate(raw, nullString);
            case DATE_TIME:
                return formatDateTime(raw, nullString);
            default:
                return raw;
        }
    }

    private static String formatInteger(String raw, boolean showZero, String nullString) {
        try {
            long val = Long.parseLong(raw);
            if (val == 0 && !showZero) return nullString;
            // Grouped output (NBSP under fr-FR), matching .NET GetStringInt which uses the "n" format
            // specifier (always groups). Finding #12.
            return new DecimalFormat("#,##0", FR_SYMBOLS).format(val);
        } catch (NumberFormatException e) {
            return raw;
        }
    }

    private static String formatDecimal(String raw, int nbDecimal, boolean showZero,
                                        String nullString, boolean decimalSignificative) {
        try {
            String formatted = formatDecimalCore(raw, nbDecimal, showZero, decimalSignificative);
            return formatted == null ? nullString : formatted;
        } catch (NumberFormatException e) {
            return raw;
        }
    }

    /** DECIMAL formatting with a trailing suffix (currency symbol or " %"); suffix is omitted when the
     *  value is treated as null (zero with showZero=false) or unparseable. */
    private static String formatWithSuffix(String raw, int nbDecimal, boolean showZero,
                                           String nullString, boolean decimalSignificative, String suffix) {
        try {
            String formatted = formatDecimalCore(raw, nbDecimal, showZero, decimalSignificative);
            return formatted == null ? nullString : formatted + suffix;
        } catch (NumberFormatException e) {
            return raw;
        }
    }

    /**
     * Core decimal formatter shared by DECIMAL / CURRENCY / POURCENTAGE.
     * Returns the formatted number, or {@code null} to signal "use nullString" (zero with showZero=false).
     * Throws {@link NumberFormatException} on unparseable input so callers can fall back to the raw value.
     *
     * <p>decimalSignificative drives the fraction digits, matching .NET GetDecimalPattern:
     * true → fixed nbDecimal decimals with trailing zeros ('0' pattern); false → suppress trailing
     * zeros up to nbDecimal ('#' pattern). Finding #13. Rounding is HALF_UP (round half away from
     * zero), matching .NET Decimal.ToString, instead of DecimalFormat's default HALF_EVEN.
     */
    private static String formatDecimalCore(String raw, int nbDecimal, boolean showZero,
                                            boolean decimalSignificative) {
        BigDecimal val = new BigDecimal(raw);
        if (val.compareTo(BigDecimal.ZERO) == 0 && !showZero) {
            return null;
        }
        DecimalFormat df = new DecimalFormat("#,##0", FR_SYMBOLS);
        df.setMaximumFractionDigits(nbDecimal);
        df.setMinimumFractionDigits(decimalSignificative ? nbDecimal : 0);
        df.setRoundingMode(RoundingMode.HALF_UP);
        return df.format(val);
    }

    private static String formatDate(String raw, String nullString) {
        try {
            LocalDate date = LocalDate.parse(raw.substring(0, 10));
            return date.format(DATE_FMT);
        } catch (Exception e) {
            return raw.isEmpty() ? nullString : raw;
        }
    }

    private static String formatDateTime(String raw, String nullString) {
        try {
            LocalDateTime dt = LocalDateTime.parse(raw.substring(0, 19));
            return dt.format(DATETIME_FMT);
        } catch (Exception e) {
            return raw.isEmpty() ? nullString : raw;
        }
    }
}