/**
 * Clipping.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Clipping  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String bottom;

    private java.lang.String edited;

    private java.lang.String invert;

    private java.lang.String left;

    private java.lang.String noise;

    private java.lang.String outset;

    private java.lang.String outsideOnly;

    private java.lang.String pathName;

    private java.lang.String restrictToBox;

    private java.lang.String right;

    private java.lang.String smoothness;

    private java.lang.String threshhold;

    private java.lang.String top;

    private java.lang.String type;

    public Clipping() {
    }

    public Clipping(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String bottom,
           java.lang.String edited,
           java.lang.String invert,
           java.lang.String left,
           java.lang.String noise,
           java.lang.String outset,
           java.lang.String outsideOnly,
           java.lang.String pathName,
           java.lang.String restrictToBox,
           java.lang.String right,
           java.lang.String smoothness,
           java.lang.String threshhold,
           java.lang.String top,
           java.lang.String type) {
        super(
            request);
        this.bottom = bottom;
        this.edited = edited;
        this.invert = invert;
        this.left = left;
        this.noise = noise;
        this.outset = outset;
        this.outsideOnly = outsideOnly;
        this.pathName = pathName;
        this.restrictToBox = restrictToBox;
        this.right = right;
        this.smoothness = smoothness;
        this.threshhold = threshhold;
        this.top = top;
        this.type = type;
    }


    /**
     * Gets the bottom value for this Clipping.
     * 
     * @return bottom
     */
    public java.lang.String getBottom() {
        return bottom;
    }


    /**
     * Sets the bottom value for this Clipping.
     * 
     * @param bottom
     */
    public void setBottom(java.lang.String bottom) {
        this.bottom = bottom;
    }


    /**
     * Gets the edited value for this Clipping.
     * 
     * @return edited
     */
    public java.lang.String getEdited() {
        return edited;
    }


    /**
     * Sets the edited value for this Clipping.
     * 
     * @param edited
     */
    public void setEdited(java.lang.String edited) {
        this.edited = edited;
    }


    /**
     * Gets the invert value for this Clipping.
     * 
     * @return invert
     */
    public java.lang.String getInvert() {
        return invert;
    }


    /**
     * Sets the invert value for this Clipping.
     * 
     * @param invert
     */
    public void setInvert(java.lang.String invert) {
        this.invert = invert;
    }


    /**
     * Gets the left value for this Clipping.
     * 
     * @return left
     */
    public java.lang.String getLeft() {
        return left;
    }


    /**
     * Sets the left value for this Clipping.
     * 
     * @param left
     */
    public void setLeft(java.lang.String left) {
        this.left = left;
    }


    /**
     * Gets the noise value for this Clipping.
     * 
     * @return noise
     */
    public java.lang.String getNoise() {
        return noise;
    }


    /**
     * Sets the noise value for this Clipping.
     * 
     * @param noise
     */
    public void setNoise(java.lang.String noise) {
        this.noise = noise;
    }


    /**
     * Gets the outset value for this Clipping.
     * 
     * @return outset
     */
    public java.lang.String getOutset() {
        return outset;
    }


    /**
     * Sets the outset value for this Clipping.
     * 
     * @param outset
     */
    public void setOutset(java.lang.String outset) {
        this.outset = outset;
    }


    /**
     * Gets the outsideOnly value for this Clipping.
     * 
     * @return outsideOnly
     */
    public java.lang.String getOutsideOnly() {
        return outsideOnly;
    }


    /**
     * Sets the outsideOnly value for this Clipping.
     * 
     * @param outsideOnly
     */
    public void setOutsideOnly(java.lang.String outsideOnly) {
        this.outsideOnly = outsideOnly;
    }


    /**
     * Gets the pathName value for this Clipping.
     * 
     * @return pathName
     */
    public java.lang.String getPathName() {
        return pathName;
    }


    /**
     * Sets the pathName value for this Clipping.
     * 
     * @param pathName
     */
    public void setPathName(java.lang.String pathName) {
        this.pathName = pathName;
    }


    /**
     * Gets the restrictToBox value for this Clipping.
     * 
     * @return restrictToBox
     */
    public java.lang.String getRestrictToBox() {
        return restrictToBox;
    }


    /**
     * Sets the restrictToBox value for this Clipping.
     * 
     * @param restrictToBox
     */
    public void setRestrictToBox(java.lang.String restrictToBox) {
        this.restrictToBox = restrictToBox;
    }


    /**
     * Gets the right value for this Clipping.
     * 
     * @return right
     */
    public java.lang.String getRight() {
        return right;
    }


    /**
     * Sets the right value for this Clipping.
     * 
     * @param right
     */
    public void setRight(java.lang.String right) {
        this.right = right;
    }


    /**
     * Gets the smoothness value for this Clipping.
     * 
     * @return smoothness
     */
    public java.lang.String getSmoothness() {
        return smoothness;
    }


    /**
     * Sets the smoothness value for this Clipping.
     * 
     * @param smoothness
     */
    public void setSmoothness(java.lang.String smoothness) {
        this.smoothness = smoothness;
    }


    /**
     * Gets the threshhold value for this Clipping.
     * 
     * @return threshhold
     */
    public java.lang.String getThreshhold() {
        return threshhold;
    }


    /**
     * Sets the threshhold value for this Clipping.
     * 
     * @param threshhold
     */
    public void setThreshhold(java.lang.String threshhold) {
        this.threshhold = threshhold;
    }


    /**
     * Gets the top value for this Clipping.
     * 
     * @return top
     */
    public java.lang.String getTop() {
        return top;
    }


    /**
     * Sets the top value for this Clipping.
     * 
     * @param top
     */
    public void setTop(java.lang.String top) {
        this.top = top;
    }


    /**
     * Gets the type value for this Clipping.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this Clipping.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Clipping)) return false;
        Clipping other = (Clipping) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.bottom==null && other.getBottom()==null) || 
             (this.bottom!=null &&
              this.bottom.equals(other.getBottom()))) &&
            ((this.edited==null && other.getEdited()==null) || 
             (this.edited!=null &&
              this.edited.equals(other.getEdited()))) &&
            ((this.invert==null && other.getInvert()==null) || 
             (this.invert!=null &&
              this.invert.equals(other.getInvert()))) &&
            ((this.left==null && other.getLeft()==null) || 
             (this.left!=null &&
              this.left.equals(other.getLeft()))) &&
            ((this.noise==null && other.getNoise()==null) || 
             (this.noise!=null &&
              this.noise.equals(other.getNoise()))) &&
            ((this.outset==null && other.getOutset()==null) || 
             (this.outset!=null &&
              this.outset.equals(other.getOutset()))) &&
            ((this.outsideOnly==null && other.getOutsideOnly()==null) || 
             (this.outsideOnly!=null &&
              this.outsideOnly.equals(other.getOutsideOnly()))) &&
            ((this.pathName==null && other.getPathName()==null) || 
             (this.pathName!=null &&
              this.pathName.equals(other.getPathName()))) &&
            ((this.restrictToBox==null && other.getRestrictToBox()==null) || 
             (this.restrictToBox!=null &&
              this.restrictToBox.equals(other.getRestrictToBox()))) &&
            ((this.right==null && other.getRight()==null) || 
             (this.right!=null &&
              this.right.equals(other.getRight()))) &&
            ((this.smoothness==null && other.getSmoothness()==null) || 
             (this.smoothness!=null &&
              this.smoothness.equals(other.getSmoothness()))) &&
            ((this.threshhold==null && other.getThreshhold()==null) || 
             (this.threshhold!=null &&
              this.threshhold.equals(other.getThreshhold()))) &&
            ((this.top==null && other.getTop()==null) || 
             (this.top!=null &&
              this.top.equals(other.getTop()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBottom() != null) {
            _hashCode += getBottom().hashCode();
        }
        if (getEdited() != null) {
            _hashCode += getEdited().hashCode();
        }
        if (getInvert() != null) {
            _hashCode += getInvert().hashCode();
        }
        if (getLeft() != null) {
            _hashCode += getLeft().hashCode();
        }
        if (getNoise() != null) {
            _hashCode += getNoise().hashCode();
        }
        if (getOutset() != null) {
            _hashCode += getOutset().hashCode();
        }
        if (getOutsideOnly() != null) {
            _hashCode += getOutsideOnly().hashCode();
        }
        if (getPathName() != null) {
            _hashCode += getPathName().hashCode();
        }
        if (getRestrictToBox() != null) {
            _hashCode += getRestrictToBox().hashCode();
        }
        if (getRight() != null) {
            _hashCode += getRight().hashCode();
        }
        if (getSmoothness() != null) {
            _hashCode += getSmoothness().hashCode();
        }
        if (getThreshhold() != null) {
            _hashCode += getThreshhold().hashCode();
        }
        if (getTop() != null) {
            _hashCode += getTop().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Clipping.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Clipping"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bottom");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bottom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("edited");
        elemField.setXmlName(new javax.xml.namespace.QName("", "edited"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invert");
        elemField.setXmlName(new javax.xml.namespace.QName("", "invert"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("left");
        elemField.setXmlName(new javax.xml.namespace.QName("", "left"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noise");
        elemField.setXmlName(new javax.xml.namespace.QName("", "noise"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outset");
        elemField.setXmlName(new javax.xml.namespace.QName("", "outset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outsideOnly");
        elemField.setXmlName(new javax.xml.namespace.QName("", "outsideOnly"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pathName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pathName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("restrictToBox");
        elemField.setXmlName(new javax.xml.namespace.QName("", "restrictToBox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("right");
        elemField.setXmlName(new javax.xml.namespace.QName("", "right"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("smoothness");
        elemField.setXmlName(new javax.xml.namespace.QName("", "smoothness"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("threshhold");
        elemField.setXmlName(new javax.xml.namespace.QName("", "threshhold"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("top");
        elemField.setXmlName(new javax.xml.namespace.QName("", "top"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
