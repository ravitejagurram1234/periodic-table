package com.socgen.sgs.api.quark.engine.domain.element;

import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Group;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Represents a template group element (multiple boxes) for dynamic tasks.
 * Wraps a SOAP-generated {@link Group} and contains child TBox elements.
 *
 * <p>Never work directly on a TGroup without cloning it first,
 * as modifications would affect all tasks sharing the same template.
 *
 * Cross-reference: QXP.Engine.Core.TGroup
 */
@Getter
@Setter
@Slf4j
public class TGroup extends TElement {

    private static final String UNKNOWN_PAGE = "?";

    /** Source SOAP group. */
    private Group srcGroup;

    /** Source boxes extracted from the group (populated after evaluation). */
    private Box[] srcBoxes;

    /** Child TBox elements contained in this group. */
    private List<TBox> tBoxes = new ArrayList<>();

    /** Page containing this element ("?" if not evaluated). */
    private String page = UNKNOWN_PAGE;

    /**
     * No-arg constructor for serialization/deserialization.
     */
    public TGroup() {
        super();
    }

    /**
     * Create a TGroup from a SOAP Group.
     *
     * @param group the SOAP-generated Group
     */
    public TGroup(Group group) {
        super(group.getName());
        this.srcGroup = group;
    }

    /**
     * Evaluate geometry by computing the bounding box of all child elements.
     * Iterates through boxRefs, resolves them from the QXP project elements,
     * and computes min/max bounds.
     *
     * @param qxpProject the QXP project — must be cast to
     *                   {@link com.socgen.sgs.api.quark.engine.domain.project.QxpProject}
     *                   to access the elements map. Using Object here to avoid circular dependency
     *                   during initial class creation.
     */
    @Override
    @SuppressWarnings("unchecked")
    public void evaluate(Object qxpProject) {
        if (isEvaluated()) {
            return;
        }

        // qxpProject is passed as Object to avoid circular dependency.
        // At runtime, it provides a getElements() method returning Map<String, TElement>.
        Map<String, TElement> elements;
        try {
            elements = (Map<String, TElement>) qxpProject.getClass()
                    .getMethod("getElements")
                    .invoke(qxpProject);
        } catch (Exception e) {
            log.error("Failed to get elements from QxpProject during TGroup evaluation", e);
            setEvaluated(true);
            return;
        }

        evaluateBoxes(elements);

        // Compute bounding box from all child TBoxes
        if (tBoxes.isEmpty()) {
            setLeft(BigDecimal.ZERO);
            setTop(BigDecimal.ZERO);
            setWidth(BigDecimal.ZERO);
            setHeight(BigDecimal.ZERO);
        } else {
            BigDecimal leftMin = new BigDecimal(Long.MAX_VALUE);
            BigDecimal topMin = new BigDecimal(Long.MAX_VALUE);
            BigDecimal rightMax = new BigDecimal(Long.MIN_VALUE);
            BigDecimal bottomMax = new BigDecimal(Long.MIN_VALUE);

            for (TBox tBox : tBoxes) {
                if (tBox.getLeft().compareTo(leftMin) < 0) leftMin = tBox.getLeft();
                if (tBox.getTop().compareTo(topMin) < 0) topMin = tBox.getTop();
                if (tBox.getRight().compareTo(rightMax) > 0) rightMax = tBox.getRight();
                if (tBox.getBottom().compareTo(bottomMax) > 0) bottomMax = tBox.getBottom();
            }

            setLeft(leftMin);
            setTop(topMin);
            setWidth(rightMax.subtract(leftMin));
            setHeight(bottomMax.subtract(topMin));
        }

        setEvaluated(true);
    }

    /**
     * Evaluate child boxes by resolving boxRefs from the elements map.
     * Each boxRef name is looked up in the project elements dictionary.
     *
     * @param elements the project elements map (name → TElement)
     */
    private void evaluateBoxes(Map<String, TElement> elements) {
        boolean subGroup = false;
        List<Box> resolvedBoxes = new ArrayList<>();

        if (srcGroup == null || srcGroup.getBoxRefs() == null) {
            this.srcBoxes = new Box[0];
            return;
        }

        for (BoxRef boxRef : srcGroup.getBoxRefs()) {
            if (boxRef == null || boxRef.getName() == null) {
                continue;
            }

            String refName = boxRef.getName();

            if (!elements.containsKey(refName)) {
                log.error("TGroup [{}] references unknown sub-element [{}]", getName(), refName);
                continue;
            }

            TElement refElement = elements.get(refName);

            if (refElement instanceof TBox) {
                TBox tBox = (TBox) refElement;
                tBoxes.add(tBox);
                tBox.evaluate(null); // TBox.evaluate doesn't use qxpProject
                resolvedBoxes.add(tBox.getSrcBox());

                if (UNKNOWN_PAGE.equals(page) && !UNKNOWN_PAGE.equals(tBox.getPage())) {
                    this.page = tBox.getPage();
                }
            } else if (refElement instanceof TGroup) {
                // Sub-groups: evaluate but flag as problematic
                // .NET logs warning: "TGroupSubGroupProblem"
                subGroup = true;
                TGroup subGrp = (TGroup) refElement;
                subGrp.evaluate(buildQxpProjectProxy(elements));

                if (UNKNOWN_PAGE.equals(page) && !UNKNOWN_PAGE.equals(subGrp.getPage())) {
                    this.page = subGrp.getPage();
                }
            }
        }

        this.srcBoxes = resolvedBoxes.toArray(new Box[0]);

        if (subGroup) {
            log.warn("TGroup [{}] on page [{}] contains sub-groups — this may cause issues",
                    getName(), page);
        }
    }

    /**
     * Build a minimal proxy object that TGroup.evaluate() can use to access elements.
     * This avoids circular dependency with QxpProject.
     */
    private Object buildQxpProjectProxy(Map<String, TElement> elements) {
        return new Object() {
            @SuppressWarnings("unused")
            public Map<String, TElement> getElements() {
                return elements;
            }
        };
    }
}