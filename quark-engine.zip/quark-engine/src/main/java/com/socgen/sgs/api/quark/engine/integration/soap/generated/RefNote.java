/**
 * RefNote.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class RefNote  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBody refNoteBody;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBodyMarker refNoteBodyMarker;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ReferencedTextMarker referencedTextMarker;

    private java.lang.String restartNumberingValue;

    private java.lang.String style;

    private java.lang.String xrefLabel;

    public RefNote() {
    }

    public RefNote(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBody refNoteBody,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBodyMarker refNoteBodyMarker,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ReferencedTextMarker referencedTextMarker,
           java.lang.String restartNumberingValue,
           java.lang.String style,
           java.lang.String xrefLabel) {
        super(
            request);
        this.index = index;
        this.refNoteBody = refNoteBody;
        this.refNoteBodyMarker = refNoteBodyMarker;
        this.referencedTextMarker = referencedTextMarker;
        this.restartNumberingValue = restartNumberingValue;
        this.style = style;
        this.xrefLabel = xrefLabel;
    }


    /**
     * Gets the index value for this RefNote.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this RefNote.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the refNoteBody value for this RefNote.
     * 
     * @return refNoteBody
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBody getRefNoteBody() {
        return refNoteBody;
    }


    /**
     * Sets the refNoteBody value for this RefNote.
     * 
     * @param refNoteBody
     */
    public void setRefNoteBody(com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBody refNoteBody) {
        this.refNoteBody = refNoteBody;
    }


    /**
     * Gets the refNoteBodyMarker value for this RefNote.
     * 
     * @return refNoteBodyMarker
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBodyMarker getRefNoteBodyMarker() {
        return refNoteBodyMarker;
    }


    /**
     * Sets the refNoteBodyMarker value for this RefNote.
     * 
     * @param refNoteBodyMarker
     */
    public void setRefNoteBodyMarker(com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBodyMarker refNoteBodyMarker) {
        this.refNoteBodyMarker = refNoteBodyMarker;
    }


    /**
     * Gets the referencedTextMarker value for this RefNote.
     * 
     * @return referencedTextMarker
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ReferencedTextMarker getReferencedTextMarker() {
        return referencedTextMarker;
    }


    /**
     * Sets the referencedTextMarker value for this RefNote.
     * 
     * @param referencedTextMarker
     */
    public void setReferencedTextMarker(com.socgen.sgs.api.quark.engine.integration.soap.generated.ReferencedTextMarker referencedTextMarker) {
        this.referencedTextMarker = referencedTextMarker;
    }


    /**
     * Gets the restartNumberingValue value for this RefNote.
     * 
     * @return restartNumberingValue
     */
    public java.lang.String getRestartNumberingValue() {
        return restartNumberingValue;
    }


    /**
     * Sets the restartNumberingValue value for this RefNote.
     * 
     * @param restartNumberingValue
     */
    public void setRestartNumberingValue(java.lang.String restartNumberingValue) {
        this.restartNumberingValue = restartNumberingValue;
    }


    /**
     * Gets the style value for this RefNote.
     * 
     * @return style
     */
    public java.lang.String getStyle() {
        return style;
    }


    /**
     * Sets the style value for this RefNote.
     * 
     * @param style
     */
    public void setStyle(java.lang.String style) {
        this.style = style;
    }


    /**
     * Gets the xrefLabel value for this RefNote.
     * 
     * @return xrefLabel
     */
    public java.lang.String getXrefLabel() {
        return xrefLabel;
    }


    /**
     * Sets the xrefLabel value for this RefNote.
     * 
     * @param xrefLabel
     */
    public void setXrefLabel(java.lang.String xrefLabel) {
        this.xrefLabel = xrefLabel;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RefNote)) return false;
        RefNote other = (RefNote) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.index == other.getIndex() &&
            ((this.refNoteBody==null && other.getRefNoteBody()==null) || 
             (this.refNoteBody!=null &&
              this.refNoteBody.equals(other.getRefNoteBody()))) &&
            ((this.refNoteBodyMarker==null && other.getRefNoteBodyMarker()==null) || 
             (this.refNoteBodyMarker!=null &&
              this.refNoteBodyMarker.equals(other.getRefNoteBodyMarker()))) &&
            ((this.referencedTextMarker==null && other.getReferencedTextMarker()==null) || 
             (this.referencedTextMarker!=null &&
              this.referencedTextMarker.equals(other.getReferencedTextMarker()))) &&
            ((this.restartNumberingValue==null && other.getRestartNumberingValue()==null) || 
             (this.restartNumberingValue!=null &&
              this.restartNumberingValue.equals(other.getRestartNumberingValue()))) &&
            ((this.style==null && other.getStyle()==null) || 
             (this.style!=null &&
              this.style.equals(other.getStyle()))) &&
            ((this.xrefLabel==null && other.getXrefLabel()==null) || 
             (this.xrefLabel!=null &&
              this.xrefLabel.equals(other.getXrefLabel())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += getIndex();
        if (getRefNoteBody() != null) {
            _hashCode += getRefNoteBody().hashCode();
        }
        if (getRefNoteBodyMarker() != null) {
            _hashCode += getRefNoteBodyMarker().hashCode();
        }
        if (getReferencedTextMarker() != null) {
            _hashCode += getReferencedTextMarker().hashCode();
        }
        if (getRestartNumberingValue() != null) {
            _hashCode += getRestartNumberingValue().hashCode();
        }
        if (getStyle() != null) {
            _hashCode += getStyle().hashCode();
        }
        if (getXrefLabel() != null) {
            _hashCode += getXrefLabel().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RefNote.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RefNote"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refNoteBody");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "refNoteBody"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RefNoteBody"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refNoteBodyMarker");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "refNoteBodyMarker"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RefNoteBodyMarker"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referencedTextMarker");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "referencedTextMarker"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ReferencedTextMarker"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("restartNumberingValue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "restartNumberingValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("style");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "style"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xrefLabel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "xrefLabel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
