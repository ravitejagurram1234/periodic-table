/**
 * Stop.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Stop  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String angle;

    private java.lang.String aspectRatio;

    private java.lang.String overPrint;

    private java.lang.String shade;

    private java.lang.String type;

    public Stop() {
    }

    public Stop(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String angle,
           java.lang.String aspectRatio,
           java.lang.String overPrint,
           java.lang.String shade,
           java.lang.String type) {
        super(
            request);
        this.angle = angle;
        this.aspectRatio = aspectRatio;
        this.overPrint = overPrint;
        this.shade = shade;
        this.type = type;
    }


    /**
     * Gets the angle value for this Stop.
     * 
     * @return angle
     */
    public java.lang.String getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this Stop.
     * 
     * @param angle
     */
    public void setAngle(java.lang.String angle) {
        this.angle = angle;
    }


    /**
     * Gets the aspectRatio value for this Stop.
     * 
     * @return aspectRatio
     */
    public java.lang.String getAspectRatio() {
        return aspectRatio;
    }


    /**
     * Sets the aspectRatio value for this Stop.
     * 
     * @param aspectRatio
     */
    public void setAspectRatio(java.lang.String aspectRatio) {
        this.aspectRatio = aspectRatio;
    }


    /**
     * Gets the overPrint value for this Stop.
     * 
     * @return overPrint
     */
    public java.lang.String getOverPrint() {
        return overPrint;
    }


    /**
     * Sets the overPrint value for this Stop.
     * 
     * @param overPrint
     */
    public void setOverPrint(java.lang.String overPrint) {
        this.overPrint = overPrint;
    }


    /**
     * Gets the shade value for this Stop.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this Stop.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the type value for this Stop.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this Stop.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Stop)) return false;
        Stop other = (Stop) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.angle==null && other.getAngle()==null) || 
             (this.angle!=null &&
              this.angle.equals(other.getAngle()))) &&
            ((this.aspectRatio==null && other.getAspectRatio()==null) || 
             (this.aspectRatio!=null &&
              this.aspectRatio.equals(other.getAspectRatio()))) &&
            ((this.overPrint==null && other.getOverPrint()==null) || 
             (this.overPrint!=null &&
              this.overPrint.equals(other.getOverPrint()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAngle() != null) {
            _hashCode += getAngle().hashCode();
        }
        if (getAspectRatio() != null) {
            _hashCode += getAspectRatio().hashCode();
        }
        if (getOverPrint() != null) {
            _hashCode += getOverPrint().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Stop.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Stop"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("angle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "angle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aspectRatio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "aspectRatio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overPrint");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "overPrint"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
