/**
 * IndexStyle.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class IndexStyle  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LevelStyle levelStyle;

    private java.lang.String name;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Separators separators;

    public IndexStyle() {
    }

    public IndexStyle(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LevelStyle levelStyle,
           java.lang.String name,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Separators separators) {
        super(
            request);
        this.levelStyle = levelStyle;
        this.name = name;
        this.separators = separators;
    }


    /**
     * Gets the levelStyle value for this IndexStyle.
     * 
     * @return levelStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LevelStyle getLevelStyle() {
        return levelStyle;
    }


    /**
     * Sets the levelStyle value for this IndexStyle.
     * 
     * @param levelStyle
     */
    public void setLevelStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.LevelStyle levelStyle) {
        this.levelStyle = levelStyle;
    }


    /**
     * Gets the name value for this IndexStyle.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this IndexStyle.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the separators value for this IndexStyle.
     * 
     * @return separators
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Separators getSeparators() {
        return separators;
    }


    /**
     * Sets the separators value for this IndexStyle.
     * 
     * @param separators
     */
    public void setSeparators(com.socgen.sgs.api.quark.engine.integration.soap.generated.Separators separators) {
        this.separators = separators;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IndexStyle)) return false;
        IndexStyle other = (IndexStyle) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.levelStyle==null && other.getLevelStyle()==null) || 
             (this.levelStyle!=null &&
              this.levelStyle.equals(other.getLevelStyle()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.separators==null && other.getSeparators()==null) || 
             (this.separators!=null &&
              this.separators.equals(other.getSeparators())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLevelStyle() != null) {
            _hashCode += getLevelStyle().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getSeparators() != null) {
            _hashCode += getSeparators().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IndexStyle.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexStyle"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("levelStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "levelStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LevelStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("separators");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "separators"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Separators"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
