package com.socgen.sgs.api.quark.engine.infra.dao;
import com.socgen.sgs.api.quark.engine.domain.Run;
public interface GetInParamsDao {
    /** Fetches all input parameters for the given run and populates run.inParams. */
    void getInParams(Run run);
}
