package com.socgen.sgs.api.quark.engine.domain.bloc;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import lombok.Getter;

/** Represents a group bloc (multiple boxes) in a QuarkXPress document. */
@Getter
public class BlocGroup extends BlocBase {

    private final Box[] srcBoxes;

    public BlocGroup(TaskBase task, String name, Box[] srcBoxes) {
        super(task, name);
        this.srcBoxes = srcBoxes;
    }

    @Override
    public int getNbBox() {
        return (srcBoxes != null) ? srcBoxes.length : 0;
    }
}

