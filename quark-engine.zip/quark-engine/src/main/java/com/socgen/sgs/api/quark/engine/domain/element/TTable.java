package com.socgen.sgs.api.quark.engine.domain.element;

import com.socgen.sgs.api.quark.engine.integration.soap.generated.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * Represents a template table element available for dynamic tasks.
 * Wraps a SOAP-generated {@link Table}.
 *
 * <p>Note: Table template evaluation is not yet implemented in .NET either
 * ("Non traité pour le moment — il n'est pas possible de définir des template de type Table").
 * This class exists for structural completeness and future use.
 *
 * Cross-reference: QXP.Engine.Core.TTable
 */
@Getter
@Setter
public class TTable extends TElement {

    /** Source SOAP table. */
    private Table srcTable;

    /**
     * No-arg constructor for serialization/deserialization.
     */
    public TTable() {
        super();
    }

    /**
     * Create a TTable from a SOAP Table.
     *
     * @param table the SOAP-generated Table
     */
    public TTable(Table table) {
        super(table.getName());
        this.srcTable = table;
    }

    /**
     * Evaluate geometry from the QXP project.
     * Not yet implemented (matches .NET behavior).
     *
     * @param qxpProject the QXP project
     */
    @Override
    public void evaluate(Object qxpProject) {
        // Not implemented — matches .NET:
        // "Non traité pour le moment il n'est pas possible de définir des template de type Table"
        // Will be implemented when table templates are supported in gabarit templates.
    }
}