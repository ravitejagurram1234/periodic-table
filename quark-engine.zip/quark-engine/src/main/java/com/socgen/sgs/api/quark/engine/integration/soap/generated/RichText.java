/**
 * RichText.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class RichText  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String allCaps;

    private java.lang.String applySendingToNonCJK;

    private java.lang.String backgroundColor;

    private java.lang.String backgroundColorBottomPadding;

    private java.lang.String backgroundColorLeftPadding;

    private java.lang.String backgroundColorOpacity;

    private java.lang.String backgroundColorRightPadding;

    private java.lang.String backgroundColorShade;

    private java.lang.String backgroundColorTopPadding;

    private java.lang.String baselineShift;

    private java.lang.String bold;

    private java.lang.String borderBottomPadding;

    private java.lang.String borderColor;

    private java.lang.String borderLeftPadding;

    private java.lang.String borderOpacity;

    private java.lang.String borderRightPadding;

    private java.lang.String borderShade;

    private java.lang.String borderStyle;

    private java.lang.String borderTopPadding;

    private java.lang.String borderWidth;

    private java.lang.String bottomBorder;

    private java.lang.String charStyle;

    private java.lang.String color;

    private java.lang.String doubleStrikeThru;

    private java.lang.String emphasisMark;

    private java.lang.String fauxStyle;

    private java.lang.String font;

    private java.lang.String fontset;

    private java.lang.String fontsetSize;

    private java.lang.String HLAnchorRef;

    private java.lang.String HLType;

    private java.lang.String halfWidthUpright;

    private java.lang.String horizontalScale;

    private java.lang.String hyperlinkRef;

    private int index;

    private java.lang.String italic;

    private java.lang.String kernAmount;

    private java.lang.String language;

    private java.lang.String leftBorder;

    private java.lang.String ligatures;

    private java.lang.String merge;

    private java.lang.String missingFont;

    private java.lang.String nonBreaking;

    private java.lang.String OTAllSmallCaps;

    private java.lang.String OTAltVerticalMetrics;

    private java.lang.String OTAlternateFormsNone;

    private java.lang.String OTAlternateHalfMetrics;

    private java.lang.String OTAlternateWidthsNone;

    private java.lang.String OTContextualAlternatives;

    private java.lang.String OTDenominator;

    private java.lang.String OTDiscretionaryLigatures;

    private java.lang.String OTFeature;

    private java.lang.String OTFractions;

    private java.lang.String OTFullWidths;

    private java.lang.String OTHVKanaAlternatives;

    private java.lang.String OTHalfWidths;

    private java.lang.String OTItalicsFeature;

    private java.lang.String OTJIS04Forms;

    private java.lang.String OTJIS78Forms;

    private java.lang.String OTJIS83Forms;

    private java.lang.String OTJIS90Forms;

    private java.lang.String OTLiningFigures;

    private java.lang.String OTLocalizedForms;

    private java.lang.String OTNumerator;

    private java.lang.String OTOldStyleFigures;

    private java.lang.String OTOrdinals;

    private java.lang.String OTPositionNone;

    private java.lang.String OTProportionalAltVerticalMetrics;

    private java.lang.String OTProportionalFigures;

    private java.lang.String OTProportionalWidths;

    private java.lang.String OTQuarterWidths;

    private java.lang.String OTRubiNotationForms;

    private java.lang.String OTScientificInferiorFeature;

    private java.lang.String OTSimplifiedForms;

    private java.lang.String OTSmallCaps;

    private java.lang.String OTStandardLigatures;

    private java.lang.String OTSubscript;

    private java.lang.String OTSuperscript;

    private java.lang.String OTSwashes;

    private java.lang.String OTTabularFigures;

    private java.lang.String OTThirdWidths;

    private java.lang.String OTTitlingAlternates;

    private java.lang.String OTTraditionalForms;

    private java.lang.String OTVariant;

    private java.lang.String opacity;

    private java.lang.String outline;

    private java.lang.String PSFontName;

    private java.lang.String pageNumberChar;

    private java.lang.String plain;

    private java.lang.String rightBorder;

    private java.lang.String script;

    private java.lang.String sending;

    private java.lang.String shade;

    private java.lang.String shadingStyleName;

    private java.lang.String shadow;

    private java.lang.String size;

    private java.lang.String smallCaps;

    private java.lang.String strikeThru;

    private java.lang.String subScript;

    private java.lang.String superScript;

    private java.lang.String superior;

    private java.lang.String topBorder;

    private java.lang.String trackAmount;

    private java.lang.String underline;

    private java.lang.String unencodedGlyphId;

    private java.lang.String value;

    private java.lang.String verticalScale;

    private java.lang.String wordUnderline;

    private java.lang.String xrefLabel;

    public RichText() {
    }

    public RichText(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String allCaps,
           java.lang.String applySendingToNonCJK,
           java.lang.String backgroundColor,
           java.lang.String backgroundColorBottomPadding,
           java.lang.String backgroundColorLeftPadding,
           java.lang.String backgroundColorOpacity,
           java.lang.String backgroundColorRightPadding,
           java.lang.String backgroundColorShade,
           java.lang.String backgroundColorTopPadding,
           java.lang.String baselineShift,
           java.lang.String bold,
           java.lang.String borderBottomPadding,
           java.lang.String borderColor,
           java.lang.String borderLeftPadding,
           java.lang.String borderOpacity,
           java.lang.String borderRightPadding,
           java.lang.String borderShade,
           java.lang.String borderStyle,
           java.lang.String borderTopPadding,
           java.lang.String borderWidth,
           java.lang.String bottomBorder,
           java.lang.String charStyle,
           java.lang.String color,
           java.lang.String doubleStrikeThru,
           java.lang.String emphasisMark,
           java.lang.String fauxStyle,
           java.lang.String font,
           java.lang.String fontset,
           java.lang.String fontsetSize,
           java.lang.String HLAnchorRef,
           java.lang.String HLType,
           java.lang.String halfWidthUpright,
           java.lang.String horizontalScale,
           java.lang.String hyperlinkRef,
           int index,
           java.lang.String italic,
           java.lang.String kernAmount,
           java.lang.String language,
           java.lang.String leftBorder,
           java.lang.String ligatures,
           java.lang.String merge,
           java.lang.String missingFont,
           java.lang.String nonBreaking,
           java.lang.String OTAllSmallCaps,
           java.lang.String OTAltVerticalMetrics,
           java.lang.String OTAlternateFormsNone,
           java.lang.String OTAlternateHalfMetrics,
           java.lang.String OTAlternateWidthsNone,
           java.lang.String OTContextualAlternatives,
           java.lang.String OTDenominator,
           java.lang.String OTDiscretionaryLigatures,
           java.lang.String OTFeature,
           java.lang.String OTFractions,
           java.lang.String OTFullWidths,
           java.lang.String OTHVKanaAlternatives,
           java.lang.String OTHalfWidths,
           java.lang.String OTItalicsFeature,
           java.lang.String OTJIS04Forms,
           java.lang.String OTJIS78Forms,
           java.lang.String OTJIS83Forms,
           java.lang.String OTJIS90Forms,
           java.lang.String OTLiningFigures,
           java.lang.String OTLocalizedForms,
           java.lang.String OTNumerator,
           java.lang.String OTOldStyleFigures,
           java.lang.String OTOrdinals,
           java.lang.String OTPositionNone,
           java.lang.String OTProportionalAltVerticalMetrics,
           java.lang.String OTProportionalFigures,
           java.lang.String OTProportionalWidths,
           java.lang.String OTQuarterWidths,
           java.lang.String OTRubiNotationForms,
           java.lang.String OTScientificInferiorFeature,
           java.lang.String OTSimplifiedForms,
           java.lang.String OTSmallCaps,
           java.lang.String OTStandardLigatures,
           java.lang.String OTSubscript,
           java.lang.String OTSuperscript,
           java.lang.String OTSwashes,
           java.lang.String OTTabularFigures,
           java.lang.String OTThirdWidths,
           java.lang.String OTTitlingAlternates,
           java.lang.String OTTraditionalForms,
           java.lang.String OTVariant,
           java.lang.String opacity,
           java.lang.String outline,
           java.lang.String PSFontName,
           java.lang.String pageNumberChar,
           java.lang.String plain,
           java.lang.String rightBorder,
           java.lang.String script,
           java.lang.String sending,
           java.lang.String shade,
           java.lang.String shadingStyleName,
           java.lang.String shadow,
           java.lang.String size,
           java.lang.String smallCaps,
           java.lang.String strikeThru,
           java.lang.String subScript,
           java.lang.String superScript,
           java.lang.String superior,
           java.lang.String topBorder,
           java.lang.String trackAmount,
           java.lang.String underline,
           java.lang.String unencodedGlyphId,
           java.lang.String value,
           java.lang.String verticalScale,
           java.lang.String wordUnderline,
           java.lang.String xrefLabel) {
        super(
            request);
        this.allCaps = allCaps;
        this.applySendingToNonCJK = applySendingToNonCJK;
        this.backgroundColor = backgroundColor;
        this.backgroundColorBottomPadding = backgroundColorBottomPadding;
        this.backgroundColorLeftPadding = backgroundColorLeftPadding;
        this.backgroundColorOpacity = backgroundColorOpacity;
        this.backgroundColorRightPadding = backgroundColorRightPadding;
        this.backgroundColorShade = backgroundColorShade;
        this.backgroundColorTopPadding = backgroundColorTopPadding;
        this.baselineShift = baselineShift;
        this.bold = bold;
        this.borderBottomPadding = borderBottomPadding;
        this.borderColor = borderColor;
        this.borderLeftPadding = borderLeftPadding;
        this.borderOpacity = borderOpacity;
        this.borderRightPadding = borderRightPadding;
        this.borderShade = borderShade;
        this.borderStyle = borderStyle;
        this.borderTopPadding = borderTopPadding;
        this.borderWidth = borderWidth;
        this.bottomBorder = bottomBorder;
        this.charStyle = charStyle;
        this.color = color;
        this.doubleStrikeThru = doubleStrikeThru;
        this.emphasisMark = emphasisMark;
        this.fauxStyle = fauxStyle;
        this.font = font;
        this.fontset = fontset;
        this.fontsetSize = fontsetSize;
        this.HLAnchorRef = HLAnchorRef;
        this.HLType = HLType;
        this.halfWidthUpright = halfWidthUpright;
        this.horizontalScale = horizontalScale;
        this.hyperlinkRef = hyperlinkRef;
        this.index = index;
        this.italic = italic;
        this.kernAmount = kernAmount;
        this.language = language;
        this.leftBorder = leftBorder;
        this.ligatures = ligatures;
        this.merge = merge;
        this.missingFont = missingFont;
        this.nonBreaking = nonBreaking;
        this.OTAllSmallCaps = OTAllSmallCaps;
        this.OTAltVerticalMetrics = OTAltVerticalMetrics;
        this.OTAlternateFormsNone = OTAlternateFormsNone;
        this.OTAlternateHalfMetrics = OTAlternateHalfMetrics;
        this.OTAlternateWidthsNone = OTAlternateWidthsNone;
        this.OTContextualAlternatives = OTContextualAlternatives;
        this.OTDenominator = OTDenominator;
        this.OTDiscretionaryLigatures = OTDiscretionaryLigatures;
        this.OTFeature = OTFeature;
        this.OTFractions = OTFractions;
        this.OTFullWidths = OTFullWidths;
        this.OTHVKanaAlternatives = OTHVKanaAlternatives;
        this.OTHalfWidths = OTHalfWidths;
        this.OTItalicsFeature = OTItalicsFeature;
        this.OTJIS04Forms = OTJIS04Forms;
        this.OTJIS78Forms = OTJIS78Forms;
        this.OTJIS83Forms = OTJIS83Forms;
        this.OTJIS90Forms = OTJIS90Forms;
        this.OTLiningFigures = OTLiningFigures;
        this.OTLocalizedForms = OTLocalizedForms;
        this.OTNumerator = OTNumerator;
        this.OTOldStyleFigures = OTOldStyleFigures;
        this.OTOrdinals = OTOrdinals;
        this.OTPositionNone = OTPositionNone;
        this.OTProportionalAltVerticalMetrics = OTProportionalAltVerticalMetrics;
        this.OTProportionalFigures = OTProportionalFigures;
        this.OTProportionalWidths = OTProportionalWidths;
        this.OTQuarterWidths = OTQuarterWidths;
        this.OTRubiNotationForms = OTRubiNotationForms;
        this.OTScientificInferiorFeature = OTScientificInferiorFeature;
        this.OTSimplifiedForms = OTSimplifiedForms;
        this.OTSmallCaps = OTSmallCaps;
        this.OTStandardLigatures = OTStandardLigatures;
        this.OTSubscript = OTSubscript;
        this.OTSuperscript = OTSuperscript;
        this.OTSwashes = OTSwashes;
        this.OTTabularFigures = OTTabularFigures;
        this.OTThirdWidths = OTThirdWidths;
        this.OTTitlingAlternates = OTTitlingAlternates;
        this.OTTraditionalForms = OTTraditionalForms;
        this.OTVariant = OTVariant;
        this.opacity = opacity;
        this.outline = outline;
        this.PSFontName = PSFontName;
        this.pageNumberChar = pageNumberChar;
        this.plain = plain;
        this.rightBorder = rightBorder;
        this.script = script;
        this.sending = sending;
        this.shade = shade;
        this.shadingStyleName = shadingStyleName;
        this.shadow = shadow;
        this.size = size;
        this.smallCaps = smallCaps;
        this.strikeThru = strikeThru;
        this.subScript = subScript;
        this.superScript = superScript;
        this.superior = superior;
        this.topBorder = topBorder;
        this.trackAmount = trackAmount;
        this.underline = underline;
        this.unencodedGlyphId = unencodedGlyphId;
        this.value = value;
        this.verticalScale = verticalScale;
        this.wordUnderline = wordUnderline;
        this.xrefLabel = xrefLabel;
    }


    /**
     * Gets the allCaps value for this RichText.
     * 
     * @return allCaps
     */
    public java.lang.String getAllCaps() {
        return allCaps;
    }


    /**
     * Sets the allCaps value for this RichText.
     * 
     * @param allCaps
     */
    public void setAllCaps(java.lang.String allCaps) {
        this.allCaps = allCaps;
    }


    /**
     * Gets the applySendingToNonCJK value for this RichText.
     * 
     * @return applySendingToNonCJK
     */
    public java.lang.String getApplySendingToNonCJK() {
        return applySendingToNonCJK;
    }


    /**
     * Sets the applySendingToNonCJK value for this RichText.
     * 
     * @param applySendingToNonCJK
     */
    public void setApplySendingToNonCJK(java.lang.String applySendingToNonCJK) {
        this.applySendingToNonCJK = applySendingToNonCJK;
    }


    /**
     * Gets the backgroundColor value for this RichText.
     * 
     * @return backgroundColor
     */
    public java.lang.String getBackgroundColor() {
        return backgroundColor;
    }


    /**
     * Sets the backgroundColor value for this RichText.
     * 
     * @param backgroundColor
     */
    public void setBackgroundColor(java.lang.String backgroundColor) {
        this.backgroundColor = backgroundColor;
    }


    /**
     * Gets the backgroundColorBottomPadding value for this RichText.
     * 
     * @return backgroundColorBottomPadding
     */
    public java.lang.String getBackgroundColorBottomPadding() {
        return backgroundColorBottomPadding;
    }


    /**
     * Sets the backgroundColorBottomPadding value for this RichText.
     * 
     * @param backgroundColorBottomPadding
     */
    public void setBackgroundColorBottomPadding(java.lang.String backgroundColorBottomPadding) {
        this.backgroundColorBottomPadding = backgroundColorBottomPadding;
    }


    /**
     * Gets the backgroundColorLeftPadding value for this RichText.
     * 
     * @return backgroundColorLeftPadding
     */
    public java.lang.String getBackgroundColorLeftPadding() {
        return backgroundColorLeftPadding;
    }


    /**
     * Sets the backgroundColorLeftPadding value for this RichText.
     * 
     * @param backgroundColorLeftPadding
     */
    public void setBackgroundColorLeftPadding(java.lang.String backgroundColorLeftPadding) {
        this.backgroundColorLeftPadding = backgroundColorLeftPadding;
    }


    /**
     * Gets the backgroundColorOpacity value for this RichText.
     * 
     * @return backgroundColorOpacity
     */
    public java.lang.String getBackgroundColorOpacity() {
        return backgroundColorOpacity;
    }


    /**
     * Sets the backgroundColorOpacity value for this RichText.
     * 
     * @param backgroundColorOpacity
     */
    public void setBackgroundColorOpacity(java.lang.String backgroundColorOpacity) {
        this.backgroundColorOpacity = backgroundColorOpacity;
    }


    /**
     * Gets the backgroundColorRightPadding value for this RichText.
     * 
     * @return backgroundColorRightPadding
     */
    public java.lang.String getBackgroundColorRightPadding() {
        return backgroundColorRightPadding;
    }


    /**
     * Sets the backgroundColorRightPadding value for this RichText.
     * 
     * @param backgroundColorRightPadding
     */
    public void setBackgroundColorRightPadding(java.lang.String backgroundColorRightPadding) {
        this.backgroundColorRightPadding = backgroundColorRightPadding;
    }


    /**
     * Gets the backgroundColorShade value for this RichText.
     * 
     * @return backgroundColorShade
     */
    public java.lang.String getBackgroundColorShade() {
        return backgroundColorShade;
    }


    /**
     * Sets the backgroundColorShade value for this RichText.
     * 
     * @param backgroundColorShade
     */
    public void setBackgroundColorShade(java.lang.String backgroundColorShade) {
        this.backgroundColorShade = backgroundColorShade;
    }


    /**
     * Gets the backgroundColorTopPadding value for this RichText.
     * 
     * @return backgroundColorTopPadding
     */
    public java.lang.String getBackgroundColorTopPadding() {
        return backgroundColorTopPadding;
    }


    /**
     * Sets the backgroundColorTopPadding value for this RichText.
     * 
     * @param backgroundColorTopPadding
     */
    public void setBackgroundColorTopPadding(java.lang.String backgroundColorTopPadding) {
        this.backgroundColorTopPadding = backgroundColorTopPadding;
    }


    /**
     * Gets the baselineShift value for this RichText.
     * 
     * @return baselineShift
     */
    public java.lang.String getBaselineShift() {
        return baselineShift;
    }


    /**
     * Sets the baselineShift value for this RichText.
     * 
     * @param baselineShift
     */
    public void setBaselineShift(java.lang.String baselineShift) {
        this.baselineShift = baselineShift;
    }


    /**
     * Gets the bold value for this RichText.
     * 
     * @return bold
     */
    public java.lang.String getBold() {
        return bold;
    }


    /**
     * Sets the bold value for this RichText.
     * 
     * @param bold
     */
    public void setBold(java.lang.String bold) {
        this.bold = bold;
    }


    /**
     * Gets the borderBottomPadding value for this RichText.
     * 
     * @return borderBottomPadding
     */
    public java.lang.String getBorderBottomPadding() {
        return borderBottomPadding;
    }


    /**
     * Sets the borderBottomPadding value for this RichText.
     * 
     * @param borderBottomPadding
     */
    public void setBorderBottomPadding(java.lang.String borderBottomPadding) {
        this.borderBottomPadding = borderBottomPadding;
    }


    /**
     * Gets the borderColor value for this RichText.
     * 
     * @return borderColor
     */
    public java.lang.String getBorderColor() {
        return borderColor;
    }


    /**
     * Sets the borderColor value for this RichText.
     * 
     * @param borderColor
     */
    public void setBorderColor(java.lang.String borderColor) {
        this.borderColor = borderColor;
    }


    /**
     * Gets the borderLeftPadding value for this RichText.
     * 
     * @return borderLeftPadding
     */
    public java.lang.String getBorderLeftPadding() {
        return borderLeftPadding;
    }


    /**
     * Sets the borderLeftPadding value for this RichText.
     * 
     * @param borderLeftPadding
     */
    public void setBorderLeftPadding(java.lang.String borderLeftPadding) {
        this.borderLeftPadding = borderLeftPadding;
    }


    /**
     * Gets the borderOpacity value for this RichText.
     * 
     * @return borderOpacity
     */
    public java.lang.String getBorderOpacity() {
        return borderOpacity;
    }


    /**
     * Sets the borderOpacity value for this RichText.
     * 
     * @param borderOpacity
     */
    public void setBorderOpacity(java.lang.String borderOpacity) {
        this.borderOpacity = borderOpacity;
    }


    /**
     * Gets the borderRightPadding value for this RichText.
     * 
     * @return borderRightPadding
     */
    public java.lang.String getBorderRightPadding() {
        return borderRightPadding;
    }


    /**
     * Sets the borderRightPadding value for this RichText.
     * 
     * @param borderRightPadding
     */
    public void setBorderRightPadding(java.lang.String borderRightPadding) {
        this.borderRightPadding = borderRightPadding;
    }


    /**
     * Gets the borderShade value for this RichText.
     * 
     * @return borderShade
     */
    public java.lang.String getBorderShade() {
        return borderShade;
    }


    /**
     * Sets the borderShade value for this RichText.
     * 
     * @param borderShade
     */
    public void setBorderShade(java.lang.String borderShade) {
        this.borderShade = borderShade;
    }


    /**
     * Gets the borderStyle value for this RichText.
     * 
     * @return borderStyle
     */
    public java.lang.String getBorderStyle() {
        return borderStyle;
    }


    /**
     * Sets the borderStyle value for this RichText.
     * 
     * @param borderStyle
     */
    public void setBorderStyle(java.lang.String borderStyle) {
        this.borderStyle = borderStyle;
    }


    /**
     * Gets the borderTopPadding value for this RichText.
     * 
     * @return borderTopPadding
     */
    public java.lang.String getBorderTopPadding() {
        return borderTopPadding;
    }


    /**
     * Sets the borderTopPadding value for this RichText.
     * 
     * @param borderTopPadding
     */
    public void setBorderTopPadding(java.lang.String borderTopPadding) {
        this.borderTopPadding = borderTopPadding;
    }


    /**
     * Gets the borderWidth value for this RichText.
     * 
     * @return borderWidth
     */
    public java.lang.String getBorderWidth() {
        return borderWidth;
    }


    /**
     * Sets the borderWidth value for this RichText.
     * 
     * @param borderWidth
     */
    public void setBorderWidth(java.lang.String borderWidth) {
        this.borderWidth = borderWidth;
    }


    /**
     * Gets the bottomBorder value for this RichText.
     * 
     * @return bottomBorder
     */
    public java.lang.String getBottomBorder() {
        return bottomBorder;
    }


    /**
     * Sets the bottomBorder value for this RichText.
     * 
     * @param bottomBorder
     */
    public void setBottomBorder(java.lang.String bottomBorder) {
        this.bottomBorder = bottomBorder;
    }


    /**
     * Gets the charStyle value for this RichText.
     * 
     * @return charStyle
     */
    public java.lang.String getCharStyle() {
        return charStyle;
    }


    /**
     * Sets the charStyle value for this RichText.
     * 
     * @param charStyle
     */
    public void setCharStyle(java.lang.String charStyle) {
        this.charStyle = charStyle;
    }


    /**
     * Gets the color value for this RichText.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this RichText.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the doubleStrikeThru value for this RichText.
     * 
     * @return doubleStrikeThru
     */
    public java.lang.String getDoubleStrikeThru() {
        return doubleStrikeThru;
    }


    /**
     * Sets the doubleStrikeThru value for this RichText.
     * 
     * @param doubleStrikeThru
     */
    public void setDoubleStrikeThru(java.lang.String doubleStrikeThru) {
        this.doubleStrikeThru = doubleStrikeThru;
    }


    /**
     * Gets the emphasisMark value for this RichText.
     * 
     * @return emphasisMark
     */
    public java.lang.String getEmphasisMark() {
        return emphasisMark;
    }


    /**
     * Sets the emphasisMark value for this RichText.
     * 
     * @param emphasisMark
     */
    public void setEmphasisMark(java.lang.String emphasisMark) {
        this.emphasisMark = emphasisMark;
    }


    /**
     * Gets the fauxStyle value for this RichText.
     * 
     * @return fauxStyle
     */
    public java.lang.String getFauxStyle() {
        return fauxStyle;
    }


    /**
     * Sets the fauxStyle value for this RichText.
     * 
     * @param fauxStyle
     */
    public void setFauxStyle(java.lang.String fauxStyle) {
        this.fauxStyle = fauxStyle;
    }


    /**
     * Gets the font value for this RichText.
     * 
     * @return font
     */
    public java.lang.String getFont() {
        return font;
    }


    /**
     * Sets the font value for this RichText.
     * 
     * @param font
     */
    public void setFont(java.lang.String font) {
        this.font = font;
    }


    /**
     * Gets the fontset value for this RichText.
     * 
     * @return fontset
     */
    public java.lang.String getFontset() {
        return fontset;
    }


    /**
     * Sets the fontset value for this RichText.
     * 
     * @param fontset
     */
    public void setFontset(java.lang.String fontset) {
        this.fontset = fontset;
    }


    /**
     * Gets the fontsetSize value for this RichText.
     * 
     * @return fontsetSize
     */
    public java.lang.String getFontsetSize() {
        return fontsetSize;
    }


    /**
     * Sets the fontsetSize value for this RichText.
     * 
     * @param fontsetSize
     */
    public void setFontsetSize(java.lang.String fontsetSize) {
        this.fontsetSize = fontsetSize;
    }


    /**
     * Gets the HLAnchorRef value for this RichText.
     * 
     * @return HLAnchorRef
     */
    public java.lang.String getHLAnchorRef() {
        return HLAnchorRef;
    }


    /**
     * Sets the HLAnchorRef value for this RichText.
     * 
     * @param HLAnchorRef
     */
    public void setHLAnchorRef(java.lang.String HLAnchorRef) {
        this.HLAnchorRef = HLAnchorRef;
    }


    /**
     * Gets the HLType value for this RichText.
     * 
     * @return HLType
     */
    public java.lang.String getHLType() {
        return HLType;
    }


    /**
     * Sets the HLType value for this RichText.
     * 
     * @param HLType
     */
    public void setHLType(java.lang.String HLType) {
        this.HLType = HLType;
    }


    /**
     * Gets the halfWidthUpright value for this RichText.
     * 
     * @return halfWidthUpright
     */
    public java.lang.String getHalfWidthUpright() {
        return halfWidthUpright;
    }


    /**
     * Sets the halfWidthUpright value for this RichText.
     * 
     * @param halfWidthUpright
     */
    public void setHalfWidthUpright(java.lang.String halfWidthUpright) {
        this.halfWidthUpright = halfWidthUpright;
    }


    /**
     * Gets the horizontalScale value for this RichText.
     * 
     * @return horizontalScale
     */
    public java.lang.String getHorizontalScale() {
        return horizontalScale;
    }


    /**
     * Sets the horizontalScale value for this RichText.
     * 
     * @param horizontalScale
     */
    public void setHorizontalScale(java.lang.String horizontalScale) {
        this.horizontalScale = horizontalScale;
    }


    /**
     * Gets the hyperlinkRef value for this RichText.
     * 
     * @return hyperlinkRef
     */
    public java.lang.String getHyperlinkRef() {
        return hyperlinkRef;
    }


    /**
     * Sets the hyperlinkRef value for this RichText.
     * 
     * @param hyperlinkRef
     */
    public void setHyperlinkRef(java.lang.String hyperlinkRef) {
        this.hyperlinkRef = hyperlinkRef;
    }


    /**
     * Gets the index value for this RichText.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this RichText.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the italic value for this RichText.
     * 
     * @return italic
     */
    public java.lang.String getItalic() {
        return italic;
    }


    /**
     * Sets the italic value for this RichText.
     * 
     * @param italic
     */
    public void setItalic(java.lang.String italic) {
        this.italic = italic;
    }


    /**
     * Gets the kernAmount value for this RichText.
     * 
     * @return kernAmount
     */
    public java.lang.String getKernAmount() {
        return kernAmount;
    }


    /**
     * Sets the kernAmount value for this RichText.
     * 
     * @param kernAmount
     */
    public void setKernAmount(java.lang.String kernAmount) {
        this.kernAmount = kernAmount;
    }


    /**
     * Gets the language value for this RichText.
     * 
     * @return language
     */
    public java.lang.String getLanguage() {
        return language;
    }


    /**
     * Sets the language value for this RichText.
     * 
     * @param language
     */
    public void setLanguage(java.lang.String language) {
        this.language = language;
    }


    /**
     * Gets the leftBorder value for this RichText.
     * 
     * @return leftBorder
     */
    public java.lang.String getLeftBorder() {
        return leftBorder;
    }


    /**
     * Sets the leftBorder value for this RichText.
     * 
     * @param leftBorder
     */
    public void setLeftBorder(java.lang.String leftBorder) {
        this.leftBorder = leftBorder;
    }


    /**
     * Gets the ligatures value for this RichText.
     * 
     * @return ligatures
     */
    public java.lang.String getLigatures() {
        return ligatures;
    }


    /**
     * Sets the ligatures value for this RichText.
     * 
     * @param ligatures
     */
    public void setLigatures(java.lang.String ligatures) {
        this.ligatures = ligatures;
    }


    /**
     * Gets the merge value for this RichText.
     * 
     * @return merge
     */
    public java.lang.String getMerge() {
        return merge;
    }


    /**
     * Sets the merge value for this RichText.
     * 
     * @param merge
     */
    public void setMerge(java.lang.String merge) {
        this.merge = merge;
    }


    /**
     * Gets the missingFont value for this RichText.
     * 
     * @return missingFont
     */
    public java.lang.String getMissingFont() {
        return missingFont;
    }


    /**
     * Sets the missingFont value for this RichText.
     * 
     * @param missingFont
     */
    public void setMissingFont(java.lang.String missingFont) {
        this.missingFont = missingFont;
    }


    /**
     * Gets the nonBreaking value for this RichText.
     * 
     * @return nonBreaking
     */
    public java.lang.String getNonBreaking() {
        return nonBreaking;
    }


    /**
     * Sets the nonBreaking value for this RichText.
     * 
     * @param nonBreaking
     */
    public void setNonBreaking(java.lang.String nonBreaking) {
        this.nonBreaking = nonBreaking;
    }


    /**
     * Gets the OTAllSmallCaps value for this RichText.
     * 
     * @return OTAllSmallCaps
     */
    public java.lang.String getOTAllSmallCaps() {
        return OTAllSmallCaps;
    }


    /**
     * Sets the OTAllSmallCaps value for this RichText.
     * 
     * @param OTAllSmallCaps
     */
    public void setOTAllSmallCaps(java.lang.String OTAllSmallCaps) {
        this.OTAllSmallCaps = OTAllSmallCaps;
    }


    /**
     * Gets the OTAltVerticalMetrics value for this RichText.
     * 
     * @return OTAltVerticalMetrics
     */
    public java.lang.String getOTAltVerticalMetrics() {
        return OTAltVerticalMetrics;
    }


    /**
     * Sets the OTAltVerticalMetrics value for this RichText.
     * 
     * @param OTAltVerticalMetrics
     */
    public void setOTAltVerticalMetrics(java.lang.String OTAltVerticalMetrics) {
        this.OTAltVerticalMetrics = OTAltVerticalMetrics;
    }


    /**
     * Gets the OTAlternateFormsNone value for this RichText.
     * 
     * @return OTAlternateFormsNone
     */
    public java.lang.String getOTAlternateFormsNone() {
        return OTAlternateFormsNone;
    }


    /**
     * Sets the OTAlternateFormsNone value for this RichText.
     * 
     * @param OTAlternateFormsNone
     */
    public void setOTAlternateFormsNone(java.lang.String OTAlternateFormsNone) {
        this.OTAlternateFormsNone = OTAlternateFormsNone;
    }


    /**
     * Gets the OTAlternateHalfMetrics value for this RichText.
     * 
     * @return OTAlternateHalfMetrics
     */
    public java.lang.String getOTAlternateHalfMetrics() {
        return OTAlternateHalfMetrics;
    }


    /**
     * Sets the OTAlternateHalfMetrics value for this RichText.
     * 
     * @param OTAlternateHalfMetrics
     */
    public void setOTAlternateHalfMetrics(java.lang.String OTAlternateHalfMetrics) {
        this.OTAlternateHalfMetrics = OTAlternateHalfMetrics;
    }


    /**
     * Gets the OTAlternateWidthsNone value for this RichText.
     * 
     * @return OTAlternateWidthsNone
     */
    public java.lang.String getOTAlternateWidthsNone() {
        return OTAlternateWidthsNone;
    }


    /**
     * Sets the OTAlternateWidthsNone value for this RichText.
     * 
     * @param OTAlternateWidthsNone
     */
    public void setOTAlternateWidthsNone(java.lang.String OTAlternateWidthsNone) {
        this.OTAlternateWidthsNone = OTAlternateWidthsNone;
    }


    /**
     * Gets the OTContextualAlternatives value for this RichText.
     * 
     * @return OTContextualAlternatives
     */
    public java.lang.String getOTContextualAlternatives() {
        return OTContextualAlternatives;
    }


    /**
     * Sets the OTContextualAlternatives value for this RichText.
     * 
     * @param OTContextualAlternatives
     */
    public void setOTContextualAlternatives(java.lang.String OTContextualAlternatives) {
        this.OTContextualAlternatives = OTContextualAlternatives;
    }


    /**
     * Gets the OTDenominator value for this RichText.
     * 
     * @return OTDenominator
     */
    public java.lang.String getOTDenominator() {
        return OTDenominator;
    }


    /**
     * Sets the OTDenominator value for this RichText.
     * 
     * @param OTDenominator
     */
    public void setOTDenominator(java.lang.String OTDenominator) {
        this.OTDenominator = OTDenominator;
    }


    /**
     * Gets the OTDiscretionaryLigatures value for this RichText.
     * 
     * @return OTDiscretionaryLigatures
     */
    public java.lang.String getOTDiscretionaryLigatures() {
        return OTDiscretionaryLigatures;
    }


    /**
     * Sets the OTDiscretionaryLigatures value for this RichText.
     * 
     * @param OTDiscretionaryLigatures
     */
    public void setOTDiscretionaryLigatures(java.lang.String OTDiscretionaryLigatures) {
        this.OTDiscretionaryLigatures = OTDiscretionaryLigatures;
    }


    /**
     * Gets the OTFeature value for this RichText.
     * 
     * @return OTFeature
     */
    public java.lang.String getOTFeature() {
        return OTFeature;
    }


    /**
     * Sets the OTFeature value for this RichText.
     * 
     * @param OTFeature
     */
    public void setOTFeature(java.lang.String OTFeature) {
        this.OTFeature = OTFeature;
    }


    /**
     * Gets the OTFractions value for this RichText.
     * 
     * @return OTFractions
     */
    public java.lang.String getOTFractions() {
        return OTFractions;
    }


    /**
     * Sets the OTFractions value for this RichText.
     * 
     * @param OTFractions
     */
    public void setOTFractions(java.lang.String OTFractions) {
        this.OTFractions = OTFractions;
    }


    /**
     * Gets the OTFullWidths value for this RichText.
     * 
     * @return OTFullWidths
     */
    public java.lang.String getOTFullWidths() {
        return OTFullWidths;
    }


    /**
     * Sets the OTFullWidths value for this RichText.
     * 
     * @param OTFullWidths
     */
    public void setOTFullWidths(java.lang.String OTFullWidths) {
        this.OTFullWidths = OTFullWidths;
    }


    /**
     * Gets the OTHVKanaAlternatives value for this RichText.
     * 
     * @return OTHVKanaAlternatives
     */
    public java.lang.String getOTHVKanaAlternatives() {
        return OTHVKanaAlternatives;
    }


    /**
     * Sets the OTHVKanaAlternatives value for this RichText.
     * 
     * @param OTHVKanaAlternatives
     */
    public void setOTHVKanaAlternatives(java.lang.String OTHVKanaAlternatives) {
        this.OTHVKanaAlternatives = OTHVKanaAlternatives;
    }


    /**
     * Gets the OTHalfWidths value for this RichText.
     * 
     * @return OTHalfWidths
     */
    public java.lang.String getOTHalfWidths() {
        return OTHalfWidths;
    }


    /**
     * Sets the OTHalfWidths value for this RichText.
     * 
     * @param OTHalfWidths
     */
    public void setOTHalfWidths(java.lang.String OTHalfWidths) {
        this.OTHalfWidths = OTHalfWidths;
    }


    /**
     * Gets the OTItalicsFeature value for this RichText.
     * 
     * @return OTItalicsFeature
     */
    public java.lang.String getOTItalicsFeature() {
        return OTItalicsFeature;
    }


    /**
     * Sets the OTItalicsFeature value for this RichText.
     * 
     * @param OTItalicsFeature
     */
    public void setOTItalicsFeature(java.lang.String OTItalicsFeature) {
        this.OTItalicsFeature = OTItalicsFeature;
    }


    /**
     * Gets the OTJIS04Forms value for this RichText.
     * 
     * @return OTJIS04Forms
     */
    public java.lang.String getOTJIS04Forms() {
        return OTJIS04Forms;
    }


    /**
     * Sets the OTJIS04Forms value for this RichText.
     * 
     * @param OTJIS04Forms
     */
    public void setOTJIS04Forms(java.lang.String OTJIS04Forms) {
        this.OTJIS04Forms = OTJIS04Forms;
    }


    /**
     * Gets the OTJIS78Forms value for this RichText.
     * 
     * @return OTJIS78Forms
     */
    public java.lang.String getOTJIS78Forms() {
        return OTJIS78Forms;
    }


    /**
     * Sets the OTJIS78Forms value for this RichText.
     * 
     * @param OTJIS78Forms
     */
    public void setOTJIS78Forms(java.lang.String OTJIS78Forms) {
        this.OTJIS78Forms = OTJIS78Forms;
    }


    /**
     * Gets the OTJIS83Forms value for this RichText.
     * 
     * @return OTJIS83Forms
     */
    public java.lang.String getOTJIS83Forms() {
        return OTJIS83Forms;
    }


    /**
     * Sets the OTJIS83Forms value for this RichText.
     * 
     * @param OTJIS83Forms
     */
    public void setOTJIS83Forms(java.lang.String OTJIS83Forms) {
        this.OTJIS83Forms = OTJIS83Forms;
    }


    /**
     * Gets the OTJIS90Forms value for this RichText.
     * 
     * @return OTJIS90Forms
     */
    public java.lang.String getOTJIS90Forms() {
        return OTJIS90Forms;
    }


    /**
     * Sets the OTJIS90Forms value for this RichText.
     * 
     * @param OTJIS90Forms
     */
    public void setOTJIS90Forms(java.lang.String OTJIS90Forms) {
        this.OTJIS90Forms = OTJIS90Forms;
    }


    /**
     * Gets the OTLiningFigures value for this RichText.
     * 
     * @return OTLiningFigures
     */
    public java.lang.String getOTLiningFigures() {
        return OTLiningFigures;
    }


    /**
     * Sets the OTLiningFigures value for this RichText.
     * 
     * @param OTLiningFigures
     */
    public void setOTLiningFigures(java.lang.String OTLiningFigures) {
        this.OTLiningFigures = OTLiningFigures;
    }


    /**
     * Gets the OTLocalizedForms value for this RichText.
     * 
     * @return OTLocalizedForms
     */
    public java.lang.String getOTLocalizedForms() {
        return OTLocalizedForms;
    }


    /**
     * Sets the OTLocalizedForms value for this RichText.
     * 
     * @param OTLocalizedForms
     */
    public void setOTLocalizedForms(java.lang.String OTLocalizedForms) {
        this.OTLocalizedForms = OTLocalizedForms;
    }


    /**
     * Gets the OTNumerator value for this RichText.
     * 
     * @return OTNumerator
     */
    public java.lang.String getOTNumerator() {
        return OTNumerator;
    }


    /**
     * Sets the OTNumerator value for this RichText.
     * 
     * @param OTNumerator
     */
    public void setOTNumerator(java.lang.String OTNumerator) {
        this.OTNumerator = OTNumerator;
    }


    /**
     * Gets the OTOldStyleFigures value for this RichText.
     * 
     * @return OTOldStyleFigures
     */
    public java.lang.String getOTOldStyleFigures() {
        return OTOldStyleFigures;
    }


    /**
     * Sets the OTOldStyleFigures value for this RichText.
     * 
     * @param OTOldStyleFigures
     */
    public void setOTOldStyleFigures(java.lang.String OTOldStyleFigures) {
        this.OTOldStyleFigures = OTOldStyleFigures;
    }


    /**
     * Gets the OTOrdinals value for this RichText.
     * 
     * @return OTOrdinals
     */
    public java.lang.String getOTOrdinals() {
        return OTOrdinals;
    }


    /**
     * Sets the OTOrdinals value for this RichText.
     * 
     * @param OTOrdinals
     */
    public void setOTOrdinals(java.lang.String OTOrdinals) {
        this.OTOrdinals = OTOrdinals;
    }


    /**
     * Gets the OTPositionNone value for this RichText.
     * 
     * @return OTPositionNone
     */
    public java.lang.String getOTPositionNone() {
        return OTPositionNone;
    }


    /**
     * Sets the OTPositionNone value for this RichText.
     * 
     * @param OTPositionNone
     */
    public void setOTPositionNone(java.lang.String OTPositionNone) {
        this.OTPositionNone = OTPositionNone;
    }


    /**
     * Gets the OTProportionalAltVerticalMetrics value for this RichText.
     * 
     * @return OTProportionalAltVerticalMetrics
     */
    public java.lang.String getOTProportionalAltVerticalMetrics() {
        return OTProportionalAltVerticalMetrics;
    }


    /**
     * Sets the OTProportionalAltVerticalMetrics value for this RichText.
     * 
     * @param OTProportionalAltVerticalMetrics
     */
    public void setOTProportionalAltVerticalMetrics(java.lang.String OTProportionalAltVerticalMetrics) {
        this.OTProportionalAltVerticalMetrics = OTProportionalAltVerticalMetrics;
    }


    /**
     * Gets the OTProportionalFigures value for this RichText.
     * 
     * @return OTProportionalFigures
     */
    public java.lang.String getOTProportionalFigures() {
        return OTProportionalFigures;
    }


    /**
     * Sets the OTProportionalFigures value for this RichText.
     * 
     * @param OTProportionalFigures
     */
    public void setOTProportionalFigures(java.lang.String OTProportionalFigures) {
        this.OTProportionalFigures = OTProportionalFigures;
    }


    /**
     * Gets the OTProportionalWidths value for this RichText.
     * 
     * @return OTProportionalWidths
     */
    public java.lang.String getOTProportionalWidths() {
        return OTProportionalWidths;
    }


    /**
     * Sets the OTProportionalWidths value for this RichText.
     * 
     * @param OTProportionalWidths
     */
    public void setOTProportionalWidths(java.lang.String OTProportionalWidths) {
        this.OTProportionalWidths = OTProportionalWidths;
    }


    /**
     * Gets the OTQuarterWidths value for this RichText.
     * 
     * @return OTQuarterWidths
     */
    public java.lang.String getOTQuarterWidths() {
        return OTQuarterWidths;
    }


    /**
     * Sets the OTQuarterWidths value for this RichText.
     * 
     * @param OTQuarterWidths
     */
    public void setOTQuarterWidths(java.lang.String OTQuarterWidths) {
        this.OTQuarterWidths = OTQuarterWidths;
    }


    /**
     * Gets the OTRubiNotationForms value for this RichText.
     * 
     * @return OTRubiNotationForms
     */
    public java.lang.String getOTRubiNotationForms() {
        return OTRubiNotationForms;
    }


    /**
     * Sets the OTRubiNotationForms value for this RichText.
     * 
     * @param OTRubiNotationForms
     */
    public void setOTRubiNotationForms(java.lang.String OTRubiNotationForms) {
        this.OTRubiNotationForms = OTRubiNotationForms;
    }


    /**
     * Gets the OTScientificInferiorFeature value for this RichText.
     * 
     * @return OTScientificInferiorFeature
     */
    public java.lang.String getOTScientificInferiorFeature() {
        return OTScientificInferiorFeature;
    }


    /**
     * Sets the OTScientificInferiorFeature value for this RichText.
     * 
     * @param OTScientificInferiorFeature
     */
    public void setOTScientificInferiorFeature(java.lang.String OTScientificInferiorFeature) {
        this.OTScientificInferiorFeature = OTScientificInferiorFeature;
    }


    /**
     * Gets the OTSimplifiedForms value for this RichText.
     * 
     * @return OTSimplifiedForms
     */
    public java.lang.String getOTSimplifiedForms() {
        return OTSimplifiedForms;
    }


    /**
     * Sets the OTSimplifiedForms value for this RichText.
     * 
     * @param OTSimplifiedForms
     */
    public void setOTSimplifiedForms(java.lang.String OTSimplifiedForms) {
        this.OTSimplifiedForms = OTSimplifiedForms;
    }


    /**
     * Gets the OTSmallCaps value for this RichText.
     * 
     * @return OTSmallCaps
     */
    public java.lang.String getOTSmallCaps() {
        return OTSmallCaps;
    }


    /**
     * Sets the OTSmallCaps value for this RichText.
     * 
     * @param OTSmallCaps
     */
    public void setOTSmallCaps(java.lang.String OTSmallCaps) {
        this.OTSmallCaps = OTSmallCaps;
    }


    /**
     * Gets the OTStandardLigatures value for this RichText.
     * 
     * @return OTStandardLigatures
     */
    public java.lang.String getOTStandardLigatures() {
        return OTStandardLigatures;
    }


    /**
     * Sets the OTStandardLigatures value for this RichText.
     * 
     * @param OTStandardLigatures
     */
    public void setOTStandardLigatures(java.lang.String OTStandardLigatures) {
        this.OTStandardLigatures = OTStandardLigatures;
    }


    /**
     * Gets the OTSubscript value for this RichText.
     * 
     * @return OTSubscript
     */
    public java.lang.String getOTSubscript() {
        return OTSubscript;
    }


    /**
     * Sets the OTSubscript value for this RichText.
     * 
     * @param OTSubscript
     */
    public void setOTSubscript(java.lang.String OTSubscript) {
        this.OTSubscript = OTSubscript;
    }


    /**
     * Gets the OTSuperscript value for this RichText.
     * 
     * @return OTSuperscript
     */
    public java.lang.String getOTSuperscript() {
        return OTSuperscript;
    }


    /**
     * Sets the OTSuperscript value for this RichText.
     * 
     * @param OTSuperscript
     */
    public void setOTSuperscript(java.lang.String OTSuperscript) {
        this.OTSuperscript = OTSuperscript;
    }


    /**
     * Gets the OTSwashes value for this RichText.
     * 
     * @return OTSwashes
     */
    public java.lang.String getOTSwashes() {
        return OTSwashes;
    }


    /**
     * Sets the OTSwashes value for this RichText.
     * 
     * @param OTSwashes
     */
    public void setOTSwashes(java.lang.String OTSwashes) {
        this.OTSwashes = OTSwashes;
    }


    /**
     * Gets the OTTabularFigures value for this RichText.
     * 
     * @return OTTabularFigures
     */
    public java.lang.String getOTTabularFigures() {
        return OTTabularFigures;
    }


    /**
     * Sets the OTTabularFigures value for this RichText.
     * 
     * @param OTTabularFigures
     */
    public void setOTTabularFigures(java.lang.String OTTabularFigures) {
        this.OTTabularFigures = OTTabularFigures;
    }


    /**
     * Gets the OTThirdWidths value for this RichText.
     * 
     * @return OTThirdWidths
     */
    public java.lang.String getOTThirdWidths() {
        return OTThirdWidths;
    }


    /**
     * Sets the OTThirdWidths value for this RichText.
     * 
     * @param OTThirdWidths
     */
    public void setOTThirdWidths(java.lang.String OTThirdWidths) {
        this.OTThirdWidths = OTThirdWidths;
    }


    /**
     * Gets the OTTitlingAlternates value for this RichText.
     * 
     * @return OTTitlingAlternates
     */
    public java.lang.String getOTTitlingAlternates() {
        return OTTitlingAlternates;
    }


    /**
     * Sets the OTTitlingAlternates value for this RichText.
     * 
     * @param OTTitlingAlternates
     */
    public void setOTTitlingAlternates(java.lang.String OTTitlingAlternates) {
        this.OTTitlingAlternates = OTTitlingAlternates;
    }


    /**
     * Gets the OTTraditionalForms value for this RichText.
     * 
     * @return OTTraditionalForms
     */
    public java.lang.String getOTTraditionalForms() {
        return OTTraditionalForms;
    }


    /**
     * Sets the OTTraditionalForms value for this RichText.
     * 
     * @param OTTraditionalForms
     */
    public void setOTTraditionalForms(java.lang.String OTTraditionalForms) {
        this.OTTraditionalForms = OTTraditionalForms;
    }


    /**
     * Gets the OTVariant value for this RichText.
     * 
     * @return OTVariant
     */
    public java.lang.String getOTVariant() {
        return OTVariant;
    }


    /**
     * Sets the OTVariant value for this RichText.
     * 
     * @param OTVariant
     */
    public void setOTVariant(java.lang.String OTVariant) {
        this.OTVariant = OTVariant;
    }


    /**
     * Gets the opacity value for this RichText.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this RichText.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the outline value for this RichText.
     * 
     * @return outline
     */
    public java.lang.String getOutline() {
        return outline;
    }


    /**
     * Sets the outline value for this RichText.
     * 
     * @param outline
     */
    public void setOutline(java.lang.String outline) {
        this.outline = outline;
    }


    /**
     * Gets the PSFontName value for this RichText.
     * 
     * @return PSFontName
     */
    public java.lang.String getPSFontName() {
        return PSFontName;
    }


    /**
     * Sets the PSFontName value for this RichText.
     * 
     * @param PSFontName
     */
    public void setPSFontName(java.lang.String PSFontName) {
        this.PSFontName = PSFontName;
    }


    /**
     * Gets the pageNumberChar value for this RichText.
     * 
     * @return pageNumberChar
     */
    public java.lang.String getPageNumberChar() {
        return pageNumberChar;
    }


    /**
     * Sets the pageNumberChar value for this RichText.
     * 
     * @param pageNumberChar
     */
    public void setPageNumberChar(java.lang.String pageNumberChar) {
        this.pageNumberChar = pageNumberChar;
    }


    /**
     * Gets the plain value for this RichText.
     * 
     * @return plain
     */
    public java.lang.String getPlain() {
        return plain;
    }


    /**
     * Sets the plain value for this RichText.
     * 
     * @param plain
     */
    public void setPlain(java.lang.String plain) {
        this.plain = plain;
    }


    /**
     * Gets the rightBorder value for this RichText.
     * 
     * @return rightBorder
     */
    public java.lang.String getRightBorder() {
        return rightBorder;
    }


    /**
     * Sets the rightBorder value for this RichText.
     * 
     * @param rightBorder
     */
    public void setRightBorder(java.lang.String rightBorder) {
        this.rightBorder = rightBorder;
    }


    /**
     * Gets the script value for this RichText.
     * 
     * @return script
     */
    public java.lang.String getScript() {
        return script;
    }


    /**
     * Sets the script value for this RichText.
     * 
     * @param script
     */
    public void setScript(java.lang.String script) {
        this.script = script;
    }


    /**
     * Gets the sending value for this RichText.
     * 
     * @return sending
     */
    public java.lang.String getSending() {
        return sending;
    }


    /**
     * Sets the sending value for this RichText.
     * 
     * @param sending
     */
    public void setSending(java.lang.String sending) {
        this.sending = sending;
    }


    /**
     * Gets the shade value for this RichText.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this RichText.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the shadingStyleName value for this RichText.
     * 
     * @return shadingStyleName
     */
    public java.lang.String getShadingStyleName() {
        return shadingStyleName;
    }


    /**
     * Sets the shadingStyleName value for this RichText.
     * 
     * @param shadingStyleName
     */
    public void setShadingStyleName(java.lang.String shadingStyleName) {
        this.shadingStyleName = shadingStyleName;
    }


    /**
     * Gets the shadow value for this RichText.
     * 
     * @return shadow
     */
    public java.lang.String getShadow() {
        return shadow;
    }


    /**
     * Sets the shadow value for this RichText.
     * 
     * @param shadow
     */
    public void setShadow(java.lang.String shadow) {
        this.shadow = shadow;
    }


    /**
     * Gets the size value for this RichText.
     * 
     * @return size
     */
    public java.lang.String getSize() {
        return size;
    }


    /**
     * Sets the size value for this RichText.
     * 
     * @param size
     */
    public void setSize(java.lang.String size) {
        this.size = size;
    }


    /**
     * Gets the smallCaps value for this RichText.
     * 
     * @return smallCaps
     */
    public java.lang.String getSmallCaps() {
        return smallCaps;
    }


    /**
     * Sets the smallCaps value for this RichText.
     * 
     * @param smallCaps
     */
    public void setSmallCaps(java.lang.String smallCaps) {
        this.smallCaps = smallCaps;
    }


    /**
     * Gets the strikeThru value for this RichText.
     * 
     * @return strikeThru
     */
    public java.lang.String getStrikeThru() {
        return strikeThru;
    }


    /**
     * Sets the strikeThru value for this RichText.
     * 
     * @param strikeThru
     */
    public void setStrikeThru(java.lang.String strikeThru) {
        this.strikeThru = strikeThru;
    }


    /**
     * Gets the subScript value for this RichText.
     * 
     * @return subScript
     */
    public java.lang.String getSubScript() {
        return subScript;
    }


    /**
     * Sets the subScript value for this RichText.
     * 
     * @param subScript
     */
    public void setSubScript(java.lang.String subScript) {
        this.subScript = subScript;
    }


    /**
     * Gets the superScript value for this RichText.
     * 
     * @return superScript
     */
    public java.lang.String getSuperScript() {
        return superScript;
    }


    /**
     * Sets the superScript value for this RichText.
     * 
     * @param superScript
     */
    public void setSuperScript(java.lang.String superScript) {
        this.superScript = superScript;
    }


    /**
     * Gets the superior value for this RichText.
     * 
     * @return superior
     */
    public java.lang.String getSuperior() {
        return superior;
    }


    /**
     * Sets the superior value for this RichText.
     * 
     * @param superior
     */
    public void setSuperior(java.lang.String superior) {
        this.superior = superior;
    }


    /**
     * Gets the topBorder value for this RichText.
     * 
     * @return topBorder
     */
    public java.lang.String getTopBorder() {
        return topBorder;
    }


    /**
     * Sets the topBorder value for this RichText.
     * 
     * @param topBorder
     */
    public void setTopBorder(java.lang.String topBorder) {
        this.topBorder = topBorder;
    }


    /**
     * Gets the trackAmount value for this RichText.
     * 
     * @return trackAmount
     */
    public java.lang.String getTrackAmount() {
        return trackAmount;
    }


    /**
     * Sets the trackAmount value for this RichText.
     * 
     * @param trackAmount
     */
    public void setTrackAmount(java.lang.String trackAmount) {
        this.trackAmount = trackAmount;
    }


    /**
     * Gets the underline value for this RichText.
     * 
     * @return underline
     */
    public java.lang.String getUnderline() {
        return underline;
    }


    /**
     * Sets the underline value for this RichText.
     * 
     * @param underline
     */
    public void setUnderline(java.lang.String underline) {
        this.underline = underline;
    }


    /**
     * Gets the unencodedGlyphId value for this RichText.
     * 
     * @return unencodedGlyphId
     */
    public java.lang.String getUnencodedGlyphId() {
        return unencodedGlyphId;
    }


    /**
     * Sets the unencodedGlyphId value for this RichText.
     * 
     * @param unencodedGlyphId
     */
    public void setUnencodedGlyphId(java.lang.String unencodedGlyphId) {
        this.unencodedGlyphId = unencodedGlyphId;
    }


    /**
     * Gets the value value for this RichText.
     * 
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }


    /**
     * Sets the value value for this RichText.
     * 
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }


    /**
     * Gets the verticalScale value for this RichText.
     * 
     * @return verticalScale
     */
    public java.lang.String getVerticalScale() {
        return verticalScale;
    }


    /**
     * Sets the verticalScale value for this RichText.
     * 
     * @param verticalScale
     */
    public void setVerticalScale(java.lang.String verticalScale) {
        this.verticalScale = verticalScale;
    }


    /**
     * Gets the wordUnderline value for this RichText.
     * 
     * @return wordUnderline
     */
    public java.lang.String getWordUnderline() {
        return wordUnderline;
    }


    /**
     * Sets the wordUnderline value for this RichText.
     * 
     * @param wordUnderline
     */
    public void setWordUnderline(java.lang.String wordUnderline) {
        this.wordUnderline = wordUnderline;
    }


    /**
     * Gets the xrefLabel value for this RichText.
     * 
     * @return xrefLabel
     */
    public java.lang.String getXrefLabel() {
        return xrefLabel;
    }


    /**
     * Sets the xrefLabel value for this RichText.
     * 
     * @param xrefLabel
     */
    public void setXrefLabel(java.lang.String xrefLabel) {
        this.xrefLabel = xrefLabel;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RichText)) return false;
        RichText other = (RichText) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.allCaps==null && other.getAllCaps()==null) || 
             (this.allCaps!=null &&
              this.allCaps.equals(other.getAllCaps()))) &&
            ((this.applySendingToNonCJK==null && other.getApplySendingToNonCJK()==null) || 
             (this.applySendingToNonCJK!=null &&
              this.applySendingToNonCJK.equals(other.getApplySendingToNonCJK()))) &&
            ((this.backgroundColor==null && other.getBackgroundColor()==null) || 
             (this.backgroundColor!=null &&
              this.backgroundColor.equals(other.getBackgroundColor()))) &&
            ((this.backgroundColorBottomPadding==null && other.getBackgroundColorBottomPadding()==null) || 
             (this.backgroundColorBottomPadding!=null &&
              this.backgroundColorBottomPadding.equals(other.getBackgroundColorBottomPadding()))) &&
            ((this.backgroundColorLeftPadding==null && other.getBackgroundColorLeftPadding()==null) || 
             (this.backgroundColorLeftPadding!=null &&
              this.backgroundColorLeftPadding.equals(other.getBackgroundColorLeftPadding()))) &&
            ((this.backgroundColorOpacity==null && other.getBackgroundColorOpacity()==null) || 
             (this.backgroundColorOpacity!=null &&
              this.backgroundColorOpacity.equals(other.getBackgroundColorOpacity()))) &&
            ((this.backgroundColorRightPadding==null && other.getBackgroundColorRightPadding()==null) || 
             (this.backgroundColorRightPadding!=null &&
              this.backgroundColorRightPadding.equals(other.getBackgroundColorRightPadding()))) &&
            ((this.backgroundColorShade==null && other.getBackgroundColorShade()==null) || 
             (this.backgroundColorShade!=null &&
              this.backgroundColorShade.equals(other.getBackgroundColorShade()))) &&
            ((this.backgroundColorTopPadding==null && other.getBackgroundColorTopPadding()==null) || 
             (this.backgroundColorTopPadding!=null &&
              this.backgroundColorTopPadding.equals(other.getBackgroundColorTopPadding()))) &&
            ((this.baselineShift==null && other.getBaselineShift()==null) || 
             (this.baselineShift!=null &&
              this.baselineShift.equals(other.getBaselineShift()))) &&
            ((this.bold==null && other.getBold()==null) || 
             (this.bold!=null &&
              this.bold.equals(other.getBold()))) &&
            ((this.borderBottomPadding==null && other.getBorderBottomPadding()==null) || 
             (this.borderBottomPadding!=null &&
              this.borderBottomPadding.equals(other.getBorderBottomPadding()))) &&
            ((this.borderColor==null && other.getBorderColor()==null) || 
             (this.borderColor!=null &&
              this.borderColor.equals(other.getBorderColor()))) &&
            ((this.borderLeftPadding==null && other.getBorderLeftPadding()==null) || 
             (this.borderLeftPadding!=null &&
              this.borderLeftPadding.equals(other.getBorderLeftPadding()))) &&
            ((this.borderOpacity==null && other.getBorderOpacity()==null) || 
             (this.borderOpacity!=null &&
              this.borderOpacity.equals(other.getBorderOpacity()))) &&
            ((this.borderRightPadding==null && other.getBorderRightPadding()==null) || 
             (this.borderRightPadding!=null &&
              this.borderRightPadding.equals(other.getBorderRightPadding()))) &&
            ((this.borderShade==null && other.getBorderShade()==null) || 
             (this.borderShade!=null &&
              this.borderShade.equals(other.getBorderShade()))) &&
            ((this.borderStyle==null && other.getBorderStyle()==null) || 
             (this.borderStyle!=null &&
              this.borderStyle.equals(other.getBorderStyle()))) &&
            ((this.borderTopPadding==null && other.getBorderTopPadding()==null) || 
             (this.borderTopPadding!=null &&
              this.borderTopPadding.equals(other.getBorderTopPadding()))) &&
            ((this.borderWidth==null && other.getBorderWidth()==null) || 
             (this.borderWidth!=null &&
              this.borderWidth.equals(other.getBorderWidth()))) &&
            ((this.bottomBorder==null && other.getBottomBorder()==null) || 
             (this.bottomBorder!=null &&
              this.bottomBorder.equals(other.getBottomBorder()))) &&
            ((this.charStyle==null && other.getCharStyle()==null) || 
             (this.charStyle!=null &&
              this.charStyle.equals(other.getCharStyle()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.doubleStrikeThru==null && other.getDoubleStrikeThru()==null) || 
             (this.doubleStrikeThru!=null &&
              this.doubleStrikeThru.equals(other.getDoubleStrikeThru()))) &&
            ((this.emphasisMark==null && other.getEmphasisMark()==null) || 
             (this.emphasisMark!=null &&
              this.emphasisMark.equals(other.getEmphasisMark()))) &&
            ((this.fauxStyle==null && other.getFauxStyle()==null) || 
             (this.fauxStyle!=null &&
              this.fauxStyle.equals(other.getFauxStyle()))) &&
            ((this.font==null && other.getFont()==null) || 
             (this.font!=null &&
              this.font.equals(other.getFont()))) &&
            ((this.fontset==null && other.getFontset()==null) || 
             (this.fontset!=null &&
              this.fontset.equals(other.getFontset()))) &&
            ((this.fontsetSize==null && other.getFontsetSize()==null) || 
             (this.fontsetSize!=null &&
              this.fontsetSize.equals(other.getFontsetSize()))) &&
            ((this.HLAnchorRef==null && other.getHLAnchorRef()==null) || 
             (this.HLAnchorRef!=null &&
              this.HLAnchorRef.equals(other.getHLAnchorRef()))) &&
            ((this.HLType==null && other.getHLType()==null) || 
             (this.HLType!=null &&
              this.HLType.equals(other.getHLType()))) &&
            ((this.halfWidthUpright==null && other.getHalfWidthUpright()==null) || 
             (this.halfWidthUpright!=null &&
              this.halfWidthUpright.equals(other.getHalfWidthUpright()))) &&
            ((this.horizontalScale==null && other.getHorizontalScale()==null) || 
             (this.horizontalScale!=null &&
              this.horizontalScale.equals(other.getHorizontalScale()))) &&
            ((this.hyperlinkRef==null && other.getHyperlinkRef()==null) || 
             (this.hyperlinkRef!=null &&
              this.hyperlinkRef.equals(other.getHyperlinkRef()))) &&
            this.index == other.getIndex() &&
            ((this.italic==null && other.getItalic()==null) || 
             (this.italic!=null &&
              this.italic.equals(other.getItalic()))) &&
            ((this.kernAmount==null && other.getKernAmount()==null) || 
             (this.kernAmount!=null &&
              this.kernAmount.equals(other.getKernAmount()))) &&
            ((this.language==null && other.getLanguage()==null) || 
             (this.language!=null &&
              this.language.equals(other.getLanguage()))) &&
            ((this.leftBorder==null && other.getLeftBorder()==null) || 
             (this.leftBorder!=null &&
              this.leftBorder.equals(other.getLeftBorder()))) &&
            ((this.ligatures==null && other.getLigatures()==null) || 
             (this.ligatures!=null &&
              this.ligatures.equals(other.getLigatures()))) &&
            ((this.merge==null && other.getMerge()==null) || 
             (this.merge!=null &&
              this.merge.equals(other.getMerge()))) &&
            ((this.missingFont==null && other.getMissingFont()==null) || 
             (this.missingFont!=null &&
              this.missingFont.equals(other.getMissingFont()))) &&
            ((this.nonBreaking==null && other.getNonBreaking()==null) || 
             (this.nonBreaking!=null &&
              this.nonBreaking.equals(other.getNonBreaking()))) &&
            ((this.OTAllSmallCaps==null && other.getOTAllSmallCaps()==null) || 
             (this.OTAllSmallCaps!=null &&
              this.OTAllSmallCaps.equals(other.getOTAllSmallCaps()))) &&
            ((this.OTAltVerticalMetrics==null && other.getOTAltVerticalMetrics()==null) || 
             (this.OTAltVerticalMetrics!=null &&
              this.OTAltVerticalMetrics.equals(other.getOTAltVerticalMetrics()))) &&
            ((this.OTAlternateFormsNone==null && other.getOTAlternateFormsNone()==null) || 
             (this.OTAlternateFormsNone!=null &&
              this.OTAlternateFormsNone.equals(other.getOTAlternateFormsNone()))) &&
            ((this.OTAlternateHalfMetrics==null && other.getOTAlternateHalfMetrics()==null) || 
             (this.OTAlternateHalfMetrics!=null &&
              this.OTAlternateHalfMetrics.equals(other.getOTAlternateHalfMetrics()))) &&
            ((this.OTAlternateWidthsNone==null && other.getOTAlternateWidthsNone()==null) || 
             (this.OTAlternateWidthsNone!=null &&
              this.OTAlternateWidthsNone.equals(other.getOTAlternateWidthsNone()))) &&
            ((this.OTContextualAlternatives==null && other.getOTContextualAlternatives()==null) || 
             (this.OTContextualAlternatives!=null &&
              this.OTContextualAlternatives.equals(other.getOTContextualAlternatives()))) &&
            ((this.OTDenominator==null && other.getOTDenominator()==null) || 
             (this.OTDenominator!=null &&
              this.OTDenominator.equals(other.getOTDenominator()))) &&
            ((this.OTDiscretionaryLigatures==null && other.getOTDiscretionaryLigatures()==null) || 
             (this.OTDiscretionaryLigatures!=null &&
              this.OTDiscretionaryLigatures.equals(other.getOTDiscretionaryLigatures()))) &&
            ((this.OTFeature==null && other.getOTFeature()==null) || 
             (this.OTFeature!=null &&
              this.OTFeature.equals(other.getOTFeature()))) &&
            ((this.OTFractions==null && other.getOTFractions()==null) || 
             (this.OTFractions!=null &&
              this.OTFractions.equals(other.getOTFractions()))) &&
            ((this.OTFullWidths==null && other.getOTFullWidths()==null) || 
             (this.OTFullWidths!=null &&
              this.OTFullWidths.equals(other.getOTFullWidths()))) &&
            ((this.OTHVKanaAlternatives==null && other.getOTHVKanaAlternatives()==null) || 
             (this.OTHVKanaAlternatives!=null &&
              this.OTHVKanaAlternatives.equals(other.getOTHVKanaAlternatives()))) &&
            ((this.OTHalfWidths==null && other.getOTHalfWidths()==null) || 
             (this.OTHalfWidths!=null &&
              this.OTHalfWidths.equals(other.getOTHalfWidths()))) &&
            ((this.OTItalicsFeature==null && other.getOTItalicsFeature()==null) || 
             (this.OTItalicsFeature!=null &&
              this.OTItalicsFeature.equals(other.getOTItalicsFeature()))) &&
            ((this.OTJIS04Forms==null && other.getOTJIS04Forms()==null) || 
             (this.OTJIS04Forms!=null &&
              this.OTJIS04Forms.equals(other.getOTJIS04Forms()))) &&
            ((this.OTJIS78Forms==null && other.getOTJIS78Forms()==null) || 
             (this.OTJIS78Forms!=null &&
              this.OTJIS78Forms.equals(other.getOTJIS78Forms()))) &&
            ((this.OTJIS83Forms==null && other.getOTJIS83Forms()==null) || 
             (this.OTJIS83Forms!=null &&
              this.OTJIS83Forms.equals(other.getOTJIS83Forms()))) &&
            ((this.OTJIS90Forms==null && other.getOTJIS90Forms()==null) || 
             (this.OTJIS90Forms!=null &&
              this.OTJIS90Forms.equals(other.getOTJIS90Forms()))) &&
            ((this.OTLiningFigures==null && other.getOTLiningFigures()==null) || 
             (this.OTLiningFigures!=null &&
              this.OTLiningFigures.equals(other.getOTLiningFigures()))) &&
            ((this.OTLocalizedForms==null && other.getOTLocalizedForms()==null) || 
             (this.OTLocalizedForms!=null &&
              this.OTLocalizedForms.equals(other.getOTLocalizedForms()))) &&
            ((this.OTNumerator==null && other.getOTNumerator()==null) || 
             (this.OTNumerator!=null &&
              this.OTNumerator.equals(other.getOTNumerator()))) &&
            ((this.OTOldStyleFigures==null && other.getOTOldStyleFigures()==null) || 
             (this.OTOldStyleFigures!=null &&
              this.OTOldStyleFigures.equals(other.getOTOldStyleFigures()))) &&
            ((this.OTOrdinals==null && other.getOTOrdinals()==null) || 
             (this.OTOrdinals!=null &&
              this.OTOrdinals.equals(other.getOTOrdinals()))) &&
            ((this.OTPositionNone==null && other.getOTPositionNone()==null) || 
             (this.OTPositionNone!=null &&
              this.OTPositionNone.equals(other.getOTPositionNone()))) &&
            ((this.OTProportionalAltVerticalMetrics==null && other.getOTProportionalAltVerticalMetrics()==null) || 
             (this.OTProportionalAltVerticalMetrics!=null &&
              this.OTProportionalAltVerticalMetrics.equals(other.getOTProportionalAltVerticalMetrics()))) &&
            ((this.OTProportionalFigures==null && other.getOTProportionalFigures()==null) || 
             (this.OTProportionalFigures!=null &&
              this.OTProportionalFigures.equals(other.getOTProportionalFigures()))) &&
            ((this.OTProportionalWidths==null && other.getOTProportionalWidths()==null) || 
             (this.OTProportionalWidths!=null &&
              this.OTProportionalWidths.equals(other.getOTProportionalWidths()))) &&
            ((this.OTQuarterWidths==null && other.getOTQuarterWidths()==null) || 
             (this.OTQuarterWidths!=null &&
              this.OTQuarterWidths.equals(other.getOTQuarterWidths()))) &&
            ((this.OTRubiNotationForms==null && other.getOTRubiNotationForms()==null) || 
             (this.OTRubiNotationForms!=null &&
              this.OTRubiNotationForms.equals(other.getOTRubiNotationForms()))) &&
            ((this.OTScientificInferiorFeature==null && other.getOTScientificInferiorFeature()==null) || 
             (this.OTScientificInferiorFeature!=null &&
              this.OTScientificInferiorFeature.equals(other.getOTScientificInferiorFeature()))) &&
            ((this.OTSimplifiedForms==null && other.getOTSimplifiedForms()==null) || 
             (this.OTSimplifiedForms!=null &&
              this.OTSimplifiedForms.equals(other.getOTSimplifiedForms()))) &&
            ((this.OTSmallCaps==null && other.getOTSmallCaps()==null) || 
             (this.OTSmallCaps!=null &&
              this.OTSmallCaps.equals(other.getOTSmallCaps()))) &&
            ((this.OTStandardLigatures==null && other.getOTStandardLigatures()==null) || 
             (this.OTStandardLigatures!=null &&
              this.OTStandardLigatures.equals(other.getOTStandardLigatures()))) &&
            ((this.OTSubscript==null && other.getOTSubscript()==null) || 
             (this.OTSubscript!=null &&
              this.OTSubscript.equals(other.getOTSubscript()))) &&
            ((this.OTSuperscript==null && other.getOTSuperscript()==null) || 
             (this.OTSuperscript!=null &&
              this.OTSuperscript.equals(other.getOTSuperscript()))) &&
            ((this.OTSwashes==null && other.getOTSwashes()==null) || 
             (this.OTSwashes!=null &&
              this.OTSwashes.equals(other.getOTSwashes()))) &&
            ((this.OTTabularFigures==null && other.getOTTabularFigures()==null) || 
             (this.OTTabularFigures!=null &&
              this.OTTabularFigures.equals(other.getOTTabularFigures()))) &&
            ((this.OTThirdWidths==null && other.getOTThirdWidths()==null) || 
             (this.OTThirdWidths!=null &&
              this.OTThirdWidths.equals(other.getOTThirdWidths()))) &&
            ((this.OTTitlingAlternates==null && other.getOTTitlingAlternates()==null) || 
             (this.OTTitlingAlternates!=null &&
              this.OTTitlingAlternates.equals(other.getOTTitlingAlternates()))) &&
            ((this.OTTraditionalForms==null && other.getOTTraditionalForms()==null) || 
             (this.OTTraditionalForms!=null &&
              this.OTTraditionalForms.equals(other.getOTTraditionalForms()))) &&
            ((this.OTVariant==null && other.getOTVariant()==null) || 
             (this.OTVariant!=null &&
              this.OTVariant.equals(other.getOTVariant()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.outline==null && other.getOutline()==null) || 
             (this.outline!=null &&
              this.outline.equals(other.getOutline()))) &&
            ((this.PSFontName==null && other.getPSFontName()==null) || 
             (this.PSFontName!=null &&
              this.PSFontName.equals(other.getPSFontName()))) &&
            ((this.pageNumberChar==null && other.getPageNumberChar()==null) || 
             (this.pageNumberChar!=null &&
              this.pageNumberChar.equals(other.getPageNumberChar()))) &&
            ((this.plain==null && other.getPlain()==null) || 
             (this.plain!=null &&
              this.plain.equals(other.getPlain()))) &&
            ((this.rightBorder==null && other.getRightBorder()==null) || 
             (this.rightBorder!=null &&
              this.rightBorder.equals(other.getRightBorder()))) &&
            ((this.script==null && other.getScript()==null) || 
             (this.script!=null &&
              this.script.equals(other.getScript()))) &&
            ((this.sending==null && other.getSending()==null) || 
             (this.sending!=null &&
              this.sending.equals(other.getSending()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.shadingStyleName==null && other.getShadingStyleName()==null) || 
             (this.shadingStyleName!=null &&
              this.shadingStyleName.equals(other.getShadingStyleName()))) &&
            ((this.shadow==null && other.getShadow()==null) || 
             (this.shadow!=null &&
              this.shadow.equals(other.getShadow()))) &&
            ((this.size==null && other.getSize()==null) || 
             (this.size!=null &&
              this.size.equals(other.getSize()))) &&
            ((this.smallCaps==null && other.getSmallCaps()==null) || 
             (this.smallCaps!=null &&
              this.smallCaps.equals(other.getSmallCaps()))) &&
            ((this.strikeThru==null && other.getStrikeThru()==null) || 
             (this.strikeThru!=null &&
              this.strikeThru.equals(other.getStrikeThru()))) &&
            ((this.subScript==null && other.getSubScript()==null) || 
             (this.subScript!=null &&
              this.subScript.equals(other.getSubScript()))) &&
            ((this.superScript==null && other.getSuperScript()==null) || 
             (this.superScript!=null &&
              this.superScript.equals(other.getSuperScript()))) &&
            ((this.superior==null && other.getSuperior()==null) || 
             (this.superior!=null &&
              this.superior.equals(other.getSuperior()))) &&
            ((this.topBorder==null && other.getTopBorder()==null) || 
             (this.topBorder!=null &&
              this.topBorder.equals(other.getTopBorder()))) &&
            ((this.trackAmount==null && other.getTrackAmount()==null) || 
             (this.trackAmount!=null &&
              this.trackAmount.equals(other.getTrackAmount()))) &&
            ((this.underline==null && other.getUnderline()==null) || 
             (this.underline!=null &&
              this.underline.equals(other.getUnderline()))) &&
            ((this.unencodedGlyphId==null && other.getUnencodedGlyphId()==null) || 
             (this.unencodedGlyphId!=null &&
              this.unencodedGlyphId.equals(other.getUnencodedGlyphId()))) &&
            ((this.value==null && other.getValue()==null) || 
             (this.value!=null &&
              this.value.equals(other.getValue()))) &&
            ((this.verticalScale==null && other.getVerticalScale()==null) || 
             (this.verticalScale!=null &&
              this.verticalScale.equals(other.getVerticalScale()))) &&
            ((this.wordUnderline==null && other.getWordUnderline()==null) || 
             (this.wordUnderline!=null &&
              this.wordUnderline.equals(other.getWordUnderline()))) &&
            ((this.xrefLabel==null && other.getXrefLabel()==null) || 
             (this.xrefLabel!=null &&
              this.xrefLabel.equals(other.getXrefLabel())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAllCaps() != null) {
            _hashCode += getAllCaps().hashCode();
        }
        if (getApplySendingToNonCJK() != null) {
            _hashCode += getApplySendingToNonCJK().hashCode();
        }
        if (getBackgroundColor() != null) {
            _hashCode += getBackgroundColor().hashCode();
        }
        if (getBackgroundColorBottomPadding() != null) {
            _hashCode += getBackgroundColorBottomPadding().hashCode();
        }
        if (getBackgroundColorLeftPadding() != null) {
            _hashCode += getBackgroundColorLeftPadding().hashCode();
        }
        if (getBackgroundColorOpacity() != null) {
            _hashCode += getBackgroundColorOpacity().hashCode();
        }
        if (getBackgroundColorRightPadding() != null) {
            _hashCode += getBackgroundColorRightPadding().hashCode();
        }
        if (getBackgroundColorShade() != null) {
            _hashCode += getBackgroundColorShade().hashCode();
        }
        if (getBackgroundColorTopPadding() != null) {
            _hashCode += getBackgroundColorTopPadding().hashCode();
        }
        if (getBaselineShift() != null) {
            _hashCode += getBaselineShift().hashCode();
        }
        if (getBold() != null) {
            _hashCode += getBold().hashCode();
        }
        if (getBorderBottomPadding() != null) {
            _hashCode += getBorderBottomPadding().hashCode();
        }
        if (getBorderColor() != null) {
            _hashCode += getBorderColor().hashCode();
        }
        if (getBorderLeftPadding() != null) {
            _hashCode += getBorderLeftPadding().hashCode();
        }
        if (getBorderOpacity() != null) {
            _hashCode += getBorderOpacity().hashCode();
        }
        if (getBorderRightPadding() != null) {
            _hashCode += getBorderRightPadding().hashCode();
        }
        if (getBorderShade() != null) {
            _hashCode += getBorderShade().hashCode();
        }
        if (getBorderStyle() != null) {
            _hashCode += getBorderStyle().hashCode();
        }
        if (getBorderTopPadding() != null) {
            _hashCode += getBorderTopPadding().hashCode();
        }
        if (getBorderWidth() != null) {
            _hashCode += getBorderWidth().hashCode();
        }
        if (getBottomBorder() != null) {
            _hashCode += getBottomBorder().hashCode();
        }
        if (getCharStyle() != null) {
            _hashCode += getCharStyle().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getDoubleStrikeThru() != null) {
            _hashCode += getDoubleStrikeThru().hashCode();
        }
        if (getEmphasisMark() != null) {
            _hashCode += getEmphasisMark().hashCode();
        }
        if (getFauxStyle() != null) {
            _hashCode += getFauxStyle().hashCode();
        }
        if (getFont() != null) {
            _hashCode += getFont().hashCode();
        }
        if (getFontset() != null) {
            _hashCode += getFontset().hashCode();
        }
        if (getFontsetSize() != null) {
            _hashCode += getFontsetSize().hashCode();
        }
        if (getHLAnchorRef() != null) {
            _hashCode += getHLAnchorRef().hashCode();
        }
        if (getHLType() != null) {
            _hashCode += getHLType().hashCode();
        }
        if (getHalfWidthUpright() != null) {
            _hashCode += getHalfWidthUpright().hashCode();
        }
        if (getHorizontalScale() != null) {
            _hashCode += getHorizontalScale().hashCode();
        }
        if (getHyperlinkRef() != null) {
            _hashCode += getHyperlinkRef().hashCode();
        }
        _hashCode += getIndex();
        if (getItalic() != null) {
            _hashCode += getItalic().hashCode();
        }
        if (getKernAmount() != null) {
            _hashCode += getKernAmount().hashCode();
        }
        if (getLanguage() != null) {
            _hashCode += getLanguage().hashCode();
        }
        if (getLeftBorder() != null) {
            _hashCode += getLeftBorder().hashCode();
        }
        if (getLigatures() != null) {
            _hashCode += getLigatures().hashCode();
        }
        if (getMerge() != null) {
            _hashCode += getMerge().hashCode();
        }
        if (getMissingFont() != null) {
            _hashCode += getMissingFont().hashCode();
        }
        if (getNonBreaking() != null) {
            _hashCode += getNonBreaking().hashCode();
        }
        if (getOTAllSmallCaps() != null) {
            _hashCode += getOTAllSmallCaps().hashCode();
        }
        if (getOTAltVerticalMetrics() != null) {
            _hashCode += getOTAltVerticalMetrics().hashCode();
        }
        if (getOTAlternateFormsNone() != null) {
            _hashCode += getOTAlternateFormsNone().hashCode();
        }
        if (getOTAlternateHalfMetrics() != null) {
            _hashCode += getOTAlternateHalfMetrics().hashCode();
        }
        if (getOTAlternateWidthsNone() != null) {
            _hashCode += getOTAlternateWidthsNone().hashCode();
        }
        if (getOTContextualAlternatives() != null) {
            _hashCode += getOTContextualAlternatives().hashCode();
        }
        if (getOTDenominator() != null) {
            _hashCode += getOTDenominator().hashCode();
        }
        if (getOTDiscretionaryLigatures() != null) {
            _hashCode += getOTDiscretionaryLigatures().hashCode();
        }
        if (getOTFeature() != null) {
            _hashCode += getOTFeature().hashCode();
        }
        if (getOTFractions() != null) {
            _hashCode += getOTFractions().hashCode();
        }
        if (getOTFullWidths() != null) {
            _hashCode += getOTFullWidths().hashCode();
        }
        if (getOTHVKanaAlternatives() != null) {
            _hashCode += getOTHVKanaAlternatives().hashCode();
        }
        if (getOTHalfWidths() != null) {
            _hashCode += getOTHalfWidths().hashCode();
        }
        if (getOTItalicsFeature() != null) {
            _hashCode += getOTItalicsFeature().hashCode();
        }
        if (getOTJIS04Forms() != null) {
            _hashCode += getOTJIS04Forms().hashCode();
        }
        if (getOTJIS78Forms() != null) {
            _hashCode += getOTJIS78Forms().hashCode();
        }
        if (getOTJIS83Forms() != null) {
            _hashCode += getOTJIS83Forms().hashCode();
        }
        if (getOTJIS90Forms() != null) {
            _hashCode += getOTJIS90Forms().hashCode();
        }
        if (getOTLiningFigures() != null) {
            _hashCode += getOTLiningFigures().hashCode();
        }
        if (getOTLocalizedForms() != null) {
            _hashCode += getOTLocalizedForms().hashCode();
        }
        if (getOTNumerator() != null) {
            _hashCode += getOTNumerator().hashCode();
        }
        if (getOTOldStyleFigures() != null) {
            _hashCode += getOTOldStyleFigures().hashCode();
        }
        if (getOTOrdinals() != null) {
            _hashCode += getOTOrdinals().hashCode();
        }
        if (getOTPositionNone() != null) {
            _hashCode += getOTPositionNone().hashCode();
        }
        if (getOTProportionalAltVerticalMetrics() != null) {
            _hashCode += getOTProportionalAltVerticalMetrics().hashCode();
        }
        if (getOTProportionalFigures() != null) {
            _hashCode += getOTProportionalFigures().hashCode();
        }
        if (getOTProportionalWidths() != null) {
            _hashCode += getOTProportionalWidths().hashCode();
        }
        if (getOTQuarterWidths() != null) {
            _hashCode += getOTQuarterWidths().hashCode();
        }
        if (getOTRubiNotationForms() != null) {
            _hashCode += getOTRubiNotationForms().hashCode();
        }
        if (getOTScientificInferiorFeature() != null) {
            _hashCode += getOTScientificInferiorFeature().hashCode();
        }
        if (getOTSimplifiedForms() != null) {
            _hashCode += getOTSimplifiedForms().hashCode();
        }
        if (getOTSmallCaps() != null) {
            _hashCode += getOTSmallCaps().hashCode();
        }
        if (getOTStandardLigatures() != null) {
            _hashCode += getOTStandardLigatures().hashCode();
        }
        if (getOTSubscript() != null) {
            _hashCode += getOTSubscript().hashCode();
        }
        if (getOTSuperscript() != null) {
            _hashCode += getOTSuperscript().hashCode();
        }
        if (getOTSwashes() != null) {
            _hashCode += getOTSwashes().hashCode();
        }
        if (getOTTabularFigures() != null) {
            _hashCode += getOTTabularFigures().hashCode();
        }
        if (getOTThirdWidths() != null) {
            _hashCode += getOTThirdWidths().hashCode();
        }
        if (getOTTitlingAlternates() != null) {
            _hashCode += getOTTitlingAlternates().hashCode();
        }
        if (getOTTraditionalForms() != null) {
            _hashCode += getOTTraditionalForms().hashCode();
        }
        if (getOTVariant() != null) {
            _hashCode += getOTVariant().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getOutline() != null) {
            _hashCode += getOutline().hashCode();
        }
        if (getPSFontName() != null) {
            _hashCode += getPSFontName().hashCode();
        }
        if (getPageNumberChar() != null) {
            _hashCode += getPageNumberChar().hashCode();
        }
        if (getPlain() != null) {
            _hashCode += getPlain().hashCode();
        }
        if (getRightBorder() != null) {
            _hashCode += getRightBorder().hashCode();
        }
        if (getScript() != null) {
            _hashCode += getScript().hashCode();
        }
        if (getSending() != null) {
            _hashCode += getSending().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getShadingStyleName() != null) {
            _hashCode += getShadingStyleName().hashCode();
        }
        if (getShadow() != null) {
            _hashCode += getShadow().hashCode();
        }
        if (getSize() != null) {
            _hashCode += getSize().hashCode();
        }
        if (getSmallCaps() != null) {
            _hashCode += getSmallCaps().hashCode();
        }
        if (getStrikeThru() != null) {
            _hashCode += getStrikeThru().hashCode();
        }
        if (getSubScript() != null) {
            _hashCode += getSubScript().hashCode();
        }
        if (getSuperScript() != null) {
            _hashCode += getSuperScript().hashCode();
        }
        if (getSuperior() != null) {
            _hashCode += getSuperior().hashCode();
        }
        if (getTopBorder() != null) {
            _hashCode += getTopBorder().hashCode();
        }
        if (getTrackAmount() != null) {
            _hashCode += getTrackAmount().hashCode();
        }
        if (getUnderline() != null) {
            _hashCode += getUnderline().hashCode();
        }
        if (getUnencodedGlyphId() != null) {
            _hashCode += getUnencodedGlyphId().hashCode();
        }
        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }
        if (getVerticalScale() != null) {
            _hashCode += getVerticalScale().hashCode();
        }
        if (getWordUnderline() != null) {
            _hashCode += getWordUnderline().hashCode();
        }
        if (getXrefLabel() != null) {
            _hashCode += getXrefLabel().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RichText.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RichText"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allCaps");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "allCaps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("applySendingToNonCJK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "applySendingToNonCJK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("backgroundColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "backgroundColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("backgroundColorBottomPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "backgroundColorBottomPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("backgroundColorLeftPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "backgroundColorLeftPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("backgroundColorOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "backgroundColorOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("backgroundColorRightPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "backgroundColorRightPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("backgroundColorShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "backgroundColorShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("backgroundColorTopPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "backgroundColorTopPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("baselineShift");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "baselineShift"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bold");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "bold"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bottomBorder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "bottomBorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("charStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "charStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("doubleStrikeThru");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "doubleStrikeThru"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emphasisMark");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "emphasisMark"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fauxStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fauxStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("font");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "font"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fontset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fontset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fontsetSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fontsetSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HLAnchorRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HLAnchorRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HLType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HLType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("halfWidthUpright");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "halfWidthUpright"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horizontalScale");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "horizontalScale"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hyperlinkRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hyperlinkRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("italic");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "italic"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kernAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "kernAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftBorder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "leftBorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ligatures");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ligatures"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("merge");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "merge"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("missingFont");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "missingFont"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nonBreaking");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "nonBreaking"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTAllSmallCaps");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTAllSmallCaps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTAltVerticalMetrics");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTAltVerticalMetrics"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTAlternateFormsNone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTAlternateFormsNone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTAlternateHalfMetrics");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTAlternateHalfMetrics"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTAlternateWidthsNone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTAlternateWidthsNone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTContextualAlternatives");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTContextualAlternatives"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTDenominator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTDenominator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTDiscretionaryLigatures");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTDiscretionaryLigatures"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTFeature");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTFeature"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTFractions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTFractions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTFullWidths");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTFullWidths"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTHVKanaAlternatives");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTHVKanaAlternatives"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTHalfWidths");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTHalfWidths"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTItalicsFeature");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTItalicsFeature"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTJIS04Forms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTJIS04Forms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTJIS78Forms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTJIS78Forms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTJIS83Forms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTJIS83Forms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTJIS90Forms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTJIS90Forms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTLiningFigures");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTLiningFigures"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTLocalizedForms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTLocalizedForms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTNumerator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTNumerator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTOldStyleFigures");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTOldStyleFigures"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTOrdinals");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTOrdinals"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTPositionNone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTPositionNone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTProportionalAltVerticalMetrics");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTProportionalAltVerticalMetrics"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTProportionalFigures");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTProportionalFigures"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTProportionalWidths");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTProportionalWidths"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTQuarterWidths");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTQuarterWidths"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTRubiNotationForms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTRubiNotationForms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTScientificInferiorFeature");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTScientificInferiorFeature"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTSimplifiedForms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTSimplifiedForms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTSmallCaps");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTSmallCaps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTStandardLigatures");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTStandardLigatures"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTSubscript");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTSubscript"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTSuperscript");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTSuperscript"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTSwashes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTSwashes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTTabularFigures");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTTabularFigures"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTThirdWidths");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTThirdWidths"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTTitlingAlternates");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTTitlingAlternates"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTTraditionalForms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTTraditionalForms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OTVariant");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OTVariant"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outline");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "outline"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PSFontName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PSFontName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageNumberChar");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pageNumberChar"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("plain");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "plain"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightBorder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rightBorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("script");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "script"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sending");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "sending"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shadingStyleName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shadingStyleName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shadow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("size");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "size"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("smallCaps");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "smallCaps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("strikeThru");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "strikeThru"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subScript");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "subScript"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("superScript");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "superScript"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("superior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "superior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topBorder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "topBorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trackAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "trackAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("underline");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "underline"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("unencodedGlyphId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "unencodedGlyphId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verticalScale");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "verticalScale"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wordUnderline");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "wordUnderline"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xrefLabel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "xrefLabel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
