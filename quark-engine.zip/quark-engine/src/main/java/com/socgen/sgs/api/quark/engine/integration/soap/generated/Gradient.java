/**
 * Gradient.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Gradient  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String angle;

    private java.lang.String aspectRatio;

    private java.lang.String overPrint;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Stop stop;

    private java.lang.String type;

    public Gradient() {
    }

    public Gradient(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String angle,
           java.lang.String aspectRatio,
           java.lang.String overPrint,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Stop stop,
           java.lang.String type) {
        super(
            request);
        this.angle = angle;
        this.aspectRatio = aspectRatio;
        this.overPrint = overPrint;
        this.stop = stop;
        this.type = type;
    }


    /**
     * Gets the angle value for this Gradient.
     * 
     * @return angle
     */
    public java.lang.String getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this Gradient.
     * 
     * @param angle
     */
    public void setAngle(java.lang.String angle) {
        this.angle = angle;
    }


    /**
     * Gets the aspectRatio value for this Gradient.
     * 
     * @return aspectRatio
     */
    public java.lang.String getAspectRatio() {
        return aspectRatio;
    }


    /**
     * Sets the aspectRatio value for this Gradient.
     * 
     * @param aspectRatio
     */
    public void setAspectRatio(java.lang.String aspectRatio) {
        this.aspectRatio = aspectRatio;
    }


    /**
     * Gets the overPrint value for this Gradient.
     * 
     * @return overPrint
     */
    public java.lang.String getOverPrint() {
        return overPrint;
    }


    /**
     * Sets the overPrint value for this Gradient.
     * 
     * @param overPrint
     */
    public void setOverPrint(java.lang.String overPrint) {
        this.overPrint = overPrint;
    }


    /**
     * Gets the stop value for this Gradient.
     * 
     * @return stop
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Stop getStop() {
        return stop;
    }


    /**
     * Sets the stop value for this Gradient.
     * 
     * @param stop
     */
    public void setStop(com.socgen.sgs.api.quark.engine.integration.soap.generated.Stop stop) {
        this.stop = stop;
    }


    /**
     * Gets the type value for this Gradient.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this Gradient.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Gradient)) return false;
        Gradient other = (Gradient) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.angle==null && other.getAngle()==null) || 
             (this.angle!=null &&
              this.angle.equals(other.getAngle()))) &&
            ((this.aspectRatio==null && other.getAspectRatio()==null) || 
             (this.aspectRatio!=null &&
              this.aspectRatio.equals(other.getAspectRatio()))) &&
            ((this.overPrint==null && other.getOverPrint()==null) || 
             (this.overPrint!=null &&
              this.overPrint.equals(other.getOverPrint()))) &&
            ((this.stop==null && other.getStop()==null) || 
             (this.stop!=null &&
              this.stop.equals(other.getStop()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAngle() != null) {
            _hashCode += getAngle().hashCode();
        }
        if (getAspectRatio() != null) {
            _hashCode += getAspectRatio().hashCode();
        }
        if (getOverPrint() != null) {
            _hashCode += getOverPrint().hashCode();
        }
        if (getStop() != null) {
            _hashCode += getStop().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Gradient.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Gradient"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("angle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "angle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aspectRatio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "aspectRatio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overPrint");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "overPrint"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stop");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "stop"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Stop"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
