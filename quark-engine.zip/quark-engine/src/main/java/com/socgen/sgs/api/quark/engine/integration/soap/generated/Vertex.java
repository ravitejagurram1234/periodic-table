/**
 * Vertex.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Vertex  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String cuspVertex;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftControlPoint leftControlPoint;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RightControlPoint rightControlPoint;

    private java.lang.String smoothVertex;

    private java.lang.String straightEdge;

    private java.lang.String symmVertex;

    private java.lang.String twisted;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.VertexPoint vertexPoint;

    private java.lang.String vertexSelected;

    public Vertex() {
    }

    public Vertex(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String cuspVertex,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftControlPoint leftControlPoint,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RightControlPoint rightControlPoint,
           java.lang.String smoothVertex,
           java.lang.String straightEdge,
           java.lang.String symmVertex,
           java.lang.String twisted,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.VertexPoint vertexPoint,
           java.lang.String vertexSelected) {
        super(
            request);
        this.cuspVertex = cuspVertex;
        this.leftControlPoint = leftControlPoint;
        this.rightControlPoint = rightControlPoint;
        this.smoothVertex = smoothVertex;
        this.straightEdge = straightEdge;
        this.symmVertex = symmVertex;
        this.twisted = twisted;
        this.vertexPoint = vertexPoint;
        this.vertexSelected = vertexSelected;
    }


    /**
     * Gets the cuspVertex value for this Vertex.
     * 
     * @return cuspVertex
     */
    public java.lang.String getCuspVertex() {
        return cuspVertex;
    }


    /**
     * Sets the cuspVertex value for this Vertex.
     * 
     * @param cuspVertex
     */
    public void setCuspVertex(java.lang.String cuspVertex) {
        this.cuspVertex = cuspVertex;
    }


    /**
     * Gets the leftControlPoint value for this Vertex.
     * 
     * @return leftControlPoint
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftControlPoint getLeftControlPoint() {
        return leftControlPoint;
    }


    /**
     * Sets the leftControlPoint value for this Vertex.
     * 
     * @param leftControlPoint
     */
    public void setLeftControlPoint(com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftControlPoint leftControlPoint) {
        this.leftControlPoint = leftControlPoint;
    }


    /**
     * Gets the rightControlPoint value for this Vertex.
     * 
     * @return rightControlPoint
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RightControlPoint getRightControlPoint() {
        return rightControlPoint;
    }


    /**
     * Sets the rightControlPoint value for this Vertex.
     * 
     * @param rightControlPoint
     */
    public void setRightControlPoint(com.socgen.sgs.api.quark.engine.integration.soap.generated.RightControlPoint rightControlPoint) {
        this.rightControlPoint = rightControlPoint;
    }


    /**
     * Gets the smoothVertex value for this Vertex.
     * 
     * @return smoothVertex
     */
    public java.lang.String getSmoothVertex() {
        return smoothVertex;
    }


    /**
     * Sets the smoothVertex value for this Vertex.
     * 
     * @param smoothVertex
     */
    public void setSmoothVertex(java.lang.String smoothVertex) {
        this.smoothVertex = smoothVertex;
    }


    /**
     * Gets the straightEdge value for this Vertex.
     * 
     * @return straightEdge
     */
    public java.lang.String getStraightEdge() {
        return straightEdge;
    }


    /**
     * Sets the straightEdge value for this Vertex.
     * 
     * @param straightEdge
     */
    public void setStraightEdge(java.lang.String straightEdge) {
        this.straightEdge = straightEdge;
    }


    /**
     * Gets the symmVertex value for this Vertex.
     * 
     * @return symmVertex
     */
    public java.lang.String getSymmVertex() {
        return symmVertex;
    }


    /**
     * Sets the symmVertex value for this Vertex.
     * 
     * @param symmVertex
     */
    public void setSymmVertex(java.lang.String symmVertex) {
        this.symmVertex = symmVertex;
    }


    /**
     * Gets the twisted value for this Vertex.
     * 
     * @return twisted
     */
    public java.lang.String getTwisted() {
        return twisted;
    }


    /**
     * Sets the twisted value for this Vertex.
     * 
     * @param twisted
     */
    public void setTwisted(java.lang.String twisted) {
        this.twisted = twisted;
    }


    /**
     * Gets the vertexPoint value for this Vertex.
     * 
     * @return vertexPoint
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.VertexPoint getVertexPoint() {
        return vertexPoint;
    }


    /**
     * Sets the vertexPoint value for this Vertex.
     * 
     * @param vertexPoint
     */
    public void setVertexPoint(com.socgen.sgs.api.quark.engine.integration.soap.generated.VertexPoint vertexPoint) {
        this.vertexPoint = vertexPoint;
    }


    /**
     * Gets the vertexSelected value for this Vertex.
     * 
     * @return vertexSelected
     */
    public java.lang.String getVertexSelected() {
        return vertexSelected;
    }


    /**
     * Sets the vertexSelected value for this Vertex.
     * 
     * @param vertexSelected
     */
    public void setVertexSelected(java.lang.String vertexSelected) {
        this.vertexSelected = vertexSelected;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Vertex)) return false;
        Vertex other = (Vertex) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.cuspVertex==null && other.getCuspVertex()==null) || 
             (this.cuspVertex!=null &&
              this.cuspVertex.equals(other.getCuspVertex()))) &&
            ((this.leftControlPoint==null && other.getLeftControlPoint()==null) || 
             (this.leftControlPoint!=null &&
              this.leftControlPoint.equals(other.getLeftControlPoint()))) &&
            ((this.rightControlPoint==null && other.getRightControlPoint()==null) || 
             (this.rightControlPoint!=null &&
              this.rightControlPoint.equals(other.getRightControlPoint()))) &&
            ((this.smoothVertex==null && other.getSmoothVertex()==null) || 
             (this.smoothVertex!=null &&
              this.smoothVertex.equals(other.getSmoothVertex()))) &&
            ((this.straightEdge==null && other.getStraightEdge()==null) || 
             (this.straightEdge!=null &&
              this.straightEdge.equals(other.getStraightEdge()))) &&
            ((this.symmVertex==null && other.getSymmVertex()==null) || 
             (this.symmVertex!=null &&
              this.symmVertex.equals(other.getSymmVertex()))) &&
            ((this.twisted==null && other.getTwisted()==null) || 
             (this.twisted!=null &&
              this.twisted.equals(other.getTwisted()))) &&
            ((this.vertexPoint==null && other.getVertexPoint()==null) || 
             (this.vertexPoint!=null &&
              this.vertexPoint.equals(other.getVertexPoint()))) &&
            ((this.vertexSelected==null && other.getVertexSelected()==null) || 
             (this.vertexSelected!=null &&
              this.vertexSelected.equals(other.getVertexSelected())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCuspVertex() != null) {
            _hashCode += getCuspVertex().hashCode();
        }
        if (getLeftControlPoint() != null) {
            _hashCode += getLeftControlPoint().hashCode();
        }
        if (getRightControlPoint() != null) {
            _hashCode += getRightControlPoint().hashCode();
        }
        if (getSmoothVertex() != null) {
            _hashCode += getSmoothVertex().hashCode();
        }
        if (getStraightEdge() != null) {
            _hashCode += getStraightEdge().hashCode();
        }
        if (getSymmVertex() != null) {
            _hashCode += getSymmVertex().hashCode();
        }
        if (getTwisted() != null) {
            _hashCode += getTwisted().hashCode();
        }
        if (getVertexPoint() != null) {
            _hashCode += getVertexPoint().hashCode();
        }
        if (getVertexSelected() != null) {
            _hashCode += getVertexSelected().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Vertex.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Vertex"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cuspVertex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "cuspVertex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftControlPoint");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "leftControlPoint"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LeftControlPoint"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightControlPoint");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rightControlPoint"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RightControlPoint"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("smoothVertex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "smoothVertex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("straightEdge");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "straightEdge"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("symmVertex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "symmVertex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("twisted");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "twisted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vertexPoint");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "vertexPoint"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "VertexPoint"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vertexSelected");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "vertexSelected"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
