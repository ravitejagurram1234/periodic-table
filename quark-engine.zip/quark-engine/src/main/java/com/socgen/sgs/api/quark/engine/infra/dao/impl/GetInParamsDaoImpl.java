package com.socgen.sgs.api.quark.engine.infra.dao.impl;
import com.socgen.sgs.api.quark.engine.domain.InParam;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.infra.dao.GetInParamsDao;
import com.socgen.sgs.api.quark.engine.mapper.InParamMapper;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;
/**
 * Calls Oracle function QXP_PK_RUN.Get_In_Params and populates run.inParams.
 */
@Repository
@Slf4j
public class GetInParamsDaoImpl implements GetInParamsDao {
    private static final String RESULT_KEY = "result_cursor";
    private final SimpleJdbcCall getInParamsCall;
    @Autowired
    public GetInParamsDaoImpl(DataSource dataSource, InParamMapper inParamMapper) {
        this.getInParamsCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_In_Params")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR,
                                (rs, rowNum) -> inParamMapper.mapFromResultSet(rs)),
                        new SqlParameter("p_id_suivi", Types.NUMERIC)
                );
    }
    @Override
    public void getInParams(Run run) {
        log.info("Fetching in-params for idSuivi: {}", run.getRunProperties().getIdSuivi());
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_suivi", run.getRunProperties().getIdSuivi());
        try {
            Map<String, Object> result = getInParamsCall.execute(params);
            log.debug("Result map keys: {}, values: {}", result.keySet(), result);
            @SuppressWarnings("unchecked")
            List<InParam> rows = (List<InParam>) result.get(RESULT_KEY);
            run.getInParams().clear();
            if (rows != null) {
                rows.forEach(inParam -> run.getInParams().put(inParam.getName(), inParam));
            }
            log.info("Loaded {} in-params for idSuivi: {}",
                    run.getInParams().size(), run.getRunProperties().getIdSuivi());
        } catch (Exception e) {
            log.error("Error fetching in-params for idSuivi: {}", run.getRunProperties().getIdSuivi(), e);
            throw new RuntimeException("Failed to fetch in-params for idSuivi: "
                    + run.getRunProperties().getIdSuivi(), e);
        }
    }
}
