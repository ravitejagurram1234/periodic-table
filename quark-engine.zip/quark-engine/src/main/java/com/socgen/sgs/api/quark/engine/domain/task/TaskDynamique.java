package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DBreakRules;
import com.socgen.sgs.api.quark.engine.domain.port.FilePoolPort;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Represents a dynamic task that adds blocs/tables/pages to a QuarkXPress document. */
@Getter
@Setter
public class TaskDynamique extends TaskAnchor {

    private String sql;
    private DBreakRules pageBreakRules = DBreakRules.DEFAULT;
    private DBreakRules columnBreakRules = DBreakRules.DEFAULT;
    private boolean controlOverflow = false;
    private boolean storeData = false;
    private boolean newPageTable = false;
    private int nbColumn = 1;
    private BigDecimal columnSpace = BigDecimal.ZERO;

    private final List<String> boxNames = new ArrayList<>();
    private final List<String> overflowBoxes = new ArrayList<>();

    private FilePoolPort filePoolService;

    public TaskDynamique(int id, Run run) {
        super(id, run);
    }

    @Override
    public void prepare() {
        if (this.isTodo() && filePoolService != null) {
            // Upload the gabarit TEMPLATE (not the source gabarit) into the QXPS pool.
            // Parity: .NET Task_Dynamique.Prepare → Addfile(this.Run.Gabarit_Template.FilePoolPath,
            // this.Run.Gabarit_Template.Data). Finding #22.
            DocumentDomain gabaritTemplate = this.getRun().getGabaritTemplate();
            if (gabaritTemplate == null) {
                // .NET raises MSG_Gabarit_Template_NULL; fail loudly rather than NPE / silently
                // uploading the wrong document.
                throw new IllegalStateException(
                        "Gabarit_Template is null for dynamic task " + this.getId()
                                + " in run " + this.getRun().getId()
                                + " — id_gabarit_template must be set and loaded before prepare()");
            }
            filePoolService.addFile(gabaritTemplate.getFilePoolPath(), gabaritTemplate.getData());
        }
    }


    public void setNbColumn(int value) {
        if (value > 0) {
            this.nbColumn = value;
        }
    }

    public void setColumnSpace(BigDecimal value) {
        if (value != null && value.compareTo(BigDecimal.ZERO) > 0) {
            this.columnSpace = value;
        }
    }
}