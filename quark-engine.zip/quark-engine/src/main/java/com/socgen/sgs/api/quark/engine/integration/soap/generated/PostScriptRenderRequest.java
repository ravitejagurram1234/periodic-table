/**
 * PostScriptRenderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class PostScriptRenderRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String afterPage;

    private java.lang.String layout;

    private java.lang.String movePages;

    private java.lang.String outputStyle;

    private java.lang.String page;

    private java.lang.String pages;

    private java.lang.String pasteboard;

    private java.lang.String printBleed;

    private java.lang.String printSpreads;

    private java.lang.String spread;

    private java.lang.String updateFullRes;

    private java.lang.String updateImage;

    public PostScriptRenderRequest() {
    }

    public PostScriptRenderRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String afterPage,
           java.lang.String layout,
           java.lang.String movePages,
           java.lang.String outputStyle,
           java.lang.String page,
           java.lang.String pages,
           java.lang.String pasteboard,
           java.lang.String printBleed,
           java.lang.String printSpreads,
           java.lang.String spread,
           java.lang.String updateFullRes,
           java.lang.String updateImage) {
        super(
            request);
        this.afterPage = afterPage;
        this.layout = layout;
        this.movePages = movePages;
        this.outputStyle = outputStyle;
        this.page = page;
        this.pages = pages;
        this.pasteboard = pasteboard;
        this.printBleed = printBleed;
        this.printSpreads = printSpreads;
        this.spread = spread;
        this.updateFullRes = updateFullRes;
        this.updateImage = updateImage;
    }


    /**
     * Gets the afterPage value for this PostScriptRenderRequest.
     * 
     * @return afterPage
     */
    public java.lang.String getAfterPage() {
        return afterPage;
    }


    /**
     * Sets the afterPage value for this PostScriptRenderRequest.
     * 
     * @param afterPage
     */
    public void setAfterPage(java.lang.String afterPage) {
        this.afterPage = afterPage;
    }


    /**
     * Gets the layout value for this PostScriptRenderRequest.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this PostScriptRenderRequest.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the movePages value for this PostScriptRenderRequest.
     * 
     * @return movePages
     */
    public java.lang.String getMovePages() {
        return movePages;
    }


    /**
     * Sets the movePages value for this PostScriptRenderRequest.
     * 
     * @param movePages
     */
    public void setMovePages(java.lang.String movePages) {
        this.movePages = movePages;
    }


    /**
     * Gets the outputStyle value for this PostScriptRenderRequest.
     * 
     * @return outputStyle
     */
    public java.lang.String getOutputStyle() {
        return outputStyle;
    }


    /**
     * Sets the outputStyle value for this PostScriptRenderRequest.
     * 
     * @param outputStyle
     */
    public void setOutputStyle(java.lang.String outputStyle) {
        this.outputStyle = outputStyle;
    }


    /**
     * Gets the page value for this PostScriptRenderRequest.
     * 
     * @return page
     */
    public java.lang.String getPage() {
        return page;
    }


    /**
     * Sets the page value for this PostScriptRenderRequest.
     * 
     * @param page
     */
    public void setPage(java.lang.String page) {
        this.page = page;
    }


    /**
     * Gets the pages value for this PostScriptRenderRequest.
     * 
     * @return pages
     */
    public java.lang.String getPages() {
        return pages;
    }


    /**
     * Sets the pages value for this PostScriptRenderRequest.
     * 
     * @param pages
     */
    public void setPages(java.lang.String pages) {
        this.pages = pages;
    }


    /**
     * Gets the pasteboard value for this PostScriptRenderRequest.
     * 
     * @return pasteboard
     */
    public java.lang.String getPasteboard() {
        return pasteboard;
    }


    /**
     * Sets the pasteboard value for this PostScriptRenderRequest.
     * 
     * @param pasteboard
     */
    public void setPasteboard(java.lang.String pasteboard) {
        this.pasteboard = pasteboard;
    }


    /**
     * Gets the printBleed value for this PostScriptRenderRequest.
     * 
     * @return printBleed
     */
    public java.lang.String getPrintBleed() {
        return printBleed;
    }


    /**
     * Sets the printBleed value for this PostScriptRenderRequest.
     * 
     * @param printBleed
     */
    public void setPrintBleed(java.lang.String printBleed) {
        this.printBleed = printBleed;
    }


    /**
     * Gets the printSpreads value for this PostScriptRenderRequest.
     * 
     * @return printSpreads
     */
    public java.lang.String getPrintSpreads() {
        return printSpreads;
    }


    /**
     * Sets the printSpreads value for this PostScriptRenderRequest.
     * 
     * @param printSpreads
     */
    public void setPrintSpreads(java.lang.String printSpreads) {
        this.printSpreads = printSpreads;
    }


    /**
     * Gets the spread value for this PostScriptRenderRequest.
     * 
     * @return spread
     */
    public java.lang.String getSpread() {
        return spread;
    }


    /**
     * Sets the spread value for this PostScriptRenderRequest.
     * 
     * @param spread
     */
    public void setSpread(java.lang.String spread) {
        this.spread = spread;
    }


    /**
     * Gets the updateFullRes value for this PostScriptRenderRequest.
     * 
     * @return updateFullRes
     */
    public java.lang.String getUpdateFullRes() {
        return updateFullRes;
    }


    /**
     * Sets the updateFullRes value for this PostScriptRenderRequest.
     * 
     * @param updateFullRes
     */
    public void setUpdateFullRes(java.lang.String updateFullRes) {
        this.updateFullRes = updateFullRes;
    }


    /**
     * Gets the updateImage value for this PostScriptRenderRequest.
     * 
     * @return updateImage
     */
    public java.lang.String getUpdateImage() {
        return updateImage;
    }


    /**
     * Sets the updateImage value for this PostScriptRenderRequest.
     * 
     * @param updateImage
     */
    public void setUpdateImage(java.lang.String updateImage) {
        this.updateImage = updateImage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PostScriptRenderRequest)) return false;
        PostScriptRenderRequest other = (PostScriptRenderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.afterPage==null && other.getAfterPage()==null) || 
             (this.afterPage!=null &&
              this.afterPage.equals(other.getAfterPage()))) &&
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.movePages==null && other.getMovePages()==null) || 
             (this.movePages!=null &&
              this.movePages.equals(other.getMovePages()))) &&
            ((this.outputStyle==null && other.getOutputStyle()==null) || 
             (this.outputStyle!=null &&
              this.outputStyle.equals(other.getOutputStyle()))) &&
            ((this.page==null && other.getPage()==null) || 
             (this.page!=null &&
              this.page.equals(other.getPage()))) &&
            ((this.pages==null && other.getPages()==null) || 
             (this.pages!=null &&
              this.pages.equals(other.getPages()))) &&
            ((this.pasteboard==null && other.getPasteboard()==null) || 
             (this.pasteboard!=null &&
              this.pasteboard.equals(other.getPasteboard()))) &&
            ((this.printBleed==null && other.getPrintBleed()==null) || 
             (this.printBleed!=null &&
              this.printBleed.equals(other.getPrintBleed()))) &&
            ((this.printSpreads==null && other.getPrintSpreads()==null) || 
             (this.printSpreads!=null &&
              this.printSpreads.equals(other.getPrintSpreads()))) &&
            ((this.spread==null && other.getSpread()==null) || 
             (this.spread!=null &&
              this.spread.equals(other.getSpread()))) &&
            ((this.updateFullRes==null && other.getUpdateFullRes()==null) || 
             (this.updateFullRes!=null &&
              this.updateFullRes.equals(other.getUpdateFullRes()))) &&
            ((this.updateImage==null && other.getUpdateImage()==null) || 
             (this.updateImage!=null &&
              this.updateImage.equals(other.getUpdateImage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAfterPage() != null) {
            _hashCode += getAfterPage().hashCode();
        }
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getMovePages() != null) {
            _hashCode += getMovePages().hashCode();
        }
        if (getOutputStyle() != null) {
            _hashCode += getOutputStyle().hashCode();
        }
        if (getPage() != null) {
            _hashCode += getPage().hashCode();
        }
        if (getPages() != null) {
            _hashCode += getPages().hashCode();
        }
        if (getPasteboard() != null) {
            _hashCode += getPasteboard().hashCode();
        }
        if (getPrintBleed() != null) {
            _hashCode += getPrintBleed().hashCode();
        }
        if (getPrintSpreads() != null) {
            _hashCode += getPrintSpreads().hashCode();
        }
        if (getSpread() != null) {
            _hashCode += getSpread().hashCode();
        }
        if (getUpdateFullRes() != null) {
            _hashCode += getUpdateFullRes().hashCode();
        }
        if (getUpdateImage() != null) {
            _hashCode += getUpdateImage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PostScriptRenderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "PostScriptRenderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("afterPage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "afterPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("movePages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "movePages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "outputStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("page");
        elemField.setXmlName(new javax.xml.namespace.QName("", "page"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pasteboard");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pasteboard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("printBleed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "printBleed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("printSpreads");
        elemField.setXmlName(new javax.xml.namespace.QName("", "printSpreads"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spread");
        elemField.setXmlName(new javax.xml.namespace.QName("", "spread"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateFullRes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateFullRes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateImage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateImage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
