/**
 * CalloutAnchor.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class CalloutAnchor  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignHorSettings alignHorSettings;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignVerSettings alignVerSettings;

    private java.lang.String allowManualPos;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutBoxRef calloutBoxRef;

    private java.lang.String calloutStyle;

    private java.lang.String horizontalPadding;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox inlineBox;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem inlineItem;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable inlineTable;

    private java.lang.String keepOnSamePage;

    private java.lang.String keepWithinMargins;

    private java.lang.String operation;

    private java.lang.String UID;

    private java.lang.String verticalPadding;

    public CalloutAnchor() {
    }

    public CalloutAnchor(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignHorSettings alignHorSettings,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignVerSettings alignVerSettings,
           java.lang.String allowManualPos,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutBoxRef calloutBoxRef,
           java.lang.String calloutStyle,
           java.lang.String horizontalPadding,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox inlineBox,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem inlineItem,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable inlineTable,
           java.lang.String keepOnSamePage,
           java.lang.String keepWithinMargins,
           java.lang.String operation,
           java.lang.String UID,
           java.lang.String verticalPadding) {
        super(
            request);
        this.alignHorSettings = alignHorSettings;
        this.alignVerSettings = alignVerSettings;
        this.allowManualPos = allowManualPos;
        this.calloutBoxRef = calloutBoxRef;
        this.calloutStyle = calloutStyle;
        this.horizontalPadding = horizontalPadding;
        this.index = index;
        this.inlineBox = inlineBox;
        this.inlineItem = inlineItem;
        this.inlineTable = inlineTable;
        this.keepOnSamePage = keepOnSamePage;
        this.keepWithinMargins = keepWithinMargins;
        this.operation = operation;
        this.UID = UID;
        this.verticalPadding = verticalPadding;
    }


    /**
     * Gets the alignHorSettings value for this CalloutAnchor.
     * 
     * @return alignHorSettings
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignHorSettings getAlignHorSettings() {
        return alignHorSettings;
    }


    /**
     * Sets the alignHorSettings value for this CalloutAnchor.
     * 
     * @param alignHorSettings
     */
    public void setAlignHorSettings(com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignHorSettings alignHorSettings) {
        this.alignHorSettings = alignHorSettings;
    }


    /**
     * Gets the alignVerSettings value for this CalloutAnchor.
     * 
     * @return alignVerSettings
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignVerSettings getAlignVerSettings() {
        return alignVerSettings;
    }


    /**
     * Sets the alignVerSettings value for this CalloutAnchor.
     * 
     * @param alignVerSettings
     */
    public void setAlignVerSettings(com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignVerSettings alignVerSettings) {
        this.alignVerSettings = alignVerSettings;
    }


    /**
     * Gets the allowManualPos value for this CalloutAnchor.
     * 
     * @return allowManualPos
     */
    public java.lang.String getAllowManualPos() {
        return allowManualPos;
    }


    /**
     * Sets the allowManualPos value for this CalloutAnchor.
     * 
     * @param allowManualPos
     */
    public void setAllowManualPos(java.lang.String allowManualPos) {
        this.allowManualPos = allowManualPos;
    }


    /**
     * Gets the calloutBoxRef value for this CalloutAnchor.
     * 
     * @return calloutBoxRef
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutBoxRef getCalloutBoxRef() {
        return calloutBoxRef;
    }


    /**
     * Sets the calloutBoxRef value for this CalloutAnchor.
     * 
     * @param calloutBoxRef
     */
    public void setCalloutBoxRef(com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutBoxRef calloutBoxRef) {
        this.calloutBoxRef = calloutBoxRef;
    }


    /**
     * Gets the calloutStyle value for this CalloutAnchor.
     * 
     * @return calloutStyle
     */
    public java.lang.String getCalloutStyle() {
        return calloutStyle;
    }


    /**
     * Sets the calloutStyle value for this CalloutAnchor.
     * 
     * @param calloutStyle
     */
    public void setCalloutStyle(java.lang.String calloutStyle) {
        this.calloutStyle = calloutStyle;
    }


    /**
     * Gets the horizontalPadding value for this CalloutAnchor.
     * 
     * @return horizontalPadding
     */
    public java.lang.String getHorizontalPadding() {
        return horizontalPadding;
    }


    /**
     * Sets the horizontalPadding value for this CalloutAnchor.
     * 
     * @param horizontalPadding
     */
    public void setHorizontalPadding(java.lang.String horizontalPadding) {
        this.horizontalPadding = horizontalPadding;
    }


    /**
     * Gets the index value for this CalloutAnchor.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this CalloutAnchor.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the inlineBox value for this CalloutAnchor.
     * 
     * @return inlineBox
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox getInlineBox() {
        return inlineBox;
    }


    /**
     * Sets the inlineBox value for this CalloutAnchor.
     * 
     * @param inlineBox
     */
    public void setInlineBox(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox inlineBox) {
        this.inlineBox = inlineBox;
    }


    /**
     * Gets the inlineItem value for this CalloutAnchor.
     * 
     * @return inlineItem
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem getInlineItem() {
        return inlineItem;
    }


    /**
     * Sets the inlineItem value for this CalloutAnchor.
     * 
     * @param inlineItem
     */
    public void setInlineItem(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem inlineItem) {
        this.inlineItem = inlineItem;
    }


    /**
     * Gets the inlineTable value for this CalloutAnchor.
     * 
     * @return inlineTable
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable getInlineTable() {
        return inlineTable;
    }


    /**
     * Sets the inlineTable value for this CalloutAnchor.
     * 
     * @param inlineTable
     */
    public void setInlineTable(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable inlineTable) {
        this.inlineTable = inlineTable;
    }


    /**
     * Gets the keepOnSamePage value for this CalloutAnchor.
     * 
     * @return keepOnSamePage
     */
    public java.lang.String getKeepOnSamePage() {
        return keepOnSamePage;
    }


    /**
     * Sets the keepOnSamePage value for this CalloutAnchor.
     * 
     * @param keepOnSamePage
     */
    public void setKeepOnSamePage(java.lang.String keepOnSamePage) {
        this.keepOnSamePage = keepOnSamePage;
    }


    /**
     * Gets the keepWithinMargins value for this CalloutAnchor.
     * 
     * @return keepWithinMargins
     */
    public java.lang.String getKeepWithinMargins() {
        return keepWithinMargins;
    }


    /**
     * Sets the keepWithinMargins value for this CalloutAnchor.
     * 
     * @param keepWithinMargins
     */
    public void setKeepWithinMargins(java.lang.String keepWithinMargins) {
        this.keepWithinMargins = keepWithinMargins;
    }


    /**
     * Gets the operation value for this CalloutAnchor.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this CalloutAnchor.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the UID value for this CalloutAnchor.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this CalloutAnchor.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the verticalPadding value for this CalloutAnchor.
     * 
     * @return verticalPadding
     */
    public java.lang.String getVerticalPadding() {
        return verticalPadding;
    }


    /**
     * Sets the verticalPadding value for this CalloutAnchor.
     * 
     * @param verticalPadding
     */
    public void setVerticalPadding(java.lang.String verticalPadding) {
        this.verticalPadding = verticalPadding;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CalloutAnchor)) return false;
        CalloutAnchor other = (CalloutAnchor) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignHorSettings==null && other.getAlignHorSettings()==null) || 
             (this.alignHorSettings!=null &&
              this.alignHorSettings.equals(other.getAlignHorSettings()))) &&
            ((this.alignVerSettings==null && other.getAlignVerSettings()==null) || 
             (this.alignVerSettings!=null &&
              this.alignVerSettings.equals(other.getAlignVerSettings()))) &&
            ((this.allowManualPos==null && other.getAllowManualPos()==null) || 
             (this.allowManualPos!=null &&
              this.allowManualPos.equals(other.getAllowManualPos()))) &&
            ((this.calloutBoxRef==null && other.getCalloutBoxRef()==null) || 
             (this.calloutBoxRef!=null &&
              this.calloutBoxRef.equals(other.getCalloutBoxRef()))) &&
            ((this.calloutStyle==null && other.getCalloutStyle()==null) || 
             (this.calloutStyle!=null &&
              this.calloutStyle.equals(other.getCalloutStyle()))) &&
            ((this.horizontalPadding==null && other.getHorizontalPadding()==null) || 
             (this.horizontalPadding!=null &&
              this.horizontalPadding.equals(other.getHorizontalPadding()))) &&
            this.index == other.getIndex() &&
            ((this.inlineBox==null && other.getInlineBox()==null) || 
             (this.inlineBox!=null &&
              this.inlineBox.equals(other.getInlineBox()))) &&
            ((this.inlineItem==null && other.getInlineItem()==null) || 
             (this.inlineItem!=null &&
              this.inlineItem.equals(other.getInlineItem()))) &&
            ((this.inlineTable==null && other.getInlineTable()==null) || 
             (this.inlineTable!=null &&
              this.inlineTable.equals(other.getInlineTable()))) &&
            ((this.keepOnSamePage==null && other.getKeepOnSamePage()==null) || 
             (this.keepOnSamePage!=null &&
              this.keepOnSamePage.equals(other.getKeepOnSamePage()))) &&
            ((this.keepWithinMargins==null && other.getKeepWithinMargins()==null) || 
             (this.keepWithinMargins!=null &&
              this.keepWithinMargins.equals(other.getKeepWithinMargins()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.verticalPadding==null && other.getVerticalPadding()==null) || 
             (this.verticalPadding!=null &&
              this.verticalPadding.equals(other.getVerticalPadding())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignHorSettings() != null) {
            _hashCode += getAlignHorSettings().hashCode();
        }
        if (getAlignVerSettings() != null) {
            _hashCode += getAlignVerSettings().hashCode();
        }
        if (getAllowManualPos() != null) {
            _hashCode += getAllowManualPos().hashCode();
        }
        if (getCalloutBoxRef() != null) {
            _hashCode += getCalloutBoxRef().hashCode();
        }
        if (getCalloutStyle() != null) {
            _hashCode += getCalloutStyle().hashCode();
        }
        if (getHorizontalPadding() != null) {
            _hashCode += getHorizontalPadding().hashCode();
        }
        _hashCode += getIndex();
        if (getInlineBox() != null) {
            _hashCode += getInlineBox().hashCode();
        }
        if (getInlineItem() != null) {
            _hashCode += getInlineItem().hashCode();
        }
        if (getInlineTable() != null) {
            _hashCode += getInlineTable().hashCode();
        }
        if (getKeepOnSamePage() != null) {
            _hashCode += getKeepOnSamePage().hashCode();
        }
        if (getKeepWithinMargins() != null) {
            _hashCode += getKeepWithinMargins().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getVerticalPadding() != null) {
            _hashCode += getVerticalPadding().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CalloutAnchor.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CalloutAnchor"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignHorSettings");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignHorSettings"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AlignHorSettings"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignVerSettings");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignVerSettings"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AlignVerSettings"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowManualPos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "allowManualPos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("calloutBoxRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "calloutBoxRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CalloutBoxRef"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("calloutStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "calloutStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horizontalPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "horizontalPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineBox");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineBox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineBox"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineItem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineItem"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineTable");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineTable"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineTable"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keepOnSamePage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "keepOnSamePage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keepWithinMargins");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "keepWithinMargins"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verticalPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "verticalPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
