package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;

import java.util.List;
import java.util.Map;

public interface GetGabaritTemplateDao {

    DocumentDomain getGabaritTemplate(int idGabaritTemplate);

    List<Map<String, Object>> getTemplates(int idGabaritTemplate);
}

