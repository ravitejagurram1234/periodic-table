/**
 * Max.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Max  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Location location;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ScaleTo scaleTo;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Size size;

    public Max() {
    }

    public Max(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Location location,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ScaleTo scaleTo,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Size size) {
        super(
            request);
        this.location = location;
        this.scaleTo = scaleTo;
        this.size = size;
    }


    /**
     * Gets the location value for this Max.
     * 
     * @return location
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Location getLocation() {
        return location;
    }


    /**
     * Sets the location value for this Max.
     * 
     * @param location
     */
    public void setLocation(com.socgen.sgs.api.quark.engine.integration.soap.generated.Location location) {
        this.location = location;
    }


    /**
     * Gets the scaleTo value for this Max.
     * 
     * @return scaleTo
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ScaleTo getScaleTo() {
        return scaleTo;
    }


    /**
     * Sets the scaleTo value for this Max.
     * 
     * @param scaleTo
     */
    public void setScaleTo(com.socgen.sgs.api.quark.engine.integration.soap.generated.ScaleTo scaleTo) {
        this.scaleTo = scaleTo;
    }


    /**
     * Gets the size value for this Max.
     * 
     * @return size
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Size getSize() {
        return size;
    }


    /**
     * Sets the size value for this Max.
     * 
     * @param size
     */
    public void setSize(com.socgen.sgs.api.quark.engine.integration.soap.generated.Size size) {
        this.size = size;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Max)) return false;
        Max other = (Max) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.location==null && other.getLocation()==null) || 
             (this.location!=null &&
              this.location.equals(other.getLocation()))) &&
            ((this.scaleTo==null && other.getScaleTo()==null) || 
             (this.scaleTo!=null &&
              this.scaleTo.equals(other.getScaleTo()))) &&
            ((this.size==null && other.getSize()==null) || 
             (this.size!=null &&
              this.size.equals(other.getSize())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLocation() != null) {
            _hashCode += getLocation().hashCode();
        }
        if (getScaleTo() != null) {
            _hashCode += getScaleTo().hashCode();
        }
        if (getSize() != null) {
            _hashCode += getSize().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Max.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Max"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("location");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "location"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Location"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleTo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scaleTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ScaleTo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("size");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "size"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Size"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
