/**
 * MasterPageSequence.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class MasterPageSequence  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String name;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageAlternatives[] repeatableMasterPageAlternatives;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageReference[] repeatableMasterPageReferences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.SingleMasterPageReference[] singleMasterPageReferences;

    public MasterPageSequence() {
    }

    public MasterPageSequence(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String name,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageAlternatives[] repeatableMasterPageAlternatives,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageReference[] repeatableMasterPageReferences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.SingleMasterPageReference[] singleMasterPageReferences) {
        super(
            request);
        this.name = name;
        this.repeatableMasterPageAlternatives = repeatableMasterPageAlternatives;
        this.repeatableMasterPageReferences = repeatableMasterPageReferences;
        this.singleMasterPageReferences = singleMasterPageReferences;
    }


    /**
     * Gets the name value for this MasterPageSequence.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this MasterPageSequence.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the repeatableMasterPageAlternatives value for this MasterPageSequence.
     * 
     * @return repeatableMasterPageAlternatives
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageAlternatives[] getRepeatableMasterPageAlternatives() {
        return repeatableMasterPageAlternatives;
    }


    /**
     * Sets the repeatableMasterPageAlternatives value for this MasterPageSequence.
     * 
     * @param repeatableMasterPageAlternatives
     */
    public void setRepeatableMasterPageAlternatives(com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageAlternatives[] repeatableMasterPageAlternatives) {
        this.repeatableMasterPageAlternatives = repeatableMasterPageAlternatives;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageAlternatives getRepeatableMasterPageAlternatives(int i) {
        return this.repeatableMasterPageAlternatives[i];
    }

    public void setRepeatableMasterPageAlternatives(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageAlternatives _value) {
        this.repeatableMasterPageAlternatives[i] = _value;
    }


    /**
     * Gets the repeatableMasterPageReferences value for this MasterPageSequence.
     * 
     * @return repeatableMasterPageReferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageReference[] getRepeatableMasterPageReferences() {
        return repeatableMasterPageReferences;
    }


    /**
     * Sets the repeatableMasterPageReferences value for this MasterPageSequence.
     * 
     * @param repeatableMasterPageReferences
     */
    public void setRepeatableMasterPageReferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageReference[] repeatableMasterPageReferences) {
        this.repeatableMasterPageReferences = repeatableMasterPageReferences;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageReference getRepeatableMasterPageReferences(int i) {
        return this.repeatableMasterPageReferences[i];
    }

    public void setRepeatableMasterPageReferences(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageReference _value) {
        this.repeatableMasterPageReferences[i] = _value;
    }


    /**
     * Gets the singleMasterPageReferences value for this MasterPageSequence.
     * 
     * @return singleMasterPageReferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SingleMasterPageReference[] getSingleMasterPageReferences() {
        return singleMasterPageReferences;
    }


    /**
     * Sets the singleMasterPageReferences value for this MasterPageSequence.
     * 
     * @param singleMasterPageReferences
     */
    public void setSingleMasterPageReferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.SingleMasterPageReference[] singleMasterPageReferences) {
        this.singleMasterPageReferences = singleMasterPageReferences;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SingleMasterPageReference getSingleMasterPageReferences(int i) {
        return this.singleMasterPageReferences[i];
    }

    public void setSingleMasterPageReferences(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.SingleMasterPageReference _value) {
        this.singleMasterPageReferences[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MasterPageSequence)) return false;
        MasterPageSequence other = (MasterPageSequence) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.repeatableMasterPageAlternatives==null && other.getRepeatableMasterPageAlternatives()==null) || 
             (this.repeatableMasterPageAlternatives!=null &&
              java.util.Arrays.equals(this.repeatableMasterPageAlternatives, other.getRepeatableMasterPageAlternatives()))) &&
            ((this.repeatableMasterPageReferences==null && other.getRepeatableMasterPageReferences()==null) || 
             (this.repeatableMasterPageReferences!=null &&
              java.util.Arrays.equals(this.repeatableMasterPageReferences, other.getRepeatableMasterPageReferences()))) &&
            ((this.singleMasterPageReferences==null && other.getSingleMasterPageReferences()==null) || 
             (this.singleMasterPageReferences!=null &&
              java.util.Arrays.equals(this.singleMasterPageReferences, other.getSingleMasterPageReferences())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getRepeatableMasterPageAlternatives() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRepeatableMasterPageAlternatives());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRepeatableMasterPageAlternatives(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRepeatableMasterPageReferences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRepeatableMasterPageReferences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRepeatableMasterPageReferences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSingleMasterPageReferences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSingleMasterPageReferences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSingleMasterPageReferences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MasterPageSequence.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "MasterPageSequence"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("repeatableMasterPageAlternatives");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "repeatableMasterPageAlternatives"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RepeatableMasterPageAlternatives"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("repeatableMasterPageReferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "repeatableMasterPageReferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RepeatableMasterPageReference"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("singleMasterPageReferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "singleMasterPageReferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "SingleMasterPageReference"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
