/**
 * Group.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Group  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String addToReflow;

    private java.lang.String anchoredGroupMember;

    private java.lang.String anchoredIn;

    private java.lang.String articleName;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef[] boxRefs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry;

    private java.lang.String groupOpacity;

    private int index;

    private java.lang.String name;

    private java.lang.String operation;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow;

    private java.lang.String UID;

    public Group() {
    }

    public Group(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String addToReflow,
           java.lang.String anchoredGroupMember,
           java.lang.String anchoredIn,
           java.lang.String articleName,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef[] boxRefs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry,
           java.lang.String groupOpacity,
           int index,
           java.lang.String name,
           java.lang.String operation,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow,
           java.lang.String UID) {
        super(
            request);
        this.addToReflow = addToReflow;
        this.anchoredGroupMember = anchoredGroupMember;
        this.anchoredIn = anchoredIn;
        this.articleName = articleName;
        this.boxRefs = boxRefs;
        this.geometry = geometry;
        this.groupOpacity = groupOpacity;
        this.index = index;
        this.name = name;
        this.operation = operation;
        this.shadow = shadow;
        this.UID = UID;
    }


    /**
     * Gets the addToReflow value for this Group.
     * 
     * @return addToReflow
     */
    public java.lang.String getAddToReflow() {
        return addToReflow;
    }


    /**
     * Sets the addToReflow value for this Group.
     * 
     * @param addToReflow
     */
    public void setAddToReflow(java.lang.String addToReflow) {
        this.addToReflow = addToReflow;
    }


    /**
     * Gets the anchoredGroupMember value for this Group.
     * 
     * @return anchoredGroupMember
     */
    public java.lang.String getAnchoredGroupMember() {
        return anchoredGroupMember;
    }


    /**
     * Sets the anchoredGroupMember value for this Group.
     * 
     * @param anchoredGroupMember
     */
    public void setAnchoredGroupMember(java.lang.String anchoredGroupMember) {
        this.anchoredGroupMember = anchoredGroupMember;
    }


    /**
     * Gets the anchoredIn value for this Group.
     * 
     * @return anchoredIn
     */
    public java.lang.String getAnchoredIn() {
        return anchoredIn;
    }


    /**
     * Sets the anchoredIn value for this Group.
     * 
     * @param anchoredIn
     */
    public void setAnchoredIn(java.lang.String anchoredIn) {
        this.anchoredIn = anchoredIn;
    }


    /**
     * Gets the articleName value for this Group.
     * 
     * @return articleName
     */
    public java.lang.String getArticleName() {
        return articleName;
    }


    /**
     * Sets the articleName value for this Group.
     * 
     * @param articleName
     */
    public void setArticleName(java.lang.String articleName) {
        this.articleName = articleName;
    }


    /**
     * Gets the boxRefs value for this Group.
     * 
     * @return boxRefs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef[] getBoxRefs() {
        return boxRefs;
    }


    /**
     * Sets the boxRefs value for this Group.
     * 
     * @param boxRefs
     */
    public void setBoxRefs(com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef[] boxRefs) {
        this.boxRefs = boxRefs;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef getBoxRefs(int i) {
        return this.boxRefs[i];
    }

    public void setBoxRefs(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef _value) {
        this.boxRefs[i] = _value;
    }


    /**
     * Gets the geometry value for this Group.
     * 
     * @return geometry
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry getGeometry() {
        return geometry;
    }


    /**
     * Sets the geometry value for this Group.
     * 
     * @param geometry
     */
    public void setGeometry(com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry) {
        this.geometry = geometry;
    }


    /**
     * Gets the groupOpacity value for this Group.
     * 
     * @return groupOpacity
     */
    public java.lang.String getGroupOpacity() {
        return groupOpacity;
    }


    /**
     * Sets the groupOpacity value for this Group.
     * 
     * @param groupOpacity
     */
    public void setGroupOpacity(java.lang.String groupOpacity) {
        this.groupOpacity = groupOpacity;
    }


    /**
     * Gets the index value for this Group.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this Group.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the name value for this Group.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Group.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the operation value for this Group.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this Group.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the shadow value for this Group.
     * 
     * @return shadow
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow getShadow() {
        return shadow;
    }


    /**
     * Sets the shadow value for this Group.
     * 
     * @param shadow
     */
    public void setShadow(com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow) {
        this.shadow = shadow;
    }


    /**
     * Gets the UID value for this Group.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Group.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Group)) return false;
        Group other = (Group) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.addToReflow==null && other.getAddToReflow()==null) || 
             (this.addToReflow!=null &&
              this.addToReflow.equals(other.getAddToReflow()))) &&
            ((this.anchoredGroupMember==null && other.getAnchoredGroupMember()==null) || 
             (this.anchoredGroupMember!=null &&
              this.anchoredGroupMember.equals(other.getAnchoredGroupMember()))) &&
            ((this.anchoredIn==null && other.getAnchoredIn()==null) || 
             (this.anchoredIn!=null &&
              this.anchoredIn.equals(other.getAnchoredIn()))) &&
            ((this.articleName==null && other.getArticleName()==null) || 
             (this.articleName!=null &&
              this.articleName.equals(other.getArticleName()))) &&
            ((this.boxRefs==null && other.getBoxRefs()==null) || 
             (this.boxRefs!=null &&
              java.util.Arrays.equals(this.boxRefs, other.getBoxRefs()))) &&
            ((this.geometry==null && other.getGeometry()==null) || 
             (this.geometry!=null &&
              this.geometry.equals(other.getGeometry()))) &&
            ((this.groupOpacity==null && other.getGroupOpacity()==null) || 
             (this.groupOpacity!=null &&
              this.groupOpacity.equals(other.getGroupOpacity()))) &&
            this.index == other.getIndex() &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.shadow==null && other.getShadow()==null) || 
             (this.shadow!=null &&
              this.shadow.equals(other.getShadow()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAddToReflow() != null) {
            _hashCode += getAddToReflow().hashCode();
        }
        if (getAnchoredGroupMember() != null) {
            _hashCode += getAnchoredGroupMember().hashCode();
        }
        if (getAnchoredIn() != null) {
            _hashCode += getAnchoredIn().hashCode();
        }
        if (getArticleName() != null) {
            _hashCode += getArticleName().hashCode();
        }
        if (getBoxRefs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getBoxRefs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getBoxRefs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGeometry() != null) {
            _hashCode += getGeometry().hashCode();
        }
        if (getGroupOpacity() != null) {
            _hashCode += getGroupOpacity().hashCode();
        }
        _hashCode += getIndex();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getShadow() != null) {
            _hashCode += getShadow().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Group.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Group"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addToReflow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "addToReflow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredGroupMember");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredGroupMember"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredIn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredIn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("articleName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "articleName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxRefs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxRefs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "BoxRef"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "geometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Geometry"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "groupOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shadow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Shadow"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
