package com.socgen.sgs.api.quark.engine.infra.pdf;

import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Splits a multi-page PDF into one byte[] per page, using Apache PDFBox.
 *
 * <p>Replaces the .NET QXPIO.PDF_Tools.Split_PDF (whose source ships only as a compiled assembly).
 * Functional parity that matters: the number of output pages and their order. The per-page pool
 * file <em>names</em> are internal/transient (chosen by the loader), so they need not match .NET's.
 */
@Component
@Slf4j
public class PdfSplitter {

    /**
     * Split a PDF into per-page byte arrays (page order preserved).
     *
     * @param pdfData the source PDF bytes
     * @return one byte[] per page (empty list if input is null/empty)
     */
    public List<byte[]> split(byte[] pdfData) {
        List<byte[]> pages = new ArrayList<>();
        if (pdfData == null || pdfData.length == 0) {
            return pages;
        }
        try (PDDocument document = PDDocument.load(new ByteArrayInputStream(pdfData))) {
            Splitter splitter = new Splitter();
            List<PDDocument> split = splitter.split(document);
            for (PDDocument page : split) {
                try (page; ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                    page.save(baos);
                    pages.add(baos.toByteArray());
                }
            }
            log.info("Split PDF into {} page(s)", pages.size());
            return pages;
        } catch (Exception e) {
            log.error("Failed to split PDF ({} bytes): {}", pdfData.length, e.getMessage(), e);
            throw new RuntimeException("Failed to split PDF", e);
        }
    }
}