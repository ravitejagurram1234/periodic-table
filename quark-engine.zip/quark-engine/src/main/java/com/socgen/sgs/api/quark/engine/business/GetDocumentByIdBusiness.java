package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.GetDocumentByIdDao;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/** Bridge for loading a generated document by id (service → business → dao). */
@Component
@RequiredArgsConstructor
public class GetDocumentByIdBusiness {

    private final GetDocumentByIdDao getDocumentByIdDao;

    public DocumentDomain getDocumentById(int idDocument) {
        return getDocumentByIdDao.getDocumentById(idDocument);
    }
}