package com.socgen.sgs.api.quark.engine.domain.modifier;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Represents a table in a modifier project hierarchy.
 *
 * Cross-reference: QXP.Engine.Core.Table (Modifier namespace)
 */
@Getter
@Setter
public class ModifierTable {

    private String uid;
    private String name;
    private int column;
    private Table srcTable;
    private BlocActionEnum action = BlocActionEnum.NONE;
    private TaskBase task;
    private final Map<Integer, ModifierLigne> lignes = new LinkedHashMap<>();

    public ModifierTable() {
    }
}