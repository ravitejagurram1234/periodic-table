/**
 * Rubi.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Rubi  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignment;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences;

    private java.lang.String annonations;

    private java.lang.String autoAlignATLLineEdges;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] calloutAnchors;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes;

    private java.lang.String offset;

    private java.lang.String overhang;

    private java.lang.String overhangAlignment;

    private java.lang.String placement;

    private java.lang.String relativeSize;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RubiText rubiText;

    public Rubi() {
    }

    public Rubi(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignment,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences,
           java.lang.String annonations,
           java.lang.String autoAlignATLLineEdges,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] calloutAnchors,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes,
           java.lang.String offset,
           java.lang.String overhang,
           java.lang.String overhangAlignment,
           java.lang.String placement,
           java.lang.String relativeSize,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RubiText rubiText) {
        super(
            request);
        this.alignment = alignment;
        this.anchoredBoxReferences = anchoredBoxReferences;
        this.annonations = annonations;
        this.autoAlignATLLineEdges = autoAlignATLLineEdges;
        this.calloutAnchors = calloutAnchors;
        this.hiddenData = hiddenData;
        this.index = index;
        this.inlineBoxes = inlineBoxes;
        this.offset = offset;
        this.overhang = overhang;
        this.overhangAlignment = overhangAlignment;
        this.placement = placement;
        this.relativeSize = relativeSize;
        this.richText = richText;
        this.rubiText = rubiText;
    }


    /**
     * Gets the alignment value for this Rubi.
     * 
     * @return alignment
     */
    public java.lang.String getAlignment() {
        return alignment;
    }


    /**
     * Sets the alignment value for this Rubi.
     * 
     * @param alignment
     */
    public void setAlignment(java.lang.String alignment) {
        this.alignment = alignment;
    }


    /**
     * Gets the anchoredBoxReferences value for this Rubi.
     * 
     * @return anchoredBoxReferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] getAnchoredBoxReferences() {
        return anchoredBoxReferences;
    }


    /**
     * Sets the anchoredBoxReferences value for this Rubi.
     * 
     * @param anchoredBoxReferences
     */
    public void setAnchoredBoxReferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences) {
        this.anchoredBoxReferences = anchoredBoxReferences;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference getAnchoredBoxReferences(int i) {
        return this.anchoredBoxReferences[i];
    }

    public void setAnchoredBoxReferences(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference _value) {
        this.anchoredBoxReferences[i] = _value;
    }


    /**
     * Gets the annonations value for this Rubi.
     * 
     * @return annonations
     */
    public java.lang.String getAnnonations() {
        return annonations;
    }


    /**
     * Sets the annonations value for this Rubi.
     * 
     * @param annonations
     */
    public void setAnnonations(java.lang.String annonations) {
        this.annonations = annonations;
    }


    /**
     * Gets the autoAlignATLLineEdges value for this Rubi.
     * 
     * @return autoAlignATLLineEdges
     */
    public java.lang.String getAutoAlignATLLineEdges() {
        return autoAlignATLLineEdges;
    }


    /**
     * Sets the autoAlignATLLineEdges value for this Rubi.
     * 
     * @param autoAlignATLLineEdges
     */
    public void setAutoAlignATLLineEdges(java.lang.String autoAlignATLLineEdges) {
        this.autoAlignATLLineEdges = autoAlignATLLineEdges;
    }


    /**
     * Gets the calloutAnchors value for this Rubi.
     * 
     * @return calloutAnchors
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] getCalloutAnchors() {
        return calloutAnchors;
    }


    /**
     * Sets the calloutAnchors value for this Rubi.
     * 
     * @param calloutAnchors
     */
    public void setCalloutAnchors(com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] calloutAnchors) {
        this.calloutAnchors = calloutAnchors;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor getCalloutAnchors(int i) {
        return this.calloutAnchors[i];
    }

    public void setCalloutAnchors(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor _value) {
        this.calloutAnchors[i] = _value;
    }


    /**
     * Gets the hiddenData value for this Rubi.
     * 
     * @return hiddenData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] getHiddenData() {
        return hiddenData;
    }


    /**
     * Sets the hiddenData value for this Rubi.
     * 
     * @param hiddenData
     */
    public void setHiddenData(com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData) {
        this.hiddenData = hiddenData;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData getHiddenData(int i) {
        return this.hiddenData[i];
    }

    public void setHiddenData(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData _value) {
        this.hiddenData[i] = _value;
    }


    /**
     * Gets the index value for this Rubi.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this Rubi.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the inlineBoxes value for this Rubi.
     * 
     * @return inlineBoxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] getInlineBoxes() {
        return inlineBoxes;
    }


    /**
     * Sets the inlineBoxes value for this Rubi.
     * 
     * @param inlineBoxes
     */
    public void setInlineBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes) {
        this.inlineBoxes = inlineBoxes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox getInlineBoxes(int i) {
        return this.inlineBoxes[i];
    }

    public void setInlineBoxes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox _value) {
        this.inlineBoxes[i] = _value;
    }


    /**
     * Gets the offset value for this Rubi.
     * 
     * @return offset
     */
    public java.lang.String getOffset() {
        return offset;
    }


    /**
     * Sets the offset value for this Rubi.
     * 
     * @param offset
     */
    public void setOffset(java.lang.String offset) {
        this.offset = offset;
    }


    /**
     * Gets the overhang value for this Rubi.
     * 
     * @return overhang
     */
    public java.lang.String getOverhang() {
        return overhang;
    }


    /**
     * Sets the overhang value for this Rubi.
     * 
     * @param overhang
     */
    public void setOverhang(java.lang.String overhang) {
        this.overhang = overhang;
    }


    /**
     * Gets the overhangAlignment value for this Rubi.
     * 
     * @return overhangAlignment
     */
    public java.lang.String getOverhangAlignment() {
        return overhangAlignment;
    }


    /**
     * Sets the overhangAlignment value for this Rubi.
     * 
     * @param overhangAlignment
     */
    public void setOverhangAlignment(java.lang.String overhangAlignment) {
        this.overhangAlignment = overhangAlignment;
    }


    /**
     * Gets the placement value for this Rubi.
     * 
     * @return placement
     */
    public java.lang.String getPlacement() {
        return placement;
    }


    /**
     * Sets the placement value for this Rubi.
     * 
     * @param placement
     */
    public void setPlacement(java.lang.String placement) {
        this.placement = placement;
    }


    /**
     * Gets the relativeSize value for this Rubi.
     * 
     * @return relativeSize
     */
    public java.lang.String getRelativeSize() {
        return relativeSize;
    }


    /**
     * Sets the relativeSize value for this Rubi.
     * 
     * @param relativeSize
     */
    public void setRelativeSize(java.lang.String relativeSize) {
        this.relativeSize = relativeSize;
    }


    /**
     * Gets the richText value for this Rubi.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this Rubi.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText getRichText(int i) {
        return this.richText[i];
    }

    public void setRichText(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText _value) {
        this.richText[i] = _value;
    }


    /**
     * Gets the rubiText value for this Rubi.
     * 
     * @return rubiText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RubiText getRubiText() {
        return rubiText;
    }


    /**
     * Sets the rubiText value for this Rubi.
     * 
     * @param rubiText
     */
    public void setRubiText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RubiText rubiText) {
        this.rubiText = rubiText;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Rubi)) return false;
        Rubi other = (Rubi) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignment==null && other.getAlignment()==null) || 
             (this.alignment!=null &&
              this.alignment.equals(other.getAlignment()))) &&
            ((this.anchoredBoxReferences==null && other.getAnchoredBoxReferences()==null) || 
             (this.anchoredBoxReferences!=null &&
              java.util.Arrays.equals(this.anchoredBoxReferences, other.getAnchoredBoxReferences()))) &&
            ((this.annonations==null && other.getAnnonations()==null) || 
             (this.annonations!=null &&
              this.annonations.equals(other.getAnnonations()))) &&
            ((this.autoAlignATLLineEdges==null && other.getAutoAlignATLLineEdges()==null) || 
             (this.autoAlignATLLineEdges!=null &&
              this.autoAlignATLLineEdges.equals(other.getAutoAlignATLLineEdges()))) &&
            ((this.calloutAnchors==null && other.getCalloutAnchors()==null) || 
             (this.calloutAnchors!=null &&
              java.util.Arrays.equals(this.calloutAnchors, other.getCalloutAnchors()))) &&
            ((this.hiddenData==null && other.getHiddenData()==null) || 
             (this.hiddenData!=null &&
              java.util.Arrays.equals(this.hiddenData, other.getHiddenData()))) &&
            this.index == other.getIndex() &&
            ((this.inlineBoxes==null && other.getInlineBoxes()==null) || 
             (this.inlineBoxes!=null &&
              java.util.Arrays.equals(this.inlineBoxes, other.getInlineBoxes()))) &&
            ((this.offset==null && other.getOffset()==null) || 
             (this.offset!=null &&
              this.offset.equals(other.getOffset()))) &&
            ((this.overhang==null && other.getOverhang()==null) || 
             (this.overhang!=null &&
              this.overhang.equals(other.getOverhang()))) &&
            ((this.overhangAlignment==null && other.getOverhangAlignment()==null) || 
             (this.overhangAlignment!=null &&
              this.overhangAlignment.equals(other.getOverhangAlignment()))) &&
            ((this.placement==null && other.getPlacement()==null) || 
             (this.placement!=null &&
              this.placement.equals(other.getPlacement()))) &&
            ((this.relativeSize==null && other.getRelativeSize()==null) || 
             (this.relativeSize!=null &&
              this.relativeSize.equals(other.getRelativeSize()))) &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText()))) &&
            ((this.rubiText==null && other.getRubiText()==null) || 
             (this.rubiText!=null &&
              this.rubiText.equals(other.getRubiText())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignment() != null) {
            _hashCode += getAlignment().hashCode();
        }
        if (getAnchoredBoxReferences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAnchoredBoxReferences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAnchoredBoxReferences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAnnonations() != null) {
            _hashCode += getAnnonations().hashCode();
        }
        if (getAutoAlignATLLineEdges() != null) {
            _hashCode += getAutoAlignATLLineEdges().hashCode();
        }
        if (getCalloutAnchors() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCalloutAnchors());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCalloutAnchors(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHiddenData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHiddenData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHiddenData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getIndex();
        if (getInlineBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOffset() != null) {
            _hashCode += getOffset().hashCode();
        }
        if (getOverhang() != null) {
            _hashCode += getOverhang().hashCode();
        }
        if (getOverhangAlignment() != null) {
            _hashCode += getOverhangAlignment().hashCode();
        }
        if (getPlacement() != null) {
            _hashCode += getPlacement().hashCode();
        }
        if (getRelativeSize() != null) {
            _hashCode += getRelativeSize().hashCode();
        }
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRubiText() != null) {
            _hashCode += getRubiText().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Rubi.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Rubi"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredBoxReferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredBoxReferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AnchoredBoxReference"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("annonations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "annonations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("autoAlignATLLineEdges");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "autoAlignATLLineEdges"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("calloutAnchors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "calloutAnchors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CalloutAnchor"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hiddenData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hiddenData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HiddenData"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineBoxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineBoxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineBox"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "offset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overhang");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "overhang"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overhangAlignment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "overhangAlignment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("placement");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "placement"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relativeSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "relativeSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RichText"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rubiText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rubiText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RubiText"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
