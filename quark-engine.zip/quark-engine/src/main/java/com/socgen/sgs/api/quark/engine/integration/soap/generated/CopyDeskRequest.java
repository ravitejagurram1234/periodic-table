/**
 * CopyDeskRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class CopyDeskRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String component;

    private java.lang.String ignoreOvermatter;

    private java.lang.String showPagePicture;

    public CopyDeskRequest() {
    }

    public CopyDeskRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String component,
           java.lang.String ignoreOvermatter,
           java.lang.String showPagePicture) {
        super(
            request);
        this.component = component;
        this.ignoreOvermatter = ignoreOvermatter;
        this.showPagePicture = showPagePicture;
    }


    /**
     * Gets the component value for this CopyDeskRequest.
     * 
     * @return component
     */
    public java.lang.String getComponent() {
        return component;
    }


    /**
     * Sets the component value for this CopyDeskRequest.
     * 
     * @param component
     */
    public void setComponent(java.lang.String component) {
        this.component = component;
    }


    /**
     * Gets the ignoreOvermatter value for this CopyDeskRequest.
     * 
     * @return ignoreOvermatter
     */
    public java.lang.String getIgnoreOvermatter() {
        return ignoreOvermatter;
    }


    /**
     * Sets the ignoreOvermatter value for this CopyDeskRequest.
     * 
     * @param ignoreOvermatter
     */
    public void setIgnoreOvermatter(java.lang.String ignoreOvermatter) {
        this.ignoreOvermatter = ignoreOvermatter;
    }


    /**
     * Gets the showPagePicture value for this CopyDeskRequest.
     * 
     * @return showPagePicture
     */
    public java.lang.String getShowPagePicture() {
        return showPagePicture;
    }


    /**
     * Sets the showPagePicture value for this CopyDeskRequest.
     * 
     * @param showPagePicture
     */
    public void setShowPagePicture(java.lang.String showPagePicture) {
        this.showPagePicture = showPagePicture;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CopyDeskRequest)) return false;
        CopyDeskRequest other = (CopyDeskRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.component==null && other.getComponent()==null) || 
             (this.component!=null &&
              this.component.equals(other.getComponent()))) &&
            ((this.ignoreOvermatter==null && other.getIgnoreOvermatter()==null) || 
             (this.ignoreOvermatter!=null &&
              this.ignoreOvermatter.equals(other.getIgnoreOvermatter()))) &&
            ((this.showPagePicture==null && other.getShowPagePicture()==null) || 
             (this.showPagePicture!=null &&
              this.showPagePicture.equals(other.getShowPagePicture())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getComponent() != null) {
            _hashCode += getComponent().hashCode();
        }
        if (getIgnoreOvermatter() != null) {
            _hashCode += getIgnoreOvermatter().hashCode();
        }
        if (getShowPagePicture() != null) {
            _hashCode += getShowPagePicture().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CopyDeskRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CopyDeskRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("component");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "component"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ignoreOvermatter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ignoreOvermatter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showPagePicture");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "showPagePicture"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
