/**
 * AppStudioRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class AppStudioRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String article;

    private java.lang.String articleSource;

    private java.lang.String convertSectionsToPageStacks;

    private java.lang.String issue;

    private java.lang.String organization;

    private java.lang.String password;

    private java.lang.String publication;

    private java.lang.String upload;

    private java.lang.String userName;

    public AppStudioRequest() {
    }

    public AppStudioRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String article,
           java.lang.String articleSource,
           java.lang.String convertSectionsToPageStacks,
           java.lang.String issue,
           java.lang.String organization,
           java.lang.String password,
           java.lang.String publication,
           java.lang.String upload,
           java.lang.String userName) {
        super(
            request);
        this.article = article;
        this.articleSource = articleSource;
        this.convertSectionsToPageStacks = convertSectionsToPageStacks;
        this.issue = issue;
        this.organization = organization;
        this.password = password;
        this.publication = publication;
        this.upload = upload;
        this.userName = userName;
    }


    /**
     * Gets the article value for this AppStudioRequest.
     * 
     * @return article
     */
    public java.lang.String getArticle() {
        return article;
    }


    /**
     * Sets the article value for this AppStudioRequest.
     * 
     * @param article
     */
    public void setArticle(java.lang.String article) {
        this.article = article;
    }


    /**
     * Gets the articleSource value for this AppStudioRequest.
     * 
     * @return articleSource
     */
    public java.lang.String getArticleSource() {
        return articleSource;
    }


    /**
     * Sets the articleSource value for this AppStudioRequest.
     * 
     * @param articleSource
     */
    public void setArticleSource(java.lang.String articleSource) {
        this.articleSource = articleSource;
    }


    /**
     * Gets the convertSectionsToPageStacks value for this AppStudioRequest.
     * 
     * @return convertSectionsToPageStacks
     */
    public java.lang.String getConvertSectionsToPageStacks() {
        return convertSectionsToPageStacks;
    }


    /**
     * Sets the convertSectionsToPageStacks value for this AppStudioRequest.
     * 
     * @param convertSectionsToPageStacks
     */
    public void setConvertSectionsToPageStacks(java.lang.String convertSectionsToPageStacks) {
        this.convertSectionsToPageStacks = convertSectionsToPageStacks;
    }


    /**
     * Gets the issue value for this AppStudioRequest.
     * 
     * @return issue
     */
    public java.lang.String getIssue() {
        return issue;
    }


    /**
     * Sets the issue value for this AppStudioRequest.
     * 
     * @param issue
     */
    public void setIssue(java.lang.String issue) {
        this.issue = issue;
    }


    /**
     * Gets the organization value for this AppStudioRequest.
     * 
     * @return organization
     */
    public java.lang.String getOrganization() {
        return organization;
    }


    /**
     * Sets the organization value for this AppStudioRequest.
     * 
     * @param organization
     */
    public void setOrganization(java.lang.String organization) {
        this.organization = organization;
    }


    /**
     * Gets the password value for this AppStudioRequest.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this AppStudioRequest.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the publication value for this AppStudioRequest.
     * 
     * @return publication
     */
    public java.lang.String getPublication() {
        return publication;
    }


    /**
     * Sets the publication value for this AppStudioRequest.
     * 
     * @param publication
     */
    public void setPublication(java.lang.String publication) {
        this.publication = publication;
    }


    /**
     * Gets the upload value for this AppStudioRequest.
     * 
     * @return upload
     */
    public java.lang.String getUpload() {
        return upload;
    }


    /**
     * Sets the upload value for this AppStudioRequest.
     * 
     * @param upload
     */
    public void setUpload(java.lang.String upload) {
        this.upload = upload;
    }


    /**
     * Gets the userName value for this AppStudioRequest.
     * 
     * @return userName
     */
    public java.lang.String getUserName() {
        return userName;
    }


    /**
     * Sets the userName value for this AppStudioRequest.
     * 
     * @param userName
     */
    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AppStudioRequest)) return false;
        AppStudioRequest other = (AppStudioRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.article==null && other.getArticle()==null) || 
             (this.article!=null &&
              this.article.equals(other.getArticle()))) &&
            ((this.articleSource==null && other.getArticleSource()==null) || 
             (this.articleSource!=null &&
              this.articleSource.equals(other.getArticleSource()))) &&
            ((this.convertSectionsToPageStacks==null && other.getConvertSectionsToPageStacks()==null) || 
             (this.convertSectionsToPageStacks!=null &&
              this.convertSectionsToPageStacks.equals(other.getConvertSectionsToPageStacks()))) &&
            ((this.issue==null && other.getIssue()==null) || 
             (this.issue!=null &&
              this.issue.equals(other.getIssue()))) &&
            ((this.organization==null && other.getOrganization()==null) || 
             (this.organization!=null &&
              this.organization.equals(other.getOrganization()))) &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            ((this.publication==null && other.getPublication()==null) || 
             (this.publication!=null &&
              this.publication.equals(other.getPublication()))) &&
            ((this.upload==null && other.getUpload()==null) || 
             (this.upload!=null &&
              this.upload.equals(other.getUpload()))) &&
            ((this.userName==null && other.getUserName()==null) || 
             (this.userName!=null &&
              this.userName.equals(other.getUserName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getArticle() != null) {
            _hashCode += getArticle().hashCode();
        }
        if (getArticleSource() != null) {
            _hashCode += getArticleSource().hashCode();
        }
        if (getConvertSectionsToPageStacks() != null) {
            _hashCode += getConvertSectionsToPageStacks().hashCode();
        }
        if (getIssue() != null) {
            _hashCode += getIssue().hashCode();
        }
        if (getOrganization() != null) {
            _hashCode += getOrganization().hashCode();
        }
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        if (getPublication() != null) {
            _hashCode += getPublication().hashCode();
        }
        if (getUpload() != null) {
            _hashCode += getUpload().hashCode();
        }
        if (getUserName() != null) {
            _hashCode += getUserName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AppStudioRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AppStudioRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("article");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "article"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("articleSource");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "articleSource"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("convertSectionsToPageStacks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "convertSectionsToPageStacks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("issue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "issue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organization");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "organization"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publication");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "publication"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("upload");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "upload"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "userName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
