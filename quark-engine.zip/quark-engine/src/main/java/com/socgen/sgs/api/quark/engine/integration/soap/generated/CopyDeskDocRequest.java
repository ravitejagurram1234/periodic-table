/**
 * CopyDeskDocRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class CopyDeskDocRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String article;

    private java.lang.String component;

    private java.lang.String format;

    private java.lang.String includePagePicture;

    private java.lang.String picDPI;

    private java.lang.String picFormat;

    private java.lang.String quality;

    private java.lang.String saveAsTemplate;

    private java.lang.String spreadRange;

    public CopyDeskDocRequest() {
    }

    public CopyDeskDocRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String article,
           java.lang.String component,
           java.lang.String format,
           java.lang.String includePagePicture,
           java.lang.String picDPI,
           java.lang.String picFormat,
           java.lang.String quality,
           java.lang.String saveAsTemplate,
           java.lang.String spreadRange) {
        super(
            request);
        this.article = article;
        this.component = component;
        this.format = format;
        this.includePagePicture = includePagePicture;
        this.picDPI = picDPI;
        this.picFormat = picFormat;
        this.quality = quality;
        this.saveAsTemplate = saveAsTemplate;
        this.spreadRange = spreadRange;
    }


    /**
     * Gets the article value for this CopyDeskDocRequest.
     * 
     * @return article
     */
    public java.lang.String getArticle() {
        return article;
    }


    /**
     * Sets the article value for this CopyDeskDocRequest.
     * 
     * @param article
     */
    public void setArticle(java.lang.String article) {
        this.article = article;
    }


    /**
     * Gets the component value for this CopyDeskDocRequest.
     * 
     * @return component
     */
    public java.lang.String getComponent() {
        return component;
    }


    /**
     * Sets the component value for this CopyDeskDocRequest.
     * 
     * @param component
     */
    public void setComponent(java.lang.String component) {
        this.component = component;
    }


    /**
     * Gets the format value for this CopyDeskDocRequest.
     * 
     * @return format
     */
    public java.lang.String getFormat() {
        return format;
    }


    /**
     * Sets the format value for this CopyDeskDocRequest.
     * 
     * @param format
     */
    public void setFormat(java.lang.String format) {
        this.format = format;
    }


    /**
     * Gets the includePagePicture value for this CopyDeskDocRequest.
     * 
     * @return includePagePicture
     */
    public java.lang.String getIncludePagePicture() {
        return includePagePicture;
    }


    /**
     * Sets the includePagePicture value for this CopyDeskDocRequest.
     * 
     * @param includePagePicture
     */
    public void setIncludePagePicture(java.lang.String includePagePicture) {
        this.includePagePicture = includePagePicture;
    }


    /**
     * Gets the picDPI value for this CopyDeskDocRequest.
     * 
     * @return picDPI
     */
    public java.lang.String getPicDPI() {
        return picDPI;
    }


    /**
     * Sets the picDPI value for this CopyDeskDocRequest.
     * 
     * @param picDPI
     */
    public void setPicDPI(java.lang.String picDPI) {
        this.picDPI = picDPI;
    }


    /**
     * Gets the picFormat value for this CopyDeskDocRequest.
     * 
     * @return picFormat
     */
    public java.lang.String getPicFormat() {
        return picFormat;
    }


    /**
     * Sets the picFormat value for this CopyDeskDocRequest.
     * 
     * @param picFormat
     */
    public void setPicFormat(java.lang.String picFormat) {
        this.picFormat = picFormat;
    }


    /**
     * Gets the quality value for this CopyDeskDocRequest.
     * 
     * @return quality
     */
    public java.lang.String getQuality() {
        return quality;
    }


    /**
     * Sets the quality value for this CopyDeskDocRequest.
     * 
     * @param quality
     */
    public void setQuality(java.lang.String quality) {
        this.quality = quality;
    }


    /**
     * Gets the saveAsTemplate value for this CopyDeskDocRequest.
     * 
     * @return saveAsTemplate
     */
    public java.lang.String getSaveAsTemplate() {
        return saveAsTemplate;
    }


    /**
     * Sets the saveAsTemplate value for this CopyDeskDocRequest.
     * 
     * @param saveAsTemplate
     */
    public void setSaveAsTemplate(java.lang.String saveAsTemplate) {
        this.saveAsTemplate = saveAsTemplate;
    }


    /**
     * Gets the spreadRange value for this CopyDeskDocRequest.
     * 
     * @return spreadRange
     */
    public java.lang.String getSpreadRange() {
        return spreadRange;
    }


    /**
     * Sets the spreadRange value for this CopyDeskDocRequest.
     * 
     * @param spreadRange
     */
    public void setSpreadRange(java.lang.String spreadRange) {
        this.spreadRange = spreadRange;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CopyDeskDocRequest)) return false;
        CopyDeskDocRequest other = (CopyDeskDocRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.article==null && other.getArticle()==null) || 
             (this.article!=null &&
              this.article.equals(other.getArticle()))) &&
            ((this.component==null && other.getComponent()==null) || 
             (this.component!=null &&
              this.component.equals(other.getComponent()))) &&
            ((this.format==null && other.getFormat()==null) || 
             (this.format!=null &&
              this.format.equals(other.getFormat()))) &&
            ((this.includePagePicture==null && other.getIncludePagePicture()==null) || 
             (this.includePagePicture!=null &&
              this.includePagePicture.equals(other.getIncludePagePicture()))) &&
            ((this.picDPI==null && other.getPicDPI()==null) || 
             (this.picDPI!=null &&
              this.picDPI.equals(other.getPicDPI()))) &&
            ((this.picFormat==null && other.getPicFormat()==null) || 
             (this.picFormat!=null &&
              this.picFormat.equals(other.getPicFormat()))) &&
            ((this.quality==null && other.getQuality()==null) || 
             (this.quality!=null &&
              this.quality.equals(other.getQuality()))) &&
            ((this.saveAsTemplate==null && other.getSaveAsTemplate()==null) || 
             (this.saveAsTemplate!=null &&
              this.saveAsTemplate.equals(other.getSaveAsTemplate()))) &&
            ((this.spreadRange==null && other.getSpreadRange()==null) || 
             (this.spreadRange!=null &&
              this.spreadRange.equals(other.getSpreadRange())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getArticle() != null) {
            _hashCode += getArticle().hashCode();
        }
        if (getComponent() != null) {
            _hashCode += getComponent().hashCode();
        }
        if (getFormat() != null) {
            _hashCode += getFormat().hashCode();
        }
        if (getIncludePagePicture() != null) {
            _hashCode += getIncludePagePicture().hashCode();
        }
        if (getPicDPI() != null) {
            _hashCode += getPicDPI().hashCode();
        }
        if (getPicFormat() != null) {
            _hashCode += getPicFormat().hashCode();
        }
        if (getQuality() != null) {
            _hashCode += getQuality().hashCode();
        }
        if (getSaveAsTemplate() != null) {
            _hashCode += getSaveAsTemplate().hashCode();
        }
        if (getSpreadRange() != null) {
            _hashCode += getSpreadRange().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CopyDeskDocRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CopyDeskDocRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("article");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "article"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("component");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "component"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("format");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "format"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includePagePicture");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "includePagePicture"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picDPI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "picDPI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "picFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quality");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "quality"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saveAsTemplate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "saveAsTemplate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spreadRange");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spreadRange"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
