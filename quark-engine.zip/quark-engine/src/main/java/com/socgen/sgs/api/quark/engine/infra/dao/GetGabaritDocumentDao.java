package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;

public interface GetGabaritDocumentDao {
    DocumentDomain getGabaritDocument(Integer idSuivi);
}

