package com.socgen.sgs.api.quark.engine.domain.helper;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Provides mathematical utility functions for dynamic report generation.
 *
 * Cross-reference: QXP.Engine.Core.Math_Helper
 */
public final class MathHelper {

    private MathHelper() {
    }

    /**
     * Calculate a percentage of a value.
     * result = value * (percent / 100)
     *
     * @param value   the source value
     * @param percent the percentage to apply
     * @return the calculated value
     */
    public static BigDecimal getValPercent(BigDecimal value, BigDecimal percent) {
        if (value == null || percent == null) {
            return BigDecimal.ZERO;
        }
        return value.multiply(percent).divide(BigDecimal.valueOf(100), 6, RoundingMode.HALF_UP);
    }
}