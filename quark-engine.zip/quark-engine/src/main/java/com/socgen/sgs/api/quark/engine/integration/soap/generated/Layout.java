/**
 * Layout.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Layout  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Article[] articles;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes;

    private java.lang.String copyContentToSynchronizedOrientation;

    private java.lang.String duplicateFromLayout;

    private java.lang.String height;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink[] hyperlinks;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] inlineItems;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] inlineTables;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer[] layers;

    private java.lang.String layoutHidden;

    private java.lang.String layoutId;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutMetadata layoutMetadata;

    private java.lang.String layoutSpecification;

    private java.lang.String layoutType;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterPageSequence[] masterPageSequences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterSpread[] masterSpreads;

    private java.lang.String mediaType;

    private java.lang.String name;

    private java.lang.String operation;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence[] pageSequences;

    private java.lang.String pointsPerInch;

    private java.lang.String reflowViewLayout;

    private java.lang.String reflowViewLayoutUID;

    private java.lang.String sharedStatus;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread[] spreads;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] tables;

    private java.lang.String UID;

    private java.lang.String width;

    public Layout() {
    }

    public Layout(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Article[] articles,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes,
           java.lang.String copyContentToSynchronizedOrientation,
           java.lang.String duplicateFromLayout,
           java.lang.String height,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink[] hyperlinks,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] inlineItems,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] inlineTables,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer[] layers,
           java.lang.String layoutHidden,
           java.lang.String layoutId,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutMetadata layoutMetadata,
           java.lang.String layoutSpecification,
           java.lang.String layoutType,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterPageSequence[] masterPageSequences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterSpread[] masterSpreads,
           java.lang.String mediaType,
           java.lang.String name,
           java.lang.String operation,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence[] pageSequences,
           java.lang.String pointsPerInch,
           java.lang.String reflowViewLayout,
           java.lang.String reflowViewLayoutUID,
           java.lang.String sharedStatus,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread[] spreads,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] tables,
           java.lang.String UID,
           java.lang.String width) {
        super(
            request);
        this.articles = articles;
        this.boxes = boxes;
        this.copyContentToSynchronizedOrientation = copyContentToSynchronizedOrientation;
        this.duplicateFromLayout = duplicateFromLayout;
        this.height = height;
        this.hyperlinks = hyperlinks;
        this.inlineBoxes = inlineBoxes;
        this.inlineItems = inlineItems;
        this.inlineTables = inlineTables;
        this.layers = layers;
        this.layoutHidden = layoutHidden;
        this.layoutId = layoutId;
        this.layoutMetadata = layoutMetadata;
        this.layoutSpecification = layoutSpecification;
        this.layoutType = layoutType;
        this.masterPageSequences = masterPageSequences;
        this.masterSpreads = masterSpreads;
        this.mediaType = mediaType;
        this.name = name;
        this.operation = operation;
        this.pageSequences = pageSequences;
        this.pointsPerInch = pointsPerInch;
        this.reflowViewLayout = reflowViewLayout;
        this.reflowViewLayoutUID = reflowViewLayoutUID;
        this.sharedStatus = sharedStatus;
        this.spreads = spreads;
        this.tables = tables;
        this.UID = UID;
        this.width = width;
    }


    /**
     * Gets the articles value for this Layout.
     * 
     * @return articles
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Article[] getArticles() {
        return articles;
    }


    /**
     * Sets the articles value for this Layout.
     * 
     * @param articles
     */
    public void setArticles(com.socgen.sgs.api.quark.engine.integration.soap.generated.Article[] articles) {
        this.articles = articles;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Article getArticles(int i) {
        return this.articles[i];
    }

    public void setArticles(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Article _value) {
        this.articles[i] = _value;
    }


    /**
     * Gets the boxes value for this Layout.
     * 
     * @return boxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] getBoxes() {
        return boxes;
    }


    /**
     * Sets the boxes value for this Layout.
     * 
     * @param boxes
     */
    public void setBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes) {
        this.boxes = boxes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Box getBoxes(int i) {
        return this.boxes[i];
    }

    public void setBoxes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Box _value) {
        this.boxes[i] = _value;
    }


    /**
     * Gets the copyContentToSynchronizedOrientation value for this Layout.
     * 
     * @return copyContentToSynchronizedOrientation
     */
    public java.lang.String getCopyContentToSynchronizedOrientation() {
        return copyContentToSynchronizedOrientation;
    }


    /**
     * Sets the copyContentToSynchronizedOrientation value for this Layout.
     * 
     * @param copyContentToSynchronizedOrientation
     */
    public void setCopyContentToSynchronizedOrientation(java.lang.String copyContentToSynchronizedOrientation) {
        this.copyContentToSynchronizedOrientation = copyContentToSynchronizedOrientation;
    }


    /**
     * Gets the duplicateFromLayout value for this Layout.
     * 
     * @return duplicateFromLayout
     */
    public java.lang.String getDuplicateFromLayout() {
        return duplicateFromLayout;
    }


    /**
     * Sets the duplicateFromLayout value for this Layout.
     * 
     * @param duplicateFromLayout
     */
    public void setDuplicateFromLayout(java.lang.String duplicateFromLayout) {
        this.duplicateFromLayout = duplicateFromLayout;
    }


    /**
     * Gets the height value for this Layout.
     * 
     * @return height
     */
    public java.lang.String getHeight() {
        return height;
    }


    /**
     * Sets the height value for this Layout.
     * 
     * @param height
     */
    public void setHeight(java.lang.String height) {
        this.height = height;
    }


    /**
     * Gets the hyperlinks value for this Layout.
     * 
     * @return hyperlinks
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink[] getHyperlinks() {
        return hyperlinks;
    }


    /**
     * Sets the hyperlinks value for this Layout.
     * 
     * @param hyperlinks
     */
    public void setHyperlinks(com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink[] hyperlinks) {
        this.hyperlinks = hyperlinks;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink getHyperlinks(int i) {
        return this.hyperlinks[i];
    }

    public void setHyperlinks(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink _value) {
        this.hyperlinks[i] = _value;
    }


    /**
     * Gets the inlineBoxes value for this Layout.
     * 
     * @return inlineBoxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] getInlineBoxes() {
        return inlineBoxes;
    }


    /**
     * Sets the inlineBoxes value for this Layout.
     * 
     * @param inlineBoxes
     */
    public void setInlineBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes) {
        this.inlineBoxes = inlineBoxes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox getInlineBoxes(int i) {
        return this.inlineBoxes[i];
    }

    public void setInlineBoxes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox _value) {
        this.inlineBoxes[i] = _value;
    }


    /**
     * Gets the inlineItems value for this Layout.
     * 
     * @return inlineItems
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] getInlineItems() {
        return inlineItems;
    }


    /**
     * Sets the inlineItems value for this Layout.
     * 
     * @param inlineItems
     */
    public void setInlineItems(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] inlineItems) {
        this.inlineItems = inlineItems;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem getInlineItems(int i) {
        return this.inlineItems[i];
    }

    public void setInlineItems(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem _value) {
        this.inlineItems[i] = _value;
    }


    /**
     * Gets the inlineTables value for this Layout.
     * 
     * @return inlineTables
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] getInlineTables() {
        return inlineTables;
    }


    /**
     * Sets the inlineTables value for this Layout.
     * 
     * @param inlineTables
     */
    public void setInlineTables(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] inlineTables) {
        this.inlineTables = inlineTables;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable getInlineTables(int i) {
        return this.inlineTables[i];
    }

    public void setInlineTables(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable _value) {
        this.inlineTables[i] = _value;
    }


    /**
     * Gets the layers value for this Layout.
     * 
     * @return layers
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer[] getLayers() {
        return layers;
    }


    /**
     * Sets the layers value for this Layout.
     * 
     * @param layers
     */
    public void setLayers(com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer[] layers) {
        this.layers = layers;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer getLayers(int i) {
        return this.layers[i];
    }

    public void setLayers(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer _value) {
        this.layers[i] = _value;
    }


    /**
     * Gets the layoutHidden value for this Layout.
     * 
     * @return layoutHidden
     */
    public java.lang.String getLayoutHidden() {
        return layoutHidden;
    }


    /**
     * Sets the layoutHidden value for this Layout.
     * 
     * @param layoutHidden
     */
    public void setLayoutHidden(java.lang.String layoutHidden) {
        this.layoutHidden = layoutHidden;
    }


    /**
     * Gets the layoutId value for this Layout.
     * 
     * @return layoutId
     */
    public java.lang.String getLayoutId() {
        return layoutId;
    }


    /**
     * Sets the layoutId value for this Layout.
     * 
     * @param layoutId
     */
    public void setLayoutId(java.lang.String layoutId) {
        this.layoutId = layoutId;
    }


    /**
     * Gets the layoutMetadata value for this Layout.
     * 
     * @return layoutMetadata
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutMetadata getLayoutMetadata() {
        return layoutMetadata;
    }


    /**
     * Sets the layoutMetadata value for this Layout.
     * 
     * @param layoutMetadata
     */
    public void setLayoutMetadata(com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutMetadata layoutMetadata) {
        this.layoutMetadata = layoutMetadata;
    }


    /**
     * Gets the layoutSpecification value for this Layout.
     * 
     * @return layoutSpecification
     */
    public java.lang.String getLayoutSpecification() {
        return layoutSpecification;
    }


    /**
     * Sets the layoutSpecification value for this Layout.
     * 
     * @param layoutSpecification
     */
    public void setLayoutSpecification(java.lang.String layoutSpecification) {
        this.layoutSpecification = layoutSpecification;
    }


    /**
     * Gets the layoutType value for this Layout.
     * 
     * @return layoutType
     */
    public java.lang.String getLayoutType() {
        return layoutType;
    }


    /**
     * Sets the layoutType value for this Layout.
     * 
     * @param layoutType
     */
    public void setLayoutType(java.lang.String layoutType) {
        this.layoutType = layoutType;
    }


    /**
     * Gets the masterPageSequences value for this Layout.
     * 
     * @return masterPageSequences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterPageSequence[] getMasterPageSequences() {
        return masterPageSequences;
    }


    /**
     * Sets the masterPageSequences value for this Layout.
     * 
     * @param masterPageSequences
     */
    public void setMasterPageSequences(com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterPageSequence[] masterPageSequences) {
        this.masterPageSequences = masterPageSequences;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterPageSequence getMasterPageSequences(int i) {
        return this.masterPageSequences[i];
    }

    public void setMasterPageSequences(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterPageSequence _value) {
        this.masterPageSequences[i] = _value;
    }


    /**
     * Gets the masterSpreads value for this Layout.
     * 
     * @return masterSpreads
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterSpread[] getMasterSpreads() {
        return masterSpreads;
    }


    /**
     * Sets the masterSpreads value for this Layout.
     * 
     * @param masterSpreads
     */
    public void setMasterSpreads(com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterSpread[] masterSpreads) {
        this.masterSpreads = masterSpreads;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterSpread getMasterSpreads(int i) {
        return this.masterSpreads[i];
    }

    public void setMasterSpreads(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterSpread _value) {
        this.masterSpreads[i] = _value;
    }


    /**
     * Gets the mediaType value for this Layout.
     * 
     * @return mediaType
     */
    public java.lang.String getMediaType() {
        return mediaType;
    }


    /**
     * Sets the mediaType value for this Layout.
     * 
     * @param mediaType
     */
    public void setMediaType(java.lang.String mediaType) {
        this.mediaType = mediaType;
    }


    /**
     * Gets the name value for this Layout.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Layout.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the operation value for this Layout.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this Layout.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the pageSequences value for this Layout.
     * 
     * @return pageSequences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence[] getPageSequences() {
        return pageSequences;
    }


    /**
     * Sets the pageSequences value for this Layout.
     * 
     * @param pageSequences
     */
    public void setPageSequences(com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence[] pageSequences) {
        this.pageSequences = pageSequences;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence getPageSequences(int i) {
        return this.pageSequences[i];
    }

    public void setPageSequences(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence _value) {
        this.pageSequences[i] = _value;
    }


    /**
     * Gets the pointsPerInch value for this Layout.
     * 
     * @return pointsPerInch
     */
    public java.lang.String getPointsPerInch() {
        return pointsPerInch;
    }


    /**
     * Sets the pointsPerInch value for this Layout.
     * 
     * @param pointsPerInch
     */
    public void setPointsPerInch(java.lang.String pointsPerInch) {
        this.pointsPerInch = pointsPerInch;
    }


    /**
     * Gets the reflowViewLayout value for this Layout.
     * 
     * @return reflowViewLayout
     */
    public java.lang.String getReflowViewLayout() {
        return reflowViewLayout;
    }


    /**
     * Sets the reflowViewLayout value for this Layout.
     * 
     * @param reflowViewLayout
     */
    public void setReflowViewLayout(java.lang.String reflowViewLayout) {
        this.reflowViewLayout = reflowViewLayout;
    }


    /**
     * Gets the reflowViewLayoutUID value for this Layout.
     * 
     * @return reflowViewLayoutUID
     */
    public java.lang.String getReflowViewLayoutUID() {
        return reflowViewLayoutUID;
    }


    /**
     * Sets the reflowViewLayoutUID value for this Layout.
     * 
     * @param reflowViewLayoutUID
     */
    public void setReflowViewLayoutUID(java.lang.String reflowViewLayoutUID) {
        this.reflowViewLayoutUID = reflowViewLayoutUID;
    }


    /**
     * Gets the sharedStatus value for this Layout.
     * 
     * @return sharedStatus
     */
    public java.lang.String getSharedStatus() {
        return sharedStatus;
    }


    /**
     * Sets the sharedStatus value for this Layout.
     * 
     * @param sharedStatus
     */
    public void setSharedStatus(java.lang.String sharedStatus) {
        this.sharedStatus = sharedStatus;
    }


    /**
     * Gets the spreads value for this Layout.
     * 
     * @return spreads
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread[] getSpreads() {
        return spreads;
    }


    /**
     * Sets the spreads value for this Layout.
     * 
     * @param spreads
     */
    public void setSpreads(com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread[] spreads) {
        this.spreads = spreads;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread getSpreads(int i) {
        return this.spreads[i];
    }

    public void setSpreads(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread _value) {
        this.spreads[i] = _value;
    }


    /**
     * Gets the tables value for this Layout.
     * 
     * @return tables
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] getTables() {
        return tables;
    }


    /**
     * Sets the tables value for this Layout.
     * 
     * @param tables
     */
    public void setTables(com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] tables) {
        this.tables = tables;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Table getTables(int i) {
        return this.tables[i];
    }

    public void setTables(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Table _value) {
        this.tables[i] = _value;
    }


    /**
     * Gets the UID value for this Layout.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Layout.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the width value for this Layout.
     * 
     * @return width
     */
    public java.lang.String getWidth() {
        return width;
    }


    /**
     * Sets the width value for this Layout.
     * 
     * @param width
     */
    public void setWidth(java.lang.String width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Layout)) return false;
        Layout other = (Layout) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.articles==null && other.getArticles()==null) || 
             (this.articles!=null &&
              java.util.Arrays.equals(this.articles, other.getArticles()))) &&
            ((this.boxes==null && other.getBoxes()==null) || 
             (this.boxes!=null &&
              java.util.Arrays.equals(this.boxes, other.getBoxes()))) &&
            ((this.copyContentToSynchronizedOrientation==null && other.getCopyContentToSynchronizedOrientation()==null) || 
             (this.copyContentToSynchronizedOrientation!=null &&
              this.copyContentToSynchronizedOrientation.equals(other.getCopyContentToSynchronizedOrientation()))) &&
            ((this.duplicateFromLayout==null && other.getDuplicateFromLayout()==null) || 
             (this.duplicateFromLayout!=null &&
              this.duplicateFromLayout.equals(other.getDuplicateFromLayout()))) &&
            ((this.height==null && other.getHeight()==null) || 
             (this.height!=null &&
              this.height.equals(other.getHeight()))) &&
            ((this.hyperlinks==null && other.getHyperlinks()==null) || 
             (this.hyperlinks!=null &&
              java.util.Arrays.equals(this.hyperlinks, other.getHyperlinks()))) &&
            ((this.inlineBoxes==null && other.getInlineBoxes()==null) || 
             (this.inlineBoxes!=null &&
              java.util.Arrays.equals(this.inlineBoxes, other.getInlineBoxes()))) &&
            ((this.inlineItems==null && other.getInlineItems()==null) || 
             (this.inlineItems!=null &&
              java.util.Arrays.equals(this.inlineItems, other.getInlineItems()))) &&
            ((this.inlineTables==null && other.getInlineTables()==null) || 
             (this.inlineTables!=null &&
              java.util.Arrays.equals(this.inlineTables, other.getInlineTables()))) &&
            ((this.layers==null && other.getLayers()==null) || 
             (this.layers!=null &&
              java.util.Arrays.equals(this.layers, other.getLayers()))) &&
            ((this.layoutHidden==null && other.getLayoutHidden()==null) || 
             (this.layoutHidden!=null &&
              this.layoutHidden.equals(other.getLayoutHidden()))) &&
            ((this.layoutId==null && other.getLayoutId()==null) || 
             (this.layoutId!=null &&
              this.layoutId.equals(other.getLayoutId()))) &&
            ((this.layoutMetadata==null && other.getLayoutMetadata()==null) || 
             (this.layoutMetadata!=null &&
              this.layoutMetadata.equals(other.getLayoutMetadata()))) &&
            ((this.layoutSpecification==null && other.getLayoutSpecification()==null) || 
             (this.layoutSpecification!=null &&
              this.layoutSpecification.equals(other.getLayoutSpecification()))) &&
            ((this.layoutType==null && other.getLayoutType()==null) || 
             (this.layoutType!=null &&
              this.layoutType.equals(other.getLayoutType()))) &&
            ((this.masterPageSequences==null && other.getMasterPageSequences()==null) || 
             (this.masterPageSequences!=null &&
              java.util.Arrays.equals(this.masterPageSequences, other.getMasterPageSequences()))) &&
            ((this.masterSpreads==null && other.getMasterSpreads()==null) || 
             (this.masterSpreads!=null &&
              java.util.Arrays.equals(this.masterSpreads, other.getMasterSpreads()))) &&
            ((this.mediaType==null && other.getMediaType()==null) || 
             (this.mediaType!=null &&
              this.mediaType.equals(other.getMediaType()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.pageSequences==null && other.getPageSequences()==null) || 
             (this.pageSequences!=null &&
              java.util.Arrays.equals(this.pageSequences, other.getPageSequences()))) &&
            ((this.pointsPerInch==null && other.getPointsPerInch()==null) || 
             (this.pointsPerInch!=null &&
              this.pointsPerInch.equals(other.getPointsPerInch()))) &&
            ((this.reflowViewLayout==null && other.getReflowViewLayout()==null) || 
             (this.reflowViewLayout!=null &&
              this.reflowViewLayout.equals(other.getReflowViewLayout()))) &&
            ((this.reflowViewLayoutUID==null && other.getReflowViewLayoutUID()==null) || 
             (this.reflowViewLayoutUID!=null &&
              this.reflowViewLayoutUID.equals(other.getReflowViewLayoutUID()))) &&
            ((this.sharedStatus==null && other.getSharedStatus()==null) || 
             (this.sharedStatus!=null &&
              this.sharedStatus.equals(other.getSharedStatus()))) &&
            ((this.spreads==null && other.getSpreads()==null) || 
             (this.spreads!=null &&
              java.util.Arrays.equals(this.spreads, other.getSpreads()))) &&
            ((this.tables==null && other.getTables()==null) || 
             (this.tables!=null &&
              java.util.Arrays.equals(this.tables, other.getTables()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.width==null && other.getWidth()==null) || 
             (this.width!=null &&
              this.width.equals(other.getWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getArticles() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArticles());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArticles(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCopyContentToSynchronizedOrientation() != null) {
            _hashCode += getCopyContentToSynchronizedOrientation().hashCode();
        }
        if (getDuplicateFromLayout() != null) {
            _hashCode += getDuplicateFromLayout().hashCode();
        }
        if (getHeight() != null) {
            _hashCode += getHeight().hashCode();
        }
        if (getHyperlinks() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHyperlinks());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHyperlinks(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInlineBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInlineItems() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineItems());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineItems(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInlineTables() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineTables());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineTables(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLayers() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLayers());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLayers(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLayoutHidden() != null) {
            _hashCode += getLayoutHidden().hashCode();
        }
        if (getLayoutId() != null) {
            _hashCode += getLayoutId().hashCode();
        }
        if (getLayoutMetadata() != null) {
            _hashCode += getLayoutMetadata().hashCode();
        }
        if (getLayoutSpecification() != null) {
            _hashCode += getLayoutSpecification().hashCode();
        }
        if (getLayoutType() != null) {
            _hashCode += getLayoutType().hashCode();
        }
        if (getMasterPageSequences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMasterPageSequences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMasterPageSequences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMasterSpreads() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMasterSpreads());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMasterSpreads(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMediaType() != null) {
            _hashCode += getMediaType().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getPageSequences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPageSequences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPageSequences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPointsPerInch() != null) {
            _hashCode += getPointsPerInch().hashCode();
        }
        if (getReflowViewLayout() != null) {
            _hashCode += getReflowViewLayout().hashCode();
        }
        if (getReflowViewLayoutUID() != null) {
            _hashCode += getReflowViewLayoutUID().hashCode();
        }
        if (getSharedStatus() != null) {
            _hashCode += getSharedStatus().hashCode();
        }
        if (getSpreads() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSpreads());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSpreads(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTables() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTables());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTables(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getWidth() != null) {
            _hashCode += getWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Layout.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Layout"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("articles");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "articles"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Article"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Box"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("copyContentToSynchronizedOrientation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "copyContentToSynchronizedOrientation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateFromLayout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "duplicateFromLayout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("height");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "height"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hyperlinks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hyperlinks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Hyperlink"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineBoxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineBoxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineBox"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineItems");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineItem"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineTables");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineTables"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineTable"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layers");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Layer"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutHidden");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layoutHidden"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layoutId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutMetadata");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layoutMetadata"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LayoutMetadata"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutSpecification");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layoutSpecification"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layoutType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("masterPageSequences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "masterPageSequences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "MasterPageSequence"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("masterSpreads");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "masterSpreads"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "MasterSpread"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mediaType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "mediaType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageSequences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pageSequences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageSequence"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pointsPerInch");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pointsPerInch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reflowViewLayout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "reflowViewLayout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reflowViewLayoutUID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "reflowViewLayoutUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sharedStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "sharedStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spreads");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spreads"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Spread"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tables");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tables"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Table"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("width");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "width"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
