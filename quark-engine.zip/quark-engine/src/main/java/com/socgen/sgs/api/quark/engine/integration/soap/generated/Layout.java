/**
 * Layout.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Layout  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String UID;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Article[] articles;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer[] layers;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutProperty layoutProperty;

    private java.lang.String mediaType;

    private java.lang.String name;

    private java.lang.String pointsPerInch;

    private java.lang.String sharedStatus;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread[] spreads;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] tables;

    public Layout() {
    }

    public Layout(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String UID,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Article[] articles,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer[] layers,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutProperty layoutProperty,
           java.lang.String mediaType,
           java.lang.String name,
           java.lang.String pointsPerInch,
           java.lang.String sharedStatus,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread[] spreads,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] tables) {
        super(
            request);
        this.UID = UID;
        this.articles = articles;
        this.boxes = boxes;
        this.layers = layers;
        this.layoutProperty = layoutProperty;
        this.mediaType = mediaType;
        this.name = name;
        this.pointsPerInch = pointsPerInch;
        this.sharedStatus = sharedStatus;
        this.spreads = spreads;
        this.tables = tables;
    }


    /**
     * Gets the UID value for this Layout.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Layout.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the articles value for this Layout.
     * 
     * @return articles
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Article[] getArticles() {
        return articles;
    }


    /**
     * Sets the articles value for this Layout.
     * 
     * @param articles
     */
    public void setArticles(com.socgen.sgs.api.quark.engine.integration.soap.generated.Article[] articles) {
        this.articles = articles;
    }


    /**
     * Gets the boxes value for this Layout.
     * 
     * @return boxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] getBoxes() {
        return boxes;
    }


    /**
     * Sets the boxes value for this Layout.
     * 
     * @param boxes
     */
    public void setBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes) {
        this.boxes = boxes;
    }


    /**
     * Gets the layers value for this Layout.
     * 
     * @return layers
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer[] getLayers() {
        return layers;
    }


    /**
     * Sets the layers value for this Layout.
     * 
     * @param layers
     */
    public void setLayers(com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer[] layers) {
        this.layers = layers;
    }


    /**
     * Gets the layoutProperty value for this Layout.
     * 
     * @return layoutProperty
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutProperty getLayoutProperty() {
        return layoutProperty;
    }


    /**
     * Sets the layoutProperty value for this Layout.
     * 
     * @param layoutProperty
     */
    public void setLayoutProperty(com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutProperty layoutProperty) {
        this.layoutProperty = layoutProperty;
    }


    /**
     * Gets the mediaType value for this Layout.
     * 
     * @return mediaType
     */
    public java.lang.String getMediaType() {
        return mediaType;
    }


    /**
     * Sets the mediaType value for this Layout.
     * 
     * @param mediaType
     */
    public void setMediaType(java.lang.String mediaType) {
        this.mediaType = mediaType;
    }


    /**
     * Gets the name value for this Layout.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Layout.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the pointsPerInch value for this Layout.
     * 
     * @return pointsPerInch
     */
    public java.lang.String getPointsPerInch() {
        return pointsPerInch;
    }


    /**
     * Sets the pointsPerInch value for this Layout.
     * 
     * @param pointsPerInch
     */
    public void setPointsPerInch(java.lang.String pointsPerInch) {
        this.pointsPerInch = pointsPerInch;
    }


    /**
     * Gets the sharedStatus value for this Layout.
     * 
     * @return sharedStatus
     */
    public java.lang.String getSharedStatus() {
        return sharedStatus;
    }


    /**
     * Sets the sharedStatus value for this Layout.
     * 
     * @param sharedStatus
     */
    public void setSharedStatus(java.lang.String sharedStatus) {
        this.sharedStatus = sharedStatus;
    }


    /**
     * Gets the spreads value for this Layout.
     * 
     * @return spreads
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread[] getSpreads() {
        return spreads;
    }


    /**
     * Sets the spreads value for this Layout.
     * 
     * @param spreads
     */
    public void setSpreads(com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread[] spreads) {
        this.spreads = spreads;
    }


    /**
     * Gets the tables value for this Layout.
     * 
     * @return tables
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] getTables() {
        return tables;
    }


    /**
     * Sets the tables value for this Layout.
     * 
     * @param tables
     */
    public void setTables(com.socgen.sgs.api.quark.engine.integration.soap.generated.Table[] tables) {
        this.tables = tables;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Layout)) return false;
        Layout other = (Layout) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.articles==null && other.getArticles()==null) || 
             (this.articles!=null &&
              java.util.Arrays.equals(this.articles, other.getArticles()))) &&
            ((this.boxes==null && other.getBoxes()==null) || 
             (this.boxes!=null &&
              java.util.Arrays.equals(this.boxes, other.getBoxes()))) &&
            ((this.layers==null && other.getLayers()==null) || 
             (this.layers!=null &&
              java.util.Arrays.equals(this.layers, other.getLayers()))) &&
            ((this.layoutProperty==null && other.getLayoutProperty()==null) || 
             (this.layoutProperty!=null &&
              this.layoutProperty.equals(other.getLayoutProperty()))) &&
            ((this.mediaType==null && other.getMediaType()==null) || 
             (this.mediaType!=null &&
              this.mediaType.equals(other.getMediaType()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.pointsPerInch==null && other.getPointsPerInch()==null) || 
             (this.pointsPerInch!=null &&
              this.pointsPerInch.equals(other.getPointsPerInch()))) &&
            ((this.sharedStatus==null && other.getSharedStatus()==null) || 
             (this.sharedStatus!=null &&
              this.sharedStatus.equals(other.getSharedStatus()))) &&
            ((this.spreads==null && other.getSpreads()==null) || 
             (this.spreads!=null &&
              java.util.Arrays.equals(this.spreads, other.getSpreads()))) &&
            ((this.tables==null && other.getTables()==null) || 
             (this.tables!=null &&
              java.util.Arrays.equals(this.tables, other.getTables())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getArticles() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArticles());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArticles(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLayers() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLayers());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLayers(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLayoutProperty() != null) {
            _hashCode += getLayoutProperty().hashCode();
        }
        if (getMediaType() != null) {
            _hashCode += getMediaType().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getPointsPerInch() != null) {
            _hashCode += getPointsPerInch().hashCode();
        }
        if (getSharedStatus() != null) {
            _hashCode += getSharedStatus().hashCode();
        }
        if (getSpreads() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSpreads());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSpreads(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTables() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTables());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTables(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Layout.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Layout"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("articles");
        elemField.setXmlName(new javax.xml.namespace.QName("", "articles"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Article"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "boxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Box"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layers");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Layer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutProperty");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layoutProperty"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LayoutProperty"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mediaType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mediaType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pointsPerInch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pointsPerInch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sharedStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sharedStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spreads");
        elemField.setXmlName(new javax.xml.namespace.QName("", "spreads"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Spread"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tables");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tables"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Table"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
