/**
 * BottomGrid.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class BottomGrid  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String color;

    private java.lang.String gapColor;

    private java.lang.String gapOpacity;

    private java.lang.String gapShade;

    private java.lang.String opacity;

    private java.lang.String shade;

    private java.lang.String style;

    private java.lang.String width;

    public BottomGrid() {
    }

    public BottomGrid(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String color,
           java.lang.String gapColor,
           java.lang.String gapOpacity,
           java.lang.String gapShade,
           java.lang.String opacity,
           java.lang.String shade,
           java.lang.String style,
           java.lang.String width) {
        super(
            request);
        this.color = color;
        this.gapColor = gapColor;
        this.gapOpacity = gapOpacity;
        this.gapShade = gapShade;
        this.opacity = opacity;
        this.shade = shade;
        this.style = style;
        this.width = width;
    }


    /**
     * Gets the color value for this BottomGrid.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this BottomGrid.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the gapColor value for this BottomGrid.
     * 
     * @return gapColor
     */
    public java.lang.String getGapColor() {
        return gapColor;
    }


    /**
     * Sets the gapColor value for this BottomGrid.
     * 
     * @param gapColor
     */
    public void setGapColor(java.lang.String gapColor) {
        this.gapColor = gapColor;
    }


    /**
     * Gets the gapOpacity value for this BottomGrid.
     * 
     * @return gapOpacity
     */
    public java.lang.String getGapOpacity() {
        return gapOpacity;
    }


    /**
     * Sets the gapOpacity value for this BottomGrid.
     * 
     * @param gapOpacity
     */
    public void setGapOpacity(java.lang.String gapOpacity) {
        this.gapOpacity = gapOpacity;
    }


    /**
     * Gets the gapShade value for this BottomGrid.
     * 
     * @return gapShade
     */
    public java.lang.String getGapShade() {
        return gapShade;
    }


    /**
     * Sets the gapShade value for this BottomGrid.
     * 
     * @param gapShade
     */
    public void setGapShade(java.lang.String gapShade) {
        this.gapShade = gapShade;
    }


    /**
     * Gets the opacity value for this BottomGrid.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this BottomGrid.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the shade value for this BottomGrid.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this BottomGrid.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the style value for this BottomGrid.
     * 
     * @return style
     */
    public java.lang.String getStyle() {
        return style;
    }


    /**
     * Sets the style value for this BottomGrid.
     * 
     * @param style
     */
    public void setStyle(java.lang.String style) {
        this.style = style;
    }


    /**
     * Gets the width value for this BottomGrid.
     * 
     * @return width
     */
    public java.lang.String getWidth() {
        return width;
    }


    /**
     * Sets the width value for this BottomGrid.
     * 
     * @param width
     */
    public void setWidth(java.lang.String width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BottomGrid)) return false;
        BottomGrid other = (BottomGrid) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.gapColor==null && other.getGapColor()==null) || 
             (this.gapColor!=null &&
              this.gapColor.equals(other.getGapColor()))) &&
            ((this.gapOpacity==null && other.getGapOpacity()==null) || 
             (this.gapOpacity!=null &&
              this.gapOpacity.equals(other.getGapOpacity()))) &&
            ((this.gapShade==null && other.getGapShade()==null) || 
             (this.gapShade!=null &&
              this.gapShade.equals(other.getGapShade()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.style==null && other.getStyle()==null) || 
             (this.style!=null &&
              this.style.equals(other.getStyle()))) &&
            ((this.width==null && other.getWidth()==null) || 
             (this.width!=null &&
              this.width.equals(other.getWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getGapColor() != null) {
            _hashCode += getGapColor().hashCode();
        }
        if (getGapOpacity() != null) {
            _hashCode += getGapOpacity().hashCode();
        }
        if (getGapShade() != null) {
            _hashCode += getGapShade().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getStyle() != null) {
            _hashCode += getStyle().hashCode();
        }
        if (getWidth() != null) {
            _hashCode += getWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BottomGrid.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "BottomGrid"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gapColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "gapColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gapOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "gapOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gapShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "gapShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("style");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "style"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("width");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "width"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
