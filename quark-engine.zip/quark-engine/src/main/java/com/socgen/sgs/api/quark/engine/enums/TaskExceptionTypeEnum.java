package com.socgen.sgs.api.quark.engine.enums;
public enum TaskExceptionTypeEnum {
    NONE,
    LINE,
    TABLE,
    GROUP;
    public static TaskExceptionTypeEnum fromName(String name) {
        if (name == null) {
            return NONE;
        }
        try {
            return valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return NONE;
        }
    }
}
