package com.socgen.sgs.api.quark.engine.enums;

import lombok.Getter;

/**
 * Enumeration representing the type of report (rapport).
 * Defines different report types that can be generated.
 */
@Getter
public enum TypeRapportEnum {

    /**
     * Unknown report type - used as a fallback value.
     */
    UNKNOWN(0, "Unknown"),

    /**
     * Annual Report (Rapport Annuel).
     * Standard yearly financial report.
     */
    RAPPORT_ANNUEL(1, "Rapport_Annuel"),

    /**
     * Brochure/Prospectus (Plaquette).
     * Marketing or informational brochure document.
     */
    PLAQUETTE(2, "Plaquette"),

    /**
     * Prospectus (Propectus).
     * Investment prospectus document.
     */
    PROSPECTUS(3, "Propectus"),

    /**
     * Compartment Report (Rapport Compartiment).
     * Report specific to a compartment or fund division.
     */
    RAPPORT_COMPARTIMENT(4, "Rapport_Compartiment"),

    /**
     * DICI Document.
     * Key Information Document (KID) for investment products.
     */
    DICI(5, "DICI");

    private final int code;
    private final String label;

    TypeRapportEnum(int code, String label) {
        this.code = code;
        this.label = label;
    }

    /**
     * Get TypeRapportEnum from integer code.
     *
     * @param code the numeric code
     * @return the corresponding TypeRapportEnum, or UNKNOWN if not found
     */
    public static TypeRapportEnum fromCode(int code) {
        for (TypeRapportEnum type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        return UNKNOWN;
    }

    /**
     * Get TypeRapportEnum from string label.
     *
     * @param label the string label (case-insensitive)
     * @return the corresponding TypeRapportEnum, or UNKNOWN if not found
     */
    public static TypeRapportEnum fromLabel(String label) {
        if (label == null) {
            return UNKNOWN;
        }
        for (TypeRapportEnum type : values()) {
            if (type.label.equalsIgnoreCase(label)) {
                return type;
            }
        }
        return UNKNOWN;
    }
}
