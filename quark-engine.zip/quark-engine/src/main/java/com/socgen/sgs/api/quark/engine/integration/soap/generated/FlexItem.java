/**
 * FlexItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class FlexItem  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignSelf;

    private java.lang.String flex;

    private java.lang.String flexBasis;

    private java.lang.String flexGrow;

    private java.lang.String flexShrink;

    private java.lang.String height;

    private java.lang.String maxHeight;

    private java.lang.String maxWidth;

    private java.lang.String minHeight;

    private java.lang.String minWidth;

    private java.lang.String order;

    private java.lang.String overflow;

    private java.lang.String position;

    private java.lang.String width;

    public FlexItem() {
    }

    public FlexItem(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignSelf,
           java.lang.String flex,
           java.lang.String flexBasis,
           java.lang.String flexGrow,
           java.lang.String flexShrink,
           java.lang.String height,
           java.lang.String maxHeight,
           java.lang.String maxWidth,
           java.lang.String minHeight,
           java.lang.String minWidth,
           java.lang.String order,
           java.lang.String overflow,
           java.lang.String position,
           java.lang.String width) {
        super(
            request);
        this.alignSelf = alignSelf;
        this.flex = flex;
        this.flexBasis = flexBasis;
        this.flexGrow = flexGrow;
        this.flexShrink = flexShrink;
        this.height = height;
        this.maxHeight = maxHeight;
        this.maxWidth = maxWidth;
        this.minHeight = minHeight;
        this.minWidth = minWidth;
        this.order = order;
        this.overflow = overflow;
        this.position = position;
        this.width = width;
    }


    /**
     * Gets the alignSelf value for this FlexItem.
     * 
     * @return alignSelf
     */
    public java.lang.String getAlignSelf() {
        return alignSelf;
    }


    /**
     * Sets the alignSelf value for this FlexItem.
     * 
     * @param alignSelf
     */
    public void setAlignSelf(java.lang.String alignSelf) {
        this.alignSelf = alignSelf;
    }


    /**
     * Gets the flex value for this FlexItem.
     * 
     * @return flex
     */
    public java.lang.String getFlex() {
        return flex;
    }


    /**
     * Sets the flex value for this FlexItem.
     * 
     * @param flex
     */
    public void setFlex(java.lang.String flex) {
        this.flex = flex;
    }


    /**
     * Gets the flexBasis value for this FlexItem.
     * 
     * @return flexBasis
     */
    public java.lang.String getFlexBasis() {
        return flexBasis;
    }


    /**
     * Sets the flexBasis value for this FlexItem.
     * 
     * @param flexBasis
     */
    public void setFlexBasis(java.lang.String flexBasis) {
        this.flexBasis = flexBasis;
    }


    /**
     * Gets the flexGrow value for this FlexItem.
     * 
     * @return flexGrow
     */
    public java.lang.String getFlexGrow() {
        return flexGrow;
    }


    /**
     * Sets the flexGrow value for this FlexItem.
     * 
     * @param flexGrow
     */
    public void setFlexGrow(java.lang.String flexGrow) {
        this.flexGrow = flexGrow;
    }


    /**
     * Gets the flexShrink value for this FlexItem.
     * 
     * @return flexShrink
     */
    public java.lang.String getFlexShrink() {
        return flexShrink;
    }


    /**
     * Sets the flexShrink value for this FlexItem.
     * 
     * @param flexShrink
     */
    public void setFlexShrink(java.lang.String flexShrink) {
        this.flexShrink = flexShrink;
    }


    /**
     * Gets the height value for this FlexItem.
     * 
     * @return height
     */
    public java.lang.String getHeight() {
        return height;
    }


    /**
     * Sets the height value for this FlexItem.
     * 
     * @param height
     */
    public void setHeight(java.lang.String height) {
        this.height = height;
    }


    /**
     * Gets the maxHeight value for this FlexItem.
     * 
     * @return maxHeight
     */
    public java.lang.String getMaxHeight() {
        return maxHeight;
    }


    /**
     * Sets the maxHeight value for this FlexItem.
     * 
     * @param maxHeight
     */
    public void setMaxHeight(java.lang.String maxHeight) {
        this.maxHeight = maxHeight;
    }


    /**
     * Gets the maxWidth value for this FlexItem.
     * 
     * @return maxWidth
     */
    public java.lang.String getMaxWidth() {
        return maxWidth;
    }


    /**
     * Sets the maxWidth value for this FlexItem.
     * 
     * @param maxWidth
     */
    public void setMaxWidth(java.lang.String maxWidth) {
        this.maxWidth = maxWidth;
    }


    /**
     * Gets the minHeight value for this FlexItem.
     * 
     * @return minHeight
     */
    public java.lang.String getMinHeight() {
        return minHeight;
    }


    /**
     * Sets the minHeight value for this FlexItem.
     * 
     * @param minHeight
     */
    public void setMinHeight(java.lang.String minHeight) {
        this.minHeight = minHeight;
    }


    /**
     * Gets the minWidth value for this FlexItem.
     * 
     * @return minWidth
     */
    public java.lang.String getMinWidth() {
        return minWidth;
    }


    /**
     * Sets the minWidth value for this FlexItem.
     * 
     * @param minWidth
     */
    public void setMinWidth(java.lang.String minWidth) {
        this.minWidth = minWidth;
    }


    /**
     * Gets the order value for this FlexItem.
     * 
     * @return order
     */
    public java.lang.String getOrder() {
        return order;
    }


    /**
     * Sets the order value for this FlexItem.
     * 
     * @param order
     */
    public void setOrder(java.lang.String order) {
        this.order = order;
    }


    /**
     * Gets the overflow value for this FlexItem.
     * 
     * @return overflow
     */
    public java.lang.String getOverflow() {
        return overflow;
    }


    /**
     * Sets the overflow value for this FlexItem.
     * 
     * @param overflow
     */
    public void setOverflow(java.lang.String overflow) {
        this.overflow = overflow;
    }


    /**
     * Gets the position value for this FlexItem.
     * 
     * @return position
     */
    public java.lang.String getPosition() {
        return position;
    }


    /**
     * Sets the position value for this FlexItem.
     * 
     * @param position
     */
    public void setPosition(java.lang.String position) {
        this.position = position;
    }


    /**
     * Gets the width value for this FlexItem.
     * 
     * @return width
     */
    public java.lang.String getWidth() {
        return width;
    }


    /**
     * Sets the width value for this FlexItem.
     * 
     * @param width
     */
    public void setWidth(java.lang.String width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FlexItem)) return false;
        FlexItem other = (FlexItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignSelf==null && other.getAlignSelf()==null) || 
             (this.alignSelf!=null &&
              this.alignSelf.equals(other.getAlignSelf()))) &&
            ((this.flex==null && other.getFlex()==null) || 
             (this.flex!=null &&
              this.flex.equals(other.getFlex()))) &&
            ((this.flexBasis==null && other.getFlexBasis()==null) || 
             (this.flexBasis!=null &&
              this.flexBasis.equals(other.getFlexBasis()))) &&
            ((this.flexGrow==null && other.getFlexGrow()==null) || 
             (this.flexGrow!=null &&
              this.flexGrow.equals(other.getFlexGrow()))) &&
            ((this.flexShrink==null && other.getFlexShrink()==null) || 
             (this.flexShrink!=null &&
              this.flexShrink.equals(other.getFlexShrink()))) &&
            ((this.height==null && other.getHeight()==null) || 
             (this.height!=null &&
              this.height.equals(other.getHeight()))) &&
            ((this.maxHeight==null && other.getMaxHeight()==null) || 
             (this.maxHeight!=null &&
              this.maxHeight.equals(other.getMaxHeight()))) &&
            ((this.maxWidth==null && other.getMaxWidth()==null) || 
             (this.maxWidth!=null &&
              this.maxWidth.equals(other.getMaxWidth()))) &&
            ((this.minHeight==null && other.getMinHeight()==null) || 
             (this.minHeight!=null &&
              this.minHeight.equals(other.getMinHeight()))) &&
            ((this.minWidth==null && other.getMinWidth()==null) || 
             (this.minWidth!=null &&
              this.minWidth.equals(other.getMinWidth()))) &&
            ((this.order==null && other.getOrder()==null) || 
             (this.order!=null &&
              this.order.equals(other.getOrder()))) &&
            ((this.overflow==null && other.getOverflow()==null) || 
             (this.overflow!=null &&
              this.overflow.equals(other.getOverflow()))) &&
            ((this.position==null && other.getPosition()==null) || 
             (this.position!=null &&
              this.position.equals(other.getPosition()))) &&
            ((this.width==null && other.getWidth()==null) || 
             (this.width!=null &&
              this.width.equals(other.getWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignSelf() != null) {
            _hashCode += getAlignSelf().hashCode();
        }
        if (getFlex() != null) {
            _hashCode += getFlex().hashCode();
        }
        if (getFlexBasis() != null) {
            _hashCode += getFlexBasis().hashCode();
        }
        if (getFlexGrow() != null) {
            _hashCode += getFlexGrow().hashCode();
        }
        if (getFlexShrink() != null) {
            _hashCode += getFlexShrink().hashCode();
        }
        if (getHeight() != null) {
            _hashCode += getHeight().hashCode();
        }
        if (getMaxHeight() != null) {
            _hashCode += getMaxHeight().hashCode();
        }
        if (getMaxWidth() != null) {
            _hashCode += getMaxWidth().hashCode();
        }
        if (getMinHeight() != null) {
            _hashCode += getMinHeight().hashCode();
        }
        if (getMinWidth() != null) {
            _hashCode += getMinWidth().hashCode();
        }
        if (getOrder() != null) {
            _hashCode += getOrder().hashCode();
        }
        if (getOverflow() != null) {
            _hashCode += getOverflow().hashCode();
        }
        if (getPosition() != null) {
            _hashCode += getPosition().hashCode();
        }
        if (getWidth() != null) {
            _hashCode += getWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FlexItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "FlexItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignSelf");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignSelf"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "flex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flexBasis");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "flexBasis"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flexGrow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "flexGrow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flexShrink");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "flexShrink"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("height");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "height"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxHeight");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "maxHeight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "maxWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minHeight");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "minHeight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "minWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "order"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overflow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "overflow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("position");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "position"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("width");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "width"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
