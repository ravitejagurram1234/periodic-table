package com.socgen.sgs.api.quark.engine.enums;

import lombok.Getter;

/**
 * Represents the data type of an input parameter.
 */
@Getter
public enum DataTypeEnum {

    UNSPECIFIED(0),
    TEXT(1),
    INT(2),
    DECIMAL(3),
    DATE(4),
    DATE_TIME(5),
    CURRENCY(6),
    POURCENTAGE(7),
    CUSTOM(99);

    private final int code;

    DataTypeEnum(int code) {
        this.code = code;
    }

    public static DataTypeEnum fromCode(int code) {
        for (DataTypeEnum type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        return UNSPECIFIED;
    }
}
