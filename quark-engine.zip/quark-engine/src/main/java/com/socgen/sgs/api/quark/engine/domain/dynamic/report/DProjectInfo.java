package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

/**
 * Holds structural information about a QuarkXPress project
 * deduced from the XML structure (number of spreads, boxes per page, etc.).
 *
 * Cross-reference: QXP.Engine.Core.DProject_Info
 */
@Getter
@Setter
public class DProjectInfo {

    /** Project name from the PROJECT element. */
    private String name;

    /** XML version from the PROJECT element. */
    private String xmlVersion;

    /** Number of boxes per page. Key = page number, Value = box count. */
    private Map<Integer, Integer> pageBoxes = new HashMap<>();

    /** Total number of spreads in the project. */
    private int nbSpread;

    /** Total number of boxes in the project. */
    private int nbBox;

    public DProjectInfo() {
    }

    /**
     * Get the number of boxes on a specific page.
     *
     * @param page the page number
     * @return the number of boxes on that page, or 0 if no boxes
     */
    public int getNbBoxOnPage(int page) {
        return pageBoxes.getOrDefault(page, 0);
    }

    /**
     * Get the total number of pages (derived from pageBoxes key count).
     *
     * @return number of pages
     */
    public int getNbPage() {
        return pageBoxes.size();
    }
}