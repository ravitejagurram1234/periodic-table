package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.enums.DocumentFormatEnum;
import com.socgen.sgs.api.quark.engine.enums.SubTaskTypeEnum;
import lombok.Getter;
import lombok.Setter;

/** Represents a task that inserts a document or document fragment. */
@Getter
@Setter
public class TaskDocument extends TaskBase {

    private String formatDocument;
    private boolean rotationImage = false;
    private int idSousCategorie;
    private boolean conserverStyle = false;
    private String offsetValues;
    private TaskImageOffset imageOffset;
    private DocumentDomain document;
    private String positionValues;
    private TaskImagePosition imagePosition;

    public TaskDocument(int id, Run run) {
        super(id, run);
    }

    @Override
    public void prepare() {
        DocumentFormatEnum format = DocumentFormatEnum.fromFormat(this.formatDocument);
        if (format == null) {
            this.setSubTaskType(SubTaskTypeEnum.UNKNOWN);
            return;
        }

        switch (format) {
            case PDF:
                this.setSubTaskType(SubTaskTypeEnum.FILE_PDF);
                this.setToLoad(true);
                break;
            case JPG:
            case JPEG:
            case EPS:
            case TIF:
            case TIFF:
            case GIF:
                this.setSubTaskType(SubTaskTypeEnum.FILE_IMG);
                this.setToLoad(true);
                break;
            case RTF:
                this.setSubTaskType(SubTaskTypeEnum.FILE_RTF);
                break;
            case DOC:
                this.setSubTaskType(SubTaskTypeEnum.FILE_DOC);
                break;
            case XTG:
                this.setSubTaskType(SubTaskTypeEnum.FILE_XTG);
                break;
            case QXP:
                this.setSubTaskType(SubTaskTypeEnum.FILE_QXP_DATA);
                break;
            default:
                this.setSubTaskType(SubTaskTypeEnum.UNKNOWN);
                break;
        }

        // Document loading is delegated to the business/service layer
    }

    public String resolveTargetBlocName() {
        switch (this.getSubTaskType()) {
            case FILE_PDF:
                return this.getDestinationBlocName() + "_1";
            case FILE_QXP_DATA:
                String dest = this.getDestinationBlocName() != null ? this.getDestinationBlocName() : "";
                String[] blocNames = dest.split("\\|");
                return blocNames.length > 0 ? blocNames[0] : dest;
            default:
                return this.getDestinationBlocName();
        }
    }

    @Override
    public boolean isModeDegrade() {
        return this.document != null && this.document.isModeDegrade();
    }
}


