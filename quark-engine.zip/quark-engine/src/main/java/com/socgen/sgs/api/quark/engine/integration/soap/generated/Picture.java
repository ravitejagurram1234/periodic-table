/**
 * Picture.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Picture  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String angle;

    private java.lang.String clearPicture;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Clipping clipping;

    private java.lang.String fit;

    private java.lang.String flipHorizontal;

    private java.lang.String flipVertical;

    private java.lang.String fullResolution;

    private java.lang.String mask;

    private java.lang.String offsetAcross;

    private java.lang.String offsetDown;

    private java.lang.String opacity;

    private java.lang.String picBackGroundColor;

    private java.lang.String picBackGroundOpacity;

    private java.lang.String picBackGroundShade;

    private java.lang.String pictureColor;

    private java.lang.String scaleAcross;

    private java.lang.String scaleDown;

    private java.lang.String shade;

    private java.lang.String skew;

    private java.lang.String supressPicture;

    public Picture() {
    }

    public Picture(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String angle,
           java.lang.String clearPicture,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Clipping clipping,
           java.lang.String fit,
           java.lang.String flipHorizontal,
           java.lang.String flipVertical,
           java.lang.String fullResolution,
           java.lang.String mask,
           java.lang.String offsetAcross,
           java.lang.String offsetDown,
           java.lang.String opacity,
           java.lang.String picBackGroundColor,
           java.lang.String picBackGroundOpacity,
           java.lang.String picBackGroundShade,
           java.lang.String pictureColor,
           java.lang.String scaleAcross,
           java.lang.String scaleDown,
           java.lang.String shade,
           java.lang.String skew,
           java.lang.String supressPicture) {
        super(
            request);
        this.angle = angle;
        this.clearPicture = clearPicture;
        this.clipping = clipping;
        this.fit = fit;
        this.flipHorizontal = flipHorizontal;
        this.flipVertical = flipVertical;
        this.fullResolution = fullResolution;
        this.mask = mask;
        this.offsetAcross = offsetAcross;
        this.offsetDown = offsetDown;
        this.opacity = opacity;
        this.picBackGroundColor = picBackGroundColor;
        this.picBackGroundOpacity = picBackGroundOpacity;
        this.picBackGroundShade = picBackGroundShade;
        this.pictureColor = pictureColor;
        this.scaleAcross = scaleAcross;
        this.scaleDown = scaleDown;
        this.shade = shade;
        this.skew = skew;
        this.supressPicture = supressPicture;
    }


    /**
     * Gets the angle value for this Picture.
     * 
     * @return angle
     */
    public java.lang.String getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this Picture.
     * 
     * @param angle
     */
    public void setAngle(java.lang.String angle) {
        this.angle = angle;
    }


    /**
     * Gets the clearPicture value for this Picture.
     * 
     * @return clearPicture
     */
    public java.lang.String getClearPicture() {
        return clearPicture;
    }


    /**
     * Sets the clearPicture value for this Picture.
     * 
     * @param clearPicture
     */
    public void setClearPicture(java.lang.String clearPicture) {
        this.clearPicture = clearPicture;
    }


    /**
     * Gets the clipping value for this Picture.
     * 
     * @return clipping
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Clipping getClipping() {
        return clipping;
    }


    /**
     * Sets the clipping value for this Picture.
     * 
     * @param clipping
     */
    public void setClipping(com.socgen.sgs.api.quark.engine.integration.soap.generated.Clipping clipping) {
        this.clipping = clipping;
    }


    /**
     * Gets the fit value for this Picture.
     * 
     * @return fit
     */
    public java.lang.String getFit() {
        return fit;
    }


    /**
     * Sets the fit value for this Picture.
     * 
     * @param fit
     */
    public void setFit(java.lang.String fit) {
        this.fit = fit;
    }


    /**
     * Gets the flipHorizontal value for this Picture.
     * 
     * @return flipHorizontal
     */
    public java.lang.String getFlipHorizontal() {
        return flipHorizontal;
    }


    /**
     * Sets the flipHorizontal value for this Picture.
     * 
     * @param flipHorizontal
     */
    public void setFlipHorizontal(java.lang.String flipHorizontal) {
        this.flipHorizontal = flipHorizontal;
    }


    /**
     * Gets the flipVertical value for this Picture.
     * 
     * @return flipVertical
     */
    public java.lang.String getFlipVertical() {
        return flipVertical;
    }


    /**
     * Sets the flipVertical value for this Picture.
     * 
     * @param flipVertical
     */
    public void setFlipVertical(java.lang.String flipVertical) {
        this.flipVertical = flipVertical;
    }


    /**
     * Gets the fullResolution value for this Picture.
     * 
     * @return fullResolution
     */
    public java.lang.String getFullResolution() {
        return fullResolution;
    }


    /**
     * Sets the fullResolution value for this Picture.
     * 
     * @param fullResolution
     */
    public void setFullResolution(java.lang.String fullResolution) {
        this.fullResolution = fullResolution;
    }


    /**
     * Gets the mask value for this Picture.
     * 
     * @return mask
     */
    public java.lang.String getMask() {
        return mask;
    }


    /**
     * Sets the mask value for this Picture.
     * 
     * @param mask
     */
    public void setMask(java.lang.String mask) {
        this.mask = mask;
    }


    /**
     * Gets the offsetAcross value for this Picture.
     * 
     * @return offsetAcross
     */
    public java.lang.String getOffsetAcross() {
        return offsetAcross;
    }


    /**
     * Sets the offsetAcross value for this Picture.
     * 
     * @param offsetAcross
     */
    public void setOffsetAcross(java.lang.String offsetAcross) {
        this.offsetAcross = offsetAcross;
    }


    /**
     * Gets the offsetDown value for this Picture.
     * 
     * @return offsetDown
     */
    public java.lang.String getOffsetDown() {
        return offsetDown;
    }


    /**
     * Sets the offsetDown value for this Picture.
     * 
     * @param offsetDown
     */
    public void setOffsetDown(java.lang.String offsetDown) {
        this.offsetDown = offsetDown;
    }


    /**
     * Gets the opacity value for this Picture.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this Picture.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the picBackGroundColor value for this Picture.
     * 
     * @return picBackGroundColor
     */
    public java.lang.String getPicBackGroundColor() {
        return picBackGroundColor;
    }


    /**
     * Sets the picBackGroundColor value for this Picture.
     * 
     * @param picBackGroundColor
     */
    public void setPicBackGroundColor(java.lang.String picBackGroundColor) {
        this.picBackGroundColor = picBackGroundColor;
    }


    /**
     * Gets the picBackGroundOpacity value for this Picture.
     * 
     * @return picBackGroundOpacity
     */
    public java.lang.String getPicBackGroundOpacity() {
        return picBackGroundOpacity;
    }


    /**
     * Sets the picBackGroundOpacity value for this Picture.
     * 
     * @param picBackGroundOpacity
     */
    public void setPicBackGroundOpacity(java.lang.String picBackGroundOpacity) {
        this.picBackGroundOpacity = picBackGroundOpacity;
    }


    /**
     * Gets the picBackGroundShade value for this Picture.
     * 
     * @return picBackGroundShade
     */
    public java.lang.String getPicBackGroundShade() {
        return picBackGroundShade;
    }


    /**
     * Sets the picBackGroundShade value for this Picture.
     * 
     * @param picBackGroundShade
     */
    public void setPicBackGroundShade(java.lang.String picBackGroundShade) {
        this.picBackGroundShade = picBackGroundShade;
    }


    /**
     * Gets the pictureColor value for this Picture.
     * 
     * @return pictureColor
     */
    public java.lang.String getPictureColor() {
        return pictureColor;
    }


    /**
     * Sets the pictureColor value for this Picture.
     * 
     * @param pictureColor
     */
    public void setPictureColor(java.lang.String pictureColor) {
        this.pictureColor = pictureColor;
    }


    /**
     * Gets the scaleAcross value for this Picture.
     * 
     * @return scaleAcross
     */
    public java.lang.String getScaleAcross() {
        return scaleAcross;
    }


    /**
     * Sets the scaleAcross value for this Picture.
     * 
     * @param scaleAcross
     */
    public void setScaleAcross(java.lang.String scaleAcross) {
        this.scaleAcross = scaleAcross;
    }


    /**
     * Gets the scaleDown value for this Picture.
     * 
     * @return scaleDown
     */
    public java.lang.String getScaleDown() {
        return scaleDown;
    }


    /**
     * Sets the scaleDown value for this Picture.
     * 
     * @param scaleDown
     */
    public void setScaleDown(java.lang.String scaleDown) {
        this.scaleDown = scaleDown;
    }


    /**
     * Gets the shade value for this Picture.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this Picture.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the skew value for this Picture.
     * 
     * @return skew
     */
    public java.lang.String getSkew() {
        return skew;
    }


    /**
     * Sets the skew value for this Picture.
     * 
     * @param skew
     */
    public void setSkew(java.lang.String skew) {
        this.skew = skew;
    }


    /**
     * Gets the supressPicture value for this Picture.
     * 
     * @return supressPicture
     */
    public java.lang.String getSupressPicture() {
        return supressPicture;
    }


    /**
     * Sets the supressPicture value for this Picture.
     * 
     * @param supressPicture
     */
    public void setSupressPicture(java.lang.String supressPicture) {
        this.supressPicture = supressPicture;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Picture)) return false;
        Picture other = (Picture) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.angle==null && other.getAngle()==null) || 
             (this.angle!=null &&
              this.angle.equals(other.getAngle()))) &&
            ((this.clearPicture==null && other.getClearPicture()==null) || 
             (this.clearPicture!=null &&
              this.clearPicture.equals(other.getClearPicture()))) &&
            ((this.clipping==null && other.getClipping()==null) || 
             (this.clipping!=null &&
              this.clipping.equals(other.getClipping()))) &&
            ((this.fit==null && other.getFit()==null) || 
             (this.fit!=null &&
              this.fit.equals(other.getFit()))) &&
            ((this.flipHorizontal==null && other.getFlipHorizontal()==null) || 
             (this.flipHorizontal!=null &&
              this.flipHorizontal.equals(other.getFlipHorizontal()))) &&
            ((this.flipVertical==null && other.getFlipVertical()==null) || 
             (this.flipVertical!=null &&
              this.flipVertical.equals(other.getFlipVertical()))) &&
            ((this.fullResolution==null && other.getFullResolution()==null) || 
             (this.fullResolution!=null &&
              this.fullResolution.equals(other.getFullResolution()))) &&
            ((this.mask==null && other.getMask()==null) || 
             (this.mask!=null &&
              this.mask.equals(other.getMask()))) &&
            ((this.offsetAcross==null && other.getOffsetAcross()==null) || 
             (this.offsetAcross!=null &&
              this.offsetAcross.equals(other.getOffsetAcross()))) &&
            ((this.offsetDown==null && other.getOffsetDown()==null) || 
             (this.offsetDown!=null &&
              this.offsetDown.equals(other.getOffsetDown()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.picBackGroundColor==null && other.getPicBackGroundColor()==null) || 
             (this.picBackGroundColor!=null &&
              this.picBackGroundColor.equals(other.getPicBackGroundColor()))) &&
            ((this.picBackGroundOpacity==null && other.getPicBackGroundOpacity()==null) || 
             (this.picBackGroundOpacity!=null &&
              this.picBackGroundOpacity.equals(other.getPicBackGroundOpacity()))) &&
            ((this.picBackGroundShade==null && other.getPicBackGroundShade()==null) || 
             (this.picBackGroundShade!=null &&
              this.picBackGroundShade.equals(other.getPicBackGroundShade()))) &&
            ((this.pictureColor==null && other.getPictureColor()==null) || 
             (this.pictureColor!=null &&
              this.pictureColor.equals(other.getPictureColor()))) &&
            ((this.scaleAcross==null && other.getScaleAcross()==null) || 
             (this.scaleAcross!=null &&
              this.scaleAcross.equals(other.getScaleAcross()))) &&
            ((this.scaleDown==null && other.getScaleDown()==null) || 
             (this.scaleDown!=null &&
              this.scaleDown.equals(other.getScaleDown()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.skew==null && other.getSkew()==null) || 
             (this.skew!=null &&
              this.skew.equals(other.getSkew()))) &&
            ((this.supressPicture==null && other.getSupressPicture()==null) || 
             (this.supressPicture!=null &&
              this.supressPicture.equals(other.getSupressPicture())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAngle() != null) {
            _hashCode += getAngle().hashCode();
        }
        if (getClearPicture() != null) {
            _hashCode += getClearPicture().hashCode();
        }
        if (getClipping() != null) {
            _hashCode += getClipping().hashCode();
        }
        if (getFit() != null) {
            _hashCode += getFit().hashCode();
        }
        if (getFlipHorizontal() != null) {
            _hashCode += getFlipHorizontal().hashCode();
        }
        if (getFlipVertical() != null) {
            _hashCode += getFlipVertical().hashCode();
        }
        if (getFullResolution() != null) {
            _hashCode += getFullResolution().hashCode();
        }
        if (getMask() != null) {
            _hashCode += getMask().hashCode();
        }
        if (getOffsetAcross() != null) {
            _hashCode += getOffsetAcross().hashCode();
        }
        if (getOffsetDown() != null) {
            _hashCode += getOffsetDown().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getPicBackGroundColor() != null) {
            _hashCode += getPicBackGroundColor().hashCode();
        }
        if (getPicBackGroundOpacity() != null) {
            _hashCode += getPicBackGroundOpacity().hashCode();
        }
        if (getPicBackGroundShade() != null) {
            _hashCode += getPicBackGroundShade().hashCode();
        }
        if (getPictureColor() != null) {
            _hashCode += getPictureColor().hashCode();
        }
        if (getScaleAcross() != null) {
            _hashCode += getScaleAcross().hashCode();
        }
        if (getScaleDown() != null) {
            _hashCode += getScaleDown().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getSkew() != null) {
            _hashCode += getSkew().hashCode();
        }
        if (getSupressPicture() != null) {
            _hashCode += getSupressPicture().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Picture.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Picture"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("angle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "angle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clearPicture");
        elemField.setXmlName(new javax.xml.namespace.QName("", "clearPicture"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clipping");
        elemField.setXmlName(new javax.xml.namespace.QName("", "clipping"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Clipping"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flipHorizontal");
        elemField.setXmlName(new javax.xml.namespace.QName("", "flipHorizontal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flipVertical");
        elemField.setXmlName(new javax.xml.namespace.QName("", "flipVertical"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fullResolution");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fullResolution"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mask");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mask"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offsetAcross");
        elemField.setXmlName(new javax.xml.namespace.QName("", "offsetAcross"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offsetDown");
        elemField.setXmlName(new javax.xml.namespace.QName("", "offsetDown"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picBackGroundColor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "picBackGroundColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picBackGroundOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "picBackGroundOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picBackGroundShade");
        elemField.setXmlName(new javax.xml.namespace.QName("", "picBackGroundShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pictureColor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pictureColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleAcross");
        elemField.setXmlName(new javax.xml.namespace.QName("", "scaleAcross"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleDown");
        elemField.setXmlName(new javax.xml.namespace.QName("", "scaleDown"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("skew");
        elemField.setXmlName(new javax.xml.namespace.QName("", "skew"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supressPicture");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supressPicture"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
