package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

/**
 * Contains spatial information for a DTable.
 * Currently empty — reserved for future use.
 *
 * Cross-reference: QXP.Engine.Core.DTable_Info
 */
public class DTableInfo {

    public DTableInfo() {
    }
}