/**
 * Cell.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Cell  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String addToReflow;

    private java.lang.String articleName;

    private java.lang.String blendAngle;

    private java.lang.String blendColor;

    private java.lang.String blendOpacity;

    private java.lang.String blendShape;

    private java.lang.String blendStyle;

    private java.lang.String boxType;

    private java.lang.String color;

    private java.lang.String columnCount;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder contentPlaceholder;

    private java.lang.String HLAnchorRef;

    private java.lang.String HLType;

    private java.lang.String hyperlinkRef;

    private java.lang.String mergeColSpan;

    private java.lang.String mergeRowSpan;

    private java.lang.String name;

    private java.lang.String opacity;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder placeholder;

    private java.lang.String shade;

    private java.lang.String split;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Text text;

    private java.lang.String UID;

    public Cell() {
    }

    public Cell(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String addToReflow,
           java.lang.String articleName,
           java.lang.String blendAngle,
           java.lang.String blendColor,
           java.lang.String blendOpacity,
           java.lang.String blendShape,
           java.lang.String blendStyle,
           java.lang.String boxType,
           java.lang.String color,
           java.lang.String columnCount,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder contentPlaceholder,
           java.lang.String HLAnchorRef,
           java.lang.String HLType,
           java.lang.String hyperlinkRef,
           java.lang.String mergeColSpan,
           java.lang.String mergeRowSpan,
           java.lang.String name,
           java.lang.String opacity,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder placeholder,
           java.lang.String shade,
           java.lang.String split,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Text text,
           java.lang.String UID) {
        super(
            request);
        this.addToReflow = addToReflow;
        this.articleName = articleName;
        this.blendAngle = blendAngle;
        this.blendColor = blendColor;
        this.blendOpacity = blendOpacity;
        this.blendShape = blendShape;
        this.blendStyle = blendStyle;
        this.boxType = boxType;
        this.color = color;
        this.columnCount = columnCount;
        this.content = content;
        this.contentPlaceholder = contentPlaceholder;
        this.HLAnchorRef = HLAnchorRef;
        this.HLType = HLType;
        this.hyperlinkRef = hyperlinkRef;
        this.mergeColSpan = mergeColSpan;
        this.mergeRowSpan = mergeRowSpan;
        this.name = name;
        this.opacity = opacity;
        this.picture = picture;
        this.placeholder = placeholder;
        this.shade = shade;
        this.split = split;
        this.text = text;
        this.UID = UID;
    }


    /**
     * Gets the addToReflow value for this Cell.
     * 
     * @return addToReflow
     */
    public java.lang.String getAddToReflow() {
        return addToReflow;
    }


    /**
     * Sets the addToReflow value for this Cell.
     * 
     * @param addToReflow
     */
    public void setAddToReflow(java.lang.String addToReflow) {
        this.addToReflow = addToReflow;
    }


    /**
     * Gets the articleName value for this Cell.
     * 
     * @return articleName
     */
    public java.lang.String getArticleName() {
        return articleName;
    }


    /**
     * Sets the articleName value for this Cell.
     * 
     * @param articleName
     */
    public void setArticleName(java.lang.String articleName) {
        this.articleName = articleName;
    }


    /**
     * Gets the blendAngle value for this Cell.
     * 
     * @return blendAngle
     */
    public java.lang.String getBlendAngle() {
        return blendAngle;
    }


    /**
     * Sets the blendAngle value for this Cell.
     * 
     * @param blendAngle
     */
    public void setBlendAngle(java.lang.String blendAngle) {
        this.blendAngle = blendAngle;
    }


    /**
     * Gets the blendColor value for this Cell.
     * 
     * @return blendColor
     */
    public java.lang.String getBlendColor() {
        return blendColor;
    }


    /**
     * Sets the blendColor value for this Cell.
     * 
     * @param blendColor
     */
    public void setBlendColor(java.lang.String blendColor) {
        this.blendColor = blendColor;
    }


    /**
     * Gets the blendOpacity value for this Cell.
     * 
     * @return blendOpacity
     */
    public java.lang.String getBlendOpacity() {
        return blendOpacity;
    }


    /**
     * Sets the blendOpacity value for this Cell.
     * 
     * @param blendOpacity
     */
    public void setBlendOpacity(java.lang.String blendOpacity) {
        this.blendOpacity = blendOpacity;
    }


    /**
     * Gets the blendShape value for this Cell.
     * 
     * @return blendShape
     */
    public java.lang.String getBlendShape() {
        return blendShape;
    }


    /**
     * Sets the blendShape value for this Cell.
     * 
     * @param blendShape
     */
    public void setBlendShape(java.lang.String blendShape) {
        this.blendShape = blendShape;
    }


    /**
     * Gets the blendStyle value for this Cell.
     * 
     * @return blendStyle
     */
    public java.lang.String getBlendStyle() {
        return blendStyle;
    }


    /**
     * Sets the blendStyle value for this Cell.
     * 
     * @param blendStyle
     */
    public void setBlendStyle(java.lang.String blendStyle) {
        this.blendStyle = blendStyle;
    }


    /**
     * Gets the boxType value for this Cell.
     * 
     * @return boxType
     */
    public java.lang.String getBoxType() {
        return boxType;
    }


    /**
     * Sets the boxType value for this Cell.
     * 
     * @param boxType
     */
    public void setBoxType(java.lang.String boxType) {
        this.boxType = boxType;
    }


    /**
     * Gets the color value for this Cell.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this Cell.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the columnCount value for this Cell.
     * 
     * @return columnCount
     */
    public java.lang.String getColumnCount() {
        return columnCount;
    }


    /**
     * Sets the columnCount value for this Cell.
     * 
     * @param columnCount
     */
    public void setColumnCount(java.lang.String columnCount) {
        this.columnCount = columnCount;
    }


    /**
     * Gets the content value for this Cell.
     * 
     * @return content
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Content getContent() {
        return content;
    }


    /**
     * Sets the content value for this Cell.
     * 
     * @param content
     */
    public void setContent(com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content) {
        this.content = content;
    }


    /**
     * Gets the contentPlaceholder value for this Cell.
     * 
     * @return contentPlaceholder
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder getContentPlaceholder() {
        return contentPlaceholder;
    }


    /**
     * Sets the contentPlaceholder value for this Cell.
     * 
     * @param contentPlaceholder
     */
    public void setContentPlaceholder(com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder contentPlaceholder) {
        this.contentPlaceholder = contentPlaceholder;
    }


    /**
     * Gets the HLAnchorRef value for this Cell.
     * 
     * @return HLAnchorRef
     */
    public java.lang.String getHLAnchorRef() {
        return HLAnchorRef;
    }


    /**
     * Sets the HLAnchorRef value for this Cell.
     * 
     * @param HLAnchorRef
     */
    public void setHLAnchorRef(java.lang.String HLAnchorRef) {
        this.HLAnchorRef = HLAnchorRef;
    }


    /**
     * Gets the HLType value for this Cell.
     * 
     * @return HLType
     */
    public java.lang.String getHLType() {
        return HLType;
    }


    /**
     * Sets the HLType value for this Cell.
     * 
     * @param HLType
     */
    public void setHLType(java.lang.String HLType) {
        this.HLType = HLType;
    }


    /**
     * Gets the hyperlinkRef value for this Cell.
     * 
     * @return hyperlinkRef
     */
    public java.lang.String getHyperlinkRef() {
        return hyperlinkRef;
    }


    /**
     * Sets the hyperlinkRef value for this Cell.
     * 
     * @param hyperlinkRef
     */
    public void setHyperlinkRef(java.lang.String hyperlinkRef) {
        this.hyperlinkRef = hyperlinkRef;
    }


    /**
     * Gets the mergeColSpan value for this Cell.
     * 
     * @return mergeColSpan
     */
    public java.lang.String getMergeColSpan() {
        return mergeColSpan;
    }


    /**
     * Sets the mergeColSpan value for this Cell.
     * 
     * @param mergeColSpan
     */
    public void setMergeColSpan(java.lang.String mergeColSpan) {
        this.mergeColSpan = mergeColSpan;
    }


    /**
     * Gets the mergeRowSpan value for this Cell.
     * 
     * @return mergeRowSpan
     */
    public java.lang.String getMergeRowSpan() {
        return mergeRowSpan;
    }


    /**
     * Sets the mergeRowSpan value for this Cell.
     * 
     * @param mergeRowSpan
     */
    public void setMergeRowSpan(java.lang.String mergeRowSpan) {
        this.mergeRowSpan = mergeRowSpan;
    }


    /**
     * Gets the name value for this Cell.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Cell.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the opacity value for this Cell.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this Cell.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the picture value for this Cell.
     * 
     * @return picture
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture getPicture() {
        return picture;
    }


    /**
     * Sets the picture value for this Cell.
     * 
     * @param picture
     */
    public void setPicture(com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture) {
        this.picture = picture;
    }


    /**
     * Gets the placeholder value for this Cell.
     * 
     * @return placeholder
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder getPlaceholder() {
        return placeholder;
    }


    /**
     * Sets the placeholder value for this Cell.
     * 
     * @param placeholder
     */
    public void setPlaceholder(com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder placeholder) {
        this.placeholder = placeholder;
    }


    /**
     * Gets the shade value for this Cell.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this Cell.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the split value for this Cell.
     * 
     * @return split
     */
    public java.lang.String getSplit() {
        return split;
    }


    /**
     * Sets the split value for this Cell.
     * 
     * @param split
     */
    public void setSplit(java.lang.String split) {
        this.split = split;
    }


    /**
     * Gets the text value for this Cell.
     * 
     * @return text
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Text getText() {
        return text;
    }


    /**
     * Sets the text value for this Cell.
     * 
     * @param text
     */
    public void setText(com.socgen.sgs.api.quark.engine.integration.soap.generated.Text text) {
        this.text = text;
    }


    /**
     * Gets the UID value for this Cell.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Cell.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Cell)) return false;
        Cell other = (Cell) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.addToReflow==null && other.getAddToReflow()==null) || 
             (this.addToReflow!=null &&
              this.addToReflow.equals(other.getAddToReflow()))) &&
            ((this.articleName==null && other.getArticleName()==null) || 
             (this.articleName!=null &&
              this.articleName.equals(other.getArticleName()))) &&
            ((this.blendAngle==null && other.getBlendAngle()==null) || 
             (this.blendAngle!=null &&
              this.blendAngle.equals(other.getBlendAngle()))) &&
            ((this.blendColor==null && other.getBlendColor()==null) || 
             (this.blendColor!=null &&
              this.blendColor.equals(other.getBlendColor()))) &&
            ((this.blendOpacity==null && other.getBlendOpacity()==null) || 
             (this.blendOpacity!=null &&
              this.blendOpacity.equals(other.getBlendOpacity()))) &&
            ((this.blendShape==null && other.getBlendShape()==null) || 
             (this.blendShape!=null &&
              this.blendShape.equals(other.getBlendShape()))) &&
            ((this.blendStyle==null && other.getBlendStyle()==null) || 
             (this.blendStyle!=null &&
              this.blendStyle.equals(other.getBlendStyle()))) &&
            ((this.boxType==null && other.getBoxType()==null) || 
             (this.boxType!=null &&
              this.boxType.equals(other.getBoxType()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.columnCount==null && other.getColumnCount()==null) || 
             (this.columnCount!=null &&
              this.columnCount.equals(other.getColumnCount()))) &&
            ((this.content==null && other.getContent()==null) || 
             (this.content!=null &&
              this.content.equals(other.getContent()))) &&
            ((this.contentPlaceholder==null && other.getContentPlaceholder()==null) || 
             (this.contentPlaceholder!=null &&
              this.contentPlaceholder.equals(other.getContentPlaceholder()))) &&
            ((this.HLAnchorRef==null && other.getHLAnchorRef()==null) || 
             (this.HLAnchorRef!=null &&
              this.HLAnchorRef.equals(other.getHLAnchorRef()))) &&
            ((this.HLType==null && other.getHLType()==null) || 
             (this.HLType!=null &&
              this.HLType.equals(other.getHLType()))) &&
            ((this.hyperlinkRef==null && other.getHyperlinkRef()==null) || 
             (this.hyperlinkRef!=null &&
              this.hyperlinkRef.equals(other.getHyperlinkRef()))) &&
            ((this.mergeColSpan==null && other.getMergeColSpan()==null) || 
             (this.mergeColSpan!=null &&
              this.mergeColSpan.equals(other.getMergeColSpan()))) &&
            ((this.mergeRowSpan==null && other.getMergeRowSpan()==null) || 
             (this.mergeRowSpan!=null &&
              this.mergeRowSpan.equals(other.getMergeRowSpan()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.picture==null && other.getPicture()==null) || 
             (this.picture!=null &&
              this.picture.equals(other.getPicture()))) &&
            ((this.placeholder==null && other.getPlaceholder()==null) || 
             (this.placeholder!=null &&
              this.placeholder.equals(other.getPlaceholder()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.split==null && other.getSplit()==null) || 
             (this.split!=null &&
              this.split.equals(other.getSplit()))) &&
            ((this.text==null && other.getText()==null) || 
             (this.text!=null &&
              this.text.equals(other.getText()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAddToReflow() != null) {
            _hashCode += getAddToReflow().hashCode();
        }
        if (getArticleName() != null) {
            _hashCode += getArticleName().hashCode();
        }
        if (getBlendAngle() != null) {
            _hashCode += getBlendAngle().hashCode();
        }
        if (getBlendColor() != null) {
            _hashCode += getBlendColor().hashCode();
        }
        if (getBlendOpacity() != null) {
            _hashCode += getBlendOpacity().hashCode();
        }
        if (getBlendShape() != null) {
            _hashCode += getBlendShape().hashCode();
        }
        if (getBlendStyle() != null) {
            _hashCode += getBlendStyle().hashCode();
        }
        if (getBoxType() != null) {
            _hashCode += getBoxType().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getColumnCount() != null) {
            _hashCode += getColumnCount().hashCode();
        }
        if (getContent() != null) {
            _hashCode += getContent().hashCode();
        }
        if (getContentPlaceholder() != null) {
            _hashCode += getContentPlaceholder().hashCode();
        }
        if (getHLAnchorRef() != null) {
            _hashCode += getHLAnchorRef().hashCode();
        }
        if (getHLType() != null) {
            _hashCode += getHLType().hashCode();
        }
        if (getHyperlinkRef() != null) {
            _hashCode += getHyperlinkRef().hashCode();
        }
        if (getMergeColSpan() != null) {
            _hashCode += getMergeColSpan().hashCode();
        }
        if (getMergeRowSpan() != null) {
            _hashCode += getMergeRowSpan().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getPicture() != null) {
            _hashCode += getPicture().hashCode();
        }
        if (getPlaceholder() != null) {
            _hashCode += getPlaceholder().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getSplit() != null) {
            _hashCode += getSplit().hashCode();
        }
        if (getText() != null) {
            _hashCode += getText().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Cell.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Cell"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addToReflow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "addToReflow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("articleName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "articleName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendAngle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendAngle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendShape");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendShape"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("content");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "content"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Content"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentPlaceholder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "contentPlaceholder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ContentPlaceholder"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HLAnchorRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HLAnchorRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HLType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HLType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hyperlinkRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hyperlinkRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mergeColSpan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "mergeColSpan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mergeRowSpan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "mergeRowSpan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picture");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "picture"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Picture"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("placeholder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "placeholder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Placeholder"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("split");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "split"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("text");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "text"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Text"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
