package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDao;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDocumentCertifieDao;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDocumentDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Business component responsible for orchestrating the retrieval and preparation of gabarit documents.
 * Handles all gabarit source types: GABARIT, DOCUMENT_COURANT, DOCUMENT_PRECEDENT_CERTIFIE, DOCUMENT_SUIVI.
 * The fetched document paths are resolved using RunProperties pool path methods.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class GetGabaritBusiness {

    private final GetGabaritDao getGabaritDao;
    private final GetGabaritDocumentDao getGabaritDocumentDao;
    private final GetGabaritDocumentCertifieDao getGabaritDocumentCertifieDao;

    @Value("${documentpool.basePath:D:\\Documents}")
    private String documentPoolBasePath;

    /**
     * Fetches the gabarit from template (GABARIT source).
     * Calls Get_Gabarit with idGabarit.
     *
     * @param runProperties the run properties for path generation
     * @param idGabarit     the gabarit ID from run properties
     * @return DocumentDomain with prepared pool paths
     */
    public DocumentDomain getAndPrepareGabarit(RunProperties runProperties, Integer idGabarit) {
        log.info("Fetching gabarit for idGabarit: {}", idGabarit);
        DocumentDomain gabarit = getGabaritDao.getGabarit(idGabarit);
        return preparePaths(gabarit, runProperties);
    }

    /**
     * Fetches the gabarit from the previously generated document on the current follow-up (DOCUMENT_COURANT source).
     * Calls Get_Gabarit_Document with idSuivi.
     *
     * @param runProperties the run properties for path generation
     * @param idSuivi       the follow-up ID from run properties
     * @return DocumentDomain with prepared pool paths
     */
    public DocumentDomain getAndPrepareGabaritDocumentCourant(RunProperties runProperties, Integer idSuivi) {
        log.info("Fetching gabarit document courant for idSuivi: {}", idSuivi);
        DocumentDomain gabarit = getGabaritDocumentDao.getGabaritDocument(idSuivi);
        return preparePaths(gabarit, runProperties);
    }

    /**
     * Fetches the gabarit from the last certified document on a previous follow-up (DOCUMENT_PRECEDENT_CERTIFIE source).
     * Calls Get_Gabarit_Document_Certifie with idSuivi.
     *
     * @param runProperties the run properties for path generation
     * @param idSuivi       the follow-up ID from run properties
     * @return DocumentDomain with prepared pool paths
     */
    public DocumentDomain getAndPrepareGabaritDocumentCertifie(RunProperties runProperties, Integer idSuivi) {
        log.info("Fetching certified gabarit document for idSuivi: {}", idSuivi);
        DocumentDomain gabarit = getGabaritDocumentCertifieDao.getGabaritDocumentCertifie(idSuivi);
        return preparePaths(gabarit, runProperties);
    }

    /**
     * Fetches the gabarit from the document of a specific follow-up (DOCUMENT_SUIVI source).
     * Calls Get_Gabarit_Document with idSuiviGabaritSource.
     *
     * @param runProperties         the run properties for path generation
     * @param idSuiviGabaritSource  the specific follow-up ID from run properties
     * @return DocumentDomain with prepared pool paths
     */
    public DocumentDomain getAndPrepareGabaritDocumentSuivi(RunProperties runProperties, Integer idSuiviGabaritSource) {
        log.info("Fetching gabarit document suivi for idSuiviGabaritSource: {}", idSuiviGabaritSource);
        DocumentDomain gabarit = getGabaritDocumentDao.getGabaritDocument(idSuiviGabaritSource);
        return preparePaths(gabarit, runProperties);
    }

    /**
     * Resolves pool path and absolute path for the given document using run properties.
     */
    private DocumentDomain preparePaths(DocumentDomain gabarit, RunProperties runProperties) {
        if (gabarit.getFileName() != null) {
            gabarit.setFilePoolPath(runProperties.getPoolPath(gabarit.getFileName()));
            gabarit.setFileFullPath(runProperties.getPoolPathAbsolute(gabarit.getFileName(), documentPoolBasePath));
        }
        log.info("Prepared gabarit paths - poolPath: {}, fullPath: {}",
                gabarit.getFilePoolPath(), gabarit.getFileFullPath());
        return gabarit;
    }
}
