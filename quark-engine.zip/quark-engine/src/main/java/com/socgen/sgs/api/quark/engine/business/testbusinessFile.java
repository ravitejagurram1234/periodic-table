package com.socgen.sgs.api.quark.engine.business;

public class testbusinessFile {
    //commented code.
    int var = 10;
}
