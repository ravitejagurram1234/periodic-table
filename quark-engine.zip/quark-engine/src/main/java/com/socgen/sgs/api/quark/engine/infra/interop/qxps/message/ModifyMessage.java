package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * QXPS GET message for applying structural modifications to a document.
 * The modify XML file must have been previously uploaded via AddFileMessage.
 *
 * URL: {baseUrl}/{documentName}?modify=file:{modifyFileName}
 * NOTE: path is NULL — modify goes in the query string, not the path.
 *
 * Cross-reference: .NET QXPS_Message_Modify
 */
@Getter
@RequiredArgsConstructor
public class ModifyMessage implements QxpsMessage {

    private static final String QUERY_PATTERN = "modify=file:%s";

    /** The pool path of the previously uploaded modify XML file. */
    private final String modifyFileName;

    @Override
    public String getCommandPath() {
        return null;
    }

    @Override
    public String getCommandQuery() {
        return String.format(QUERY_PATTERN, modifyFileName);
    }

    @Override
    public byte[] getData() {
        return null;
    }

    @Override
    public boolean isPost() {
        return false;
    }
}
