/**
 * KeepLinesTogether.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class KeepLinesTogether  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String allLinesInPara;

    private java.lang.String enabled;

    private java.lang.String endLine;

    private java.lang.String startLine;

    public KeepLinesTogether() {
    }

    public KeepLinesTogether(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String allLinesInPara,
           java.lang.String enabled,
           java.lang.String endLine,
           java.lang.String startLine) {
        super(
            request);
        this.allLinesInPara = allLinesInPara;
        this.enabled = enabled;
        this.endLine = endLine;
        this.startLine = startLine;
    }


    /**
     * Gets the allLinesInPara value for this KeepLinesTogether.
     * 
     * @return allLinesInPara
     */
    public java.lang.String getAllLinesInPara() {
        return allLinesInPara;
    }


    /**
     * Sets the allLinesInPara value for this KeepLinesTogether.
     * 
     * @param allLinesInPara
     */
    public void setAllLinesInPara(java.lang.String allLinesInPara) {
        this.allLinesInPara = allLinesInPara;
    }


    /**
     * Gets the enabled value for this KeepLinesTogether.
     * 
     * @return enabled
     */
    public java.lang.String getEnabled() {
        return enabled;
    }


    /**
     * Sets the enabled value for this KeepLinesTogether.
     * 
     * @param enabled
     */
    public void setEnabled(java.lang.String enabled) {
        this.enabled = enabled;
    }


    /**
     * Gets the endLine value for this KeepLinesTogether.
     * 
     * @return endLine
     */
    public java.lang.String getEndLine() {
        return endLine;
    }


    /**
     * Sets the endLine value for this KeepLinesTogether.
     * 
     * @param endLine
     */
    public void setEndLine(java.lang.String endLine) {
        this.endLine = endLine;
    }


    /**
     * Gets the startLine value for this KeepLinesTogether.
     * 
     * @return startLine
     */
    public java.lang.String getStartLine() {
        return startLine;
    }


    /**
     * Sets the startLine value for this KeepLinesTogether.
     * 
     * @param startLine
     */
    public void setStartLine(java.lang.String startLine) {
        this.startLine = startLine;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof KeepLinesTogether)) return false;
        KeepLinesTogether other = (KeepLinesTogether) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.allLinesInPara==null && other.getAllLinesInPara()==null) || 
             (this.allLinesInPara!=null &&
              this.allLinesInPara.equals(other.getAllLinesInPara()))) &&
            ((this.enabled==null && other.getEnabled()==null) || 
             (this.enabled!=null &&
              this.enabled.equals(other.getEnabled()))) &&
            ((this.endLine==null && other.getEndLine()==null) || 
             (this.endLine!=null &&
              this.endLine.equals(other.getEndLine()))) &&
            ((this.startLine==null && other.getStartLine()==null) || 
             (this.startLine!=null &&
              this.startLine.equals(other.getStartLine())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAllLinesInPara() != null) {
            _hashCode += getAllLinesInPara().hashCode();
        }
        if (getEnabled() != null) {
            _hashCode += getEnabled().hashCode();
        }
        if (getEndLine() != null) {
            _hashCode += getEndLine().hashCode();
        }
        if (getStartLine() != null) {
            _hashCode += getStartLine().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(KeepLinesTogether.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "KeepLinesTogether"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allLinesInPara");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "allLinesInPara"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enabled");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "enabled"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endLine");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "endLine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startLine");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "startLine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
