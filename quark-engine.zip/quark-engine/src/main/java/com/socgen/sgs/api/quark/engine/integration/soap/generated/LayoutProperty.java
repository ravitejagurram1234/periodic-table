/**
 * LayoutProperty.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class LayoutProperty  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String automaticBox;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnGuides columnGuides;

    private java.lang.String facingPages;

    private java.lang.String height;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Margins margins;

    private java.lang.String storyDirection;

    private java.lang.String width;

    public LayoutProperty() {
    }

    public LayoutProperty(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String automaticBox,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnGuides columnGuides,
           java.lang.String facingPages,
           java.lang.String height,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Margins margins,
           java.lang.String storyDirection,
           java.lang.String width) {
        super(
            request);
        this.automaticBox = automaticBox;
        this.columnGuides = columnGuides;
        this.facingPages = facingPages;
        this.height = height;
        this.margins = margins;
        this.storyDirection = storyDirection;
        this.width = width;
    }


    /**
     * Gets the automaticBox value for this LayoutProperty.
     * 
     * @return automaticBox
     */
    public java.lang.String getAutomaticBox() {
        return automaticBox;
    }


    /**
     * Sets the automaticBox value for this LayoutProperty.
     * 
     * @param automaticBox
     */
    public void setAutomaticBox(java.lang.String automaticBox) {
        this.automaticBox = automaticBox;
    }


    /**
     * Gets the columnGuides value for this LayoutProperty.
     * 
     * @return columnGuides
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnGuides getColumnGuides() {
        return columnGuides;
    }


    /**
     * Sets the columnGuides value for this LayoutProperty.
     * 
     * @param columnGuides
     */
    public void setColumnGuides(com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnGuides columnGuides) {
        this.columnGuides = columnGuides;
    }


    /**
     * Gets the facingPages value for this LayoutProperty.
     * 
     * @return facingPages
     */
    public java.lang.String getFacingPages() {
        return facingPages;
    }


    /**
     * Sets the facingPages value for this LayoutProperty.
     * 
     * @param facingPages
     */
    public void setFacingPages(java.lang.String facingPages) {
        this.facingPages = facingPages;
    }


    /**
     * Gets the height value for this LayoutProperty.
     * 
     * @return height
     */
    public java.lang.String getHeight() {
        return height;
    }


    /**
     * Sets the height value for this LayoutProperty.
     * 
     * @param height
     */
    public void setHeight(java.lang.String height) {
        this.height = height;
    }


    /**
     * Gets the margins value for this LayoutProperty.
     * 
     * @return margins
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Margins getMargins() {
        return margins;
    }


    /**
     * Sets the margins value for this LayoutProperty.
     * 
     * @param margins
     */
    public void setMargins(com.socgen.sgs.api.quark.engine.integration.soap.generated.Margins margins) {
        this.margins = margins;
    }


    /**
     * Gets the storyDirection value for this LayoutProperty.
     * 
     * @return storyDirection
     */
    public java.lang.String getStoryDirection() {
        return storyDirection;
    }


    /**
     * Sets the storyDirection value for this LayoutProperty.
     * 
     * @param storyDirection
     */
    public void setStoryDirection(java.lang.String storyDirection) {
        this.storyDirection = storyDirection;
    }


    /**
     * Gets the width value for this LayoutProperty.
     * 
     * @return width
     */
    public java.lang.String getWidth() {
        return width;
    }


    /**
     * Sets the width value for this LayoutProperty.
     * 
     * @param width
     */
    public void setWidth(java.lang.String width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LayoutProperty)) return false;
        LayoutProperty other = (LayoutProperty) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.automaticBox==null && other.getAutomaticBox()==null) || 
             (this.automaticBox!=null &&
              this.automaticBox.equals(other.getAutomaticBox()))) &&
            ((this.columnGuides==null && other.getColumnGuides()==null) || 
             (this.columnGuides!=null &&
              this.columnGuides.equals(other.getColumnGuides()))) &&
            ((this.facingPages==null && other.getFacingPages()==null) || 
             (this.facingPages!=null &&
              this.facingPages.equals(other.getFacingPages()))) &&
            ((this.height==null && other.getHeight()==null) || 
             (this.height!=null &&
              this.height.equals(other.getHeight()))) &&
            ((this.margins==null && other.getMargins()==null) || 
             (this.margins!=null &&
              this.margins.equals(other.getMargins()))) &&
            ((this.storyDirection==null && other.getStoryDirection()==null) || 
             (this.storyDirection!=null &&
              this.storyDirection.equals(other.getStoryDirection()))) &&
            ((this.width==null && other.getWidth()==null) || 
             (this.width!=null &&
              this.width.equals(other.getWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAutomaticBox() != null) {
            _hashCode += getAutomaticBox().hashCode();
        }
        if (getColumnGuides() != null) {
            _hashCode += getColumnGuides().hashCode();
        }
        if (getFacingPages() != null) {
            _hashCode += getFacingPages().hashCode();
        }
        if (getHeight() != null) {
            _hashCode += getHeight().hashCode();
        }
        if (getMargins() != null) {
            _hashCode += getMargins().hashCode();
        }
        if (getStoryDirection() != null) {
            _hashCode += getStoryDirection().hashCode();
        }
        if (getWidth() != null) {
            _hashCode += getWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LayoutProperty.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LayoutProperty"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("automaticBox");
        elemField.setXmlName(new javax.xml.namespace.QName("", "automaticBox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnGuides");
        elemField.setXmlName(new javax.xml.namespace.QName("", "columnGuides"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ColumnGuides"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("facingPages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "facingPages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("height");
        elemField.setXmlName(new javax.xml.namespace.QName("", "height"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("margins");
        elemField.setXmlName(new javax.xml.namespace.QName("", "margins"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Margins"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("storyDirection");
        elemField.setXmlName(new javax.xml.namespace.QName("", "storyDirection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("width");
        elemField.setXmlName(new javax.xml.namespace.QName("", "width"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
