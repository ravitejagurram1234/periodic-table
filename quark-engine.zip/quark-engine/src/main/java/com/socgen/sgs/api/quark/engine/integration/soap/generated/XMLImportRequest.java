/**
 * XMLImportRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class XMLImportRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String layout;

    private java.lang.String paginate;

    private java.lang.String XMLDocument;

    public XMLImportRequest() {
    }

    public XMLImportRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String layout,
           java.lang.String paginate,
           java.lang.String XMLDocument) {
        super(
            request);
        this.layout = layout;
        this.paginate = paginate;
        this.XMLDocument = XMLDocument;
    }


    /**
     * Gets the layout value for this XMLImportRequest.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this XMLImportRequest.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the paginate value for this XMLImportRequest.
     * 
     * @return paginate
     */
    public java.lang.String getPaginate() {
        return paginate;
    }


    /**
     * Sets the paginate value for this XMLImportRequest.
     * 
     * @param paginate
     */
    public void setPaginate(java.lang.String paginate) {
        this.paginate = paginate;
    }


    /**
     * Gets the XMLDocument value for this XMLImportRequest.
     * 
     * @return XMLDocument
     */
    public java.lang.String getXMLDocument() {
        return XMLDocument;
    }


    /**
     * Sets the XMLDocument value for this XMLImportRequest.
     * 
     * @param XMLDocument
     */
    public void setXMLDocument(java.lang.String XMLDocument) {
        this.XMLDocument = XMLDocument;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof XMLImportRequest)) return false;
        XMLImportRequest other = (XMLImportRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.paginate==null && other.getPaginate()==null) || 
             (this.paginate!=null &&
              this.paginate.equals(other.getPaginate()))) &&
            ((this.XMLDocument==null && other.getXMLDocument()==null) || 
             (this.XMLDocument!=null &&
              this.XMLDocument.equals(other.getXMLDocument())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getPaginate() != null) {
            _hashCode += getPaginate().hashCode();
        }
        if (getXMLDocument() != null) {
            _hashCode += getXMLDocument().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(XMLImportRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "XMLImportRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paginate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "paginate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("XMLDocument");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "XMLDocument"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
