package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.service.task.TaskPostProcessService;
import com.socgen.sgs.api.quark.engine.service.task.TaskPostProcessStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/** Dispatches task post-processing to the matching strategy bean. */
@Service
@Slf4j
public class TaskPostProcessServiceImpl implements TaskPostProcessService {

    @SuppressWarnings("rawtypes")
    private final Map<Class, TaskPostProcessStrategy> strategyMap;

    @SuppressWarnings("rawtypes")
    public TaskPostProcessServiceImpl(List<TaskPostProcessStrategy> strategies) {
        this.strategyMap = strategies.stream()
                .collect(Collectors.toMap(TaskPostProcessStrategy::getTaskType, Function.identity()));
        log.info("Registered {} task post-process strategies: {}", strategyMap.size(), strategyMap.keySet());
    }

    @Override
    @SuppressWarnings("unchecked")
    public void postProcess(TaskBase task) {
        TaskPostProcessStrategy strategy = strategyMap.get(task.getClass());
        if (strategy != null) {
            strategy.postProcess(task);
        } else {
            log.debug("No post-process strategy for task type: {}", task.getClass().getSimpleName());
        }
    }
}

