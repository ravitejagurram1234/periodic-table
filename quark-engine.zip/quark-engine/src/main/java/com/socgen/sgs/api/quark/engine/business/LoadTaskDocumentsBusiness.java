package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunError;
import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.domain.port.FilePoolPort;
import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.domain.task.TaskDocument;
import com.socgen.sgs.api.quark.engine.domain.task.TaskQxpPrevious;
import com.socgen.sgs.api.quark.engine.enums.SubTaskTypeEnum;
import com.socgen.sgs.api.quark.engine.infra.dao.GetDocumentDao;
import com.socgen.sgs.api.quark.engine.infra.dao.GetLastQxpCertifieDao;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.config.QxpsProperties;
import com.socgen.sgs.api.quark.engine.infra.pdf.PdfSplitter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Loads each task's reference/previous document during the Prepare phase and uploads it to the
 * QuarkXPress pool (PDFs are split per page), so the task strategies can read/insert it.
 *
 * <p>This is the service → business → (dao + infra) bridge for what .NET does inside
 * {@code Task_Document.Prepare()} and {@code Task_QXP_Previous.Prepare()} (document loading is
 * intentionally kept out of the Java domain {@code prepare()} methods). All pool writes go through
 * the Quark API ({@link FilePoolPort#addFile}) — never local files — honouring the Kubernetes
 * remote-host constraint.
 *
 * <p>Cross-reference: .NET Task_Document.Prepare (Get_Document + Addfile + PDF split) and
 * Task_QXP_Previous.Prepare (Get_Last_Qxp_Certifie + Addfile).
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class LoadTaskDocumentsBusiness {

    private static final String PDF_PAGE_NAME_PATTERN = "%s_%d_p%d.pdf"; // prefix, id, page (1-based)
    private static final String PREVIOUS_TYPE_ANY = "any";
    private static final String PREVIOUS_TYPE_SAME = "same";

    private final GetDocumentDao getDocumentDao;
    private final GetLastQxpCertifieDao getLastQxpCertifieDao;
    private final FilePoolPort filePool;
    private final PdfSplitter pdfSplitter;
    private final GetGabaritXmlBusiness getGabaritXmlBusiness;
    private final GetDocumentProjectBusiness getDocumentProjectBusiness;
    private final QxpsProperties qxpsProperties;

    /** Load + pool-upload documents for every task that needs one. */
    public void loadDocuments(Run run) {
        String basePath = qxpsProperties.getPool().getDefaultPath();
        for (TaskBase task : run.getTasks().values()) {
            try {
                if (task instanceof TaskDocument) {
                    loadDocumentTask(run, (TaskDocument) task, basePath);
                } else if (task instanceof TaskQxpPrevious) {
                    loadQxpPreviousTask(run, (TaskQxpPrevious) task, basePath);
                }
            } catch (Exception e) {
                task.setInError(true);
                run.getErrors().add(new RunError(RunError.CRITIQUE,
                        "Erreur lors du chargement du document de la tache " + task.getId() + " : " + e.getMessage()));
                log.error("Error loading document for task {}: {}", task.getId(), e.getMessage(), e);
            }
        }
    }

    // ------------------------------------------------------------------
    // TaskDocument — Cross-reference: .NET Task_Document.Prepare
    // ------------------------------------------------------------------

    private void loadDocumentTask(Run run, TaskDocument task, String basePath) {
        // .NET: (ToLoad || Todo) && IsSet(Id_Sous_Categorie, false)  (i.e. sous-categorie != 0)
        if (!(task.isToLoad() || task.isTodo()) || task.getIdSousCategorie() == 0) {
            return;
        }

        RunProperties props = run.getRunProperties();
        DocumentDomain doc = getDocumentDao.getDocument(
                task.getIdSousCategorie(), props.getIdFndCode(), props.getIdUnitCode(),
                props.getSociete(), props.getIdLangue(), props.getDateEcheance());

        if (doc == null) {
            // .NET Errors.Add(Document_Null, ...) → Unspecified severity.
            run.getErrors().add(new RunError(RunError.UNSPECIFIED,
                    "Document_Null: aucun document pour la sous-categorie " + task.getIdSousCategorie()
                            + " (tache " + task.getId() + ")"));
            log.warn("No document found for task {} (sousCategorie {})", task.getId(), task.getIdSousCategorie());
            return;
        }

        completePaths(doc, props, basePath);
//        markModeDegradeIfTooBig(doc, run);
        task.setDocument(doc);

        SubTaskTypeEnum subType = task.getSubTaskType();
        if (subType == SubTaskTypeEnum.FILE_PDF) {
            loadPdfPages(doc, props, basePath);
        } else if (subType == SubTaskTypeEnum.FILE_QXP_DATA) {
            // Upload the source QXP then load its XML (always) / project (only when keeping style).
            filePool.addFile(doc.getFilePoolPath(), doc.getData());
            loadQxpSource(doc, task.isConserverStyle());
        } else {
            // IMG / DOC / RTF / XTG — upload the file as-is.
            filePool.addFile(doc.getFilePoolPath(), doc.getData());
        }
    }

    /** PDF: split into pages, upload each page to the pool, expose the per-page absolute paths. */
    private void loadPdfPages(DocumentDomain doc, RunProperties props, String basePath) {
        List<byte[]> pages = pdfSplitter.split(doc.getData());
        List<String> pdfFiles = new ArrayList<>();
        for (int i = 0; i < pages.size(); i++) {
            String pageName = String.format(PDF_PAGE_NAME_PATTERN, doc.getPrefix(), doc.getId(), i + 1);
            filePool.addFile(props.getPoolPath(pageName), pages.get(i));
            // The strategy uses these entries directly as the picture content value (absolute host path).
            pdfFiles.add(props.getPoolPathAbsolute(pageName, basePath));
        }
        doc.setPdfFiles(pdfFiles);
        log.info("Loaded {} PDF page(s) for document {}", pdfFiles.size(), doc.getId());
    }

    // ------------------------------------------------------------------
    // TaskQxpPrevious — Cross-reference: .NET Task_QXP_Previous.Prepare
    // ------------------------------------------------------------------

    private void loadQxpPreviousTask(Run run, TaskQxpPrevious task, String basePath) {
        // .NET: this.Todo && IsNull(this.Document)  (the null-check eases standalone debugging).
        if (!task.isTodo() || task.getDocument() != null) {
            return;
        }

        RunProperties props = run.getRunProperties();
        int previousTypeRapport = resolvePreviousTypeRapport(props, task.getPreviousTypeRapport());

        DocumentDomain doc = getLastQxpCertifieDao.getLastQxpCertifie(props.getIdSuivi(), previousTypeRapport);
        if (doc == null) {
            // .NET Errors.Add(Document_LastQxp_Null, ...) then Todo = false.
            run.getErrors().add(new RunError(RunError.UNSPECIFIED,
                    "Document_LastQxp_Null: aucun QXP certifie precedent pour le suivi " + props.getIdSuivi()
                            + " (type rapport " + previousTypeRapport + ", tache " + task.getId() + ")"));
            log.warn("No previous certified QXP for task {} (suivi {}, typeRapport {})",
                    task.getId(), props.getIdSuivi(), previousTypeRapport);
            task.setTodo(false);
            return;
        }

        completePaths(doc, props, basePath);
//        markModeDegradeIfTooBig(doc, run);
        // Upload so getXPressDOM / fetchXml can read the source structure back.
        filePool.addFile(doc.getFilePoolPath(), doc.getData());
        loadQxpSource(doc, task.isConserverStyle());
        task.setDocument(doc);
    }

    /**
     * Resolve the certified report type to search for.
     * .NET: default = current run's report type; "any" → 0; "same" → keep default; else parse int.
     */
    private int resolvePreviousTypeRapport(RunProperties props, String previousType) {
        int type = props.getTypeRapport() != null ? props.getTypeRapport().getCode() : 0;
        if (previousType != null && !previousType.isBlank()) {
            if (PREVIOUS_TYPE_ANY.equals(previousType)) {
                type = 0;
            } else if (!PREVIOUS_TYPE_SAME.equals(previousType)) {
                try {
                    int parsed = Integer.parseInt(previousType.trim());
                    if (parsed > 0) {
                        type = parsed;
                    }
                } catch (NumberFormatException e) {
                    log.warn("Invalid previousTypeRapport [{}], using default {}", previousType, type);
                }
            }
        }
        return type;
    }

    // ------------------------------------------------------------------
    // Shared helpers
    // ------------------------------------------------------------------

    /** Fill pool-relative path + absolute (Windows) host path from the run pool + base path. */
    private void completePaths(DocumentDomain doc, RunProperties props, String basePath) {
        String fileName = doc.getFileName();
        doc.setFilePoolPath(props.getPoolPath(fileName));
        doc.setFileFullPath(props.getPoolPathAbsolute(fileName, basePath));
    }

    /** A reference doc exceeding the run size limit flags the (task) document as degraded. */
//    private void markModeDegradeIfTooBig(DocumentDomain doc, Run run) {
//        if (doc.getData() != null && doc.getData().length > run.getSizeLimitBeforeFailSoft()) {
//            doc.setModeDegrade(true);
//            log.warn("Document {} ({} bytes) exceeds size limit {} → mode degrade",
//                    doc.getId(), doc.getData().length, run.getSizeLimitBeforeFailSoft());
//        }
//    }

    /** Load the XML (always) and, when keeping style, the project DOM of a pooled QXP source. */
    private void loadQxpSource(DocumentDomain doc, boolean conserverStyle) {
        doc.initXmlFromContent(getGabaritXmlBusiness.fetchXml(doc.getFilePoolPath()));
        if (conserverStyle) {
            doc.setQxpProject(getDocumentProjectBusiness.getProject(doc.getFilePoolPath()));
        }
    }
}