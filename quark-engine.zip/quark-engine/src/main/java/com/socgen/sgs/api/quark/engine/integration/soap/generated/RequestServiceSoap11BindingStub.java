/**
 * RequestServiceSoap11BindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class RequestServiceSoap11BindingStub extends org.apache.axis.client.Stub implements com.socgen.sgs.api.quark.engine.integration.soap.generated.RequestServicePortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[21];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getAppStudioConfig");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "QContentData"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("processRequest");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://com.quark.qxpsm", "QRequestContext"), com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "QContentData"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getXPressDOMFromXML");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Project"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("saveAllDocs");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getXPressDOM");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Project"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("processRequestEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://com.quark.qxpsm", "QRequestContext"), com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "QContentData"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("createSession");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"), long.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getOpenSessions");
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setPreferences");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://com.quark.qxpsm", "Preferences"), com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("openDoc");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getOpenDocs");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "QOpenDocData"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("closeSession");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getXMLFromXPressDOM");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://com.quark.qxpsm", "Project"), com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("saveDoc");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("clearAppStudioCredentials");
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("setAppStudioCredentials");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getXPressDOMEx");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://com.quark.qxpsm", "QXPressDOMOptions"), com.socgen.sgs.api.quark.engine.integration.soap.generated.QXPressDOMOptions.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Project"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getPreferences");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Preferences"));
        oper.setReturnClass(com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("closeDoc");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("closeAllDocs");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("newDoc");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param4"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://com.quark.qxpsm", "param5"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[20] = oper;

    }

    public RequestServiceSoap11BindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public RequestServiceSoap11BindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public RequestServiceSoap11BindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.1");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
        addBindings2();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AddCells");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AddCells.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AddFileRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AddFileRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AlignHorSettings");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignHorSettings.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AlignVerSettings");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AlignVerSettings.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AllowBoxOffPage");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AllowBoxOffPage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AllowBoxOnToPasteboard");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AllowBoxOnToPasteboard.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AllowMemoryCaching");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AllowMemoryCaching.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AnchoredBoxReference");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AppStudioRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AppStudioRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Article");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Article.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "AuthenticationPreferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.AuthenticationPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Author");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Author.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "BNStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.BNStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Border");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Border.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Bottom");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Bottom.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "BottomGrid");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.BottomGrid.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Box");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Box.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "BoxAttribute");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "BoxRef");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxRef.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "CacheSize");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CacheSize.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "CalloutAnchor");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "CalloutBoxRef");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutBoxRef.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Cell");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ChildID");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ChildID.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Clipping");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Clipping.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColGroup");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ColGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColSpec");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ColSpec.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Column");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Column.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColumnFlow");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnFlow.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColumnSpan");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSpan.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColumnSplit");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSplit.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Component");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Component.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "CompositionZone");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CompositionZone.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ConditionalMasterPageReference");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConditionalMasterPageReference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ConfirmPassword");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConfirmPassword.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ConstructFileRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConstructFileRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ConstructRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConstructRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ConstructStreamRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ConstructStreamRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Content");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Content.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ContentPlaceholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ContinuedHeader");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ContinuedTRowStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedTRowStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Contour");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Contour.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Contours");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Contours.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "CopyDeskDocRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyDeskDocRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "CopyDeskRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyDeskRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "CopyFit");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Copyright");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Copyright.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "CrossReferenceToIndex");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.CrossReferenceToIndex.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "DataProvider");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DataProvider.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "DefaultRenderType");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DefaultRenderType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "DeleteCells");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteCells.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "DeleteRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DeleteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Deletion");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Deletion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Description");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Description.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "DisableQXDReturn");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DisableQXDReturn.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "DocAttributesRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DocAttributesRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "DocPreviewRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DocPreviewRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "DocumentRootFolder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DocumentRootFolder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "DropCap");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.DropCap.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "EmailFrom");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EmailFrom.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "EMailPreferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "EmailTo");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EmailTo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Entry");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Entry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "EPSRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EPSRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "EPubRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EPubRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "EvaluateRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EvaluateRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "EvenTColStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTColStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "EvenTRowStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTRowStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Excel");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Excel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "FileInfoRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FileInfoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "FirstTColStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FirstTColStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Fit");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Fit.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "FitText");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FitText.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "FlexContainer");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexContainer.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "FlexItem");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "FlushAllRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FlushAllRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "FlushRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FlushRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Footer");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Footer.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "FooterTRowStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.FooterTRowStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ForceServedDocumentsClosed");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ForceServedDocumentsClosed.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Format");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Format.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Frame");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Geometry");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "GetDocInfoRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GetDocInfoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "GetDocPoolListRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GetDocPoolListRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "GetProjectInfoRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GetProjectInfoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "GetServerInfoRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GetServerInfoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Gradient");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Gradient.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Grid");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Grid.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "GridLine");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Group");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Group.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "GroupCharacters");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "GrowAcross");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GrowAcross.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "GrowDown");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.GrowDown.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Header");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Header.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "HeadTRowStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.HeadTRowStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Height");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Height.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "HiddenData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Html5Request");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Html5Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Hyperlink");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ID");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ID.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Index");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Index.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexSpecifications");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexSpecifications.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexTerm");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineBox");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineItem");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineTable");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Insertion");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Insertion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Inset");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Interactivity");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Isbn");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Isbn.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ItemEntry");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ItemEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "JobJacketRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.JobJacketRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "JPEGRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.JPEGRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "KeepLinesTogether");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.KeepLinesTogether.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "KeyValue");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.KeyValue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Keywords");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Keywords.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "KindleRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.KindleRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LastTColStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LastTColStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Layer");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Layer.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LayersRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LayersRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Layout");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LayoutMetadata");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutMetadata.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LayoutRef");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LayoutRef.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Left");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Left.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LeftControlPoint");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftControlPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LeftGrid");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftGrid.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LevelStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LevelStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LineStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LineStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LinkedBox");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "List");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.List.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LiteralRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LiteralRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Location");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Location.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LockToGrid");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LockToGrid.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LogDocProblems");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LogDocProblems.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LoggingPreferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "LogTiming");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.LogTiming.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "MainTerm");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MainTerm.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "MasterPageSequence");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterPageSequence.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "MasterSpread");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MasterSpread.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Max");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Max.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "MetaData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Min");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Min.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ModifierFileRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ModifierFileRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ModifierRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ModifierRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ModifierStreamRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ModifierStreamRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "MoveDown");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MoveDown.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "MoveLeft");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MoveLeft.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "MoveRight");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MoveRight.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "MoveUp");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.MoveUp.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "NameValueParam");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Note");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Note.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "OddTColStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTColStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "OddTRowStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTRowStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Origin");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Origin.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "OverMatter");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Page");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Page.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageBreak");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageRef");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PageRef.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageSequence");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Paragraph");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ParentTable");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ParentTable.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "PDFRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PDFRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Picture");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Placeholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "PNGRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PNGRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Position");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Position.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "PostScriptRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PostScriptRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Preferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "PreFlightRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PreFlightRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Project");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ProjectRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ProjectRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Publication");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Publication.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "PublicationChannel");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.PublicationChannel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Publisher");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Publisher.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "QContentData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "QOpenDocData");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "QRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "QRequestContext");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "QResponseHeader");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QResponseHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "QuarkXPressRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QuarkXPressRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "QXPressDOMOptions");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.QXPressDOMOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RawCustomRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RawCustomRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ReferencedTextMarker");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ReferencedTextMarker.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RefNote");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RefNoteBody");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RefNoteBodyMarker");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNoteBodyMarker.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RelPosition");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RelPosition.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RepeatableMasterPageAlternatives");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageAlternatives.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RepeatableMasterPageReference");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RepeatableMasterPageReference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RequestParameters");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RequestParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RequestSettings");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RequestSettings.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RequireAdminVerification");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RequireAdminVerification.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RGBColor");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RichText");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Right");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Right.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RightControlPoint");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RightControlPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RightGrid");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RightGrid.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings2() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RLERawCustomRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RLERawCustomRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Row");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Row.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Rubi");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "RubiText");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.RubiText.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Rule");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Runaround");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SaveAs");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SaveAsRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Scale");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Scale.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ScaleTo");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ScaleTo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ScreenPDFRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ScreenPDFRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Section");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Section.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SectionNumberFormat");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SectionNumberFormat.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Separators");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Separators.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ServerPreferences");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ShadingStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ShadingStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Shadow");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ShrinkAcross");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ShrinkAcross.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ShrinkDown");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ShrinkDown.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "ShutdownRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.ShutdownRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SingleMasterPageReference");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SingleMasterPageReference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Size");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Size.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SmartTemplateRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SmartTemplateRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SmtpPort");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SmtpPort.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SmtpServerIP");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SmtpServerIP.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SpineImage");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SpineImage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SplineShape");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SplineShape.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Spread");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "StackingOrder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StackingOrder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "StaticContent");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.StaticContent.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Stop");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Stop.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Story");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Story.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Subject");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Subject.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SubTerm1");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm1.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SubTerm2");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm2.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SubTerm3");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm3.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SubTerm4");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm4.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "SuppressOutput");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.SuppressOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Tab");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Tab.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Table");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Table.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TableBreak");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TableBreak.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TableStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TableStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TabSpec");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TBody");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TBody.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TCol");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TCol.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TColStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TColStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TContinued");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TContinued.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Text");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Text.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TextAttribute");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TextAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TextNodePlaceholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TextPlaceholder");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TFoot");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TFoot.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "THead");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.THead.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Title");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Title.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Top");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Top.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TopGrid");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TopGrid.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TRow");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TRow.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "TRowStyle");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.TRowStyle.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "UpdateContentRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.UpdateContentRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "UpdateGeometryRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.UpdateGeometryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "VerificationPassword");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.VerificationPassword.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "VerificationUsername");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.VerificationUsername.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Vertex");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Vertex.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "VertexPoint");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.VertexPoint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Vertices");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Vertices.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "VistaRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.VistaRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Width");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Width.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "XMLImportRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.XMLImportRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "XMLRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.XMLRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "Xref");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.Xref.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://com.quark.qxpsm", "XTagRenderRequest");
            cachedSerQNames.add(qName);
            cls = com.socgen.sgs.api.quark.engine.integration.soap.generated.XTagRenderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData getAppStudioConfig(java.lang.String param0, java.lang.String param1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getAppStudioConfig");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "getAppStudioConfig"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {param0, param1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData processRequest(com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext param0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:processRequest");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "processRequest"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {param0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOMFromXML(java.lang.String param0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getXPressDOMFromXML");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "getXPressDOMFromXML"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {param0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void saveAllDocs(java.lang.String param0, java.lang.String param1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:saveAllDocs");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "saveAllDocs"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {param0, param1});

    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOM(java.lang.String param0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getXPressDOM");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "getXPressDOM"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {param0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData processRequestEx(com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext param0, java.lang.String param1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:processRequestEx");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "processRequestEx"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {param0, param1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String createSession(long param0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:createSession");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "createSession"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Long(param0)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String[] getOpenSessions() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getOpenSessions");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "getOpenSessions"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void setPreferences(java.lang.String param0, int param1, java.lang.String param2, java.lang.String param3, com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences param4) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:setPreferences");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "setPreferences"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {param0, new java.lang.Integer(param1), param2, param3, param4});

    }

    public void openDoc(java.lang.String param0, java.lang.String param1, int param2, java.lang.String param3) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:openDoc");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "openDoc"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {param0, param1, new java.lang.Integer(param2), param3});

    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[] getOpenDocs(java.lang.String param0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getOpenDocs");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "getOpenDocs"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {param0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void closeSession(java.lang.String param0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:closeSession");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "closeSession"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {param0});

    }

    public java.lang.String getXMLFromXPressDOM(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project param0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getXMLFromXPressDOM");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "getXMLFromXPressDOM"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {param0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void saveDoc(java.lang.String param0, java.lang.String param1, java.lang.String param2, java.lang.String param3) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:saveDoc");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "saveDoc"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {param0, param1, param2, param3});

    }

    public void clearAppStudioCredentials() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:clearAppStudioCredentials");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "clearAppStudioCredentials"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {});

    }

    public void setAppStudioCredentials(java.lang.String param0, java.lang.String param1, java.lang.String param2, java.lang.String param3, java.lang.String param4, java.lang.String param5) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:setAppStudioCredentials");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "setAppStudioCredentials"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {param0, param1, param2, param3, param4, param5});

    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOMEx(java.lang.String param0, com.socgen.sgs.api.quark.engine.integration.soap.generated.QXPressDOMOptions param1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getXPressDOMEx");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "getXPressDOMEx"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {param0, param1});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Project) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.Project.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences getPreferences(java.lang.String param0, int param1, java.lang.String param2, java.lang.String param3) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:getPreferences");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "getPreferences"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {param0, new java.lang.Integer(param1), param2, param3});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences) org.apache.axis.utils.JavaUtils.convert(_resp, com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void closeDoc(java.lang.String param0, java.lang.String param1) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:closeDoc");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "closeDoc"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {param0, param1});

    }

    public void closeAllDocs(java.lang.String param0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:closeAllDocs");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "closeAllDocs"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {param0});

    }

    public void newDoc(java.lang.String param0, java.lang.String param1, java.lang.String param2, java.lang.String param3, int param4, java.lang.String param5) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:newDoc");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "newDoc"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.invokeOneWay(new java.lang.Object[] {param0, param1, param2, param3, new java.lang.Integer(param4), param5});

    }

}
