package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a dynamic report containing sections with relative and absolute elements.
 *
 * Cross-reference: QXP.Engine.Core.DReport
 */
@Getter
@Setter
public class DReport {

    /** Report geometry information (total page count). */
    private final DReportInfo info = new DReportInfo();

    /** Sections contained in this report. */
    private final List<DSection> sections = new ArrayList<>();

    /** Page break rules for row splitting across pages. */
    private DBreakRules pageBreakRules = DBreakRules.DEFAULT;

    /** Column break rules for row splitting across columns. */
    private DBreakRules columnBreakRules = DBreakRules.DEFAULT;

    public DReport() {
    }
}