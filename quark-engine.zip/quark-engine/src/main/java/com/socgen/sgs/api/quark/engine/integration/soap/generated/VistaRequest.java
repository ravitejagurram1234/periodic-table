/**
 * VistaRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class VistaRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String applyVistaEffect;

    private java.lang.String deleteVistaEffect;

    private java.lang.String vistaBox;

    public VistaRequest() {
    }

    public VistaRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String applyVistaEffect,
           java.lang.String deleteVistaEffect,
           java.lang.String vistaBox) {
        super(
            request);
        this.applyVistaEffect = applyVistaEffect;
        this.deleteVistaEffect = deleteVistaEffect;
        this.vistaBox = vistaBox;
    }


    /**
     * Gets the applyVistaEffect value for this VistaRequest.
     * 
     * @return applyVistaEffect
     */
    public java.lang.String getApplyVistaEffect() {
        return applyVistaEffect;
    }


    /**
     * Sets the applyVistaEffect value for this VistaRequest.
     * 
     * @param applyVistaEffect
     */
    public void setApplyVistaEffect(java.lang.String applyVistaEffect) {
        this.applyVistaEffect = applyVistaEffect;
    }


    /**
     * Gets the deleteVistaEffect value for this VistaRequest.
     * 
     * @return deleteVistaEffect
     */
    public java.lang.String getDeleteVistaEffect() {
        return deleteVistaEffect;
    }


    /**
     * Sets the deleteVistaEffect value for this VistaRequest.
     * 
     * @param deleteVistaEffect
     */
    public void setDeleteVistaEffect(java.lang.String deleteVistaEffect) {
        this.deleteVistaEffect = deleteVistaEffect;
    }


    /**
     * Gets the vistaBox value for this VistaRequest.
     * 
     * @return vistaBox
     */
    public java.lang.String getVistaBox() {
        return vistaBox;
    }


    /**
     * Sets the vistaBox value for this VistaRequest.
     * 
     * @param vistaBox
     */
    public void setVistaBox(java.lang.String vistaBox) {
        this.vistaBox = vistaBox;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VistaRequest)) return false;
        VistaRequest other = (VistaRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.applyVistaEffect==null && other.getApplyVistaEffect()==null) || 
             (this.applyVistaEffect!=null &&
              this.applyVistaEffect.equals(other.getApplyVistaEffect()))) &&
            ((this.deleteVistaEffect==null && other.getDeleteVistaEffect()==null) || 
             (this.deleteVistaEffect!=null &&
              this.deleteVistaEffect.equals(other.getDeleteVistaEffect()))) &&
            ((this.vistaBox==null && other.getVistaBox()==null) || 
             (this.vistaBox!=null &&
              this.vistaBox.equals(other.getVistaBox())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getApplyVistaEffect() != null) {
            _hashCode += getApplyVistaEffect().hashCode();
        }
        if (getDeleteVistaEffect() != null) {
            _hashCode += getDeleteVistaEffect().hashCode();
        }
        if (getVistaBox() != null) {
            _hashCode += getVistaBox().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VistaRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "VistaRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("applyVistaEffect");
        elemField.setXmlName(new javax.xml.namespace.QName("", "applyVistaEffect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deleteVistaEffect");
        elemField.setXmlName(new javax.xml.namespace.QName("", "deleteVistaEffect"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vistaBox");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vistaBox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
