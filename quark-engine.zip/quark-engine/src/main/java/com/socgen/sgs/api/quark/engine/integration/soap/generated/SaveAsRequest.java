/**
 * SaveAsRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class SaveAsRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String newFilePath;

    private java.lang.String newName;

    private java.lang.String replaceFile;

    private java.lang.String saveToPool;

    public SaveAsRequest() {
    }

    public SaveAsRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String newFilePath,
           java.lang.String newName,
           java.lang.String replaceFile,
           java.lang.String saveToPool) {
        super(
            request);
        this.newFilePath = newFilePath;
        this.newName = newName;
        this.replaceFile = replaceFile;
        this.saveToPool = saveToPool;
    }


    /**
     * Gets the newFilePath value for this SaveAsRequest.
     * 
     * @return newFilePath
     */
    public java.lang.String getNewFilePath() {
        return newFilePath;
    }


    /**
     * Sets the newFilePath value for this SaveAsRequest.
     * 
     * @param newFilePath
     */
    public void setNewFilePath(java.lang.String newFilePath) {
        this.newFilePath = newFilePath;
    }


    /**
     * Gets the newName value for this SaveAsRequest.
     * 
     * @return newName
     */
    public java.lang.String getNewName() {
        return newName;
    }


    /**
     * Sets the newName value for this SaveAsRequest.
     * 
     * @param newName
     */
    public void setNewName(java.lang.String newName) {
        this.newName = newName;
    }


    /**
     * Gets the replaceFile value for this SaveAsRequest.
     * 
     * @return replaceFile
     */
    public java.lang.String getReplaceFile() {
        return replaceFile;
    }


    /**
     * Sets the replaceFile value for this SaveAsRequest.
     * 
     * @param replaceFile
     */
    public void setReplaceFile(java.lang.String replaceFile) {
        this.replaceFile = replaceFile;
    }


    /**
     * Gets the saveToPool value for this SaveAsRequest.
     * 
     * @return saveToPool
     */
    public java.lang.String getSaveToPool() {
        return saveToPool;
    }


    /**
     * Sets the saveToPool value for this SaveAsRequest.
     * 
     * @param saveToPool
     */
    public void setSaveToPool(java.lang.String saveToPool) {
        this.saveToPool = saveToPool;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SaveAsRequest)) return false;
        SaveAsRequest other = (SaveAsRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.newFilePath==null && other.getNewFilePath()==null) || 
             (this.newFilePath!=null &&
              this.newFilePath.equals(other.getNewFilePath()))) &&
            ((this.newName==null && other.getNewName()==null) || 
             (this.newName!=null &&
              this.newName.equals(other.getNewName()))) &&
            ((this.replaceFile==null && other.getReplaceFile()==null) || 
             (this.replaceFile!=null &&
              this.replaceFile.equals(other.getReplaceFile()))) &&
            ((this.saveToPool==null && other.getSaveToPool()==null) || 
             (this.saveToPool!=null &&
              this.saveToPool.equals(other.getSaveToPool())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getNewFilePath() != null) {
            _hashCode += getNewFilePath().hashCode();
        }
        if (getNewName() != null) {
            _hashCode += getNewName().hashCode();
        }
        if (getReplaceFile() != null) {
            _hashCode += getReplaceFile().hashCode();
        }
        if (getSaveToPool() != null) {
            _hashCode += getSaveToPool().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SaveAsRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "SaveAsRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("newFilePath");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "newFilePath"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("newName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "newName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("replaceFile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "replaceFile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saveToPool");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "saveToPool"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
