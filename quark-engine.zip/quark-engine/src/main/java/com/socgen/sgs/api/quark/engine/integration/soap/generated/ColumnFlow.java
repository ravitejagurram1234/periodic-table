/**
 * ColumnFlow.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ColumnFlow  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSpan columnSpan;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSplit columnSplit;

    private java.lang.String flowOrder;

    public ColumnFlow() {
    }

    public ColumnFlow(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSpan columnSpan,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSplit columnSplit,
           java.lang.String flowOrder) {
        super(
            request);
        this.columnSpan = columnSpan;
        this.columnSplit = columnSplit;
        this.flowOrder = flowOrder;
    }


    /**
     * Gets the columnSpan value for this ColumnFlow.
     * 
     * @return columnSpan
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSpan getColumnSpan() {
        return columnSpan;
    }


    /**
     * Sets the columnSpan value for this ColumnFlow.
     * 
     * @param columnSpan
     */
    public void setColumnSpan(com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSpan columnSpan) {
        this.columnSpan = columnSpan;
    }


    /**
     * Gets the columnSplit value for this ColumnFlow.
     * 
     * @return columnSplit
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSplit getColumnSplit() {
        return columnSplit;
    }


    /**
     * Sets the columnSplit value for this ColumnFlow.
     * 
     * @param columnSplit
     */
    public void setColumnSplit(com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnSplit columnSplit) {
        this.columnSplit = columnSplit;
    }


    /**
     * Gets the flowOrder value for this ColumnFlow.
     * 
     * @return flowOrder
     */
    public java.lang.String getFlowOrder() {
        return flowOrder;
    }


    /**
     * Sets the flowOrder value for this ColumnFlow.
     * 
     * @param flowOrder
     */
    public void setFlowOrder(java.lang.String flowOrder) {
        this.flowOrder = flowOrder;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ColumnFlow)) return false;
        ColumnFlow other = (ColumnFlow) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.columnSpan==null && other.getColumnSpan()==null) || 
             (this.columnSpan!=null &&
              this.columnSpan.equals(other.getColumnSpan()))) &&
            ((this.columnSplit==null && other.getColumnSplit()==null) || 
             (this.columnSplit!=null &&
              this.columnSplit.equals(other.getColumnSplit()))) &&
            ((this.flowOrder==null && other.getFlowOrder()==null) || 
             (this.flowOrder!=null &&
              this.flowOrder.equals(other.getFlowOrder())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getColumnSpan() != null) {
            _hashCode += getColumnSpan().hashCode();
        }
        if (getColumnSplit() != null) {
            _hashCode += getColumnSplit().hashCode();
        }
        if (getFlowOrder() != null) {
            _hashCode += getFlowOrder().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ColumnFlow.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColumnFlow"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnSpan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnSpan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColumnSpan"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnSplit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnSplit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColumnSplit"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flowOrder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "flowOrder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
