/**
 * Box.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Box  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String addToReflow;

    private java.lang.String anchoredGroupMember;

    private java.lang.String anchoredIn;

    private java.lang.String articleName;

    private java.lang.String blendAngle;

    private java.lang.String blendColor;

    private java.lang.String blendOpacity;

    private java.lang.String blendShape;

    private java.lang.String blendStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border;

    private java.lang.String boxType;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes;

    private java.lang.String color;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder contentPlaceholder;

    private java.lang.String convertToGraphic;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexContainer flexContainer;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexItem flexItem;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Gradient gradient;

    private java.lang.String HLAnchorRef;

    private java.lang.String HLType;

    private java.lang.String hyperlinkRef;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity interactivity;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData;

    private java.lang.String name;

    private java.lang.String opacity;

    private java.lang.String operation;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder[] placeholders;

    private java.lang.String shade;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Text text;

    private java.lang.String UID;

    public Box() {
    }

    public Box(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String addToReflow,
           java.lang.String anchoredGroupMember,
           java.lang.String anchoredIn,
           java.lang.String articleName,
           java.lang.String blendAngle,
           java.lang.String blendColor,
           java.lang.String blendOpacity,
           java.lang.String blendShape,
           java.lang.String blendStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border,
           java.lang.String boxType,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes,
           java.lang.String color,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder contentPlaceholder,
           java.lang.String convertToGraphic,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexContainer flexContainer,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexItem flexItem,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Gradient gradient,
           java.lang.String HLAnchorRef,
           java.lang.String HLType,
           java.lang.String hyperlinkRef,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity interactivity,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData,
           java.lang.String name,
           java.lang.String opacity,
           java.lang.String operation,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder[] placeholders,
           java.lang.String shade,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Text text,
           java.lang.String UID) {
        super(
            request);
        this.addToReflow = addToReflow;
        this.anchoredGroupMember = anchoredGroupMember;
        this.anchoredIn = anchoredIn;
        this.articleName = articleName;
        this.blendAngle = blendAngle;
        this.blendColor = blendColor;
        this.blendOpacity = blendOpacity;
        this.blendShape = blendShape;
        this.blendStyle = blendStyle;
        this.border = border;
        this.boxType = boxType;
        this.boxes = boxes;
        this.color = color;
        this.content = content;
        this.contentPlaceholder = contentPlaceholder;
        this.convertToGraphic = convertToGraphic;
        this.flexContainer = flexContainer;
        this.flexItem = flexItem;
        this.frame = frame;
        this.geometry = geometry;
        this.gradient = gradient;
        this.HLAnchorRef = HLAnchorRef;
        this.HLType = HLType;
        this.hyperlinkRef = hyperlinkRef;
        this.index = index;
        this.interactivity = interactivity;
        this.metaData = metaData;
        this.name = name;
        this.opacity = opacity;
        this.operation = operation;
        this.picture = picture;
        this.placeholders = placeholders;
        this.shade = shade;
        this.shadow = shadow;
        this.text = text;
        this.UID = UID;
    }


    /**
     * Gets the addToReflow value for this Box.
     * 
     * @return addToReflow
     */
    public java.lang.String getAddToReflow() {
        return addToReflow;
    }


    /**
     * Sets the addToReflow value for this Box.
     * 
     * @param addToReflow
     */
    public void setAddToReflow(java.lang.String addToReflow) {
        this.addToReflow = addToReflow;
    }


    /**
     * Gets the anchoredGroupMember value for this Box.
     * 
     * @return anchoredGroupMember
     */
    public java.lang.String getAnchoredGroupMember() {
        return anchoredGroupMember;
    }


    /**
     * Sets the anchoredGroupMember value for this Box.
     * 
     * @param anchoredGroupMember
     */
    public void setAnchoredGroupMember(java.lang.String anchoredGroupMember) {
        this.anchoredGroupMember = anchoredGroupMember;
    }


    /**
     * Gets the anchoredIn value for this Box.
     * 
     * @return anchoredIn
     */
    public java.lang.String getAnchoredIn() {
        return anchoredIn;
    }


    /**
     * Sets the anchoredIn value for this Box.
     * 
     * @param anchoredIn
     */
    public void setAnchoredIn(java.lang.String anchoredIn) {
        this.anchoredIn = anchoredIn;
    }


    /**
     * Gets the articleName value for this Box.
     * 
     * @return articleName
     */
    public java.lang.String getArticleName() {
        return articleName;
    }


    /**
     * Sets the articleName value for this Box.
     * 
     * @param articleName
     */
    public void setArticleName(java.lang.String articleName) {
        this.articleName = articleName;
    }


    /**
     * Gets the blendAngle value for this Box.
     * 
     * @return blendAngle
     */
    public java.lang.String getBlendAngle() {
        return blendAngle;
    }


    /**
     * Sets the blendAngle value for this Box.
     * 
     * @param blendAngle
     */
    public void setBlendAngle(java.lang.String blendAngle) {
        this.blendAngle = blendAngle;
    }


    /**
     * Gets the blendColor value for this Box.
     * 
     * @return blendColor
     */
    public java.lang.String getBlendColor() {
        return blendColor;
    }


    /**
     * Sets the blendColor value for this Box.
     * 
     * @param blendColor
     */
    public void setBlendColor(java.lang.String blendColor) {
        this.blendColor = blendColor;
    }


    /**
     * Gets the blendOpacity value for this Box.
     * 
     * @return blendOpacity
     */
    public java.lang.String getBlendOpacity() {
        return blendOpacity;
    }


    /**
     * Sets the blendOpacity value for this Box.
     * 
     * @param blendOpacity
     */
    public void setBlendOpacity(java.lang.String blendOpacity) {
        this.blendOpacity = blendOpacity;
    }


    /**
     * Gets the blendShape value for this Box.
     * 
     * @return blendShape
     */
    public java.lang.String getBlendShape() {
        return blendShape;
    }


    /**
     * Sets the blendShape value for this Box.
     * 
     * @param blendShape
     */
    public void setBlendShape(java.lang.String blendShape) {
        this.blendShape = blendShape;
    }


    /**
     * Gets the blendStyle value for this Box.
     * 
     * @return blendStyle
     */
    public java.lang.String getBlendStyle() {
        return blendStyle;
    }


    /**
     * Sets the blendStyle value for this Box.
     * 
     * @param blendStyle
     */
    public void setBlendStyle(java.lang.String blendStyle) {
        this.blendStyle = blendStyle;
    }


    /**
     * Gets the border value for this Box.
     * 
     * @return border
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Border getBorder() {
        return border;
    }


    /**
     * Sets the border value for this Box.
     * 
     * @param border
     */
    public void setBorder(com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border) {
        this.border = border;
    }


    /**
     * Gets the boxType value for this Box.
     * 
     * @return boxType
     */
    public java.lang.String getBoxType() {
        return boxType;
    }


    /**
     * Sets the boxType value for this Box.
     * 
     * @param boxType
     */
    public void setBoxType(java.lang.String boxType) {
        this.boxType = boxType;
    }


    /**
     * Gets the boxes value for this Box.
     * 
     * @return boxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] getBoxes() {
        return boxes;
    }


    /**
     * Sets the boxes value for this Box.
     * 
     * @param boxes
     */
    public void setBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.Box[] boxes) {
        this.boxes = boxes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Box getBoxes(int i) {
        return this.boxes[i];
    }

    public void setBoxes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Box _value) {
        this.boxes[i] = _value;
    }


    /**
     * Gets the color value for this Box.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this Box.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the content value for this Box.
     * 
     * @return content
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Content getContent() {
        return content;
    }


    /**
     * Sets the content value for this Box.
     * 
     * @param content
     */
    public void setContent(com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content) {
        this.content = content;
    }


    /**
     * Gets the contentPlaceholder value for this Box.
     * 
     * @return contentPlaceholder
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder getContentPlaceholder() {
        return contentPlaceholder;
    }


    /**
     * Sets the contentPlaceholder value for this Box.
     * 
     * @param contentPlaceholder
     */
    public void setContentPlaceholder(com.socgen.sgs.api.quark.engine.integration.soap.generated.ContentPlaceholder contentPlaceholder) {
        this.contentPlaceholder = contentPlaceholder;
    }


    /**
     * Gets the convertToGraphic value for this Box.
     * 
     * @return convertToGraphic
     */
    public java.lang.String getConvertToGraphic() {
        return convertToGraphic;
    }


    /**
     * Sets the convertToGraphic value for this Box.
     * 
     * @param convertToGraphic
     */
    public void setConvertToGraphic(java.lang.String convertToGraphic) {
        this.convertToGraphic = convertToGraphic;
    }


    /**
     * Gets the flexContainer value for this Box.
     * 
     * @return flexContainer
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexContainer getFlexContainer() {
        return flexContainer;
    }


    /**
     * Sets the flexContainer value for this Box.
     * 
     * @param flexContainer
     */
    public void setFlexContainer(com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexContainer flexContainer) {
        this.flexContainer = flexContainer;
    }


    /**
     * Gets the flexItem value for this Box.
     * 
     * @return flexItem
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexItem getFlexItem() {
        return flexItem;
    }


    /**
     * Sets the flexItem value for this Box.
     * 
     * @param flexItem
     */
    public void setFlexItem(com.socgen.sgs.api.quark.engine.integration.soap.generated.FlexItem flexItem) {
        this.flexItem = flexItem;
    }


    /**
     * Gets the frame value for this Box.
     * 
     * @return frame
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame getFrame() {
        return frame;
    }


    /**
     * Sets the frame value for this Box.
     * 
     * @param frame
     */
    public void setFrame(com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame) {
        this.frame = frame;
    }


    /**
     * Gets the geometry value for this Box.
     * 
     * @return geometry
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry getGeometry() {
        return geometry;
    }


    /**
     * Sets the geometry value for this Box.
     * 
     * @param geometry
     */
    public void setGeometry(com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry geometry) {
        this.geometry = geometry;
    }


    /**
     * Gets the gradient value for this Box.
     * 
     * @return gradient
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Gradient getGradient() {
        return gradient;
    }


    /**
     * Sets the gradient value for this Box.
     * 
     * @param gradient
     */
    public void setGradient(com.socgen.sgs.api.quark.engine.integration.soap.generated.Gradient gradient) {
        this.gradient = gradient;
    }


    /**
     * Gets the HLAnchorRef value for this Box.
     * 
     * @return HLAnchorRef
     */
    public java.lang.String getHLAnchorRef() {
        return HLAnchorRef;
    }


    /**
     * Sets the HLAnchorRef value for this Box.
     * 
     * @param HLAnchorRef
     */
    public void setHLAnchorRef(java.lang.String HLAnchorRef) {
        this.HLAnchorRef = HLAnchorRef;
    }


    /**
     * Gets the HLType value for this Box.
     * 
     * @return HLType
     */
    public java.lang.String getHLType() {
        return HLType;
    }


    /**
     * Sets the HLType value for this Box.
     * 
     * @param HLType
     */
    public void setHLType(java.lang.String HLType) {
        this.HLType = HLType;
    }


    /**
     * Gets the hyperlinkRef value for this Box.
     * 
     * @return hyperlinkRef
     */
    public java.lang.String getHyperlinkRef() {
        return hyperlinkRef;
    }


    /**
     * Sets the hyperlinkRef value for this Box.
     * 
     * @param hyperlinkRef
     */
    public void setHyperlinkRef(java.lang.String hyperlinkRef) {
        this.hyperlinkRef = hyperlinkRef;
    }


    /**
     * Gets the index value for this Box.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this Box.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the interactivity value for this Box.
     * 
     * @return interactivity
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity getInteractivity() {
        return interactivity;
    }


    /**
     * Sets the interactivity value for this Box.
     * 
     * @param interactivity
     */
    public void setInteractivity(com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity interactivity) {
        this.interactivity = interactivity;
    }


    /**
     * Gets the metaData value for this Box.
     * 
     * @return metaData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData getMetaData() {
        return metaData;
    }


    /**
     * Sets the metaData value for this Box.
     * 
     * @param metaData
     */
    public void setMetaData(com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData) {
        this.metaData = metaData;
    }


    /**
     * Gets the name value for this Box.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Box.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the opacity value for this Box.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this Box.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the operation value for this Box.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this Box.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }


    /**
     * Gets the picture value for this Box.
     * 
     * @return picture
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture getPicture() {
        return picture;
    }


    /**
     * Sets the picture value for this Box.
     * 
     * @param picture
     */
    public void setPicture(com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture) {
        this.picture = picture;
    }


    /**
     * Gets the placeholders value for this Box.
     * 
     * @return placeholders
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder[] getPlaceholders() {
        return placeholders;
    }


    /**
     * Sets the placeholders value for this Box.
     * 
     * @param placeholders
     */
    public void setPlaceholders(com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder[] placeholders) {
        this.placeholders = placeholders;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder getPlaceholders(int i) {
        return this.placeholders[i];
    }

    public void setPlaceholders(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Placeholder _value) {
        this.placeholders[i] = _value;
    }


    /**
     * Gets the shade value for this Box.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this Box.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the shadow value for this Box.
     * 
     * @return shadow
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow getShadow() {
        return shadow;
    }


    /**
     * Sets the shadow value for this Box.
     * 
     * @param shadow
     */
    public void setShadow(com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow) {
        this.shadow = shadow;
    }


    /**
     * Gets the text value for this Box.
     * 
     * @return text
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Text getText() {
        return text;
    }


    /**
     * Sets the text value for this Box.
     * 
     * @param text
     */
    public void setText(com.socgen.sgs.api.quark.engine.integration.soap.generated.Text text) {
        this.text = text;
    }


    /**
     * Gets the UID value for this Box.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Box.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Box)) return false;
        Box other = (Box) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.addToReflow==null && other.getAddToReflow()==null) || 
             (this.addToReflow!=null &&
              this.addToReflow.equals(other.getAddToReflow()))) &&
            ((this.anchoredGroupMember==null && other.getAnchoredGroupMember()==null) || 
             (this.anchoredGroupMember!=null &&
              this.anchoredGroupMember.equals(other.getAnchoredGroupMember()))) &&
            ((this.anchoredIn==null && other.getAnchoredIn()==null) || 
             (this.anchoredIn!=null &&
              this.anchoredIn.equals(other.getAnchoredIn()))) &&
            ((this.articleName==null && other.getArticleName()==null) || 
             (this.articleName!=null &&
              this.articleName.equals(other.getArticleName()))) &&
            ((this.blendAngle==null && other.getBlendAngle()==null) || 
             (this.blendAngle!=null &&
              this.blendAngle.equals(other.getBlendAngle()))) &&
            ((this.blendColor==null && other.getBlendColor()==null) || 
             (this.blendColor!=null &&
              this.blendColor.equals(other.getBlendColor()))) &&
            ((this.blendOpacity==null && other.getBlendOpacity()==null) || 
             (this.blendOpacity!=null &&
              this.blendOpacity.equals(other.getBlendOpacity()))) &&
            ((this.blendShape==null && other.getBlendShape()==null) || 
             (this.blendShape!=null &&
              this.blendShape.equals(other.getBlendShape()))) &&
            ((this.blendStyle==null && other.getBlendStyle()==null) || 
             (this.blendStyle!=null &&
              this.blendStyle.equals(other.getBlendStyle()))) &&
            ((this.border==null && other.getBorder()==null) || 
             (this.border!=null &&
              this.border.equals(other.getBorder()))) &&
            ((this.boxType==null && other.getBoxType()==null) || 
             (this.boxType!=null &&
              this.boxType.equals(other.getBoxType()))) &&
            ((this.boxes==null && other.getBoxes()==null) || 
             (this.boxes!=null &&
              java.util.Arrays.equals(this.boxes, other.getBoxes()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.content==null && other.getContent()==null) || 
             (this.content!=null &&
              this.content.equals(other.getContent()))) &&
            ((this.contentPlaceholder==null && other.getContentPlaceholder()==null) || 
             (this.contentPlaceholder!=null &&
              this.contentPlaceholder.equals(other.getContentPlaceholder()))) &&
            ((this.convertToGraphic==null && other.getConvertToGraphic()==null) || 
             (this.convertToGraphic!=null &&
              this.convertToGraphic.equals(other.getConvertToGraphic()))) &&
            ((this.flexContainer==null && other.getFlexContainer()==null) || 
             (this.flexContainer!=null &&
              this.flexContainer.equals(other.getFlexContainer()))) &&
            ((this.flexItem==null && other.getFlexItem()==null) || 
             (this.flexItem!=null &&
              this.flexItem.equals(other.getFlexItem()))) &&
            ((this.frame==null && other.getFrame()==null) || 
             (this.frame!=null &&
              this.frame.equals(other.getFrame()))) &&
            ((this.geometry==null && other.getGeometry()==null) || 
             (this.geometry!=null &&
              this.geometry.equals(other.getGeometry()))) &&
            ((this.gradient==null && other.getGradient()==null) || 
             (this.gradient!=null &&
              this.gradient.equals(other.getGradient()))) &&
            ((this.HLAnchorRef==null && other.getHLAnchorRef()==null) || 
             (this.HLAnchorRef!=null &&
              this.HLAnchorRef.equals(other.getHLAnchorRef()))) &&
            ((this.HLType==null && other.getHLType()==null) || 
             (this.HLType!=null &&
              this.HLType.equals(other.getHLType()))) &&
            ((this.hyperlinkRef==null && other.getHyperlinkRef()==null) || 
             (this.hyperlinkRef!=null &&
              this.hyperlinkRef.equals(other.getHyperlinkRef()))) &&
            this.index == other.getIndex() &&
            ((this.interactivity==null && other.getInteractivity()==null) || 
             (this.interactivity!=null &&
              this.interactivity.equals(other.getInteractivity()))) &&
            ((this.metaData==null && other.getMetaData()==null) || 
             (this.metaData!=null &&
              this.metaData.equals(other.getMetaData()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation()))) &&
            ((this.picture==null && other.getPicture()==null) || 
             (this.picture!=null &&
              this.picture.equals(other.getPicture()))) &&
            ((this.placeholders==null && other.getPlaceholders()==null) || 
             (this.placeholders!=null &&
              java.util.Arrays.equals(this.placeholders, other.getPlaceholders()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.shadow==null && other.getShadow()==null) || 
             (this.shadow!=null &&
              this.shadow.equals(other.getShadow()))) &&
            ((this.text==null && other.getText()==null) || 
             (this.text!=null &&
              this.text.equals(other.getText()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAddToReflow() != null) {
            _hashCode += getAddToReflow().hashCode();
        }
        if (getAnchoredGroupMember() != null) {
            _hashCode += getAnchoredGroupMember().hashCode();
        }
        if (getAnchoredIn() != null) {
            _hashCode += getAnchoredIn().hashCode();
        }
        if (getArticleName() != null) {
            _hashCode += getArticleName().hashCode();
        }
        if (getBlendAngle() != null) {
            _hashCode += getBlendAngle().hashCode();
        }
        if (getBlendColor() != null) {
            _hashCode += getBlendColor().hashCode();
        }
        if (getBlendOpacity() != null) {
            _hashCode += getBlendOpacity().hashCode();
        }
        if (getBlendShape() != null) {
            _hashCode += getBlendShape().hashCode();
        }
        if (getBlendStyle() != null) {
            _hashCode += getBlendStyle().hashCode();
        }
        if (getBorder() != null) {
            _hashCode += getBorder().hashCode();
        }
        if (getBoxType() != null) {
            _hashCode += getBoxType().hashCode();
        }
        if (getBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getContent() != null) {
            _hashCode += getContent().hashCode();
        }
        if (getContentPlaceholder() != null) {
            _hashCode += getContentPlaceholder().hashCode();
        }
        if (getConvertToGraphic() != null) {
            _hashCode += getConvertToGraphic().hashCode();
        }
        if (getFlexContainer() != null) {
            _hashCode += getFlexContainer().hashCode();
        }
        if (getFlexItem() != null) {
            _hashCode += getFlexItem().hashCode();
        }
        if (getFrame() != null) {
            _hashCode += getFrame().hashCode();
        }
        if (getGeometry() != null) {
            _hashCode += getGeometry().hashCode();
        }
        if (getGradient() != null) {
            _hashCode += getGradient().hashCode();
        }
        if (getHLAnchorRef() != null) {
            _hashCode += getHLAnchorRef().hashCode();
        }
        if (getHLType() != null) {
            _hashCode += getHLType().hashCode();
        }
        if (getHyperlinkRef() != null) {
            _hashCode += getHyperlinkRef().hashCode();
        }
        _hashCode += getIndex();
        if (getInteractivity() != null) {
            _hashCode += getInteractivity().hashCode();
        }
        if (getMetaData() != null) {
            _hashCode += getMetaData().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        if (getPicture() != null) {
            _hashCode += getPicture().hashCode();
        }
        if (getPlaceholders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPlaceholders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPlaceholders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getShadow() != null) {
            _hashCode += getShadow().hashCode();
        }
        if (getText() != null) {
            _hashCode += getText().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Box.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Box"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addToReflow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "addToReflow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredGroupMember");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredGroupMember"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredIn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredIn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("articleName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "articleName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendAngle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendAngle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendShape");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendShape"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("border");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "border"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Border"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Box"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("content");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "content"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Content"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentPlaceholder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "contentPlaceholder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ContentPlaceholder"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("convertToGraphic");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "convertToGraphic"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flexContainer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "flexContainer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "FlexContainer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flexItem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "flexItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "FlexItem"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frame");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "frame"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Frame"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geometry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "geometry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Geometry"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gradient");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "gradient"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Gradient"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HLAnchorRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HLAnchorRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HLType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HLType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hyperlinkRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hyperlinkRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interactivity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "interactivity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Interactivity"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metaData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "metaData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "MetaData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picture");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "picture"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Picture"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("placeholders");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "placeholders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Placeholder"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shadow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Shadow"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("text");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "text"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Text"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
