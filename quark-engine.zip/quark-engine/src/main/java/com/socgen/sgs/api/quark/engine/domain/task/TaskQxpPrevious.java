package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.enums.SubTaskTypeEnum;
import lombok.Getter;
import lombok.Setter;

/** Represents a task that retrieves data from a previously certified QXP document. */
@Getter
@Setter
public class TaskQxpPrevious extends TaskBase {

    private boolean conserverStyle = false;
    private String previousTypeRapport;
    private DocumentDomain document;
    private String positionBlocName = "";

    public TaskQxpPrevious(int id, Run run) {
        super(id, run);
    }

    @Override
    public void prepare() {
        this.setSubTaskType(SubTaskTypeEnum.FILE_QXP_PREVIOUS);
    }

    /** Resolves the target destination bloc name for page/layout evaluation. */
    public String resolveTargetBlocName() {
        if (this.positionBlocName != null && !this.positionBlocName.isBlank()) {
            return this.positionBlocName;
        }
        if (this.getDestinationBlocName() != null && !this.getDestinationBlocName().isBlank()) {
            String[] destinations = this.getDestinationBlocName().split("\\|");
            return destinations[0];
        }
        return null;
    }

    @Override
    public boolean isModeDegrade() {
        return this.document != null && this.document.isModeDegrade();
    }
}


