package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.GetDocumentByIdDao;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

/**
 * Calls QXP_PK_RUN.Get_Document_ByID (FUNCTION → cursor) to load a document by id.
 * Cross-reference: .NET QXPS_File_Manager.Get_Document(id) (used by Run_Previous).
 */
@Repository
@Slf4j
public class GetDocumentByIdDaoImpl implements GetDocumentByIdDao {

    private static final String RESULT_KEY = "result_cursor";
    private final SimpleJdbcCall getDocumentByIdCall;

    @Autowired
    public GetDocumentByIdDaoImpl(DataSource dataSource) {
        this.getDocumentByIdCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_Document_ByID")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR,
                                (rs, rowNum) -> mapFromResultSet(rs)),
                        new SqlParameter("p_id_document", Types.NUMERIC)
                );
    }

    @Override
    public DocumentDomain getDocumentById(int idDocument) {
        log.info("Fetching document by id: {}", idDocument);

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_document", idDocument);

        try {
            Map<String, Object> result = getDocumentByIdCall.execute(params);

            @SuppressWarnings("unchecked")
            List<DocumentDomain> rows = (List<DocumentDomain>) result.get(RESULT_KEY);

            if (rows == null || rows.isEmpty()) {
                log.warn("No document found for id: {}", idDocument);
                return null;
            }
            return rows.get(0);
        } catch (Exception e) {
            log.error("Error fetching document by id: {}", idDocument, e);
            throw new RuntimeException("Failed to fetch document by id: " + idDocument, e);
        }
    }

    private DocumentDomain mapFromResultSet(ResultSet rs) throws SQLException {
        DocumentDomain doc = new DocumentDomain();
        doc.setId(rs.getInt("id_document"));
        doc.setName(rs.getString("nom"));
        // Read the cursor's format column VERBATIM (Get_Document_ByID returns it), falling back to "QXP"
        // only when null/blank; the file name is built from the unmodified format value. Finding #84.
        String fmt = rs.getString("format");
        doc.setFormat(fmt != null && !fmt.isBlank() ? fmt : "QXP");
        doc.setPrefix(DocumentDomain.FILE_DOCUMENT_PREFIX);
        doc.setData(rs.getBytes("contenu"));
        doc.setIdLangue(rs.getInt("id_langue"));
        String fileName = String.format("%s_%d.%s", doc.getPrefix(), doc.getId(), doc.getFormat());
        doc.setFileName(fileName);
        // Pool name used to upload (addFile) and to read back (getXPressDOM/getProject) — keep consistent.
        doc.setFilePoolPath(fileName);
        return doc;
    }
}