/**
 * Row.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Row  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String autofit;

    private java.lang.String autofitMaxLimit;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell[] cells;

    private java.lang.String color;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine[] gridLines;

    private java.lang.String mergeRowSpan;

    private java.lang.String opacity;

    private java.lang.String rowCount;

    private java.lang.String rowHeight;

    private java.lang.String shade;

    private java.lang.String split;

    public Row() {
    }

    public Row(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String autofit,
           java.lang.String autofitMaxLimit,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell[] cells,
           java.lang.String color,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine[] gridLines,
           java.lang.String mergeRowSpan,
           java.lang.String opacity,
           java.lang.String rowCount,
           java.lang.String rowHeight,
           java.lang.String shade,
           java.lang.String split) {
        super(
            request);
        this.autofit = autofit;
        this.autofitMaxLimit = autofitMaxLimit;
        this.cells = cells;
        this.color = color;
        this.gridLines = gridLines;
        this.mergeRowSpan = mergeRowSpan;
        this.opacity = opacity;
        this.rowCount = rowCount;
        this.rowHeight = rowHeight;
        this.shade = shade;
        this.split = split;
    }


    /**
     * Gets the autofit value for this Row.
     * 
     * @return autofit
     */
    public java.lang.String getAutofit() {
        return autofit;
    }


    /**
     * Sets the autofit value for this Row.
     * 
     * @param autofit
     */
    public void setAutofit(java.lang.String autofit) {
        this.autofit = autofit;
    }


    /**
     * Gets the autofitMaxLimit value for this Row.
     * 
     * @return autofitMaxLimit
     */
    public java.lang.String getAutofitMaxLimit() {
        return autofitMaxLimit;
    }


    /**
     * Sets the autofitMaxLimit value for this Row.
     * 
     * @param autofitMaxLimit
     */
    public void setAutofitMaxLimit(java.lang.String autofitMaxLimit) {
        this.autofitMaxLimit = autofitMaxLimit;
    }


    /**
     * Gets the cells value for this Row.
     * 
     * @return cells
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell[] getCells() {
        return cells;
    }


    /**
     * Sets the cells value for this Row.
     * 
     * @param cells
     */
    public void setCells(com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell[] cells) {
        this.cells = cells;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell getCells(int i) {
        return this.cells[i];
    }

    public void setCells(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell _value) {
        this.cells[i] = _value;
    }


    /**
     * Gets the color value for this Row.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this Row.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the gridLines value for this Row.
     * 
     * @return gridLines
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine[] getGridLines() {
        return gridLines;
    }


    /**
     * Sets the gridLines value for this Row.
     * 
     * @param gridLines
     */
    public void setGridLines(com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine[] gridLines) {
        this.gridLines = gridLines;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine getGridLines(int i) {
        return this.gridLines[i];
    }

    public void setGridLines(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.GridLine _value) {
        this.gridLines[i] = _value;
    }


    /**
     * Gets the mergeRowSpan value for this Row.
     * 
     * @return mergeRowSpan
     */
    public java.lang.String getMergeRowSpan() {
        return mergeRowSpan;
    }


    /**
     * Sets the mergeRowSpan value for this Row.
     * 
     * @param mergeRowSpan
     */
    public void setMergeRowSpan(java.lang.String mergeRowSpan) {
        this.mergeRowSpan = mergeRowSpan;
    }


    /**
     * Gets the opacity value for this Row.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this Row.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the rowCount value for this Row.
     * 
     * @return rowCount
     */
    public java.lang.String getRowCount() {
        return rowCount;
    }


    /**
     * Sets the rowCount value for this Row.
     * 
     * @param rowCount
     */
    public void setRowCount(java.lang.String rowCount) {
        this.rowCount = rowCount;
    }


    /**
     * Gets the rowHeight value for this Row.
     * 
     * @return rowHeight
     */
    public java.lang.String getRowHeight() {
        return rowHeight;
    }


    /**
     * Sets the rowHeight value for this Row.
     * 
     * @param rowHeight
     */
    public void setRowHeight(java.lang.String rowHeight) {
        this.rowHeight = rowHeight;
    }


    /**
     * Gets the shade value for this Row.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this Row.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the split value for this Row.
     * 
     * @return split
     */
    public java.lang.String getSplit() {
        return split;
    }


    /**
     * Sets the split value for this Row.
     * 
     * @param split
     */
    public void setSplit(java.lang.String split) {
        this.split = split;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Row)) return false;
        Row other = (Row) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.autofit==null && other.getAutofit()==null) || 
             (this.autofit!=null &&
              this.autofit.equals(other.getAutofit()))) &&
            ((this.autofitMaxLimit==null && other.getAutofitMaxLimit()==null) || 
             (this.autofitMaxLimit!=null &&
              this.autofitMaxLimit.equals(other.getAutofitMaxLimit()))) &&
            ((this.cells==null && other.getCells()==null) || 
             (this.cells!=null &&
              java.util.Arrays.equals(this.cells, other.getCells()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.gridLines==null && other.getGridLines()==null) || 
             (this.gridLines!=null &&
              java.util.Arrays.equals(this.gridLines, other.getGridLines()))) &&
            ((this.mergeRowSpan==null && other.getMergeRowSpan()==null) || 
             (this.mergeRowSpan!=null &&
              this.mergeRowSpan.equals(other.getMergeRowSpan()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.rowCount==null && other.getRowCount()==null) || 
             (this.rowCount!=null &&
              this.rowCount.equals(other.getRowCount()))) &&
            ((this.rowHeight==null && other.getRowHeight()==null) || 
             (this.rowHeight!=null &&
              this.rowHeight.equals(other.getRowHeight()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.split==null && other.getSplit()==null) || 
             (this.split!=null &&
              this.split.equals(other.getSplit())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAutofit() != null) {
            _hashCode += getAutofit().hashCode();
        }
        if (getAutofitMaxLimit() != null) {
            _hashCode += getAutofitMaxLimit().hashCode();
        }
        if (getCells() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCells());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCells(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getGridLines() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGridLines());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGridLines(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMergeRowSpan() != null) {
            _hashCode += getMergeRowSpan().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getRowCount() != null) {
            _hashCode += getRowCount().hashCode();
        }
        if (getRowHeight() != null) {
            _hashCode += getRowHeight().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getSplit() != null) {
            _hashCode += getSplit().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Row.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Row"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("autofit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "autofit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("autofitMaxLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "autofitMaxLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cells");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "cells"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Cell"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gridLines");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "gridLines"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "GridLine"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mergeRowSpan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "mergeRowSpan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rowCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rowCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rowHeight");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rowHeight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("split");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "split"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
