package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.RunError;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocPage;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocTable;
import com.socgen.sgs.api.quark.engine.domain.element.TBox;
import com.socgen.sgs.api.quark.engine.domain.element.TElement;
import com.socgen.sgs.api.quark.engine.domain.element.TGroup;
import com.socgen.sgs.api.quark.engine.domain.element.TTable;
import com.socgen.sgs.api.quark.engine.domain.helper.TElementHelper;
import com.socgen.sgs.api.quark.engine.domain.task.TaskDocument;
import com.socgen.sgs.api.quark.engine.domain.task.TaskImageOffset;
import com.socgen.sgs.api.quark.engine.domain.task.TaskImagePosition;
import com.socgen.sgs.api.quark.engine.domain.xml.QxpXml;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.enums.StaticTElementNameEnum;
import com.socgen.sgs.api.quark.engine.enums.SubTaskTypeEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import com.socgen.sgs.api.quark.engine.service.task.TaskProcessStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Strategy for processing TaskDocument (document/image insertion into blocs).
 * Handles document formats: IMG, PDF, DOC/RTF/XTG, QXP_Data.
 *
 * <p>Each format has distinct processing logic matching .NET Process_Document.cs exactly:
 * <ul>
 *   <li>IMG: Get TElement template, set image path, create BlocBox in blocsModify</li>
 *   <li>PDF: Multi-page with UPDATE/CREATE logic based on existing blocs in gabarit</li>
 *   <li>DOC/RTF/XTG: Get TElement template, set file path with "file:" prefix, create BlocBox</li>
 *   <li>QXP_Data (value mode): Extract value from source document XML, create BlocBox in blocsUpdate</li>
 *   <li>QXP_Data (style mode): Analyse source project, clone TElement, create bloc in blocsModify</li>
 * </ul>
 *
 * Cross-reference: QXP.Engine.Core.Business.Process_Document
 */
@Component
@Slf4j
public class DocumentTaskProcessStrategy implements TaskProcessStrategy<TaskDocument> {

    // Constants matching .NET Process_Document
    private static final String SOURCE_FILE_ABSOLU_PATTERN = "%s";
    private static final String SOURCE_FILE_DOC_POOL_PATTERN = "file:%s";
    private static final String PDF_BLOC_NAME_PATTERN = "%s_%d";    // 0=prefix, 1=bloc number
    private static final String PDF_PAGE_NAME_PATTERN = "P%d_%s";   // 0=page, 1=bloc name
    private static final String PICTURE_ROTATION_90 = "90";

    @Override
    public Class<TaskDocument> getTaskType() {
        return TaskDocument.class;
    }

    @Override
    public void process(TaskDocument task) {
        log.debug("DocumentTaskProcessStrategy processing task [{}] format={}",
                task.getId(), task.getFormatDocument());

        // Validate destination bloc name
        if (task.getDestinationBlocName() == null || task.getDestinationBlocName().isBlank()) {
            log.warn("Missing destinationBlocName for document task [{}], skipping", task.getId());
            return;
        }

        BlocBox blocBox = null;

        SubTaskTypeEnum subTaskType = task.getSubTaskType();
        if (subTaskType == null) {
            log.warn("Document task [{}] has null sub-task type, skipping", task.getId());
            return;
        }

        switch (subTaskType) {
            case FILE_IMG:
                blocBox = processImg(task);
                break;
            case FILE_PDF:
                processFilePdf(task);
                break;
            case FILE_DOC:
            case FILE_RTF:
            case FILE_XTG:
                blocBox = processDocumentFile(task);
                break;
            case FILE_QXP_DATA:
                processFileQxpData(task);
                break;
            default:
                log.warn("Unsupported sub-task type [{}] for document task [{}]",
                        subTaskType, task.getId());
                return;
        }

        // IMG and DOC/RTF/XTG return a single blocBox to add to blocsModify
        // PDF and QXP_Data handle their own bloc additions internally
        if (blocBox != null) {
            task.getBlocsModify().put(blocBox.getName(), blocBox);
        }
    }

    // ========================================================================
    // IMG format
    // Cross-reference: Process_Document.cs lines 43-48
    // ========================================================================

    /**
     * IMG format: Get TElement template, set image file path, handle rotation.
     * Uses Static_TElement_Name.IMG template.
     * Action is NOT explicitly set (uses default from BlocBase constructor = NONE).
     */
    private BlocBox processImg(TaskDocument task) {
        log.debug("DocumentTaskProcessStrategy IMG: task [{}]", task.getId());

        DocumentDomain doc = task.getDocument();
        if (doc == null) {
            log.warn("IMG task [{}] has no document loaded, skipping", task.getId());
            return null;
        }

        // Get a clone of the IMG TElement template
        TElement tElement = TElementHelper.getTElement(
                StaticTElementNameEnum.IMG, task.getDestinationBlocName());
        if (!(tElement instanceof TBox)) {
            log.warn("IMG task [{}] could not get TBox template", task.getId());
            return null;
        }

        TBox tBox = (TBox) tElement;

        // Set image file path as content value (absolute path)
        // .NET: __tBox.SrcBox.content.value = string.Format(SourceFileAbsoluPattern, task.Document.FileFullPath)
        if (tBox.getSrcBox().getContent() != null) {
            tBox.getSrcBox().getContent().setValue(
                    String.format(SOURCE_FILE_ABSOLU_PATTERN, doc.getFileFullPath()));
        }

        // Handle image rotation
        // .NET: if (task.Rotation_Image) __tBox.SrcBox.picture.angle = "90"
        if (task.isRotationImage() && tBox.getSrcBox().getPicture() != null) {
            tBox.getSrcBox().getPicture().setAngle(PICTURE_ROTATION_90);
        }

        // Create BlocBox from TBox (extracts srcBox and srcExtraBox)
        BlocBox blocBox = new BlocBox(task, task.getDestinationBlocName(),
                tBox.getSrcBox(), tBox.getSrcExtraBox());

        log.debug("IMG bloc [{}] created with path [{}]",
                task.getDestinationBlocName(), doc.getFileFullPath());

        return blocBox;
    }

    // ========================================================================
    // DOC/RTF/XTG format
    // Cross-reference: Process_Document.cs lines 52-58
    // ========================================================================

    /**
     * DOC/RTF/XTG format: Get TElement template, set file path with "file:" prefix.
     * Uses Static_TElement_Name.RTF_DOC_XTG template.
     * Action is NOT explicitly set (uses default = NONE).
     */
    private BlocBox processDocumentFile(TaskDocument task) {
        log.debug("DocumentTaskProcessStrategy DOC/RTF/XTG: task [{}] subType={}",
                task.getId(), task.getSubTaskType());

        DocumentDomain doc = task.getDocument();
        if (doc == null) {
            log.warn("Document file task [{}] has no document loaded, skipping", task.getId());
            return null;
        }

        // Get a clone of the RTF_DOC_XTG TElement template
        TElement tElement = TElementHelper.getTElement(
                StaticTElementNameEnum.RTF_DOC_XTG, task.getDestinationBlocName());
        if (!(tElement instanceof TBox)) {
            log.warn("DOC/RTF/XTG task [{}] could not get TBox template", task.getId());
            return null;
        }

        TBox tBox = (TBox) tElement;

        // Set file path with "file:" prefix as content value
        // .NET: __tBox.SrcBox.content.value = string.Format(SourceFileDocPoolPattern, task.Document.FileFullPath)
        if (tBox.getSrcBox().getContent() != null) {
            tBox.getSrcBox().getContent().setValue(
                    String.format(SOURCE_FILE_DOC_POOL_PATTERN, doc.getFileFullPath()));
        }

        // Create BlocBox from TBox
        BlocBox blocBox = new BlocBox(task, task.getDestinationBlocName(),
                tBox.getSrcBox(), tBox.getSrcExtraBox());

        log.debug("DOC/RTF/XTG bloc [{}] created with path [{}]",
                task.getDestinationBlocName(), doc.getFileFullPath());

        return blocBox;
    }

    // ========================================================================
    // PDF format
    // Cross-reference: Process_Document.cs Process_File_PDF() lines 165-250
    // ========================================================================

    /**
     * PDF format: Multi-page handling with UPDATE/CREATE logic.
     * Compares PDF page count with existing box count in gabarit to determine:
     * - More blocs than PDFs → remove excess pages
     * - Same count → update existing blocs
     * - More PDFs than blocs → create new blocs and pages
     */
    private void processFilePdf(TaskDocument task) {
        log.debug("DocumentTaskProcessStrategy PDF: task [{}]", task.getId());

        DocumentDomain doc = task.getDocument();
        if (doc == null || doc.getPdfFiles().isEmpty()) {
            log.warn("PDF task [{}] has no PDF files, skipping", task.getId());
            return;
        }

        // Get list of existing box names starting with destination prefix in gabarit
        // .NET: task.Run.Gabarit.XML.GetListBoxNameStartWith(task.DestinationBlocName)
        QxpXml gabaritXml = task.getRun().getGabarit().getQxpXml();
        List<String> existingBoxNames = gabaritXml.getListBoxNameStartWith(task.getDestinationBlocName());

        if (existingBoxNames.isEmpty()) {
            // Parity: .NET Process_Document records MissingDestinationBlocNameInTask (Errors.Add(string)
            // → Error_Type.Unspecified) before returning, instead of silently skipping. Finding #39.
            task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED, String.format(
                    "Manque le bloc de destination %s dans la tache %s",
                    task.getDestinationBlocName(), task.getId())));
            log.warn("PDF task [{}] no existing blocs found for prefix [{}], skipping",
                    task.getId(), task.getDestinationBlocName());
            return;
        }

        int pdfFileCount = doc.getPdfFiles().size();
        int existingBoxCount = existingBoxNames.size();

        // Initialize image offset helper
        // .NET: task.Image_Offset = new Task_Image_Offset(task.Offset_Values)
        TaskImageOffset imageOffset = task.getImageOffset();
        if (imageOffset == null && task.getOffsetValues() != null) {
            imageOffset = new TaskImageOffset(task.getOffsetValues());
            task.setImageOffset(imageOffset);
        }

        // Initialize image position helper
        // .NET: task.Image_Position = new Task_Image_Position(task.Position_Values)
        // build position helper UNCONDITIONALLY (ctor maps null/invalid → DEFAULT)
        TaskImagePosition imagePosition = task.getImagePosition();
        if (imagePosition == null) {
            imagePosition = new TaskImagePosition(task.getPositionValues());
            task.setImagePosition(imagePosition);
        }

        int maxPages = Math.max(pdfFileCount, existingBoxCount);

        for (int i = 0; i < maxPages; i++) {

            // CASE 1: More existing blocs than PDF pages → remove excess pages
            // .NET: if(__i < __lstBoxName.Count && __i >= task.Document.PDFFiles.Count)
            if (i < existingBoxCount && i >= pdfFileCount) {
                String blocName = String.format(PDF_BLOC_NAME_PATTERN,
                        task.getDestinationBlocName(), i + 1);
                BlocPage blocPage = new BlocPage(task, blocName);
                blocPage.setRelativePage(i);
                blocPage.setAction(BlocActionEnum.REMOVE);
                task.getBlocsModify().put(blocPage.getName(), blocPage);
            }
            // CASE 2: PDF page exists → create or update bloc
            else {
                String pdfFile = doc.getPdfFiles().get(i);
                String blocName = String.format("%s_%d", task.getDestinationBlocName(), i + 1);

                // Select template: PDF_1 for first page, PDF_N for subsequent
                StaticTElementNameEnum templateName;
                if (i == 0) {
                    templateName = StaticTElementNameEnum.PDF_1;
                } else {
                    templateName = StaticTElementNameEnum.PDF_N;
                }

                TElement tElement = TElementHelper.getTElement(templateName, blocName);
                if (!(tElement instanceof TBox)) {
                    log.warn("PDF task [{}] could not get TBox template for page [{}]",
                            task.getId(), i + 1);
                    continue;
                }

                TBox tBox = (TBox) tElement;

                // Set PDF file path as content value
                // .NET: __tBox.SrcBox.content.value = __doc.GetPDFFileAbsolutePath(__file)
                if (tBox.getSrcBox().getContent() != null) {
                    tBox.getSrcBox().getContent().setValue(pdfFile);
                }

                // Create BlocBox from TBox
                BlocBox blocBox = new BlocBox(task, blocName,
                        tBox.getSrcBox(), tBox.getSrcExtraBox());
                blocBox.setRelativePage(i);

                Box srcBox = blocBox.getSrcBox();
                Box extraBox = blocBox.getSrcExtraBox();

                // Set position for pages after the first
                // .NET: if (__i > 0) { set geometry position from Image_Position }
                if (i > 0 && srcBox != null
                        && srcBox.getGeometry() != null && srcBox.getGeometry().getPosition() != null) {
                    srcBox.getGeometry().getPosition().setLeft(imagePosition.getLeft());
                    srcBox.getGeometry().getPosition().setTop(imagePosition.getTop());
                    srcBox.getGeometry().getPosition().setRight(imagePosition.getRight());
                    srcBox.getGeometry().getPosition().setBottom(imagePosition.getBottom());
                }

                // Handle rotation and offset
                if (task.isRotationImage()) {
                    // Rotation: set angle on srcBox picture
                    if (tBox.getSrcBox() != null && tBox.getSrcBox().getPicture() != null) {
                        tBox.getSrcBox().getPicture().setAngle(PICTURE_ROTATION_90);
                    }
                    // Offset across on extraBox when rotated
                    if (extraBox != null && extraBox.getPicture() != null && imageOffset != null) {
                        extraBox.getPicture().setOffsetAcross(imageOffset.getOffset(i));
                    }
                } else {
                    // Offset down on extraBox when not rotated
                    if (extraBox != null && extraBox.getPicture() != null && imageOffset != null) {
                        extraBox.getPicture().setOffsetDown(imageOffset.getOffset(i));
                    }
                }

                // Determine action: UPDATE if box exists, CREATE if new
                // .NET: if(__i < __lstBoxName.Count) → UPDATE, else → CREATE (with new page)
                if (i < existingBoxCount) {
                    blocBox.setAction(BlocActionEnum.UPDATE);
                } else {
                    // Need to create a new page first
                    String pageName = String.format(PDF_PAGE_NAME_PATTERN, i, blocName);
                    BlocPage blocPage = new BlocPage(task, pageName);
                    blocPage.setAction(BlocActionEnum.CREATE);
                    blocPage.setRelativePage(i);
                    task.getBlocsModify().put(blocPage.getName(), blocPage);

                    // Then create the box
                    blocBox.setAction(BlocActionEnum.CREATE);
                }

                task.getBlocsModify().put(blocBox.getName(), blocBox);

                log.debug("PDF page [{}] bloc [{}] action={}", i + 1, blocName, blocBox.getAction());
            }
        }
    }

    // ========================================================================
    // QXP_Data format
    // Cross-reference: Process_Document.cs Process_File_QXP_Data() lines 86-162
    // ========================================================================

    /**
     * QXP_Data: Copy content from a previous QXP document.
     * Two modes based on conserverStyle flag:
     * - false (VALUE mode): Extract text value from source XML, store in blocsUpdate
     * - true (STYLE mode): Analyse source project, clone elements, store in blocsModify
     */
    private void processFileQxpData(TaskDocument task) {
        log.debug("DocumentTaskProcessStrategy QXP_DATA: task [{}] conserverStyle={}",
                task.getId(), task.isConserverStyle());

        // Both source and destination must be set
        if (task.getSourceBlocName() == null || task.getSourceBlocName().isBlank()
                || task.getDestinationBlocName() == null || task.getDestinationBlocName().isBlank()) {
            log.warn("QXP_DATA task [{}] requires both source and destination bloc names", task.getId());
            return;
        }

        DocumentDomain doc = task.getDocument();
        if (doc == null) {
            log.warn("QXP_DATA task [{}] has no document loaded, skipping", task.getId());
            return;
        }

        // If style mode, analyse the project structure first
        // .NET: if(task.Conserver_Style) { task.Document.QXPProject.Analyse(task, false); }
        if (task.isConserverStyle()) {
            doc.getQxpProject().analyse(task, false);
        }

        // Split pipe-separated source and destination names
        String[] sourceNames = task.getSourceBlocName().split("\\|");
        String[] destNames = task.getDestinationBlocName().split("\\|");

        // .NET has an unresolved TODO here: it iterates the SOURCE length and indexes the
        // DESTINATION array, so a mismatch would throw IndexOutOfRange. We instead surface a clear
        // run error and process only the safe overlap (no crash, no silent drop). (2 = Critique)
        if (sourceNames.length != destNames.length) {
            task.getRun().getErrors().add(new RunError(2,
                    "QXP_Data: nombre de blocs source (" + sourceNames.length
                            + ") different de la destination (" + destNames.length
                            + ") pour la tache " + task.getId()));
            log.warn("QXP_Data source/destination count mismatch ({} vs {}) for task [{}]",
                    sourceNames.length, destNames.length, task.getId());
        }
        int count = Math.min(sourceNames.length, destNames.length);

        for (int i = 0; i < count; i++) {
            String sourceName = sourceNames[i].trim();
            String destName = destNames[i].trim();

            if (sourceName.isEmpty() || destName.isEmpty()) {
                continue;
            }

            if (task.isConserverStyle()) {
                processQxpDataStyle(task, doc, sourceName, destName);
            } else {
                processQxpDataValue(task, doc, sourceName, destName);
            }
        }
    }

    /**
     * QXP_Data VALUE mode: Extract text value from source document XML.
     * Creates BlocBox in blocsUpdate with action UPDATE.
     *
     * Cross-reference: Process_Document.cs lines 152-158
     */
    private void processQxpDataValue(TaskDocument task, DocumentDomain doc,
                                     String sourceName, String destName) {
        // Extract value from source document's XML structure
        // .NET: string __bloc_Value = __doc.XML.GetValue(__sourceName)
        String blocValue = doc.getQxpXml().getValue(sourceName);

        BlocBox blocBox = new BlocBox(task, destName, blocValue);
        blocBox.setAction(BlocActionEnum.UPDATE);

        task.getBlocsUpdate().put(blocBox.getName(), blocBox);

        log.debug("QXP_DATA VALUE: bloc [{}] = [{}] from source [{}]",
                destName, blocValue, sourceName);
    }

    /**
     * QXP_Data STYLE mode: Clone element structure from source project.
     * Looks up source element in QXPProject.Elements, creates appropriate bloc type.
     * Supports TBox, TTable, and TGroup (TGroup not yet treated in .NET either).
     *
     * Cross-reference: Process_Document.cs lines 118-149
     */
    private void processQxpDataStyle(TaskDocument task, DocumentDomain doc,
                                     String sourceName, String destName) {
        Map<String, TElement> elements = doc.getQxpProject().getElements();

        if (elements == null || !elements.containsKey(sourceName)) {
            log.warn("QXP_DATA STYLE task [{}] source element [{}] not found in project",
                    task.getId(), sourceName);
            return;
        }

        TElement tElement = elements.get(sourceName);

        // Case 1: Source is a TBox
        // .NET: Bloc_Box __blocBox = new Bloc_Box(task, __destinationName, __tBox);
        //       __blocBox.Action = Bloc_Action.UPDATE;
        if (tElement instanceof TBox) {
            TBox srcTBox = (TBox) tElement;

            // Create a new TBox with style+value transferred from source
            TBox destTBox = TElementHelper.getNewTBoxStyleValueFromTBox(srcTBox, destName);
            if (destTBox == null) {
                log.warn("QXP_DATA STYLE task [{}] could not transfer TBox style for [{}]",
                        task.getId(), sourceName);
                return;
            }

            BlocBox blocBox = new BlocBox(task, destName,
                    destTBox.getSrcBox(), destTBox.getSrcExtraBox());
            blocBox.setAction(BlocActionEnum.UPDATE);

            // Genuine duplicate → record an Unspecified error (matches .NET BlocDupliquerDansTache
            // severity), WITHOUT the .NET quirk of flagging every TBox style-copy. The .NET code
            // added the bloc inline then re-checked ContainsKey (always true) — we only flag a real
            // collision.
            if (task.getBlocsModify().containsKey(blocBox.getName())) {
                task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                        "BlocDupliquerDansTache: bloc [" + blocBox.getName()
                                + "] deja present dans la tache " + task.getId()));
                log.warn("QXP_DATA STYLE task [{}] duplicate bloc name [{}]",
                        task.getId(), blocBox.getName());
            } else {
                task.getBlocsModify().put(blocBox.getName(), blocBox);
            }

            log.debug("QXP_DATA STYLE TBox: bloc [{}] cloned from source [{}]",
                    destName, sourceName);
        }
        // Case 2: Source is a TTable
        // .NET: Bloc_Table __blocTable = new Bloc_Table(task, __destinationName, __tTable);
        //       __blocTable.Action = Bloc_Action.UPDATE;
        else if (tElement instanceof TTable) {
            TTable srcTTable = (TTable) tElement;

            TTable destTTable = TElementHelper.getNewTTableStyleValueFromTTable(srcTTable, destName);
            if (destTTable == null) {
                log.warn("QXP_DATA STYLE task [{}] could not transfer TTable style for [{}]",
                        task.getId(), sourceName);
                return;
            }

            BlocTable blocTable = new BlocTable(task, destName, destTTable.getSrcTable());
            blocTable.setAction(BlocActionEnum.UPDATE);

            if (task.getBlocsModify().containsKey(blocTable.getName())) {
                task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                        "BlocDupliquerDansTache: bloc [" + blocTable.getName()
                                + "] deja present dans la tache " + task.getId()));
                log.warn("QXP_DATA STYLE task [{}] duplicate bloc name [{}]",
                        task.getId(), blocTable.getName());
            } else {
                task.getBlocsModify().put(blocTable.getName(), blocTable);
            }

            log.debug("QXP_DATA STYLE TTable: bloc [{}] cloned from source [{}]",
                    destName, sourceName);
        }
        // Case 3: Source is a TGroup — not yet treated
        // .NET: "Pas traité pour le moment"
        else if (tElement instanceof TGroup) {
            log.debug("QXP_DATA STYLE TGroup: not yet treated for source [{}]", sourceName);
        }
    }
}