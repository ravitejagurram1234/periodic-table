/**
 * Interactivity.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Interactivity  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.DataProvider dataProvider;

    private java.lang.String ownerXTId;

    private java.lang.String type;

    public Interactivity() {
    }

    public Interactivity(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.DataProvider dataProvider,
           java.lang.String ownerXTId,
           java.lang.String type) {
        super(
            request);
        this.dataProvider = dataProvider;
        this.ownerXTId = ownerXTId;
        this.type = type;
    }


    /**
     * Gets the dataProvider value for this Interactivity.
     * 
     * @return dataProvider
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.DataProvider getDataProvider() {
        return dataProvider;
    }


    /**
     * Sets the dataProvider value for this Interactivity.
     * 
     * @param dataProvider
     */
    public void setDataProvider(com.socgen.sgs.api.quark.engine.integration.soap.generated.DataProvider dataProvider) {
        this.dataProvider = dataProvider;
    }


    /**
     * Gets the ownerXTId value for this Interactivity.
     * 
     * @return ownerXTId
     */
    public java.lang.String getOwnerXTId() {
        return ownerXTId;
    }


    /**
     * Sets the ownerXTId value for this Interactivity.
     * 
     * @param ownerXTId
     */
    public void setOwnerXTId(java.lang.String ownerXTId) {
        this.ownerXTId = ownerXTId;
    }


    /**
     * Gets the type value for this Interactivity.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this Interactivity.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Interactivity)) return false;
        Interactivity other = (Interactivity) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.dataProvider==null && other.getDataProvider()==null) || 
             (this.dataProvider!=null &&
              this.dataProvider.equals(other.getDataProvider()))) &&
            ((this.ownerXTId==null && other.getOwnerXTId()==null) || 
             (this.ownerXTId!=null &&
              this.ownerXTId.equals(other.getOwnerXTId()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDataProvider() != null) {
            _hashCode += getDataProvider().hashCode();
        }
        if (getOwnerXTId() != null) {
            _hashCode += getOwnerXTId().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Interactivity.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Interactivity"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataProvider");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "dataProvider"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "DataProvider"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerXTId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ownerXTId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
