package com.socgen.sgs.api.quark.engine.enums;

import lombok.Getter;

/** Represents the type of a task in a run. */
@Getter
public enum TaskTypeEnum {

    SYSTEM(0),
    SQL(1),
    DOC_EOS(2),
    DOC_QXP(3),
    SQL_DYNAMIQUE(4),
    COMPARTIMENTS(5);

    private final int code;

    TaskTypeEnum(int code) {
        this.code = code;
    }

    public static TaskTypeEnum fromCode(int code) {
        for (TaskTypeEnum type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        return SYSTEM;
    }
}

