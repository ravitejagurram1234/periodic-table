package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.infra.dao.GetCompartimentRunsDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DAO implementation that calls QXP_PK_RUN.Get_Compartiment_Runs Oracle function.
 *
 * <p>Oracle function signature:
 * <pre>
 * FUNCTION Get_Compartiment_Runs(
 *     p_id_gabarit_tete   IN NUMBER,
 *     p_id_structure      IN VARCHAR2,
 *     p_id_gabarit_fils   IN NUMBER,
 *     p_id_type_rapport   IN NUMBER,
 *     p_id_langue         IN NUMBER,
 *     p_date_echeance     IN DATE,
 *     p_to_generate       IN NUMBER
 * ) RETURN qxp_pk_common.hcur
 * </pre>
 *
 * Returns cursor with columns: id_fnd_code (VARCHAR2), id_run (NUMBER)
 *
 * Cross-reference: .NET Proxy_Run.Get_Compartiment_Runs()
 */
@Repository
@Slf4j
@RequiredArgsConstructor
public class GetCompartimentRunsDaoImpl implements GetCompartimentRunsDao {

    private static final String RESULT_KEY = "result_cursor";

    private final DataSource dataSource;

    private SimpleJdbcCall getCompartimentRunsCall;

    @PostConstruct
    private void init() {
        this.getCompartimentRunsCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_Compartiment_Runs")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR,
                                (ResultSet rs, int rowNum) -> {
                                    String idFndCode = rs.getString("id_fnd_code");
                                    int idRun = rs.getInt("id_run");
                                    if (rs.wasNull()) {
                                        idRun = 0;
                                    }
                                    return new String[]{idFndCode, String.valueOf(idRun)};
                                }),
                        new SqlParameter("p_id_gabarit_tete", Types.NUMERIC),
                        new SqlParameter("p_id_structure", Types.VARCHAR),
                        new SqlParameter("p_id_gabarit_fils", Types.NUMERIC),
                        new SqlParameter("p_id_type_rapport", Types.NUMERIC),
                        new SqlParameter("p_id_langue", Types.NUMERIC),
                        new SqlParameter("p_date_echeance", Types.DATE),
                        new SqlParameter("p_to_generate", Types.NUMERIC)
                );
    }

    @Override
    public LinkedHashMap<String, Integer> getCompartimentRuns(int idGabaritTete, String idStructure,
                                                              int idGabaritFils, int idTypeRapport,
                                                              int idLangue, LocalDate dateEcheance,
                                                              boolean toGenerate) {
        log.info("Fetching compartment runs for gabarit={}, structure={}, gabaritFils={}",
                idGabaritTete, idStructure, idGabaritFils);

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_gabarit_tete", idGabaritTete)
                .addValue("p_id_structure", idStructure)
                .addValue("p_id_gabarit_fils", idGabaritFils)
                .addValue("p_id_type_rapport", idTypeRapport)
                .addValue("p_id_langue", idLangue)
                .addValue("p_date_echeance", java.sql.Date.valueOf(dateEcheance))
                .addValue("p_to_generate", toGenerate ? 1 : 0);

        try {
            Map<String, Object> result = getCompartimentRunsCall.execute(params);

            @SuppressWarnings("unchecked")
            List<String[]> rows = (List<String[]>) result.get(RESULT_KEY);

            // Preserve insertion order (matches .NET ordering by asgc.position)
            LinkedHashMap<String, Integer> compartimentRuns = new LinkedHashMap<>();

            if (rows != null) {
                for (String[] row : rows) {
                    String idFndCode = row[0];
                    int idRun = Integer.parseInt(row[1]);
                    compartimentRuns.put(idFndCode, idRun);
                }
            }

            log.info("Found {} compartment runs for gabarit={}", compartimentRuns.size(), idGabaritTete);
            return compartimentRuns;

        } catch (Exception e) {
            // Parity: .NET Proxy_Run.Get_Compartiment_Runs has no try/catch — a DB/cursor failure must
            // fail the run, not be swallowed into an empty map (which would masquerade as "no rows" and
            // silently drop compartiments). A legitimately empty 0-row result still flows through above
            // and is handled by CompartimentTaskProcessStrategy as the NoneRunCompartiment critique.
            // Finding #48.
            log.error("Error fetching compartment runs for gabarit={}: {}", idGabaritTete, e.getMessage(), e);
            throw new RuntimeException(
                    "Failed to fetch compartment runs for gabarit=" + idGabaritTete, e);
        }
    }
}