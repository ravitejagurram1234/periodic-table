package com.socgen.sgs.api.quark.engine.domain.task;
import com.socgen.sgs.api.quark.engine.enums.TaskExceptionTypeEnum;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaskException {
    private String tableName;
    private String name;
    private int[] indexLignes;
    private TaskExceptionTypeEnum type = TaskExceptionTypeEnum.NONE;
    public TaskException(String tableName, String name, int[] indexLignes, TaskExceptionTypeEnum type) {
        this.tableName  = tableName;
        this.name       = name;
        this.indexLignes = indexLignes;
        this.type       = type;
    }
}
