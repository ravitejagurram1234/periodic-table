package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

import lombok.Getter;

/**
 * QXPS GET message for fetching XML content from a document.
 *
 * Two modes:
 * - With boxName: {baseUrl}/xml/{documentName}?box={boxName} (single box XML)
 * - Without boxName: {baseUrl}/xml/{documentName} (full document XML)
 *
 * Cross-reference: .NET QXP_XML.Create_From_File() uses full document XML
 */
@Getter
public class FetchXmlMessage implements QxpsMessage {

    private static final String MESSAGE_PATH = "xml";

    private final String boxName;

    /**
     * Fetch full document XML (no box filter).
     * Used by Check step for overflow detection and data collection.
     */
    public FetchXmlMessage() {
        this.boxName = null;
    }

    /**
     * Fetch XML for a specific box.
     * Used for DID parsing, specific value reads.
     *
     * @param boxName the box name to filter
     */
    public FetchXmlMessage(String boxName) {
        this.boxName = boxName;
    }

    @Override
    public String getCommandPath() {
        return MESSAGE_PATH;
    }

    @Override
    public String getCommandQuery() {
        if (boxName != null && !boxName.isEmpty()) {
            return "box=" + boxName;
        }
        return null;
    }

    @Override
    public byte[] getData() {
        return null;
    }

    @Override
    public boolean isPost() {
        return false;
    }

    @Override
    public MessagePriority getPriority() {
        return MessagePriority.LOWEST;
    }
}