/**
 * Xref.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Xref  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String charStyle;

    private java.lang.String href;

    private java.lang.String hyperlink;

    private java.lang.String includeAboveBelow;

    private java.lang.String separator;

    private java.lang.String xrefStyle;

    public Xref() {
    }

    public Xref(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String charStyle,
           java.lang.String href,
           java.lang.String hyperlink,
           java.lang.String includeAboveBelow,
           java.lang.String separator,
           java.lang.String xrefStyle) {
        super(
            request);
        this.charStyle = charStyle;
        this.href = href;
        this.hyperlink = hyperlink;
        this.includeAboveBelow = includeAboveBelow;
        this.separator = separator;
        this.xrefStyle = xrefStyle;
    }


    /**
     * Gets the charStyle value for this Xref.
     * 
     * @return charStyle
     */
    public java.lang.String getCharStyle() {
        return charStyle;
    }


    /**
     * Sets the charStyle value for this Xref.
     * 
     * @param charStyle
     */
    public void setCharStyle(java.lang.String charStyle) {
        this.charStyle = charStyle;
    }


    /**
     * Gets the href value for this Xref.
     * 
     * @return href
     */
    public java.lang.String getHref() {
        return href;
    }


    /**
     * Sets the href value for this Xref.
     * 
     * @param href
     */
    public void setHref(java.lang.String href) {
        this.href = href;
    }


    /**
     * Gets the hyperlink value for this Xref.
     * 
     * @return hyperlink
     */
    public java.lang.String getHyperlink() {
        return hyperlink;
    }


    /**
     * Sets the hyperlink value for this Xref.
     * 
     * @param hyperlink
     */
    public void setHyperlink(java.lang.String hyperlink) {
        this.hyperlink = hyperlink;
    }


    /**
     * Gets the includeAboveBelow value for this Xref.
     * 
     * @return includeAboveBelow
     */
    public java.lang.String getIncludeAboveBelow() {
        return includeAboveBelow;
    }


    /**
     * Sets the includeAboveBelow value for this Xref.
     * 
     * @param includeAboveBelow
     */
    public void setIncludeAboveBelow(java.lang.String includeAboveBelow) {
        this.includeAboveBelow = includeAboveBelow;
    }


    /**
     * Gets the separator value for this Xref.
     * 
     * @return separator
     */
    public java.lang.String getSeparator() {
        return separator;
    }


    /**
     * Sets the separator value for this Xref.
     * 
     * @param separator
     */
    public void setSeparator(java.lang.String separator) {
        this.separator = separator;
    }


    /**
     * Gets the xrefStyle value for this Xref.
     * 
     * @return xrefStyle
     */
    public java.lang.String getXrefStyle() {
        return xrefStyle;
    }


    /**
     * Sets the xrefStyle value for this Xref.
     * 
     * @param xrefStyle
     */
    public void setXrefStyle(java.lang.String xrefStyle) {
        this.xrefStyle = xrefStyle;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Xref)) return false;
        Xref other = (Xref) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.charStyle==null && other.getCharStyle()==null) || 
             (this.charStyle!=null &&
              this.charStyle.equals(other.getCharStyle()))) &&
            ((this.href==null && other.getHref()==null) || 
             (this.href!=null &&
              this.href.equals(other.getHref()))) &&
            ((this.hyperlink==null && other.getHyperlink()==null) || 
             (this.hyperlink!=null &&
              this.hyperlink.equals(other.getHyperlink()))) &&
            ((this.includeAboveBelow==null && other.getIncludeAboveBelow()==null) || 
             (this.includeAboveBelow!=null &&
              this.includeAboveBelow.equals(other.getIncludeAboveBelow()))) &&
            ((this.separator==null && other.getSeparator()==null) || 
             (this.separator!=null &&
              this.separator.equals(other.getSeparator()))) &&
            ((this.xrefStyle==null && other.getXrefStyle()==null) || 
             (this.xrefStyle!=null &&
              this.xrefStyle.equals(other.getXrefStyle())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCharStyle() != null) {
            _hashCode += getCharStyle().hashCode();
        }
        if (getHref() != null) {
            _hashCode += getHref().hashCode();
        }
        if (getHyperlink() != null) {
            _hashCode += getHyperlink().hashCode();
        }
        if (getIncludeAboveBelow() != null) {
            _hashCode += getIncludeAboveBelow().hashCode();
        }
        if (getSeparator() != null) {
            _hashCode += getSeparator().hashCode();
        }
        if (getXrefStyle() != null) {
            _hashCode += getXrefStyle().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Xref.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Xref"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("charStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "charStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("href");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "href"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hyperlink");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hyperlink"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeAboveBelow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "includeAboveBelow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("separator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "separator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xrefStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "xrefStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
