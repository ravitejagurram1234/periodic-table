/**
 * Publication.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Publication  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String name;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.PublicationChannel[] publicationChannels;

    private java.lang.String UID;

    public Publication() {
    }

    public Publication(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String name,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.PublicationChannel[] publicationChannels,
           java.lang.String UID) {
        super(
            request);
        this.name = name;
        this.publicationChannels = publicationChannels;
        this.UID = UID;
    }


    /**
     * Gets the name value for this Publication.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Publication.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the publicationChannels value for this Publication.
     * 
     * @return publicationChannels
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PublicationChannel[] getPublicationChannels() {
        return publicationChannels;
    }


    /**
     * Sets the publicationChannels value for this Publication.
     * 
     * @param publicationChannels
     */
    public void setPublicationChannels(com.socgen.sgs.api.quark.engine.integration.soap.generated.PublicationChannel[] publicationChannels) {
        this.publicationChannels = publicationChannels;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PublicationChannel getPublicationChannels(int i) {
        return this.publicationChannels[i];
    }

    public void setPublicationChannels(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.PublicationChannel _value) {
        this.publicationChannels[i] = _value;
    }


    /**
     * Gets the UID value for this Publication.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Publication.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Publication)) return false;
        Publication other = (Publication) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.publicationChannels==null && other.getPublicationChannels()==null) || 
             (this.publicationChannels!=null &&
              java.util.Arrays.equals(this.publicationChannels, other.getPublicationChannels()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getPublicationChannels() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPublicationChannels());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPublicationChannels(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Publication.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Publication"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publicationChannels");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "publicationChannels"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PublicationChannel"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
