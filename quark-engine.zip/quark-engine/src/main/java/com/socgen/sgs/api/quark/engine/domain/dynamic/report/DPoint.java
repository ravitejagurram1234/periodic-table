package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Represents a position (left, top) in a dynamic document.
 *
 * Cross-reference: QXP.Engine.Core.DPoint
 */
@Getter
@Setter
public class DPoint {

    private BigDecimal left;
    private BigDecimal top;

    /** Origin point (0, 0). */
    public static final DPoint DEFAULT = new DPoint(BigDecimal.ZERO, BigDecimal.ZERO);

    /**
     * Create a DPoint at origin.
     */
    public DPoint() {
        this.left = BigDecimal.ZERO;
        this.top = BigDecimal.ZERO;
    }

    /**
     * Create a DPoint from another point (copy).
     *
     * @param start the source point
     */
    public DPoint(DPoint start) {
        this.left = start.getLeft();
        this.top = start.getTop();
    }

    /**
     * Create a DPoint at a specific position.
     *
     * @param left left position
     * @param top  top position
     */
    public DPoint(BigDecimal left, BigDecimal top) {
        this.left = left;
        this.top = top;
    }

    /**
     * Reset the point to new coordinates.
     *
     * @param left new left position
     * @param top  new top position
     */
    public void reset(BigDecimal left, BigDecimal top) {
        this.left = left;
        this.top = top;
    }
}