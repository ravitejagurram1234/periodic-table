package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

import com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 * QXPS GET message for setting name/value parameters on a document.
 * Each NameValueParam becomes a query parameter: paramName=textValue
 *
 * URL: {baseUrl}/{documentName}?name1=value1&name2=value2
 * NOTE: path is NULL — params go directly in the query string.
 * NOTE: This is a GET, not a POST.
 *
 * Cross-reference: .NET QXPS_Message_ParamsValue
 */
@Getter
public class ParamsValueMessage implements QxpsMessage {

    private final NameValueParam[] nameValues;

    public ParamsValueMessage(NameValueParam[] nameValues) {
        this.nameValues = nameValues != null ? nameValues : new NameValueParam[0];
    }

    @Override
    public String getCommandPath() {
        return null;
    }

    @Override
    public String getCommandQuery() {
        if (nameValues.length == 0) {
            return null;
        }
        List<String> args = new ArrayList<>();
        for (NameValueParam nv : nameValues) {
            args.add(nv.getParamName() + "=" + nv.getTextValue());
        }
        return String.join("&", args);
    }

    @Override
    public byte[] getData() {
        return null;
    }

    @Override
    public boolean isPost() {
        return false;
    }
}
