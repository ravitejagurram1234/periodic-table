/**
 * FlexContainer.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class FlexContainer  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignContent;

    private java.lang.String alignItems;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content;

    private java.lang.String flexDirection;

    private java.lang.String flexWrap;

    private java.lang.String justifyContent;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture;

    public FlexContainer() {
    }

    public FlexContainer(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignContent,
           java.lang.String alignItems,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content,
           java.lang.String flexDirection,
           java.lang.String flexWrap,
           java.lang.String justifyContent,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture) {
        super(
            request);
        this.alignContent = alignContent;
        this.alignItems = alignItems;
        this.content = content;
        this.flexDirection = flexDirection;
        this.flexWrap = flexWrap;
        this.justifyContent = justifyContent;
        this.picture = picture;
    }


    /**
     * Gets the alignContent value for this FlexContainer.
     * 
     * @return alignContent
     */
    public java.lang.String getAlignContent() {
        return alignContent;
    }


    /**
     * Sets the alignContent value for this FlexContainer.
     * 
     * @param alignContent
     */
    public void setAlignContent(java.lang.String alignContent) {
        this.alignContent = alignContent;
    }


    /**
     * Gets the alignItems value for this FlexContainer.
     * 
     * @return alignItems
     */
    public java.lang.String getAlignItems() {
        return alignItems;
    }


    /**
     * Sets the alignItems value for this FlexContainer.
     * 
     * @param alignItems
     */
    public void setAlignItems(java.lang.String alignItems) {
        this.alignItems = alignItems;
    }


    /**
     * Gets the content value for this FlexContainer.
     * 
     * @return content
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Content getContent() {
        return content;
    }


    /**
     * Sets the content value for this FlexContainer.
     * 
     * @param content
     */
    public void setContent(com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content) {
        this.content = content;
    }


    /**
     * Gets the flexDirection value for this FlexContainer.
     * 
     * @return flexDirection
     */
    public java.lang.String getFlexDirection() {
        return flexDirection;
    }


    /**
     * Sets the flexDirection value for this FlexContainer.
     * 
     * @param flexDirection
     */
    public void setFlexDirection(java.lang.String flexDirection) {
        this.flexDirection = flexDirection;
    }


    /**
     * Gets the flexWrap value for this FlexContainer.
     * 
     * @return flexWrap
     */
    public java.lang.String getFlexWrap() {
        return flexWrap;
    }


    /**
     * Sets the flexWrap value for this FlexContainer.
     * 
     * @param flexWrap
     */
    public void setFlexWrap(java.lang.String flexWrap) {
        this.flexWrap = flexWrap;
    }


    /**
     * Gets the justifyContent value for this FlexContainer.
     * 
     * @return justifyContent
     */
    public java.lang.String getJustifyContent() {
        return justifyContent;
    }


    /**
     * Sets the justifyContent value for this FlexContainer.
     * 
     * @param justifyContent
     */
    public void setJustifyContent(java.lang.String justifyContent) {
        this.justifyContent = justifyContent;
    }


    /**
     * Gets the picture value for this FlexContainer.
     * 
     * @return picture
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture getPicture() {
        return picture;
    }


    /**
     * Sets the picture value for this FlexContainer.
     * 
     * @param picture
     */
    public void setPicture(com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture) {
        this.picture = picture;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FlexContainer)) return false;
        FlexContainer other = (FlexContainer) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignContent==null && other.getAlignContent()==null) || 
             (this.alignContent!=null &&
              this.alignContent.equals(other.getAlignContent()))) &&
            ((this.alignItems==null && other.getAlignItems()==null) || 
             (this.alignItems!=null &&
              this.alignItems.equals(other.getAlignItems()))) &&
            ((this.content==null && other.getContent()==null) || 
             (this.content!=null &&
              this.content.equals(other.getContent()))) &&
            ((this.flexDirection==null && other.getFlexDirection()==null) || 
             (this.flexDirection!=null &&
              this.flexDirection.equals(other.getFlexDirection()))) &&
            ((this.flexWrap==null && other.getFlexWrap()==null) || 
             (this.flexWrap!=null &&
              this.flexWrap.equals(other.getFlexWrap()))) &&
            ((this.justifyContent==null && other.getJustifyContent()==null) || 
             (this.justifyContent!=null &&
              this.justifyContent.equals(other.getJustifyContent()))) &&
            ((this.picture==null && other.getPicture()==null) || 
             (this.picture!=null &&
              this.picture.equals(other.getPicture())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignContent() != null) {
            _hashCode += getAlignContent().hashCode();
        }
        if (getAlignItems() != null) {
            _hashCode += getAlignItems().hashCode();
        }
        if (getContent() != null) {
            _hashCode += getContent().hashCode();
        }
        if (getFlexDirection() != null) {
            _hashCode += getFlexDirection().hashCode();
        }
        if (getFlexWrap() != null) {
            _hashCode += getFlexWrap().hashCode();
        }
        if (getJustifyContent() != null) {
            _hashCode += getJustifyContent().hashCode();
        }
        if (getPicture() != null) {
            _hashCode += getPicture().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FlexContainer.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "FlexContainer"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignContent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignContent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignItems");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("content");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "content"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Content"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flexDirection");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "flexDirection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flexWrap");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "flexWrap"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("justifyContent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "justifyContent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picture");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "picture"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Picture"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
