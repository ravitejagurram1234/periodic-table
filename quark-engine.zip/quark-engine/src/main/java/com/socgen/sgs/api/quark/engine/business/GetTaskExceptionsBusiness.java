package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.infra.dao.GetTaskExceptionsDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/** Orchestrates retrieval of task exceptions for a run. */
@Component
@RequiredArgsConstructor
@Slf4j
public class GetTaskExceptionsBusiness {

    private final GetTaskExceptionsDao getTaskExceptionsDao;

    /**
     * Retrieves the raw task-exception rows for the given run ID.
     *
     * @param runId the run identifier
     * @return list of task-exception row maps
     */
    public List<Map<String, Object>> execute(int runId) {
        log.info("Business layer: loading task exceptions for runId: {}", runId);
        return getTaskExceptionsDao.getTaskExceptions(runId);
    }
}

