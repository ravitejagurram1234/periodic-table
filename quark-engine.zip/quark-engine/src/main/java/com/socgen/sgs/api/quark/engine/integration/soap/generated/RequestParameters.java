/**
 * RequestParameters.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class RequestParameters  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam[] params;

    private java.lang.String requestNamespace;

    public RequestParameters() {
    }

    public RequestParameters(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam[] params,
           java.lang.String requestNamespace) {
        super(
            request);
        this.params = params;
        this.requestNamespace = requestNamespace;
    }


    /**
     * Gets the params value for this RequestParameters.
     * 
     * @return params
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam[] getParams() {
        return params;
    }


    /**
     * Sets the params value for this RequestParameters.
     * 
     * @param params
     */
    public void setParams(com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam[] params) {
        this.params = params;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam getParams(int i) {
        return this.params[i];
    }

    public void setParams(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam _value) {
        this.params[i] = _value;
    }


    /**
     * Gets the requestNamespace value for this RequestParameters.
     * 
     * @return requestNamespace
     */
    public java.lang.String getRequestNamespace() {
        return requestNamespace;
    }


    /**
     * Sets the requestNamespace value for this RequestParameters.
     * 
     * @param requestNamespace
     */
    public void setRequestNamespace(java.lang.String requestNamespace) {
        this.requestNamespace = requestNamespace;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RequestParameters)) return false;
        RequestParameters other = (RequestParameters) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.params==null && other.getParams()==null) || 
             (this.params!=null &&
              java.util.Arrays.equals(this.params, other.getParams()))) &&
            ((this.requestNamespace==null && other.getRequestNamespace()==null) || 
             (this.requestNamespace!=null &&
              this.requestNamespace.equals(other.getRequestNamespace())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getParams() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParams());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParams(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRequestNamespace() != null) {
            _hashCode += getRequestNamespace().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RequestParameters.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RequestParameters"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("params");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "params"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "NameValueParam"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestNamespace");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "requestNamespace"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
