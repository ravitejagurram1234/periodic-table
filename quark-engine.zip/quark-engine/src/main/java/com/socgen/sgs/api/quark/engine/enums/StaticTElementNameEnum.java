package com.socgen.sgs.api.quark.engine.enums;

/**
 * Names of static template elements used by certain tasks (IMG, PDF, DOC, etc.).
 * These are pre-built TElement instances loaded at startup by TElementHelper.
 *
 * Cross-reference: QXP.Engine.Core.Static_TElement_Name
 */
public enum StaticTElementNameEnum {

    /** First PDF bloc in a list (update-only mode). */
    PDF_1,

    /** Subsequent PDF blocs (can be create or update). */
    PDF_N,

    /** Image insertion (JPG, JPEG, EPS, GIF, PNG, TIF, TIFF). */
    IMG,

    /** Document insertion (RTF, DOC, XTG fragment). */
    RTF_DOC_XTG,

    /** Move a bloc from one page to another. */
    MOVE_BLOC,

    /** Move a bloc and update its value. */
    MOVE_BLOC_VALUE,

    /** Empty bloc with no properties. */
    EMPTY_BLOC,

    /** Empty table with no properties. */
    EMPTY_TABLE
}