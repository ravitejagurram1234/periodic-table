/**
 * ContinuedHeader.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ContinuedHeader  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String appliedTo;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] rows;

    public ContinuedHeader() {
    }

    public ContinuedHeader(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String appliedTo,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] rows) {
        super(
            request);
        this.appliedTo = appliedTo;
        this.rows = rows;
    }


    /**
     * Gets the appliedTo value for this ContinuedHeader.
     * 
     * @return appliedTo
     */
    public java.lang.String getAppliedTo() {
        return appliedTo;
    }


    /**
     * Sets the appliedTo value for this ContinuedHeader.
     * 
     * @param appliedTo
     */
    public void setAppliedTo(java.lang.String appliedTo) {
        this.appliedTo = appliedTo;
    }


    /**
     * Gets the rows value for this ContinuedHeader.
     * 
     * @return rows
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] getRows() {
        return rows;
    }


    /**
     * Sets the rows value for this ContinuedHeader.
     * 
     * @param rows
     */
    public void setRows(com.socgen.sgs.api.quark.engine.integration.soap.generated.Row[] rows) {
        this.rows = rows;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Row getRows(int i) {
        return this.rows[i];
    }

    public void setRows(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Row _value) {
        this.rows[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ContinuedHeader)) return false;
        ContinuedHeader other = (ContinuedHeader) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.appliedTo==null && other.getAppliedTo()==null) || 
             (this.appliedTo!=null &&
              this.appliedTo.equals(other.getAppliedTo()))) &&
            ((this.rows==null && other.getRows()==null) || 
             (this.rows!=null &&
              java.util.Arrays.equals(this.rows, other.getRows())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAppliedTo() != null) {
            _hashCode += getAppliedTo().hashCode();
        }
        if (getRows() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRows());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRows(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ContinuedHeader.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ContinuedHeader"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appliedTo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "appliedTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rows");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rows"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Row"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
