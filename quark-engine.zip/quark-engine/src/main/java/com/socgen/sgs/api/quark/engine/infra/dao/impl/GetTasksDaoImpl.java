package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.infra.dao.GetTasksDao;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Calls Oracle function QXP_PK_RUN.Get_Taches and returns raw row maps. */
@Repository
@Slf4j
public class GetTasksDaoImpl implements GetTasksDao {

    private static final String RESULT_KEY = "result_cursor";
    private final SimpleJdbcCall getTasksCall;

    @Autowired
    public GetTasksDaoImpl(DataSource dataSource) {
        this.getTasksCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_Taches")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR, new ColumnMapRowMapper()),
                        new SqlParameter("p_id_run", Types.NUMERIC)
                );
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getTasks(int runId) {
        log.info("Fetching tasks for runId: {}", runId);
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_run", runId);

        Map<String, Object> result = getTasksCall.execute(params);
        List<Map<String, Object>> rows = (List<Map<String, Object>>) result.get(RESULT_KEY);

        if (rows == null) {
            log.warn("No tasks returned for runId: {}", runId);
            return Collections.emptyList();
        }
        log.info("Fetched {} task rows for runId: {}", rows.size(), runId);
        return rows;
    }
}
