package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.InsertDocumentDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Oracle implementation: QXP_PK_RUN.Insert_Document
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class InsertDocumentDaoImpl implements InsertDocumentDao {

    private final DataSource dataSource;

    @Override
    public int insertDocument(DocumentDomain document, int idSousCategorie,
                              String idFndCode, String idUnitCode,
                              LocalDate dateEcheance, int idRun) {
        if (document == null || document.getData() == null) {
            return Integer.MIN_VALUE;
        }

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Insert_Document")
                .declareParameters(
                        new SqlOutParameter("RETURN", Types.NUMERIC),
                        new SqlParameter("p_code_port", Types.VARCHAR),
                        new SqlParameter("p_id_unit_code", Types.VARCHAR),
                        new SqlParameter("p_id_sous_categorie", Types.NUMERIC),
                        new SqlParameter("p_format", Types.VARCHAR),
                        new SqlParameter("p_id_langue", Types.NUMERIC),
                        new SqlParameter("p_date_document", Types.DATE),
                        new SqlParameter("p_nom_document", Types.VARCHAR),
                        new SqlParameter("p_id_utilisateur", Types.NUMERIC),
                        new SqlParameter("p_contenu", Types.BLOB),
                        new SqlParameter("p_taille_document", Types.NUMERIC),
                        new SqlParameter("p_is_actif", Types.NUMERIC),
                        new SqlParameter("p_id_run", Types.NUMERIC)
                );

        Map<String, Object> params = new HashMap<>();
        params.put("p_code_port", idFndCode);
        params.put("p_id_unit_code", idUnitCode);
        params.put("p_id_sous_categorie", idSousCategorie);
        params.put("p_format", document.getFormat());
        params.put("p_id_langue", document.getIdLangue() != null ? document.getIdLangue() : 1);
        params.put("p_date_document", java.sql.Date.valueOf(dateEcheance));
        params.put("p_nom_document", document.getFileName());
        params.put("p_id_utilisateur", 0);
        params.put("p_contenu", document.getData());
        params.put("p_taille_document", document.getData().length);
        params.put("p_is_actif", 1);
        params.put("p_id_run", idRun);

        Map<String, Object> result = jdbcCall.execute(params);
        Number idDoc = (Number) result.get("RETURN");

        log.debug("Inserted document [{}] with id [{}] for run [{}]",
                document.getFileName(), idDoc, idRun);

        return idDoc != null ? idDoc.intValue() : Integer.MIN_VALUE;
    }
}