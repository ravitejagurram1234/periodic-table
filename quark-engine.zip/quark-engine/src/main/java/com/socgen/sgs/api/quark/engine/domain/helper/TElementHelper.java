package com.socgen.sgs.api.quark.engine.domain.helper;

import com.socgen.sgs.api.quark.engine.domain.element.TBox;
import com.socgen.sgs.api.quark.engine.domain.element.TElement;
import com.socgen.sgs.api.quark.engine.domain.element.TGroup;
import com.socgen.sgs.api.quark.engine.domain.element.TTable;
import com.socgen.sgs.api.quark.engine.enums.StaticTElementNameEnum;
import com.socgen.sgs.api.quark.engine.enums.TBoxTypeEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Content;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Geometry;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Position;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Story;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Table;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Text;
import lombok.extern.slf4j.Slf4j;

import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;

/**
 * Helper for creating, cloning, and manipulating TElements during bloc generation.
 * Maintains a static cache of pre-built template elements (IMG, PDF, DOC, etc.)
 * that are cloned and customized for each task.
 *
 * <p>Key operations:
 * <ul>
 *   <li>{@link #getTElement(StaticTElementNameEnum, String)} — get a cloned template with new name</li>
 *   <li>{@link #getNewTBoxStyleValueFromTBox(TBox, String)} — copy style+value from source TBox</li>
 *   <li>{@link #getNewTTableStyleValueFromTTable(TTable, String)} — copy style+value from source TTable</li>
 *   <li>{@link #newBlocName()} — generate a unique bloc name</li>
 * </ul>
 *
 * Cross-reference: QXP.Engine.Core.TElement_Helper
 */
@Slf4j
public final class TElementHelper {

    // ========================================================================
    // Constants
    // ========================================================================

    private static final int NEW_BLOC_NAME_SIZE = 29;

    /** Prefix for data-bearing boxes inside groups (e.g., "C_0_GroupBox1"). */
    public static final String DATA_BLOC_PREFIX = "C_";

    // ========================================================================
    // Static element cache
    // ========================================================================

    private static final Map<StaticTElementNameEnum, TElement> STATIC_ELEMENTS = new EnumMap<>(StaticTElementNameEnum.class);

    static {
        try {
            loadStaticElements();
        } catch (Exception e) {
            log.error("Unable to load StaticElements", e);
        }
    }

    private TElementHelper() {
        // Utility class
    }

    // ========================================================================
    // Public API — Element retrieval
    // ========================================================================

    /**
     * Get a cloned copy of a static TElement with a new name.
     * The clone ensures modifications don't affect the original template.
     *
     * @param tElementName the static element type (IMG, PDF_1, PDF_N, etc.)
     * @param newName      the new name to assign to the element and its srcBox
     * @return a cloned TElement with the new name, or null if not found
     */
    public static TElement getTElement(StaticTElementNameEnum tElementName, String newName) {
        TElement defaultElement = getDefaultTElement(tElementName);
        if (defaultElement == null) {
            log.warn("Static TElement not found for [{}]", tElementName);
            return null;
        }

        if (defaultElement instanceof TBox) {
            TBox cloned = cloneTBox((TBox) defaultElement);
            cloned.setName(newName);
            cloned.getSrcBox().setName(newName);
            if (cloned.getSrcExtraBox() != null) {
                cloned.getSrcExtraBox().setName(newName);
            }
            return cloned;
        } else if (defaultElement instanceof TGroup) {
            TGroup cloned = cloneTGroup((TGroup) defaultElement);
            cloned.setName(newName);
            return cloned;
        } else if (defaultElement instanceof TTable) {
            TTable cloned = cloneTTable((TTable) defaultElement);
            cloned.setName(newName);
            return cloned;
        }

        return null;
    }

    // ========================================================================
    // Public API — Style/Value transfer
    // ========================================================================

    /**
     * Create a new TBox that copies only the style and value from a source TBox.
     * Used by QXP_Data STYLE mode to transfer content from a previous document.
     *
     * <p>For CT_TEXT boxes: copies text/story (with clearOldText=true), removes linkedBoxes.
     * <p>For CT_PICT boxes: copies picture and content.
     *
     * @param srcTBox the source TBox to copy from
     * @param newName the new name for the destination TBox
     * @return a new TBox with style and value transferred, or null on error
     */
    public static TBox getNewTBoxStyleValueFromTBox(TBox srcTBox, String newName) {
        TElement destElement = getTElement(StaticTElementNameEnum.EMPTY_BLOC, newName);
        if (!(destElement instanceof TBox)) {
            log.warn("Cannot create destination TBox for style transfer to [{}]", newName);
            return null;
        }

        TBox destTBox = (TBox) destElement;
        Box srcBox = srcTBox.getSrcBox();
        Box destBox = destTBox.getSrcBox();

        switch (srcTBox.getType()) {
            case CT_TEXT:
                destBox.setBoxType(TBoxTypeEnum.CT_TEXT.name());
                if (srcBox.getText() != null && srcBox.getText().getStory() != null) {
                    destBox.setText(srcBox.getText());
                    destBox.getText().getStory().setClearOldText("true");
                    // Remove linkedBoxes reference — destination may have different linking
                    destBox.getText().getStory().setLinkedBoxes(null);
                }
                break;

            case CT_PICT:
                destBox.setBoxType(TBoxTypeEnum.CT_PICT.name());
                destBox.setPicture(srcBox.getPicture());
                destBox.setContent(srcBox.getContent());
                break;

            default:
                break;
        }

        return destTBox;
    }

    /**
     * Create a new TTable that copies style and value from a source TTable.
     * Used by QXP_Data STYLE mode to transfer table content from a previous document.
     *
     * <p>Copies all rows with clearOldText=true on each cell's story.
     * Sets maintainGeometry=false to let QuarkXPress adapt the table geometry.
     *
     * @param srcTTable the source TTable to copy from
     * @param newName   the new name for the destination TTable
     * @return a new TTable with content transferred, or null on error
     */
    public static TTable getNewTTableStyleValueFromTTable(TTable srcTTable, String newName) {
        TElement destElement = getTElement(StaticTElementNameEnum.EMPTY_TABLE, newName);
        if (!(destElement instanceof TTable)) {
            log.warn("Cannot create destination TTable for style transfer to [{}]", newName);
            return null;
        }

        TTable destTTable = (TTable) destElement;
        Table srcTable = srcTTable.getSrcTable();

        // Let QuarkXPress adapt the geometry
        destTTable.getSrcTable().setMaintainGeometry("false");

        if (srcTable.getRows() != null) {
            destTTable.getSrcTable().setRows(srcTable.getRows());

            // Set clearOldText on all cells to avoid merging old and new content
            for (com.socgen.sgs.api.quark.engine.integration.soap.generated.Row row : destTTable.getSrcTable().getRows()) {
                if (row == null || row.getCells() == null) {
                    continue;
                }
                for (com.socgen.sgs.api.quark.engine.integration.soap.generated.Cell cell : row.getCells()) {
                    if (cell != null && cell.getText() != null && cell.getText().getStory() != null) {
                        cell.getText().getStory().setClearOldText("true");
                    }
                }
            }
        }

        return destTTable;
    }

    // ========================================================================
    // Public API — Box name/value updates
    // ========================================================================

    /**
     * Update the name and text value of a TBox's source box.
     *
     * @param tBox     the TBox to update
     * @param newName  the new box name
     * @param newValue the new text value
     */
    public static void updateNameValue(TBox tBox, String newName, String newValue) {
        Box srcBox = tBox.getSrcBox();
        if (srcBox == null) {
            log.warn("SrcBox is null for TBox update with name [{}]", newName);
            return;
        }

        // Update text value
        if (srcBox.getText() != null && srcBox.getText().getStory() != null) {
            Paragraph[] paragraphs = srcBox.getText().getStory().getParagraphs();
            if (paragraphs == null || paragraphs.length == 0
                    || paragraphs[0].getRichText() == null || paragraphs[0].getRichText().length == 0) {
                // Create warning-style paragraph if missing
                srcBox.getText().getStory().setParagraphs(createWarningParagraph());
            }
            srcBox.getText().getStory().getParagraphs()[0].getRichText()[0].setValue(newValue);
        }

        // Update names
        srcBox.setName(newName);
        tBox.setName(newName);
    }

    /**
     * Generate a unique bloc name using UUID.
     * Produces a 29-character string for use as a box name in QuarkXPress documents.
     *
     * @return a unique bloc name
     */
    public static String newBlocName() {
        String uuid = UUID.randomUUID().toString().replace("-", "");
        if (uuid.length() > NEW_BLOC_NAME_SIZE) {
            uuid = uuid.substring(0, NEW_BLOC_NAME_SIZE);
        }
        return uuid;
    }

    /**
     * Get the data index from a box name following the pattern C_X_Y
     * where X is the index (e.g., "C_0_Group1" → index 0).
     *
     * @param boxName the box name to parse
     * @return the index, or -1 if not parseable
     */
    public static int getIndexBox(String boxName) {
        if (boxName == null || boxName.length() < 5) {
            return -1;
        }
        // Skip "C_" prefix, find next underscore
        String sub = boxName.substring(2);
        int underscoreIdx = sub.indexOf('_');
        if (underscoreIdx <= 0) {
            return -1;
        }
        try {
            return Integer.parseInt(sub.substring(0, underscoreIdx));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ========================================================================
    // Public API — Warning paragraph
    // ========================================================================

    /**
     * Create a default warning paragraph with bold red text.
     * Used when a box has no paragraph structure but needs a text value.
     *
     * @return an array with one warning-style Paragraph
     */
    public static Paragraph[] createWarningParagraph() {
        Paragraph paragraph = new Paragraph();
        RichText richText = new RichText();
        richText.setBold("true");
        richText.setColor("Rouge");
        paragraph.setRichText(new RichText[]{richText});
        return new Paragraph[]{paragraph};
    }

    // ========================================================================
    // Private — Static element initialization
    // ========================================================================

    /**
     * Load all pre-built static template elements.
     * These serve as prototypes that are cloned for each task.
     *
     * Cross-reference: QXP.Engine.Core.TElement_Helper.LoadStaticElements()
     */
    private static void loadStaticElements() {
        Box box;
        Box boxExtra;
        Picture picture;
        Table table;

        // ---- EMPTY_BLOC ----
        box = new Box();
        STATIC_ELEMENTS.put(StaticTElementNameEnum.EMPTY_BLOC, new TBox(box));

        // ---- IMG ----
        box = new Box();
        picture = new Picture();
        box.setContent(new Content());
        picture.setFit("FITPICTURETOBOXPRO");
        box.setPicture(picture);
        STATIC_ELEMENTS.put(StaticTElementNameEnum.IMG, new TBox(box));

        // ---- PDF_1 (first PDF page — update existing box) ----
        box = new Box();
        picture = new Picture();
        box.setContent(new Content());
        picture.setFit("FITPICTURETOBOXPRO");
        box.setPicture(picture);
        box.setGeometry(new Geometry());
        box.getGeometry().setAllowBoxOffPage("true");
        box.getGeometry().setAllowBoxOnToPasteboard("true");
        // Extra box for PDF offset operations
        boxExtra = new Box();
        boxExtra.setPicture(new Picture());
        STATIC_ELEMENTS.put(StaticTElementNameEnum.PDF_1, new TBox(box, boxExtra));

        // ---- PDF_N (subsequent PDF pages — may be create or update) ----
        box = new Box();
        box.setContent(new Content());
        picture = new Picture();
        box.setGeometry(new Geometry());
        picture.setFit("FITPICTURETOBOXPRO");
        box.setPicture(picture);
        // No runaround for PDF boxes
        Runaround runaround = new Runaround();
        runaround.setType("NONE");
        box.getGeometry().setRunaround(runaround);
        // Set box type to picture
        box.setBoxType(TBoxTypeEnum.CT_PICT.name());
        box.getGeometry().setPosition(new Position());
        // Extra box for PDF offset operations
        boxExtra = new Box();
        boxExtra.setPicture(new Picture());
        STATIC_ELEMENTS.put(StaticTElementNameEnum.PDF_N, new TBox(box, boxExtra));

        // ---- RTF_DOC_XTG ----
        box = new Box();
        box.setContent(new Content());
        box.getContent().setConvertQuotes("true");
        box.getContent().setIncludeStyleSheets("true");
        STATIC_ELEMENTS.put(StaticTElementNameEnum.RTF_DOC_XTG, new TBox(box));

        // ---- MOVE_BLOC ----
        box = new Box();
        box.setGeometry(new Geometry());
        box.getGeometry().setPosition(new Position());
        box.getGeometry().setAllowBoxOffPage("true");
        box.getGeometry().setAllowBoxOnToPasteboard("true");
        STATIC_ELEMENTS.put(StaticTElementNameEnum.MOVE_BLOC, new TBox(box));

        // ---- MOVE_BLOC_VALUE ----
        box = new Box();
        box.setGeometry(new Geometry());
        box.getGeometry().setPosition(new Position());
        box.getGeometry().setAllowBoxOffPage("true");
        box.getGeometry().setAllowBoxOnToPasteboard("true");
        box.setContent(new Content());
        STATIC_ELEMENTS.put(StaticTElementNameEnum.MOVE_BLOC_VALUE, new TBox(box));

        // ---- EMPTY_TABLE ----
        table = new Table();
        STATIC_ELEMENTS.put(StaticTElementNameEnum.EMPTY_TABLE, new TTable(table));
    }

    // ========================================================================
    // Public API — Bloc creation from DCell
    // ========================================================================

    /**
     * Create a BlocBase (BlocBox or BlocGroup) from a DCell.
     * Used by Stage 4 (Render_Boxes) of dynamic task processing.
     *
     * Cross-reference: .NET TElement_Helper.Get_Bloc(DCell, Task_Dynamique)
     */
    public static com.socgen.sgs.api.quark.engine.domain.bloc.BlocBase getBloc(
            com.socgen.sgs.api.quark.engine.domain.dynamic.report.DCell cell,
            com.socgen.sgs.api.quark.engine.domain.task.TaskDynamique task) {

        if (cell.getTElement() instanceof TBox) {
            TBox tBox = cloneTBox((TBox) cell.getTElement());
            updateTElementBox(tBox, cell);
            return updateAndGetBlocBox(tBox, cell, task);
        } else if (cell.getTElement() instanceof com.socgen.sgs.api.quark.engine.domain.element.TGroup) {
            com.socgen.sgs.api.quark.engine.domain.element.TGroup tGroup =
                    cloneTGroup((com.socgen.sgs.api.quark.engine.domain.element.TGroup) cell.getTElement());
            return updateAndGetBlocGroup(tGroup, cell, task);
        }
        return null;
    }

    /**
     * Create a BlocBox for moving an anchor to a new page.
     * Used by Stage 4 (Render_Boxes) to reposition start/end anchors.
     *
     * Cross-reference: .NET TElement_Helper.Get_Move_Anchor()
     */
    public static com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox getMoveAnchor(
            com.socgen.sgs.api.quark.engine.domain.task.TaskBase task,
            com.socgen.sgs.api.quark.engine.domain.dynamic.report.DBlocInfo anchor,
            int newRelativePage) {

        TElement tElement = getTElement(StaticTElementNameEnum.MOVE_BLOC, anchor.getName());
        if (!(tElement instanceof TBox)) {
            log.warn("Cannot get MOVE_BLOC template for anchor [{}]", anchor.getName());
            return null;
        }

        TBox tBox = (TBox) tElement;
        com.socgen.sgs.api.quark.engine.integration.soap.generated.Box box = tBox.getSrcBox();

        // Set position from anchor info
        if (box.getGeometry() != null && box.getGeometry().getPosition() != null) {
            box.getGeometry().getPosition().setLeft(anchor.getLeft().toPlainString());
            box.getGeometry().getPosition().setTop(anchor.getTop().toPlainString());
            box.getGeometry().getPosition().setRight(anchor.getRight().toPlainString());
            box.getGeometry().getPosition().setBottom(anchor.getBottom().toPlainString());
        }
        box.setUID(anchor.getUid());

        com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox bloc =
                new com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox(
                        task, tBox.getSrcBox().getName(), tBox.getSrcBox(), tBox.getSrcExtraBox());
        bloc.setAction(com.socgen.sgs.api.quark.engine.enums.BlocActionEnum.MOVE);
        bloc.setRelativePage(newRelativePage);
        bloc.setPagination(true);

        return bloc;
    }

    private static void updateTElementBox(TBox tBox, com.socgen.sgs.api.quark.engine.domain.dynamic.report.DCell cell) {
        if (cell.getNewNames().size() == 1) {
            updateNameValue(tBox, cell.getNewNames().get(0), cell.getValues().get(0));
        }
        // Position update would go here (using cell.getInfo().getZone())
    }

    private static com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox updateAndGetBlocBox(
            TBox tBox,
            com.socgen.sgs.api.quark.engine.domain.dynamic.report.DCell cell,
            com.socgen.sgs.api.quark.engine.domain.task.TaskDynamique task) {

        com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox blocBox =
                new com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox(
                        task, tBox.getName(), tBox.getSrcBox(), tBox.getSrcExtraBox());
        blocBox.setAction(com.socgen.sgs.api.quark.engine.enums.BlocActionEnum.CREATE);
        blocBox.setRelativePage(cell.getInfo().getPage() - 1);

        return blocBox;
    }

    private static com.socgen.sgs.api.quark.engine.domain.bloc.BlocGroup updateAndGetBlocGroup(
            com.socgen.sgs.api.quark.engine.domain.element.TGroup tGroup,
            com.socgen.sgs.api.quark.engine.domain.dynamic.report.DCell cell,
            com.socgen.sgs.api.quark.engine.domain.task.TaskDynamique task) {

        com.socgen.sgs.api.quark.engine.domain.bloc.BlocGroup blocGroup =
                new com.socgen.sgs.api.quark.engine.domain.bloc.BlocGroup(
                        task, tGroup.getName(), tGroup.getSrcBoxes());
        blocGroup.setAction(com.socgen.sgs.api.quark.engine.enums.BlocActionEnum.CREATE);
        blocGroup.setRelativePage(cell.getInfo().getPage() - 1);

        return blocGroup;
    }

    // ========================================================================
    // Private — Cloning
    // ========================================================================

    /**
     * Deep-clone a TBox by creating new SOAP Box objects with the same properties.
     * This approach avoids serialization dependency (unlike .NET which uses XML serialization).
     */
    private static TBox cloneTBox(TBox source) {
        Box clonedBox = cloneBox(source.getSrcBox());
        Box clonedExtra = source.getSrcExtraBox() != null ? cloneBox(source.getSrcExtraBox()) : null;

        TBox cloned = clonedExtra != null ? new TBox(clonedBox, clonedExtra) : new TBox(clonedBox);
        cloned.setType(source.getType());
        cloned.setPage(source.getPage());
        return cloned;
    }

    /**
     * Deep-clone a TTable.
     */
    private static TTable cloneTTable(TTable source) {
        // For tables, we create a new TTable wrapping the same SOAP table reference.
        // Deep cloning of table rows/cells is done at usage time (e.g., style transfer).
        Table clonedTable = new Table();
        if (source.getSrcTable() != null) {
            clonedTable.setName(source.getSrcTable().getName());
        }
        TTable cloned = new TTable(clonedTable);
        return cloned;
    }

    /**
     * Deep-clone a TGroup.
     */
    private static TGroup cloneTGroup(TGroup source) {
        // Groups are cloned by creating a new TGroup referencing the same SOAP Group.
        // Box resolution happens at evaluate time.
        TGroup cloned = new TGroup();
        cloned.setName(source.getName());
        cloned.setSrcGroup(source.getSrcGroup());
        return cloned;
    }

    /**
     * Deep-clone a SOAP Box by copying all relevant properties.
     * Creates new Geometry/Position/Content objects to avoid shared references.
     */
    private static Box cloneBox(Box source) {
        if (source == null) {
            return null;
        }

        Box cloned = new Box();
        cloned.setName(source.getName());
        cloned.setUID(source.getUID());
        cloned.setBoxType(source.getBoxType());
        cloned.setColor(source.getColor());
        cloned.setOpacity(source.getOpacity());
        cloned.setShade(source.getShade());
        cloned.setOperation(source.getOperation());
        cloned.setIndex(source.getIndex());
        cloned.setAnchoredIn(source.getAnchoredIn());
        cloned.setAnchoredGroupMember(source.getAnchoredGroupMember());

        // Clone geometry (with position)
        if (source.getGeometry() != null) {
            Geometry geom = new Geometry();
            Geometry srcGeom = source.getGeometry();
            geom.setPage(srcGeom.getPage());
            geom.setStackingOrder(srcGeom.getStackingOrder());
            geom.setAllowBoxOffPage(srcGeom.getAllowBoxOffPage());
            geom.setAllowBoxOnToPasteboard(srcGeom.getAllowBoxOnToPasteboard());

            if (srcGeom.getRunaround() != null) {
                Runaround ra = new Runaround();
                ra.setType(srcGeom.getRunaround().getType());
                geom.setRunaround(ra);
            }

            if (srcGeom.getPosition() != null) {
                Position pos = new Position();
                pos.setLeft(srcGeom.getPosition().getLeft());
                pos.setTop(srcGeom.getPosition().getTop());
                pos.setRight(srcGeom.getPosition().getRight());
                pos.setBottom(srcGeom.getPosition().getBottom());
                geom.setPosition(pos);
            }
            cloned.setGeometry(geom);
        }

        // Clone content
        if (source.getContent() != null) {
            Content content = new Content();
            content.setValue(source.getContent().getValue());
            content.setConvertQuotes(source.getContent().getConvertQuotes());
            content.setIncludeStyleSheets(source.getContent().getIncludeStyleSheets());
            cloned.setContent(content);
        }

        // Clone picture
        if (source.getPicture() != null) {
            Picture pic = new Picture();
            pic.setFit(source.getPicture().getFit());
            pic.setAngle(source.getPicture().getAngle());
            pic.setOffsetAcross(source.getPicture().getOffsetAcross());
            pic.setOffsetDown(source.getPicture().getOffsetDown());
            cloned.setPicture(pic);
        }

        // Clone text/story
        if (source.getText() != null) {
            Text text = new Text();
            if (source.getText().getStory() != null) {
                Story story = new Story();
                story.setParagraphs(source.getText().getStory().getParagraphs());
                story.setClearOldText(source.getText().getStory().getClearOldText());
                story.setLinkedBoxes(source.getText().getStory().getLinkedBoxes());
                text.setStory(story);
            }
            cloned.setText(text);
        }

        // Clone frame
        cloned.setFrame(source.getFrame());

        // Clone shadow
        cloned.setShadow(source.getShadow());

        // Clone metadata
        cloned.setMetaData(source.getMetaData());

        // Clone placeholders
        cloned.setPlaceholders(source.getPlaceholders());
        cloned.setContentPlaceholder(source.getContentPlaceholder());

        return cloned;
    }

    /**
     * Retrieve a static TElement by its name from the cache.
     */
    private static TElement getDefaultTElement(StaticTElementNameEnum elementName) {
        return STATIC_ELEMENTS.get(elementName);
    }
}