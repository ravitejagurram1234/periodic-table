package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;

/**
 * DAO interface for retrieving Gabarit (template) documents from the database.
 */
public interface GetGabaritDao {
    DocumentDomain getGabarit(Integer idGabarit);
}

