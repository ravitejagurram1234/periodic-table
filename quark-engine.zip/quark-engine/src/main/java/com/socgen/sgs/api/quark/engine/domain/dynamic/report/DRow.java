package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a row in a DTable of a dynamic report.
 * Contains cells and optional page/column break behavior.
 *
 * Cross-reference: QXP.Engine.Core.DRow
 */
@Getter
@Setter
public class DRow {

    /** Cells contained in this row. */
    private final List<DCell> cells = new ArrayList<>();

    /** Geometry information for this row. */
    private DRowInfo info = new DRowInfo();

    /** Row level (also called Row_Level). Used for page break rules. */
    private int level = 0;

    /** Rows to repeat on page break (populated during Prepare phase). */
    private List<DRow> pageBreakRows = new ArrayList<>();

    /** Rows to repeat on column break (populated during Prepare phase). */
    private List<DRow> columnBreakRows = new ArrayList<>();

    /** Clone generation counter. */
    private int generation = 1;

    public DRow() {
    }

    /**
     * Clone this row. Increments generation counter and clones all cells.
     *
     * @return a new DRow with cloned cells and info
     */
    public DRow cloneRow() {
        DRow newRow = new DRow();
        this.generation++;
        newRow.generation = this.generation;
        newRow.info = this.info.cloneInfo();
        newRow.level = this.level;
        newRow.pageBreakRows = this.pageBreakRows;

        for (DCell cell : this.cells) {
            newRow.cells.add(cell.cloneCell());
        }
        return newRow;
    }

    /**
     * Check if this row contains at least one cell with a Page_Break template.
     * Such rows are not treated as normal relative rows — they are repeated
     * at the beginning of each new page.
     *
     * @return true if any cell has pageBreak=true on its template
     */
    public boolean isPageBreak() {
        for (DCell cell : cells) {
            if (cell.getTemplate().isPageBreak()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if this row contains at least one cell with a Column_Break template.
     * Such rows are repeated at the beginning of each new column.
     *
     * @return true if any cell has columnBreak=true on its template
     */
    public boolean isColumnBreak() {
        for (DCell cell : cells) {
            if (cell.getTemplate().isColumnBreak()) {
                return true;
            }
        }
        return false;
    }
}