/**
 * Border.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Border  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String borderBottomBlendMode;

    private java.lang.String borderBottomColor;

    private java.lang.String borderBottomGapBlendMode;

    private java.lang.String borderBottomGapColor;

    private java.lang.String borderBottomGapOpacity;

    private java.lang.String borderBottomGapShade;

    private java.lang.String borderBottomOpacity;

    private java.lang.String borderBottomShade;

    private java.lang.String borderBottomStyle;

    private java.lang.String borderBottomWidth;

    private java.lang.String borderLeftBlendMode;

    private java.lang.String borderLeftColor;

    private java.lang.String borderLeftGapBlendMode;

    private java.lang.String borderLeftGapColor;

    private java.lang.String borderLeftGapOpacity;

    private java.lang.String borderLeftGapShade;

    private java.lang.String borderLeftOpacity;

    private java.lang.String borderLeftShade;

    private java.lang.String borderLeftStyle;

    private java.lang.String borderLeftWidth;

    private java.lang.String borderMidHorizontalBlendMode;

    private java.lang.String borderMidHorizontalColor;

    private java.lang.String borderMidHorizontalGapBlendMode;

    private java.lang.String borderMidHorizontalGapColor;

    private java.lang.String borderMidHorizontalGapOpacity;

    private java.lang.String borderMidHorizontalGapShade;

    private java.lang.String borderMidHorizontalOpacity;

    private java.lang.String borderMidHorizontalShade;

    private java.lang.String borderMidHorizontalStyle;

    private java.lang.String borderMidHorizontalWidth;

    private java.lang.String borderMidVerticalBlendMode;

    private java.lang.String borderMidVerticalColor;

    private java.lang.String borderMidVerticalGapBlendMode;

    private java.lang.String borderMidVerticalGapColor;

    private java.lang.String borderMidVerticalGapOpacity;

    private java.lang.String borderMidVerticalGapShade;

    private java.lang.String borderMidVerticalOpacity;

    private java.lang.String borderMidVerticalShade;

    private java.lang.String borderMidVerticalStyle;

    private java.lang.String borderMidVerticalWidth;

    private java.lang.String borderRightBlendMode;

    private java.lang.String borderRightColor;

    private java.lang.String borderRightGapBlendMode;

    private java.lang.String borderRightGapColor;

    private java.lang.String borderRightGapOpacity;

    private java.lang.String borderRightGapShade;

    private java.lang.String borderRightOpacity;

    private java.lang.String borderRightShade;

    private java.lang.String borderRightStyle;

    private java.lang.String borderRightWidth;

    private java.lang.String borderTopBlendMode;

    private java.lang.String borderTopColor;

    private java.lang.String borderTopGapBlendMode;

    private java.lang.String borderTopGapColor;

    private java.lang.String borderTopGapOpacity;

    private java.lang.String borderTopGapShade;

    private java.lang.String borderTopOpacity;

    private java.lang.String borderTopShade;

    private java.lang.String borderTopStyle;

    private java.lang.String borderTopWidth;

    public Border() {
    }

    public Border(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String borderBottomBlendMode,
           java.lang.String borderBottomColor,
           java.lang.String borderBottomGapBlendMode,
           java.lang.String borderBottomGapColor,
           java.lang.String borderBottomGapOpacity,
           java.lang.String borderBottomGapShade,
           java.lang.String borderBottomOpacity,
           java.lang.String borderBottomShade,
           java.lang.String borderBottomStyle,
           java.lang.String borderBottomWidth,
           java.lang.String borderLeftBlendMode,
           java.lang.String borderLeftColor,
           java.lang.String borderLeftGapBlendMode,
           java.lang.String borderLeftGapColor,
           java.lang.String borderLeftGapOpacity,
           java.lang.String borderLeftGapShade,
           java.lang.String borderLeftOpacity,
           java.lang.String borderLeftShade,
           java.lang.String borderLeftStyle,
           java.lang.String borderLeftWidth,
           java.lang.String borderMidHorizontalBlendMode,
           java.lang.String borderMidHorizontalColor,
           java.lang.String borderMidHorizontalGapBlendMode,
           java.lang.String borderMidHorizontalGapColor,
           java.lang.String borderMidHorizontalGapOpacity,
           java.lang.String borderMidHorizontalGapShade,
           java.lang.String borderMidHorizontalOpacity,
           java.lang.String borderMidHorizontalShade,
           java.lang.String borderMidHorizontalStyle,
           java.lang.String borderMidHorizontalWidth,
           java.lang.String borderMidVerticalBlendMode,
           java.lang.String borderMidVerticalColor,
           java.lang.String borderMidVerticalGapBlendMode,
           java.lang.String borderMidVerticalGapColor,
           java.lang.String borderMidVerticalGapOpacity,
           java.lang.String borderMidVerticalGapShade,
           java.lang.String borderMidVerticalOpacity,
           java.lang.String borderMidVerticalShade,
           java.lang.String borderMidVerticalStyle,
           java.lang.String borderMidVerticalWidth,
           java.lang.String borderRightBlendMode,
           java.lang.String borderRightColor,
           java.lang.String borderRightGapBlendMode,
           java.lang.String borderRightGapColor,
           java.lang.String borderRightGapOpacity,
           java.lang.String borderRightGapShade,
           java.lang.String borderRightOpacity,
           java.lang.String borderRightShade,
           java.lang.String borderRightStyle,
           java.lang.String borderRightWidth,
           java.lang.String borderTopBlendMode,
           java.lang.String borderTopColor,
           java.lang.String borderTopGapBlendMode,
           java.lang.String borderTopGapColor,
           java.lang.String borderTopGapOpacity,
           java.lang.String borderTopGapShade,
           java.lang.String borderTopOpacity,
           java.lang.String borderTopShade,
           java.lang.String borderTopStyle,
           java.lang.String borderTopWidth) {
        super(
            request);
        this.borderBottomBlendMode = borderBottomBlendMode;
        this.borderBottomColor = borderBottomColor;
        this.borderBottomGapBlendMode = borderBottomGapBlendMode;
        this.borderBottomGapColor = borderBottomGapColor;
        this.borderBottomGapOpacity = borderBottomGapOpacity;
        this.borderBottomGapShade = borderBottomGapShade;
        this.borderBottomOpacity = borderBottomOpacity;
        this.borderBottomShade = borderBottomShade;
        this.borderBottomStyle = borderBottomStyle;
        this.borderBottomWidth = borderBottomWidth;
        this.borderLeftBlendMode = borderLeftBlendMode;
        this.borderLeftColor = borderLeftColor;
        this.borderLeftGapBlendMode = borderLeftGapBlendMode;
        this.borderLeftGapColor = borderLeftGapColor;
        this.borderLeftGapOpacity = borderLeftGapOpacity;
        this.borderLeftGapShade = borderLeftGapShade;
        this.borderLeftOpacity = borderLeftOpacity;
        this.borderLeftShade = borderLeftShade;
        this.borderLeftStyle = borderLeftStyle;
        this.borderLeftWidth = borderLeftWidth;
        this.borderMidHorizontalBlendMode = borderMidHorizontalBlendMode;
        this.borderMidHorizontalColor = borderMidHorizontalColor;
        this.borderMidHorizontalGapBlendMode = borderMidHorizontalGapBlendMode;
        this.borderMidHorizontalGapColor = borderMidHorizontalGapColor;
        this.borderMidHorizontalGapOpacity = borderMidHorizontalGapOpacity;
        this.borderMidHorizontalGapShade = borderMidHorizontalGapShade;
        this.borderMidHorizontalOpacity = borderMidHorizontalOpacity;
        this.borderMidHorizontalShade = borderMidHorizontalShade;
        this.borderMidHorizontalStyle = borderMidHorizontalStyle;
        this.borderMidHorizontalWidth = borderMidHorizontalWidth;
        this.borderMidVerticalBlendMode = borderMidVerticalBlendMode;
        this.borderMidVerticalColor = borderMidVerticalColor;
        this.borderMidVerticalGapBlendMode = borderMidVerticalGapBlendMode;
        this.borderMidVerticalGapColor = borderMidVerticalGapColor;
        this.borderMidVerticalGapOpacity = borderMidVerticalGapOpacity;
        this.borderMidVerticalGapShade = borderMidVerticalGapShade;
        this.borderMidVerticalOpacity = borderMidVerticalOpacity;
        this.borderMidVerticalShade = borderMidVerticalShade;
        this.borderMidVerticalStyle = borderMidVerticalStyle;
        this.borderMidVerticalWidth = borderMidVerticalWidth;
        this.borderRightBlendMode = borderRightBlendMode;
        this.borderRightColor = borderRightColor;
        this.borderRightGapBlendMode = borderRightGapBlendMode;
        this.borderRightGapColor = borderRightGapColor;
        this.borderRightGapOpacity = borderRightGapOpacity;
        this.borderRightGapShade = borderRightGapShade;
        this.borderRightOpacity = borderRightOpacity;
        this.borderRightShade = borderRightShade;
        this.borderRightStyle = borderRightStyle;
        this.borderRightWidth = borderRightWidth;
        this.borderTopBlendMode = borderTopBlendMode;
        this.borderTopColor = borderTopColor;
        this.borderTopGapBlendMode = borderTopGapBlendMode;
        this.borderTopGapColor = borderTopGapColor;
        this.borderTopGapOpacity = borderTopGapOpacity;
        this.borderTopGapShade = borderTopGapShade;
        this.borderTopOpacity = borderTopOpacity;
        this.borderTopShade = borderTopShade;
        this.borderTopStyle = borderTopStyle;
        this.borderTopWidth = borderTopWidth;
    }


    /**
     * Gets the borderBottomBlendMode value for this Border.
     * 
     * @return borderBottomBlendMode
     */
    public java.lang.String getBorderBottomBlendMode() {
        return borderBottomBlendMode;
    }


    /**
     * Sets the borderBottomBlendMode value for this Border.
     * 
     * @param borderBottomBlendMode
     */
    public void setBorderBottomBlendMode(java.lang.String borderBottomBlendMode) {
        this.borderBottomBlendMode = borderBottomBlendMode;
    }


    /**
     * Gets the borderBottomColor value for this Border.
     * 
     * @return borderBottomColor
     */
    public java.lang.String getBorderBottomColor() {
        return borderBottomColor;
    }


    /**
     * Sets the borderBottomColor value for this Border.
     * 
     * @param borderBottomColor
     */
    public void setBorderBottomColor(java.lang.String borderBottomColor) {
        this.borderBottomColor = borderBottomColor;
    }


    /**
     * Gets the borderBottomGapBlendMode value for this Border.
     * 
     * @return borderBottomGapBlendMode
     */
    public java.lang.String getBorderBottomGapBlendMode() {
        return borderBottomGapBlendMode;
    }


    /**
     * Sets the borderBottomGapBlendMode value for this Border.
     * 
     * @param borderBottomGapBlendMode
     */
    public void setBorderBottomGapBlendMode(java.lang.String borderBottomGapBlendMode) {
        this.borderBottomGapBlendMode = borderBottomGapBlendMode;
    }


    /**
     * Gets the borderBottomGapColor value for this Border.
     * 
     * @return borderBottomGapColor
     */
    public java.lang.String getBorderBottomGapColor() {
        return borderBottomGapColor;
    }


    /**
     * Sets the borderBottomGapColor value for this Border.
     * 
     * @param borderBottomGapColor
     */
    public void setBorderBottomGapColor(java.lang.String borderBottomGapColor) {
        this.borderBottomGapColor = borderBottomGapColor;
    }


    /**
     * Gets the borderBottomGapOpacity value for this Border.
     * 
     * @return borderBottomGapOpacity
     */
    public java.lang.String getBorderBottomGapOpacity() {
        return borderBottomGapOpacity;
    }


    /**
     * Sets the borderBottomGapOpacity value for this Border.
     * 
     * @param borderBottomGapOpacity
     */
    public void setBorderBottomGapOpacity(java.lang.String borderBottomGapOpacity) {
        this.borderBottomGapOpacity = borderBottomGapOpacity;
    }


    /**
     * Gets the borderBottomGapShade value for this Border.
     * 
     * @return borderBottomGapShade
     */
    public java.lang.String getBorderBottomGapShade() {
        return borderBottomGapShade;
    }


    /**
     * Sets the borderBottomGapShade value for this Border.
     * 
     * @param borderBottomGapShade
     */
    public void setBorderBottomGapShade(java.lang.String borderBottomGapShade) {
        this.borderBottomGapShade = borderBottomGapShade;
    }


    /**
     * Gets the borderBottomOpacity value for this Border.
     * 
     * @return borderBottomOpacity
     */
    public java.lang.String getBorderBottomOpacity() {
        return borderBottomOpacity;
    }


    /**
     * Sets the borderBottomOpacity value for this Border.
     * 
     * @param borderBottomOpacity
     */
    public void setBorderBottomOpacity(java.lang.String borderBottomOpacity) {
        this.borderBottomOpacity = borderBottomOpacity;
    }


    /**
     * Gets the borderBottomShade value for this Border.
     * 
     * @return borderBottomShade
     */
    public java.lang.String getBorderBottomShade() {
        return borderBottomShade;
    }


    /**
     * Sets the borderBottomShade value for this Border.
     * 
     * @param borderBottomShade
     */
    public void setBorderBottomShade(java.lang.String borderBottomShade) {
        this.borderBottomShade = borderBottomShade;
    }


    /**
     * Gets the borderBottomStyle value for this Border.
     * 
     * @return borderBottomStyle
     */
    public java.lang.String getBorderBottomStyle() {
        return borderBottomStyle;
    }


    /**
     * Sets the borderBottomStyle value for this Border.
     * 
     * @param borderBottomStyle
     */
    public void setBorderBottomStyle(java.lang.String borderBottomStyle) {
        this.borderBottomStyle = borderBottomStyle;
    }


    /**
     * Gets the borderBottomWidth value for this Border.
     * 
     * @return borderBottomWidth
     */
    public java.lang.String getBorderBottomWidth() {
        return borderBottomWidth;
    }


    /**
     * Sets the borderBottomWidth value for this Border.
     * 
     * @param borderBottomWidth
     */
    public void setBorderBottomWidth(java.lang.String borderBottomWidth) {
        this.borderBottomWidth = borderBottomWidth;
    }


    /**
     * Gets the borderLeftBlendMode value for this Border.
     * 
     * @return borderLeftBlendMode
     */
    public java.lang.String getBorderLeftBlendMode() {
        return borderLeftBlendMode;
    }


    /**
     * Sets the borderLeftBlendMode value for this Border.
     * 
     * @param borderLeftBlendMode
     */
    public void setBorderLeftBlendMode(java.lang.String borderLeftBlendMode) {
        this.borderLeftBlendMode = borderLeftBlendMode;
    }


    /**
     * Gets the borderLeftColor value for this Border.
     * 
     * @return borderLeftColor
     */
    public java.lang.String getBorderLeftColor() {
        return borderLeftColor;
    }


    /**
     * Sets the borderLeftColor value for this Border.
     * 
     * @param borderLeftColor
     */
    public void setBorderLeftColor(java.lang.String borderLeftColor) {
        this.borderLeftColor = borderLeftColor;
    }


    /**
     * Gets the borderLeftGapBlendMode value for this Border.
     * 
     * @return borderLeftGapBlendMode
     */
    public java.lang.String getBorderLeftGapBlendMode() {
        return borderLeftGapBlendMode;
    }


    /**
     * Sets the borderLeftGapBlendMode value for this Border.
     * 
     * @param borderLeftGapBlendMode
     */
    public void setBorderLeftGapBlendMode(java.lang.String borderLeftGapBlendMode) {
        this.borderLeftGapBlendMode = borderLeftGapBlendMode;
    }


    /**
     * Gets the borderLeftGapColor value for this Border.
     * 
     * @return borderLeftGapColor
     */
    public java.lang.String getBorderLeftGapColor() {
        return borderLeftGapColor;
    }


    /**
     * Sets the borderLeftGapColor value for this Border.
     * 
     * @param borderLeftGapColor
     */
    public void setBorderLeftGapColor(java.lang.String borderLeftGapColor) {
        this.borderLeftGapColor = borderLeftGapColor;
    }


    /**
     * Gets the borderLeftGapOpacity value for this Border.
     * 
     * @return borderLeftGapOpacity
     */
    public java.lang.String getBorderLeftGapOpacity() {
        return borderLeftGapOpacity;
    }


    /**
     * Sets the borderLeftGapOpacity value for this Border.
     * 
     * @param borderLeftGapOpacity
     */
    public void setBorderLeftGapOpacity(java.lang.String borderLeftGapOpacity) {
        this.borderLeftGapOpacity = borderLeftGapOpacity;
    }


    /**
     * Gets the borderLeftGapShade value for this Border.
     * 
     * @return borderLeftGapShade
     */
    public java.lang.String getBorderLeftGapShade() {
        return borderLeftGapShade;
    }


    /**
     * Sets the borderLeftGapShade value for this Border.
     * 
     * @param borderLeftGapShade
     */
    public void setBorderLeftGapShade(java.lang.String borderLeftGapShade) {
        this.borderLeftGapShade = borderLeftGapShade;
    }


    /**
     * Gets the borderLeftOpacity value for this Border.
     * 
     * @return borderLeftOpacity
     */
    public java.lang.String getBorderLeftOpacity() {
        return borderLeftOpacity;
    }


    /**
     * Sets the borderLeftOpacity value for this Border.
     * 
     * @param borderLeftOpacity
     */
    public void setBorderLeftOpacity(java.lang.String borderLeftOpacity) {
        this.borderLeftOpacity = borderLeftOpacity;
    }


    /**
     * Gets the borderLeftShade value for this Border.
     * 
     * @return borderLeftShade
     */
    public java.lang.String getBorderLeftShade() {
        return borderLeftShade;
    }


    /**
     * Sets the borderLeftShade value for this Border.
     * 
     * @param borderLeftShade
     */
    public void setBorderLeftShade(java.lang.String borderLeftShade) {
        this.borderLeftShade = borderLeftShade;
    }


    /**
     * Gets the borderLeftStyle value for this Border.
     * 
     * @return borderLeftStyle
     */
    public java.lang.String getBorderLeftStyle() {
        return borderLeftStyle;
    }


    /**
     * Sets the borderLeftStyle value for this Border.
     * 
     * @param borderLeftStyle
     */
    public void setBorderLeftStyle(java.lang.String borderLeftStyle) {
        this.borderLeftStyle = borderLeftStyle;
    }


    /**
     * Gets the borderLeftWidth value for this Border.
     * 
     * @return borderLeftWidth
     */
    public java.lang.String getBorderLeftWidth() {
        return borderLeftWidth;
    }


    /**
     * Sets the borderLeftWidth value for this Border.
     * 
     * @param borderLeftWidth
     */
    public void setBorderLeftWidth(java.lang.String borderLeftWidth) {
        this.borderLeftWidth = borderLeftWidth;
    }


    /**
     * Gets the borderMidHorizontalBlendMode value for this Border.
     * 
     * @return borderMidHorizontalBlendMode
     */
    public java.lang.String getBorderMidHorizontalBlendMode() {
        return borderMidHorizontalBlendMode;
    }


    /**
     * Sets the borderMidHorizontalBlendMode value for this Border.
     * 
     * @param borderMidHorizontalBlendMode
     */
    public void setBorderMidHorizontalBlendMode(java.lang.String borderMidHorizontalBlendMode) {
        this.borderMidHorizontalBlendMode = borderMidHorizontalBlendMode;
    }


    /**
     * Gets the borderMidHorizontalColor value for this Border.
     * 
     * @return borderMidHorizontalColor
     */
    public java.lang.String getBorderMidHorizontalColor() {
        return borderMidHorizontalColor;
    }


    /**
     * Sets the borderMidHorizontalColor value for this Border.
     * 
     * @param borderMidHorizontalColor
     */
    public void setBorderMidHorizontalColor(java.lang.String borderMidHorizontalColor) {
        this.borderMidHorizontalColor = borderMidHorizontalColor;
    }


    /**
     * Gets the borderMidHorizontalGapBlendMode value for this Border.
     * 
     * @return borderMidHorizontalGapBlendMode
     */
    public java.lang.String getBorderMidHorizontalGapBlendMode() {
        return borderMidHorizontalGapBlendMode;
    }


    /**
     * Sets the borderMidHorizontalGapBlendMode value for this Border.
     * 
     * @param borderMidHorizontalGapBlendMode
     */
    public void setBorderMidHorizontalGapBlendMode(java.lang.String borderMidHorizontalGapBlendMode) {
        this.borderMidHorizontalGapBlendMode = borderMidHorizontalGapBlendMode;
    }


    /**
     * Gets the borderMidHorizontalGapColor value for this Border.
     * 
     * @return borderMidHorizontalGapColor
     */
    public java.lang.String getBorderMidHorizontalGapColor() {
        return borderMidHorizontalGapColor;
    }


    /**
     * Sets the borderMidHorizontalGapColor value for this Border.
     * 
     * @param borderMidHorizontalGapColor
     */
    public void setBorderMidHorizontalGapColor(java.lang.String borderMidHorizontalGapColor) {
        this.borderMidHorizontalGapColor = borderMidHorizontalGapColor;
    }


    /**
     * Gets the borderMidHorizontalGapOpacity value for this Border.
     * 
     * @return borderMidHorizontalGapOpacity
     */
    public java.lang.String getBorderMidHorizontalGapOpacity() {
        return borderMidHorizontalGapOpacity;
    }


    /**
     * Sets the borderMidHorizontalGapOpacity value for this Border.
     * 
     * @param borderMidHorizontalGapOpacity
     */
    public void setBorderMidHorizontalGapOpacity(java.lang.String borderMidHorizontalGapOpacity) {
        this.borderMidHorizontalGapOpacity = borderMidHorizontalGapOpacity;
    }


    /**
     * Gets the borderMidHorizontalGapShade value for this Border.
     * 
     * @return borderMidHorizontalGapShade
     */
    public java.lang.String getBorderMidHorizontalGapShade() {
        return borderMidHorizontalGapShade;
    }


    /**
     * Sets the borderMidHorizontalGapShade value for this Border.
     * 
     * @param borderMidHorizontalGapShade
     */
    public void setBorderMidHorizontalGapShade(java.lang.String borderMidHorizontalGapShade) {
        this.borderMidHorizontalGapShade = borderMidHorizontalGapShade;
    }


    /**
     * Gets the borderMidHorizontalOpacity value for this Border.
     * 
     * @return borderMidHorizontalOpacity
     */
    public java.lang.String getBorderMidHorizontalOpacity() {
        return borderMidHorizontalOpacity;
    }


    /**
     * Sets the borderMidHorizontalOpacity value for this Border.
     * 
     * @param borderMidHorizontalOpacity
     */
    public void setBorderMidHorizontalOpacity(java.lang.String borderMidHorizontalOpacity) {
        this.borderMidHorizontalOpacity = borderMidHorizontalOpacity;
    }


    /**
     * Gets the borderMidHorizontalShade value for this Border.
     * 
     * @return borderMidHorizontalShade
     */
    public java.lang.String getBorderMidHorizontalShade() {
        return borderMidHorizontalShade;
    }


    /**
     * Sets the borderMidHorizontalShade value for this Border.
     * 
     * @param borderMidHorizontalShade
     */
    public void setBorderMidHorizontalShade(java.lang.String borderMidHorizontalShade) {
        this.borderMidHorizontalShade = borderMidHorizontalShade;
    }


    /**
     * Gets the borderMidHorizontalStyle value for this Border.
     * 
     * @return borderMidHorizontalStyle
     */
    public java.lang.String getBorderMidHorizontalStyle() {
        return borderMidHorizontalStyle;
    }


    /**
     * Sets the borderMidHorizontalStyle value for this Border.
     * 
     * @param borderMidHorizontalStyle
     */
    public void setBorderMidHorizontalStyle(java.lang.String borderMidHorizontalStyle) {
        this.borderMidHorizontalStyle = borderMidHorizontalStyle;
    }


    /**
     * Gets the borderMidHorizontalWidth value for this Border.
     * 
     * @return borderMidHorizontalWidth
     */
    public java.lang.String getBorderMidHorizontalWidth() {
        return borderMidHorizontalWidth;
    }


    /**
     * Sets the borderMidHorizontalWidth value for this Border.
     * 
     * @param borderMidHorizontalWidth
     */
    public void setBorderMidHorizontalWidth(java.lang.String borderMidHorizontalWidth) {
        this.borderMidHorizontalWidth = borderMidHorizontalWidth;
    }


    /**
     * Gets the borderMidVerticalBlendMode value for this Border.
     * 
     * @return borderMidVerticalBlendMode
     */
    public java.lang.String getBorderMidVerticalBlendMode() {
        return borderMidVerticalBlendMode;
    }


    /**
     * Sets the borderMidVerticalBlendMode value for this Border.
     * 
     * @param borderMidVerticalBlendMode
     */
    public void setBorderMidVerticalBlendMode(java.lang.String borderMidVerticalBlendMode) {
        this.borderMidVerticalBlendMode = borderMidVerticalBlendMode;
    }


    /**
     * Gets the borderMidVerticalColor value for this Border.
     * 
     * @return borderMidVerticalColor
     */
    public java.lang.String getBorderMidVerticalColor() {
        return borderMidVerticalColor;
    }


    /**
     * Sets the borderMidVerticalColor value for this Border.
     * 
     * @param borderMidVerticalColor
     */
    public void setBorderMidVerticalColor(java.lang.String borderMidVerticalColor) {
        this.borderMidVerticalColor = borderMidVerticalColor;
    }


    /**
     * Gets the borderMidVerticalGapBlendMode value for this Border.
     * 
     * @return borderMidVerticalGapBlendMode
     */
    public java.lang.String getBorderMidVerticalGapBlendMode() {
        return borderMidVerticalGapBlendMode;
    }


    /**
     * Sets the borderMidVerticalGapBlendMode value for this Border.
     * 
     * @param borderMidVerticalGapBlendMode
     */
    public void setBorderMidVerticalGapBlendMode(java.lang.String borderMidVerticalGapBlendMode) {
        this.borderMidVerticalGapBlendMode = borderMidVerticalGapBlendMode;
    }


    /**
     * Gets the borderMidVerticalGapColor value for this Border.
     * 
     * @return borderMidVerticalGapColor
     */
    public java.lang.String getBorderMidVerticalGapColor() {
        return borderMidVerticalGapColor;
    }


    /**
     * Sets the borderMidVerticalGapColor value for this Border.
     * 
     * @param borderMidVerticalGapColor
     */
    public void setBorderMidVerticalGapColor(java.lang.String borderMidVerticalGapColor) {
        this.borderMidVerticalGapColor = borderMidVerticalGapColor;
    }


    /**
     * Gets the borderMidVerticalGapOpacity value for this Border.
     * 
     * @return borderMidVerticalGapOpacity
     */
    public java.lang.String getBorderMidVerticalGapOpacity() {
        return borderMidVerticalGapOpacity;
    }


    /**
     * Sets the borderMidVerticalGapOpacity value for this Border.
     * 
     * @param borderMidVerticalGapOpacity
     */
    public void setBorderMidVerticalGapOpacity(java.lang.String borderMidVerticalGapOpacity) {
        this.borderMidVerticalGapOpacity = borderMidVerticalGapOpacity;
    }


    /**
     * Gets the borderMidVerticalGapShade value for this Border.
     * 
     * @return borderMidVerticalGapShade
     */
    public java.lang.String getBorderMidVerticalGapShade() {
        return borderMidVerticalGapShade;
    }


    /**
     * Sets the borderMidVerticalGapShade value for this Border.
     * 
     * @param borderMidVerticalGapShade
     */
    public void setBorderMidVerticalGapShade(java.lang.String borderMidVerticalGapShade) {
        this.borderMidVerticalGapShade = borderMidVerticalGapShade;
    }


    /**
     * Gets the borderMidVerticalOpacity value for this Border.
     * 
     * @return borderMidVerticalOpacity
     */
    public java.lang.String getBorderMidVerticalOpacity() {
        return borderMidVerticalOpacity;
    }


    /**
     * Sets the borderMidVerticalOpacity value for this Border.
     * 
     * @param borderMidVerticalOpacity
     */
    public void setBorderMidVerticalOpacity(java.lang.String borderMidVerticalOpacity) {
        this.borderMidVerticalOpacity = borderMidVerticalOpacity;
    }


    /**
     * Gets the borderMidVerticalShade value for this Border.
     * 
     * @return borderMidVerticalShade
     */
    public java.lang.String getBorderMidVerticalShade() {
        return borderMidVerticalShade;
    }


    /**
     * Sets the borderMidVerticalShade value for this Border.
     * 
     * @param borderMidVerticalShade
     */
    public void setBorderMidVerticalShade(java.lang.String borderMidVerticalShade) {
        this.borderMidVerticalShade = borderMidVerticalShade;
    }


    /**
     * Gets the borderMidVerticalStyle value for this Border.
     * 
     * @return borderMidVerticalStyle
     */
    public java.lang.String getBorderMidVerticalStyle() {
        return borderMidVerticalStyle;
    }


    /**
     * Sets the borderMidVerticalStyle value for this Border.
     * 
     * @param borderMidVerticalStyle
     */
    public void setBorderMidVerticalStyle(java.lang.String borderMidVerticalStyle) {
        this.borderMidVerticalStyle = borderMidVerticalStyle;
    }


    /**
     * Gets the borderMidVerticalWidth value for this Border.
     * 
     * @return borderMidVerticalWidth
     */
    public java.lang.String getBorderMidVerticalWidth() {
        return borderMidVerticalWidth;
    }


    /**
     * Sets the borderMidVerticalWidth value for this Border.
     * 
     * @param borderMidVerticalWidth
     */
    public void setBorderMidVerticalWidth(java.lang.String borderMidVerticalWidth) {
        this.borderMidVerticalWidth = borderMidVerticalWidth;
    }


    /**
     * Gets the borderRightBlendMode value for this Border.
     * 
     * @return borderRightBlendMode
     */
    public java.lang.String getBorderRightBlendMode() {
        return borderRightBlendMode;
    }


    /**
     * Sets the borderRightBlendMode value for this Border.
     * 
     * @param borderRightBlendMode
     */
    public void setBorderRightBlendMode(java.lang.String borderRightBlendMode) {
        this.borderRightBlendMode = borderRightBlendMode;
    }


    /**
     * Gets the borderRightColor value for this Border.
     * 
     * @return borderRightColor
     */
    public java.lang.String getBorderRightColor() {
        return borderRightColor;
    }


    /**
     * Sets the borderRightColor value for this Border.
     * 
     * @param borderRightColor
     */
    public void setBorderRightColor(java.lang.String borderRightColor) {
        this.borderRightColor = borderRightColor;
    }


    /**
     * Gets the borderRightGapBlendMode value for this Border.
     * 
     * @return borderRightGapBlendMode
     */
    public java.lang.String getBorderRightGapBlendMode() {
        return borderRightGapBlendMode;
    }


    /**
     * Sets the borderRightGapBlendMode value for this Border.
     * 
     * @param borderRightGapBlendMode
     */
    public void setBorderRightGapBlendMode(java.lang.String borderRightGapBlendMode) {
        this.borderRightGapBlendMode = borderRightGapBlendMode;
    }


    /**
     * Gets the borderRightGapColor value for this Border.
     * 
     * @return borderRightGapColor
     */
    public java.lang.String getBorderRightGapColor() {
        return borderRightGapColor;
    }


    /**
     * Sets the borderRightGapColor value for this Border.
     * 
     * @param borderRightGapColor
     */
    public void setBorderRightGapColor(java.lang.String borderRightGapColor) {
        this.borderRightGapColor = borderRightGapColor;
    }


    /**
     * Gets the borderRightGapOpacity value for this Border.
     * 
     * @return borderRightGapOpacity
     */
    public java.lang.String getBorderRightGapOpacity() {
        return borderRightGapOpacity;
    }


    /**
     * Sets the borderRightGapOpacity value for this Border.
     * 
     * @param borderRightGapOpacity
     */
    public void setBorderRightGapOpacity(java.lang.String borderRightGapOpacity) {
        this.borderRightGapOpacity = borderRightGapOpacity;
    }


    /**
     * Gets the borderRightGapShade value for this Border.
     * 
     * @return borderRightGapShade
     */
    public java.lang.String getBorderRightGapShade() {
        return borderRightGapShade;
    }


    /**
     * Sets the borderRightGapShade value for this Border.
     * 
     * @param borderRightGapShade
     */
    public void setBorderRightGapShade(java.lang.String borderRightGapShade) {
        this.borderRightGapShade = borderRightGapShade;
    }


    /**
     * Gets the borderRightOpacity value for this Border.
     * 
     * @return borderRightOpacity
     */
    public java.lang.String getBorderRightOpacity() {
        return borderRightOpacity;
    }


    /**
     * Sets the borderRightOpacity value for this Border.
     * 
     * @param borderRightOpacity
     */
    public void setBorderRightOpacity(java.lang.String borderRightOpacity) {
        this.borderRightOpacity = borderRightOpacity;
    }


    /**
     * Gets the borderRightShade value for this Border.
     * 
     * @return borderRightShade
     */
    public java.lang.String getBorderRightShade() {
        return borderRightShade;
    }


    /**
     * Sets the borderRightShade value for this Border.
     * 
     * @param borderRightShade
     */
    public void setBorderRightShade(java.lang.String borderRightShade) {
        this.borderRightShade = borderRightShade;
    }


    /**
     * Gets the borderRightStyle value for this Border.
     * 
     * @return borderRightStyle
     */
    public java.lang.String getBorderRightStyle() {
        return borderRightStyle;
    }


    /**
     * Sets the borderRightStyle value for this Border.
     * 
     * @param borderRightStyle
     */
    public void setBorderRightStyle(java.lang.String borderRightStyle) {
        this.borderRightStyle = borderRightStyle;
    }


    /**
     * Gets the borderRightWidth value for this Border.
     * 
     * @return borderRightWidth
     */
    public java.lang.String getBorderRightWidth() {
        return borderRightWidth;
    }


    /**
     * Sets the borderRightWidth value for this Border.
     * 
     * @param borderRightWidth
     */
    public void setBorderRightWidth(java.lang.String borderRightWidth) {
        this.borderRightWidth = borderRightWidth;
    }


    /**
     * Gets the borderTopBlendMode value for this Border.
     * 
     * @return borderTopBlendMode
     */
    public java.lang.String getBorderTopBlendMode() {
        return borderTopBlendMode;
    }


    /**
     * Sets the borderTopBlendMode value for this Border.
     * 
     * @param borderTopBlendMode
     */
    public void setBorderTopBlendMode(java.lang.String borderTopBlendMode) {
        this.borderTopBlendMode = borderTopBlendMode;
    }


    /**
     * Gets the borderTopColor value for this Border.
     * 
     * @return borderTopColor
     */
    public java.lang.String getBorderTopColor() {
        return borderTopColor;
    }


    /**
     * Sets the borderTopColor value for this Border.
     * 
     * @param borderTopColor
     */
    public void setBorderTopColor(java.lang.String borderTopColor) {
        this.borderTopColor = borderTopColor;
    }


    /**
     * Gets the borderTopGapBlendMode value for this Border.
     * 
     * @return borderTopGapBlendMode
     */
    public java.lang.String getBorderTopGapBlendMode() {
        return borderTopGapBlendMode;
    }


    /**
     * Sets the borderTopGapBlendMode value for this Border.
     * 
     * @param borderTopGapBlendMode
     */
    public void setBorderTopGapBlendMode(java.lang.String borderTopGapBlendMode) {
        this.borderTopGapBlendMode = borderTopGapBlendMode;
    }


    /**
     * Gets the borderTopGapColor value for this Border.
     * 
     * @return borderTopGapColor
     */
    public java.lang.String getBorderTopGapColor() {
        return borderTopGapColor;
    }


    /**
     * Sets the borderTopGapColor value for this Border.
     * 
     * @param borderTopGapColor
     */
    public void setBorderTopGapColor(java.lang.String borderTopGapColor) {
        this.borderTopGapColor = borderTopGapColor;
    }


    /**
     * Gets the borderTopGapOpacity value for this Border.
     * 
     * @return borderTopGapOpacity
     */
    public java.lang.String getBorderTopGapOpacity() {
        return borderTopGapOpacity;
    }


    /**
     * Sets the borderTopGapOpacity value for this Border.
     * 
     * @param borderTopGapOpacity
     */
    public void setBorderTopGapOpacity(java.lang.String borderTopGapOpacity) {
        this.borderTopGapOpacity = borderTopGapOpacity;
    }


    /**
     * Gets the borderTopGapShade value for this Border.
     * 
     * @return borderTopGapShade
     */
    public java.lang.String getBorderTopGapShade() {
        return borderTopGapShade;
    }


    /**
     * Sets the borderTopGapShade value for this Border.
     * 
     * @param borderTopGapShade
     */
    public void setBorderTopGapShade(java.lang.String borderTopGapShade) {
        this.borderTopGapShade = borderTopGapShade;
    }


    /**
     * Gets the borderTopOpacity value for this Border.
     * 
     * @return borderTopOpacity
     */
    public java.lang.String getBorderTopOpacity() {
        return borderTopOpacity;
    }


    /**
     * Sets the borderTopOpacity value for this Border.
     * 
     * @param borderTopOpacity
     */
    public void setBorderTopOpacity(java.lang.String borderTopOpacity) {
        this.borderTopOpacity = borderTopOpacity;
    }


    /**
     * Gets the borderTopShade value for this Border.
     * 
     * @return borderTopShade
     */
    public java.lang.String getBorderTopShade() {
        return borderTopShade;
    }


    /**
     * Sets the borderTopShade value for this Border.
     * 
     * @param borderTopShade
     */
    public void setBorderTopShade(java.lang.String borderTopShade) {
        this.borderTopShade = borderTopShade;
    }


    /**
     * Gets the borderTopStyle value for this Border.
     * 
     * @return borderTopStyle
     */
    public java.lang.String getBorderTopStyle() {
        return borderTopStyle;
    }


    /**
     * Sets the borderTopStyle value for this Border.
     * 
     * @param borderTopStyle
     */
    public void setBorderTopStyle(java.lang.String borderTopStyle) {
        this.borderTopStyle = borderTopStyle;
    }


    /**
     * Gets the borderTopWidth value for this Border.
     * 
     * @return borderTopWidth
     */
    public java.lang.String getBorderTopWidth() {
        return borderTopWidth;
    }


    /**
     * Sets the borderTopWidth value for this Border.
     * 
     * @param borderTopWidth
     */
    public void setBorderTopWidth(java.lang.String borderTopWidth) {
        this.borderTopWidth = borderTopWidth;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Border)) return false;
        Border other = (Border) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.borderBottomBlendMode==null && other.getBorderBottomBlendMode()==null) || 
             (this.borderBottomBlendMode!=null &&
              this.borderBottomBlendMode.equals(other.getBorderBottomBlendMode()))) &&
            ((this.borderBottomColor==null && other.getBorderBottomColor()==null) || 
             (this.borderBottomColor!=null &&
              this.borderBottomColor.equals(other.getBorderBottomColor()))) &&
            ((this.borderBottomGapBlendMode==null && other.getBorderBottomGapBlendMode()==null) || 
             (this.borderBottomGapBlendMode!=null &&
              this.borderBottomGapBlendMode.equals(other.getBorderBottomGapBlendMode()))) &&
            ((this.borderBottomGapColor==null && other.getBorderBottomGapColor()==null) || 
             (this.borderBottomGapColor!=null &&
              this.borderBottomGapColor.equals(other.getBorderBottomGapColor()))) &&
            ((this.borderBottomGapOpacity==null && other.getBorderBottomGapOpacity()==null) || 
             (this.borderBottomGapOpacity!=null &&
              this.borderBottomGapOpacity.equals(other.getBorderBottomGapOpacity()))) &&
            ((this.borderBottomGapShade==null && other.getBorderBottomGapShade()==null) || 
             (this.borderBottomGapShade!=null &&
              this.borderBottomGapShade.equals(other.getBorderBottomGapShade()))) &&
            ((this.borderBottomOpacity==null && other.getBorderBottomOpacity()==null) || 
             (this.borderBottomOpacity!=null &&
              this.borderBottomOpacity.equals(other.getBorderBottomOpacity()))) &&
            ((this.borderBottomShade==null && other.getBorderBottomShade()==null) || 
             (this.borderBottomShade!=null &&
              this.borderBottomShade.equals(other.getBorderBottomShade()))) &&
            ((this.borderBottomStyle==null && other.getBorderBottomStyle()==null) || 
             (this.borderBottomStyle!=null &&
              this.borderBottomStyle.equals(other.getBorderBottomStyle()))) &&
            ((this.borderBottomWidth==null && other.getBorderBottomWidth()==null) || 
             (this.borderBottomWidth!=null &&
              this.borderBottomWidth.equals(other.getBorderBottomWidth()))) &&
            ((this.borderLeftBlendMode==null && other.getBorderLeftBlendMode()==null) || 
             (this.borderLeftBlendMode!=null &&
              this.borderLeftBlendMode.equals(other.getBorderLeftBlendMode()))) &&
            ((this.borderLeftColor==null && other.getBorderLeftColor()==null) || 
             (this.borderLeftColor!=null &&
              this.borderLeftColor.equals(other.getBorderLeftColor()))) &&
            ((this.borderLeftGapBlendMode==null && other.getBorderLeftGapBlendMode()==null) || 
             (this.borderLeftGapBlendMode!=null &&
              this.borderLeftGapBlendMode.equals(other.getBorderLeftGapBlendMode()))) &&
            ((this.borderLeftGapColor==null && other.getBorderLeftGapColor()==null) || 
             (this.borderLeftGapColor!=null &&
              this.borderLeftGapColor.equals(other.getBorderLeftGapColor()))) &&
            ((this.borderLeftGapOpacity==null && other.getBorderLeftGapOpacity()==null) || 
             (this.borderLeftGapOpacity!=null &&
              this.borderLeftGapOpacity.equals(other.getBorderLeftGapOpacity()))) &&
            ((this.borderLeftGapShade==null && other.getBorderLeftGapShade()==null) || 
             (this.borderLeftGapShade!=null &&
              this.borderLeftGapShade.equals(other.getBorderLeftGapShade()))) &&
            ((this.borderLeftOpacity==null && other.getBorderLeftOpacity()==null) || 
             (this.borderLeftOpacity!=null &&
              this.borderLeftOpacity.equals(other.getBorderLeftOpacity()))) &&
            ((this.borderLeftShade==null && other.getBorderLeftShade()==null) || 
             (this.borderLeftShade!=null &&
              this.borderLeftShade.equals(other.getBorderLeftShade()))) &&
            ((this.borderLeftStyle==null && other.getBorderLeftStyle()==null) || 
             (this.borderLeftStyle!=null &&
              this.borderLeftStyle.equals(other.getBorderLeftStyle()))) &&
            ((this.borderLeftWidth==null && other.getBorderLeftWidth()==null) || 
             (this.borderLeftWidth!=null &&
              this.borderLeftWidth.equals(other.getBorderLeftWidth()))) &&
            ((this.borderMidHorizontalBlendMode==null && other.getBorderMidHorizontalBlendMode()==null) || 
             (this.borderMidHorizontalBlendMode!=null &&
              this.borderMidHorizontalBlendMode.equals(other.getBorderMidHorizontalBlendMode()))) &&
            ((this.borderMidHorizontalColor==null && other.getBorderMidHorizontalColor()==null) || 
             (this.borderMidHorizontalColor!=null &&
              this.borderMidHorizontalColor.equals(other.getBorderMidHorizontalColor()))) &&
            ((this.borderMidHorizontalGapBlendMode==null && other.getBorderMidHorizontalGapBlendMode()==null) || 
             (this.borderMidHorizontalGapBlendMode!=null &&
              this.borderMidHorizontalGapBlendMode.equals(other.getBorderMidHorizontalGapBlendMode()))) &&
            ((this.borderMidHorizontalGapColor==null && other.getBorderMidHorizontalGapColor()==null) || 
             (this.borderMidHorizontalGapColor!=null &&
              this.borderMidHorizontalGapColor.equals(other.getBorderMidHorizontalGapColor()))) &&
            ((this.borderMidHorizontalGapOpacity==null && other.getBorderMidHorizontalGapOpacity()==null) || 
             (this.borderMidHorizontalGapOpacity!=null &&
              this.borderMidHorizontalGapOpacity.equals(other.getBorderMidHorizontalGapOpacity()))) &&
            ((this.borderMidHorizontalGapShade==null && other.getBorderMidHorizontalGapShade()==null) || 
             (this.borderMidHorizontalGapShade!=null &&
              this.borderMidHorizontalGapShade.equals(other.getBorderMidHorizontalGapShade()))) &&
            ((this.borderMidHorizontalOpacity==null && other.getBorderMidHorizontalOpacity()==null) || 
             (this.borderMidHorizontalOpacity!=null &&
              this.borderMidHorizontalOpacity.equals(other.getBorderMidHorizontalOpacity()))) &&
            ((this.borderMidHorizontalShade==null && other.getBorderMidHorizontalShade()==null) || 
             (this.borderMidHorizontalShade!=null &&
              this.borderMidHorizontalShade.equals(other.getBorderMidHorizontalShade()))) &&
            ((this.borderMidHorizontalStyle==null && other.getBorderMidHorizontalStyle()==null) || 
             (this.borderMidHorizontalStyle!=null &&
              this.borderMidHorizontalStyle.equals(other.getBorderMidHorizontalStyle()))) &&
            ((this.borderMidHorizontalWidth==null && other.getBorderMidHorizontalWidth()==null) || 
             (this.borderMidHorizontalWidth!=null &&
              this.borderMidHorizontalWidth.equals(other.getBorderMidHorizontalWidth()))) &&
            ((this.borderMidVerticalBlendMode==null && other.getBorderMidVerticalBlendMode()==null) || 
             (this.borderMidVerticalBlendMode!=null &&
              this.borderMidVerticalBlendMode.equals(other.getBorderMidVerticalBlendMode()))) &&
            ((this.borderMidVerticalColor==null && other.getBorderMidVerticalColor()==null) || 
             (this.borderMidVerticalColor!=null &&
              this.borderMidVerticalColor.equals(other.getBorderMidVerticalColor()))) &&
            ((this.borderMidVerticalGapBlendMode==null && other.getBorderMidVerticalGapBlendMode()==null) || 
             (this.borderMidVerticalGapBlendMode!=null &&
              this.borderMidVerticalGapBlendMode.equals(other.getBorderMidVerticalGapBlendMode()))) &&
            ((this.borderMidVerticalGapColor==null && other.getBorderMidVerticalGapColor()==null) || 
             (this.borderMidVerticalGapColor!=null &&
              this.borderMidVerticalGapColor.equals(other.getBorderMidVerticalGapColor()))) &&
            ((this.borderMidVerticalGapOpacity==null && other.getBorderMidVerticalGapOpacity()==null) || 
             (this.borderMidVerticalGapOpacity!=null &&
              this.borderMidVerticalGapOpacity.equals(other.getBorderMidVerticalGapOpacity()))) &&
            ((this.borderMidVerticalGapShade==null && other.getBorderMidVerticalGapShade()==null) || 
             (this.borderMidVerticalGapShade!=null &&
              this.borderMidVerticalGapShade.equals(other.getBorderMidVerticalGapShade()))) &&
            ((this.borderMidVerticalOpacity==null && other.getBorderMidVerticalOpacity()==null) || 
             (this.borderMidVerticalOpacity!=null &&
              this.borderMidVerticalOpacity.equals(other.getBorderMidVerticalOpacity()))) &&
            ((this.borderMidVerticalShade==null && other.getBorderMidVerticalShade()==null) || 
             (this.borderMidVerticalShade!=null &&
              this.borderMidVerticalShade.equals(other.getBorderMidVerticalShade()))) &&
            ((this.borderMidVerticalStyle==null && other.getBorderMidVerticalStyle()==null) || 
             (this.borderMidVerticalStyle!=null &&
              this.borderMidVerticalStyle.equals(other.getBorderMidVerticalStyle()))) &&
            ((this.borderMidVerticalWidth==null && other.getBorderMidVerticalWidth()==null) || 
             (this.borderMidVerticalWidth!=null &&
              this.borderMidVerticalWidth.equals(other.getBorderMidVerticalWidth()))) &&
            ((this.borderRightBlendMode==null && other.getBorderRightBlendMode()==null) || 
             (this.borderRightBlendMode!=null &&
              this.borderRightBlendMode.equals(other.getBorderRightBlendMode()))) &&
            ((this.borderRightColor==null && other.getBorderRightColor()==null) || 
             (this.borderRightColor!=null &&
              this.borderRightColor.equals(other.getBorderRightColor()))) &&
            ((this.borderRightGapBlendMode==null && other.getBorderRightGapBlendMode()==null) || 
             (this.borderRightGapBlendMode!=null &&
              this.borderRightGapBlendMode.equals(other.getBorderRightGapBlendMode()))) &&
            ((this.borderRightGapColor==null && other.getBorderRightGapColor()==null) || 
             (this.borderRightGapColor!=null &&
              this.borderRightGapColor.equals(other.getBorderRightGapColor()))) &&
            ((this.borderRightGapOpacity==null && other.getBorderRightGapOpacity()==null) || 
             (this.borderRightGapOpacity!=null &&
              this.borderRightGapOpacity.equals(other.getBorderRightGapOpacity()))) &&
            ((this.borderRightGapShade==null && other.getBorderRightGapShade()==null) || 
             (this.borderRightGapShade!=null &&
              this.borderRightGapShade.equals(other.getBorderRightGapShade()))) &&
            ((this.borderRightOpacity==null && other.getBorderRightOpacity()==null) || 
             (this.borderRightOpacity!=null &&
              this.borderRightOpacity.equals(other.getBorderRightOpacity()))) &&
            ((this.borderRightShade==null && other.getBorderRightShade()==null) || 
             (this.borderRightShade!=null &&
              this.borderRightShade.equals(other.getBorderRightShade()))) &&
            ((this.borderRightStyle==null && other.getBorderRightStyle()==null) || 
             (this.borderRightStyle!=null &&
              this.borderRightStyle.equals(other.getBorderRightStyle()))) &&
            ((this.borderRightWidth==null && other.getBorderRightWidth()==null) || 
             (this.borderRightWidth!=null &&
              this.borderRightWidth.equals(other.getBorderRightWidth()))) &&
            ((this.borderTopBlendMode==null && other.getBorderTopBlendMode()==null) || 
             (this.borderTopBlendMode!=null &&
              this.borderTopBlendMode.equals(other.getBorderTopBlendMode()))) &&
            ((this.borderTopColor==null && other.getBorderTopColor()==null) || 
             (this.borderTopColor!=null &&
              this.borderTopColor.equals(other.getBorderTopColor()))) &&
            ((this.borderTopGapBlendMode==null && other.getBorderTopGapBlendMode()==null) || 
             (this.borderTopGapBlendMode!=null &&
              this.borderTopGapBlendMode.equals(other.getBorderTopGapBlendMode()))) &&
            ((this.borderTopGapColor==null && other.getBorderTopGapColor()==null) || 
             (this.borderTopGapColor!=null &&
              this.borderTopGapColor.equals(other.getBorderTopGapColor()))) &&
            ((this.borderTopGapOpacity==null && other.getBorderTopGapOpacity()==null) || 
             (this.borderTopGapOpacity!=null &&
              this.borderTopGapOpacity.equals(other.getBorderTopGapOpacity()))) &&
            ((this.borderTopGapShade==null && other.getBorderTopGapShade()==null) || 
             (this.borderTopGapShade!=null &&
              this.borderTopGapShade.equals(other.getBorderTopGapShade()))) &&
            ((this.borderTopOpacity==null && other.getBorderTopOpacity()==null) || 
             (this.borderTopOpacity!=null &&
              this.borderTopOpacity.equals(other.getBorderTopOpacity()))) &&
            ((this.borderTopShade==null && other.getBorderTopShade()==null) || 
             (this.borderTopShade!=null &&
              this.borderTopShade.equals(other.getBorderTopShade()))) &&
            ((this.borderTopStyle==null && other.getBorderTopStyle()==null) || 
             (this.borderTopStyle!=null &&
              this.borderTopStyle.equals(other.getBorderTopStyle()))) &&
            ((this.borderTopWidth==null && other.getBorderTopWidth()==null) || 
             (this.borderTopWidth!=null &&
              this.borderTopWidth.equals(other.getBorderTopWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBorderBottomBlendMode() != null) {
            _hashCode += getBorderBottomBlendMode().hashCode();
        }
        if (getBorderBottomColor() != null) {
            _hashCode += getBorderBottomColor().hashCode();
        }
        if (getBorderBottomGapBlendMode() != null) {
            _hashCode += getBorderBottomGapBlendMode().hashCode();
        }
        if (getBorderBottomGapColor() != null) {
            _hashCode += getBorderBottomGapColor().hashCode();
        }
        if (getBorderBottomGapOpacity() != null) {
            _hashCode += getBorderBottomGapOpacity().hashCode();
        }
        if (getBorderBottomGapShade() != null) {
            _hashCode += getBorderBottomGapShade().hashCode();
        }
        if (getBorderBottomOpacity() != null) {
            _hashCode += getBorderBottomOpacity().hashCode();
        }
        if (getBorderBottomShade() != null) {
            _hashCode += getBorderBottomShade().hashCode();
        }
        if (getBorderBottomStyle() != null) {
            _hashCode += getBorderBottomStyle().hashCode();
        }
        if (getBorderBottomWidth() != null) {
            _hashCode += getBorderBottomWidth().hashCode();
        }
        if (getBorderLeftBlendMode() != null) {
            _hashCode += getBorderLeftBlendMode().hashCode();
        }
        if (getBorderLeftColor() != null) {
            _hashCode += getBorderLeftColor().hashCode();
        }
        if (getBorderLeftGapBlendMode() != null) {
            _hashCode += getBorderLeftGapBlendMode().hashCode();
        }
        if (getBorderLeftGapColor() != null) {
            _hashCode += getBorderLeftGapColor().hashCode();
        }
        if (getBorderLeftGapOpacity() != null) {
            _hashCode += getBorderLeftGapOpacity().hashCode();
        }
        if (getBorderLeftGapShade() != null) {
            _hashCode += getBorderLeftGapShade().hashCode();
        }
        if (getBorderLeftOpacity() != null) {
            _hashCode += getBorderLeftOpacity().hashCode();
        }
        if (getBorderLeftShade() != null) {
            _hashCode += getBorderLeftShade().hashCode();
        }
        if (getBorderLeftStyle() != null) {
            _hashCode += getBorderLeftStyle().hashCode();
        }
        if (getBorderLeftWidth() != null) {
            _hashCode += getBorderLeftWidth().hashCode();
        }
        if (getBorderMidHorizontalBlendMode() != null) {
            _hashCode += getBorderMidHorizontalBlendMode().hashCode();
        }
        if (getBorderMidHorizontalColor() != null) {
            _hashCode += getBorderMidHorizontalColor().hashCode();
        }
        if (getBorderMidHorizontalGapBlendMode() != null) {
            _hashCode += getBorderMidHorizontalGapBlendMode().hashCode();
        }
        if (getBorderMidHorizontalGapColor() != null) {
            _hashCode += getBorderMidHorizontalGapColor().hashCode();
        }
        if (getBorderMidHorizontalGapOpacity() != null) {
            _hashCode += getBorderMidHorizontalGapOpacity().hashCode();
        }
        if (getBorderMidHorizontalGapShade() != null) {
            _hashCode += getBorderMidHorizontalGapShade().hashCode();
        }
        if (getBorderMidHorizontalOpacity() != null) {
            _hashCode += getBorderMidHorizontalOpacity().hashCode();
        }
        if (getBorderMidHorizontalShade() != null) {
            _hashCode += getBorderMidHorizontalShade().hashCode();
        }
        if (getBorderMidHorizontalStyle() != null) {
            _hashCode += getBorderMidHorizontalStyle().hashCode();
        }
        if (getBorderMidHorizontalWidth() != null) {
            _hashCode += getBorderMidHorizontalWidth().hashCode();
        }
        if (getBorderMidVerticalBlendMode() != null) {
            _hashCode += getBorderMidVerticalBlendMode().hashCode();
        }
        if (getBorderMidVerticalColor() != null) {
            _hashCode += getBorderMidVerticalColor().hashCode();
        }
        if (getBorderMidVerticalGapBlendMode() != null) {
            _hashCode += getBorderMidVerticalGapBlendMode().hashCode();
        }
        if (getBorderMidVerticalGapColor() != null) {
            _hashCode += getBorderMidVerticalGapColor().hashCode();
        }
        if (getBorderMidVerticalGapOpacity() != null) {
            _hashCode += getBorderMidVerticalGapOpacity().hashCode();
        }
        if (getBorderMidVerticalGapShade() != null) {
            _hashCode += getBorderMidVerticalGapShade().hashCode();
        }
        if (getBorderMidVerticalOpacity() != null) {
            _hashCode += getBorderMidVerticalOpacity().hashCode();
        }
        if (getBorderMidVerticalShade() != null) {
            _hashCode += getBorderMidVerticalShade().hashCode();
        }
        if (getBorderMidVerticalStyle() != null) {
            _hashCode += getBorderMidVerticalStyle().hashCode();
        }
        if (getBorderMidVerticalWidth() != null) {
            _hashCode += getBorderMidVerticalWidth().hashCode();
        }
        if (getBorderRightBlendMode() != null) {
            _hashCode += getBorderRightBlendMode().hashCode();
        }
        if (getBorderRightColor() != null) {
            _hashCode += getBorderRightColor().hashCode();
        }
        if (getBorderRightGapBlendMode() != null) {
            _hashCode += getBorderRightGapBlendMode().hashCode();
        }
        if (getBorderRightGapColor() != null) {
            _hashCode += getBorderRightGapColor().hashCode();
        }
        if (getBorderRightGapOpacity() != null) {
            _hashCode += getBorderRightGapOpacity().hashCode();
        }
        if (getBorderRightGapShade() != null) {
            _hashCode += getBorderRightGapShade().hashCode();
        }
        if (getBorderRightOpacity() != null) {
            _hashCode += getBorderRightOpacity().hashCode();
        }
        if (getBorderRightShade() != null) {
            _hashCode += getBorderRightShade().hashCode();
        }
        if (getBorderRightStyle() != null) {
            _hashCode += getBorderRightStyle().hashCode();
        }
        if (getBorderRightWidth() != null) {
            _hashCode += getBorderRightWidth().hashCode();
        }
        if (getBorderTopBlendMode() != null) {
            _hashCode += getBorderTopBlendMode().hashCode();
        }
        if (getBorderTopColor() != null) {
            _hashCode += getBorderTopColor().hashCode();
        }
        if (getBorderTopGapBlendMode() != null) {
            _hashCode += getBorderTopGapBlendMode().hashCode();
        }
        if (getBorderTopGapColor() != null) {
            _hashCode += getBorderTopGapColor().hashCode();
        }
        if (getBorderTopGapOpacity() != null) {
            _hashCode += getBorderTopGapOpacity().hashCode();
        }
        if (getBorderTopGapShade() != null) {
            _hashCode += getBorderTopGapShade().hashCode();
        }
        if (getBorderTopOpacity() != null) {
            _hashCode += getBorderTopOpacity().hashCode();
        }
        if (getBorderTopShade() != null) {
            _hashCode += getBorderTopShade().hashCode();
        }
        if (getBorderTopStyle() != null) {
            _hashCode += getBorderTopStyle().hashCode();
        }
        if (getBorderTopWidth() != null) {
            _hashCode += getBorderTopWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Border.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Border"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomGapBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomGapBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomGapColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomGapColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomGapOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomGapOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomGapShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomGapShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftGapBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftGapBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftGapColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftGapColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftGapOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftGapOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftGapShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftGapShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalGapBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalGapBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalGapColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalGapColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalGapOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalGapOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalGapShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalGapShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidHorizontalWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidHorizontalWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalGapBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalGapBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalGapColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalGapColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalGapOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalGapOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalGapShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalGapShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderMidVerticalWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderMidVerticalWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightGapBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightGapBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightGapColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightGapColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightGapOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightGapOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightGapShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightGapShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopGapBlendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopGapBlendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopGapColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopGapColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopGapOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopGapOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopGapShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopGapShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
