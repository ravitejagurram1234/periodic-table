/**
 * Format.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Format  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String HAndJ;

    private java.lang.String alignment;

    private java.lang.String characterAlignment;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.DropCap dropCap;

    private java.lang.String firstLine;

    private java.lang.String hangingCharacters;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.KeepLinesTogether keepLinesTogether;

    private java.lang.String keepWithNext;

    private java.lang.String leading;

    private java.lang.String leftIndent;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LockToGrid lockToGrid;

    private java.lang.String mojigumiSet;

    private java.lang.String rightIndent;

    private java.lang.String spaceAfter;

    private java.lang.String spaceBefore;

    public Format() {
    }

    public Format(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String HAndJ,
           java.lang.String alignment,
           java.lang.String characterAlignment,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.DropCap dropCap,
           java.lang.String firstLine,
           java.lang.String hangingCharacters,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.KeepLinesTogether keepLinesTogether,
           java.lang.String keepWithNext,
           java.lang.String leading,
           java.lang.String leftIndent,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LockToGrid lockToGrid,
           java.lang.String mojigumiSet,
           java.lang.String rightIndent,
           java.lang.String spaceAfter,
           java.lang.String spaceBefore) {
        super(
            request);
        this.HAndJ = HAndJ;
        this.alignment = alignment;
        this.characterAlignment = characterAlignment;
        this.dropCap = dropCap;
        this.firstLine = firstLine;
        this.hangingCharacters = hangingCharacters;
        this.keepLinesTogether = keepLinesTogether;
        this.keepWithNext = keepWithNext;
        this.leading = leading;
        this.leftIndent = leftIndent;
        this.lockToGrid = lockToGrid;
        this.mojigumiSet = mojigumiSet;
        this.rightIndent = rightIndent;
        this.spaceAfter = spaceAfter;
        this.spaceBefore = spaceBefore;
    }


    /**
     * Gets the HAndJ value for this Format.
     * 
     * @return HAndJ
     */
    public java.lang.String getHAndJ() {
        return HAndJ;
    }


    /**
     * Sets the HAndJ value for this Format.
     * 
     * @param HAndJ
     */
    public void setHAndJ(java.lang.String HAndJ) {
        this.HAndJ = HAndJ;
    }


    /**
     * Gets the alignment value for this Format.
     * 
     * @return alignment
     */
    public java.lang.String getAlignment() {
        return alignment;
    }


    /**
     * Sets the alignment value for this Format.
     * 
     * @param alignment
     */
    public void setAlignment(java.lang.String alignment) {
        this.alignment = alignment;
    }


    /**
     * Gets the characterAlignment value for this Format.
     * 
     * @return characterAlignment
     */
    public java.lang.String getCharacterAlignment() {
        return characterAlignment;
    }


    /**
     * Sets the characterAlignment value for this Format.
     * 
     * @param characterAlignment
     */
    public void setCharacterAlignment(java.lang.String characterAlignment) {
        this.characterAlignment = characterAlignment;
    }


    /**
     * Gets the dropCap value for this Format.
     * 
     * @return dropCap
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.DropCap getDropCap() {
        return dropCap;
    }


    /**
     * Sets the dropCap value for this Format.
     * 
     * @param dropCap
     */
    public void setDropCap(com.socgen.sgs.api.quark.engine.integration.soap.generated.DropCap dropCap) {
        this.dropCap = dropCap;
    }


    /**
     * Gets the firstLine value for this Format.
     * 
     * @return firstLine
     */
    public java.lang.String getFirstLine() {
        return firstLine;
    }


    /**
     * Sets the firstLine value for this Format.
     * 
     * @param firstLine
     */
    public void setFirstLine(java.lang.String firstLine) {
        this.firstLine = firstLine;
    }


    /**
     * Gets the hangingCharacters value for this Format.
     * 
     * @return hangingCharacters
     */
    public java.lang.String getHangingCharacters() {
        return hangingCharacters;
    }


    /**
     * Sets the hangingCharacters value for this Format.
     * 
     * @param hangingCharacters
     */
    public void setHangingCharacters(java.lang.String hangingCharacters) {
        this.hangingCharacters = hangingCharacters;
    }


    /**
     * Gets the keepLinesTogether value for this Format.
     * 
     * @return keepLinesTogether
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.KeepLinesTogether getKeepLinesTogether() {
        return keepLinesTogether;
    }


    /**
     * Sets the keepLinesTogether value for this Format.
     * 
     * @param keepLinesTogether
     */
    public void setKeepLinesTogether(com.socgen.sgs.api.quark.engine.integration.soap.generated.KeepLinesTogether keepLinesTogether) {
        this.keepLinesTogether = keepLinesTogether;
    }


    /**
     * Gets the keepWithNext value for this Format.
     * 
     * @return keepWithNext
     */
    public java.lang.String getKeepWithNext() {
        return keepWithNext;
    }


    /**
     * Sets the keepWithNext value for this Format.
     * 
     * @param keepWithNext
     */
    public void setKeepWithNext(java.lang.String keepWithNext) {
        this.keepWithNext = keepWithNext;
    }


    /**
     * Gets the leading value for this Format.
     * 
     * @return leading
     */
    public java.lang.String getLeading() {
        return leading;
    }


    /**
     * Sets the leading value for this Format.
     * 
     * @param leading
     */
    public void setLeading(java.lang.String leading) {
        this.leading = leading;
    }


    /**
     * Gets the leftIndent value for this Format.
     * 
     * @return leftIndent
     */
    public java.lang.String getLeftIndent() {
        return leftIndent;
    }


    /**
     * Sets the leftIndent value for this Format.
     * 
     * @param leftIndent
     */
    public void setLeftIndent(java.lang.String leftIndent) {
        this.leftIndent = leftIndent;
    }


    /**
     * Gets the lockToGrid value for this Format.
     * 
     * @return lockToGrid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LockToGrid getLockToGrid() {
        return lockToGrid;
    }


    /**
     * Sets the lockToGrid value for this Format.
     * 
     * @param lockToGrid
     */
    public void setLockToGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.LockToGrid lockToGrid) {
        this.lockToGrid = lockToGrid;
    }


    /**
     * Gets the mojigumiSet value for this Format.
     * 
     * @return mojigumiSet
     */
    public java.lang.String getMojigumiSet() {
        return mojigumiSet;
    }


    /**
     * Sets the mojigumiSet value for this Format.
     * 
     * @param mojigumiSet
     */
    public void setMojigumiSet(java.lang.String mojigumiSet) {
        this.mojigumiSet = mojigumiSet;
    }


    /**
     * Gets the rightIndent value for this Format.
     * 
     * @return rightIndent
     */
    public java.lang.String getRightIndent() {
        return rightIndent;
    }


    /**
     * Sets the rightIndent value for this Format.
     * 
     * @param rightIndent
     */
    public void setRightIndent(java.lang.String rightIndent) {
        this.rightIndent = rightIndent;
    }


    /**
     * Gets the spaceAfter value for this Format.
     * 
     * @return spaceAfter
     */
    public java.lang.String getSpaceAfter() {
        return spaceAfter;
    }


    /**
     * Sets the spaceAfter value for this Format.
     * 
     * @param spaceAfter
     */
    public void setSpaceAfter(java.lang.String spaceAfter) {
        this.spaceAfter = spaceAfter;
    }


    /**
     * Gets the spaceBefore value for this Format.
     * 
     * @return spaceBefore
     */
    public java.lang.String getSpaceBefore() {
        return spaceBefore;
    }


    /**
     * Sets the spaceBefore value for this Format.
     * 
     * @param spaceBefore
     */
    public void setSpaceBefore(java.lang.String spaceBefore) {
        this.spaceBefore = spaceBefore;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Format)) return false;
        Format other = (Format) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.HAndJ==null && other.getHAndJ()==null) || 
             (this.HAndJ!=null &&
              this.HAndJ.equals(other.getHAndJ()))) &&
            ((this.alignment==null && other.getAlignment()==null) || 
             (this.alignment!=null &&
              this.alignment.equals(other.getAlignment()))) &&
            ((this.characterAlignment==null && other.getCharacterAlignment()==null) || 
             (this.characterAlignment!=null &&
              this.characterAlignment.equals(other.getCharacterAlignment()))) &&
            ((this.dropCap==null && other.getDropCap()==null) || 
             (this.dropCap!=null &&
              this.dropCap.equals(other.getDropCap()))) &&
            ((this.firstLine==null && other.getFirstLine()==null) || 
             (this.firstLine!=null &&
              this.firstLine.equals(other.getFirstLine()))) &&
            ((this.hangingCharacters==null && other.getHangingCharacters()==null) || 
             (this.hangingCharacters!=null &&
              this.hangingCharacters.equals(other.getHangingCharacters()))) &&
            ((this.keepLinesTogether==null && other.getKeepLinesTogether()==null) || 
             (this.keepLinesTogether!=null &&
              this.keepLinesTogether.equals(other.getKeepLinesTogether()))) &&
            ((this.keepWithNext==null && other.getKeepWithNext()==null) || 
             (this.keepWithNext!=null &&
              this.keepWithNext.equals(other.getKeepWithNext()))) &&
            ((this.leading==null && other.getLeading()==null) || 
             (this.leading!=null &&
              this.leading.equals(other.getLeading()))) &&
            ((this.leftIndent==null && other.getLeftIndent()==null) || 
             (this.leftIndent!=null &&
              this.leftIndent.equals(other.getLeftIndent()))) &&
            ((this.lockToGrid==null && other.getLockToGrid()==null) || 
             (this.lockToGrid!=null &&
              this.lockToGrid.equals(other.getLockToGrid()))) &&
            ((this.mojigumiSet==null && other.getMojigumiSet()==null) || 
             (this.mojigumiSet!=null &&
              this.mojigumiSet.equals(other.getMojigumiSet()))) &&
            ((this.rightIndent==null && other.getRightIndent()==null) || 
             (this.rightIndent!=null &&
              this.rightIndent.equals(other.getRightIndent()))) &&
            ((this.spaceAfter==null && other.getSpaceAfter()==null) || 
             (this.spaceAfter!=null &&
              this.spaceAfter.equals(other.getSpaceAfter()))) &&
            ((this.spaceBefore==null && other.getSpaceBefore()==null) || 
             (this.spaceBefore!=null &&
              this.spaceBefore.equals(other.getSpaceBefore())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getHAndJ() != null) {
            _hashCode += getHAndJ().hashCode();
        }
        if (getAlignment() != null) {
            _hashCode += getAlignment().hashCode();
        }
        if (getCharacterAlignment() != null) {
            _hashCode += getCharacterAlignment().hashCode();
        }
        if (getDropCap() != null) {
            _hashCode += getDropCap().hashCode();
        }
        if (getFirstLine() != null) {
            _hashCode += getFirstLine().hashCode();
        }
        if (getHangingCharacters() != null) {
            _hashCode += getHangingCharacters().hashCode();
        }
        if (getKeepLinesTogether() != null) {
            _hashCode += getKeepLinesTogether().hashCode();
        }
        if (getKeepWithNext() != null) {
            _hashCode += getKeepWithNext().hashCode();
        }
        if (getLeading() != null) {
            _hashCode += getLeading().hashCode();
        }
        if (getLeftIndent() != null) {
            _hashCode += getLeftIndent().hashCode();
        }
        if (getLockToGrid() != null) {
            _hashCode += getLockToGrid().hashCode();
        }
        if (getMojigumiSet() != null) {
            _hashCode += getMojigumiSet().hashCode();
        }
        if (getRightIndent() != null) {
            _hashCode += getRightIndent().hashCode();
        }
        if (getSpaceAfter() != null) {
            _hashCode += getSpaceAfter().hashCode();
        }
        if (getSpaceBefore() != null) {
            _hashCode += getSpaceBefore().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Format.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Format"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HAndJ");
        elemField.setXmlName(new javax.xml.namespace.QName("", "HAndJ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignment");
        elemField.setXmlName(new javax.xml.namespace.QName("", "alignment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("characterAlignment");
        elemField.setXmlName(new javax.xml.namespace.QName("", "characterAlignment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dropCap");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dropCap"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "DropCap"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstLine");
        elemField.setXmlName(new javax.xml.namespace.QName("", "firstLine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hangingCharacters");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hangingCharacters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keepLinesTogether");
        elemField.setXmlName(new javax.xml.namespace.QName("", "keepLinesTogether"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "KeepLinesTogether"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keepWithNext");
        elemField.setXmlName(new javax.xml.namespace.QName("", "keepWithNext"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leading");
        elemField.setXmlName(new javax.xml.namespace.QName("", "leading"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftIndent");
        elemField.setXmlName(new javax.xml.namespace.QName("", "leftIndent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lockToGrid");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lockToGrid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LockToGrid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mojigumiSet");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mojigumiSet"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightIndent");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rightIndent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spaceAfter");
        elemField.setXmlName(new javax.xml.namespace.QName("", "spaceAfter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spaceBefore");
        elemField.setXmlName(new javax.xml.namespace.QName("", "spaceBefore"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
