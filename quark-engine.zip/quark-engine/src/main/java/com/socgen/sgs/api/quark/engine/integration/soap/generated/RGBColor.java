/**
 * RGBColor.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class RGBColor  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String blue;

    private java.lang.String green;

    private java.lang.String red;

    public RGBColor() {
    }

    public RGBColor(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String blue,
           java.lang.String green,
           java.lang.String red) {
        super(
            request);
        this.blue = blue;
        this.green = green;
        this.red = red;
    }


    /**
     * Gets the blue value for this RGBColor.
     * 
     * @return blue
     */
    public java.lang.String getBlue() {
        return blue;
    }


    /**
     * Sets the blue value for this RGBColor.
     * 
     * @param blue
     */
    public void setBlue(java.lang.String blue) {
        this.blue = blue;
    }


    /**
     * Gets the green value for this RGBColor.
     * 
     * @return green
     */
    public java.lang.String getGreen() {
        return green;
    }


    /**
     * Sets the green value for this RGBColor.
     * 
     * @param green
     */
    public void setGreen(java.lang.String green) {
        this.green = green;
    }


    /**
     * Gets the red value for this RGBColor.
     * 
     * @return red
     */
    public java.lang.String getRed() {
        return red;
    }


    /**
     * Sets the red value for this RGBColor.
     * 
     * @param red
     */
    public void setRed(java.lang.String red) {
        this.red = red;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RGBColor)) return false;
        RGBColor other = (RGBColor) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.blue==null && other.getBlue()==null) || 
             (this.blue!=null &&
              this.blue.equals(other.getBlue()))) &&
            ((this.green==null && other.getGreen()==null) || 
             (this.green!=null &&
              this.green.equals(other.getGreen()))) &&
            ((this.red==null && other.getRed()==null) || 
             (this.red!=null &&
              this.red.equals(other.getRed())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBlue() != null) {
            _hashCode += getBlue().hashCode();
        }
        if (getGreen() != null) {
            _hashCode += getGreen().hashCode();
        }
        if (getRed() != null) {
            _hashCode += getRed().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RGBColor.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RGBColor"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blue");
        elemField.setXmlName(new javax.xml.namespace.QName("", "blue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("green");
        elemField.setXmlName(new javax.xml.namespace.QName("", "green"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("red");
        elemField.setXmlName(new javax.xml.namespace.QName("", "red"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
