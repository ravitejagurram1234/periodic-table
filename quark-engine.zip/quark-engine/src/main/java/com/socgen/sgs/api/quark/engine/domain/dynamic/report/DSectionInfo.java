package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

/**
 * Contains information specific to a DSection.
 *
 * Cross-reference: QXP.Engine.Core.DSection_Info
 */
@Getter
@Setter
public class DSectionInfo {

    /** Master page associated with this section. */
    private DMasterPage masterPage;

    public DSectionInfo() {
    }
}