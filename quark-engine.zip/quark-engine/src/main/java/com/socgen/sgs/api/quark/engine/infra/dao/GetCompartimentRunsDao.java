package com.socgen.sgs.api.quark.engine.infra.dao;

import java.time.LocalDate;
import java.util.LinkedHashMap;

/**
 * DAO interface for retrieving compartment run IDs.
 * Calls QXP_PK_RUN.Get_Compartiment_Runs Oracle function.
 *
 * Cross-reference: .NET Proxy_Run.Get_Compartiment_Runs()
 */
public interface GetCompartimentRunsDao {

    /**
     * Get compartment runs as an ordered map of fund code → run ID.
     *
     * @param idGabaritTete   the parent gabarit ID
     * @param idStructure     the fund code (structure identifier)
     * @param idGabaritFils   the child gabarit ID
     * @param idTypeRapport   the report type (4 = compartiment)
     * @param idLangue        the language ID
     * @param dateEcheance    the due date
     * @param toGenerate      true if runs should be generated, false if retrieving previous
     * @return ordered map of fund code → run ID (0 or null if no run exists)
     */
    LinkedHashMap<String, Integer> getCompartimentRuns(int idGabaritTete, String idStructure,
                                                       int idGabaritFils, int idTypeRapport,
                                                       int idLangue, LocalDate dateEcheance,
                                                       boolean toGenerate);
}