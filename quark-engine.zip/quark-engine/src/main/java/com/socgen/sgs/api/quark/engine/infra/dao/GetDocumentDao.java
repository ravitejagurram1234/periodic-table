package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;

import java.time.LocalDate;

/**
 * DAO for loading a reference document (image/PDF/RTF/DOC/XTG/QXP) to be inserted into a template.
 * Cross-reference: .NET QXPS_File_Manager.Get_Document → Oracle QXP_PK_RUN.Get_Document (6-arg).
 */
public interface GetDocumentDao {

    /**
     * Load a reference document by sous-categorie + fund/part/company context for the run's
     * language and echeance date.
     *
     * @return the document (id/name/format/data, prefix "D"), or null if none found
     */
    DocumentDomain getDocument(int idSousCategorie, String idFndCode, String idUnitCode,
                               String societe, int idLangue, LocalDate dateEcheance);
}