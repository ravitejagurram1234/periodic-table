/**
 * PageSequence.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class PageSequence  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String forcePageCount;

    private java.lang.String masterReference;

    private java.lang.String name;

    private java.lang.String orientation;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.SectionNumberFormat sectionNumberFormat;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.StaticContent staticContent;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Story story;

    public PageSequence() {
    }

    public PageSequence(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String forcePageCount,
           java.lang.String masterReference,
           java.lang.String name,
           java.lang.String orientation,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.SectionNumberFormat sectionNumberFormat,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.StaticContent staticContent,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Story story) {
        super(
            request);
        this.forcePageCount = forcePageCount;
        this.masterReference = masterReference;
        this.name = name;
        this.orientation = orientation;
        this.sectionNumberFormat = sectionNumberFormat;
        this.staticContent = staticContent;
        this.story = story;
    }


    /**
     * Gets the forcePageCount value for this PageSequence.
     * 
     * @return forcePageCount
     */
    public java.lang.String getForcePageCount() {
        return forcePageCount;
    }


    /**
     * Sets the forcePageCount value for this PageSequence.
     * 
     * @param forcePageCount
     */
    public void setForcePageCount(java.lang.String forcePageCount) {
        this.forcePageCount = forcePageCount;
    }


    /**
     * Gets the masterReference value for this PageSequence.
     * 
     * @return masterReference
     */
    public java.lang.String getMasterReference() {
        return masterReference;
    }


    /**
     * Sets the masterReference value for this PageSequence.
     * 
     * @param masterReference
     */
    public void setMasterReference(java.lang.String masterReference) {
        this.masterReference = masterReference;
    }


    /**
     * Gets the name value for this PageSequence.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this PageSequence.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the orientation value for this PageSequence.
     * 
     * @return orientation
     */
    public java.lang.String getOrientation() {
        return orientation;
    }


    /**
     * Sets the orientation value for this PageSequence.
     * 
     * @param orientation
     */
    public void setOrientation(java.lang.String orientation) {
        this.orientation = orientation;
    }


    /**
     * Gets the sectionNumberFormat value for this PageSequence.
     * 
     * @return sectionNumberFormat
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SectionNumberFormat getSectionNumberFormat() {
        return sectionNumberFormat;
    }


    /**
     * Sets the sectionNumberFormat value for this PageSequence.
     * 
     * @param sectionNumberFormat
     */
    public void setSectionNumberFormat(com.socgen.sgs.api.quark.engine.integration.soap.generated.SectionNumberFormat sectionNumberFormat) {
        this.sectionNumberFormat = sectionNumberFormat;
    }


    /**
     * Gets the staticContent value for this PageSequence.
     * 
     * @return staticContent
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.StaticContent getStaticContent() {
        return staticContent;
    }


    /**
     * Sets the staticContent value for this PageSequence.
     * 
     * @param staticContent
     */
    public void setStaticContent(com.socgen.sgs.api.quark.engine.integration.soap.generated.StaticContent staticContent) {
        this.staticContent = staticContent;
    }


    /**
     * Gets the story value for this PageSequence.
     * 
     * @return story
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Story getStory() {
        return story;
    }


    /**
     * Sets the story value for this PageSequence.
     * 
     * @param story
     */
    public void setStory(com.socgen.sgs.api.quark.engine.integration.soap.generated.Story story) {
        this.story = story;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PageSequence)) return false;
        PageSequence other = (PageSequence) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.forcePageCount==null && other.getForcePageCount()==null) || 
             (this.forcePageCount!=null &&
              this.forcePageCount.equals(other.getForcePageCount()))) &&
            ((this.masterReference==null && other.getMasterReference()==null) || 
             (this.masterReference!=null &&
              this.masterReference.equals(other.getMasterReference()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.orientation==null && other.getOrientation()==null) || 
             (this.orientation!=null &&
              this.orientation.equals(other.getOrientation()))) &&
            ((this.sectionNumberFormat==null && other.getSectionNumberFormat()==null) || 
             (this.sectionNumberFormat!=null &&
              this.sectionNumberFormat.equals(other.getSectionNumberFormat()))) &&
            ((this.staticContent==null && other.getStaticContent()==null) || 
             (this.staticContent!=null &&
              this.staticContent.equals(other.getStaticContent()))) &&
            ((this.story==null && other.getStory()==null) || 
             (this.story!=null &&
              this.story.equals(other.getStory())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getForcePageCount() != null) {
            _hashCode += getForcePageCount().hashCode();
        }
        if (getMasterReference() != null) {
            _hashCode += getMasterReference().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOrientation() != null) {
            _hashCode += getOrientation().hashCode();
        }
        if (getSectionNumberFormat() != null) {
            _hashCode += getSectionNumberFormat().hashCode();
        }
        if (getStaticContent() != null) {
            _hashCode += getStaticContent().hashCode();
        }
        if (getStory() != null) {
            _hashCode += getStory().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PageSequence.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageSequence"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("forcePageCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "forcePageCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("masterReference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "masterReference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orientation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "orientation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sectionNumberFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "sectionNumberFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "SectionNumberFormat"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("staticContent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "staticContent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "StaticContent"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("story");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "story"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Story"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
