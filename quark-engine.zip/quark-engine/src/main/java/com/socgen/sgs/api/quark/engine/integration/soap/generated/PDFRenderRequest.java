/**
 * PDFRenderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class PDFRenderRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String addLayer;

    private java.lang.String afterPage;

    private java.lang.String allLayers;

    private java.lang.String author;

    private java.lang.String bleed;

    private java.lang.String colorCompression;

    private java.lang.String colorImageDownSample;

    private java.lang.String createTaggedPdf;

    private java.lang.String deleteLayer;

    private java.lang.String exportIndexesAsHyperlinks;

    private java.lang.String exportListsAsBookmarks;

    private java.lang.String exportListsAsHyperlinks;

    private java.lang.String fontDownloadOption;

    private java.lang.String grayscaleCompression;

    private java.lang.String grayscaleImageDownSample;

    private java.lang.String images;

    private java.lang.String includeHyperlinks;

    private java.lang.String keywords;

    private java.lang.String layerEnd;

    private java.lang.String layerStart;

    private java.lang.String layers;

    private java.lang.String layout;

    private java.lang.String layoutEnd;

    private java.lang.String layoutStart;

    private java.lang.String lowResolution;

    private java.lang.String mode;

    private java.lang.String monochromeCompression;

    private java.lang.String monochromeImagedownSample;

    private java.lang.String movePages;

    private java.lang.String offset;

    private java.lang.String offsetBleed;

    private java.lang.String outputStyle;

    private java.lang.String PDFPage;

    private java.lang.String page;

    private java.lang.String pages;

    private java.lang.String pasteboard;

    private java.lang.String plates;

    private java.lang.String postScriptFile;

    private java.lang.String printColors;

    private java.lang.String produceBlankPages;

    private java.lang.String produceBlankPlatesOption;

    private java.lang.String reducePdfSize;

    private java.lang.String registration;

    private java.lang.String separate;

    private java.lang.String spread;

    private java.lang.String spreads;

    private java.lang.String subject;

    private java.lang.String thumbnail;

    private java.lang.String title;

    private java.lang.String transparencyFlatteningResolution;

    private java.lang.String updateFullRes;

    private java.lang.String updateImage;

    private java.lang.String useOPI;

    private java.lang.String verification;

    public PDFRenderRequest() {
    }

    public PDFRenderRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String addLayer,
           java.lang.String afterPage,
           java.lang.String allLayers,
           java.lang.String author,
           java.lang.String bleed,
           java.lang.String colorCompression,
           java.lang.String colorImageDownSample,
           java.lang.String createTaggedPdf,
           java.lang.String deleteLayer,
           java.lang.String exportIndexesAsHyperlinks,
           java.lang.String exportListsAsBookmarks,
           java.lang.String exportListsAsHyperlinks,
           java.lang.String fontDownloadOption,
           java.lang.String grayscaleCompression,
           java.lang.String grayscaleImageDownSample,
           java.lang.String images,
           java.lang.String includeHyperlinks,
           java.lang.String keywords,
           java.lang.String layerEnd,
           java.lang.String layerStart,
           java.lang.String layers,
           java.lang.String layout,
           java.lang.String layoutEnd,
           java.lang.String layoutStart,
           java.lang.String lowResolution,
           java.lang.String mode,
           java.lang.String monochromeCompression,
           java.lang.String monochromeImagedownSample,
           java.lang.String movePages,
           java.lang.String offset,
           java.lang.String offsetBleed,
           java.lang.String outputStyle,
           java.lang.String PDFPage,
           java.lang.String page,
           java.lang.String pages,
           java.lang.String pasteboard,
           java.lang.String plates,
           java.lang.String postScriptFile,
           java.lang.String printColors,
           java.lang.String produceBlankPages,
           java.lang.String produceBlankPlatesOption,
           java.lang.String reducePdfSize,
           java.lang.String registration,
           java.lang.String separate,
           java.lang.String spread,
           java.lang.String spreads,
           java.lang.String subject,
           java.lang.String thumbnail,
           java.lang.String title,
           java.lang.String transparencyFlatteningResolution,
           java.lang.String updateFullRes,
           java.lang.String updateImage,
           java.lang.String useOPI,
           java.lang.String verification) {
        super(
            request);
        this.addLayer = addLayer;
        this.afterPage = afterPage;
        this.allLayers = allLayers;
        this.author = author;
        this.bleed = bleed;
        this.colorCompression = colorCompression;
        this.colorImageDownSample = colorImageDownSample;
        this.createTaggedPdf = createTaggedPdf;
        this.deleteLayer = deleteLayer;
        this.exportIndexesAsHyperlinks = exportIndexesAsHyperlinks;
        this.exportListsAsBookmarks = exportListsAsBookmarks;
        this.exportListsAsHyperlinks = exportListsAsHyperlinks;
        this.fontDownloadOption = fontDownloadOption;
        this.grayscaleCompression = grayscaleCompression;
        this.grayscaleImageDownSample = grayscaleImageDownSample;
        this.images = images;
        this.includeHyperlinks = includeHyperlinks;
        this.keywords = keywords;
        this.layerEnd = layerEnd;
        this.layerStart = layerStart;
        this.layers = layers;
        this.layout = layout;
        this.layoutEnd = layoutEnd;
        this.layoutStart = layoutStart;
        this.lowResolution = lowResolution;
        this.mode = mode;
        this.monochromeCompression = monochromeCompression;
        this.monochromeImagedownSample = monochromeImagedownSample;
        this.movePages = movePages;
        this.offset = offset;
        this.offsetBleed = offsetBleed;
        this.outputStyle = outputStyle;
        this.PDFPage = PDFPage;
        this.page = page;
        this.pages = pages;
        this.pasteboard = pasteboard;
        this.plates = plates;
        this.postScriptFile = postScriptFile;
        this.printColors = printColors;
        this.produceBlankPages = produceBlankPages;
        this.produceBlankPlatesOption = produceBlankPlatesOption;
        this.reducePdfSize = reducePdfSize;
        this.registration = registration;
        this.separate = separate;
        this.spread = spread;
        this.spreads = spreads;
        this.subject = subject;
        this.thumbnail = thumbnail;
        this.title = title;
        this.transparencyFlatteningResolution = transparencyFlatteningResolution;
        this.updateFullRes = updateFullRes;
        this.updateImage = updateImage;
        this.useOPI = useOPI;
        this.verification = verification;
    }


    /**
     * Gets the addLayer value for this PDFRenderRequest.
     * 
     * @return addLayer
     */
    public java.lang.String getAddLayer() {
        return addLayer;
    }


    /**
     * Sets the addLayer value for this PDFRenderRequest.
     * 
     * @param addLayer
     */
    public void setAddLayer(java.lang.String addLayer) {
        this.addLayer = addLayer;
    }


    /**
     * Gets the afterPage value for this PDFRenderRequest.
     * 
     * @return afterPage
     */
    public java.lang.String getAfterPage() {
        return afterPage;
    }


    /**
     * Sets the afterPage value for this PDFRenderRequest.
     * 
     * @param afterPage
     */
    public void setAfterPage(java.lang.String afterPage) {
        this.afterPage = afterPage;
    }


    /**
     * Gets the allLayers value for this PDFRenderRequest.
     * 
     * @return allLayers
     */
    public java.lang.String getAllLayers() {
        return allLayers;
    }


    /**
     * Sets the allLayers value for this PDFRenderRequest.
     * 
     * @param allLayers
     */
    public void setAllLayers(java.lang.String allLayers) {
        this.allLayers = allLayers;
    }


    /**
     * Gets the author value for this PDFRenderRequest.
     * 
     * @return author
     */
    public java.lang.String getAuthor() {
        return author;
    }


    /**
     * Sets the author value for this PDFRenderRequest.
     * 
     * @param author
     */
    public void setAuthor(java.lang.String author) {
        this.author = author;
    }


    /**
     * Gets the bleed value for this PDFRenderRequest.
     * 
     * @return bleed
     */
    public java.lang.String getBleed() {
        return bleed;
    }


    /**
     * Sets the bleed value for this PDFRenderRequest.
     * 
     * @param bleed
     */
    public void setBleed(java.lang.String bleed) {
        this.bleed = bleed;
    }


    /**
     * Gets the colorCompression value for this PDFRenderRequest.
     * 
     * @return colorCompression
     */
    public java.lang.String getColorCompression() {
        return colorCompression;
    }


    /**
     * Sets the colorCompression value for this PDFRenderRequest.
     * 
     * @param colorCompression
     */
    public void setColorCompression(java.lang.String colorCompression) {
        this.colorCompression = colorCompression;
    }


    /**
     * Gets the colorImageDownSample value for this PDFRenderRequest.
     * 
     * @return colorImageDownSample
     */
    public java.lang.String getColorImageDownSample() {
        return colorImageDownSample;
    }


    /**
     * Sets the colorImageDownSample value for this PDFRenderRequest.
     * 
     * @param colorImageDownSample
     */
    public void setColorImageDownSample(java.lang.String colorImageDownSample) {
        this.colorImageDownSample = colorImageDownSample;
    }


    /**
     * Gets the createTaggedPdf value for this PDFRenderRequest.
     * 
     * @return createTaggedPdf
     */
    public java.lang.String getCreateTaggedPdf() {
        return createTaggedPdf;
    }


    /**
     * Sets the createTaggedPdf value for this PDFRenderRequest.
     * 
     * @param createTaggedPdf
     */
    public void setCreateTaggedPdf(java.lang.String createTaggedPdf) {
        this.createTaggedPdf = createTaggedPdf;
    }


    /**
     * Gets the deleteLayer value for this PDFRenderRequest.
     * 
     * @return deleteLayer
     */
    public java.lang.String getDeleteLayer() {
        return deleteLayer;
    }


    /**
     * Sets the deleteLayer value for this PDFRenderRequest.
     * 
     * @param deleteLayer
     */
    public void setDeleteLayer(java.lang.String deleteLayer) {
        this.deleteLayer = deleteLayer;
    }


    /**
     * Gets the exportIndexesAsHyperlinks value for this PDFRenderRequest.
     * 
     * @return exportIndexesAsHyperlinks
     */
    public java.lang.String getExportIndexesAsHyperlinks() {
        return exportIndexesAsHyperlinks;
    }


    /**
     * Sets the exportIndexesAsHyperlinks value for this PDFRenderRequest.
     * 
     * @param exportIndexesAsHyperlinks
     */
    public void setExportIndexesAsHyperlinks(java.lang.String exportIndexesAsHyperlinks) {
        this.exportIndexesAsHyperlinks = exportIndexesAsHyperlinks;
    }


    /**
     * Gets the exportListsAsBookmarks value for this PDFRenderRequest.
     * 
     * @return exportListsAsBookmarks
     */
    public java.lang.String getExportListsAsBookmarks() {
        return exportListsAsBookmarks;
    }


    /**
     * Sets the exportListsAsBookmarks value for this PDFRenderRequest.
     * 
     * @param exportListsAsBookmarks
     */
    public void setExportListsAsBookmarks(java.lang.String exportListsAsBookmarks) {
        this.exportListsAsBookmarks = exportListsAsBookmarks;
    }


    /**
     * Gets the exportListsAsHyperlinks value for this PDFRenderRequest.
     * 
     * @return exportListsAsHyperlinks
     */
    public java.lang.String getExportListsAsHyperlinks() {
        return exportListsAsHyperlinks;
    }


    /**
     * Sets the exportListsAsHyperlinks value for this PDFRenderRequest.
     * 
     * @param exportListsAsHyperlinks
     */
    public void setExportListsAsHyperlinks(java.lang.String exportListsAsHyperlinks) {
        this.exportListsAsHyperlinks = exportListsAsHyperlinks;
    }


    /**
     * Gets the fontDownloadOption value for this PDFRenderRequest.
     * 
     * @return fontDownloadOption
     */
    public java.lang.String getFontDownloadOption() {
        return fontDownloadOption;
    }


    /**
     * Sets the fontDownloadOption value for this PDFRenderRequest.
     * 
     * @param fontDownloadOption
     */
    public void setFontDownloadOption(java.lang.String fontDownloadOption) {
        this.fontDownloadOption = fontDownloadOption;
    }


    /**
     * Gets the grayscaleCompression value for this PDFRenderRequest.
     * 
     * @return grayscaleCompression
     */
    public java.lang.String getGrayscaleCompression() {
        return grayscaleCompression;
    }


    /**
     * Sets the grayscaleCompression value for this PDFRenderRequest.
     * 
     * @param grayscaleCompression
     */
    public void setGrayscaleCompression(java.lang.String grayscaleCompression) {
        this.grayscaleCompression = grayscaleCompression;
    }


    /**
     * Gets the grayscaleImageDownSample value for this PDFRenderRequest.
     * 
     * @return grayscaleImageDownSample
     */
    public java.lang.String getGrayscaleImageDownSample() {
        return grayscaleImageDownSample;
    }


    /**
     * Sets the grayscaleImageDownSample value for this PDFRenderRequest.
     * 
     * @param grayscaleImageDownSample
     */
    public void setGrayscaleImageDownSample(java.lang.String grayscaleImageDownSample) {
        this.grayscaleImageDownSample = grayscaleImageDownSample;
    }


    /**
     * Gets the images value for this PDFRenderRequest.
     * 
     * @return images
     */
    public java.lang.String getImages() {
        return images;
    }


    /**
     * Sets the images value for this PDFRenderRequest.
     * 
     * @param images
     */
    public void setImages(java.lang.String images) {
        this.images = images;
    }


    /**
     * Gets the includeHyperlinks value for this PDFRenderRequest.
     * 
     * @return includeHyperlinks
     */
    public java.lang.String getIncludeHyperlinks() {
        return includeHyperlinks;
    }


    /**
     * Sets the includeHyperlinks value for this PDFRenderRequest.
     * 
     * @param includeHyperlinks
     */
    public void setIncludeHyperlinks(java.lang.String includeHyperlinks) {
        this.includeHyperlinks = includeHyperlinks;
    }


    /**
     * Gets the keywords value for this PDFRenderRequest.
     * 
     * @return keywords
     */
    public java.lang.String getKeywords() {
        return keywords;
    }


    /**
     * Sets the keywords value for this PDFRenderRequest.
     * 
     * @param keywords
     */
    public void setKeywords(java.lang.String keywords) {
        this.keywords = keywords;
    }


    /**
     * Gets the layerEnd value for this PDFRenderRequest.
     * 
     * @return layerEnd
     */
    public java.lang.String getLayerEnd() {
        return layerEnd;
    }


    /**
     * Sets the layerEnd value for this PDFRenderRequest.
     * 
     * @param layerEnd
     */
    public void setLayerEnd(java.lang.String layerEnd) {
        this.layerEnd = layerEnd;
    }


    /**
     * Gets the layerStart value for this PDFRenderRequest.
     * 
     * @return layerStart
     */
    public java.lang.String getLayerStart() {
        return layerStart;
    }


    /**
     * Sets the layerStart value for this PDFRenderRequest.
     * 
     * @param layerStart
     */
    public void setLayerStart(java.lang.String layerStart) {
        this.layerStart = layerStart;
    }


    /**
     * Gets the layers value for this PDFRenderRequest.
     * 
     * @return layers
     */
    public java.lang.String getLayers() {
        return layers;
    }


    /**
     * Sets the layers value for this PDFRenderRequest.
     * 
     * @param layers
     */
    public void setLayers(java.lang.String layers) {
        this.layers = layers;
    }


    /**
     * Gets the layout value for this PDFRenderRequest.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this PDFRenderRequest.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the layoutEnd value for this PDFRenderRequest.
     * 
     * @return layoutEnd
     */
    public java.lang.String getLayoutEnd() {
        return layoutEnd;
    }


    /**
     * Sets the layoutEnd value for this PDFRenderRequest.
     * 
     * @param layoutEnd
     */
    public void setLayoutEnd(java.lang.String layoutEnd) {
        this.layoutEnd = layoutEnd;
    }


    /**
     * Gets the layoutStart value for this PDFRenderRequest.
     * 
     * @return layoutStart
     */
    public java.lang.String getLayoutStart() {
        return layoutStart;
    }


    /**
     * Sets the layoutStart value for this PDFRenderRequest.
     * 
     * @param layoutStart
     */
    public void setLayoutStart(java.lang.String layoutStart) {
        this.layoutStart = layoutStart;
    }


    /**
     * Gets the lowResolution value for this PDFRenderRequest.
     * 
     * @return lowResolution
     */
    public java.lang.String getLowResolution() {
        return lowResolution;
    }


    /**
     * Sets the lowResolution value for this PDFRenderRequest.
     * 
     * @param lowResolution
     */
    public void setLowResolution(java.lang.String lowResolution) {
        this.lowResolution = lowResolution;
    }


    /**
     * Gets the mode value for this PDFRenderRequest.
     * 
     * @return mode
     */
    public java.lang.String getMode() {
        return mode;
    }


    /**
     * Sets the mode value for this PDFRenderRequest.
     * 
     * @param mode
     */
    public void setMode(java.lang.String mode) {
        this.mode = mode;
    }


    /**
     * Gets the monochromeCompression value for this PDFRenderRequest.
     * 
     * @return monochromeCompression
     */
    public java.lang.String getMonochromeCompression() {
        return monochromeCompression;
    }


    /**
     * Sets the monochromeCompression value for this PDFRenderRequest.
     * 
     * @param monochromeCompression
     */
    public void setMonochromeCompression(java.lang.String monochromeCompression) {
        this.monochromeCompression = monochromeCompression;
    }


    /**
     * Gets the monochromeImagedownSample value for this PDFRenderRequest.
     * 
     * @return monochromeImagedownSample
     */
    public java.lang.String getMonochromeImagedownSample() {
        return monochromeImagedownSample;
    }


    /**
     * Sets the monochromeImagedownSample value for this PDFRenderRequest.
     * 
     * @param monochromeImagedownSample
     */
    public void setMonochromeImagedownSample(java.lang.String monochromeImagedownSample) {
        this.monochromeImagedownSample = monochromeImagedownSample;
    }


    /**
     * Gets the movePages value for this PDFRenderRequest.
     * 
     * @return movePages
     */
    public java.lang.String getMovePages() {
        return movePages;
    }


    /**
     * Sets the movePages value for this PDFRenderRequest.
     * 
     * @param movePages
     */
    public void setMovePages(java.lang.String movePages) {
        this.movePages = movePages;
    }


    /**
     * Gets the offset value for this PDFRenderRequest.
     * 
     * @return offset
     */
    public java.lang.String getOffset() {
        return offset;
    }


    /**
     * Sets the offset value for this PDFRenderRequest.
     * 
     * @param offset
     */
    public void setOffset(java.lang.String offset) {
        this.offset = offset;
    }


    /**
     * Gets the offsetBleed value for this PDFRenderRequest.
     * 
     * @return offsetBleed
     */
    public java.lang.String getOffsetBleed() {
        return offsetBleed;
    }


    /**
     * Sets the offsetBleed value for this PDFRenderRequest.
     * 
     * @param offsetBleed
     */
    public void setOffsetBleed(java.lang.String offsetBleed) {
        this.offsetBleed = offsetBleed;
    }


    /**
     * Gets the outputStyle value for this PDFRenderRequest.
     * 
     * @return outputStyle
     */
    public java.lang.String getOutputStyle() {
        return outputStyle;
    }


    /**
     * Sets the outputStyle value for this PDFRenderRequest.
     * 
     * @param outputStyle
     */
    public void setOutputStyle(java.lang.String outputStyle) {
        this.outputStyle = outputStyle;
    }


    /**
     * Gets the PDFPage value for this PDFRenderRequest.
     * 
     * @return PDFPage
     */
    public java.lang.String getPDFPage() {
        return PDFPage;
    }


    /**
     * Sets the PDFPage value for this PDFRenderRequest.
     * 
     * @param PDFPage
     */
    public void setPDFPage(java.lang.String PDFPage) {
        this.PDFPage = PDFPage;
    }


    /**
     * Gets the page value for this PDFRenderRequest.
     * 
     * @return page
     */
    public java.lang.String getPage() {
        return page;
    }


    /**
     * Sets the page value for this PDFRenderRequest.
     * 
     * @param page
     */
    public void setPage(java.lang.String page) {
        this.page = page;
    }


    /**
     * Gets the pages value for this PDFRenderRequest.
     * 
     * @return pages
     */
    public java.lang.String getPages() {
        return pages;
    }


    /**
     * Sets the pages value for this PDFRenderRequest.
     * 
     * @param pages
     */
    public void setPages(java.lang.String pages) {
        this.pages = pages;
    }


    /**
     * Gets the pasteboard value for this PDFRenderRequest.
     * 
     * @return pasteboard
     */
    public java.lang.String getPasteboard() {
        return pasteboard;
    }


    /**
     * Sets the pasteboard value for this PDFRenderRequest.
     * 
     * @param pasteboard
     */
    public void setPasteboard(java.lang.String pasteboard) {
        this.pasteboard = pasteboard;
    }


    /**
     * Gets the plates value for this PDFRenderRequest.
     * 
     * @return plates
     */
    public java.lang.String getPlates() {
        return plates;
    }


    /**
     * Sets the plates value for this PDFRenderRequest.
     * 
     * @param plates
     */
    public void setPlates(java.lang.String plates) {
        this.plates = plates;
    }


    /**
     * Gets the postScriptFile value for this PDFRenderRequest.
     * 
     * @return postScriptFile
     */
    public java.lang.String getPostScriptFile() {
        return postScriptFile;
    }


    /**
     * Sets the postScriptFile value for this PDFRenderRequest.
     * 
     * @param postScriptFile
     */
    public void setPostScriptFile(java.lang.String postScriptFile) {
        this.postScriptFile = postScriptFile;
    }


    /**
     * Gets the printColors value for this PDFRenderRequest.
     * 
     * @return printColors
     */
    public java.lang.String getPrintColors() {
        return printColors;
    }


    /**
     * Sets the printColors value for this PDFRenderRequest.
     * 
     * @param printColors
     */
    public void setPrintColors(java.lang.String printColors) {
        this.printColors = printColors;
    }


    /**
     * Gets the produceBlankPages value for this PDFRenderRequest.
     * 
     * @return produceBlankPages
     */
    public java.lang.String getProduceBlankPages() {
        return produceBlankPages;
    }


    /**
     * Sets the produceBlankPages value for this PDFRenderRequest.
     * 
     * @param produceBlankPages
     */
    public void setProduceBlankPages(java.lang.String produceBlankPages) {
        this.produceBlankPages = produceBlankPages;
    }


    /**
     * Gets the produceBlankPlatesOption value for this PDFRenderRequest.
     * 
     * @return produceBlankPlatesOption
     */
    public java.lang.String getProduceBlankPlatesOption() {
        return produceBlankPlatesOption;
    }


    /**
     * Sets the produceBlankPlatesOption value for this PDFRenderRequest.
     * 
     * @param produceBlankPlatesOption
     */
    public void setProduceBlankPlatesOption(java.lang.String produceBlankPlatesOption) {
        this.produceBlankPlatesOption = produceBlankPlatesOption;
    }


    /**
     * Gets the reducePdfSize value for this PDFRenderRequest.
     * 
     * @return reducePdfSize
     */
    public java.lang.String getReducePdfSize() {
        return reducePdfSize;
    }


    /**
     * Sets the reducePdfSize value for this PDFRenderRequest.
     * 
     * @param reducePdfSize
     */
    public void setReducePdfSize(java.lang.String reducePdfSize) {
        this.reducePdfSize = reducePdfSize;
    }


    /**
     * Gets the registration value for this PDFRenderRequest.
     * 
     * @return registration
     */
    public java.lang.String getRegistration() {
        return registration;
    }


    /**
     * Sets the registration value for this PDFRenderRequest.
     * 
     * @param registration
     */
    public void setRegistration(java.lang.String registration) {
        this.registration = registration;
    }


    /**
     * Gets the separate value for this PDFRenderRequest.
     * 
     * @return separate
     */
    public java.lang.String getSeparate() {
        return separate;
    }


    /**
     * Sets the separate value for this PDFRenderRequest.
     * 
     * @param separate
     */
    public void setSeparate(java.lang.String separate) {
        this.separate = separate;
    }


    /**
     * Gets the spread value for this PDFRenderRequest.
     * 
     * @return spread
     */
    public java.lang.String getSpread() {
        return spread;
    }


    /**
     * Sets the spread value for this PDFRenderRequest.
     * 
     * @param spread
     */
    public void setSpread(java.lang.String spread) {
        this.spread = spread;
    }


    /**
     * Gets the spreads value for this PDFRenderRequest.
     * 
     * @return spreads
     */
    public java.lang.String getSpreads() {
        return spreads;
    }


    /**
     * Sets the spreads value for this PDFRenderRequest.
     * 
     * @param spreads
     */
    public void setSpreads(java.lang.String spreads) {
        this.spreads = spreads;
    }


    /**
     * Gets the subject value for this PDFRenderRequest.
     * 
     * @return subject
     */
    public java.lang.String getSubject() {
        return subject;
    }


    /**
     * Sets the subject value for this PDFRenderRequest.
     * 
     * @param subject
     */
    public void setSubject(java.lang.String subject) {
        this.subject = subject;
    }


    /**
     * Gets the thumbnail value for this PDFRenderRequest.
     * 
     * @return thumbnail
     */
    public java.lang.String getThumbnail() {
        return thumbnail;
    }


    /**
     * Sets the thumbnail value for this PDFRenderRequest.
     * 
     * @param thumbnail
     */
    public void setThumbnail(java.lang.String thumbnail) {
        this.thumbnail = thumbnail;
    }


    /**
     * Gets the title value for this PDFRenderRequest.
     * 
     * @return title
     */
    public java.lang.String getTitle() {
        return title;
    }


    /**
     * Sets the title value for this PDFRenderRequest.
     * 
     * @param title
     */
    public void setTitle(java.lang.String title) {
        this.title = title;
    }


    /**
     * Gets the transparencyFlatteningResolution value for this PDFRenderRequest.
     * 
     * @return transparencyFlatteningResolution
     */
    public java.lang.String getTransparencyFlatteningResolution() {
        return transparencyFlatteningResolution;
    }


    /**
     * Sets the transparencyFlatteningResolution value for this PDFRenderRequest.
     * 
     * @param transparencyFlatteningResolution
     */
    public void setTransparencyFlatteningResolution(java.lang.String transparencyFlatteningResolution) {
        this.transparencyFlatteningResolution = transparencyFlatteningResolution;
    }


    /**
     * Gets the updateFullRes value for this PDFRenderRequest.
     * 
     * @return updateFullRes
     */
    public java.lang.String getUpdateFullRes() {
        return updateFullRes;
    }


    /**
     * Sets the updateFullRes value for this PDFRenderRequest.
     * 
     * @param updateFullRes
     */
    public void setUpdateFullRes(java.lang.String updateFullRes) {
        this.updateFullRes = updateFullRes;
    }


    /**
     * Gets the updateImage value for this PDFRenderRequest.
     * 
     * @return updateImage
     */
    public java.lang.String getUpdateImage() {
        return updateImage;
    }


    /**
     * Sets the updateImage value for this PDFRenderRequest.
     * 
     * @param updateImage
     */
    public void setUpdateImage(java.lang.String updateImage) {
        this.updateImage = updateImage;
    }


    /**
     * Gets the useOPI value for this PDFRenderRequest.
     * 
     * @return useOPI
     */
    public java.lang.String getUseOPI() {
        return useOPI;
    }


    /**
     * Sets the useOPI value for this PDFRenderRequest.
     * 
     * @param useOPI
     */
    public void setUseOPI(java.lang.String useOPI) {
        this.useOPI = useOPI;
    }


    /**
     * Gets the verification value for this PDFRenderRequest.
     * 
     * @return verification
     */
    public java.lang.String getVerification() {
        return verification;
    }


    /**
     * Sets the verification value for this PDFRenderRequest.
     * 
     * @param verification
     */
    public void setVerification(java.lang.String verification) {
        this.verification = verification;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PDFRenderRequest)) return false;
        PDFRenderRequest other = (PDFRenderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.addLayer==null && other.getAddLayer()==null) || 
             (this.addLayer!=null &&
              this.addLayer.equals(other.getAddLayer()))) &&
            ((this.afterPage==null && other.getAfterPage()==null) || 
             (this.afterPage!=null &&
              this.afterPage.equals(other.getAfterPage()))) &&
            ((this.allLayers==null && other.getAllLayers()==null) || 
             (this.allLayers!=null &&
              this.allLayers.equals(other.getAllLayers()))) &&
            ((this.author==null && other.getAuthor()==null) || 
             (this.author!=null &&
              this.author.equals(other.getAuthor()))) &&
            ((this.bleed==null && other.getBleed()==null) || 
             (this.bleed!=null &&
              this.bleed.equals(other.getBleed()))) &&
            ((this.colorCompression==null && other.getColorCompression()==null) || 
             (this.colorCompression!=null &&
              this.colorCompression.equals(other.getColorCompression()))) &&
            ((this.colorImageDownSample==null && other.getColorImageDownSample()==null) || 
             (this.colorImageDownSample!=null &&
              this.colorImageDownSample.equals(other.getColorImageDownSample()))) &&
            ((this.createTaggedPdf==null && other.getCreateTaggedPdf()==null) || 
             (this.createTaggedPdf!=null &&
              this.createTaggedPdf.equals(other.getCreateTaggedPdf()))) &&
            ((this.deleteLayer==null && other.getDeleteLayer()==null) || 
             (this.deleteLayer!=null &&
              this.deleteLayer.equals(other.getDeleteLayer()))) &&
            ((this.exportIndexesAsHyperlinks==null && other.getExportIndexesAsHyperlinks()==null) || 
             (this.exportIndexesAsHyperlinks!=null &&
              this.exportIndexesAsHyperlinks.equals(other.getExportIndexesAsHyperlinks()))) &&
            ((this.exportListsAsBookmarks==null && other.getExportListsAsBookmarks()==null) || 
             (this.exportListsAsBookmarks!=null &&
              this.exportListsAsBookmarks.equals(other.getExportListsAsBookmarks()))) &&
            ((this.exportListsAsHyperlinks==null && other.getExportListsAsHyperlinks()==null) || 
             (this.exportListsAsHyperlinks!=null &&
              this.exportListsAsHyperlinks.equals(other.getExportListsAsHyperlinks()))) &&
            ((this.fontDownloadOption==null && other.getFontDownloadOption()==null) || 
             (this.fontDownloadOption!=null &&
              this.fontDownloadOption.equals(other.getFontDownloadOption()))) &&
            ((this.grayscaleCompression==null && other.getGrayscaleCompression()==null) || 
             (this.grayscaleCompression!=null &&
              this.grayscaleCompression.equals(other.getGrayscaleCompression()))) &&
            ((this.grayscaleImageDownSample==null && other.getGrayscaleImageDownSample()==null) || 
             (this.grayscaleImageDownSample!=null &&
              this.grayscaleImageDownSample.equals(other.getGrayscaleImageDownSample()))) &&
            ((this.images==null && other.getImages()==null) || 
             (this.images!=null &&
              this.images.equals(other.getImages()))) &&
            ((this.includeHyperlinks==null && other.getIncludeHyperlinks()==null) || 
             (this.includeHyperlinks!=null &&
              this.includeHyperlinks.equals(other.getIncludeHyperlinks()))) &&
            ((this.keywords==null && other.getKeywords()==null) || 
             (this.keywords!=null &&
              this.keywords.equals(other.getKeywords()))) &&
            ((this.layerEnd==null && other.getLayerEnd()==null) || 
             (this.layerEnd!=null &&
              this.layerEnd.equals(other.getLayerEnd()))) &&
            ((this.layerStart==null && other.getLayerStart()==null) || 
             (this.layerStart!=null &&
              this.layerStart.equals(other.getLayerStart()))) &&
            ((this.layers==null && other.getLayers()==null) || 
             (this.layers!=null &&
              this.layers.equals(other.getLayers()))) &&
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.layoutEnd==null && other.getLayoutEnd()==null) || 
             (this.layoutEnd!=null &&
              this.layoutEnd.equals(other.getLayoutEnd()))) &&
            ((this.layoutStart==null && other.getLayoutStart()==null) || 
             (this.layoutStart!=null &&
              this.layoutStart.equals(other.getLayoutStart()))) &&
            ((this.lowResolution==null && other.getLowResolution()==null) || 
             (this.lowResolution!=null &&
              this.lowResolution.equals(other.getLowResolution()))) &&
            ((this.mode==null && other.getMode()==null) || 
             (this.mode!=null &&
              this.mode.equals(other.getMode()))) &&
            ((this.monochromeCompression==null && other.getMonochromeCompression()==null) || 
             (this.monochromeCompression!=null &&
              this.monochromeCompression.equals(other.getMonochromeCompression()))) &&
            ((this.monochromeImagedownSample==null && other.getMonochromeImagedownSample()==null) || 
             (this.monochromeImagedownSample!=null &&
              this.monochromeImagedownSample.equals(other.getMonochromeImagedownSample()))) &&
            ((this.movePages==null && other.getMovePages()==null) || 
             (this.movePages!=null &&
              this.movePages.equals(other.getMovePages()))) &&
            ((this.offset==null && other.getOffset()==null) || 
             (this.offset!=null &&
              this.offset.equals(other.getOffset()))) &&
            ((this.offsetBleed==null && other.getOffsetBleed()==null) || 
             (this.offsetBleed!=null &&
              this.offsetBleed.equals(other.getOffsetBleed()))) &&
            ((this.outputStyle==null && other.getOutputStyle()==null) || 
             (this.outputStyle!=null &&
              this.outputStyle.equals(other.getOutputStyle()))) &&
            ((this.PDFPage==null && other.getPDFPage()==null) || 
             (this.PDFPage!=null &&
              this.PDFPage.equals(other.getPDFPage()))) &&
            ((this.page==null && other.getPage()==null) || 
             (this.page!=null &&
              this.page.equals(other.getPage()))) &&
            ((this.pages==null && other.getPages()==null) || 
             (this.pages!=null &&
              this.pages.equals(other.getPages()))) &&
            ((this.pasteboard==null && other.getPasteboard()==null) || 
             (this.pasteboard!=null &&
              this.pasteboard.equals(other.getPasteboard()))) &&
            ((this.plates==null && other.getPlates()==null) || 
             (this.plates!=null &&
              this.plates.equals(other.getPlates()))) &&
            ((this.postScriptFile==null && other.getPostScriptFile()==null) || 
             (this.postScriptFile!=null &&
              this.postScriptFile.equals(other.getPostScriptFile()))) &&
            ((this.printColors==null && other.getPrintColors()==null) || 
             (this.printColors!=null &&
              this.printColors.equals(other.getPrintColors()))) &&
            ((this.produceBlankPages==null && other.getProduceBlankPages()==null) || 
             (this.produceBlankPages!=null &&
              this.produceBlankPages.equals(other.getProduceBlankPages()))) &&
            ((this.produceBlankPlatesOption==null && other.getProduceBlankPlatesOption()==null) || 
             (this.produceBlankPlatesOption!=null &&
              this.produceBlankPlatesOption.equals(other.getProduceBlankPlatesOption()))) &&
            ((this.reducePdfSize==null && other.getReducePdfSize()==null) || 
             (this.reducePdfSize!=null &&
              this.reducePdfSize.equals(other.getReducePdfSize()))) &&
            ((this.registration==null && other.getRegistration()==null) || 
             (this.registration!=null &&
              this.registration.equals(other.getRegistration()))) &&
            ((this.separate==null && other.getSeparate()==null) || 
             (this.separate!=null &&
              this.separate.equals(other.getSeparate()))) &&
            ((this.spread==null && other.getSpread()==null) || 
             (this.spread!=null &&
              this.spread.equals(other.getSpread()))) &&
            ((this.spreads==null && other.getSpreads()==null) || 
             (this.spreads!=null &&
              this.spreads.equals(other.getSpreads()))) &&
            ((this.subject==null && other.getSubject()==null) || 
             (this.subject!=null &&
              this.subject.equals(other.getSubject()))) &&
            ((this.thumbnail==null && other.getThumbnail()==null) || 
             (this.thumbnail!=null &&
              this.thumbnail.equals(other.getThumbnail()))) &&
            ((this.title==null && other.getTitle()==null) || 
             (this.title!=null &&
              this.title.equals(other.getTitle()))) &&
            ((this.transparencyFlatteningResolution==null && other.getTransparencyFlatteningResolution()==null) || 
             (this.transparencyFlatteningResolution!=null &&
              this.transparencyFlatteningResolution.equals(other.getTransparencyFlatteningResolution()))) &&
            ((this.updateFullRes==null && other.getUpdateFullRes()==null) || 
             (this.updateFullRes!=null &&
              this.updateFullRes.equals(other.getUpdateFullRes()))) &&
            ((this.updateImage==null && other.getUpdateImage()==null) || 
             (this.updateImage!=null &&
              this.updateImage.equals(other.getUpdateImage()))) &&
            ((this.useOPI==null && other.getUseOPI()==null) || 
             (this.useOPI!=null &&
              this.useOPI.equals(other.getUseOPI()))) &&
            ((this.verification==null && other.getVerification()==null) || 
             (this.verification!=null &&
              this.verification.equals(other.getVerification())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAddLayer() != null) {
            _hashCode += getAddLayer().hashCode();
        }
        if (getAfterPage() != null) {
            _hashCode += getAfterPage().hashCode();
        }
        if (getAllLayers() != null) {
            _hashCode += getAllLayers().hashCode();
        }
        if (getAuthor() != null) {
            _hashCode += getAuthor().hashCode();
        }
        if (getBleed() != null) {
            _hashCode += getBleed().hashCode();
        }
        if (getColorCompression() != null) {
            _hashCode += getColorCompression().hashCode();
        }
        if (getColorImageDownSample() != null) {
            _hashCode += getColorImageDownSample().hashCode();
        }
        if (getCreateTaggedPdf() != null) {
            _hashCode += getCreateTaggedPdf().hashCode();
        }
        if (getDeleteLayer() != null) {
            _hashCode += getDeleteLayer().hashCode();
        }
        if (getExportIndexesAsHyperlinks() != null) {
            _hashCode += getExportIndexesAsHyperlinks().hashCode();
        }
        if (getExportListsAsBookmarks() != null) {
            _hashCode += getExportListsAsBookmarks().hashCode();
        }
        if (getExportListsAsHyperlinks() != null) {
            _hashCode += getExportListsAsHyperlinks().hashCode();
        }
        if (getFontDownloadOption() != null) {
            _hashCode += getFontDownloadOption().hashCode();
        }
        if (getGrayscaleCompression() != null) {
            _hashCode += getGrayscaleCompression().hashCode();
        }
        if (getGrayscaleImageDownSample() != null) {
            _hashCode += getGrayscaleImageDownSample().hashCode();
        }
        if (getImages() != null) {
            _hashCode += getImages().hashCode();
        }
        if (getIncludeHyperlinks() != null) {
            _hashCode += getIncludeHyperlinks().hashCode();
        }
        if (getKeywords() != null) {
            _hashCode += getKeywords().hashCode();
        }
        if (getLayerEnd() != null) {
            _hashCode += getLayerEnd().hashCode();
        }
        if (getLayerStart() != null) {
            _hashCode += getLayerStart().hashCode();
        }
        if (getLayers() != null) {
            _hashCode += getLayers().hashCode();
        }
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getLayoutEnd() != null) {
            _hashCode += getLayoutEnd().hashCode();
        }
        if (getLayoutStart() != null) {
            _hashCode += getLayoutStart().hashCode();
        }
        if (getLowResolution() != null) {
            _hashCode += getLowResolution().hashCode();
        }
        if (getMode() != null) {
            _hashCode += getMode().hashCode();
        }
        if (getMonochromeCompression() != null) {
            _hashCode += getMonochromeCompression().hashCode();
        }
        if (getMonochromeImagedownSample() != null) {
            _hashCode += getMonochromeImagedownSample().hashCode();
        }
        if (getMovePages() != null) {
            _hashCode += getMovePages().hashCode();
        }
        if (getOffset() != null) {
            _hashCode += getOffset().hashCode();
        }
        if (getOffsetBleed() != null) {
            _hashCode += getOffsetBleed().hashCode();
        }
        if (getOutputStyle() != null) {
            _hashCode += getOutputStyle().hashCode();
        }
        if (getPDFPage() != null) {
            _hashCode += getPDFPage().hashCode();
        }
        if (getPage() != null) {
            _hashCode += getPage().hashCode();
        }
        if (getPages() != null) {
            _hashCode += getPages().hashCode();
        }
        if (getPasteboard() != null) {
            _hashCode += getPasteboard().hashCode();
        }
        if (getPlates() != null) {
            _hashCode += getPlates().hashCode();
        }
        if (getPostScriptFile() != null) {
            _hashCode += getPostScriptFile().hashCode();
        }
        if (getPrintColors() != null) {
            _hashCode += getPrintColors().hashCode();
        }
        if (getProduceBlankPages() != null) {
            _hashCode += getProduceBlankPages().hashCode();
        }
        if (getProduceBlankPlatesOption() != null) {
            _hashCode += getProduceBlankPlatesOption().hashCode();
        }
        if (getReducePdfSize() != null) {
            _hashCode += getReducePdfSize().hashCode();
        }
        if (getRegistration() != null) {
            _hashCode += getRegistration().hashCode();
        }
        if (getSeparate() != null) {
            _hashCode += getSeparate().hashCode();
        }
        if (getSpread() != null) {
            _hashCode += getSpread().hashCode();
        }
        if (getSpreads() != null) {
            _hashCode += getSpreads().hashCode();
        }
        if (getSubject() != null) {
            _hashCode += getSubject().hashCode();
        }
        if (getThumbnail() != null) {
            _hashCode += getThumbnail().hashCode();
        }
        if (getTitle() != null) {
            _hashCode += getTitle().hashCode();
        }
        if (getTransparencyFlatteningResolution() != null) {
            _hashCode += getTransparencyFlatteningResolution().hashCode();
        }
        if (getUpdateFullRes() != null) {
            _hashCode += getUpdateFullRes().hashCode();
        }
        if (getUpdateImage() != null) {
            _hashCode += getUpdateImage().hashCode();
        }
        if (getUseOPI() != null) {
            _hashCode += getUseOPI().hashCode();
        }
        if (getVerification() != null) {
            _hashCode += getVerification().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PDFRenderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PDFRenderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addLayer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "addLayer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("afterPage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "afterPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allLayers");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "allLayers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("author");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "author"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bleed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "bleed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("colorCompression");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "colorCompression"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("colorImageDownSample");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "colorImageDownSample"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createTaggedPdf");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "createTaggedPdf"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deleteLayer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "deleteLayer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exportIndexesAsHyperlinks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "exportIndexesAsHyperlinks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exportListsAsBookmarks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "exportListsAsBookmarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exportListsAsHyperlinks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "exportListsAsHyperlinks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fontDownloadOption");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fontDownloadOption"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grayscaleCompression");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "grayscaleCompression"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grayscaleImageDownSample");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "grayscaleImageDownSample"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("images");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "images"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeHyperlinks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "includeHyperlinks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keywords");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "keywords"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layerEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layerEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layerStart");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layerStart"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layers");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layoutEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layoutStart");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layoutStart"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lowResolution");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "lowResolution"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "mode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("monochromeCompression");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "monochromeCompression"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("monochromeImagedownSample");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "monochromeImagedownSample"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("movePages");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "movePages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "offset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offsetBleed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "offsetBleed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "outputStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PDFPage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PDFPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("page");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "page"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pages");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pasteboard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pasteboard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("plates");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "plates"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("postScriptFile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "postScriptFile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("printColors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "printColors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produceBlankPages");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "produceBlankPages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produceBlankPlatesOption");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "produceBlankPlatesOption"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reducePdfSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "reducePdfSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("registration");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "registration"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("separate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "separate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spread");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spread"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spreads");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spreads"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subject");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "subject"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thumbnail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "thumbnail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("title");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "title"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transparencyFlatteningResolution");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "transparencyFlatteningResolution"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateFullRes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "updateFullRes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateImage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "updateImage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("useOPI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "useOPI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verification");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "verification"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
