package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.Run;

/**
 * DAO interface for updating run start information
 */
public interface RunStartUpdateDao {
    /**
     * Start a run by updating its status and start date
     * @param run the run to start
     */
    void startRun(Run run);
}
