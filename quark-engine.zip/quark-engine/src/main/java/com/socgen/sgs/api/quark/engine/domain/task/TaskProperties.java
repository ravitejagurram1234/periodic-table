package com.socgen.sgs.api.quark.engine.domain.task;
import com.socgen.sgs.api.quark.engine.enums.TaskActionTypeEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
/** Represents the properties and configuration of a task. */
@Getter
@Setter
@NoArgsConstructor
public class TaskProperties {
    private String layoutName;
    private int pageNum;
    private int indexLigne = Integer.MIN_VALUE;
    private int nbLigne = Integer.MIN_VALUE;
    private TaskActionTypeEnum taskAction = TaskActionTypeEnum.NONE;
    private String tableName;
}
