package com.socgen.sgs.api.quark.engine.service.impl;

import com.socgen.sgs.api.quark.engine.business.QxpsCallerBusiness;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.dto.QxpsCallerResult;
import com.socgen.sgs.api.quark.engine.service.QxpsCallerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Orchestrates QuarkXPress Server execution for a run. The actual QXPS/SOAP work lives in the
 * {@code business} layer ({@link QxpsCallerBusiness}); this service simply delegates, keeping the
 * service → business → infra boundary (the service must not depend on {@code infra} directly).
 *
 * Cross-reference: QXP.Engine.Core.QXPS_Caller.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class QxpsCallerServiceImpl implements QxpsCallerService {

    private final QxpsCallerBusiness qxpsCallerBusiness;

    @Override
    public void process(Run run) {
        qxpsCallerBusiness.process(run);
    }

    @Override
    public QxpsCallerResult render(Run run, boolean renderPdf, boolean renderJpg,
                                   boolean renderQxp, String compression, String downsample) {
        return qxpsCallerBusiness.render(run, renderPdf, renderJpg, renderQxp, compression, downsample);
    }
}