package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.dynamic.template.Template;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

@Component
public class TemplateMapper {

    public Template mapToTemplate(Map<String, Object> row) {
        Template template = new Template();

        template.setName(getString(row, "NOM"));
        template.setSrcName(getString(row, "SRC_NOM"));
        template.setSrcNameOverflow(getString(row, "SRC_NOM_OVERFLOW"));
        template.setAbsolute(getBoolean(row, "ABSOLUTE"));
        template.setPageBreak(getBoolean(row, "PAGE_BREAK"));
        template.setColumnBreak(getBoolean(row, "COLUMN_BREAK"));

        BigDecimal left = getBigDecimal(row, "LEFT");
        if (left != null) template.setLeft(left);

        BigDecimal top = getBigDecimal(row, "TOP");
        if (top != null) template.setTop(top);

        BigDecimal width = getBigDecimal(row, "WIDTH");
        if (width != null) template.setWidth(width);

        BigDecimal height = getBigDecimal(row, "HEIGHT");
        if (height != null) template.setHeight(height);

        // Store the raw [Flags] value directly (parity: .NET Proxy_Template.cs:185-188 casts the int
        // to the [Flags] enum without validating bit combinations). Never throws on combined values.
        Integer absoluteRepeatVal = getInteger(row, "ABSOLUTE_REPEAT");
        if (absoluteRepeatVal != null) {
            template.setAbsoluteRepeat(absoluteRepeatVal);
        }

        return template;
    }

    private String getString(Map<String, Object> row, String key) {
        Object val = row.get(key);
        return val != null ? val.toString() : null;
    }

    private boolean getBoolean(Map<String, Object> row, String key) {
        Object val = row.get(key);
        if (val instanceof Number) return ((Number) val).intValue() != 0;
        if (val instanceof Boolean) return (Boolean) val;
        return false;
    }

    private BigDecimal getBigDecimal(Map<String, Object> row, String key) {
        Object val = row.get(key);
        if (val instanceof BigDecimal) return (BigDecimal) val;
        if (val instanceof Number) return BigDecimal.valueOf(((Number) val).doubleValue());
        return null;
    }

    private Integer getInteger(Map<String, Object> row, String key) {
        Object val = row.get(key);
        if (val instanceof Number) return ((Number) val).intValue();
        return null;
    }
}