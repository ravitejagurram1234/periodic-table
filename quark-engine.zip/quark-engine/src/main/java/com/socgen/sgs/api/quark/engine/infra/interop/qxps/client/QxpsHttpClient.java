package com.socgen.sgs.api.quark.engine.infra.interop.qxps.client;

import com.socgen.sgs.api.quark.engine.infra.interop.qxps.config.QxpsProperties;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.exception.QxpsException;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.message.QxpsMessage;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.model.QxpsRequestInfo;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.model.QxpsResponseInfo;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.request.QxpsRequestBuilder;
import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import jakarta.annotation.PostConstruct;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class QxpsHttpClient {

    private final QxpsRequestBuilder requestBuilder;
    private final QxpsProperties qxpsProperties;
    private WebClient webClient;

    private static final Set<String> TEXT_CONTENT_TYPES = Set.of(
            "text/plain", "text/xml", "text/html", ""
    );

    public QxpsHttpClient(QxpsRequestBuilder requestBuilder, QxpsProperties qxpsProperties) {
        this.requestBuilder = requestBuilder;
        this.qxpsProperties = qxpsProperties;
    }

    @PostConstruct
    void init() {
        int timeout = qxpsProperties.getServer().getTimeout();
        HttpClient httpClient = HttpClient.create()
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, timeout)
                .doOnConnected(conn ->
                        conn.addHandlerLast(new ReadTimeoutHandler(timeout, TimeUnit.MILLISECONDS))
                )
                .responseTimeout(Duration.ofMillis(timeout));

        this.webClient = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    public QxpsResponseInfo execute(String documentName, QxpsMessage message) {
        QxpsRequestInfo requestInfo = requestBuilder.build(documentName, message);
        log.info("QXPS call: {} {}", requestInfo.getMethod(), requestInfo.getUri());

        try {
            if (requestInfo.getMethod() == HttpMethod.POST) {
                return executePost(requestInfo);
            }
            return executeGet(requestInfo);
        } catch (QxpsException e) {
            throw e;
        } catch (Exception e) {
            throw new QxpsException(requestInfo, e);
        }
    }

    private QxpsResponseInfo executePost(QxpsRequestInfo requestInfo) {
        byte[] multipartBody = buildMultipartBody(requestInfo.getData());
        String boundary = extractBoundary(multipartBody);

        return webClient.post()
                .uri(requestInfo.getUri())
                .header(HttpHeaders.CONTENT_TYPE, "multipart/form-data; boundary=" + boundary)
                .bodyValue(multipartBody)
                .exchangeToMono(clientResponse -> handleResponse(requestInfo, clientResponse))
                .block();
    }

    private QxpsResponseInfo executeGet(QxpsRequestInfo requestInfo) {
        return webClient.get()
                .uri(requestInfo.getUri())
                .exchangeToMono(clientResponse -> handleResponse(requestInfo, clientResponse))
                .block();
    }

    private Mono<QxpsResponseInfo> handleResponse(QxpsRequestInfo requestInfo, ClientResponse clientResponse) {
        HttpStatusCode status = clientResponse.statusCode();
        if (status.isError()) {
            return clientResponse.bodyToMono(String.class)
                    .defaultIfEmpty("")
                    .flatMap(errorBody -> Mono.error(
                            new QxpsException(requestInfo, "HTTP " + status.value() + ": " + errorBody)));
        }

        QxpsResponseInfo response = new QxpsResponseInfo();
        MediaType contentType = clientResponse.headers().contentType().orElse(null);
        String contentTypeValue = contentType != null ? contentType.toString() : "";
        response.setContentType(contentTypeValue);

        if (isTextContentType(contentTypeValue)) {
            return clientResponse.bodyToMono(String.class)
                    .defaultIfEmpty("")
                    .map(text -> { response.setTextResponse(text); return response; });
        } else {
            return clientResponse.bodyToMono(byte[].class)
                    .defaultIfEmpty(new byte[0])
                    .map(bytes -> { response.setBinaryResponse(bytes); return response; });
        }
    }

    /** Builds multipart body matching the .NET WriteMultipart format exactly. */
    private byte[] buildMultipartBody(byte[] data) {
        String boundary = UUID.randomUUID().toString();
        String header = "--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"file\"; filename=\"fileData.bin\"\r\n"
                + "Content-Type: binary/octet-stream\r\n"
                + "\r\n";
        String footer = "\r\n--" + boundary + "--";

        byte[] headerBytes = header.getBytes(StandardCharsets.UTF_8);
        byte[] footerBytes = footer.getBytes(StandardCharsets.UTF_8);

        byte[] body = new byte[headerBytes.length + data.length + footerBytes.length];
        System.arraycopy(headerBytes, 0, body, 0, headerBytes.length);
        System.arraycopy(data, 0, body, headerBytes.length, data.length);
        System.arraycopy(footerBytes, 0, body, headerBytes.length + data.length, footerBytes.length);

        return body;
    }

    /** Extracts the boundary string from the already-built multipart body. */
    private String extractBoundary(byte[] multipartBody) {
        String start = new String(multipartBody, 0, Math.min(200, multipartBody.length), StandardCharsets.UTF_8);
        // Body starts with "--{boundary}\r\n", so boundary is between index 2 and the first \r\n
        int endIndex = start.indexOf("\r\n");
        return start.substring(2, endIndex);
    }

    private boolean isTextContentType(String contentType) {
        if (contentType == null || contentType.isEmpty()) return true;
        String lower = contentType.toLowerCase();
        return TEXT_CONTENT_TYPES.stream().anyMatch(t -> !t.isEmpty() && lower.startsWith(t));
    }
}

