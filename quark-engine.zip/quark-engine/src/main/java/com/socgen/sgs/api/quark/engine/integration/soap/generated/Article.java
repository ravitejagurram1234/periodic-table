/**
 * Article.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Article  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor RGBColor;

    private java.lang.String UID;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Component[] components;

    private java.lang.String docFormat;

    private java.lang.String exportArticle;

    private java.lang.String name;

    private java.lang.String operation;

    public Article() {
    }

    public Article(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor RGBColor,
           java.lang.String UID,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Component[] components,
           java.lang.String docFormat,
           java.lang.String exportArticle,
           java.lang.String name,
           java.lang.String operation) {
        super(
            request);
        this.RGBColor = RGBColor;
        this.UID = UID;
        this.components = components;
        this.docFormat = docFormat;
        this.exportArticle = exportArticle;
        this.name = name;
        this.operation = operation;
    }


    /**
     * Gets the RGBColor value for this Article.
     * 
     * @return RGBColor
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor getRGBColor() {
        return RGBColor;
    }


    /**
     * Sets the RGBColor value for this Article.
     * 
     * @param RGBColor
     */
    public void setRGBColor(com.socgen.sgs.api.quark.engine.integration.soap.generated.RGBColor RGBColor) {
        this.RGBColor = RGBColor;
    }


    /**
     * Gets the UID value for this Article.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Article.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the components value for this Article.
     * 
     * @return components
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Component[] getComponents() {
        return components;
    }


    /**
     * Sets the components value for this Article.
     * 
     * @param components
     */
    public void setComponents(com.socgen.sgs.api.quark.engine.integration.soap.generated.Component[] components) {
        this.components = components;
    }


    /**
     * Gets the docFormat value for this Article.
     * 
     * @return docFormat
     */
    public java.lang.String getDocFormat() {
        return docFormat;
    }


    /**
     * Sets the docFormat value for this Article.
     * 
     * @param docFormat
     */
    public void setDocFormat(java.lang.String docFormat) {
        this.docFormat = docFormat;
    }


    /**
     * Gets the exportArticle value for this Article.
     * 
     * @return exportArticle
     */
    public java.lang.String getExportArticle() {
        return exportArticle;
    }


    /**
     * Sets the exportArticle value for this Article.
     * 
     * @param exportArticle
     */
    public void setExportArticle(java.lang.String exportArticle) {
        this.exportArticle = exportArticle;
    }


    /**
     * Gets the name value for this Article.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Article.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the operation value for this Article.
     * 
     * @return operation
     */
    public java.lang.String getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this Article.
     * 
     * @param operation
     */
    public void setOperation(java.lang.String operation) {
        this.operation = operation;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Article)) return false;
        Article other = (Article) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.RGBColor==null && other.getRGBColor()==null) || 
             (this.RGBColor!=null &&
              this.RGBColor.equals(other.getRGBColor()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.components==null && other.getComponents()==null) || 
             (this.components!=null &&
              java.util.Arrays.equals(this.components, other.getComponents()))) &&
            ((this.docFormat==null && other.getDocFormat()==null) || 
             (this.docFormat!=null &&
              this.docFormat.equals(other.getDocFormat()))) &&
            ((this.exportArticle==null && other.getExportArticle()==null) || 
             (this.exportArticle!=null &&
              this.exportArticle.equals(other.getExportArticle()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.operation==null && other.getOperation()==null) || 
             (this.operation!=null &&
              this.operation.equals(other.getOperation())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getRGBColor() != null) {
            _hashCode += getRGBColor().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getComponents() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getComponents());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getComponents(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDocFormat() != null) {
            _hashCode += getDocFormat().hashCode();
        }
        if (getExportArticle() != null) {
            _hashCode += getExportArticle().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOperation() != null) {
            _hashCode += getOperation().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Article.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Article"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RGBColor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RGBColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RGBColor"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("components");
        elemField.setXmlName(new javax.xml.namespace.QName("", "components"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Component"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("docFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "docFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exportArticle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "exportArticle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
