package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.mapper.RunPropertiesMapper;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;
import com.socgen.sgs.api.quark.engine.infra.dao.GetRunPropertiesDao;
import lombok.extern.slf4j.Slf4j;
import lombok.RequiredArgsConstructor;
import oracle.jdbc.OracleTypes;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import jakarta.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Map;

/**
 * DAO implementation that calls the Oracle function QXP_PK_RUN.Get_Run_Properties
 * to retrieve properties for a given run.
 */
@Repository
@Slf4j
@RequiredArgsConstructor
public class GetRunPropertiesDaoImpl implements GetRunPropertiesDao {

    private static final String RESULT_KEY = "result_cursor";

    private final DataSource dataSource;
    private final RunPropertiesMapper runPropertiesMapper;

    private SimpleJdbcCall getRunPropertiesCall;

    @PostConstruct
    private void init() {
        // Get_Run_Properties is a FUNCTION in QXP_PK_RUN package that returns a REF CURSOR.
        // Using withFunctionName so Spring generates: { ? = call QXP_PK_RUN.Get_Run_Properties(?) }
        // The first declared parameter (SqlOutParameter) binds to the function return value.
        this.getRunPropertiesCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_Run_Properties")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR,
                                (rs, rowNum) -> runPropertiesMapper.mapFromResultSet(rs)),
                        new SqlParameter("p_id_run", Types.NUMERIC)
                );
    }

    @Override
    public RunProperties getRunProperties(RunIdDto runIdDto) {
        log.info("Fetching run properties for runId: {}", runIdDto.getRunId());

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_run", runIdDto.getRunId());

        try {
            Map<String, Object> result = getRunPropertiesCall.execute(params);

            log.debug("Result map keys: {}, values: {}", result.keySet(), result);

            @SuppressWarnings("unchecked")
            List<RunProperties> rows = (List<RunProperties>) result.get(RESULT_KEY);

            if (rows == null || rows.isEmpty()) {
                log.error("No run properties found for runId: {}", runIdDto.getRunId());
                throw new IllegalArgumentException(
                        "No run properties found for runId: " + runIdDto.getRunId());
            }

            log.info("Successfully retrieved run properties for runId: {}", runIdDto.getRunId());
            return rows.get(0);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error fetching run properties for runId: {}", runIdDto.getRunId(), e);
            throw new RuntimeException("Failed to fetch run properties for runId: " + runIdDto.getRunId(), e);
        }
    }
}












