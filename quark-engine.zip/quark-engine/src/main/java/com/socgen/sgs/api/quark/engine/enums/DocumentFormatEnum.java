package com.socgen.sgs.api.quark.engine.enums;

import lombok.Getter;

/**
 * Enumeration representing different document formats.
 * Defines the supported file formats for documents and templates.
 */
@Getter
public enum DocumentFormatEnum {

    PDF("PDF"),
    JPG("JPG"),
    JPEG("JPEG"),
    EPS("EPS"),
    GIF("GIF"),
    PNG("PNG"),
    XTG("XTG"),
    DOC("DOC"),
    RTF("RTF"),
    QXP("QXP"),
    TIF("TIF"),
    TIFF("TIFF");

    private final String format;

    DocumentFormatEnum(String format) {
        this.format = format;
    }

    /**
     * Get DocumentFormatEnum from string format.
     *
     * @param format the string format (case-insensitive)
     * @return the corresponding DocumentFormatEnum, or null if not found
     */
    public static DocumentFormatEnum fromFormat(String format) {
        if (format == null) {
            return null;
        }
        for (DocumentFormatEnum f : values()) {
            if (f.format.equalsIgnoreCase(format)) {
                return f;
            }
        }
        return null;
    }
}

