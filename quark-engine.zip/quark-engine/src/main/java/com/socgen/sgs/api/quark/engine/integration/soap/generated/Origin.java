/**
 * Origin.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Origin  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String relativeTo;

    private java.lang.String x;

    private java.lang.String y;

    public Origin() {
    }

    public Origin(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String relativeTo,
           java.lang.String x,
           java.lang.String y) {
        super(
            request);
        this.relativeTo = relativeTo;
        this.x = x;
        this.y = y;
    }


    /**
     * Gets the relativeTo value for this Origin.
     * 
     * @return relativeTo
     */
    public java.lang.String getRelativeTo() {
        return relativeTo;
    }


    /**
     * Sets the relativeTo value for this Origin.
     * 
     * @param relativeTo
     */
    public void setRelativeTo(java.lang.String relativeTo) {
        this.relativeTo = relativeTo;
    }


    /**
     * Gets the x value for this Origin.
     * 
     * @return x
     */
    public java.lang.String getX() {
        return x;
    }


    /**
     * Sets the x value for this Origin.
     * 
     * @param x
     */
    public void setX(java.lang.String x) {
        this.x = x;
    }


    /**
     * Gets the y value for this Origin.
     * 
     * @return y
     */
    public java.lang.String getY() {
        return y;
    }


    /**
     * Sets the y value for this Origin.
     * 
     * @param y
     */
    public void setY(java.lang.String y) {
        this.y = y;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Origin)) return false;
        Origin other = (Origin) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.relativeTo==null && other.getRelativeTo()==null) || 
             (this.relativeTo!=null &&
              this.relativeTo.equals(other.getRelativeTo()))) &&
            ((this.x==null && other.getX()==null) || 
             (this.x!=null &&
              this.x.equals(other.getX()))) &&
            ((this.y==null && other.getY()==null) || 
             (this.y!=null &&
              this.y.equals(other.getY())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getRelativeTo() != null) {
            _hashCode += getRelativeTo().hashCode();
        }
        if (getX() != null) {
            _hashCode += getX().hashCode();
        }
        if (getY() != null) {
            _hashCode += getY().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Origin.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Origin"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relativeTo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "relativeTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("x");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "x"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("y");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "y"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
