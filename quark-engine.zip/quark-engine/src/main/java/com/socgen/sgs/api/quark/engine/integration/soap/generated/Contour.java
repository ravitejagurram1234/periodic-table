/**
 * Contour.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Contour  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String curvedEdges;

    private java.lang.String invertedContour;

    private java.lang.String polyContour;

    private java.lang.String rectContour;

    private java.lang.String selfIntersected;

    private java.lang.String topLevel;

    private java.lang.String vertexTagExists;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Vertices vertices;

    public Contour() {
    }

    public Contour(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String curvedEdges,
           java.lang.String invertedContour,
           java.lang.String polyContour,
           java.lang.String rectContour,
           java.lang.String selfIntersected,
           java.lang.String topLevel,
           java.lang.String vertexTagExists,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Vertices vertices) {
        super(
            request);
        this.curvedEdges = curvedEdges;
        this.invertedContour = invertedContour;
        this.polyContour = polyContour;
        this.rectContour = rectContour;
        this.selfIntersected = selfIntersected;
        this.topLevel = topLevel;
        this.vertexTagExists = vertexTagExists;
        this.vertices = vertices;
    }


    /**
     * Gets the curvedEdges value for this Contour.
     * 
     * @return curvedEdges
     */
    public java.lang.String getCurvedEdges() {
        return curvedEdges;
    }


    /**
     * Sets the curvedEdges value for this Contour.
     * 
     * @param curvedEdges
     */
    public void setCurvedEdges(java.lang.String curvedEdges) {
        this.curvedEdges = curvedEdges;
    }


    /**
     * Gets the invertedContour value for this Contour.
     * 
     * @return invertedContour
     */
    public java.lang.String getInvertedContour() {
        return invertedContour;
    }


    /**
     * Sets the invertedContour value for this Contour.
     * 
     * @param invertedContour
     */
    public void setInvertedContour(java.lang.String invertedContour) {
        this.invertedContour = invertedContour;
    }


    /**
     * Gets the polyContour value for this Contour.
     * 
     * @return polyContour
     */
    public java.lang.String getPolyContour() {
        return polyContour;
    }


    /**
     * Sets the polyContour value for this Contour.
     * 
     * @param polyContour
     */
    public void setPolyContour(java.lang.String polyContour) {
        this.polyContour = polyContour;
    }


    /**
     * Gets the rectContour value for this Contour.
     * 
     * @return rectContour
     */
    public java.lang.String getRectContour() {
        return rectContour;
    }


    /**
     * Sets the rectContour value for this Contour.
     * 
     * @param rectContour
     */
    public void setRectContour(java.lang.String rectContour) {
        this.rectContour = rectContour;
    }


    /**
     * Gets the selfIntersected value for this Contour.
     * 
     * @return selfIntersected
     */
    public java.lang.String getSelfIntersected() {
        return selfIntersected;
    }


    /**
     * Sets the selfIntersected value for this Contour.
     * 
     * @param selfIntersected
     */
    public void setSelfIntersected(java.lang.String selfIntersected) {
        this.selfIntersected = selfIntersected;
    }


    /**
     * Gets the topLevel value for this Contour.
     * 
     * @return topLevel
     */
    public java.lang.String getTopLevel() {
        return topLevel;
    }


    /**
     * Sets the topLevel value for this Contour.
     * 
     * @param topLevel
     */
    public void setTopLevel(java.lang.String topLevel) {
        this.topLevel = topLevel;
    }


    /**
     * Gets the vertexTagExists value for this Contour.
     * 
     * @return vertexTagExists
     */
    public java.lang.String getVertexTagExists() {
        return vertexTagExists;
    }


    /**
     * Sets the vertexTagExists value for this Contour.
     * 
     * @param vertexTagExists
     */
    public void setVertexTagExists(java.lang.String vertexTagExists) {
        this.vertexTagExists = vertexTagExists;
    }


    /**
     * Gets the vertices value for this Contour.
     * 
     * @return vertices
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Vertices getVertices() {
        return vertices;
    }


    /**
     * Sets the vertices value for this Contour.
     * 
     * @param vertices
     */
    public void setVertices(com.socgen.sgs.api.quark.engine.integration.soap.generated.Vertices vertices) {
        this.vertices = vertices;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Contour)) return false;
        Contour other = (Contour) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.curvedEdges==null && other.getCurvedEdges()==null) || 
             (this.curvedEdges!=null &&
              this.curvedEdges.equals(other.getCurvedEdges()))) &&
            ((this.invertedContour==null && other.getInvertedContour()==null) || 
             (this.invertedContour!=null &&
              this.invertedContour.equals(other.getInvertedContour()))) &&
            ((this.polyContour==null && other.getPolyContour()==null) || 
             (this.polyContour!=null &&
              this.polyContour.equals(other.getPolyContour()))) &&
            ((this.rectContour==null && other.getRectContour()==null) || 
             (this.rectContour!=null &&
              this.rectContour.equals(other.getRectContour()))) &&
            ((this.selfIntersected==null && other.getSelfIntersected()==null) || 
             (this.selfIntersected!=null &&
              this.selfIntersected.equals(other.getSelfIntersected()))) &&
            ((this.topLevel==null && other.getTopLevel()==null) || 
             (this.topLevel!=null &&
              this.topLevel.equals(other.getTopLevel()))) &&
            ((this.vertexTagExists==null && other.getVertexTagExists()==null) || 
             (this.vertexTagExists!=null &&
              this.vertexTagExists.equals(other.getVertexTagExists()))) &&
            ((this.vertices==null && other.getVertices()==null) || 
             (this.vertices!=null &&
              this.vertices.equals(other.getVertices())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCurvedEdges() != null) {
            _hashCode += getCurvedEdges().hashCode();
        }
        if (getInvertedContour() != null) {
            _hashCode += getInvertedContour().hashCode();
        }
        if (getPolyContour() != null) {
            _hashCode += getPolyContour().hashCode();
        }
        if (getRectContour() != null) {
            _hashCode += getRectContour().hashCode();
        }
        if (getSelfIntersected() != null) {
            _hashCode += getSelfIntersected().hashCode();
        }
        if (getTopLevel() != null) {
            _hashCode += getTopLevel().hashCode();
        }
        if (getVertexTagExists() != null) {
            _hashCode += getVertexTagExists().hashCode();
        }
        if (getVertices() != null) {
            _hashCode += getVertices().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Contour.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Contour"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("curvedEdges");
        elemField.setXmlName(new javax.xml.namespace.QName("", "curvedEdges"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invertedContour");
        elemField.setXmlName(new javax.xml.namespace.QName("", "invertedContour"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("polyContour");
        elemField.setXmlName(new javax.xml.namespace.QName("", "polyContour"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rectContour");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rectContour"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("selfIntersected");
        elemField.setXmlName(new javax.xml.namespace.QName("", "selfIntersected"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "topLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vertexTagExists");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vertexTagExists"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vertices");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vertices"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Vertices"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
