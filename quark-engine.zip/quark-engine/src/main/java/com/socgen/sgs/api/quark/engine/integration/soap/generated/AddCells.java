/**
 * AddCells.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class AddCells  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String baseIndex;

    private java.lang.String insertCount;

    private java.lang.String insertPosition;

    private java.lang.String keepAttribute;

    private java.lang.String type;

    public AddCells() {
    }

    public AddCells(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String baseIndex,
           java.lang.String insertCount,
           java.lang.String insertPosition,
           java.lang.String keepAttribute,
           java.lang.String type) {
        super(
            request);
        this.baseIndex = baseIndex;
        this.insertCount = insertCount;
        this.insertPosition = insertPosition;
        this.keepAttribute = keepAttribute;
        this.type = type;
    }


    /**
     * Gets the baseIndex value for this AddCells.
     * 
     * @return baseIndex
     */
    public java.lang.String getBaseIndex() {
        return baseIndex;
    }


    /**
     * Sets the baseIndex value for this AddCells.
     * 
     * @param baseIndex
     */
    public void setBaseIndex(java.lang.String baseIndex) {
        this.baseIndex = baseIndex;
    }


    /**
     * Gets the insertCount value for this AddCells.
     * 
     * @return insertCount
     */
    public java.lang.String getInsertCount() {
        return insertCount;
    }


    /**
     * Sets the insertCount value for this AddCells.
     * 
     * @param insertCount
     */
    public void setInsertCount(java.lang.String insertCount) {
        this.insertCount = insertCount;
    }


    /**
     * Gets the insertPosition value for this AddCells.
     * 
     * @return insertPosition
     */
    public java.lang.String getInsertPosition() {
        return insertPosition;
    }


    /**
     * Sets the insertPosition value for this AddCells.
     * 
     * @param insertPosition
     */
    public void setInsertPosition(java.lang.String insertPosition) {
        this.insertPosition = insertPosition;
    }


    /**
     * Gets the keepAttribute value for this AddCells.
     * 
     * @return keepAttribute
     */
    public java.lang.String getKeepAttribute() {
        return keepAttribute;
    }


    /**
     * Sets the keepAttribute value for this AddCells.
     * 
     * @param keepAttribute
     */
    public void setKeepAttribute(java.lang.String keepAttribute) {
        this.keepAttribute = keepAttribute;
    }


    /**
     * Gets the type value for this AddCells.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this AddCells.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AddCells)) return false;
        AddCells other = (AddCells) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.baseIndex==null && other.getBaseIndex()==null) || 
             (this.baseIndex!=null &&
              this.baseIndex.equals(other.getBaseIndex()))) &&
            ((this.insertCount==null && other.getInsertCount()==null) || 
             (this.insertCount!=null &&
              this.insertCount.equals(other.getInsertCount()))) &&
            ((this.insertPosition==null && other.getInsertPosition()==null) || 
             (this.insertPosition!=null &&
              this.insertPosition.equals(other.getInsertPosition()))) &&
            ((this.keepAttribute==null && other.getKeepAttribute()==null) || 
             (this.keepAttribute!=null &&
              this.keepAttribute.equals(other.getKeepAttribute()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBaseIndex() != null) {
            _hashCode += getBaseIndex().hashCode();
        }
        if (getInsertCount() != null) {
            _hashCode += getInsertCount().hashCode();
        }
        if (getInsertPosition() != null) {
            _hashCode += getInsertPosition().hashCode();
        }
        if (getKeepAttribute() != null) {
            _hashCode += getKeepAttribute().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AddCells.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AddCells"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("baseIndex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "baseIndex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insertCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "insertCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insertPosition");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "insertPosition"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keepAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "keepAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
