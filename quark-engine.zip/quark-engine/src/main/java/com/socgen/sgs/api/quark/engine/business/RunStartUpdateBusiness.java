package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.infra.dao.RunStartUpdateDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Business component responsible for orchestrating the start/update of a run.
 */
@Component
public class RunStartUpdateBusiness {

    private static final Logger log = LoggerFactory.getLogger(RunStartUpdateBusiness.class);
    private final RunStartUpdateDao runStartUpdateDao;

    public RunStartUpdateBusiness(RunStartUpdateDao runStartUpdateDao) {
        this.runStartUpdateDao = runStartUpdateDao;
    }
    public void execute(Run run) {
        log.info("Business layer: starting run with ID: {}", run.getId());
        runStartUpdateDao.startRun(run);
    }
}
