/**
 * LockToGrid.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class LockToGrid  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String enabled;

    private java.lang.String gridLevel;

    private java.lang.String gridType;

    public LockToGrid() {
    }

    public LockToGrid(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String enabled,
           java.lang.String gridLevel,
           java.lang.String gridType) {
        super(
            request);
        this.enabled = enabled;
        this.gridLevel = gridLevel;
        this.gridType = gridType;
    }


    /**
     * Gets the enabled value for this LockToGrid.
     * 
     * @return enabled
     */
    public java.lang.String getEnabled() {
        return enabled;
    }


    /**
     * Sets the enabled value for this LockToGrid.
     * 
     * @param enabled
     */
    public void setEnabled(java.lang.String enabled) {
        this.enabled = enabled;
    }


    /**
     * Gets the gridLevel value for this LockToGrid.
     * 
     * @return gridLevel
     */
    public java.lang.String getGridLevel() {
        return gridLevel;
    }


    /**
     * Sets the gridLevel value for this LockToGrid.
     * 
     * @param gridLevel
     */
    public void setGridLevel(java.lang.String gridLevel) {
        this.gridLevel = gridLevel;
    }


    /**
     * Gets the gridType value for this LockToGrid.
     * 
     * @return gridType
     */
    public java.lang.String getGridType() {
        return gridType;
    }


    /**
     * Sets the gridType value for this LockToGrid.
     * 
     * @param gridType
     */
    public void setGridType(java.lang.String gridType) {
        this.gridType = gridType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LockToGrid)) return false;
        LockToGrid other = (LockToGrid) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.enabled==null && other.getEnabled()==null) || 
             (this.enabled!=null &&
              this.enabled.equals(other.getEnabled()))) &&
            ((this.gridLevel==null && other.getGridLevel()==null) || 
             (this.gridLevel!=null &&
              this.gridLevel.equals(other.getGridLevel()))) &&
            ((this.gridType==null && other.getGridType()==null) || 
             (this.gridType!=null &&
              this.gridType.equals(other.getGridType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getEnabled() != null) {
            _hashCode += getEnabled().hashCode();
        }
        if (getGridLevel() != null) {
            _hashCode += getGridLevel().hashCode();
        }
        if (getGridType() != null) {
            _hashCode += getGridType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LockToGrid.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LockToGrid"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enabled");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enabled"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gridLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "gridLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gridType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "gridType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
