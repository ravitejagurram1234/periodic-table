/**
 * ServerPreferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ServerPreferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private boolean allowMemoryCaching;

    private int cacheSize;

    private java.lang.String defaultRenderType;

    private boolean disableQuarkXPressDocumentReturn;

    private java.lang.String documentRootFolder;

    private boolean forceCloseServedDocuments;

    private int scale;

    public ServerPreferences() {
    }

    public ServerPreferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           boolean allowMemoryCaching,
           int cacheSize,
           java.lang.String defaultRenderType,
           boolean disableQuarkXPressDocumentReturn,
           java.lang.String documentRootFolder,
           boolean forceCloseServedDocuments,
           int scale) {
        super(
            request);
        this.allowMemoryCaching = allowMemoryCaching;
        this.cacheSize = cacheSize;
        this.defaultRenderType = defaultRenderType;
        this.disableQuarkXPressDocumentReturn = disableQuarkXPressDocumentReturn;
        this.documentRootFolder = documentRootFolder;
        this.forceCloseServedDocuments = forceCloseServedDocuments;
        this.scale = scale;
    }


    /**
     * Gets the allowMemoryCaching value for this ServerPreferences.
     * 
     * @return allowMemoryCaching
     */
    public boolean isAllowMemoryCaching() {
        return allowMemoryCaching;
    }


    /**
     * Sets the allowMemoryCaching value for this ServerPreferences.
     * 
     * @param allowMemoryCaching
     */
    public void setAllowMemoryCaching(boolean allowMemoryCaching) {
        this.allowMemoryCaching = allowMemoryCaching;
    }


    /**
     * Gets the cacheSize value for this ServerPreferences.
     * 
     * @return cacheSize
     */
    public int getCacheSize() {
        return cacheSize;
    }


    /**
     * Sets the cacheSize value for this ServerPreferences.
     * 
     * @param cacheSize
     */
    public void setCacheSize(int cacheSize) {
        this.cacheSize = cacheSize;
    }


    /**
     * Gets the defaultRenderType value for this ServerPreferences.
     * 
     * @return defaultRenderType
     */
    public java.lang.String getDefaultRenderType() {
        return defaultRenderType;
    }


    /**
     * Sets the defaultRenderType value for this ServerPreferences.
     * 
     * @param defaultRenderType
     */
    public void setDefaultRenderType(java.lang.String defaultRenderType) {
        this.defaultRenderType = defaultRenderType;
    }


    /**
     * Gets the disableQuarkXPressDocumentReturn value for this ServerPreferences.
     * 
     * @return disableQuarkXPressDocumentReturn
     */
    public boolean isDisableQuarkXPressDocumentReturn() {
        return disableQuarkXPressDocumentReturn;
    }


    /**
     * Sets the disableQuarkXPressDocumentReturn value for this ServerPreferences.
     * 
     * @param disableQuarkXPressDocumentReturn
     */
    public void setDisableQuarkXPressDocumentReturn(boolean disableQuarkXPressDocumentReturn) {
        this.disableQuarkXPressDocumentReturn = disableQuarkXPressDocumentReturn;
    }


    /**
     * Gets the documentRootFolder value for this ServerPreferences.
     * 
     * @return documentRootFolder
     */
    public java.lang.String getDocumentRootFolder() {
        return documentRootFolder;
    }


    /**
     * Sets the documentRootFolder value for this ServerPreferences.
     * 
     * @param documentRootFolder
     */
    public void setDocumentRootFolder(java.lang.String documentRootFolder) {
        this.documentRootFolder = documentRootFolder;
    }


    /**
     * Gets the forceCloseServedDocuments value for this ServerPreferences.
     * 
     * @return forceCloseServedDocuments
     */
    public boolean isForceCloseServedDocuments() {
        return forceCloseServedDocuments;
    }


    /**
     * Sets the forceCloseServedDocuments value for this ServerPreferences.
     * 
     * @param forceCloseServedDocuments
     */
    public void setForceCloseServedDocuments(boolean forceCloseServedDocuments) {
        this.forceCloseServedDocuments = forceCloseServedDocuments;
    }


    /**
     * Gets the scale value for this ServerPreferences.
     * 
     * @return scale
     */
    public int getScale() {
        return scale;
    }


    /**
     * Sets the scale value for this ServerPreferences.
     * 
     * @param scale
     */
    public void setScale(int scale) {
        this.scale = scale;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ServerPreferences)) return false;
        ServerPreferences other = (ServerPreferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.allowMemoryCaching == other.isAllowMemoryCaching() &&
            this.cacheSize == other.getCacheSize() &&
            ((this.defaultRenderType==null && other.getDefaultRenderType()==null) || 
             (this.defaultRenderType!=null &&
              this.defaultRenderType.equals(other.getDefaultRenderType()))) &&
            this.disableQuarkXPressDocumentReturn == other.isDisableQuarkXPressDocumentReturn() &&
            ((this.documentRootFolder==null && other.getDocumentRootFolder()==null) || 
             (this.documentRootFolder!=null &&
              this.documentRootFolder.equals(other.getDocumentRootFolder()))) &&
            this.forceCloseServedDocuments == other.isForceCloseServedDocuments() &&
            this.scale == other.getScale();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isAllowMemoryCaching() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getCacheSize();
        if (getDefaultRenderType() != null) {
            _hashCode += getDefaultRenderType().hashCode();
        }
        _hashCode += (isDisableQuarkXPressDocumentReturn() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getDocumentRootFolder() != null) {
            _hashCode += getDocumentRootFolder().hashCode();
        }
        _hashCode += (isForceCloseServedDocuments() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getScale();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ServerPreferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ServerPreferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowMemoryCaching");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "allowMemoryCaching"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cacheSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "cacheSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultRenderType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "defaultRenderType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("disableQuarkXPressDocumentReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "disableQuarkXPressDocumentReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentRootFolder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "documentRootFolder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("forceCloseServedDocuments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "forceCloseServedDocuments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scale");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scale"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
