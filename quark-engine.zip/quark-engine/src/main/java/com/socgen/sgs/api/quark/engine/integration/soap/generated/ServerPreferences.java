/**
 * ServerPreferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ServerPreferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private boolean allowFileToBeAdded;

    private boolean allowMemoryCaching;

    private int cacheSize;

    private int contentLoadingTimeout;

    private java.lang.String defaultDocument;

    private java.lang.String defaultRenderType;

    private boolean disableQuarkXPressDocumentReturn;

    private java.lang.String documentRootFolder;

    private boolean enableFileSystemDocPool;

    private java.lang.String errorDocument;

    private boolean forceCloseServedDocuments;

    private boolean generateHierarchyOnAddfile;

    private java.lang.String noAccessDocument;

    private int scale;

    public ServerPreferences() {
    }

    public ServerPreferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           boolean allowFileToBeAdded,
           boolean allowMemoryCaching,
           int cacheSize,
           int contentLoadingTimeout,
           java.lang.String defaultDocument,
           java.lang.String defaultRenderType,
           boolean disableQuarkXPressDocumentReturn,
           java.lang.String documentRootFolder,
           boolean enableFileSystemDocPool,
           java.lang.String errorDocument,
           boolean forceCloseServedDocuments,
           boolean generateHierarchyOnAddfile,
           java.lang.String noAccessDocument,
           int scale) {
        super(
            request);
        this.allowFileToBeAdded = allowFileToBeAdded;
        this.allowMemoryCaching = allowMemoryCaching;
        this.cacheSize = cacheSize;
        this.contentLoadingTimeout = contentLoadingTimeout;
        this.defaultDocument = defaultDocument;
        this.defaultRenderType = defaultRenderType;
        this.disableQuarkXPressDocumentReturn = disableQuarkXPressDocumentReturn;
        this.documentRootFolder = documentRootFolder;
        this.enableFileSystemDocPool = enableFileSystemDocPool;
        this.errorDocument = errorDocument;
        this.forceCloseServedDocuments = forceCloseServedDocuments;
        this.generateHierarchyOnAddfile = generateHierarchyOnAddfile;
        this.noAccessDocument = noAccessDocument;
        this.scale = scale;
    }


    /**
     * Gets the allowFileToBeAdded value for this ServerPreferences.
     * 
     * @return allowFileToBeAdded
     */
    public boolean isAllowFileToBeAdded() {
        return allowFileToBeAdded;
    }


    /**
     * Sets the allowFileToBeAdded value for this ServerPreferences.
     * 
     * @param allowFileToBeAdded
     */
    public void setAllowFileToBeAdded(boolean allowFileToBeAdded) {
        this.allowFileToBeAdded = allowFileToBeAdded;
    }


    /**
     * Gets the allowMemoryCaching value for this ServerPreferences.
     * 
     * @return allowMemoryCaching
     */
    public boolean isAllowMemoryCaching() {
        return allowMemoryCaching;
    }


    /**
     * Sets the allowMemoryCaching value for this ServerPreferences.
     * 
     * @param allowMemoryCaching
     */
    public void setAllowMemoryCaching(boolean allowMemoryCaching) {
        this.allowMemoryCaching = allowMemoryCaching;
    }


    /**
     * Gets the cacheSize value for this ServerPreferences.
     * 
     * @return cacheSize
     */
    public int getCacheSize() {
        return cacheSize;
    }


    /**
     * Sets the cacheSize value for this ServerPreferences.
     * 
     * @param cacheSize
     */
    public void setCacheSize(int cacheSize) {
        this.cacheSize = cacheSize;
    }


    /**
     * Gets the contentLoadingTimeout value for this ServerPreferences.
     * 
     * @return contentLoadingTimeout
     */
    public int getContentLoadingTimeout() {
        return contentLoadingTimeout;
    }


    /**
     * Sets the contentLoadingTimeout value for this ServerPreferences.
     * 
     * @param contentLoadingTimeout
     */
    public void setContentLoadingTimeout(int contentLoadingTimeout) {
        this.contentLoadingTimeout = contentLoadingTimeout;
    }


    /**
     * Gets the defaultDocument value for this ServerPreferences.
     * 
     * @return defaultDocument
     */
    public java.lang.String getDefaultDocument() {
        return defaultDocument;
    }


    /**
     * Sets the defaultDocument value for this ServerPreferences.
     * 
     * @param defaultDocument
     */
    public void setDefaultDocument(java.lang.String defaultDocument) {
        this.defaultDocument = defaultDocument;
    }


    /**
     * Gets the defaultRenderType value for this ServerPreferences.
     * 
     * @return defaultRenderType
     */
    public java.lang.String getDefaultRenderType() {
        return defaultRenderType;
    }


    /**
     * Sets the defaultRenderType value for this ServerPreferences.
     * 
     * @param defaultRenderType
     */
    public void setDefaultRenderType(java.lang.String defaultRenderType) {
        this.defaultRenderType = defaultRenderType;
    }


    /**
     * Gets the disableQuarkXPressDocumentReturn value for this ServerPreferences.
     * 
     * @return disableQuarkXPressDocumentReturn
     */
    public boolean isDisableQuarkXPressDocumentReturn() {
        return disableQuarkXPressDocumentReturn;
    }


    /**
     * Sets the disableQuarkXPressDocumentReturn value for this ServerPreferences.
     * 
     * @param disableQuarkXPressDocumentReturn
     */
    public void setDisableQuarkXPressDocumentReturn(boolean disableQuarkXPressDocumentReturn) {
        this.disableQuarkXPressDocumentReturn = disableQuarkXPressDocumentReturn;
    }


    /**
     * Gets the documentRootFolder value for this ServerPreferences.
     * 
     * @return documentRootFolder
     */
    public java.lang.String getDocumentRootFolder() {
        return documentRootFolder;
    }


    /**
     * Sets the documentRootFolder value for this ServerPreferences.
     * 
     * @param documentRootFolder
     */
    public void setDocumentRootFolder(java.lang.String documentRootFolder) {
        this.documentRootFolder = documentRootFolder;
    }


    /**
     * Gets the enableFileSystemDocPool value for this ServerPreferences.
     * 
     * @return enableFileSystemDocPool
     */
    public boolean isEnableFileSystemDocPool() {
        return enableFileSystemDocPool;
    }


    /**
     * Sets the enableFileSystemDocPool value for this ServerPreferences.
     * 
     * @param enableFileSystemDocPool
     */
    public void setEnableFileSystemDocPool(boolean enableFileSystemDocPool) {
        this.enableFileSystemDocPool = enableFileSystemDocPool;
    }


    /**
     * Gets the errorDocument value for this ServerPreferences.
     * 
     * @return errorDocument
     */
    public java.lang.String getErrorDocument() {
        return errorDocument;
    }


    /**
     * Sets the errorDocument value for this ServerPreferences.
     * 
     * @param errorDocument
     */
    public void setErrorDocument(java.lang.String errorDocument) {
        this.errorDocument = errorDocument;
    }


    /**
     * Gets the forceCloseServedDocuments value for this ServerPreferences.
     * 
     * @return forceCloseServedDocuments
     */
    public boolean isForceCloseServedDocuments() {
        return forceCloseServedDocuments;
    }


    /**
     * Sets the forceCloseServedDocuments value for this ServerPreferences.
     * 
     * @param forceCloseServedDocuments
     */
    public void setForceCloseServedDocuments(boolean forceCloseServedDocuments) {
        this.forceCloseServedDocuments = forceCloseServedDocuments;
    }


    /**
     * Gets the generateHierarchyOnAddfile value for this ServerPreferences.
     * 
     * @return generateHierarchyOnAddfile
     */
    public boolean isGenerateHierarchyOnAddfile() {
        return generateHierarchyOnAddfile;
    }


    /**
     * Sets the generateHierarchyOnAddfile value for this ServerPreferences.
     * 
     * @param generateHierarchyOnAddfile
     */
    public void setGenerateHierarchyOnAddfile(boolean generateHierarchyOnAddfile) {
        this.generateHierarchyOnAddfile = generateHierarchyOnAddfile;
    }


    /**
     * Gets the noAccessDocument value for this ServerPreferences.
     * 
     * @return noAccessDocument
     */
    public java.lang.String getNoAccessDocument() {
        return noAccessDocument;
    }


    /**
     * Sets the noAccessDocument value for this ServerPreferences.
     * 
     * @param noAccessDocument
     */
    public void setNoAccessDocument(java.lang.String noAccessDocument) {
        this.noAccessDocument = noAccessDocument;
    }


    /**
     * Gets the scale value for this ServerPreferences.
     * 
     * @return scale
     */
    public int getScale() {
        return scale;
    }


    /**
     * Sets the scale value for this ServerPreferences.
     * 
     * @param scale
     */
    public void setScale(int scale) {
        this.scale = scale;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ServerPreferences)) return false;
        ServerPreferences other = (ServerPreferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.allowFileToBeAdded == other.isAllowFileToBeAdded() &&
            this.allowMemoryCaching == other.isAllowMemoryCaching() &&
            this.cacheSize == other.getCacheSize() &&
            this.contentLoadingTimeout == other.getContentLoadingTimeout() &&
            ((this.defaultDocument==null && other.getDefaultDocument()==null) || 
             (this.defaultDocument!=null &&
              this.defaultDocument.equals(other.getDefaultDocument()))) &&
            ((this.defaultRenderType==null && other.getDefaultRenderType()==null) || 
             (this.defaultRenderType!=null &&
              this.defaultRenderType.equals(other.getDefaultRenderType()))) &&
            this.disableQuarkXPressDocumentReturn == other.isDisableQuarkXPressDocumentReturn() &&
            ((this.documentRootFolder==null && other.getDocumentRootFolder()==null) || 
             (this.documentRootFolder!=null &&
              this.documentRootFolder.equals(other.getDocumentRootFolder()))) &&
            this.enableFileSystemDocPool == other.isEnableFileSystemDocPool() &&
            ((this.errorDocument==null && other.getErrorDocument()==null) || 
             (this.errorDocument!=null &&
              this.errorDocument.equals(other.getErrorDocument()))) &&
            this.forceCloseServedDocuments == other.isForceCloseServedDocuments() &&
            this.generateHierarchyOnAddfile == other.isGenerateHierarchyOnAddfile() &&
            ((this.noAccessDocument==null && other.getNoAccessDocument()==null) || 
             (this.noAccessDocument!=null &&
              this.noAccessDocument.equals(other.getNoAccessDocument()))) &&
            this.scale == other.getScale();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isAllowFileToBeAdded() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isAllowMemoryCaching() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getCacheSize();
        _hashCode += getContentLoadingTimeout();
        if (getDefaultDocument() != null) {
            _hashCode += getDefaultDocument().hashCode();
        }
        if (getDefaultRenderType() != null) {
            _hashCode += getDefaultRenderType().hashCode();
        }
        _hashCode += (isDisableQuarkXPressDocumentReturn() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getDocumentRootFolder() != null) {
            _hashCode += getDocumentRootFolder().hashCode();
        }
        _hashCode += (isEnableFileSystemDocPool() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getErrorDocument() != null) {
            _hashCode += getErrorDocument().hashCode();
        }
        _hashCode += (isForceCloseServedDocuments() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isGenerateHierarchyOnAddfile() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getNoAccessDocument() != null) {
            _hashCode += getNoAccessDocument().hashCode();
        }
        _hashCode += getScale();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ServerPreferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ServerPreferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowFileToBeAdded");
        elemField.setXmlName(new javax.xml.namespace.QName("", "allowFileToBeAdded"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowMemoryCaching");
        elemField.setXmlName(new javax.xml.namespace.QName("", "allowMemoryCaching"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cacheSize");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cacheSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentLoadingTimeout");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contentLoadingTimeout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultDocument");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defaultDocument"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultRenderType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defaultRenderType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("disableQuarkXPressDocumentReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("", "disableQuarkXPressDocumentReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentRootFolder");
        elemField.setXmlName(new javax.xml.namespace.QName("", "documentRootFolder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enableFileSystemDocPool");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enableFileSystemDocPool"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorDocument");
        elemField.setXmlName(new javax.xml.namespace.QName("", "errorDocument"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("forceCloseServedDocuments");
        elemField.setXmlName(new javax.xml.namespace.QName("", "forceCloseServedDocuments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("generateHierarchyOnAddfile");
        elemField.setXmlName(new javax.xml.namespace.QName("", "generateHierarchyOnAddfile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noAccessDocument");
        elemField.setXmlName(new javax.xml.namespace.QName("", "noAccessDocument"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scale");
        elemField.setXmlName(new javax.xml.namespace.QName("", "scale"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
