/**
 * SplineShape.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class SplineShape  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String closedShape;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Contours contours;

    private java.lang.String hasHoles;

    private java.lang.String hasSplines;

    private java.lang.String incomplete;

    private java.lang.String invertedShape;

    private java.lang.String moreThanOneTopLevelContour;

    private java.lang.String newFormat;

    private java.lang.String rectShape;

    private java.lang.String tagsAllocated;

    private java.lang.String vertSelected;

    private java.lang.String wellformed;

    public SplineShape() {
    }

    public SplineShape(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String closedShape,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Contours contours,
           java.lang.String hasHoles,
           java.lang.String hasSplines,
           java.lang.String incomplete,
           java.lang.String invertedShape,
           java.lang.String moreThanOneTopLevelContour,
           java.lang.String newFormat,
           java.lang.String rectShape,
           java.lang.String tagsAllocated,
           java.lang.String vertSelected,
           java.lang.String wellformed) {
        super(
            request);
        this.closedShape = closedShape;
        this.contours = contours;
        this.hasHoles = hasHoles;
        this.hasSplines = hasSplines;
        this.incomplete = incomplete;
        this.invertedShape = invertedShape;
        this.moreThanOneTopLevelContour = moreThanOneTopLevelContour;
        this.newFormat = newFormat;
        this.rectShape = rectShape;
        this.tagsAllocated = tagsAllocated;
        this.vertSelected = vertSelected;
        this.wellformed = wellformed;
    }


    /**
     * Gets the closedShape value for this SplineShape.
     * 
     * @return closedShape
     */
    public java.lang.String getClosedShape() {
        return closedShape;
    }


    /**
     * Sets the closedShape value for this SplineShape.
     * 
     * @param closedShape
     */
    public void setClosedShape(java.lang.String closedShape) {
        this.closedShape = closedShape;
    }


    /**
     * Gets the contours value for this SplineShape.
     * 
     * @return contours
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Contours getContours() {
        return contours;
    }


    /**
     * Sets the contours value for this SplineShape.
     * 
     * @param contours
     */
    public void setContours(com.socgen.sgs.api.quark.engine.integration.soap.generated.Contours contours) {
        this.contours = contours;
    }


    /**
     * Gets the hasHoles value for this SplineShape.
     * 
     * @return hasHoles
     */
    public java.lang.String getHasHoles() {
        return hasHoles;
    }


    /**
     * Sets the hasHoles value for this SplineShape.
     * 
     * @param hasHoles
     */
    public void setHasHoles(java.lang.String hasHoles) {
        this.hasHoles = hasHoles;
    }


    /**
     * Gets the hasSplines value for this SplineShape.
     * 
     * @return hasSplines
     */
    public java.lang.String getHasSplines() {
        return hasSplines;
    }


    /**
     * Sets the hasSplines value for this SplineShape.
     * 
     * @param hasSplines
     */
    public void setHasSplines(java.lang.String hasSplines) {
        this.hasSplines = hasSplines;
    }


    /**
     * Gets the incomplete value for this SplineShape.
     * 
     * @return incomplete
     */
    public java.lang.String getIncomplete() {
        return incomplete;
    }


    /**
     * Sets the incomplete value for this SplineShape.
     * 
     * @param incomplete
     */
    public void setIncomplete(java.lang.String incomplete) {
        this.incomplete = incomplete;
    }


    /**
     * Gets the invertedShape value for this SplineShape.
     * 
     * @return invertedShape
     */
    public java.lang.String getInvertedShape() {
        return invertedShape;
    }


    /**
     * Sets the invertedShape value for this SplineShape.
     * 
     * @param invertedShape
     */
    public void setInvertedShape(java.lang.String invertedShape) {
        this.invertedShape = invertedShape;
    }


    /**
     * Gets the moreThanOneTopLevelContour value for this SplineShape.
     * 
     * @return moreThanOneTopLevelContour
     */
    public java.lang.String getMoreThanOneTopLevelContour() {
        return moreThanOneTopLevelContour;
    }


    /**
     * Sets the moreThanOneTopLevelContour value for this SplineShape.
     * 
     * @param moreThanOneTopLevelContour
     */
    public void setMoreThanOneTopLevelContour(java.lang.String moreThanOneTopLevelContour) {
        this.moreThanOneTopLevelContour = moreThanOneTopLevelContour;
    }


    /**
     * Gets the newFormat value for this SplineShape.
     * 
     * @return newFormat
     */
    public java.lang.String getNewFormat() {
        return newFormat;
    }


    /**
     * Sets the newFormat value for this SplineShape.
     * 
     * @param newFormat
     */
    public void setNewFormat(java.lang.String newFormat) {
        this.newFormat = newFormat;
    }


    /**
     * Gets the rectShape value for this SplineShape.
     * 
     * @return rectShape
     */
    public java.lang.String getRectShape() {
        return rectShape;
    }


    /**
     * Sets the rectShape value for this SplineShape.
     * 
     * @param rectShape
     */
    public void setRectShape(java.lang.String rectShape) {
        this.rectShape = rectShape;
    }


    /**
     * Gets the tagsAllocated value for this SplineShape.
     * 
     * @return tagsAllocated
     */
    public java.lang.String getTagsAllocated() {
        return tagsAllocated;
    }


    /**
     * Sets the tagsAllocated value for this SplineShape.
     * 
     * @param tagsAllocated
     */
    public void setTagsAllocated(java.lang.String tagsAllocated) {
        this.tagsAllocated = tagsAllocated;
    }


    /**
     * Gets the vertSelected value for this SplineShape.
     * 
     * @return vertSelected
     */
    public java.lang.String getVertSelected() {
        return vertSelected;
    }


    /**
     * Sets the vertSelected value for this SplineShape.
     * 
     * @param vertSelected
     */
    public void setVertSelected(java.lang.String vertSelected) {
        this.vertSelected = vertSelected;
    }


    /**
     * Gets the wellformed value for this SplineShape.
     * 
     * @return wellformed
     */
    public java.lang.String getWellformed() {
        return wellformed;
    }


    /**
     * Sets the wellformed value for this SplineShape.
     * 
     * @param wellformed
     */
    public void setWellformed(java.lang.String wellformed) {
        this.wellformed = wellformed;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SplineShape)) return false;
        SplineShape other = (SplineShape) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.closedShape==null && other.getClosedShape()==null) || 
             (this.closedShape!=null &&
              this.closedShape.equals(other.getClosedShape()))) &&
            ((this.contours==null && other.getContours()==null) || 
             (this.contours!=null &&
              this.contours.equals(other.getContours()))) &&
            ((this.hasHoles==null && other.getHasHoles()==null) || 
             (this.hasHoles!=null &&
              this.hasHoles.equals(other.getHasHoles()))) &&
            ((this.hasSplines==null && other.getHasSplines()==null) || 
             (this.hasSplines!=null &&
              this.hasSplines.equals(other.getHasSplines()))) &&
            ((this.incomplete==null && other.getIncomplete()==null) || 
             (this.incomplete!=null &&
              this.incomplete.equals(other.getIncomplete()))) &&
            ((this.invertedShape==null && other.getInvertedShape()==null) || 
             (this.invertedShape!=null &&
              this.invertedShape.equals(other.getInvertedShape()))) &&
            ((this.moreThanOneTopLevelContour==null && other.getMoreThanOneTopLevelContour()==null) || 
             (this.moreThanOneTopLevelContour!=null &&
              this.moreThanOneTopLevelContour.equals(other.getMoreThanOneTopLevelContour()))) &&
            ((this.newFormat==null && other.getNewFormat()==null) || 
             (this.newFormat!=null &&
              this.newFormat.equals(other.getNewFormat()))) &&
            ((this.rectShape==null && other.getRectShape()==null) || 
             (this.rectShape!=null &&
              this.rectShape.equals(other.getRectShape()))) &&
            ((this.tagsAllocated==null && other.getTagsAllocated()==null) || 
             (this.tagsAllocated!=null &&
              this.tagsAllocated.equals(other.getTagsAllocated()))) &&
            ((this.vertSelected==null && other.getVertSelected()==null) || 
             (this.vertSelected!=null &&
              this.vertSelected.equals(other.getVertSelected()))) &&
            ((this.wellformed==null && other.getWellformed()==null) || 
             (this.wellformed!=null &&
              this.wellformed.equals(other.getWellformed())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getClosedShape() != null) {
            _hashCode += getClosedShape().hashCode();
        }
        if (getContours() != null) {
            _hashCode += getContours().hashCode();
        }
        if (getHasHoles() != null) {
            _hashCode += getHasHoles().hashCode();
        }
        if (getHasSplines() != null) {
            _hashCode += getHasSplines().hashCode();
        }
        if (getIncomplete() != null) {
            _hashCode += getIncomplete().hashCode();
        }
        if (getInvertedShape() != null) {
            _hashCode += getInvertedShape().hashCode();
        }
        if (getMoreThanOneTopLevelContour() != null) {
            _hashCode += getMoreThanOneTopLevelContour().hashCode();
        }
        if (getNewFormat() != null) {
            _hashCode += getNewFormat().hashCode();
        }
        if (getRectShape() != null) {
            _hashCode += getRectShape().hashCode();
        }
        if (getTagsAllocated() != null) {
            _hashCode += getTagsAllocated().hashCode();
        }
        if (getVertSelected() != null) {
            _hashCode += getVertSelected().hashCode();
        }
        if (getWellformed() != null) {
            _hashCode += getWellformed().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SplineShape.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "SplineShape"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("closedShape");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "closedShape"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contours");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "contours"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Contours"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hasHoles");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hasHoles"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hasSplines");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hasSplines"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("incomplete");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "incomplete"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invertedShape");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "invertedShape"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moreThanOneTopLevelContour");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "moreThanOneTopLevelContour"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("newFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "newFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rectShape");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rectShape"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tagsAllocated");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tagsAllocated"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vertSelected");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "vertSelected"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wellformed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "wellformed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
