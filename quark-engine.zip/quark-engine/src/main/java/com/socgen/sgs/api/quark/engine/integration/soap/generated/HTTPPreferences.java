/**
 * HTTPPreferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class HTTPPreferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RequireAdminVerification adminVerification;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterConfig connectionFilterConfiguration;

    private int connectionTimeout;

    private int defaultBufferSize;

    private boolean enableHTTPInterface;

    private int maxConnections;

    private int maxListens;

    private int portNumber;

    private boolean useConnectionFilters;

    public HTTPPreferences() {
    }

    public HTTPPreferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RequireAdminVerification adminVerification,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterConfig connectionFilterConfiguration,
           int connectionTimeout,
           int defaultBufferSize,
           boolean enableHTTPInterface,
           int maxConnections,
           int maxListens,
           int portNumber,
           boolean useConnectionFilters) {
        super(
            request);
        this.adminVerification = adminVerification;
        this.connectionFilterConfiguration = connectionFilterConfiguration;
        this.connectionTimeout = connectionTimeout;
        this.defaultBufferSize = defaultBufferSize;
        this.enableHTTPInterface = enableHTTPInterface;
        this.maxConnections = maxConnections;
        this.maxListens = maxListens;
        this.portNumber = portNumber;
        this.useConnectionFilters = useConnectionFilters;
    }


    /**
     * Gets the adminVerification value for this HTTPPreferences.
     * 
     * @return adminVerification
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RequireAdminVerification getAdminVerification() {
        return adminVerification;
    }


    /**
     * Sets the adminVerification value for this HTTPPreferences.
     * 
     * @param adminVerification
     */
    public void setAdminVerification(com.socgen.sgs.api.quark.engine.integration.soap.generated.RequireAdminVerification adminVerification) {
        this.adminVerification = adminVerification;
    }


    /**
     * Gets the connectionFilterConfiguration value for this HTTPPreferences.
     * 
     * @return connectionFilterConfiguration
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterConfig getConnectionFilterConfiguration() {
        return connectionFilterConfiguration;
    }


    /**
     * Sets the connectionFilterConfiguration value for this HTTPPreferences.
     * 
     * @param connectionFilterConfiguration
     */
    public void setConnectionFilterConfiguration(com.socgen.sgs.api.quark.engine.integration.soap.generated.ConnectionFilterConfig connectionFilterConfiguration) {
        this.connectionFilterConfiguration = connectionFilterConfiguration;
    }


    /**
     * Gets the connectionTimeout value for this HTTPPreferences.
     * 
     * @return connectionTimeout
     */
    public int getConnectionTimeout() {
        return connectionTimeout;
    }


    /**
     * Sets the connectionTimeout value for this HTTPPreferences.
     * 
     * @param connectionTimeout
     */
    public void setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }


    /**
     * Gets the defaultBufferSize value for this HTTPPreferences.
     * 
     * @return defaultBufferSize
     */
    public int getDefaultBufferSize() {
        return defaultBufferSize;
    }


    /**
     * Sets the defaultBufferSize value for this HTTPPreferences.
     * 
     * @param defaultBufferSize
     */
    public void setDefaultBufferSize(int defaultBufferSize) {
        this.defaultBufferSize = defaultBufferSize;
    }


    /**
     * Gets the enableHTTPInterface value for this HTTPPreferences.
     * 
     * @return enableHTTPInterface
     */
    public boolean isEnableHTTPInterface() {
        return enableHTTPInterface;
    }


    /**
     * Sets the enableHTTPInterface value for this HTTPPreferences.
     * 
     * @param enableHTTPInterface
     */
    public void setEnableHTTPInterface(boolean enableHTTPInterface) {
        this.enableHTTPInterface = enableHTTPInterface;
    }


    /**
     * Gets the maxConnections value for this HTTPPreferences.
     * 
     * @return maxConnections
     */
    public int getMaxConnections() {
        return maxConnections;
    }


    /**
     * Sets the maxConnections value for this HTTPPreferences.
     * 
     * @param maxConnections
     */
    public void setMaxConnections(int maxConnections) {
        this.maxConnections = maxConnections;
    }


    /**
     * Gets the maxListens value for this HTTPPreferences.
     * 
     * @return maxListens
     */
    public int getMaxListens() {
        return maxListens;
    }


    /**
     * Sets the maxListens value for this HTTPPreferences.
     * 
     * @param maxListens
     */
    public void setMaxListens(int maxListens) {
        this.maxListens = maxListens;
    }


    /**
     * Gets the portNumber value for this HTTPPreferences.
     * 
     * @return portNumber
     */
    public int getPortNumber() {
        return portNumber;
    }


    /**
     * Sets the portNumber value for this HTTPPreferences.
     * 
     * @param portNumber
     */
    public void setPortNumber(int portNumber) {
        this.portNumber = portNumber;
    }


    /**
     * Gets the useConnectionFilters value for this HTTPPreferences.
     * 
     * @return useConnectionFilters
     */
    public boolean isUseConnectionFilters() {
        return useConnectionFilters;
    }


    /**
     * Sets the useConnectionFilters value for this HTTPPreferences.
     * 
     * @param useConnectionFilters
     */
    public void setUseConnectionFilters(boolean useConnectionFilters) {
        this.useConnectionFilters = useConnectionFilters;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HTTPPreferences)) return false;
        HTTPPreferences other = (HTTPPreferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.adminVerification==null && other.getAdminVerification()==null) || 
             (this.adminVerification!=null &&
              this.adminVerification.equals(other.getAdminVerification()))) &&
            ((this.connectionFilterConfiguration==null && other.getConnectionFilterConfiguration()==null) || 
             (this.connectionFilterConfiguration!=null &&
              this.connectionFilterConfiguration.equals(other.getConnectionFilterConfiguration()))) &&
            this.connectionTimeout == other.getConnectionTimeout() &&
            this.defaultBufferSize == other.getDefaultBufferSize() &&
            this.enableHTTPInterface == other.isEnableHTTPInterface() &&
            this.maxConnections == other.getMaxConnections() &&
            this.maxListens == other.getMaxListens() &&
            this.portNumber == other.getPortNumber() &&
            this.useConnectionFilters == other.isUseConnectionFilters();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAdminVerification() != null) {
            _hashCode += getAdminVerification().hashCode();
        }
        if (getConnectionFilterConfiguration() != null) {
            _hashCode += getConnectionFilterConfiguration().hashCode();
        }
        _hashCode += getConnectionTimeout();
        _hashCode += getDefaultBufferSize();
        _hashCode += (isEnableHTTPInterface() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getMaxConnections();
        _hashCode += getMaxListens();
        _hashCode += getPortNumber();
        _hashCode += (isUseConnectionFilters() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HTTPPreferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "HTTPPreferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adminVerification");
        elemField.setXmlName(new javax.xml.namespace.QName("", "adminVerification"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RequireAdminVerification"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("connectionFilterConfiguration");
        elemField.setXmlName(new javax.xml.namespace.QName("", "connectionFilterConfiguration"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterConfig"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("connectionTimeout");
        elemField.setXmlName(new javax.xml.namespace.QName("", "connectionTimeout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultBufferSize");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defaultBufferSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enableHTTPInterface");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enableHTTPInterface"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxConnections");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maxConnections"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxListens");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maxListens"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("portNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "portNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("useConnectionFilters");
        elemField.setXmlName(new javax.xml.namespace.QName("", "useConnectionFilters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
