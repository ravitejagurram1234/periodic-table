package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;

/**
 * DAO for loading the last certified QXP for a suivi + report type, used by QXP_Previous tasks.
 * Cross-reference: .NET QXPS_File_Manager.Get_Last_Qxp_Certifie → Oracle QXP_PK_RUN.Get_Last_Qxp_Certifie.
 *
 * <p>ora.txt signature: p_id_suivi NUMBER, p_id_type_rapport NUMBER (langue is derived inside the
 * SQL from the current suivi — there is NO langue parameter).
 */
public interface GetLastQxpCertifieDao {

    /**
     * Load the most recent certified QXP for the given suivi and report type
     * (idTypeRapport = 0 matches any report type).
     *
     * @return the document (id/name/format=QXP/data, prefix "D"), or null if none found
     */
    DocumentDomain getLastQxpCertifie(int idSuivi, int idTypeRapport);
}