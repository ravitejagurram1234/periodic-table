package com.socgen.sgs.api.quark.engine.infra.interop.qxps.helper;

import com.socgen.sgs.api.quark.engine.infra.interop.qxps.client.QxpsHttpClient;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.message.AddFileMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class QxpsHelper {

    private final QxpsHttpClient qxpsHttpClient;

    public void addFile(String documentName, byte[] data) {
        AddFileMessage message = new AddFileMessage(data);
        qxpsHttpClient.execute(documentName, message);
        log.info("File added to QXPS document pool: {}", documentName);
    }
}

