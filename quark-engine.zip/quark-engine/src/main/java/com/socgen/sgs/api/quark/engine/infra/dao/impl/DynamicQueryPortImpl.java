package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.InParam;
import com.socgen.sgs.api.quark.engine.domain.port.DynamicQueryPort;
import com.socgen.sgs.api.quark.engine.infra.dao.TaskSqlDao;
import com.socgen.sgs.api.quark.engine.mapper.InParamSqlMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Infrastructure implementation of DynamicQueryPort.
 * Reuses existing TaskSqlDao for SQL execution and InParamSqlMapper for parameter conversion.
 *
 * Cross-reference: .NET Proxy_Generic.GetReader() used in Process_Dynamique.Get_Report()
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class DynamicQueryPortImpl implements DynamicQueryPort {

    private final TaskSqlDao taskSqlDao;
    private final InParamSqlMapper inParamSqlMapper;

    @Override
    public List<Map<String, Object>> executeQuery(String sql, Map<String, InParam> parameters) {
        if (sql == null || sql.isBlank()) {
            log.warn("Empty SQL provided to DynamicQueryPort, returning empty result");
            return Collections.emptyList();
        }

        log.debug("DynamicQueryPort executing SQL with {} parameters",
                parameters != null ? parameters.size() : 0);

        try {
            Map<String, Object> jdbcParams = inParamSqlMapper.toParameterMap(
                    parameters != null ? parameters : Collections.emptyMap());

            List<Map<String, Object>> results = taskSqlDao.executeSql(sql, jdbcParams);

            log.debug("DynamicQueryPort returned {} rows", results.size());
            return results;

        } catch (Exception e) {
            log.error("DynamicQueryPort SQL execution failed: {}", e.getMessage(), e);
            throw new RuntimeException("Dynamic query execution failed", e);
        }
    }
}