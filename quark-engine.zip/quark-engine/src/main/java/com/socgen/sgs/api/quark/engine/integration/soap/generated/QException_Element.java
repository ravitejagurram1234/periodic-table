/**
 * QException_Element.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class QException_Element  extends org.apache.axis.AxisFault  implements java.io.Serializable {
    private java.lang.String HTTPResponseCode;

    private java.lang.String managerErrorCode;

    private java.lang.String managerErrorMessage;

    private java.lang.String serverErrorCode;

    private java.lang.String serverErrorMessage;

    private java.lang.String serverExtendedMessage;

    public QException_Element() {
    }

    public QException_Element(
           java.lang.String HTTPResponseCode,
           java.lang.String managerErrorCode,
           java.lang.String managerErrorMessage,
           java.lang.String serverErrorCode,
           java.lang.String serverErrorMessage,
           java.lang.String serverExtendedMessage) {
        this.HTTPResponseCode = HTTPResponseCode;
        this.managerErrorCode = managerErrorCode;
        this.managerErrorMessage = managerErrorMessage;
        this.serverErrorCode = serverErrorCode;
        this.serverErrorMessage = serverErrorMessage;
        this.serverExtendedMessage = serverExtendedMessage;
    }


    /**
     * Gets the HTTPResponseCode value for this QException_Element.
     * 
     * @return HTTPResponseCode
     */
    public java.lang.String getHTTPResponseCode() {
        return HTTPResponseCode;
    }


    /**
     * Sets the HTTPResponseCode value for this QException_Element.
     * 
     * @param HTTPResponseCode
     */
    public void setHTTPResponseCode(java.lang.String HTTPResponseCode) {
        this.HTTPResponseCode = HTTPResponseCode;
    }


    /**
     * Gets the managerErrorCode value for this QException_Element.
     * 
     * @return managerErrorCode
     */
    public java.lang.String getManagerErrorCode() {
        return managerErrorCode;
    }


    /**
     * Sets the managerErrorCode value for this QException_Element.
     * 
     * @param managerErrorCode
     */
    public void setManagerErrorCode(java.lang.String managerErrorCode) {
        this.managerErrorCode = managerErrorCode;
    }


    /**
     * Gets the managerErrorMessage value for this QException_Element.
     * 
     * @return managerErrorMessage
     */
    public java.lang.String getManagerErrorMessage() {
        return managerErrorMessage;
    }


    /**
     * Sets the managerErrorMessage value for this QException_Element.
     * 
     * @param managerErrorMessage
     */
    public void setManagerErrorMessage(java.lang.String managerErrorMessage) {
        this.managerErrorMessage = managerErrorMessage;
    }


    /**
     * Gets the serverErrorCode value for this QException_Element.
     * 
     * @return serverErrorCode
     */
    public java.lang.String getServerErrorCode() {
        return serverErrorCode;
    }


    /**
     * Sets the serverErrorCode value for this QException_Element.
     * 
     * @param serverErrorCode
     */
    public void setServerErrorCode(java.lang.String serverErrorCode) {
        this.serverErrorCode = serverErrorCode;
    }


    /**
     * Gets the serverErrorMessage value for this QException_Element.
     * 
     * @return serverErrorMessage
     */
    public java.lang.String getServerErrorMessage() {
        return serverErrorMessage;
    }


    /**
     * Sets the serverErrorMessage value for this QException_Element.
     * 
     * @param serverErrorMessage
     */
    public void setServerErrorMessage(java.lang.String serverErrorMessage) {
        this.serverErrorMessage = serverErrorMessage;
    }


    /**
     * Gets the serverExtendedMessage value for this QException_Element.
     * 
     * @return serverExtendedMessage
     */
    public java.lang.String getServerExtendedMessage() {
        return serverExtendedMessage;
    }


    /**
     * Sets the serverExtendedMessage value for this QException_Element.
     * 
     * @param serverExtendedMessage
     */
    public void setServerExtendedMessage(java.lang.String serverExtendedMessage) {
        this.serverExtendedMessage = serverExtendedMessage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QException_Element)) return false;
        QException_Element other = (QException_Element) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.HTTPResponseCode==null && other.getHTTPResponseCode()==null) || 
             (this.HTTPResponseCode!=null &&
              this.HTTPResponseCode.equals(other.getHTTPResponseCode()))) &&
            ((this.managerErrorCode==null && other.getManagerErrorCode()==null) || 
             (this.managerErrorCode!=null &&
              this.managerErrorCode.equals(other.getManagerErrorCode()))) &&
            ((this.managerErrorMessage==null && other.getManagerErrorMessage()==null) || 
             (this.managerErrorMessage!=null &&
              this.managerErrorMessage.equals(other.getManagerErrorMessage()))) &&
            ((this.serverErrorCode==null && other.getServerErrorCode()==null) || 
             (this.serverErrorCode!=null &&
              this.serverErrorCode.equals(other.getServerErrorCode()))) &&
            ((this.serverErrorMessage==null && other.getServerErrorMessage()==null) || 
             (this.serverErrorMessage!=null &&
              this.serverErrorMessage.equals(other.getServerErrorMessage()))) &&
            ((this.serverExtendedMessage==null && other.getServerExtendedMessage()==null) || 
             (this.serverExtendedMessage!=null &&
              this.serverExtendedMessage.equals(other.getServerExtendedMessage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHTTPResponseCode() != null) {
            _hashCode += getHTTPResponseCode().hashCode();
        }
        if (getManagerErrorCode() != null) {
            _hashCode += getManagerErrorCode().hashCode();
        }
        if (getManagerErrorMessage() != null) {
            _hashCode += getManagerErrorMessage().hashCode();
        }
        if (getServerErrorCode() != null) {
            _hashCode += getServerErrorCode().hashCode();
        }
        if (getServerErrorMessage() != null) {
            _hashCode += getServerErrorMessage().hashCode();
        }
        if (getServerExtendedMessage() != null) {
            _hashCode += getServerExtendedMessage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QException_Element.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", ">QException"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HTTPResponseCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HTTPResponseCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("managerErrorCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "managerErrorCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("managerErrorMessage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "managerErrorMessage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverErrorCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "serverErrorCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverErrorMessage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "serverErrorMessage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverExtendedMessage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "serverExtendedMessage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }


    /**
     * Writes the exception data to the faultDetails
     */
    public void writeDetails(javax.xml.namespace.QName qname, org.apache.axis.encoding.SerializationContext context) throws java.io.IOException {
        context.serialize(qname, null, this);
    }
}
