/**
 * QManagerSDKSvcServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class QManagerSDKSvcServiceLocator extends org.apache.axis.client.Service implements com.socgen.sgs.api.quark.engine.integration.soap.generated.QManagerSDKSvcService {

    public QManagerSDKSvcServiceLocator() {
    }


    public QManagerSDKSvcServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public QManagerSDKSvcServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for qxpsmsdk
    private java.lang.String qxpsmsdk_address = "http://localhost:8090/quark/services/qxpsmsdk";

    public java.lang.String getqxpsmsdkAddress() {
        return qxpsmsdk_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String qxpsmsdkWSDDServiceName = "qxpsmsdk";

    public java.lang.String getqxpsmsdkWSDDServiceName() {
        return qxpsmsdkWSDDServiceName;
    }

    public void setqxpsmsdkWSDDServiceName(java.lang.String name) {
        qxpsmsdkWSDDServiceName = name;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QManagerSDKSvc getqxpsmsdk() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(qxpsmsdk_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getqxpsmsdk(endpoint);
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QManagerSDKSvc getqxpsmsdk(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.socgen.sgs.api.quark.engine.integration.soap.generated.QxpsmsdkSoapBindingStub _stub = new com.socgen.sgs.api.quark.engine.integration.soap.generated.QxpsmsdkSoapBindingStub(portAddress, this);
            _stub.setPortName(getqxpsmsdkWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setqxpsmsdkEndpointAddress(java.lang.String address) {
        qxpsmsdk_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.socgen.sgs.api.quark.engine.integration.soap.generated.QManagerSDKSvc.class.isAssignableFrom(serviceEndpointInterface)) {
                com.socgen.sgs.api.quark.engine.integration.soap.generated.QxpsmsdkSoapBindingStub _stub = new com.socgen.sgs.api.quark.engine.integration.soap.generated.QxpsmsdkSoapBindingStub(new java.net.URL(qxpsmsdk_address), this);
                _stub.setPortName(getqxpsmsdkWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("qxpsmsdk".equals(inputPortName)) {
            return getqxpsmsdk();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://webservice.manager.quark.com", "QManagerSDKSvcService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://webservice.manager.quark.com", "qxpsmsdk"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("qxpsmsdk".equals(portName)) {
            setqxpsmsdkEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
