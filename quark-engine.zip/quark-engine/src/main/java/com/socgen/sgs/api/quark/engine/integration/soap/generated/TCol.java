/**
 * TCol.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class TCol  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String blendMode;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border;

    private java.lang.String colIndex;

    private java.lang.String color;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftGrid leftGrid;

    private java.lang.String maxWidth;

    private java.lang.String minWidth;

    private java.lang.String opacity;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RightGrid rightGrid;

    private java.lang.String shade;

    private java.lang.String storyDirection;

    private java.lang.String width;

    public TCol() {
    }

    public TCol(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String blendMode,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border,
           java.lang.String colIndex,
           java.lang.String color,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftGrid leftGrid,
           java.lang.String maxWidth,
           java.lang.String minWidth,
           java.lang.String opacity,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RightGrid rightGrid,
           java.lang.String shade,
           java.lang.String storyDirection,
           java.lang.String width) {
        super(
            request);
        this.blendMode = blendMode;
        this.border = border;
        this.colIndex = colIndex;
        this.color = color;
        this.inset = inset;
        this.leftGrid = leftGrid;
        this.maxWidth = maxWidth;
        this.minWidth = minWidth;
        this.opacity = opacity;
        this.rightGrid = rightGrid;
        this.shade = shade;
        this.storyDirection = storyDirection;
        this.width = width;
    }


    /**
     * Gets the blendMode value for this TCol.
     * 
     * @return blendMode
     */
    public java.lang.String getBlendMode() {
        return blendMode;
    }


    /**
     * Sets the blendMode value for this TCol.
     * 
     * @param blendMode
     */
    public void setBlendMode(java.lang.String blendMode) {
        this.blendMode = blendMode;
    }


    /**
     * Gets the border value for this TCol.
     * 
     * @return border
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Border getBorder() {
        return border;
    }


    /**
     * Sets the border value for this TCol.
     * 
     * @param border
     */
    public void setBorder(com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border) {
        this.border = border;
    }


    /**
     * Gets the colIndex value for this TCol.
     * 
     * @return colIndex
     */
    public java.lang.String getColIndex() {
        return colIndex;
    }


    /**
     * Sets the colIndex value for this TCol.
     * 
     * @param colIndex
     */
    public void setColIndex(java.lang.String colIndex) {
        this.colIndex = colIndex;
    }


    /**
     * Gets the color value for this TCol.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this TCol.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the inset value for this TCol.
     * 
     * @return inset
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset getInset() {
        return inset;
    }


    /**
     * Sets the inset value for this TCol.
     * 
     * @param inset
     */
    public void setInset(com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset) {
        this.inset = inset;
    }


    /**
     * Gets the leftGrid value for this TCol.
     * 
     * @return leftGrid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftGrid getLeftGrid() {
        return leftGrid;
    }


    /**
     * Sets the leftGrid value for this TCol.
     * 
     * @param leftGrid
     */
    public void setLeftGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftGrid leftGrid) {
        this.leftGrid = leftGrid;
    }


    /**
     * Gets the maxWidth value for this TCol.
     * 
     * @return maxWidth
     */
    public java.lang.String getMaxWidth() {
        return maxWidth;
    }


    /**
     * Sets the maxWidth value for this TCol.
     * 
     * @param maxWidth
     */
    public void setMaxWidth(java.lang.String maxWidth) {
        this.maxWidth = maxWidth;
    }


    /**
     * Gets the minWidth value for this TCol.
     * 
     * @return minWidth
     */
    public java.lang.String getMinWidth() {
        return minWidth;
    }


    /**
     * Sets the minWidth value for this TCol.
     * 
     * @param minWidth
     */
    public void setMinWidth(java.lang.String minWidth) {
        this.minWidth = minWidth;
    }


    /**
     * Gets the opacity value for this TCol.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this TCol.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the rightGrid value for this TCol.
     * 
     * @return rightGrid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RightGrid getRightGrid() {
        return rightGrid;
    }


    /**
     * Sets the rightGrid value for this TCol.
     * 
     * @param rightGrid
     */
    public void setRightGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.RightGrid rightGrid) {
        this.rightGrid = rightGrid;
    }


    /**
     * Gets the shade value for this TCol.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this TCol.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the storyDirection value for this TCol.
     * 
     * @return storyDirection
     */
    public java.lang.String getStoryDirection() {
        return storyDirection;
    }


    /**
     * Sets the storyDirection value for this TCol.
     * 
     * @param storyDirection
     */
    public void setStoryDirection(java.lang.String storyDirection) {
        this.storyDirection = storyDirection;
    }


    /**
     * Gets the width value for this TCol.
     * 
     * @return width
     */
    public java.lang.String getWidth() {
        return width;
    }


    /**
     * Sets the width value for this TCol.
     * 
     * @param width
     */
    public void setWidth(java.lang.String width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TCol)) return false;
        TCol other = (TCol) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.blendMode==null && other.getBlendMode()==null) || 
             (this.blendMode!=null &&
              this.blendMode.equals(other.getBlendMode()))) &&
            ((this.border==null && other.getBorder()==null) || 
             (this.border!=null &&
              this.border.equals(other.getBorder()))) &&
            ((this.colIndex==null && other.getColIndex()==null) || 
             (this.colIndex!=null &&
              this.colIndex.equals(other.getColIndex()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.inset==null && other.getInset()==null) || 
             (this.inset!=null &&
              this.inset.equals(other.getInset()))) &&
            ((this.leftGrid==null && other.getLeftGrid()==null) || 
             (this.leftGrid!=null &&
              this.leftGrid.equals(other.getLeftGrid()))) &&
            ((this.maxWidth==null && other.getMaxWidth()==null) || 
             (this.maxWidth!=null &&
              this.maxWidth.equals(other.getMaxWidth()))) &&
            ((this.minWidth==null && other.getMinWidth()==null) || 
             (this.minWidth!=null &&
              this.minWidth.equals(other.getMinWidth()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.rightGrid==null && other.getRightGrid()==null) || 
             (this.rightGrid!=null &&
              this.rightGrid.equals(other.getRightGrid()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.storyDirection==null && other.getStoryDirection()==null) || 
             (this.storyDirection!=null &&
              this.storyDirection.equals(other.getStoryDirection()))) &&
            ((this.width==null && other.getWidth()==null) || 
             (this.width!=null &&
              this.width.equals(other.getWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBlendMode() != null) {
            _hashCode += getBlendMode().hashCode();
        }
        if (getBorder() != null) {
            _hashCode += getBorder().hashCode();
        }
        if (getColIndex() != null) {
            _hashCode += getColIndex().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getInset() != null) {
            _hashCode += getInset().hashCode();
        }
        if (getLeftGrid() != null) {
            _hashCode += getLeftGrid().hashCode();
        }
        if (getMaxWidth() != null) {
            _hashCode += getMaxWidth().hashCode();
        }
        if (getMinWidth() != null) {
            _hashCode += getMinWidth().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getRightGrid() != null) {
            _hashCode += getRightGrid().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getStoryDirection() != null) {
            _hashCode += getStoryDirection().hashCode();
        }
        if (getWidth() != null) {
            _hashCode += getWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TCol.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TCol"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("border");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "border"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Border"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("colIndex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "colIndex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Inset"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftGrid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "leftGrid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LeftGrid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "maxWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "minWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightGrid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rightGrid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RightGrid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("storyDirection");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "storyDirection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("width");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "width"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
