package com.socgen.sgs.api.quark.engine.service;

import com.socgen.sgs.api.quark.engine.domain.Run;

/**
 * Step 6: CHECK — Overflow detection, re-processing, and data collection.
 *
 * Cross-reference: .NET Run_Base.Check()
 */
public interface CheckService {

    /**
     * Execute the check step on a completed run.
     *
     * @param run the run after step execution
     */
    void check(Run run);
}