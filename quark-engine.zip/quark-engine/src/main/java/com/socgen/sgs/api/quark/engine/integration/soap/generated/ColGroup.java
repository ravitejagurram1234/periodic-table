/**
 * ColGroup.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ColGroup  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TCol[] tcols;

    public ColGroup() {
    }

    public ColGroup(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TCol[] tcols) {
        super(
            request);
        this.tcols = tcols;
    }


    /**
     * Gets the tcols value for this ColGroup.
     * 
     * @return tcols
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TCol[] getTcols() {
        return tcols;
    }


    /**
     * Sets the tcols value for this ColGroup.
     * 
     * @param tcols
     */
    public void setTcols(com.socgen.sgs.api.quark.engine.integration.soap.generated.TCol[] tcols) {
        this.tcols = tcols;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TCol getTcols(int i) {
        return this.tcols[i];
    }

    public void setTcols(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.TCol _value) {
        this.tcols[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ColGroup)) return false;
        ColGroup other = (ColGroup) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.tcols==null && other.getTcols()==null) || 
             (this.tcols!=null &&
              java.util.Arrays.equals(this.tcols, other.getTcols())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getTcols() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTcols());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTcols(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ColGroup.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColGroup"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tcols");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tcols"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TCol"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
