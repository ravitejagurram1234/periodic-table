/**
 * InlineBox.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class InlineBox  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignWithText;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxAttribute boxAttribute;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame;

    private java.lang.String HLAnchorRef;

    private java.lang.String HLType;

    private java.lang.String height;

    private java.lang.String hyperlinkRef;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity interactivity;

    private java.lang.String itemStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData;

    private java.lang.String name;

    private java.lang.String offset;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richtext;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround runaround;

    private java.lang.String scaleUp;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TextAttribute textAttribute;

    private java.lang.String width;

    public InlineBox() {
    }

    public InlineBox(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignWithText,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxAttribute boxAttribute,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame,
           java.lang.String HLAnchorRef,
           java.lang.String HLType,
           java.lang.String height,
           java.lang.String hyperlinkRef,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity interactivity,
           java.lang.String itemStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData,
           java.lang.String name,
           java.lang.String offset,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richtext,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround runaround,
           java.lang.String scaleUp,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TextAttribute textAttribute,
           java.lang.String width) {
        super(
            request);
        this.alignWithText = alignWithText;
        this.border = border;
        this.boxAttribute = boxAttribute;
        this.content = content;
        this.frame = frame;
        this.HLAnchorRef = HLAnchorRef;
        this.HLType = HLType;
        this.height = height;
        this.hyperlinkRef = hyperlinkRef;
        this.index = index;
        this.indexTerms = indexTerms;
        this.interactivity = interactivity;
        this.itemStyle = itemStyle;
        this.metaData = metaData;
        this.name = name;
        this.offset = offset;
        this.paragraphs = paragraphs;
        this.picture = picture;
        this.richtext = richtext;
        this.runaround = runaround;
        this.scaleUp = scaleUp;
        this.shadow = shadow;
        this.textAttribute = textAttribute;
        this.width = width;
    }


    /**
     * Gets the alignWithText value for this InlineBox.
     * 
     * @return alignWithText
     */
    public java.lang.String getAlignWithText() {
        return alignWithText;
    }


    /**
     * Sets the alignWithText value for this InlineBox.
     * 
     * @param alignWithText
     */
    public void setAlignWithText(java.lang.String alignWithText) {
        this.alignWithText = alignWithText;
    }


    /**
     * Gets the border value for this InlineBox.
     * 
     * @return border
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Border getBorder() {
        return border;
    }


    /**
     * Sets the border value for this InlineBox.
     * 
     * @param border
     */
    public void setBorder(com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border) {
        this.border = border;
    }


    /**
     * Gets the boxAttribute value for this InlineBox.
     * 
     * @return boxAttribute
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxAttribute getBoxAttribute() {
        return boxAttribute;
    }


    /**
     * Sets the boxAttribute value for this InlineBox.
     * 
     * @param boxAttribute
     */
    public void setBoxAttribute(com.socgen.sgs.api.quark.engine.integration.soap.generated.BoxAttribute boxAttribute) {
        this.boxAttribute = boxAttribute;
    }


    /**
     * Gets the content value for this InlineBox.
     * 
     * @return content
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Content getContent() {
        return content;
    }


    /**
     * Sets the content value for this InlineBox.
     * 
     * @param content
     */
    public void setContent(com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content) {
        this.content = content;
    }


    /**
     * Gets the frame value for this InlineBox.
     * 
     * @return frame
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame getFrame() {
        return frame;
    }


    /**
     * Sets the frame value for this InlineBox.
     * 
     * @param frame
     */
    public void setFrame(com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame) {
        this.frame = frame;
    }


    /**
     * Gets the HLAnchorRef value for this InlineBox.
     * 
     * @return HLAnchorRef
     */
    public java.lang.String getHLAnchorRef() {
        return HLAnchorRef;
    }


    /**
     * Sets the HLAnchorRef value for this InlineBox.
     * 
     * @param HLAnchorRef
     */
    public void setHLAnchorRef(java.lang.String HLAnchorRef) {
        this.HLAnchorRef = HLAnchorRef;
    }


    /**
     * Gets the HLType value for this InlineBox.
     * 
     * @return HLType
     */
    public java.lang.String getHLType() {
        return HLType;
    }


    /**
     * Sets the HLType value for this InlineBox.
     * 
     * @param HLType
     */
    public void setHLType(java.lang.String HLType) {
        this.HLType = HLType;
    }


    /**
     * Gets the height value for this InlineBox.
     * 
     * @return height
     */
    public java.lang.String getHeight() {
        return height;
    }


    /**
     * Sets the height value for this InlineBox.
     * 
     * @param height
     */
    public void setHeight(java.lang.String height) {
        this.height = height;
    }


    /**
     * Gets the hyperlinkRef value for this InlineBox.
     * 
     * @return hyperlinkRef
     */
    public java.lang.String getHyperlinkRef() {
        return hyperlinkRef;
    }


    /**
     * Sets the hyperlinkRef value for this InlineBox.
     * 
     * @param hyperlinkRef
     */
    public void setHyperlinkRef(java.lang.String hyperlinkRef) {
        this.hyperlinkRef = hyperlinkRef;
    }


    /**
     * Gets the index value for this InlineBox.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this InlineBox.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the indexTerms value for this InlineBox.
     * 
     * @return indexTerms
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] getIndexTerms() {
        return indexTerms;
    }


    /**
     * Sets the indexTerms value for this InlineBox.
     * 
     * @param indexTerms
     */
    public void setIndexTerms(com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms) {
        this.indexTerms = indexTerms;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm getIndexTerms(int i) {
        return this.indexTerms[i];
    }

    public void setIndexTerms(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm _value) {
        this.indexTerms[i] = _value;
    }


    /**
     * Gets the interactivity value for this InlineBox.
     * 
     * @return interactivity
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity getInteractivity() {
        return interactivity;
    }


    /**
     * Sets the interactivity value for this InlineBox.
     * 
     * @param interactivity
     */
    public void setInteractivity(com.socgen.sgs.api.quark.engine.integration.soap.generated.Interactivity interactivity) {
        this.interactivity = interactivity;
    }


    /**
     * Gets the itemStyle value for this InlineBox.
     * 
     * @return itemStyle
     */
    public java.lang.String getItemStyle() {
        return itemStyle;
    }


    /**
     * Sets the itemStyle value for this InlineBox.
     * 
     * @param itemStyle
     */
    public void setItemStyle(java.lang.String itemStyle) {
        this.itemStyle = itemStyle;
    }


    /**
     * Gets the metaData value for this InlineBox.
     * 
     * @return metaData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData getMetaData() {
        return metaData;
    }


    /**
     * Sets the metaData value for this InlineBox.
     * 
     * @param metaData
     */
    public void setMetaData(com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData) {
        this.metaData = metaData;
    }


    /**
     * Gets the name value for this InlineBox.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this InlineBox.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the offset value for this InlineBox.
     * 
     * @return offset
     */
    public java.lang.String getOffset() {
        return offset;
    }


    /**
     * Sets the offset value for this InlineBox.
     * 
     * @param offset
     */
    public void setOffset(java.lang.String offset) {
        this.offset = offset;
    }


    /**
     * Gets the paragraphs value for this InlineBox.
     * 
     * @return paragraphs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] getParagraphs() {
        return paragraphs;
    }


    /**
     * Sets the paragraphs value for this InlineBox.
     * 
     * @param paragraphs
     */
    public void setParagraphs(com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs) {
        this.paragraphs = paragraphs;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph getParagraphs(int i) {
        return this.paragraphs[i];
    }

    public void setParagraphs(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph _value) {
        this.paragraphs[i] = _value;
    }


    /**
     * Gets the picture value for this InlineBox.
     * 
     * @return picture
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture getPicture() {
        return picture;
    }


    /**
     * Sets the picture value for this InlineBox.
     * 
     * @param picture
     */
    public void setPicture(com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture) {
        this.picture = picture;
    }


    /**
     * Gets the richtext value for this InlineBox.
     * 
     * @return richtext
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichtext() {
        return richtext;
    }


    /**
     * Sets the richtext value for this InlineBox.
     * 
     * @param richtext
     */
    public void setRichtext(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richtext) {
        this.richtext = richtext;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText getRichtext(int i) {
        return this.richtext[i];
    }

    public void setRichtext(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText _value) {
        this.richtext[i] = _value;
    }


    /**
     * Gets the runaround value for this InlineBox.
     * 
     * @return runaround
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround getRunaround() {
        return runaround;
    }


    /**
     * Sets the runaround value for this InlineBox.
     * 
     * @param runaround
     */
    public void setRunaround(com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround runaround) {
        this.runaround = runaround;
    }


    /**
     * Gets the scaleUp value for this InlineBox.
     * 
     * @return scaleUp
     */
    public java.lang.String getScaleUp() {
        return scaleUp;
    }


    /**
     * Sets the scaleUp value for this InlineBox.
     * 
     * @param scaleUp
     */
    public void setScaleUp(java.lang.String scaleUp) {
        this.scaleUp = scaleUp;
    }


    /**
     * Gets the shadow value for this InlineBox.
     * 
     * @return shadow
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow getShadow() {
        return shadow;
    }


    /**
     * Sets the shadow value for this InlineBox.
     * 
     * @param shadow
     */
    public void setShadow(com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow) {
        this.shadow = shadow;
    }


    /**
     * Gets the textAttribute value for this InlineBox.
     * 
     * @return textAttribute
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextAttribute getTextAttribute() {
        return textAttribute;
    }


    /**
     * Sets the textAttribute value for this InlineBox.
     * 
     * @param textAttribute
     */
    public void setTextAttribute(com.socgen.sgs.api.quark.engine.integration.soap.generated.TextAttribute textAttribute) {
        this.textAttribute = textAttribute;
    }


    /**
     * Gets the width value for this InlineBox.
     * 
     * @return width
     */
    public java.lang.String getWidth() {
        return width;
    }


    /**
     * Sets the width value for this InlineBox.
     * 
     * @param width
     */
    public void setWidth(java.lang.String width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof InlineBox)) return false;
        InlineBox other = (InlineBox) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignWithText==null && other.getAlignWithText()==null) || 
             (this.alignWithText!=null &&
              this.alignWithText.equals(other.getAlignWithText()))) &&
            ((this.border==null && other.getBorder()==null) || 
             (this.border!=null &&
              this.border.equals(other.getBorder()))) &&
            ((this.boxAttribute==null && other.getBoxAttribute()==null) || 
             (this.boxAttribute!=null &&
              this.boxAttribute.equals(other.getBoxAttribute()))) &&
            ((this.content==null && other.getContent()==null) || 
             (this.content!=null &&
              this.content.equals(other.getContent()))) &&
            ((this.frame==null && other.getFrame()==null) || 
             (this.frame!=null &&
              this.frame.equals(other.getFrame()))) &&
            ((this.HLAnchorRef==null && other.getHLAnchorRef()==null) || 
             (this.HLAnchorRef!=null &&
              this.HLAnchorRef.equals(other.getHLAnchorRef()))) &&
            ((this.HLType==null && other.getHLType()==null) || 
             (this.HLType!=null &&
              this.HLType.equals(other.getHLType()))) &&
            ((this.height==null && other.getHeight()==null) || 
             (this.height!=null &&
              this.height.equals(other.getHeight()))) &&
            ((this.hyperlinkRef==null && other.getHyperlinkRef()==null) || 
             (this.hyperlinkRef!=null &&
              this.hyperlinkRef.equals(other.getHyperlinkRef()))) &&
            this.index == other.getIndex() &&
            ((this.indexTerms==null && other.getIndexTerms()==null) || 
             (this.indexTerms!=null &&
              java.util.Arrays.equals(this.indexTerms, other.getIndexTerms()))) &&
            ((this.interactivity==null && other.getInteractivity()==null) || 
             (this.interactivity!=null &&
              this.interactivity.equals(other.getInteractivity()))) &&
            ((this.itemStyle==null && other.getItemStyle()==null) || 
             (this.itemStyle!=null &&
              this.itemStyle.equals(other.getItemStyle()))) &&
            ((this.metaData==null && other.getMetaData()==null) || 
             (this.metaData!=null &&
              this.metaData.equals(other.getMetaData()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.offset==null && other.getOffset()==null) || 
             (this.offset!=null &&
              this.offset.equals(other.getOffset()))) &&
            ((this.paragraphs==null && other.getParagraphs()==null) || 
             (this.paragraphs!=null &&
              java.util.Arrays.equals(this.paragraphs, other.getParagraphs()))) &&
            ((this.picture==null && other.getPicture()==null) || 
             (this.picture!=null &&
              this.picture.equals(other.getPicture()))) &&
            ((this.richtext==null && other.getRichtext()==null) || 
             (this.richtext!=null &&
              java.util.Arrays.equals(this.richtext, other.getRichtext()))) &&
            ((this.runaround==null && other.getRunaround()==null) || 
             (this.runaround!=null &&
              this.runaround.equals(other.getRunaround()))) &&
            ((this.scaleUp==null && other.getScaleUp()==null) || 
             (this.scaleUp!=null &&
              this.scaleUp.equals(other.getScaleUp()))) &&
            ((this.shadow==null && other.getShadow()==null) || 
             (this.shadow!=null &&
              this.shadow.equals(other.getShadow()))) &&
            ((this.textAttribute==null && other.getTextAttribute()==null) || 
             (this.textAttribute!=null &&
              this.textAttribute.equals(other.getTextAttribute()))) &&
            ((this.width==null && other.getWidth()==null) || 
             (this.width!=null &&
              this.width.equals(other.getWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignWithText() != null) {
            _hashCode += getAlignWithText().hashCode();
        }
        if (getBorder() != null) {
            _hashCode += getBorder().hashCode();
        }
        if (getBoxAttribute() != null) {
            _hashCode += getBoxAttribute().hashCode();
        }
        if (getContent() != null) {
            _hashCode += getContent().hashCode();
        }
        if (getFrame() != null) {
            _hashCode += getFrame().hashCode();
        }
        if (getHLAnchorRef() != null) {
            _hashCode += getHLAnchorRef().hashCode();
        }
        if (getHLType() != null) {
            _hashCode += getHLType().hashCode();
        }
        if (getHeight() != null) {
            _hashCode += getHeight().hashCode();
        }
        if (getHyperlinkRef() != null) {
            _hashCode += getHyperlinkRef().hashCode();
        }
        _hashCode += getIndex();
        if (getIndexTerms() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIndexTerms());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIndexTerms(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInteractivity() != null) {
            _hashCode += getInteractivity().hashCode();
        }
        if (getItemStyle() != null) {
            _hashCode += getItemStyle().hashCode();
        }
        if (getMetaData() != null) {
            _hashCode += getMetaData().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOffset() != null) {
            _hashCode += getOffset().hashCode();
        }
        if (getParagraphs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParagraphs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParagraphs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPicture() != null) {
            _hashCode += getPicture().hashCode();
        }
        if (getRichtext() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichtext());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichtext(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRunaround() != null) {
            _hashCode += getRunaround().hashCode();
        }
        if (getScaleUp() != null) {
            _hashCode += getScaleUp().hashCode();
        }
        if (getShadow() != null) {
            _hashCode += getShadow().hashCode();
        }
        if (getTextAttribute() != null) {
            _hashCode += getTextAttribute().hashCode();
        }
        if (getWidth() != null) {
            _hashCode += getWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InlineBox.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineBox"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignWithText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignWithText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("border");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "border"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Border"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "BoxAttribute"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("content");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "content"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Content"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frame");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "frame"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Frame"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HLAnchorRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HLAnchorRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HLType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HLType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("height");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "height"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hyperlinkRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hyperlinkRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indexTerms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "indexTerms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexTerm"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interactivity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "interactivity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Interactivity"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("itemStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "itemStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metaData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "metaData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "MetaData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "offset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paragraphs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "paragraphs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Paragraph"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picture");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "picture"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Picture"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richtext");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "richtext"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RichText"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("runaround");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "runaround"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Runaround"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleUp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scaleUp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shadow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Shadow"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "textAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TextAttribute"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("width");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "width"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
