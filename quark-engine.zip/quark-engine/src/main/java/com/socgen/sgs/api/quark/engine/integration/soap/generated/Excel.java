/**
 * Excel.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Excel  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String fitToBox;

    private java.lang.String headerRows;

    private java.lang.String includeFormats;

    private java.lang.String includeGeometery;

    private java.lang.String includeHiddenColumns;

    private java.lang.String includeHiddenRows;

    private java.lang.String name;

    private java.lang.String range;

    private java.lang.String sheetName;

    private java.lang.String tableStyle;

    public Excel() {
    }

    public Excel(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String fitToBox,
           java.lang.String headerRows,
           java.lang.String includeFormats,
           java.lang.String includeGeometery,
           java.lang.String includeHiddenColumns,
           java.lang.String includeHiddenRows,
           java.lang.String name,
           java.lang.String range,
           java.lang.String sheetName,
           java.lang.String tableStyle) {
        super(
            request);
        this.fitToBox = fitToBox;
        this.headerRows = headerRows;
        this.includeFormats = includeFormats;
        this.includeGeometery = includeGeometery;
        this.includeHiddenColumns = includeHiddenColumns;
        this.includeHiddenRows = includeHiddenRows;
        this.name = name;
        this.range = range;
        this.sheetName = sheetName;
        this.tableStyle = tableStyle;
    }


    /**
     * Gets the fitToBox value for this Excel.
     * 
     * @return fitToBox
     */
    public java.lang.String getFitToBox() {
        return fitToBox;
    }


    /**
     * Sets the fitToBox value for this Excel.
     * 
     * @param fitToBox
     */
    public void setFitToBox(java.lang.String fitToBox) {
        this.fitToBox = fitToBox;
    }


    /**
     * Gets the headerRows value for this Excel.
     * 
     * @return headerRows
     */
    public java.lang.String getHeaderRows() {
        return headerRows;
    }


    /**
     * Sets the headerRows value for this Excel.
     * 
     * @param headerRows
     */
    public void setHeaderRows(java.lang.String headerRows) {
        this.headerRows = headerRows;
    }


    /**
     * Gets the includeFormats value for this Excel.
     * 
     * @return includeFormats
     */
    public java.lang.String getIncludeFormats() {
        return includeFormats;
    }


    /**
     * Sets the includeFormats value for this Excel.
     * 
     * @param includeFormats
     */
    public void setIncludeFormats(java.lang.String includeFormats) {
        this.includeFormats = includeFormats;
    }


    /**
     * Gets the includeGeometery value for this Excel.
     * 
     * @return includeGeometery
     */
    public java.lang.String getIncludeGeometery() {
        return includeGeometery;
    }


    /**
     * Sets the includeGeometery value for this Excel.
     * 
     * @param includeGeometery
     */
    public void setIncludeGeometery(java.lang.String includeGeometery) {
        this.includeGeometery = includeGeometery;
    }


    /**
     * Gets the includeHiddenColumns value for this Excel.
     * 
     * @return includeHiddenColumns
     */
    public java.lang.String getIncludeHiddenColumns() {
        return includeHiddenColumns;
    }


    /**
     * Sets the includeHiddenColumns value for this Excel.
     * 
     * @param includeHiddenColumns
     */
    public void setIncludeHiddenColumns(java.lang.String includeHiddenColumns) {
        this.includeHiddenColumns = includeHiddenColumns;
    }


    /**
     * Gets the includeHiddenRows value for this Excel.
     * 
     * @return includeHiddenRows
     */
    public java.lang.String getIncludeHiddenRows() {
        return includeHiddenRows;
    }


    /**
     * Sets the includeHiddenRows value for this Excel.
     * 
     * @param includeHiddenRows
     */
    public void setIncludeHiddenRows(java.lang.String includeHiddenRows) {
        this.includeHiddenRows = includeHiddenRows;
    }


    /**
     * Gets the name value for this Excel.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Excel.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the range value for this Excel.
     * 
     * @return range
     */
    public java.lang.String getRange() {
        return range;
    }


    /**
     * Sets the range value for this Excel.
     * 
     * @param range
     */
    public void setRange(java.lang.String range) {
        this.range = range;
    }


    /**
     * Gets the sheetName value for this Excel.
     * 
     * @return sheetName
     */
    public java.lang.String getSheetName() {
        return sheetName;
    }


    /**
     * Sets the sheetName value for this Excel.
     * 
     * @param sheetName
     */
    public void setSheetName(java.lang.String sheetName) {
        this.sheetName = sheetName;
    }


    /**
     * Gets the tableStyle value for this Excel.
     * 
     * @return tableStyle
     */
    public java.lang.String getTableStyle() {
        return tableStyle;
    }


    /**
     * Sets the tableStyle value for this Excel.
     * 
     * @param tableStyle
     */
    public void setTableStyle(java.lang.String tableStyle) {
        this.tableStyle = tableStyle;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Excel)) return false;
        Excel other = (Excel) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.fitToBox==null && other.getFitToBox()==null) || 
             (this.fitToBox!=null &&
              this.fitToBox.equals(other.getFitToBox()))) &&
            ((this.headerRows==null && other.getHeaderRows()==null) || 
             (this.headerRows!=null &&
              this.headerRows.equals(other.getHeaderRows()))) &&
            ((this.includeFormats==null && other.getIncludeFormats()==null) || 
             (this.includeFormats!=null &&
              this.includeFormats.equals(other.getIncludeFormats()))) &&
            ((this.includeGeometery==null && other.getIncludeGeometery()==null) || 
             (this.includeGeometery!=null &&
              this.includeGeometery.equals(other.getIncludeGeometery()))) &&
            ((this.includeHiddenColumns==null && other.getIncludeHiddenColumns()==null) || 
             (this.includeHiddenColumns!=null &&
              this.includeHiddenColumns.equals(other.getIncludeHiddenColumns()))) &&
            ((this.includeHiddenRows==null && other.getIncludeHiddenRows()==null) || 
             (this.includeHiddenRows!=null &&
              this.includeHiddenRows.equals(other.getIncludeHiddenRows()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.range==null && other.getRange()==null) || 
             (this.range!=null &&
              this.range.equals(other.getRange()))) &&
            ((this.sheetName==null && other.getSheetName()==null) || 
             (this.sheetName!=null &&
              this.sheetName.equals(other.getSheetName()))) &&
            ((this.tableStyle==null && other.getTableStyle()==null) || 
             (this.tableStyle!=null &&
              this.tableStyle.equals(other.getTableStyle())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getFitToBox() != null) {
            _hashCode += getFitToBox().hashCode();
        }
        if (getHeaderRows() != null) {
            _hashCode += getHeaderRows().hashCode();
        }
        if (getIncludeFormats() != null) {
            _hashCode += getIncludeFormats().hashCode();
        }
        if (getIncludeGeometery() != null) {
            _hashCode += getIncludeGeometery().hashCode();
        }
        if (getIncludeHiddenColumns() != null) {
            _hashCode += getIncludeHiddenColumns().hashCode();
        }
        if (getIncludeHiddenRows() != null) {
            _hashCode += getIncludeHiddenRows().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getRange() != null) {
            _hashCode += getRange().hashCode();
        }
        if (getSheetName() != null) {
            _hashCode += getSheetName().hashCode();
        }
        if (getTableStyle() != null) {
            _hashCode += getTableStyle().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Excel.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Excel"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fitToBox");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fitToBox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headerRows");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "headerRows"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeFormats");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "includeFormats"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeGeometery");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "includeGeometery"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeHiddenColumns");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "includeHiddenColumns"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeHiddenRows");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "includeHiddenRows"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("range");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "range"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sheetName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "sheetName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tableStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tableStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
