package com.socgen.sgs.api.quark.engine.domain.bloc;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import lombok.Getter;
import lombok.Setter;

/** Represents a line bloc for row-level operations on a table in a QuarkXPress document. */
@Getter
@Setter
public class BlocLigne extends BlocBase {

    private int index;

    public BlocLigne(TaskBase task, String name, String parentName, int index) {
        super(task, name);
        this.setParentName(parentName);
        this.index = index;
    }
}

