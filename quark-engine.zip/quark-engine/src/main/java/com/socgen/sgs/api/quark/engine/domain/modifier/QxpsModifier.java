package com.socgen.sgs.api.quark.engine.domain.modifier;

import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBase;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocGroup;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocLigne;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocPage;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocTable;
import com.socgen.sgs.api.quark.engine.domain.RunError;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Project;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

/**
 * Aggregates all bloc types into a project hierarchy for sending to QuarkXPress Server.
 * Converts BlocBox/BlocPage/BlocTable/BlocGroup/BlocLigne into the Modifier structure
 * (ModifierProjet → ModifierLayout → ModifierSpread → ModifierBox/Page/Table/Group).
 *
 * Cross-reference: QXP.Engine.Core.QXPS_Modifier
 */
@Getter
@Slf4j
public class QxpsModifier {

    private final ModifierProjet projet = new ModifierProjet();
    private boolean empty = true;
    private final List<BlocBase> blocs = new ArrayList<>();

    public QxpsModifier() {
    }

    /**
     * Add a list of blocs to the modifier.
     */
    public void addRange(Iterable<BlocBase> blocs) {
        for (BlocBase bloc : blocs) {
            add(bloc);
        }
    }

    /**
     * Add a single bloc to the modifier hierarchy.
     * Routes to the correct typed add method based on bloc class.
     *
     * Cross-reference: .NET QXPS_Modifier.Add(Bloc_Base)
     */
    public void add(BlocBase bloc) {
        if (bloc == null || bloc.isExclude()) {
            return;
        }
        blocs.add(bloc);

        if (bloc instanceof BlocBox) {
            addBlocBox((BlocBox) bloc);
        } else if (bloc instanceof BlocGroup) {
            addBlocGroup((BlocGroup) bloc);
        } else if (bloc instanceof BlocTable) {
            addBlocTable((BlocTable) bloc);
        } else if (bloc instanceof BlocLigne) {
            addBlocLigne((BlocLigne) bloc);
        } else if (bloc instanceof BlocPage) {
            addBlocPage((BlocPage) bloc);
        }
    }

    private void addBlocBox(BlocBox bloc) {
        ModifierSpread spread = addGetSpread(bloc);
        if (spread == null) return;

        ModifierBox box = new ModifierBox();
        box.setName(bloc.getName());
        box.setAction(bloc.getAction());
        box.setPageId(bloc.getPageId());
        box.setValue(bloc.getValue());
        box.setSrcBox(getBox(bloc, false));
        spread.getBoxes().put(box.getName(), box);

        if (bloc.getSrcExtraBox() != null) {
            ModifierBox extraBox = new ModifierBox();
            extraBox.setName(bloc.getName());
            extraBox.setAction(bloc.getAction());
            extraBox.setPageId(bloc.getPageId());
            extraBox.setValue(bloc.getValue());
            extraBox.setSrcBox(getBox(bloc, true));
            spread.getBoxesExtra().put(extraBox.getName(), extraBox);
        }
    }

    private void addBlocGroup(BlocGroup bloc) {
        ModifierSpread spread = addGetSpread(bloc);
        if (spread == null) return;

        ModifierGroup group = new ModifierGroup();
        group.setName(bloc.getName());
        group.setPageId(bloc.getPageId());
        group.setAction(bloc.getAction());
        group.setSrcBoxes(bloc.getSrcBoxes());
        spread.getGroups().put(group.getName(), group);
    }

    private void addBlocTable(BlocTable bloc) {
        ModifierSpread spread = addGetSpread(bloc);
        if (spread == null) return;

        if (!spread.getTables().containsKey(bloc.getName())) {
            ModifierTable table = new ModifierTable();
            table.setName(bloc.getName());
            table.setAction(bloc.getAction());
            table.setTask(bloc.getTask());
            table.setSrcTable(bloc.getSrcTable());
            spread.getTables().put(table.getName(), table);
        } else {
            ModifierTable existing = spread.getTables().get(bloc.getName());
            if (bloc.getAction() == BlocActionEnum.REMOVE) {
                existing.setAction(bloc.getAction());
                existing.getLignes().clear();
            }
        }
    }

    private void addBlocLigne(BlocLigne bloc) {
        ModifierTable table = addGetTable(bloc);
        if (table == null) return;

        ModifierLigne ligne = new ModifierLigne();
        ligne.setIndex(bloc.getIndex());

        if (!table.getLignes().containsKey(bloc.getIndex())
                && table.getAction() != BlocActionEnum.REMOVE) {
            table.getLignes().put(ligne.getIndex(), ligne);
        }
    }

    private void addBlocPage(BlocPage bloc) {
        ModifierSpread spread = addGetSpread(bloc);
        if (spread == null) return;

        ModifierPage page = new ModifierPage();
        page.setAction(bloc.getAction());
        page.setUid(String.valueOf(bloc.getPageId()));
        page.setPosition(bloc.getPosition());
        page.setIndexPosition(bloc.getIndexPosition());
        page.setName(bloc.getName());
        page.setTask(bloc.getTask());
        page.setCreateDummyNextPage(bloc.isCreateNextDummyPage());

        if (!spread.getPages().containsKey(page.getUid())) {
            spread.getPages().put(page.getUid(), page);
        }
    }

    // ========================================================================
    // Hierarchy navigation helpers
    // ========================================================================

    private ModifierLayout addGetLayout(BlocBase bloc) {
        String layoutName;
        if (bloc.getCondName() != null && !bloc.getCondName().isBlank()) {
            layoutName = bloc.getTask().getRun().getGabarit()
                    .getQxpXml().getLayoutName(bloc.getCondName());
        } else {
            layoutName = bloc.getTask().getProperties().getLayoutName();
        }

        if (layoutName == null || layoutName.isBlank()) {
            return null;
        }

        return projet.getLayouts().computeIfAbsent(layoutName, k -> {
            ModifierLayout layout = new ModifierLayout();
            layout.setName(layoutName);
            return layout;
        });
    }

    private ModifierSpread addGetSpread(BlocBase bloc) {
        ModifierLayout layout = addGetLayout(bloc);
        if (layout == null) {
            // Parity: .NET QXPS_Modifier records Empty_Layout_Or_Spread_For_Bloc (Errors.Add(string) →
            // Error_Type.Unspecified) as an audit-trail entry; it does NOT fail the run. Finding #65.
            bloc.getTask().getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                    "Layout ou Spread NULL pour le bloc " + bloc.getName()));
            log.warn("No layout found for bloc [{}]", bloc.getName());
            return null;
        }

        empty = false;
        String spreadUid = String.valueOf(bloc.getSpreadId());

        return layout.getSpreads().computeIfAbsent(spreadUid, k -> {
            ModifierSpread spread = new ModifierSpread();
            spread.setUid(spreadUid);
            return spread;
        });
    }

    private ModifierTable addGetTable(BlocBase bloc) {
        ModifierSpread spread = addGetSpread(bloc);
        if (spread == null) return null;

        return spread.getTables().computeIfAbsent(bloc.getParentName(), k -> {
            ModifierTable table = new ModifierTable();
            table.setName(bloc.getParentName());
            table.setAction(BlocActionEnum.NONE);
            table.setTask(bloc.getTask());
            return table;
        });
    }

    private Box getBox(BlocBox blocBox, boolean fromExtraSrc) {
        return fromExtraSrc ? blocBox.getSrcExtraBox() : blocBox.getSrcBox();
    }

    // ========================================================================
    // Output
    // ========================================================================

    /**
     * Get the SOAP Project structure.
     * Cross-reference: .NET QXPS_Modifier.GetProject()
     */
    public Project getProject() {
        return projet.getSdkProject();
    }
}