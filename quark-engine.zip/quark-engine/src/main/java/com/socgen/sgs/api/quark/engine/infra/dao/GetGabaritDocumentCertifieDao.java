package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;

public interface GetGabaritDocumentCertifieDao {
    DocumentDomain getGabaritDocumentCertifie(Integer idSuivi);
}

