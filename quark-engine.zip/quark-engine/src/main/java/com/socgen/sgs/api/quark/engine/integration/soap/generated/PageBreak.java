/**
 * PageBreak.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class PageBreak  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String blankMaster;

    private java.lang.String blankPage;

    private int index;

    private java.lang.String nextMaster;

    private java.lang.String nextPage;

    private java.lang.String paraStyle;

    public PageBreak() {
    }

    public PageBreak(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String blankMaster,
           java.lang.String blankPage,
           int index,
           java.lang.String nextMaster,
           java.lang.String nextPage,
           java.lang.String paraStyle) {
        super(
            request);
        this.blankMaster = blankMaster;
        this.blankPage = blankPage;
        this.index = index;
        this.nextMaster = nextMaster;
        this.nextPage = nextPage;
        this.paraStyle = paraStyle;
    }


    /**
     * Gets the blankMaster value for this PageBreak.
     * 
     * @return blankMaster
     */
    public java.lang.String getBlankMaster() {
        return blankMaster;
    }


    /**
     * Sets the blankMaster value for this PageBreak.
     * 
     * @param blankMaster
     */
    public void setBlankMaster(java.lang.String blankMaster) {
        this.blankMaster = blankMaster;
    }


    /**
     * Gets the blankPage value for this PageBreak.
     * 
     * @return blankPage
     */
    public java.lang.String getBlankPage() {
        return blankPage;
    }


    /**
     * Sets the blankPage value for this PageBreak.
     * 
     * @param blankPage
     */
    public void setBlankPage(java.lang.String blankPage) {
        this.blankPage = blankPage;
    }


    /**
     * Gets the index value for this PageBreak.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this PageBreak.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the nextMaster value for this PageBreak.
     * 
     * @return nextMaster
     */
    public java.lang.String getNextMaster() {
        return nextMaster;
    }


    /**
     * Sets the nextMaster value for this PageBreak.
     * 
     * @param nextMaster
     */
    public void setNextMaster(java.lang.String nextMaster) {
        this.nextMaster = nextMaster;
    }


    /**
     * Gets the nextPage value for this PageBreak.
     * 
     * @return nextPage
     */
    public java.lang.String getNextPage() {
        return nextPage;
    }


    /**
     * Sets the nextPage value for this PageBreak.
     * 
     * @param nextPage
     */
    public void setNextPage(java.lang.String nextPage) {
        this.nextPage = nextPage;
    }


    /**
     * Gets the paraStyle value for this PageBreak.
     * 
     * @return paraStyle
     */
    public java.lang.String getParaStyle() {
        return paraStyle;
    }


    /**
     * Sets the paraStyle value for this PageBreak.
     * 
     * @param paraStyle
     */
    public void setParaStyle(java.lang.String paraStyle) {
        this.paraStyle = paraStyle;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PageBreak)) return false;
        PageBreak other = (PageBreak) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.blankMaster==null && other.getBlankMaster()==null) || 
             (this.blankMaster!=null &&
              this.blankMaster.equals(other.getBlankMaster()))) &&
            ((this.blankPage==null && other.getBlankPage()==null) || 
             (this.blankPage!=null &&
              this.blankPage.equals(other.getBlankPage()))) &&
            this.index == other.getIndex() &&
            ((this.nextMaster==null && other.getNextMaster()==null) || 
             (this.nextMaster!=null &&
              this.nextMaster.equals(other.getNextMaster()))) &&
            ((this.nextPage==null && other.getNextPage()==null) || 
             (this.nextPage!=null &&
              this.nextPage.equals(other.getNextPage()))) &&
            ((this.paraStyle==null && other.getParaStyle()==null) || 
             (this.paraStyle!=null &&
              this.paraStyle.equals(other.getParaStyle())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBlankMaster() != null) {
            _hashCode += getBlankMaster().hashCode();
        }
        if (getBlankPage() != null) {
            _hashCode += getBlankPage().hashCode();
        }
        _hashCode += getIndex();
        if (getNextMaster() != null) {
            _hashCode += getNextMaster().hashCode();
        }
        if (getNextPage() != null) {
            _hashCode += getNextPage().hashCode();
        }
        if (getParaStyle() != null) {
            _hashCode += getParaStyle().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PageBreak.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageBreak"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blankMaster");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blankMaster"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blankPage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blankPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nextMaster");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "nextMaster"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nextPage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "nextPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paraStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "paraStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
