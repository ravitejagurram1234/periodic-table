package com.socgen.sgs.api.quark.engine.domain.element;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Abstract base class for all template elements used in dynamic tasks.
 * Holds common geometry properties (name, position, dimensions) and
 * an abstract evaluate method for computing geometry from the QXP project.
 *
 * <p>Subclasses: {@link TBox}, {@link TTable}, {@link TGroup}
 *
 * Cross-reference: QXP.Engine.Core.TElement
 */
@Getter
@Setter
public abstract class TElement {

    /** Element name (box/table/group name in the QXP document). */
    private String name;

    /** Left position in points. */
    private BigDecimal left = BigDecimal.ZERO;

    /** Top position in points. */
    private BigDecimal top = BigDecimal.ZERO;

    /** Right position in points. */
    private BigDecimal right = BigDecimal.ZERO;

    /** Bottom position in points. */
    private BigDecimal bottom = BigDecimal.ZERO;

    /** Width (right - left) in points. */
    private BigDecimal width = BigDecimal.ZERO;

    /** Height (bottom - top) in points. */
    private BigDecimal height = BigDecimal.ZERO;

    /** Whether this element's geometry has already been evaluated. */
    private boolean evaluated = false;

    /**
     * Protected no-arg constructor for serialization/deserialization.
     */
    protected TElement() {
    }

    /**
     * Create a TElement with a name.
     *
     * @param name the element name
     */
    protected TElement(String name) {
        this.name = name;
    }

    /**
     * Evaluate geometry properties from the QXP project structure.
     * Each subclass implements its own evaluation logic.
     *
     * @param qxpProject the QXP project containing element definitions
     */
    public abstract void evaluate(Object qxpProject);
}