package com.socgen.sgs.api.quark.engine.infra.dao;

import java.time.LocalDateTime;
import java.util.List;

/**
 * DAO for finalizing run status in the database.
 *
 * Cross-reference: .NET Proxy_Run — End_Run + Update_Status_Run + Insert_Run_Errors
 */
public interface EndRunDao {

    /**
     * End a successful run: update status and link generated document IDs.
     * Oracle: QXP_PK_RUN.End_Run
     */
    void endRun(int idRun, int runStatus, int idSuivi, int suiviStatus,
                LocalDateTime dateFin, String logTrace,
                int idDocPdf, int idDocQxp, int idDocDoc);

    /**
     * Update run status (used for error case).
     * Oracle: QXP_PK_RUN.Update_Status_Run
     */
    void updateStatusRun(int idRun, int runStatus, int suiviStatus,
                         LocalDateTime dateFin, String logTrace);

    /**
     * Insert run errors.
     * Oracle: QXP_PK_RUN.Insert_Run_Errors
     */
    void insertRunErrors(int idRun, String[] messages, int[] categories);
}