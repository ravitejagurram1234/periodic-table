/**
 * JPEGRenderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class JPEGRenderRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String afterPage;

    private java.lang.String box;

    private java.lang.String boxes;

    private java.lang.String download;

    private java.lang.String JPEGQuality;

    private java.lang.String layout;

    private java.lang.String movePages;

    private java.lang.String overlap;

    private java.lang.String page;

    private java.lang.String pages;

    private java.lang.String pasteboard;

    private java.lang.String scale;

    private java.lang.String showBoxOutline;

    private java.lang.String spread;

    private java.lang.String spreadnum;

    private java.lang.String updateFullRes;

    private java.lang.String updateImage;

    public JPEGRenderRequest() {
    }

    public JPEGRenderRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String afterPage,
           java.lang.String box,
           java.lang.String boxes,
           java.lang.String download,
           java.lang.String JPEGQuality,
           java.lang.String layout,
           java.lang.String movePages,
           java.lang.String overlap,
           java.lang.String page,
           java.lang.String pages,
           java.lang.String pasteboard,
           java.lang.String scale,
           java.lang.String showBoxOutline,
           java.lang.String spread,
           java.lang.String spreadnum,
           java.lang.String updateFullRes,
           java.lang.String updateImage) {
        super(
            request);
        this.afterPage = afterPage;
        this.box = box;
        this.boxes = boxes;
        this.download = download;
        this.JPEGQuality = JPEGQuality;
        this.layout = layout;
        this.movePages = movePages;
        this.overlap = overlap;
        this.page = page;
        this.pages = pages;
        this.pasteboard = pasteboard;
        this.scale = scale;
        this.showBoxOutline = showBoxOutline;
        this.spread = spread;
        this.spreadnum = spreadnum;
        this.updateFullRes = updateFullRes;
        this.updateImage = updateImage;
    }


    /**
     * Gets the afterPage value for this JPEGRenderRequest.
     * 
     * @return afterPage
     */
    public java.lang.String getAfterPage() {
        return afterPage;
    }


    /**
     * Sets the afterPage value for this JPEGRenderRequest.
     * 
     * @param afterPage
     */
    public void setAfterPage(java.lang.String afterPage) {
        this.afterPage = afterPage;
    }


    /**
     * Gets the box value for this JPEGRenderRequest.
     * 
     * @return box
     */
    public java.lang.String getBox() {
        return box;
    }


    /**
     * Sets the box value for this JPEGRenderRequest.
     * 
     * @param box
     */
    public void setBox(java.lang.String box) {
        this.box = box;
    }


    /**
     * Gets the boxes value for this JPEGRenderRequest.
     * 
     * @return boxes
     */
    public java.lang.String getBoxes() {
        return boxes;
    }


    /**
     * Sets the boxes value for this JPEGRenderRequest.
     * 
     * @param boxes
     */
    public void setBoxes(java.lang.String boxes) {
        this.boxes = boxes;
    }


    /**
     * Gets the download value for this JPEGRenderRequest.
     * 
     * @return download
     */
    public java.lang.String getDownload() {
        return download;
    }


    /**
     * Sets the download value for this JPEGRenderRequest.
     * 
     * @param download
     */
    public void setDownload(java.lang.String download) {
        this.download = download;
    }


    /**
     * Gets the JPEGQuality value for this JPEGRenderRequest.
     * 
     * @return JPEGQuality
     */
    public java.lang.String getJPEGQuality() {
        return JPEGQuality;
    }


    /**
     * Sets the JPEGQuality value for this JPEGRenderRequest.
     * 
     * @param JPEGQuality
     */
    public void setJPEGQuality(java.lang.String JPEGQuality) {
        this.JPEGQuality = JPEGQuality;
    }


    /**
     * Gets the layout value for this JPEGRenderRequest.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this JPEGRenderRequest.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the movePages value for this JPEGRenderRequest.
     * 
     * @return movePages
     */
    public java.lang.String getMovePages() {
        return movePages;
    }


    /**
     * Sets the movePages value for this JPEGRenderRequest.
     * 
     * @param movePages
     */
    public void setMovePages(java.lang.String movePages) {
        this.movePages = movePages;
    }


    /**
     * Gets the overlap value for this JPEGRenderRequest.
     * 
     * @return overlap
     */
    public java.lang.String getOverlap() {
        return overlap;
    }


    /**
     * Sets the overlap value for this JPEGRenderRequest.
     * 
     * @param overlap
     */
    public void setOverlap(java.lang.String overlap) {
        this.overlap = overlap;
    }


    /**
     * Gets the page value for this JPEGRenderRequest.
     * 
     * @return page
     */
    public java.lang.String getPage() {
        return page;
    }


    /**
     * Sets the page value for this JPEGRenderRequest.
     * 
     * @param page
     */
    public void setPage(java.lang.String page) {
        this.page = page;
    }


    /**
     * Gets the pages value for this JPEGRenderRequest.
     * 
     * @return pages
     */
    public java.lang.String getPages() {
        return pages;
    }


    /**
     * Sets the pages value for this JPEGRenderRequest.
     * 
     * @param pages
     */
    public void setPages(java.lang.String pages) {
        this.pages = pages;
    }


    /**
     * Gets the pasteboard value for this JPEGRenderRequest.
     * 
     * @return pasteboard
     */
    public java.lang.String getPasteboard() {
        return pasteboard;
    }


    /**
     * Sets the pasteboard value for this JPEGRenderRequest.
     * 
     * @param pasteboard
     */
    public void setPasteboard(java.lang.String pasteboard) {
        this.pasteboard = pasteboard;
    }


    /**
     * Gets the scale value for this JPEGRenderRequest.
     * 
     * @return scale
     */
    public java.lang.String getScale() {
        return scale;
    }


    /**
     * Sets the scale value for this JPEGRenderRequest.
     * 
     * @param scale
     */
    public void setScale(java.lang.String scale) {
        this.scale = scale;
    }


    /**
     * Gets the showBoxOutline value for this JPEGRenderRequest.
     * 
     * @return showBoxOutline
     */
    public java.lang.String getShowBoxOutline() {
        return showBoxOutline;
    }


    /**
     * Sets the showBoxOutline value for this JPEGRenderRequest.
     * 
     * @param showBoxOutline
     */
    public void setShowBoxOutline(java.lang.String showBoxOutline) {
        this.showBoxOutline = showBoxOutline;
    }


    /**
     * Gets the spread value for this JPEGRenderRequest.
     * 
     * @return spread
     */
    public java.lang.String getSpread() {
        return spread;
    }


    /**
     * Sets the spread value for this JPEGRenderRequest.
     * 
     * @param spread
     */
    public void setSpread(java.lang.String spread) {
        this.spread = spread;
    }


    /**
     * Gets the spreadnum value for this JPEGRenderRequest.
     * 
     * @return spreadnum
     */
    public java.lang.String getSpreadnum() {
        return spreadnum;
    }


    /**
     * Sets the spreadnum value for this JPEGRenderRequest.
     * 
     * @param spreadnum
     */
    public void setSpreadnum(java.lang.String spreadnum) {
        this.spreadnum = spreadnum;
    }


    /**
     * Gets the updateFullRes value for this JPEGRenderRequest.
     * 
     * @return updateFullRes
     */
    public java.lang.String getUpdateFullRes() {
        return updateFullRes;
    }


    /**
     * Sets the updateFullRes value for this JPEGRenderRequest.
     * 
     * @param updateFullRes
     */
    public void setUpdateFullRes(java.lang.String updateFullRes) {
        this.updateFullRes = updateFullRes;
    }


    /**
     * Gets the updateImage value for this JPEGRenderRequest.
     * 
     * @return updateImage
     */
    public java.lang.String getUpdateImage() {
        return updateImage;
    }


    /**
     * Sets the updateImage value for this JPEGRenderRequest.
     * 
     * @param updateImage
     */
    public void setUpdateImage(java.lang.String updateImage) {
        this.updateImage = updateImage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof JPEGRenderRequest)) return false;
        JPEGRenderRequest other = (JPEGRenderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.afterPage==null && other.getAfterPage()==null) || 
             (this.afterPage!=null &&
              this.afterPage.equals(other.getAfterPage()))) &&
            ((this.box==null && other.getBox()==null) || 
             (this.box!=null &&
              this.box.equals(other.getBox()))) &&
            ((this.boxes==null && other.getBoxes()==null) || 
             (this.boxes!=null &&
              this.boxes.equals(other.getBoxes()))) &&
            ((this.download==null && other.getDownload()==null) || 
             (this.download!=null &&
              this.download.equals(other.getDownload()))) &&
            ((this.JPEGQuality==null && other.getJPEGQuality()==null) || 
             (this.JPEGQuality!=null &&
              this.JPEGQuality.equals(other.getJPEGQuality()))) &&
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.movePages==null && other.getMovePages()==null) || 
             (this.movePages!=null &&
              this.movePages.equals(other.getMovePages()))) &&
            ((this.overlap==null && other.getOverlap()==null) || 
             (this.overlap!=null &&
              this.overlap.equals(other.getOverlap()))) &&
            ((this.page==null && other.getPage()==null) || 
             (this.page!=null &&
              this.page.equals(other.getPage()))) &&
            ((this.pages==null && other.getPages()==null) || 
             (this.pages!=null &&
              this.pages.equals(other.getPages()))) &&
            ((this.pasteboard==null && other.getPasteboard()==null) || 
             (this.pasteboard!=null &&
              this.pasteboard.equals(other.getPasteboard()))) &&
            ((this.scale==null && other.getScale()==null) || 
             (this.scale!=null &&
              this.scale.equals(other.getScale()))) &&
            ((this.showBoxOutline==null && other.getShowBoxOutline()==null) || 
             (this.showBoxOutline!=null &&
              this.showBoxOutline.equals(other.getShowBoxOutline()))) &&
            ((this.spread==null && other.getSpread()==null) || 
             (this.spread!=null &&
              this.spread.equals(other.getSpread()))) &&
            ((this.spreadnum==null && other.getSpreadnum()==null) || 
             (this.spreadnum!=null &&
              this.spreadnum.equals(other.getSpreadnum()))) &&
            ((this.updateFullRes==null && other.getUpdateFullRes()==null) || 
             (this.updateFullRes!=null &&
              this.updateFullRes.equals(other.getUpdateFullRes()))) &&
            ((this.updateImage==null && other.getUpdateImage()==null) || 
             (this.updateImage!=null &&
              this.updateImage.equals(other.getUpdateImage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAfterPage() != null) {
            _hashCode += getAfterPage().hashCode();
        }
        if (getBox() != null) {
            _hashCode += getBox().hashCode();
        }
        if (getBoxes() != null) {
            _hashCode += getBoxes().hashCode();
        }
        if (getDownload() != null) {
            _hashCode += getDownload().hashCode();
        }
        if (getJPEGQuality() != null) {
            _hashCode += getJPEGQuality().hashCode();
        }
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getMovePages() != null) {
            _hashCode += getMovePages().hashCode();
        }
        if (getOverlap() != null) {
            _hashCode += getOverlap().hashCode();
        }
        if (getPage() != null) {
            _hashCode += getPage().hashCode();
        }
        if (getPages() != null) {
            _hashCode += getPages().hashCode();
        }
        if (getPasteboard() != null) {
            _hashCode += getPasteboard().hashCode();
        }
        if (getScale() != null) {
            _hashCode += getScale().hashCode();
        }
        if (getShowBoxOutline() != null) {
            _hashCode += getShowBoxOutline().hashCode();
        }
        if (getSpread() != null) {
            _hashCode += getSpread().hashCode();
        }
        if (getSpreadnum() != null) {
            _hashCode += getSpreadnum().hashCode();
        }
        if (getUpdateFullRes() != null) {
            _hashCode += getUpdateFullRes().hashCode();
        }
        if (getUpdateImage() != null) {
            _hashCode += getUpdateImage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(JPEGRenderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "JPEGRenderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("afterPage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "afterPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("box");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "box"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("download");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "download"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JPEGQuality");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "JPEGQuality"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("movePages");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "movePages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overlap");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "overlap"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("page");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "page"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pages");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pasteboard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pasteboard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scale");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scale"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showBoxOutline");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "showBoxOutline"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spread");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spread"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spreadnum");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spreadnum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateFullRes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "updateFullRes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateImage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "updateImage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
