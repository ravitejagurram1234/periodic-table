/**
 * TableStyle.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class TableStyle  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedTRowStyle continuedTRowStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTColStyle evenTColStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTRowStyle evenTRowStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.FirstTColStyle firstTColStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.FooterTRowStyle footerTRowStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HeadTRowStyle headTRowStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LastTColStyle lastTColStyle;

    private java.lang.String name;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTColStyle oddTColStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTRowStyle oddTRowStyle;

    private java.lang.String span;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TColStyle tcolStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TRowStyle trowStyle;

    private java.lang.String UID;

    private java.lang.String width;

    public TableStyle() {
    }

    public TableStyle(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedTRowStyle continuedTRowStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTColStyle evenTColStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTRowStyle evenTRowStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.FirstTColStyle firstTColStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.FooterTRowStyle footerTRowStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HeadTRowStyle headTRowStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LastTColStyle lastTColStyle,
           java.lang.String name,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTColStyle oddTColStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTRowStyle oddTRowStyle,
           java.lang.String span,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TColStyle tcolStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TRowStyle trowStyle,
           java.lang.String UID,
           java.lang.String width) {
        super(
            request);
        this.continuedTRowStyle = continuedTRowStyle;
        this.evenTColStyle = evenTColStyle;
        this.evenTRowStyle = evenTRowStyle;
        this.firstTColStyle = firstTColStyle;
        this.footerTRowStyle = footerTRowStyle;
        this.frame = frame;
        this.headTRowStyle = headTRowStyle;
        this.lastTColStyle = lastTColStyle;
        this.name = name;
        this.oddTColStyle = oddTColStyle;
        this.oddTRowStyle = oddTRowStyle;
        this.span = span;
        this.tcolStyle = tcolStyle;
        this.trowStyle = trowStyle;
        this.UID = UID;
        this.width = width;
    }


    /**
     * Gets the continuedTRowStyle value for this TableStyle.
     * 
     * @return continuedTRowStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedTRowStyle getContinuedTRowStyle() {
        return continuedTRowStyle;
    }


    /**
     * Sets the continuedTRowStyle value for this TableStyle.
     * 
     * @param continuedTRowStyle
     */
    public void setContinuedTRowStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.ContinuedTRowStyle continuedTRowStyle) {
        this.continuedTRowStyle = continuedTRowStyle;
    }


    /**
     * Gets the evenTColStyle value for this TableStyle.
     * 
     * @return evenTColStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTColStyle getEvenTColStyle() {
        return evenTColStyle;
    }


    /**
     * Sets the evenTColStyle value for this TableStyle.
     * 
     * @param evenTColStyle
     */
    public void setEvenTColStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTColStyle evenTColStyle) {
        this.evenTColStyle = evenTColStyle;
    }


    /**
     * Gets the evenTRowStyle value for this TableStyle.
     * 
     * @return evenTRowStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTRowStyle getEvenTRowStyle() {
        return evenTRowStyle;
    }


    /**
     * Sets the evenTRowStyle value for this TableStyle.
     * 
     * @param evenTRowStyle
     */
    public void setEvenTRowStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.EvenTRowStyle evenTRowStyle) {
        this.evenTRowStyle = evenTRowStyle;
    }


    /**
     * Gets the firstTColStyle value for this TableStyle.
     * 
     * @return firstTColStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.FirstTColStyle getFirstTColStyle() {
        return firstTColStyle;
    }


    /**
     * Sets the firstTColStyle value for this TableStyle.
     * 
     * @param firstTColStyle
     */
    public void setFirstTColStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.FirstTColStyle firstTColStyle) {
        this.firstTColStyle = firstTColStyle;
    }


    /**
     * Gets the footerTRowStyle value for this TableStyle.
     * 
     * @return footerTRowStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.FooterTRowStyle getFooterTRowStyle() {
        return footerTRowStyle;
    }


    /**
     * Sets the footerTRowStyle value for this TableStyle.
     * 
     * @param footerTRowStyle
     */
    public void setFooterTRowStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.FooterTRowStyle footerTRowStyle) {
        this.footerTRowStyle = footerTRowStyle;
    }


    /**
     * Gets the frame value for this TableStyle.
     * 
     * @return frame
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame getFrame() {
        return frame;
    }


    /**
     * Sets the frame value for this TableStyle.
     * 
     * @param frame
     */
    public void setFrame(com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame) {
        this.frame = frame;
    }


    /**
     * Gets the headTRowStyle value for this TableStyle.
     * 
     * @return headTRowStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HeadTRowStyle getHeadTRowStyle() {
        return headTRowStyle;
    }


    /**
     * Sets the headTRowStyle value for this TableStyle.
     * 
     * @param headTRowStyle
     */
    public void setHeadTRowStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.HeadTRowStyle headTRowStyle) {
        this.headTRowStyle = headTRowStyle;
    }


    /**
     * Gets the lastTColStyle value for this TableStyle.
     * 
     * @return lastTColStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LastTColStyle getLastTColStyle() {
        return lastTColStyle;
    }


    /**
     * Sets the lastTColStyle value for this TableStyle.
     * 
     * @param lastTColStyle
     */
    public void setLastTColStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.LastTColStyle lastTColStyle) {
        this.lastTColStyle = lastTColStyle;
    }


    /**
     * Gets the name value for this TableStyle.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this TableStyle.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the oddTColStyle value for this TableStyle.
     * 
     * @return oddTColStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTColStyle getOddTColStyle() {
        return oddTColStyle;
    }


    /**
     * Sets the oddTColStyle value for this TableStyle.
     * 
     * @param oddTColStyle
     */
    public void setOddTColStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTColStyle oddTColStyle) {
        this.oddTColStyle = oddTColStyle;
    }


    /**
     * Gets the oddTRowStyle value for this TableStyle.
     * 
     * @return oddTRowStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTRowStyle getOddTRowStyle() {
        return oddTRowStyle;
    }


    /**
     * Sets the oddTRowStyle value for this TableStyle.
     * 
     * @param oddTRowStyle
     */
    public void setOddTRowStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.OddTRowStyle oddTRowStyle) {
        this.oddTRowStyle = oddTRowStyle;
    }


    /**
     * Gets the span value for this TableStyle.
     * 
     * @return span
     */
    public java.lang.String getSpan() {
        return span;
    }


    /**
     * Sets the span value for this TableStyle.
     * 
     * @param span
     */
    public void setSpan(java.lang.String span) {
        this.span = span;
    }


    /**
     * Gets the tcolStyle value for this TableStyle.
     * 
     * @return tcolStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TColStyle getTcolStyle() {
        return tcolStyle;
    }


    /**
     * Sets the tcolStyle value for this TableStyle.
     * 
     * @param tcolStyle
     */
    public void setTcolStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.TColStyle tcolStyle) {
        this.tcolStyle = tcolStyle;
    }


    /**
     * Gets the trowStyle value for this TableStyle.
     * 
     * @return trowStyle
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TRowStyle getTrowStyle() {
        return trowStyle;
    }


    /**
     * Sets the trowStyle value for this TableStyle.
     * 
     * @param trowStyle
     */
    public void setTrowStyle(com.socgen.sgs.api.quark.engine.integration.soap.generated.TRowStyle trowStyle) {
        this.trowStyle = trowStyle;
    }


    /**
     * Gets the UID value for this TableStyle.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this TableStyle.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the width value for this TableStyle.
     * 
     * @return width
     */
    public java.lang.String getWidth() {
        return width;
    }


    /**
     * Sets the width value for this TableStyle.
     * 
     * @param width
     */
    public void setWidth(java.lang.String width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TableStyle)) return false;
        TableStyle other = (TableStyle) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.continuedTRowStyle==null && other.getContinuedTRowStyle()==null) || 
             (this.continuedTRowStyle!=null &&
              this.continuedTRowStyle.equals(other.getContinuedTRowStyle()))) &&
            ((this.evenTColStyle==null && other.getEvenTColStyle()==null) || 
             (this.evenTColStyle!=null &&
              this.evenTColStyle.equals(other.getEvenTColStyle()))) &&
            ((this.evenTRowStyle==null && other.getEvenTRowStyle()==null) || 
             (this.evenTRowStyle!=null &&
              this.evenTRowStyle.equals(other.getEvenTRowStyle()))) &&
            ((this.firstTColStyle==null && other.getFirstTColStyle()==null) || 
             (this.firstTColStyle!=null &&
              this.firstTColStyle.equals(other.getFirstTColStyle()))) &&
            ((this.footerTRowStyle==null && other.getFooterTRowStyle()==null) || 
             (this.footerTRowStyle!=null &&
              this.footerTRowStyle.equals(other.getFooterTRowStyle()))) &&
            ((this.frame==null && other.getFrame()==null) || 
             (this.frame!=null &&
              this.frame.equals(other.getFrame()))) &&
            ((this.headTRowStyle==null && other.getHeadTRowStyle()==null) || 
             (this.headTRowStyle!=null &&
              this.headTRowStyle.equals(other.getHeadTRowStyle()))) &&
            ((this.lastTColStyle==null && other.getLastTColStyle()==null) || 
             (this.lastTColStyle!=null &&
              this.lastTColStyle.equals(other.getLastTColStyle()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.oddTColStyle==null && other.getOddTColStyle()==null) || 
             (this.oddTColStyle!=null &&
              this.oddTColStyle.equals(other.getOddTColStyle()))) &&
            ((this.oddTRowStyle==null && other.getOddTRowStyle()==null) || 
             (this.oddTRowStyle!=null &&
              this.oddTRowStyle.equals(other.getOddTRowStyle()))) &&
            ((this.span==null && other.getSpan()==null) || 
             (this.span!=null &&
              this.span.equals(other.getSpan()))) &&
            ((this.tcolStyle==null && other.getTcolStyle()==null) || 
             (this.tcolStyle!=null &&
              this.tcolStyle.equals(other.getTcolStyle()))) &&
            ((this.trowStyle==null && other.getTrowStyle()==null) || 
             (this.trowStyle!=null &&
              this.trowStyle.equals(other.getTrowStyle()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.width==null && other.getWidth()==null) || 
             (this.width!=null &&
              this.width.equals(other.getWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getContinuedTRowStyle() != null) {
            _hashCode += getContinuedTRowStyle().hashCode();
        }
        if (getEvenTColStyle() != null) {
            _hashCode += getEvenTColStyle().hashCode();
        }
        if (getEvenTRowStyle() != null) {
            _hashCode += getEvenTRowStyle().hashCode();
        }
        if (getFirstTColStyle() != null) {
            _hashCode += getFirstTColStyle().hashCode();
        }
        if (getFooterTRowStyle() != null) {
            _hashCode += getFooterTRowStyle().hashCode();
        }
        if (getFrame() != null) {
            _hashCode += getFrame().hashCode();
        }
        if (getHeadTRowStyle() != null) {
            _hashCode += getHeadTRowStyle().hashCode();
        }
        if (getLastTColStyle() != null) {
            _hashCode += getLastTColStyle().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOddTColStyle() != null) {
            _hashCode += getOddTColStyle().hashCode();
        }
        if (getOddTRowStyle() != null) {
            _hashCode += getOddTRowStyle().hashCode();
        }
        if (getSpan() != null) {
            _hashCode += getSpan().hashCode();
        }
        if (getTcolStyle() != null) {
            _hashCode += getTcolStyle().hashCode();
        }
        if (getTrowStyle() != null) {
            _hashCode += getTrowStyle().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getWidth() != null) {
            _hashCode += getWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TableStyle.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TableStyle"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("continuedTRowStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "continuedTRowStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ContinuedTRowStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("evenTColStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "evenTColStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "EvenTColStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("evenTRowStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "evenTRowStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "EvenTRowStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstTColStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "firstTColStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "FirstTColStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("footerTRowStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "footerTRowStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "FooterTRowStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frame");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "frame"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Frame"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headTRowStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "headTRowStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HeadTRowStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastTColStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "lastTColStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LastTColStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oddTColStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "oddTColStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OddTColStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oddTRowStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "oddTRowStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OddTRowStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("span");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "span"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tcolStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tcolStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TColStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trowStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "trowStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TRowStyle"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("width");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "width"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
