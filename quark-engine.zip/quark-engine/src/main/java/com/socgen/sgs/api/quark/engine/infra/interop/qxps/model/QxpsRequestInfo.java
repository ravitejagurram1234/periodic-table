package com.socgen.sgs.api.quark.engine.infra.interop.qxps.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpMethod;

import java.net.URI;

@Getter
@Setter
@AllArgsConstructor
public class QxpsRequestInfo {

    private URI uri;
    private HttpMethod method;
    private byte[] data;
}

