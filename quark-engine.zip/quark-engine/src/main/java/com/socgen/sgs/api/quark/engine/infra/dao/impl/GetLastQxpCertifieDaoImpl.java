package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.GetLastQxpCertifieDao;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

/**
 * Calls Oracle function QXP_PK_RUN.Get_Last_Qxp_Certifie (2-arg → cursor) to load the last certified
 * QXP for a suivi + report type. Cross-reference: .NET QXPS_File_Manager.Get_Last_Qxp_Certifie used by
 * Task_QXP_Previous.Prepare.
 *
 * <p>ora.txt cursor columns: ID_DOCUMENT, CONTENU, NOM, FORMAT ('QXP').
 */
@Repository
@Slf4j
public class GetLastQxpCertifieDaoImpl implements GetLastQxpCertifieDao {

    private static final String RESULT_KEY = "result_cursor";
    private final SimpleJdbcCall getLastQxpCertifieCall;

    @Autowired
    public GetLastQxpCertifieDaoImpl(DataSource dataSource) {
        this.getLastQxpCertifieCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_Last_Qxp_Certifie")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR,
                                (rs, rowNum) -> mapFromResultSet(rs)),
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_id_type_rapport", Types.NUMERIC)
                );
    }

    @Override
    public DocumentDomain getLastQxpCertifie(int idSuivi, int idTypeRapport) {
        log.info("Fetching last certified QXP for idSuivi={}, idTypeRapport={}", idSuivi, idTypeRapport);

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_suivi", idSuivi)
                .addValue("p_id_type_rapport", idTypeRapport);

        try {
            Map<String, Object> result = getLastQxpCertifieCall.execute(params);

            @SuppressWarnings("unchecked")
            List<DocumentDomain> rows = (List<DocumentDomain>) result.get(RESULT_KEY);

            if (rows == null || rows.isEmpty()) {
                log.warn("No certified previous QXP found for idSuivi={}, idTypeRapport={}", idSuivi, idTypeRapport);
                return null;
            }
            return rows.get(0);
        } catch (Exception e) {
            log.error("Error fetching last certified QXP for idSuivi={}", idSuivi, e);
            throw new RuntimeException("Failed to fetch last certified QXP for idSuivi: " + idSuivi, e);
        }
    }

    private DocumentDomain mapFromResultSet(ResultSet rs) throws SQLException {
        DocumentDomain doc = new DocumentDomain();
        doc.setId(rs.getInt("id_document"));
        doc.setName(rs.getString("nom"));
        doc.setFormat(rs.getString("format"));
        doc.setPrefix(DocumentDomain.FILE_DOCUMENT_PREFIX);
        doc.setData(rs.getBytes("contenu"));
        // fileName = D_<id>.<format> (paths completed by the loader using the run pool + base path).
        doc.setFileName(String.format("%s_%d.%s", doc.getPrefix(), doc.getId(), doc.getFormat()));
        return doc;
    }
}