/**
 * QContentData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class QContentData  implements java.io.Serializable {
    private int actualServerPortUsed;

    private java.lang.String actualServerUsed;

    private java.lang.String contentType;

    private java.lang.String encodingType;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.QResponseHeader[] headers;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData[] multipartResponse;

    private java.lang.String responseURL;

    private byte[] streamValue;

    private java.lang.String textData;

    public QContentData() {
    }

    public QContentData(
           int actualServerPortUsed,
           java.lang.String actualServerUsed,
           java.lang.String contentType,
           java.lang.String encodingType,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QResponseHeader[] headers,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData[] multipartResponse,
           java.lang.String responseURL,
           byte[] streamValue,
           java.lang.String textData) {
           this.actualServerPortUsed = actualServerPortUsed;
           this.actualServerUsed = actualServerUsed;
           this.contentType = contentType;
           this.encodingType = encodingType;
           this.headers = headers;
           this.multipartResponse = multipartResponse;
           this.responseURL = responseURL;
           this.streamValue = streamValue;
           this.textData = textData;
    }


    /**
     * Gets the actualServerPortUsed value for this QContentData.
     * 
     * @return actualServerPortUsed
     */
    public int getActualServerPortUsed() {
        return actualServerPortUsed;
    }


    /**
     * Sets the actualServerPortUsed value for this QContentData.
     * 
     * @param actualServerPortUsed
     */
    public void setActualServerPortUsed(int actualServerPortUsed) {
        this.actualServerPortUsed = actualServerPortUsed;
    }


    /**
     * Gets the actualServerUsed value for this QContentData.
     * 
     * @return actualServerUsed
     */
    public java.lang.String getActualServerUsed() {
        return actualServerUsed;
    }


    /**
     * Sets the actualServerUsed value for this QContentData.
     * 
     * @param actualServerUsed
     */
    public void setActualServerUsed(java.lang.String actualServerUsed) {
        this.actualServerUsed = actualServerUsed;
    }


    /**
     * Gets the contentType value for this QContentData.
     * 
     * @return contentType
     */
    public java.lang.String getContentType() {
        return contentType;
    }


    /**
     * Sets the contentType value for this QContentData.
     * 
     * @param contentType
     */
    public void setContentType(java.lang.String contentType) {
        this.contentType = contentType;
    }


    /**
     * Gets the encodingType value for this QContentData.
     * 
     * @return encodingType
     */
    public java.lang.String getEncodingType() {
        return encodingType;
    }


    /**
     * Sets the encodingType value for this QContentData.
     * 
     * @param encodingType
     */
    public void setEncodingType(java.lang.String encodingType) {
        this.encodingType = encodingType;
    }


    /**
     * Gets the headers value for this QContentData.
     * 
     * @return headers
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QResponseHeader[] getHeaders() {
        return headers;
    }


    /**
     * Sets the headers value for this QContentData.
     * 
     * @param headers
     */
    public void setHeaders(com.socgen.sgs.api.quark.engine.integration.soap.generated.QResponseHeader[] headers) {
        this.headers = headers;
    }


    /**
     * Gets the multipartResponse value for this QContentData.
     * 
     * @return multipartResponse
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData[] getMultipartResponse() {
        return multipartResponse;
    }


    /**
     * Sets the multipartResponse value for this QContentData.
     * 
     * @param multipartResponse
     */
    public void setMultipartResponse(com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData[] multipartResponse) {
        this.multipartResponse = multipartResponse;
    }


    /**
     * Gets the responseURL value for this QContentData.
     * 
     * @return responseURL
     */
    public java.lang.String getResponseURL() {
        return responseURL;
    }


    /**
     * Sets the responseURL value for this QContentData.
     * 
     * @param responseURL
     */
    public void setResponseURL(java.lang.String responseURL) {
        this.responseURL = responseURL;
    }


    /**
     * Gets the streamValue value for this QContentData.
     * 
     * @return streamValue
     */
    public byte[] getStreamValue() {
        return streamValue;
    }


    /**
     * Sets the streamValue value for this QContentData.
     * 
     * @param streamValue
     */
    public void setStreamValue(byte[] streamValue) {
        this.streamValue = streamValue;
    }


    /**
     * Gets the textData value for this QContentData.
     * 
     * @return textData
     */
    public java.lang.String getTextData() {
        return textData;
    }


    /**
     * Sets the textData value for this QContentData.
     * 
     * @param textData
     */
    public void setTextData(java.lang.String textData) {
        this.textData = textData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QContentData)) return false;
        QContentData other = (QContentData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.actualServerPortUsed == other.getActualServerPortUsed() &&
            ((this.actualServerUsed==null && other.getActualServerUsed()==null) || 
             (this.actualServerUsed!=null &&
              this.actualServerUsed.equals(other.getActualServerUsed()))) &&
            ((this.contentType==null && other.getContentType()==null) || 
             (this.contentType!=null &&
              this.contentType.equals(other.getContentType()))) &&
            ((this.encodingType==null && other.getEncodingType()==null) || 
             (this.encodingType!=null &&
              this.encodingType.equals(other.getEncodingType()))) &&
            ((this.headers==null && other.getHeaders()==null) || 
             (this.headers!=null &&
              java.util.Arrays.equals(this.headers, other.getHeaders()))) &&
            ((this.multipartResponse==null && other.getMultipartResponse()==null) || 
             (this.multipartResponse!=null &&
              java.util.Arrays.equals(this.multipartResponse, other.getMultipartResponse()))) &&
            ((this.responseURL==null && other.getResponseURL()==null) || 
             (this.responseURL!=null &&
              this.responseURL.equals(other.getResponseURL()))) &&
            ((this.streamValue==null && other.getStreamValue()==null) || 
             (this.streamValue!=null &&
              java.util.Arrays.equals(this.streamValue, other.getStreamValue()))) &&
            ((this.textData==null && other.getTextData()==null) || 
             (this.textData!=null &&
              this.textData.equals(other.getTextData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getActualServerPortUsed();
        if (getActualServerUsed() != null) {
            _hashCode += getActualServerUsed().hashCode();
        }
        if (getContentType() != null) {
            _hashCode += getContentType().hashCode();
        }
        if (getEncodingType() != null) {
            _hashCode += getEncodingType().hashCode();
        }
        if (getHeaders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHeaders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHeaders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMultipartResponse() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMultipartResponse());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMultipartResponse(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getResponseURL() != null) {
            _hashCode += getResponseURL().hashCode();
        }
        if (getStreamValue() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getStreamValue());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getStreamValue(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTextData() != null) {
            _hashCode += getTextData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QContentData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://command.manager.quark.com", "QContentData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("actualServerPortUsed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "actualServerPortUsed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("actualServerUsed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "actualServerUsed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contentType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("encodingType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "encodingType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headers");
        elemField.setXmlName(new javax.xml.namespace.QName("", "headers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://command.manager.quark.com", "QResponseHeader"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("multipartResponse");
        elemField.setXmlName(new javax.xml.namespace.QName("", "multipartResponse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://command.manager.quark.com", "QContentData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseURL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "responseURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("streamValue");
        elemField.setXmlName(new javax.xml.namespace.QName("", "streamValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textData");
        elemField.setXmlName(new javax.xml.namespace.QName("", "textData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
