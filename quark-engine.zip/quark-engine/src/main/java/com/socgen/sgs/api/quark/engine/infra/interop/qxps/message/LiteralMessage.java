package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

/**
 * QXPS GET message for fetching a file from the pool without modification.
 * Used to retrieve a previously saved QXP file.
 *
 * URL: {baseUrl}/literal/{documentName}
 *
 * Cross-reference: .NET QXPS_Message_Literal
 */
public class LiteralMessage implements QxpsMessage {

    private static final String MESSAGE_PATH = "literal";

    @Override
    public String getCommandPath() {
        return MESSAGE_PATH;
    }

    @Override
    public String getCommandQuery() {
        return null;
    }

    @Override
    public byte[] getData() {
        return null;
    }

    @Override
    public boolean isPost() {
        return false;
    }

    @Override
    public MessagePriority getPriority() {
        return MessagePriority.BELOW_NORMAL;
    }
}