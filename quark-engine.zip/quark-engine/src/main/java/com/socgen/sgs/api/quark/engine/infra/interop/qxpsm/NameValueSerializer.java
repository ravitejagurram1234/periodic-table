package com.socgen.sgs.api.quark.engine.infra.interop.qxpsm;

import com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Serializes NameValueParam list into XML for both HTTP ParamsValue and SOAP calls.
 */
public final class NameValueSerializer {

    private NameValueSerializer() {
    }

    /**
     * Serialize name-value params to XML bytes.
     * Format:
     * <pre>
     * &lt;PARAMSVALUE&gt;
     *   &lt;NAMEVALUEPARAM PARAMNAME="boxName" TEXTVALUE="boxValue"/&gt;
     *   ...
     * &lt;/PARAMSVALUE&gt;
     * </pre>
     */
    public static byte[] toBytes(List<NameValueParam> nameValues) {
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            XMLOutputFactory factory = XMLOutputFactory.newInstance();
            XMLStreamWriter w = factory.createXMLStreamWriter(os, "UTF-8");

            w.writeStartDocument("UTF-8", "1.0");
            w.writeStartElement("PARAMSVALUE");
            for (NameValueParam nv : nameValues) {
                w.writeEmptyElement("NAMEVALUEPARAM");
                if (nv.getParamName() != null) {
                    w.writeAttribute("PARAMNAME", nv.getParamName());
                }
                if (nv.getTextValue() != null) {
                    w.writeAttribute("TEXTVALUE", nv.getTextValue());
                }
            }
            w.writeEndElement();
            w.writeEndDocument();
            w.close();

            return os.toByteArray();
        } catch (XMLStreamException e) {
            throw new RuntimeException("Failed to serialize NameValueParams", e);
        }
    }
}