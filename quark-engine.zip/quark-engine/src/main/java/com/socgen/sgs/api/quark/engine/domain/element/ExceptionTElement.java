package com.socgen.sgs.api.quark.engine.domain.element;

/**
 * Unchecked exception raised while evaluating a template element (TBox/TTable/TGroup).
 *
 * <p>Cross-reference: .NET {@code QXP.Engine.Core.BusinessObject.Dynamique.Template.Exception_TElement}.
 * Thrown by {@code TGroup.evaluate} on a structural problem (unknown sub-element, nested sub-group) and
 * caught by {@code QxpProject.evaluatePendingGroups}, which records it as an UNSPECIFIED run error
 * (mirroring .NET {@code QXP_Project} → {@code task.Run.Errors.Add(tex.ToString())}, the string overload
 * that resolves to {@code Error_Type.Unspecified}). It is unchecked so it propagates through
 * {@code evaluate()} (which is not declared to throw) to the same generation-abort boundary as other
 * engine fatal errors when not caught.
 */
public class ExceptionTElement extends RuntimeException {

    public ExceptionTElement(String message) {
        super(message);
    }
}