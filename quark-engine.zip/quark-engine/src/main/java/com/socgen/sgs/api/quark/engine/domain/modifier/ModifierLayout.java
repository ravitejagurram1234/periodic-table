package com.socgen.sgs.api.quark.engine.domain.modifier;

import com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents a layout in a modifier project hierarchy.
 *
 * Cross-reference: QXP.Engine.Core.Layout (Modifier namespace)
 */
@Getter
@Setter
public class ModifierLayout {

    private String name;
    private final Map<String, ModifierSpread> spreads = new LinkedHashMap<>();

    public ModifierLayout() {
    }

    /**
     * Build SDK Spread array sorted by spread UID (numeric order).
     * Cross-reference: .NET Layout.GetSDKSpreads()
     */
    public Spread[] getSdkSpreads() {
        List<Spread> sdkSpreads = new ArrayList<>();

        // Sort spreads by numeric UID (ascending)
        List<Map.Entry<String, ModifierSpread>> sorted = new ArrayList<>(spreads.entrySet());
        sorted.sort(Comparator.comparingInt(e -> {
            try { return Integer.parseInt(e.getKey()); }
            catch (NumberFormatException ex) { return Integer.MAX_VALUE; }
        }));

        for (Map.Entry<String, ModifierSpread> entry : sorted) {
            ModifierSpread sp = entry.getValue();
            Spread spread = new Spread();
            spread.setUID(sp.getUid());
            spread.setBoxes(sp.getSdkBoxes());
            spread.setTables(sp.getSdkTables());
            spread.setPages(sp.getSdkPages());

            if (sp.isCreate()) {
                spread.setOperation("CREATE");
            }

            sdkSpreads.add(spread);

            // Extra boxes → separate spread with same UID
            if (!sp.getBoxesExtra().isEmpty()) {
                Spread extraSpread = new Spread();
                extraSpread.setUID(sp.getUid());
                extraSpread.setBoxes(sp.getSdkBoxesExtra());
                sdkSpreads.add(extraSpread);
            }
        }

        return sdkSpreads.toArray(new Spread[0]);
    }
}