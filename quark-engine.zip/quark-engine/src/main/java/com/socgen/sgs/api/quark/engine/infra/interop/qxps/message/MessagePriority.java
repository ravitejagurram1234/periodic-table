package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

/**
 * Priority levels for QXPS direct-call messages.
 * <p>
 * When several messages are combined into a single QuarkXPress Server URL, they are
 * sorted by ascending priority: the lower the code, the earlier the message's path/query
 * fragment appears in the combined URL.
 *
 * <p>Cross-reference: .NET QXP.Interop.QuarkServer.Message_Priority
 * (Lowest=1, BelowNormal=2, Normal=3, AboveNormal=4, Highest=5).
 */
public enum MessagePriority {

    LOWEST(1),
    BELOW_NORMAL(2),
    NORMAL(3),
    ABOVE_NORMAL(4),
    HIGHEST(5);

    private final int code;

    MessagePriority(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}