package com.socgen.sgs.api.quark.engine.infra.interop.qxps.request;

import com.socgen.sgs.api.quark.engine.infra.interop.qxps.config.QxpsProperties;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.message.QxpsMessage;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.model.QxpsRequestInfo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@Component
@RequiredArgsConstructor
public class QxpsRequestBuilder {

    private final QxpsProperties qxpsProperties;

    /** Builds request info from server config, document name and message params. */
    public QxpsRequestInfo build(String documentName, QxpsMessage message) {
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(qxpsProperties.getServer().getUrl());

        String path = message.getCommandPath();
        if (path != null && !path.isEmpty()) {
            uriBuilder.pathSegment(path);
        }
        uriBuilder.pathSegment(documentName);

        String query = message.getCommandQuery();
        if (query != null && !query.isEmpty()) {
            uriBuilder.query(query);
        }

        URI uri = uriBuilder.build(true).toUri();
        HttpMethod method = message.isPost() ? HttpMethod.POST : HttpMethod.GET;
        byte[] data = message.isPost() ? message.getData() : null;

        return new QxpsRequestInfo(uri, method, data);
    }
}

