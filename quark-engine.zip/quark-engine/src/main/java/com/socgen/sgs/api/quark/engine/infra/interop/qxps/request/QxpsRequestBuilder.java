package com.socgen.sgs.api.quark.engine.infra.interop.qxps.request;

import com.socgen.sgs.api.quark.engine.infra.interop.qxps.config.QxpsProperties;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.message.QxpsMessage;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.model.QxpsRequestInfo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Builds the QuarkXPress Server call URL from one or more messages.
 *
 * <p>Cross-reference: .NET QXPS_Request_Message.Get_Request_Message_Info().
 * Messages are sorted by ascending priority, their paths are concatenated with '/',
 * the document name is appended last, and their queries are concatenated with '&' —
 * producing ONE URL for ONE HTTP call (not one call per message).
 */
@Component
@RequiredArgsConstructor
public class QxpsRequestBuilder {

    private final QxpsProperties qxpsProperties;

    /**
     * Single-message convenience overload (standalone calls: addfile, literal, xml, delete...).
     * Cross-reference: .NET QXPS_Helper one-message QXPS_Call.
     */
    public QxpsRequestInfo build(String documentName, QxpsMessage message) {
        return buildCombined(documentName, List.of(message));
    }

    /**
     * Combines several messages into a single QuarkXPress Server URL.
     * Cross-reference: .NET QXPS_Request_Message.Get_Request_Message_Info().
     */
    public QxpsRequestInfo buildCombined(String documentName, List<QxpsMessage> messages) {
        // A small ascending sort is required: the order of fragments in the call path matters.
        // Java's List.sort is stable, so messages of equal priority keep their insertion order.
        List<QxpsMessage> sorted = new ArrayList<>(messages);
        sorted.sort(Comparator.comparingInt(m -> m.getPriority().getCode()));

        List<String> paths = new ArrayList<>();
        List<String> queries = new ArrayList<>();
        String docName = documentName;
        boolean httpPost = false;
        byte[] data = new byte[0];

        for (QxpsMessage message : sorted) {
            String p = message.getCommandPath();
            String q = message.getCommandQuery();
            String d = message.getCommandDocument();
            if (isSet(p)) {
                paths.add(p);
            }
            if (isSet(d)) {
                docName = d;
            }
            if (isSet(q)) {
                queries.add(q);
            }
            if (message.isPost()) {
                httpPost = true;
                if (data.length > 0) {
                    throw new IllegalStateException("Only one POST stream is allowed per request message");
                }
                data = message.getData() != null ? message.getData() : new byte[0];
            }
        }

        // Document name is appended at the END of the path segments.
        paths.add(docName);

        String rawPath = String.join("/", paths);
        String rawQuery = String.join("&", queries);

        // Rebuild on the bare server URI (scheme://host:port), clearing any path/query — same as .NET.
        UriComponentsBuilder uriBuilder = UriComponentsBuilder
                .fromHttpUrl(qxpsProperties.getServer().getUrl())
                .replacePath("/" + rawPath);
        if (!rawQuery.isEmpty()) {
            uriBuilder.replaceQuery(rawQuery);
        }
        // build() then encode(): '/' and '&'/'=' stay as separators, while illegal characters
        // (spaces, backslashes in Windows pool paths, ...) are percent-encoded so the URI is valid.
        // QuarkXPress Server decodes them back to the original literal values.
        URI uri = uriBuilder.build().encode().toUri();

        HttpMethod method = httpPost ? HttpMethod.POST : HttpMethod.GET;
        return new QxpsRequestInfo(uri, method, httpPost ? data : null);
    }

    private static boolean isSet(String value) {
        return value != null && !value.isEmpty();
    }
}