package com.socgen.sgs.api.quark.engine.domain.port;

import com.socgen.sgs.api.quark.engine.domain.DocumentIdentity;

/**
 * Port for fetching XML content from QuarkXPress Server and parsing document identity.
 */
public interface DocumentIdentityPort {

    /**
     * Fetches XML content for a specific box from a document in the QXPS document pool.
     *
     * @param documentName the name of the document in the pool
     * @param boxName      the box name/ID to fetch (e.g., "DID")
     * @return the raw XML content string
     */
    String fetchXmlForBox(String documentName, String boxName);

    /**
     * Extracts text content from XML by the ID NAME attribute.
     *
     * @param xmlContent the raw XML string
     * @param idName     the value of the NAME attribute on the ID element
     * @return the text content, or null if not found
     */
    String getElementValueByIdName(String xmlContent, String idName);

    /**
     * Parses a pipe-separated identity string into a {@link DocumentIdentity}.
     * Format: ID_Fnd_Code|ID_Suivi|ID_Run|ID_Langue|Due_Date|Generation_DateTime|ID_Unit_Code(optional)
     *
     * @param identityString the raw pipe-separated string
     * @return a populated {@link DocumentIdentity}
     */
    DocumentIdentity parseDocumentIdentity(String identityString);
}

