/**
 * RequestServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public interface RequestServicePortType extends java.rmi.Remote {
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData getAppStudioConfig(java.lang.String param0, java.lang.String param1) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData processRequest(com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext param0) throws java.rmi.RemoteException;
    public void saveAllDocs(java.lang.String param0, java.lang.String param1) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOMFromXML(java.lang.String param0) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOM(java.lang.String param0) throws java.rmi.RemoteException;
    public java.lang.String createSession(long param0) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData processRequestEx(com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext param0, java.lang.String param1) throws java.rmi.RemoteException;
    public java.lang.String[] getOpenSessions() throws java.rmi.RemoteException;
    public void setPreferences(java.lang.String param0, int param1, java.lang.String param2, java.lang.String param3, com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences param4) throws java.rmi.RemoteException;
    public void openDoc(java.lang.String param0, java.lang.String param1, int param2, java.lang.String param3) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[] getOpenDocs(java.lang.String param0) throws java.rmi.RemoteException;
    public void closeSession(java.lang.String param0) throws java.rmi.RemoteException;
    public java.lang.String getXMLFromXPressDOM(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project param0) throws java.rmi.RemoteException;
    public void saveDoc(java.lang.String param0, java.lang.String param1, java.lang.String param2, java.lang.String param3) throws java.rmi.RemoteException;
    public void setAppStudioCredentials(java.lang.String param0, java.lang.String param1, java.lang.String param2, java.lang.String param3, java.lang.String param4, java.lang.String param5) throws java.rmi.RemoteException;
    public void clearAppStudioCredentials() throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOMEx(java.lang.String param0, com.socgen.sgs.api.quark.engine.integration.soap.generated.QXPressDOMOptions param1) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences getPreferences(java.lang.String param0, int param1, java.lang.String param2, java.lang.String param3) throws java.rmi.RemoteException;
    public void closeDoc(java.lang.String param0, java.lang.String param1) throws java.rmi.RemoteException;
    public void closeAllDocs(java.lang.String param0) throws java.rmi.RemoteException;
    public void newDoc(java.lang.String param0, java.lang.String param1, java.lang.String param2, java.lang.String param3, int param4, java.lang.String param5) throws java.rmi.RemoteException;
}
