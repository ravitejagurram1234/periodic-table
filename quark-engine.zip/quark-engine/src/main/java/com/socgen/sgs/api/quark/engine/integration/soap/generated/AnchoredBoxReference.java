/**
 * AnchoredBoxReference.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class AnchoredBoxReference  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignWithText;

    private java.lang.String baselineShift;

    private java.lang.String boxUID;

    private java.lang.String charStyle;

    private int index;

    private java.lang.String offset;

    private java.lang.String sending;

    private java.lang.String trackAmount;

    private java.lang.String value;

    public AnchoredBoxReference() {
    }

    public AnchoredBoxReference(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignWithText,
           java.lang.String baselineShift,
           java.lang.String boxUID,
           java.lang.String charStyle,
           int index,
           java.lang.String offset,
           java.lang.String sending,
           java.lang.String trackAmount,
           java.lang.String value) {
        super(
            request);
        this.alignWithText = alignWithText;
        this.baselineShift = baselineShift;
        this.boxUID = boxUID;
        this.charStyle = charStyle;
        this.index = index;
        this.offset = offset;
        this.sending = sending;
        this.trackAmount = trackAmount;
        this.value = value;
    }


    /**
     * Gets the alignWithText value for this AnchoredBoxReference.
     * 
     * @return alignWithText
     */
    public java.lang.String getAlignWithText() {
        return alignWithText;
    }


    /**
     * Sets the alignWithText value for this AnchoredBoxReference.
     * 
     * @param alignWithText
     */
    public void setAlignWithText(java.lang.String alignWithText) {
        this.alignWithText = alignWithText;
    }


    /**
     * Gets the baselineShift value for this AnchoredBoxReference.
     * 
     * @return baselineShift
     */
    public java.lang.String getBaselineShift() {
        return baselineShift;
    }


    /**
     * Sets the baselineShift value for this AnchoredBoxReference.
     * 
     * @param baselineShift
     */
    public void setBaselineShift(java.lang.String baselineShift) {
        this.baselineShift = baselineShift;
    }


    /**
     * Gets the boxUID value for this AnchoredBoxReference.
     * 
     * @return boxUID
     */
    public java.lang.String getBoxUID() {
        return boxUID;
    }


    /**
     * Sets the boxUID value for this AnchoredBoxReference.
     * 
     * @param boxUID
     */
    public void setBoxUID(java.lang.String boxUID) {
        this.boxUID = boxUID;
    }


    /**
     * Gets the charStyle value for this AnchoredBoxReference.
     * 
     * @return charStyle
     */
    public java.lang.String getCharStyle() {
        return charStyle;
    }


    /**
     * Sets the charStyle value for this AnchoredBoxReference.
     * 
     * @param charStyle
     */
    public void setCharStyle(java.lang.String charStyle) {
        this.charStyle = charStyle;
    }


    /**
     * Gets the index value for this AnchoredBoxReference.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this AnchoredBoxReference.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the offset value for this AnchoredBoxReference.
     * 
     * @return offset
     */
    public java.lang.String getOffset() {
        return offset;
    }


    /**
     * Sets the offset value for this AnchoredBoxReference.
     * 
     * @param offset
     */
    public void setOffset(java.lang.String offset) {
        this.offset = offset;
    }


    /**
     * Gets the sending value for this AnchoredBoxReference.
     * 
     * @return sending
     */
    public java.lang.String getSending() {
        return sending;
    }


    /**
     * Sets the sending value for this AnchoredBoxReference.
     * 
     * @param sending
     */
    public void setSending(java.lang.String sending) {
        this.sending = sending;
    }


    /**
     * Gets the trackAmount value for this AnchoredBoxReference.
     * 
     * @return trackAmount
     */
    public java.lang.String getTrackAmount() {
        return trackAmount;
    }


    /**
     * Sets the trackAmount value for this AnchoredBoxReference.
     * 
     * @param trackAmount
     */
    public void setTrackAmount(java.lang.String trackAmount) {
        this.trackAmount = trackAmount;
    }


    /**
     * Gets the value value for this AnchoredBoxReference.
     * 
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }


    /**
     * Sets the value value for this AnchoredBoxReference.
     * 
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AnchoredBoxReference)) return false;
        AnchoredBoxReference other = (AnchoredBoxReference) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignWithText==null && other.getAlignWithText()==null) || 
             (this.alignWithText!=null &&
              this.alignWithText.equals(other.getAlignWithText()))) &&
            ((this.baselineShift==null && other.getBaselineShift()==null) || 
             (this.baselineShift!=null &&
              this.baselineShift.equals(other.getBaselineShift()))) &&
            ((this.boxUID==null && other.getBoxUID()==null) || 
             (this.boxUID!=null &&
              this.boxUID.equals(other.getBoxUID()))) &&
            ((this.charStyle==null && other.getCharStyle()==null) || 
             (this.charStyle!=null &&
              this.charStyle.equals(other.getCharStyle()))) &&
            this.index == other.getIndex() &&
            ((this.offset==null && other.getOffset()==null) || 
             (this.offset!=null &&
              this.offset.equals(other.getOffset()))) &&
            ((this.sending==null && other.getSending()==null) || 
             (this.sending!=null &&
              this.sending.equals(other.getSending()))) &&
            ((this.trackAmount==null && other.getTrackAmount()==null) || 
             (this.trackAmount!=null &&
              this.trackAmount.equals(other.getTrackAmount()))) &&
            ((this.value==null && other.getValue()==null) || 
             (this.value!=null &&
              this.value.equals(other.getValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignWithText() != null) {
            _hashCode += getAlignWithText().hashCode();
        }
        if (getBaselineShift() != null) {
            _hashCode += getBaselineShift().hashCode();
        }
        if (getBoxUID() != null) {
            _hashCode += getBoxUID().hashCode();
        }
        if (getCharStyle() != null) {
            _hashCode += getCharStyle().hashCode();
        }
        _hashCode += getIndex();
        if (getOffset() != null) {
            _hashCode += getOffset().hashCode();
        }
        if (getSending() != null) {
            _hashCode += getSending().hashCode();
        }
        if (getTrackAmount() != null) {
            _hashCode += getTrackAmount().hashCode();
        }
        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AnchoredBoxReference.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AnchoredBoxReference"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignWithText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignWithText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("baselineShift");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "baselineShift"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxUID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("charStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "charStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "offset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sending");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "sending"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trackAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "trackAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
