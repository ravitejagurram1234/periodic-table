package com.socgen.sgs.api.quark.engine.domain.bloc;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;

import lombok.Getter;
import lombok.Setter;

/** Base class for all bloc types that modify the structure of a QuarkXPress document. */
@Getter
@Setter
public class BlocBase {
    private final String       name;
    private final TaskBase     task;
    private String             parentName                = "";
    private BlocActionEnum     action                    = BlocActionEnum.NONE;
    private String             condName                  = "";
    private int                relativePage              = 0;
    private int                pageId                    = Integer.MIN_VALUE;
    private int                pageIdOriginale           = Integer.MIN_VALUE;
    private boolean            pagination                = false;
    private int                indexMaquette             = 4;
    private boolean            lagSpread                 = false;
    private boolean            exclude                   = false;

    public BlocBase(TaskBase task, String name) {
        this.task = task;
        this.name = name;
    }

    /** Evaluates the bloc's page based on relative page offset.
     *  Cross-reference: .NET Bloc_Base.Evaluate_Page() */
    public void evaluatePage() {
        this.pageIdOriginale = this.pageId =
                task.getPageIdFromRelative(this.condName, this.relativePage);
    }

    /** Number of boxes contained in this bloc type. Override in subclasses. */
    public int getNbBox() {
        return 1;
    }

    /** Spread ID derived from the current page ID. */
    public int getSpreadId() {
        return task.getSpreadIdFromPageId(pageId, lagSpread);
    }
}
