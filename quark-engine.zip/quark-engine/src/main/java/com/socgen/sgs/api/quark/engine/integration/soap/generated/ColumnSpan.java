/**
 * ColumnSpan.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ColumnSpan  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String columnCount;

    private java.lang.String spaceAfter;

    private java.lang.String spaceBefore;

    public ColumnSpan() {
    }

    public ColumnSpan(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String columnCount,
           java.lang.String spaceAfter,
           java.lang.String spaceBefore) {
        super(
            request);
        this.columnCount = columnCount;
        this.spaceAfter = spaceAfter;
        this.spaceBefore = spaceBefore;
    }


    /**
     * Gets the columnCount value for this ColumnSpan.
     * 
     * @return columnCount
     */
    public java.lang.String getColumnCount() {
        return columnCount;
    }


    /**
     * Sets the columnCount value for this ColumnSpan.
     * 
     * @param columnCount
     */
    public void setColumnCount(java.lang.String columnCount) {
        this.columnCount = columnCount;
    }


    /**
     * Gets the spaceAfter value for this ColumnSpan.
     * 
     * @return spaceAfter
     */
    public java.lang.String getSpaceAfter() {
        return spaceAfter;
    }


    /**
     * Sets the spaceAfter value for this ColumnSpan.
     * 
     * @param spaceAfter
     */
    public void setSpaceAfter(java.lang.String spaceAfter) {
        this.spaceAfter = spaceAfter;
    }


    /**
     * Gets the spaceBefore value for this ColumnSpan.
     * 
     * @return spaceBefore
     */
    public java.lang.String getSpaceBefore() {
        return spaceBefore;
    }


    /**
     * Sets the spaceBefore value for this ColumnSpan.
     * 
     * @param spaceBefore
     */
    public void setSpaceBefore(java.lang.String spaceBefore) {
        this.spaceBefore = spaceBefore;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ColumnSpan)) return false;
        ColumnSpan other = (ColumnSpan) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.columnCount==null && other.getColumnCount()==null) || 
             (this.columnCount!=null &&
              this.columnCount.equals(other.getColumnCount()))) &&
            ((this.spaceAfter==null && other.getSpaceAfter()==null) || 
             (this.spaceAfter!=null &&
              this.spaceAfter.equals(other.getSpaceAfter()))) &&
            ((this.spaceBefore==null && other.getSpaceBefore()==null) || 
             (this.spaceBefore!=null &&
              this.spaceBefore.equals(other.getSpaceBefore())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getColumnCount() != null) {
            _hashCode += getColumnCount().hashCode();
        }
        if (getSpaceAfter() != null) {
            _hashCode += getSpaceAfter().hashCode();
        }
        if (getSpaceBefore() != null) {
            _hashCode += getSpaceBefore().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ColumnSpan.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColumnSpan"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spaceAfter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spaceAfter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spaceBefore");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spaceBefore"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
