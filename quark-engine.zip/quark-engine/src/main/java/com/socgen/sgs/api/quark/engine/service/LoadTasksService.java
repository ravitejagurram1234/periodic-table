package com.socgen.sgs.api.quark.engine.service;

import com.socgen.sgs.api.quark.engine.domain.Run;

public interface LoadTasksService {
    void loadTasks(Run run);
}
