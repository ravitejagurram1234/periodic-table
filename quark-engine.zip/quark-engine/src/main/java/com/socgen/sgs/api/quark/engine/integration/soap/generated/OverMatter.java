/**
 * OverMatter.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class OverMatter  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi;

    public OverMatter() {
    }

    public OverMatter(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi) {
        super(
            request);
        this.anchoredBoxReferences = anchoredBoxReferences;
        this.groupCharacters = groupCharacters;
        this.hiddenData = hiddenData;
        this.index = index;
        this.paragraphs = paragraphs;
        this.richText = richText;
        this.rubi = rubi;
    }


    /**
     * Gets the anchoredBoxReferences value for this OverMatter.
     * 
     * @return anchoredBoxReferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] getAnchoredBoxReferences() {
        return anchoredBoxReferences;
    }


    /**
     * Sets the anchoredBoxReferences value for this OverMatter.
     * 
     * @param anchoredBoxReferences
     */
    public void setAnchoredBoxReferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences) {
        this.anchoredBoxReferences = anchoredBoxReferences;
    }


    /**
     * Gets the groupCharacters value for this OverMatter.
     * 
     * @return groupCharacters
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] getGroupCharacters() {
        return groupCharacters;
    }


    /**
     * Sets the groupCharacters value for this OverMatter.
     * 
     * @param groupCharacters
     */
    public void setGroupCharacters(com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters) {
        this.groupCharacters = groupCharacters;
    }


    /**
     * Gets the hiddenData value for this OverMatter.
     * 
     * @return hiddenData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] getHiddenData() {
        return hiddenData;
    }


    /**
     * Sets the hiddenData value for this OverMatter.
     * 
     * @param hiddenData
     */
    public void setHiddenData(com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData) {
        this.hiddenData = hiddenData;
    }


    /**
     * Gets the index value for this OverMatter.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this OverMatter.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the paragraphs value for this OverMatter.
     * 
     * @return paragraphs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] getParagraphs() {
        return paragraphs;
    }


    /**
     * Sets the paragraphs value for this OverMatter.
     * 
     * @param paragraphs
     */
    public void setParagraphs(com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs) {
        this.paragraphs = paragraphs;
    }


    /**
     * Gets the richText value for this OverMatter.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this OverMatter.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }


    /**
     * Gets the rubi value for this OverMatter.
     * 
     * @return rubi
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] getRubi() {
        return rubi;
    }


    /**
     * Sets the rubi value for this OverMatter.
     * 
     * @param rubi
     */
    public void setRubi(com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi) {
        this.rubi = rubi;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OverMatter)) return false;
        OverMatter other = (OverMatter) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.anchoredBoxReferences==null && other.getAnchoredBoxReferences()==null) || 
             (this.anchoredBoxReferences!=null &&
              java.util.Arrays.equals(this.anchoredBoxReferences, other.getAnchoredBoxReferences()))) &&
            ((this.groupCharacters==null && other.getGroupCharacters()==null) || 
             (this.groupCharacters!=null &&
              java.util.Arrays.equals(this.groupCharacters, other.getGroupCharacters()))) &&
            ((this.hiddenData==null && other.getHiddenData()==null) || 
             (this.hiddenData!=null &&
              java.util.Arrays.equals(this.hiddenData, other.getHiddenData()))) &&
            this.index == other.getIndex() &&
            ((this.paragraphs==null && other.getParagraphs()==null) || 
             (this.paragraphs!=null &&
              java.util.Arrays.equals(this.paragraphs, other.getParagraphs()))) &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText()))) &&
            ((this.rubi==null && other.getRubi()==null) || 
             (this.rubi!=null &&
              java.util.Arrays.equals(this.rubi, other.getRubi())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAnchoredBoxReferences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAnchoredBoxReferences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAnchoredBoxReferences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGroupCharacters() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGroupCharacters());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGroupCharacters(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHiddenData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHiddenData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHiddenData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getIndex();
        if (getParagraphs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParagraphs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParagraphs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRubi() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRubi());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRubi(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OverMatter.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "OverMatter"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredBoxReferences");
        elemField.setXmlName(new javax.xml.namespace.QName("", "anchoredBoxReferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AnchoredBoxReference"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupCharacters");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupCharacters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GroupCharacters"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hiddenData");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hiddenData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "HiddenData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paragraphs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paragraphs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Paragraph"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RichText"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rubi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rubi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Rubi"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
