package com.socgen.sgs.api.quark.engine.domain.task;

import lombok.Getter;

@Getter
public class TaskImagePosition {

    public static final String DEFAULT_IMAGE_POSITION_VALUES = "42,52;56,693;552,756;785,197";

    private static final TaskImagePosition DEFAULT = new TaskImagePosition(DEFAULT_IMAGE_POSITION_VALUES);

    private String left;
    private String top;
    private String right;
    private String bottom;

    public TaskImagePosition(String values) {
        String[] positionValues = (values != null ? values : "").split(";");

        if (positionValues.length == 4) {
            this.left = positionValues[0];
            this.top = positionValues[1];
            this.right = positionValues[2];
            this.bottom = positionValues[3];
        } else {
            this.left = DEFAULT.getLeft();
            this.top = DEFAULT.getTop();
            this.right = DEFAULT.getRight();
            this.bottom = DEFAULT.getBottom();
        }
    }
}
