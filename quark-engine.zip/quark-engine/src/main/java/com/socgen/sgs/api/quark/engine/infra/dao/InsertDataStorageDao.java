package com.socgen.sgs.api.quark.engine.infra.dao;

import java.time.LocalDateTime;

/**
 * DAO for inserting run data storage.
 *
 * Cross-reference: .NET Proxy_Store.Insert_Data_Storage
 * Oracle: QXP_PK_DATA_STORAGE.Insert_Data
 */
public interface InsertDataStorageDao {

    /**
     * Insert data storage entries.
     *
     * @param idSuivi                     suivi ID
     * @param idRun                       run ID
     * @param dateGeneration              generation date
     * @param storeType                   storage type (1=SQL, 2=DOCUMENT)
     * @param names                       bloc names
     * @param values                      bloc values
     * @param descriptifs                 descriptions
     * @param infos                       business info
     * @param historisationDifferentielle  true=differential merge, false=simple insert
     */
    void insertData(int idSuivi, int idRun, LocalDateTime dateGeneration,
                    int storeType, String[] names, String[] values,
                    String[] descriptifs, String[] infos,
                    boolean historisationDifferentielle);
}