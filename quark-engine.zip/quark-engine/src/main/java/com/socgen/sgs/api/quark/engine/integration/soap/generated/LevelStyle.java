/**
 * LevelStyle.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class LevelStyle  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String firstLevel;

    private java.lang.String fourthLevel;

    private java.lang.String letterHeadStyle;

    private java.lang.String secondLevel;

    private java.lang.String thirdLevel;

    public LevelStyle() {
    }

    public LevelStyle(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String firstLevel,
           java.lang.String fourthLevel,
           java.lang.String letterHeadStyle,
           java.lang.String secondLevel,
           java.lang.String thirdLevel) {
        super(
            request);
        this.firstLevel = firstLevel;
        this.fourthLevel = fourthLevel;
        this.letterHeadStyle = letterHeadStyle;
        this.secondLevel = secondLevel;
        this.thirdLevel = thirdLevel;
    }


    /**
     * Gets the firstLevel value for this LevelStyle.
     * 
     * @return firstLevel
     */
    public java.lang.String getFirstLevel() {
        return firstLevel;
    }


    /**
     * Sets the firstLevel value for this LevelStyle.
     * 
     * @param firstLevel
     */
    public void setFirstLevel(java.lang.String firstLevel) {
        this.firstLevel = firstLevel;
    }


    /**
     * Gets the fourthLevel value for this LevelStyle.
     * 
     * @return fourthLevel
     */
    public java.lang.String getFourthLevel() {
        return fourthLevel;
    }


    /**
     * Sets the fourthLevel value for this LevelStyle.
     * 
     * @param fourthLevel
     */
    public void setFourthLevel(java.lang.String fourthLevel) {
        this.fourthLevel = fourthLevel;
    }


    /**
     * Gets the letterHeadStyle value for this LevelStyle.
     * 
     * @return letterHeadStyle
     */
    public java.lang.String getLetterHeadStyle() {
        return letterHeadStyle;
    }


    /**
     * Sets the letterHeadStyle value for this LevelStyle.
     * 
     * @param letterHeadStyle
     */
    public void setLetterHeadStyle(java.lang.String letterHeadStyle) {
        this.letterHeadStyle = letterHeadStyle;
    }


    /**
     * Gets the secondLevel value for this LevelStyle.
     * 
     * @return secondLevel
     */
    public java.lang.String getSecondLevel() {
        return secondLevel;
    }


    /**
     * Sets the secondLevel value for this LevelStyle.
     * 
     * @param secondLevel
     */
    public void setSecondLevel(java.lang.String secondLevel) {
        this.secondLevel = secondLevel;
    }


    /**
     * Gets the thirdLevel value for this LevelStyle.
     * 
     * @return thirdLevel
     */
    public java.lang.String getThirdLevel() {
        return thirdLevel;
    }


    /**
     * Sets the thirdLevel value for this LevelStyle.
     * 
     * @param thirdLevel
     */
    public void setThirdLevel(java.lang.String thirdLevel) {
        this.thirdLevel = thirdLevel;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LevelStyle)) return false;
        LevelStyle other = (LevelStyle) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.firstLevel==null && other.getFirstLevel()==null) || 
             (this.firstLevel!=null &&
              this.firstLevel.equals(other.getFirstLevel()))) &&
            ((this.fourthLevel==null && other.getFourthLevel()==null) || 
             (this.fourthLevel!=null &&
              this.fourthLevel.equals(other.getFourthLevel()))) &&
            ((this.letterHeadStyle==null && other.getLetterHeadStyle()==null) || 
             (this.letterHeadStyle!=null &&
              this.letterHeadStyle.equals(other.getLetterHeadStyle()))) &&
            ((this.secondLevel==null && other.getSecondLevel()==null) || 
             (this.secondLevel!=null &&
              this.secondLevel.equals(other.getSecondLevel()))) &&
            ((this.thirdLevel==null && other.getThirdLevel()==null) || 
             (this.thirdLevel!=null &&
              this.thirdLevel.equals(other.getThirdLevel())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getFirstLevel() != null) {
            _hashCode += getFirstLevel().hashCode();
        }
        if (getFourthLevel() != null) {
            _hashCode += getFourthLevel().hashCode();
        }
        if (getLetterHeadStyle() != null) {
            _hashCode += getLetterHeadStyle().hashCode();
        }
        if (getSecondLevel() != null) {
            _hashCode += getSecondLevel().hashCode();
        }
        if (getThirdLevel() != null) {
            _hashCode += getThirdLevel().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LevelStyle.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LevelStyle"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "firstLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fourthLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fourthLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("letterHeadStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "letterHeadStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("secondLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "secondLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thirdLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "thirdLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
