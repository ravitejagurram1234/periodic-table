package com.socgen.sgs.api.quark.engine.domain.bloc;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Table;
import lombok.Getter;

/** Represents a table bloc in a QuarkXPress document. */
@Getter
public class BlocTable extends BlocBase {

    private final Table srcTable;

    public BlocTable(TaskBase task, String name) {
        super(task, name);
        this.srcTable = null;
    }

    public BlocTable(TaskBase task, String name, Table srcTable) {
        super(task, name);
        this.srcTable = srcTable;
    }
}

