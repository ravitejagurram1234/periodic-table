package com.socgen.sgs.api.quark.engine.domain;

import lombok.Getter;

/**
 * Enumeration representing the status of a Run
 * Maps to QXP_RUN.ID_STATUT_GENERATION in the database
 */
@Getter
public enum RunStatus {

    TO_GENERATE(1),
    GENERATED(2),
    ERROR(3),
    RUNNING(4);

    private final int statusCode;

    RunStatus(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Get RunStatus from status code
     */
    public static RunStatus fromCode(int code) {
        for (RunStatus status : values()) {
            if (status.statusCode == code) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status code: " + code);
    }

    public int getCode() {
        return statusCode;
    }

}
