package com.socgen.sgs.api.quark.engine.domain;

import lombok.Getter;

/**
 * Enumeration representing the status of a Run
 * Maps to QXP_RUN.ID_STATUT_GENERATION in the database
 */
@Getter
public enum RunStatus {

    TO_GENERATE(1, "ToGenerate"),
    GENERATED(2, "Generated"),
    ERROR(3, "Error"),
    RUNNING(4, "Running");

    private final int statusCode;

    /**
     * Stable status label persisted verbatim to QXP_AUDIT_RUN.END_STATUS.
     * Kept separate from the Java constant name on purpose, so the audit text stays
     * consistent with existing audit history and with status-based reporting
     * (GROUP BY / WHERE on END_STATUS). Do not derive from name() — the spelling is a contract.
     */
    private final String auditStatusLabel;

    RunStatus(int statusCode, String auditStatusLabel) {
        this.statusCode = statusCode;
        this.auditStatusLabel = auditStatusLabel;
    }

    /**
     * Get RunStatus from status code
     */
    public static RunStatus fromCode(int code) {
        for (RunStatus status : values()) {
            if (status.statusCode == code) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid status code: " + code);
    }

    public int getCode() {
        return statusCode;
    }

}