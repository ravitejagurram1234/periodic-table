package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunError;
import com.socgen.sgs.api.quark.engine.domain.dynamic.template.Template;
import com.socgen.sgs.api.quark.engine.domain.task.TaskDynamique;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritTemplateDao;
import com.socgen.sgs.api.quark.engine.mapper.TemplateMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Business component for loading templates from the database into a Run.
 *
 * Cross-reference: .NET Proxy_Template.Load_Templates(Run)
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class LoadTemplatesBusiness {

    private final GetGabaritTemplateDao getGabaritTemplateDao;
    private final TemplateMapper templateMapper;

    /**
     * Load all templates for the run's gabarit template into run.getTemplates().
     *
     * @param run the run to populate with templates
     */
    public void execute(Run run) {
        // .NET Run.cs:132-165 only loads the template + templates when at least one dynamic task is
        // TODO (GetEnumerable<Task_Dynamique>(true)); otherwise it does nothing. Finding #56.
        boolean hasDynamicTodo = run.getTasks().values().stream()
                .anyMatch(t -> t instanceof TaskDynamique && t.isTodo());
        if (!hasDynamicTodo) {
            log.info("No TODO dynamic task for run [{}], skipping template loading", run.getId());
            return;
        }

        int idGabaritTemplate = run.getRunProperties().getIdGabaritTemplate();
        if (idGabaritTemplate == Integer.MIN_VALUE) {
            // .NET raises Exception_Run(MSG_Missing_ID_Gabarit_Template, Gabarit.ID) → Bloquante:
            // a dynamic run with no template id is a hard configuration error, not a silent skip.
            // Finding #56.
            Object gabId = run.getGabarit() != null ? run.getGabarit().getId() : run.getId();
            run.getErrors().add(new RunError(RunError.BLOQUANTE, String.format(
                    "Manque l'identifiant du gabarit template pour le gabarit %s", gabId)));
            log.error("Missing id_gabarit_template for run [{}] which has TODO dynamic tasks", run.getId());
            return;
        }

        log.info("Loading templates for idGabaritTemplate={} in run [{}]",
                idGabaritTemplate, run.getId());

        // Load the gabarit TEMPLATE document itself FIRST (parity: .NET Run.cs:152
        // this.Gabarit_Template = Get_Gabarit_Template(this); then :157 Load_Templates(this)).
        // Dynamic tasks clone their blocs from this document — without it TaskDynamique.prepare
        // would upload the wrong document. Finding #6/#22.
        DocumentDomain gabaritTemplate = getGabaritTemplateDao.getGabaritTemplate(idGabaritTemplate);
        // The DAO builder sets fileName but not filePoolPath; populate it the same way the source
        // gabarit is set up (GetGabaritBusiness.preparePaths → getPoolPath), so the upload key and
        // every later pool lookup resolve to the same R_<runId>/<fileName> string. .NET sets it in
        // the Document ctor via GetPoolPath (Document.cs:118).
        gabaritTemplate.setFilePoolPath(run.getRunProperties().getPoolPath(gabaritTemplate.getFileName()));
        run.setGabaritTemplate(gabaritTemplate);

        // .NET Run_Base.Mode_Degrade degrades the run when EITHER the gabarit OR the gabarit_template
        // is too big — re-evaluate against the just-loaded template so an oversized template degrades
        // the run (the outer Step 3-6 gate in runProcessor then skips them). Finding #29.
        if (gabaritTemplate.evaluateModeDegrade(run.getSizeLimitBeforeFailSoft())) {
            log.warn("Gabarit template {} bytes exceeds limit {} → setting Mode_Degrade for run [{}]",
                    gabaritTemplate.getData().length, run.getSizeLimitBeforeFailSoft(), run.getId());
            run.getRunProperties().setModeDegrade(true);
        }

        List<Map<String, Object>> rows = getGabaritTemplateDao.getTemplates(idGabaritTemplate);

        run.getTemplates().clear();

        for (Map<String, Object> row : rows) {
            Template template = templateMapper.mapToTemplate(row);
            if (template != null) {
                run.getTemplates().put(template.getName(), template);
            }
        }

        log.info("Loaded {} templates for run [{}]", run.getTemplates().size(), run.getId());
    }
}