package com.socgen.sgs.api.quark.engine.infra.interop.qxps.helper;

import com.socgen.sgs.api.quark.engine.integration.soap.generated.*;
import lombok.extern.slf4j.Slf4j;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Serializes a SOAP Project into XML for the QXPS HTTP Modify command.
 * Uses StAX (XMLStreamWriter) for high-performance streaming XML generation.
 *
 * Cross-reference: QXP.Engine.Core.QXP_Project_Serializer
 */
@Slf4j
public final class QxpsProjectSerializer {

    private QxpsProjectSerializer() {
    }

    /**
     * Serialize Project to XML string.
     */
    public static String toXml(Project project) {
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            XMLOutputFactory factory = XMLOutputFactory.newInstance();
            XMLStreamWriter w = factory.createXMLStreamWriter(os, "UTF-8");

            w.writeStartDocument("UTF-8", "1.0");
            writeProject(w, project);
            w.writeEndDocument();
            w.close();

            return os.toString(StandardCharsets.UTF_8);
        } catch (XMLStreamException e) {
            throw new RuntimeException("Failed to serialize Project to XML", e);
        }
    }

    /**
     * Serialize Project to UTF-8 bytes for HTTP POST.
     */
    public static byte[] toBytes(Project project) {
        return toXml(project).getBytes(StandardCharsets.UTF_8);
    }

    // ========================================================================
    // XML writing — mirrors .NET QXP_Project_Serializer exactly
    // ========================================================================

    private static void writeProject(XMLStreamWriter w, Project project) throws XMLStreamException {
        if (project == null) return;
        w.writeStartElement("PROJECT");
        if (project.getLayouts() != null) {
            for (Layout layout : project.getLayouts()) {
                writeLayout(w, layout);
            }
        }
        w.writeEndElement();
    }

    private static void writeLayout(XMLStreamWriter w, Layout layout) throws XMLStreamException {
        if (layout == null) return;
        w.writeStartElement("LAYOUT");
        writeId(w, layout.getUID(), layout.getName());
        if (layout.getSpreads() != null) {
            for (Spread spread : layout.getSpreads()) {
                writeSpread(w, spread);
            }
        }
        w.writeEndElement();
    }

    private static void writeSpread(XMLStreamWriter w, Spread spread) throws XMLStreamException {
        if (spread == null) return;
        w.writeStartElement("SPREAD");
        writeAttr(w, "OPERATION", spread.getOperation());
        writeId(w, spread.getUID(), spread.getName());
        if (spread.getPages() != null) {
            for (Page page : spread.getPages()) {
                writePage(w, page);
            }
        }
        if (spread.getBoxes() != null) {
            for (Box box : spread.getBoxes()) {
                writeBox(w, box);
            }
        }
        if (spread.getTables() != null) {
            for (Table table : spread.getTables()) {
                writeTable(w, table);
            }
        }
        w.writeEndElement();
    }

    private static void writePage(XMLStreamWriter w, Page page) throws XMLStreamException {
        if (page == null) return;
        w.writeStartElement("PAGE");
        writeAttr(w, "OPERATION", page.getOperation());
        writeAttr(w, "MASTER", page.getMaster());
        writeAttr(w, "POSITION", page.getPosition());
        writeId(w, page.getUID(), page.getName());
        w.writeEndElement();
    }

    private static void writeBox(XMLStreamWriter w, Box box) throws XMLStreamException {
        if (box == null) return;
        w.writeStartElement("BOX");
        writeAttr(w, "OPERATION", box.getOperation());
        writeAttr(w, "BOXTYPE", box.getBoxType());
        writeAttr(w, "COLOR", box.getColor());
        writeAttr(w, "SHADE", box.getShade());
        writeAttr(w, "OPACITY", box.getOpacity());
        writeAttr(w, "ANCHOREDIN", box.getAnchoredIn());
        writeId(w, box.getUID(), box.getName());
        writeText(w, box.getText());
        writePicture(w, box.getPicture());
        writeGeometry(w, box.getGeometry());
        writeContent(w, box.getContent());
        writeShadow(w, box.getShadow());
        writeFrame(w, box.getFrame());
        w.writeEndElement();
    }

    private static void writeId(XMLStreamWriter w, String uid, String name) throws XMLStreamException {
        if ((uid == null || uid.isEmpty()) && (name == null || name.isEmpty())) return;
        w.writeStartElement("ID");
        writeAttr(w, "NAME", name);
        writeAttr(w, "UID", uid);
        w.writeEndElement();
    }

    private static void writeText(XMLStreamWriter w, Text text) throws XMLStreamException {
        if (text == null) return;
        w.writeStartElement("TEXT");
        writeAttr(w, "ANGLE", text.getAngle());
        writeAttr(w, "SKEW", text.getSkew());
        writeAttr(w, "COLUMNS", text.getColumns());
        writeAttr(w, "FLIPVERTICAL", text.getFlipVertical());
        writeAttr(w, "FLIPHORIZONTAL", text.getFlipHorizontal());
        writeAttr(w, "VERTICALALIGNMENT", text.getVerticalAlignment());
        writeAttr(w, "TEXTORIENTATION", text.getTextOrientation());
        writeStory(w, text.getStory());
        w.writeEndElement();
    }

    private static void writeStory(XMLStreamWriter w, Story story) throws XMLStreamException {
        if (story == null) return;
        w.writeStartElement("STORY");
        writeAttr(w, "CLEAROLDTEXT", story.getClearOldText());
        writeAttr(w, "FITTEXTTOBOX", story.getFitTextToBox());
        writeAttr(w, "FILE", story.getFile());
        writeAttr(w, "CONVERTQUOTES", story.getConvertQuotes());
        writeAttr(w, "INCLUDESTYLESHEETS", story.getIncludeStylesheets());
        if (story.getParagraphs() != null) {
            for (Paragraph p : story.getParagraphs()) {
                writeParagraph(w, p);
            }
        }
        w.writeEndElement();
    }

    private static void writeParagraph(XMLStreamWriter w, Paragraph paragraph) throws XMLStreamException {
        if (paragraph == null) return;
        w.writeStartElement("PARAGRAPH");
        writeAttr(w, "PARASTYLE", paragraph.getParaStyle());
        if (paragraph.getRichText() != null) {
            for (RichText rt : paragraph.getRichText()) {
                writeRichText(w, rt);
            }
        }
        w.writeEndElement();
    }

    private static void writeRichText(XMLStreamWriter w, RichText rt) throws XMLStreamException {
        if (rt == null) return;
        w.writeStartElement("RICHTEXT");
        writeAttr(w, "CHARSTYLE", rt.getCharStyle());
        writeAttr(w, "PLAIN", rt.getPlain());
        writeAttr(w, "BOLD", rt.getBold());
        writeAttr(w, "ITALIC", rt.getItalic());
        writeAttr(w, "FONT", rt.getFont());
        writeAttr(w, "SIZE", rt.getSize());
        writeAttr(w, "COLOR", rt.getColor());
        writeAttr(w, "SHADE", rt.getShade());
        writeAttr(w, "OPACITY", rt.getOpacity());
        writeAttr(w, "UNDERLINE", rt.getUnderline());
        writeAttr(w, "SUPERSCRIPT", rt.getSuperScript());
        writeAttr(w, "SUBSCRIPT", rt.getSubScript());
        writeAttr(w, "LANGUAGE", rt.getLanguage());
        if (rt.getValue() != null && !rt.getValue().isEmpty()) {
            w.writeCharacters(rt.getValue());
        }
        w.writeEndElement();
    }

    private static void writePicture(XMLStreamWriter w, Picture picture) throws XMLStreamException {
        if (picture == null) return;
        w.writeStartElement("PICTURE");
        writeAttr(w, "FIT", picture.getFit());
        writeAttr(w, "SCALEACROSS", picture.getScaleAcross());
        writeAttr(w, "SCALEDOWN", picture.getScaleDown());
        writeAttr(w, "OFFSETACROSS", picture.getOffsetAcross());
        writeAttr(w, "OFFSETDOWN", picture.getOffsetDown());
        writeAttr(w, "ANGLE", picture.getAngle());
        w.writeEndElement();
    }

    private static void writeGeometry(XMLStreamWriter w, Geometry geometry) throws XMLStreamException {
        if (geometry == null) return;
        w.writeStartElement("GEOMETRY");
        writeAttr(w, "SHAPE", geometry.getShape());
        writeAttr(w, "PAGE", geometry.getPage());
        writeAttr(w, "ANGLE", geometry.getAngle());
        writeAttr(w, "LAYER", geometry.getLayer());
        writePosition(w, geometry.getPosition());
        writeElem(w, "ALLOWBOXONTOPASTEBOARD", geometry.getAllowBoxOnToPasteboard());
        writeElem(w, "ALLOWBOXOFFPAGE", geometry.getAllowBoxOffPage());
        writeElem(w, "STACKINGORDER", geometry.getStackingOrder());
        // SUPPRESSOUTPUT: skip if value is "false" (default)
        if (geometry.getSuppressOutput() != null && !"false".equals(geometry.getSuppressOutput())) {
            writeElem(w, "SUPPRESSOUTPUT", geometry.getSuppressOutput());
        }
        writeRunaround(w, geometry.getRunaround());
        w.writeEndElement();
    }

    private static void writePosition(XMLStreamWriter w, Position pos) throws XMLStreamException {
        if (pos == null) return;
        w.writeStartElement("POSITION");
        writeElem(w, "TOP", pos.getTop());
        writeElem(w, "LEFT", pos.getLeft());
        writeElem(w, "BOTTOM", pos.getBottom());
        writeElem(w, "RIGHT", pos.getRight());
        w.writeEndElement();
    }

    private static void writeRunaround(XMLStreamWriter w, Runaround ra) throws XMLStreamException {
        if (ra == null) return;
        w.writeStartElement("RUNAROUND");
        writeAttr(w, "TYPE", ra.getType());
        w.writeEndElement();
    }

    private static void writeContent(XMLStreamWriter w, Content content) throws XMLStreamException {
        if (content == null) return;
        w.writeStartElement("CONTENT");
        writeAttr(w, "CONVERTQUOTES", content.getConvertQuotes());
        writeAttr(w, "INCLUDESTYLESHEETS", content.getIncludeStyleSheets());
        writeAttr(w, "FONTNAME", content.getFontName());
        if (content.getValue() != null && !content.getValue().isEmpty()) {
            w.writeCharacters(content.getValue());
        }
        w.writeEndElement();
    }

    private static void writeShadow(XMLStreamWriter w, Shadow shadow) throws XMLStreamException {
        if (shadow == null) return;
        w.writeStartElement("SHADOW");
        writeAttr(w, "COLOR", shadow.getColor());
        writeAttr(w, "SHADE", shadow.getShade());
        writeAttr(w, "OPACITY", shadow.getOpacity());
        writeAttr(w, "ANGLE", shadow.getAngle());
        writeAttr(w, "DISTANCE", shadow.getDistance());
        w.writeEndElement();
    }

    private static void writeFrame(XMLStreamWriter w, Frame frame) throws XMLStreamException {
        if (frame == null) return;
        w.writeStartElement("FRAME");
        writeAttr(w, "STYLE", frame.getStyle());
        writeAttr(w, "WIDTH", frame.getWidth());
        writeAttr(w, "COLOR", frame.getColor());
        writeAttr(w, "SHADE", frame.getShade());
        writeAttr(w, "OPACITY", frame.getOpacity());
        w.writeEndElement();
    }

    private static void writeTable(XMLStreamWriter w, Table table) throws XMLStreamException {
        if (table == null) return;
        w.writeStartElement("TABLE");
        writeAttr(w, "OPERATION", table.getOperation());
        writeAttr(w, "MAINTAINGEOMETRY", table.getMaintainGeometry());
        writeId(w, table.getUID(), table.getName());
        if (table.getDeleteCells() != null) {
            for (DeleteCells dc : table.getDeleteCells()) {
                writeDeleteCells(w, dc);
            }
        }
        if (table.getRows() != null) {
            for (Row row : table.getRows()) {
                writeRow(w, row);
            }
        }
        w.writeEndElement();
    }

    private static void writeDeleteCells(XMLStreamWriter w, DeleteCells dc) throws XMLStreamException {
        if (dc == null) return;
        w.writeStartElement("DELETECELLS");
        writeAttr(w, "TYPE", dc.getType());
        writeAttr(w, "BASEINDEX", dc.getBaseIndex());
        writeAttr(w, "DELETECOUNT", dc.getDeleteCount());
        w.writeEndElement();
    }

    private static void writeRow(XMLStreamWriter w, Row row) throws XMLStreamException {
        if (row == null) return;
        w.writeStartElement("ROW");
        writeAttr(w, "ROWHEIGHT", row.getRowHeight());
        if (row.getCells() != null) {
            for (Cell cell : row.getCells()) {
                writeCell(w, cell);
            }
        }
        w.writeEndElement();
    }

    private static void writeCell(XMLStreamWriter w, Cell cell) throws XMLStreamException {
        if (cell == null) return;
        w.writeStartElement("CELL");
        writeContent(w, cell.getContent());
        writeText(w, cell.getText());
        writePicture(w, cell.getPicture());
        w.writeEndElement();
    }

    // ========================================================================
    // Utility
    // ========================================================================

    private static void writeAttr(XMLStreamWriter w, String name, String value) throws XMLStreamException {
        if (value != null && !value.isEmpty()) {
            w.writeAttribute(name, value);
        }
    }

    private static void writeElem(XMLStreamWriter w, String name, String value) throws XMLStreamException {
        if (value != null && !value.isEmpty()) {
            w.writeStartElement(name);
            w.writeCharacters(value);
            w.writeEndElement();
        }
    }
}