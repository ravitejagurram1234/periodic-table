package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.task.TaskException;
import com.socgen.sgs.api.quark.engine.enums.TaskExceptionTypeEnum;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Map;

@Component
public class TaskExceptionMapper {

    public int getIdTache(Map<String, Object> row) {
        Object val = row.get("ID_TACHE");
        return val instanceof Number ? ((Number) val).intValue() : 0;
    }

    public String getNomBloc(Map<String, Object> row) {
        Object val = row.get("NOM_BLOC");
        return val != null ? val.toString() : "";
    }

    public TaskException mapToTaskException(Map<String, Object> row) {
        String nomBloc = getNomBloc(row);
        String nomTableau = getString(row, "NOM_TABLEAU");
        String strIndexLignes = getString(row, "INDEX_LIGNES");

        int[] indexLignes = parseIndexLignes(strIndexLignes);
        TaskExceptionTypeEnum type = (indexLignes.length > 0)
                ? TaskExceptionTypeEnum.LINE
                : TaskExceptionTypeEnum.TABLE;

        return new TaskException(nomTableau, nomBloc, indexLignes, type);
    }

    private int[] parseIndexLignes(String value) {
        if (value == null || value.isBlank()) {
            return new int[0];
        }
        return Arrays.stream(value.split("\\|"))
                .filter(s -> !s.isBlank())
                .mapToInt(Integer::parseInt)
                .toArray();
    }

    private String getString(Map<String, Object> row, String key) {
        Object val = row.get(key);
        return val != null ? val.toString() : null;
    }
}

