package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.task.TaskException;
import com.socgen.sgs.api.quark.engine.enums.TaskExceptionTypeEnum;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class TaskExceptionMapper {

    public int getIdTache(Map<String, Object> row) {
        Object val = row.get("ID_TACHE");
        return val instanceof Number ? ((Number) val).intValue() : 0;
    }

    public String getNomBloc(Map<String, Object> row) {
        Object val = row.get("NOM_BLOC");
        return val != null ? val.toString() : "";
    }

    public TaskException mapToTaskException(Map<String, Object> row) {
        String nomBloc = getNomBloc(row);
        String nomTableau = getString(row, "NOM_TABLEAU");
        String strIndexLignes = getString(row, "INDEX_LIGNES");

        int[] indexLignes = parseIndexLignes(strIndexLignes);
        TaskExceptionTypeEnum type = (indexLignes.length > 0)
                ? TaskExceptionTypeEnum.LINE
                : TaskExceptionTypeEnum.TABLE;

        return new TaskException(nomTableau, nomBloc, indexLignes, type);
    }

    private int[] parseIndexLignes(String value) {
        if (value == null || value.isBlank()) {
            return new int[0];
        }
        // Split keeping empty tokens and convert each WITHOUT throwing. Parity: .NET
        // Proxy_Task.cs:188 ToIntArray(value.Split('|')) keeps every token and Conversion.ToInt
        // returns int.MinValue for a blank/unparseable token (Decimal.TryParse(.., NumberStyles.Any)),
        // so a non-numeric token never aborts exception loading. Finding #52.
        String[] tokens = value.split("\\|", -1);
        int[] result = new int[tokens.length];
        for (int i = 0; i < tokens.length; i++) {
            result[i] = toInt(tokens[i]);
        }
        return result;
    }

    /** .NET Conversion.ToInt: parse value (spaces stripped); int.MinValue sentinel on blank/unparseable. */
    private int toInt(String token) {
        String v = token.replace(" ", "");
        if (v.isEmpty()) {
            return Integer.MIN_VALUE;
        }
        try {
            return new java.math.BigDecimal(v).intValue(); // truncates toward zero, like (int)decimal in .NET
        } catch (NumberFormatException e) {
            return Integer.MIN_VALUE;
        }
    }

    private String getString(Map<String, Object> row, String key) {
        Object val = row.get(key);
        return val != null ? val.toString() : null;
    }
}