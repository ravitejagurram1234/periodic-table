package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.business.ProcessSqlBusiness;
import com.socgen.sgs.api.quark.engine.domain.task.TaskSql;
import com.socgen.sgs.api.quark.engine.service.task.TaskProcessStrategy;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/** Delegates SQL task processing to ProcessSqlBusiness. */
@Component
@RequiredArgsConstructor
public class SqlTaskProcessStrategy implements TaskProcessStrategy<TaskSql> {

    private final ProcessSqlBusiness processSqlBusiness;

    @Override
    public Class<TaskSql> getTaskType() {
        return TaskSql.class;
    }

    @Override
    public void process(TaskSql task) {
        processSqlBusiness.execute(task);
    }
}

