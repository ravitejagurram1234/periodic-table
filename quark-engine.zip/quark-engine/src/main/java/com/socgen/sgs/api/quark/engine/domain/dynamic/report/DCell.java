package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import com.socgen.sgs.api.quark.engine.domain.dynamic.template.Template;
import com.socgen.sgs.api.quark.engine.domain.element.TElement;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a cell in a dynamic report. A cell can be positioned in a table (relative)
 * or directly in a section (absolute).
 *
 * <p>Each cell references a {@link Template} and optionally a resolved {@link TElement}.
 * It holds new names and values to apply to the template's boxes during rendering.
 *
 * Cross-reference: QXP.Engine.Core.DCell
 */
@Getter
@Setter
public class DCell {

    private static final String NEW_CELL_INDEX_PATTERN = "[%s_%d]";

    /** List of new box names to assign to the template's boxes. */
    private final List<String> newNames = new ArrayList<>();

    /** List of values to put in the template's boxes. */
    private final List<String> values = new ArrayList<>();

    /** Template associated with this cell. */
    private final Template template;

    /** Whether this cell uses the overflow variant of the template. */
    private boolean overflow = false;

    /** Resolved template element (set during Check phase by TElement_Helper.Evaluate_TElement). */
    private TElement tElement;

    /** Geometry information for this cell (page, column, zone). */
    private DCellInfo info = new DCellInfo();

    /** Clone generation counter. Increments on each clone. */
    private int generation = 1;

    /** Logical ID for differentiating cells in absolute mode. Always 0 for relative cells. */
    private int logicalId = 0;

    /**
     * Create a DCell with a template.
     *
     * @param template the template associated with this cell
     */
    public DCell(Template template) {
        this.template = template;
    }

    /**
     * Clone this cell. Each clone increments the generation counter and renames newNames
     * with a generation suffix (e.g., "[BoxName_2]") to ensure unique names.
     *
     * @return a new DCell with cloned info and incremented generation names
     */
    public DCell cloneCell() {
        DCell newCell = new DCell(this.template);
        this.generation++;
        newCell.generation = this.generation;
        newCell.tElement = this.tElement;
        newCell.info = this.info.cloneInfo();
        newCell.newNames.addAll(getNewNames(newCell.generation));
        newCell.values.addAll(this.values);
        newCell.logicalId = this.logicalId;
        return newCell;
    }

    /**
     * Generate new names based on generation index.
     * Generation 1 keeps original names; higher generations append "[name_generation]".
     *
     * @param newGeneration the generation index
     * @return list of new names for this generation
     */
    public List<String> getNewNames(int newGeneration) {
        List<String> result = new ArrayList<>();
        for (String oldName : this.newNames) {
            if (newGeneration == 1) {
                result.add(oldName);
            } else {
                result.add(String.format(NEW_CELL_INDEX_PATTERN, oldName, newGeneration));
            }
        }
        return result;
    }

    /**
     * Set generation to 0 so the first clone won't rename the boxes.
     * Used for absolute cells on "repeat other" pages and page break header rows.
     *
     * Cross-reference: .NET DCell.Downgrade_Generation()
     */
    public void downgradeGeneration() {
        this.generation = 0;
    }

    /**
     * Check equality based on logicalId (for absolute cells only).
     *
     * @param other the other cell to compare
     * @return true if both cells have the same logicalId
     */
    public boolean equalsCell(DCell other) {
        if (other == null) {
            return false;
        }
        return this.logicalId == other.logicalId;
    }

    /**
     * Check if any of the newNames are contained in the given list.
     * Used for overflow detection.
     *
     * @param boxNames the list to check against
     * @return true if at least one newName is in boxNames
     */
    public boolean containsOneNewName(List<String> boxNames) {
        if (boxNames == null || boxNames.isEmpty()) {
            return false;
        }
        for (String name : this.newNames) {
            if (boxNames.contains(name)) {
                return true;
            }
        }
        return false;
    }
}