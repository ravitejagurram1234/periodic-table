package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Represents a visual zone in a dynamic document (left, top, width, height).
 *
 * Cross-reference: QXP.Engine.Core.DZone
 */
@Getter
@Setter
public class DZone {

    private BigDecimal left;
    private BigDecimal top;
    private BigDecimal width;
    private BigDecimal height;

    /** Default zone: left=10, top=10, width=50, height=50 */
    public static final DZone DEFAULT = new DZone(
            BigDecimal.TEN, BigDecimal.TEN,
            BigDecimal.valueOf(50), BigDecimal.valueOf(50));

    /**
     * Create a DZone with specific dimensions.
     */
    public DZone(BigDecimal left, BigDecimal top, BigDecimal width, BigDecimal height) {
        this.left = left;
        this.top = top;
        this.width = width;
        this.height = height;
    }

    /**
     * Clone this zone to create an independent copy.
     *
     * @return a new DZone with the same dimensions
     */
    public DZone cloneZone() {
        return new DZone(this.left, this.top, this.width, this.height);
    }
}