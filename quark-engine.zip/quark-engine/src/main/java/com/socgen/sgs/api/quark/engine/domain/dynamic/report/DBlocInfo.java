package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/** Holds position and identification info for a bloc in a QuarkXPress document (left, top, right, bottom, page, name, uid). */
@Getter
@Setter
@NoArgsConstructor
public class DBlocInfo {

    private String uid = "";
    private String name = "";
    private int page = 0;
    private BigDecimal left = BigDecimal.ZERO;
    private BigDecimal top = BigDecimal.ZERO;
    private BigDecimal right = BigDecimal.ZERO;
    private BigDecimal bottom = BigDecimal.ZERO;

}

