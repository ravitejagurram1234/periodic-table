package com.socgen.sgs.api.quark.engine.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * Holds the render output from QXPS.
 */
@Getter
@Setter
public class QxpsCallerResult {

    private byte[] jpgData;
    private byte[] pdfData;
    private byte[] qxpData;

    public QxpsCallerResult() {
    }
}