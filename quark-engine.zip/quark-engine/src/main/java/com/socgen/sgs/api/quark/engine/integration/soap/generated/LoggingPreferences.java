/**
 * LoggingPreferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class LoggingPreferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private boolean logBadSXTDialogs;

    private boolean logDocProblems;

    private boolean logErrors;

    private boolean logEvents;

    private java.lang.String logFolder;

    private boolean logTiming;

    private boolean logTransactions;

    private boolean loggingEnabled;

    private boolean verboseStatusMonitoring;

    public LoggingPreferences() {
    }

    public LoggingPreferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           boolean logBadSXTDialogs,
           boolean logDocProblems,
           boolean logErrors,
           boolean logEvents,
           java.lang.String logFolder,
           boolean logTiming,
           boolean logTransactions,
           boolean loggingEnabled,
           boolean verboseStatusMonitoring) {
        super(
            request);
        this.logBadSXTDialogs = logBadSXTDialogs;
        this.logDocProblems = logDocProblems;
        this.logErrors = logErrors;
        this.logEvents = logEvents;
        this.logFolder = logFolder;
        this.logTiming = logTiming;
        this.logTransactions = logTransactions;
        this.loggingEnabled = loggingEnabled;
        this.verboseStatusMonitoring = verboseStatusMonitoring;
    }


    /**
     * Gets the logBadSXTDialogs value for this LoggingPreferences.
     * 
     * @return logBadSXTDialogs
     */
    public boolean isLogBadSXTDialogs() {
        return logBadSXTDialogs;
    }


    /**
     * Sets the logBadSXTDialogs value for this LoggingPreferences.
     * 
     * @param logBadSXTDialogs
     */
    public void setLogBadSXTDialogs(boolean logBadSXTDialogs) {
        this.logBadSXTDialogs = logBadSXTDialogs;
    }


    /**
     * Gets the logDocProblems value for this LoggingPreferences.
     * 
     * @return logDocProblems
     */
    public boolean isLogDocProblems() {
        return logDocProblems;
    }


    /**
     * Sets the logDocProblems value for this LoggingPreferences.
     * 
     * @param logDocProblems
     */
    public void setLogDocProblems(boolean logDocProblems) {
        this.logDocProblems = logDocProblems;
    }


    /**
     * Gets the logErrors value for this LoggingPreferences.
     * 
     * @return logErrors
     */
    public boolean isLogErrors() {
        return logErrors;
    }


    /**
     * Sets the logErrors value for this LoggingPreferences.
     * 
     * @param logErrors
     */
    public void setLogErrors(boolean logErrors) {
        this.logErrors = logErrors;
    }


    /**
     * Gets the logEvents value for this LoggingPreferences.
     * 
     * @return logEvents
     */
    public boolean isLogEvents() {
        return logEvents;
    }


    /**
     * Sets the logEvents value for this LoggingPreferences.
     * 
     * @param logEvents
     */
    public void setLogEvents(boolean logEvents) {
        this.logEvents = logEvents;
    }


    /**
     * Gets the logFolder value for this LoggingPreferences.
     * 
     * @return logFolder
     */
    public java.lang.String getLogFolder() {
        return logFolder;
    }


    /**
     * Sets the logFolder value for this LoggingPreferences.
     * 
     * @param logFolder
     */
    public void setLogFolder(java.lang.String logFolder) {
        this.logFolder = logFolder;
    }


    /**
     * Gets the logTiming value for this LoggingPreferences.
     * 
     * @return logTiming
     */
    public boolean isLogTiming() {
        return logTiming;
    }


    /**
     * Sets the logTiming value for this LoggingPreferences.
     * 
     * @param logTiming
     */
    public void setLogTiming(boolean logTiming) {
        this.logTiming = logTiming;
    }


    /**
     * Gets the logTransactions value for this LoggingPreferences.
     * 
     * @return logTransactions
     */
    public boolean isLogTransactions() {
        return logTransactions;
    }


    /**
     * Sets the logTransactions value for this LoggingPreferences.
     * 
     * @param logTransactions
     */
    public void setLogTransactions(boolean logTransactions) {
        this.logTransactions = logTransactions;
    }


    /**
     * Gets the loggingEnabled value for this LoggingPreferences.
     * 
     * @return loggingEnabled
     */
    public boolean isLoggingEnabled() {
        return loggingEnabled;
    }


    /**
     * Sets the loggingEnabled value for this LoggingPreferences.
     * 
     * @param loggingEnabled
     */
    public void setLoggingEnabled(boolean loggingEnabled) {
        this.loggingEnabled = loggingEnabled;
    }


    /**
     * Gets the verboseStatusMonitoring value for this LoggingPreferences.
     * 
     * @return verboseStatusMonitoring
     */
    public boolean isVerboseStatusMonitoring() {
        return verboseStatusMonitoring;
    }


    /**
     * Sets the verboseStatusMonitoring value for this LoggingPreferences.
     * 
     * @param verboseStatusMonitoring
     */
    public void setVerboseStatusMonitoring(boolean verboseStatusMonitoring) {
        this.verboseStatusMonitoring = verboseStatusMonitoring;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LoggingPreferences)) return false;
        LoggingPreferences other = (LoggingPreferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.logBadSXTDialogs == other.isLogBadSXTDialogs() &&
            this.logDocProblems == other.isLogDocProblems() &&
            this.logErrors == other.isLogErrors() &&
            this.logEvents == other.isLogEvents() &&
            ((this.logFolder==null && other.getLogFolder()==null) || 
             (this.logFolder!=null &&
              this.logFolder.equals(other.getLogFolder()))) &&
            this.logTiming == other.isLogTiming() &&
            this.logTransactions == other.isLogTransactions() &&
            this.loggingEnabled == other.isLoggingEnabled() &&
            this.verboseStatusMonitoring == other.isVerboseStatusMonitoring();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isLogBadSXTDialogs() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isLogDocProblems() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isLogErrors() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isLogEvents() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getLogFolder() != null) {
            _hashCode += getLogFolder().hashCode();
        }
        _hashCode += (isLogTiming() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isLogTransactions() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isLoggingEnabled() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isVerboseStatusMonitoring() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LoggingPreferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LoggingPreferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logBadSXTDialogs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "logBadSXTDialogs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logDocProblems");
        elemField.setXmlName(new javax.xml.namespace.QName("", "logDocProblems"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logErrors");
        elemField.setXmlName(new javax.xml.namespace.QName("", "logErrors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logEvents");
        elemField.setXmlName(new javax.xml.namespace.QName("", "logEvents"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logFolder");
        elemField.setXmlName(new javax.xml.namespace.QName("", "logFolder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logTiming");
        elemField.setXmlName(new javax.xml.namespace.QName("", "logTiming"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logTransactions");
        elemField.setXmlName(new javax.xml.namespace.QName("", "logTransactions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loggingEnabled");
        elemField.setXmlName(new javax.xml.namespace.QName("", "loggingEnabled"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verboseStatusMonitoring");
        elemField.setXmlName(new javax.xml.namespace.QName("", "verboseStatusMonitoring"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
