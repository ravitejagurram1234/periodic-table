/**
 * LoggingPreferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class LoggingPreferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private boolean logDocProblems;

    private boolean logTiming;

    public LoggingPreferences() {
    }

    public LoggingPreferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           boolean logDocProblems,
           boolean logTiming) {
        super(
            request);
        this.logDocProblems = logDocProblems;
        this.logTiming = logTiming;
    }


    /**
     * Gets the logDocProblems value for this LoggingPreferences.
     * 
     * @return logDocProblems
     */
    public boolean isLogDocProblems() {
        return logDocProblems;
    }


    /**
     * Sets the logDocProblems value for this LoggingPreferences.
     * 
     * @param logDocProblems
     */
    public void setLogDocProblems(boolean logDocProblems) {
        this.logDocProblems = logDocProblems;
    }


    /**
     * Gets the logTiming value for this LoggingPreferences.
     * 
     * @return logTiming
     */
    public boolean isLogTiming() {
        return logTiming;
    }


    /**
     * Sets the logTiming value for this LoggingPreferences.
     * 
     * @param logTiming
     */
    public void setLogTiming(boolean logTiming) {
        this.logTiming = logTiming;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LoggingPreferences)) return false;
        LoggingPreferences other = (LoggingPreferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.logDocProblems == other.isLogDocProblems() &&
            this.logTiming == other.isLogTiming();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isLogDocProblems() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isLogTiming() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LoggingPreferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LoggingPreferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logDocProblems");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "logDocProblems"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logTiming");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "logTiming"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
