package com.socgen.sgs.api.quark.engine.infra.interop.qxps.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QxpsResponseInfo {

    private byte[] binaryResponse;
    private String textResponse;
    private String contentType;
}

