package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;
import com.socgen.sgs.api.quark.engine.infra.dao.GetRunPropertiesDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Business component responsible for orchestrating the retrieval of run properties.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class GetRunPropertiesBusiness {

    private final GetRunPropertiesDao getRunPropertiesDao;

    /**
     * Retrieves the properties for a given run ID.
     *
     * @param runIdDto the DTO containing the run ID
     * @return the populated {@link RunProperties}
     */
    public RunProperties execute(RunIdDto runIdDto) {
        log.info("Business layer: fetching run properties for runId: {}", runIdDto.getRunId());
        return getRunPropertiesDao.getRunProperties(runIdDto);
    }
}

