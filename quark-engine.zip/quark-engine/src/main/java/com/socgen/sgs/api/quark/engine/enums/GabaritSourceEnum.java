package com.socgen.sgs.api.quark.engine.enums;

import lombok.Getter;

/**
 * Enumeration representing the source of a gabarit (template) document.
 * Defines different ways a document can be generated based on its source.
 */
@Getter
public enum GabaritSourceEnum {

    /**
     * Start from the gabarit (template) itself.
     * The document is generated from scratch using the template definition.
     */
    GABARIT(1, "Gabarit"),

    DOCUMENT_COURANT(2, "DocumentCourant"),

    DOCUMENT_PRECEDENT_CERTIFIE(3, "DocumentPrecedentCertifie"),

    DOCUMENT_SUIVI(4, "DocumentSuivi"),

    UNKNOWN(0, "Unknown");

    private final int code;
    private final String label;

    GabaritSourceEnum(int code, String label) {
        this.code = code;
        this.label = label;
    }

    public static GabaritSourceEnum fromCode(int code) {
        for (GabaritSourceEnum source : values()) {
            if (source.code == code) {
                return source;
            }
        }
        return UNKNOWN;
    }

    public static GabaritSourceEnum fromLabel(String label) {
        if (label == null) {
            return UNKNOWN;
        }
        for (GabaritSourceEnum source : values()) {
            if (source.label.equalsIgnoreCase(label)) {
                return source;
            }
        }
        return UNKNOWN;
    }
}
