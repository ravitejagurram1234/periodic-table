package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.GetDocumentDao;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Calls Oracle function QXP_PK_RUN.Get_Document (6-arg → cursor) to load a reference document.
 * Cross-reference: .NET QXPS_File_Manager.Get_Document(idSousCategorie, idFndCode, idUnitCode,
 * societe, idLangue, dateEcheance) used by Task_Document.Prepare.
 *
 * <p>ora.txt signature: p_id_sous_categorie NUMBER, p_id_fnd_code VARCHAR2, p_id_unit_code VARCHAR2,
 * p_societe VARCHAR2, p_id_langue NUMBER, p_date_echeance DATE → cursor(id_document, nom, contenu, format).
 */
@Repository
@Slf4j
public class GetDocumentDaoImpl implements GetDocumentDao {

    private static final String RESULT_KEY = "result_cursor";
    private final SimpleJdbcCall getDocumentCall;

    @Autowired
    public GetDocumentDaoImpl(DataSource dataSource) {
        this.getDocumentCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_Document")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR,
                                (rs, rowNum) -> mapFromResultSet(rs)),
                        new SqlParameter("p_id_sous_categorie", Types.NUMERIC),
                        new SqlParameter("p_id_fnd_code", Types.VARCHAR),
                        new SqlParameter("p_id_unit_code", Types.VARCHAR),
                        new SqlParameter("p_societe", Types.VARCHAR),
                        new SqlParameter("p_id_langue", Types.NUMERIC),
                        new SqlParameter("p_date_echeance", Types.DATE)
                );
    }

    @Override
    public DocumentDomain getDocument(int idSousCategorie, String idFndCode, String idUnitCode,
                                      String societe, int idLangue, LocalDate dateEcheance) {
        log.info("Fetching reference document: sousCategorie={}, fndCode={}, unitCode={}, societe={}, langue={}, echeance={}",
                idSousCategorie, idFndCode, idUnitCode, societe, idLangue, dateEcheance);

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_sous_categorie", idSousCategorie)
                .addValue("p_id_fnd_code", idFndCode)
                .addValue("p_id_unit_code", idUnitCode)
                .addValue("p_societe", societe)
                .addValue("p_id_langue", idLangue)
                .addValue("p_date_echeance", dateEcheance != null ? java.sql.Date.valueOf(dateEcheance) : null);

        try {
            Map<String, Object> result = getDocumentCall.execute(params);

            @SuppressWarnings("unchecked")
            List<DocumentDomain> rows = (List<DocumentDomain>) result.get(RESULT_KEY);

            if (rows == null || rows.isEmpty()) {
                log.warn("No reference document found for sousCategorie={}", idSousCategorie);
                return null;
            }
            DocumentDomain doc = rows.get(0);
            // The Get_Document cursor has no langue column, so set ID_Langue from the input langue
            // used to query. Finding #73.
            doc.setIdLangue(idLangue);
            return doc;
        } catch (Exception e) {
            log.error("Error fetching reference document for sousCategorie={}", idSousCategorie, e);
            throw new RuntimeException("Failed to fetch reference document for sousCategorie: " + idSousCategorie, e);
        }
    }

    private DocumentDomain mapFromResultSet(ResultSet rs) throws SQLException {
        DocumentDomain doc = new DocumentDomain();
        doc.setId(rs.getInt("id_document"));
        doc.setName(rs.getString("nom"));
        doc.setFormat(rs.getString("format"));
        doc.setPrefix(DocumentDomain.FILE_DOCUMENT_PREFIX);
        doc.setData(rs.getBytes("contenu"));
        // fileName = D_<id>.<format> (paths are completed by the loader using the run pool + base path).
        doc.setFileName(String.format("%s_%d.%s", doc.getPrefix(), doc.getId(), doc.getFormat()));
        return doc;
    }
}