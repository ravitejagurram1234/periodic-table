package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.business.GetCompartimentRunsBusiness;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.domain.TaskCompartimentMode;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocPage;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DBlocInfo;
import com.socgen.sgs.api.quark.engine.domain.element.TBox;
import com.socgen.sgs.api.quark.engine.domain.helper.TElementHelper;
import com.socgen.sgs.api.quark.engine.domain.project.QxpProject;
import com.socgen.sgs.api.quark.engine.domain.task.TaskCompartiment;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Project;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Spread;
import com.socgen.sgs.api.quark.engine.service.ProcessRunService;
import com.socgen.sgs.api.quark.engine.service.task.TaskProcessStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Strategy for processing TaskCompartiment (sub-document generation and merging).
 *
 * <p>Three phases:
 * <ol>
 *   <li>Prepare_Runs: Load child run IDs from database, create Run objects</li>
 *   <li>Execute_Runs: Launch each child run through the full pipeline</li>
 *   <li>Render_Runs: Extract blocs from child QXP projects, rename, create pages</li>
 * </ol>
 *
 * Cross-reference: QXP.Engine.Core.Business.Process_Compartiment
 */
@Component
@Slf4j
public class CompartimentTaskProcessStrategy implements TaskProcessStrategy<TaskCompartiment> {

    /** Report type for compartiment child runs. */
    private static final int TYPE_RAPPORT_COMPARTIMENT = 4;

    /** Maximum length for old box names before adding suffix. */
    private static final int MAX_OLD_NAME_SIZE = 24;

    private static final String SUFFIXE_PATTERN = "_%s";
    private static final String NEW_PAGE_PATTERN = "T%d_P%d";
    private static final String DEF_BOX_NAME_PATTERN = "Box%s";
    private static final String OUT_OF_PAGE_CHAR = "*";
    private static final String QXPSDK_FALSE = "false";

    private final GetCompartimentRunsBusiness getCompartimentRunsBusiness;
    private final ProcessRunService processRunService;

    /**
     * Constructor with @Lazy on ProcessRunService to break circular dependency.
     * Circular: ProcessRunService → ProcessTasksService → strategies → this → ProcessRunService
     */
    public CompartimentTaskProcessStrategy(
            GetCompartimentRunsBusiness getCompartimentRunsBusiness,
            @Lazy ProcessRunService processRunService) {
        this.getCompartimentRunsBusiness = getCompartimentRunsBusiness;
        this.processRunService = processRunService;
    }

    @Override
    public Class<TaskCompartiment> getTaskType() {
        return TaskCompartiment.class;
    }

    @Override
    public void process(TaskCompartiment task) {
        log.debug("CompartimentTaskProcessStrategy processing task [{}]", task.getId());

        RunProperties props = task.getRun().getRunProperties();

        if (props.getCompartimentMode() == TaskCompartimentMode.UNKNOWN) {
            log.error("Unknown compartiment mode for task [{}]", task.getId());
            return;
        }

        // Phase 1: Prepare child runs
        if (task.isEvaluateRuns()) {
            prepareRuns(task);
        }

        // Phase 2: Execute child runs
        executeRuns(task);

        // Phase 3: Render — extract blocs from child run results
        renderRuns(task);

        // Free memory
        task.getChildRuns().clear();
    }

    // ========================================================================
    // Phase 1: Prepare_Runs
    // Cross-reference: Process_Compartiment.Prepare_Runs() lines 71-112
    // ========================================================================

    private void prepareRuns(TaskCompartiment task) {
        RunProperties props = task.getRun().getRunProperties();

        boolean toGenerate = (props.getCompartimentMode() == TaskCompartimentMode.GENERATE
                || props.getCompartimentMode() == TaskCompartimentMode.GENERATE_AND_INCORPORATE);

        LinkedHashMap<String, Integer> compartimentRuns = getCompartimentRunsBusiness.execute(
                props.getIdGabarit(),
                props.getIdFndCode(),
                task.getIdGabaritFils(),
                TYPE_RAPPORT_COMPARTIMENT,
                props.getIdLangue(),
                props.getDateEcheance(),
                toGenerate);

        if (compartimentRuns.isEmpty()) {
            log.warn("No compartment runs found for task [{}] in run [{}]",
                    task.getId(), task.getRun().getId());
            return;
        }

        for (Map.Entry<String, Integer> entry : compartimentRuns.entrySet()) {
            String compartimentCode = entry.getKey();
            int runId = entry.getValue();

            if (runId > 0) {
                Run childRun = new Run();
                childRun.setId(runId);
                RunProperties childProps = new RunProperties();
                childProps.setIdFndCode(compartimentCode);
                childProps.setRunId(runId);
                childRun.setRunProperties(childProps);
                task.getChildRuns().add(childRun);
            } else {
                log.warn("No run found for compartment [{}] in task [{}], run [{}]",
                        compartimentCode, task.getId(), task.getRun().getId());
            }
        }
    }

    // ========================================================================
    // Phase 2: Execute_Runs
    // Cross-reference: Process_Compartiment.Execute_Runs() lines 118-132
    // ========================================================================

    private void executeRuns(TaskCompartiment task) {
        for (Run childRun : task.getChildRuns()) {
            try {
                log.info("Launching child run [{}] for compartiment task [{}]",
                        childRun.getId(), task.getId());
                processRunService.runProcessor(new RunIdDto(childRun.getId()));
                log.info("Child run [{}] completed for compartiment task [{}]",
                        childRun.getId(), task.getId());
            } catch (Exception e) {
                log.error("Error executing child run [{}] for task [{}]: {}",
                        childRun.getId(), task.getId(), e.getMessage(), e);
            }
        }
    }

    // ========================================================================
    // Phase 3: Render_Runs
    // Cross-reference: Process_Compartiment.Render_Runs() lines 138-195
    // ========================================================================

    private void renderRuns(TaskCompartiment task) {
        int lastPage = 0;

        RunProperties props = task.getRun().getRunProperties();
        boolean incorporate = (props.getCompartimentMode() == TaskCompartimentMode.INCORPORATE
                || props.getCompartimentMode() == TaskCompartimentMode.GENERATE_AND_INCORPORATE);

        if (!incorporate) {
            // Nothing to incorporate — mark task as not todo
            task.setTodo(false);
            return;
        }

        // Extract blocs from each child run
        for (Run childRun : task.getChildRuns()) {
            lastPage = addRunBlocs(task, childRun, lastPage);
        }

        // 1. If no blocs generated, create one empty page
        if (task.getBlocsModify().isEmpty()) {
            BlocPage blocPage = new BlocPage(task,
                    String.format(NEW_PAGE_PATTERN, task.getId(), 0));
            blocPage.setAction(BlocActionEnum.CREATE);
            blocPage.setRelativePage(0);
            task.getBlocsModify().put(blocPage.getName(), blocPage);
            lastPage++;
        }

        // 2. Get anchor info
        DBlocInfo startInfo = task.getStartAnchor();
        DBlocInfo endInfo = task.getEndAnchor();

        // 3. Remove old pages between anchors (inclusive: <= not <)
        // .NET: for (int __i = 0; __i <= __nb_Ancien_Page; __i++)
        int nbAnciennePage = endInfo.getPage() - startInfo.getPage();
        for (int i = 0; i <= nbAnciennePage; i++) {
            int relativeRemovePage = lastPage + i;
            BlocPage blocPage = new BlocPage(task,
                    String.format(NEW_PAGE_PATTERN, task.getId(), relativeRemovePage));
            blocPage.setAction(BlocActionEnum.REMOVE);
            blocPage.setRelativePage(relativeRemovePage);
            task.getBlocsModify().put(blocPage.getName(), blocPage);
        }

        // 4. Move start anchor to first new page
        BlocBox blocStart = TElementHelper.getMoveAnchor(task, startInfo, 0);
        if (blocStart != null) {
            blocStart.setPagination(true);
            task.getBlocsModify().put(blocStart.getName(), blocStart);
        }

        // 5. Move end anchor to last new page
        BlocBox blocEnd = TElementHelper.getMoveAnchor(task, endInfo, lastPage - 1);
        if (blocEnd != null) {
            blocEnd.setPagination(true);
            task.getBlocsModify().put(blocEnd.getName(), blocEnd);
        }
    }

    // ========================================================================
    // Add_Run_Blocs + Add_Blocs
    // Cross-reference: Process_Compartiment.Add_Run_Blocs() lines 203-220
    //                  Process_Compartiment.Add_Blocs() lines 230-330
    // ========================================================================

    private int addRunBlocs(TaskCompartiment task, Run childRun, int lastPage) {
        if (childRun.getGabarit() == null) {
            log.warn("Child run [{}] has no gabarit (final QXP), skipping", childRun.getId());
            return lastPage;
        }

        QxpProject qxpProject = childRun.getGabarit().getQxpProject();
        if (qxpProject == null || qxpProject == QxpProject.EMPTY) {
            log.warn("Child run [{}] has no QXP project, skipping", childRun.getId());
            return lastPage;
        }

        return addBlocs(task, qxpProject, childRun, lastPage);
    }

    private int addBlocs(TaskCompartiment task, QxpProject qxpProject,
                         Run childRun, int lastPage) {
        Project project = qxpProject.getProject();
        String standardSuffix = childRun.getRunProperties().getIdFndCode();

        // Group boxes by page (sorted by page number for correct ordering)
        SortedMap<Integer, List<BlocBox>> boxesByPage = new TreeMap<>();

        log.debug("Analysing child run [{}] project structure", childRun.getId());

        if (project.getLayouts() != null) {
            for (Layout layout : project.getLayouts()) {
                if (layout == null || layout.getSpreads() == null) {
                    continue;
                }
                for (Spread spread : layout.getSpreads()) {
                    if (spread == null || spread.getBoxes() == null) {
                        continue;
                    }
                    for (Box box : spread.getBoxes()) {
                        if (box == null || box.getGeometry() == null
                                || box.getGeometry().getPage() == null) {
                            continue;
                        }

                        String pageName = box.getGeometry().getPage();

                        // Skip boxes on pasteboard (page ends with *)
                        if (pageName.endsWith(OUT_OF_PAGE_CHAR)) {
                            continue;
                        }

                        int currentPageId;
                        try {
                            currentPageId = Integer.parseInt(pageName.trim());
                        } catch (NumberFormatException e) {
                            log.warn("Cannot parse page [{}] for box [{}]", pageName, box.getName());
                            continue;
                        }

                        // Rename box (must be BEFORE clearing UID)
                        box.setName(renameBloc(box, standardSuffix));

                        // Clear UID (must be AFTER rename)
                        box.setUID(null);

                        // Create BlocBox with CREATE action
                        BlocBox blocBox = new BlocBox(task, box.getName(), box, null);
                        blocBox.setAction(BlocActionEnum.CREATE);

                        boxesByPage.computeIfAbsent(currentPageId, k -> new ArrayList<>())
                                .add(blocBox);
                    }
                }
            }
        }

        // Process pages in order — only include pages with at least one visible box
        // .NET: suppressOutput == "false" means the box IS visible (not suppressed)
        for (Map.Entry<Integer, List<BlocBox>> entry : boxesByPage.entrySet()) {
            List<BlocBox> pageBoxes = entry.getValue();

            boolean hasVisibleBox = pageBoxes.stream()
                    .anyMatch(bloc -> {
                        Box srcBox = bloc.getSrcBox();
                        return srcBox != null
                                && srcBox.getGeometry() != null
                                && QXPSDK_FALSE.equals(srcBox.getGeometry().getSuppressOutput());
                    });

            if (hasVisibleBox) {
                // Create page
                BlocPage blocPage = new BlocPage(task,
                        String.format(NEW_PAGE_PATTERN, task.getId(), lastPage));
                blocPage.setAction(BlocActionEnum.CREATE);
                blocPage.setRelativePage(lastPage);
                task.getBlocsModify().put(blocPage.getName(), blocPage);

                // Add all boxes on this page
                for (BlocBox blocBox : pageBoxes) {
                    blocBox.setRelativePage(lastPage);
                    task.getBlocsModify().put(blocBox.getName(), blocBox);
                }

                lastPage++;
            }
        }

        log.debug("Extracted boxes from child run [{}], lastPage=[{}]", childRun.getId(), lastPage);
        return lastPage;
    }

    // ========================================================================
    // Rename_Bloc
    // Cross-reference: Process_Compartiment.Rename_Bloc() lines 340-365
    // ========================================================================

    private String renameBloc(Box box, String suffix) {
        String oldName = box.getName();
        String defName = String.format(DEF_BOX_NAME_PATTERN, box.getUID());
        String suffixStr = String.format(SUFFIXE_PATTERN, suffix);

        // Check if name is defined and not the default Quark pattern "BoxUID"
        if (oldName != null && !oldName.isBlank() && !oldName.equals(defName)) {
            // Truncate to max length
            String newName = oldName.length() > MAX_OLD_NAME_SIZE
                    ? oldName.substring(0, MAX_OLD_NAME_SIZE)
                    : oldName;

            // Only add suffix if not already present
            if (!newName.endsWith(suffixStr)) {
                newName = newName + suffixStr;
            }
            return newName;
        } else {
            return TElementHelper.newBlocName();
        }
    }
}