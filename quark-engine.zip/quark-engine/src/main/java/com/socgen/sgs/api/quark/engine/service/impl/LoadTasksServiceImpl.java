package com.socgen.sgs.api.quark.engine.service.impl;

import com.socgen.sgs.api.quark.engine.business.GetTasksBusiness;
import com.socgen.sgs.api.quark.engine.business.GetTaskExceptionsBusiness;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.domain.task.TaskDid;
import com.socgen.sgs.api.quark.engine.domain.task.TaskException;
import com.socgen.sgs.api.quark.engine.mapper.TaskExceptionMapper;
import com.socgen.sgs.api.quark.engine.mapper.TaskMapper;
import com.socgen.sgs.api.quark.engine.service.LoadTasksService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class LoadTasksServiceImpl implements LoadTasksService {

    private final GetTasksBusiness getTasksBusiness;
    private final GetTaskExceptionsBusiness getTaskExceptionsBusiness;
    private final TaskMapper taskMapper;
    private final TaskExceptionMapper taskExceptionMapper;

    @Override
    public void loadTasks(Run run) {
        log.info("Loading tasks for runId: {}", run.getId());

        List<Map<String, Object>> rows = getTasksBusiness.execute(run.getId());
        run.getTasks().clear();

        for (Map<String, Object> row : rows) {
            TaskBase task = taskMapper.mapToTask(row, run);
            if (task != null) {
                run.getTasks().put(task.getId(), task);
            }
        }

        log.info("Loaded {} tasks for runId: {}", run.getTasks().size(), run.getId());

        loadTaskExceptions(run);

        //adding did_Task
        TaskDid didTask = new TaskDid(TaskDid.DID_TASK_ID, run);
        run.getTasks().put(didTask.getId(), didTask);
        log.info("DID task added for runId: {}", run.getId());
    }

    private void loadTaskExceptions(Run run) {
        log.info("Loading task exceptions for runId: {}", run.getId());

        List<Map<String, Object>> rows = getTaskExceptionsBusiness.execute(run.getId());
        TaskBase cachedTask = null;

        for (Map<String, Object> row : rows) {
            int idTache = taskExceptionMapper.getIdTache(row);
            String nomBloc = taskExceptionMapper.getNomBloc(row);

            // Local cache: reuse last task if same id
            if (cachedTask == null || cachedTask.getId() != idTache) {
                if (run.getTasks().containsKey(idTache)) {
                    cachedTask = run.getTasks().get(idTache);
                } else {
                    cachedTask = null;
                    log.warn("Task {} not found in run {} for bloc exception '{}'", idTache, run.getId(), nomBloc);
                    continue;
                }
            }

            TaskException taskException = taskExceptionMapper.mapToTaskException(row);

            if (cachedTask.getExceptions().containsKey(nomBloc)) {
                log.warn("Duplicate bloc exception '{}' for task {} in run {}", nomBloc, cachedTask.getDebugInfo(), run.getId());
            } else {
                cachedTask.getExceptions().put(nomBloc, taskException);
            }
        }

        log.info("Task exceptions loaded for runId: {}", run.getId());
    }
}
