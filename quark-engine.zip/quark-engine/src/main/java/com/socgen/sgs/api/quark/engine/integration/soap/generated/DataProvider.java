/**
 * DataProvider.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class DataProvider  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String dataProviderXTId;

    public DataProvider() {
    }

    public DataProvider(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String dataProviderXTId) {
        super(
            request);
        this.dataProviderXTId = dataProviderXTId;
    }


    /**
     * Gets the dataProviderXTId value for this DataProvider.
     * 
     * @return dataProviderXTId
     */
    public java.lang.String getDataProviderXTId() {
        return dataProviderXTId;
    }


    /**
     * Sets the dataProviderXTId value for this DataProvider.
     * 
     * @param dataProviderXTId
     */
    public void setDataProviderXTId(java.lang.String dataProviderXTId) {
        this.dataProviderXTId = dataProviderXTId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DataProvider)) return false;
        DataProvider other = (DataProvider) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.dataProviderXTId==null && other.getDataProviderXTId()==null) || 
             (this.dataProviderXTId!=null &&
              this.dataProviderXTId.equals(other.getDataProviderXTId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDataProviderXTId() != null) {
            _hashCode += getDataProviderXTId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DataProvider.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "DataProvider"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataProviderXTId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "dataProviderXTId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
