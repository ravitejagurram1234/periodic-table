package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.domain.Run;

/**
 * Represents the DID (Document Identity) update task in a QuarkXPress run.
 * <p>
 * This task is always executed ({@code todo=true}, {@code allwaysReprocess=true}) and its
 * destination bloc is always the {@code "DID"} bloc.
 * <p>
 * It is a pure state holder: the update logic lives in
 * {@code DidTaskPostProcessStrategy}. The DID can only be computed once every other task's
 * pagination is known (post-process), and it must be turned into a bloc by the system
 * bloc-creation path — both of which belong in the service layer. This mirrors .NET
 * {@code Task_DID}, whose {@code PostProcess()} delegates to {@code Process_System.Process(this)}.
 *
 * <p>Translated from .NET {@code Task_DID} — {@code QXP.Engine.Core}.</p>
 */
public class TaskDid extends TaskSystem {

    private static final String DID_BLOC_NAME = "DID";
    public static final int DID_TASK_ID = 0;

    /**
     * Creates a new TaskDid, always bound to the "DID" bloc.
     *
     * @param id  the task identifier
     * @param run the run that created this task
     */
    public TaskDid(int id, Run run) {
        super(id, run);
        // This task is always to be executed
        this.setTodo(true);
        // Always the same destination
        this.setDestinationBlocName(DID_BLOC_NAME);
        // This task will be re-executed at each processing cycle
        this.setAllwaysReprocess(true);
        // Debug comment
        this.setCommentaire("DID updater");
    }
}