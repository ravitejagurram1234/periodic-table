package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBase;
import com.socgen.sgs.api.quark.engine.domain.helper.DocumentIdentityHelper;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import lombok.extern.slf4j.Slf4j;

/**
 * Represents the DID (Document Identity) update task in a QuarkXPress run.
 * <p>
 * This task is always executed ({@code todo=true}, {@code allwaysReprocess=true}).
 * Its destination bloc is always the "DID" bloc.
 * </p>
 * <p>
 * Two update modes:
 * <ul>
 *   <li><b>MOVE mode (modifier)</b>: when any task has a bloc with pagination enabled,
 *       the DID bloc must be repositioned and updated via the MOVE action.</li>
 *   <li><b>NAME_VALUE mode</b>: otherwise the DID is updated by value only.</li>
 * </ul>
 * </p>
 *
 * <p>Translated from .NET {@code Task_DID} — {@code QXP.Engine.Core}</p>
 */
@Slf4j
public class TaskDid extends TaskSystem {

    private static final String DID_BLOC_NAME = "DID";
    public static final int DID_TASK_ID = 0;

    /**
     * Creates a new TaskDid, always bound to the "DID" bloc.
     *
     * @param id  the task identifier
     * @param run the run that created this task
     */
    public TaskDid(int id, Run run) {
        super(id, run);
        // This task is always to be executed
        this.setTodo(true);
        // Always the same destination
        this.setDestinationBlocName(DID_BLOC_NAME);
        // This task will be re-executed at each processing cycle
        this.setAllwaysReprocess(true);
        // Debug comment
        this.setCommentaire("DID updater");
    }

    /**
     * Nothing to do at process time — all logic is in post-processing.
     * Called by TaskProcessService.
     */
    public void executeProcess() {
    }

    /**
     * Post-processing of the DID task.
     * Called by TaskPostProcessService.
     * <ol>
     *   <li>Determines update mode: MOVE if any task has a paginated bloc, else NAME_VALUE.</li>
     *   <li>Builds the new DID identity string from the run.</li>
     *   <li>In MOVE mode: sets action to MOVE, enables pagination, creates a bloc in blocsModify.</li>
     *   <li>In NAME_VALUE mode: sets value directly.</li>
     * </ol>
     */
    public void executePostProcess() {
        boolean modifier = false;

        // 1. Determine update mode: check if any task has a paginated bloc in blocsModify
        for (TaskBase task : this.getRun().getTasks().values()) {
            for (BlocBase bloc : task.getBlocsModify().values()) {
                if (bloc.isPagination()) {
                    modifier = true;
                    break;
                }
            }
            if (modifier) {
                break;
            }
        }

        // 2. Build new DID identity string
        String didValue = DocumentIdentityHelper.getNewIdentity(this.getRun());
        log.debug("New DID identity value for runId {}: {}", this.getRun().getId(), didValue);

        if (modifier) {
            // MOVE mode: reposition DID bloc and update its value via a BlocBase in blocsModify
            log.info("DID update mode: MOVE (pagination detected) for runId {}", this.getRun().getId());

            this.setAction(BlocActionEnum.MOVE);
            this.setPagination(true);

            // Build a bloc representing the DID destination with the new value
            BlocBase didBloc = new BlocBase(this, DID_BLOC_NAME);
            didBloc.setAction(BlocActionEnum.MOVE);
            didBloc.setPagination(true);

            this.getBlocsModify().put(DID_BLOC_NAME, didBloc);
            this.setValue(didValue);

        } else {
            // NAME_VALUE mode: update DID value only
            log.info("DID update mode: NAME_VALUE for runId {}", this.getRun().getId());
            this.setValue(didValue);
        }

        log.info("DID task postProcess completed for runId {}", this.getRun().getId());
    }
}


