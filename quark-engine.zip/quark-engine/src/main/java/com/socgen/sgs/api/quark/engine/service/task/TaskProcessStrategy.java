package com.socgen.sgs.api.quark.engine.service.task;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;

/** Strategy for processing a specific task type. */
public interface TaskProcessStrategy<T extends TaskBase> {

    Class<T> getTaskType();

    void process(T task);
}

