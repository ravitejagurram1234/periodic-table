package com.socgen.sgs.api.quark.engine.domain;

import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBase;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox;
import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Consolidates tasks into execution steps for the QuarkXPress server.
 * Provides getSteps() which builds the ordered list of RunTaskStep:
 * <ol>
 *   <li>Step[0]: UPDATE — all blocsUpdate (text values via SOAP, directCall=false)</li>
 *   <li>Step[1]: PAGINATION — blocs with pagination=true (page create/remove via HTTP)</li>
 *   <li>Step[2..N]: MODIFY — remaining blocsModify, split at splitStepBoxNumber per step</li>
 * </ol>
 *
 * Cross-reference: QXP.Engine.Core.Run_Task
 */
@Getter
@Slf4j
public class RunTask {

    /** Tasks that have modify blocs. Keyed by task ID, preserves order. */
    private final Map<Integer, TaskBase> tasksModifier = new LinkedHashMap<>();

    /** Tasks that have update blocs. Keyed by task ID, preserves order. */
    private final Map<Integer, TaskBase> tasksUpdate = new LinkedHashMap<>();

    /**
     * Maximum blocs per modify step. If exceeded, a new step is created.
     * Default 500 (from .NET EngineCoreSetting.Current.Step_Limit).
     */
    private int splitStepBoxNumber = 500;

    /** Temporary steps (intermediate modify steps created when splitting). */
    private List<RunTaskStep> stepsTemp = null;

    /** Final ordered list of steps. */
    private List<RunTaskStep> steps = null;

    private final Run run;

    public RunTask() {
        this.run = null;
    }

    public RunTask(Run run) {
        this.run = run;
    }

    /**
     * Add a task to the appropriate task lists based on its blocs.
     * Called during Pass 2 (Verify) of ProcessTasksServiceImpl.
     *
     * @param task the task that has been processed and verified
     */
    public void addTask(TaskBase task) {
        if (task.getBlocsModify().size() > 0) {
            tasksModifier.put(task.getId(), task);
        }
        if (task.getBlocsUpdate().size() > 0) {
            tasksUpdate.put(task.getId(), task);
        }
    }

    /**
     * Build the ordered list of execution steps from all collected tasks.
     * This is the main aggregation method called by Step 5.
     *
     * <p>Step ordering:
     * <ol>
     *   <li>UPDATE step — all blocsUpdate, directCall=false (SOAP)</li>
     *   <li>PAGINATION step — blocs with pagination=true</li>
     *   <li>Intermediate MODIFY steps (if split due to box count limit)</li>
     *   <li>Final MODIFY step — remaining blocsModify</li>
     * </ol>
     *
     * Cross-reference: QXP.Engine.Core.Run_Task.Get_Steps()
     *
     * @return the ordered list of RunTaskStep
     */
    public List<RunTaskStep> getSteps() {
        if (steps != null) {
            return steps;
        }

        int index = 0;
        int nbModify = 0;

        stepsTemp = new ArrayList<>();
        steps = new ArrayList<>();

        // ================================================================
        // Step 1: UPDATE step — all text value changes (SOAP/ParamsValue)
        // Direct_Call = false → goes through QuarkXPress Manager (SOAP)
        // ================================================================

        RunTaskStep updateStep = new RunTaskStep(run);
        updateStep.setDirectCall(false);

        if (!tasksUpdate.isEmpty()) {
            for (TaskBase task : tasksUpdate.values()) {
                updateStep.getBlocsUpdate().addAll(task.getBlocsUpdate().values());
            }
        }

        if (!updateStep.getBlocsUpdate().isEmpty()) {
            steps.add(updateStep);
        }

        // ================================================================
        // Step 2: PAGINATION step — blocs with pagination=true
        // Step 3+: MODIFY steps — remaining structural modifications
        // ================================================================

        RunTaskStep paginationStep = new RunTaskStep(run);
        RunTaskStep modifyStep = new RunTaskStep(run);

        for (TaskBase taskModify : tasksModifier.values()) {
            if (taskModify.getBlocsModify().isEmpty()) {
                continue;
            }

            boolean haveModifyPagination = false;
            boolean haveModify = false;

            for (BlocBase bloc : taskModify.getBlocsModify().values()) {
                if (bloc.isPagination()) {
                    // Pagination blocs → pagination step
                    haveModifyPagination = true;
                    paginationStep.getBlocsModify().add(bloc);
                } else {
                    // Regular modify blocs → modify step
                    nbModify += bloc.getNbBox();
                    haveModify = true;
                    modifyStep.getBlocsModify().add(bloc);
                }

                // Check if we need to split into a new modify step
                if (splitStepBoxNumber > 0 && nbModify > splitStepBoxNumber) {
                    // Remove old and add new evaluateInfo task reference
                    modifyStep.removeEvaluateInfoTask(taskModify);
                    modifyStep.addEvaluateInfoTask(taskModify);

                    // Save current modify step to temp list
                    stepsTemp.add(modifyStep);

                    // Create new modify step
                    modifyStep = new RunTaskStep(run);
                    haveModify = false;
                    nbModify = 0;
                }
            }

            // Register evaluateInfo callbacks
            if (haveModifyPagination) {
                paginationStep.addEvaluateInfoTask(taskModify);
                paginationStep.setPagination(true);
            }

            if (haveModify) {
                modifyStep.removeEvaluateInfoTask(taskModify);
                modifyStep.addEvaluateInfoTask(taskModify);
            }
        }

        // Add steps in correct order:
        // 1. Pagination step (page operations first)
        if (!paginationStep.getBlocsModify().isEmpty()) {
            steps.add(paginationStep);
        }

        // 2. Intermediate modify steps (from splitting)
        if (!stepsTemp.isEmpty()) {
            steps.addAll(stepsTemp);
        }

        // 3. Final modify step
        if (!modifyStep.getBlocsModify().isEmpty()) {
            steps.add(modifyStep);
        }

        // Number the steps
        for (RunTaskStep step : steps) {
            step.setIndex(index++);
        }

        return steps;
    }

    /**
     * Get total number of excluded boxes across all steps.
     *
     * Cross-reference: .NET Run_Task.NbExcludeBoxes
     */
    public int getNbExcludeBoxes() {
        int excludes = 0;
        if (steps != null) {
            for (RunTaskStep step : steps) {
                excludes += step.getNbBoxExcluded();
            }
        }
        return excludes;
    }

    /**
     * Set the split step box number (maximum blocs per modify step).
     *
     * @param splitStepBoxNumber max blocs per step
     */
    public void setSplitStepBoxNumber(int splitStepBoxNumber) {
        this.splitStepBoxNumber = splitStepBoxNumber;
    }
}