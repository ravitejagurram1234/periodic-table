/**
 * LinkedBox.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class LinkedBox  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String UID;

    private java.lang.String columnCount;

    private java.lang.String endOffset;

    private java.lang.String name;

    private java.lang.String rowCount;

    private java.lang.String startOffset;

    public LinkedBox() {
    }

    public LinkedBox(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String UID,
           java.lang.String columnCount,
           java.lang.String endOffset,
           java.lang.String name,
           java.lang.String rowCount,
           java.lang.String startOffset) {
        super(
            request);
        this.UID = UID;
        this.columnCount = columnCount;
        this.endOffset = endOffset;
        this.name = name;
        this.rowCount = rowCount;
        this.startOffset = startOffset;
    }


    /**
     * Gets the UID value for this LinkedBox.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this LinkedBox.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the columnCount value for this LinkedBox.
     * 
     * @return columnCount
     */
    public java.lang.String getColumnCount() {
        return columnCount;
    }


    /**
     * Sets the columnCount value for this LinkedBox.
     * 
     * @param columnCount
     */
    public void setColumnCount(java.lang.String columnCount) {
        this.columnCount = columnCount;
    }


    /**
     * Gets the endOffset value for this LinkedBox.
     * 
     * @return endOffset
     */
    public java.lang.String getEndOffset() {
        return endOffset;
    }


    /**
     * Sets the endOffset value for this LinkedBox.
     * 
     * @param endOffset
     */
    public void setEndOffset(java.lang.String endOffset) {
        this.endOffset = endOffset;
    }


    /**
     * Gets the name value for this LinkedBox.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this LinkedBox.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the rowCount value for this LinkedBox.
     * 
     * @return rowCount
     */
    public java.lang.String getRowCount() {
        return rowCount;
    }


    /**
     * Sets the rowCount value for this LinkedBox.
     * 
     * @param rowCount
     */
    public void setRowCount(java.lang.String rowCount) {
        this.rowCount = rowCount;
    }


    /**
     * Gets the startOffset value for this LinkedBox.
     * 
     * @return startOffset
     */
    public java.lang.String getStartOffset() {
        return startOffset;
    }


    /**
     * Sets the startOffset value for this LinkedBox.
     * 
     * @param startOffset
     */
    public void setStartOffset(java.lang.String startOffset) {
        this.startOffset = startOffset;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LinkedBox)) return false;
        LinkedBox other = (LinkedBox) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.columnCount==null && other.getColumnCount()==null) || 
             (this.columnCount!=null &&
              this.columnCount.equals(other.getColumnCount()))) &&
            ((this.endOffset==null && other.getEndOffset()==null) || 
             (this.endOffset!=null &&
              this.endOffset.equals(other.getEndOffset()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.rowCount==null && other.getRowCount()==null) || 
             (this.rowCount!=null &&
              this.rowCount.equals(other.getRowCount()))) &&
            ((this.startOffset==null && other.getStartOffset()==null) || 
             (this.startOffset!=null &&
              this.startOffset.equals(other.getStartOffset())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getColumnCount() != null) {
            _hashCode += getColumnCount().hashCode();
        }
        if (getEndOffset() != null) {
            _hashCode += getEndOffset().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getRowCount() != null) {
            _hashCode += getRowCount().hashCode();
        }
        if (getStartOffset() != null) {
            _hashCode += getStartOffset().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LinkedBox.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LinkedBox"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "columnCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endOffset");
        elemField.setXmlName(new javax.xml.namespace.QName("", "endOffset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rowCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rowCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startOffset");
        elemField.setXmlName(new javax.xml.namespace.QName("", "startOffset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
