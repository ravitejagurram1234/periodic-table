/**
 * UpdateGeometryRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class UpdateGeometryRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String articleId;

    private java.lang.String fromFile;

    private java.lang.String layout;

    private java.lang.String toFile;

    public UpdateGeometryRequest() {
    }

    public UpdateGeometryRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String articleId,
           java.lang.String fromFile,
           java.lang.String layout,
           java.lang.String toFile) {
        super(
            request);
        this.articleId = articleId;
        this.fromFile = fromFile;
        this.layout = layout;
        this.toFile = toFile;
    }


    /**
     * Gets the articleId value for this UpdateGeometryRequest.
     * 
     * @return articleId
     */
    public java.lang.String getArticleId() {
        return articleId;
    }


    /**
     * Sets the articleId value for this UpdateGeometryRequest.
     * 
     * @param articleId
     */
    public void setArticleId(java.lang.String articleId) {
        this.articleId = articleId;
    }


    /**
     * Gets the fromFile value for this UpdateGeometryRequest.
     * 
     * @return fromFile
     */
    public java.lang.String getFromFile() {
        return fromFile;
    }


    /**
     * Sets the fromFile value for this UpdateGeometryRequest.
     * 
     * @param fromFile
     */
    public void setFromFile(java.lang.String fromFile) {
        this.fromFile = fromFile;
    }


    /**
     * Gets the layout value for this UpdateGeometryRequest.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this UpdateGeometryRequest.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the toFile value for this UpdateGeometryRequest.
     * 
     * @return toFile
     */
    public java.lang.String getToFile() {
        return toFile;
    }


    /**
     * Sets the toFile value for this UpdateGeometryRequest.
     * 
     * @param toFile
     */
    public void setToFile(java.lang.String toFile) {
        this.toFile = toFile;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UpdateGeometryRequest)) return false;
        UpdateGeometryRequest other = (UpdateGeometryRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.articleId==null && other.getArticleId()==null) || 
             (this.articleId!=null &&
              this.articleId.equals(other.getArticleId()))) &&
            ((this.fromFile==null && other.getFromFile()==null) || 
             (this.fromFile!=null &&
              this.fromFile.equals(other.getFromFile()))) &&
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.toFile==null && other.getToFile()==null) || 
             (this.toFile!=null &&
              this.toFile.equals(other.getToFile())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getArticleId() != null) {
            _hashCode += getArticleId().hashCode();
        }
        if (getFromFile() != null) {
            _hashCode += getFromFile().hashCode();
        }
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getToFile() != null) {
            _hashCode += getToFile().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UpdateGeometryRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UpdateGeometryRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("articleId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "articleId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromFile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fromFile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toFile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "toFile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
