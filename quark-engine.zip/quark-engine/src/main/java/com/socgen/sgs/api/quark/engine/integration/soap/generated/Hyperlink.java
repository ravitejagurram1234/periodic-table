/**
 * Hyperlink.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Hyperlink  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignRelativeTo;

    private java.lang.String HLType;

    private java.lang.String target;

    public Hyperlink() {
    }

    public Hyperlink(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignRelativeTo,
           java.lang.String HLType,
           java.lang.String target) {
        super(
            request);
        this.alignRelativeTo = alignRelativeTo;
        this.HLType = HLType;
        this.target = target;
    }


    /**
     * Gets the alignRelativeTo value for this Hyperlink.
     * 
     * @return alignRelativeTo
     */
    public java.lang.String getAlignRelativeTo() {
        return alignRelativeTo;
    }


    /**
     * Sets the alignRelativeTo value for this Hyperlink.
     * 
     * @param alignRelativeTo
     */
    public void setAlignRelativeTo(java.lang.String alignRelativeTo) {
        this.alignRelativeTo = alignRelativeTo;
    }


    /**
     * Gets the HLType value for this Hyperlink.
     * 
     * @return HLType
     */
    public java.lang.String getHLType() {
        return HLType;
    }


    /**
     * Sets the HLType value for this Hyperlink.
     * 
     * @param HLType
     */
    public void setHLType(java.lang.String HLType) {
        this.HLType = HLType;
    }


    /**
     * Gets the target value for this Hyperlink.
     * 
     * @return target
     */
    public java.lang.String getTarget() {
        return target;
    }


    /**
     * Sets the target value for this Hyperlink.
     * 
     * @param target
     */
    public void setTarget(java.lang.String target) {
        this.target = target;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Hyperlink)) return false;
        Hyperlink other = (Hyperlink) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignRelativeTo==null && other.getAlignRelativeTo()==null) || 
             (this.alignRelativeTo!=null &&
              this.alignRelativeTo.equals(other.getAlignRelativeTo()))) &&
            ((this.HLType==null && other.getHLType()==null) || 
             (this.HLType!=null &&
              this.HLType.equals(other.getHLType()))) &&
            ((this.target==null && other.getTarget()==null) || 
             (this.target!=null &&
              this.target.equals(other.getTarget())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignRelativeTo() != null) {
            _hashCode += getAlignRelativeTo().hashCode();
        }
        if (getHLType() != null) {
            _hashCode += getHLType().hashCode();
        }
        if (getTarget() != null) {
            _hashCode += getTarget().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Hyperlink.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Hyperlink"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignRelativeTo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignRelativeTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HLType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HLType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("target");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "target"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
