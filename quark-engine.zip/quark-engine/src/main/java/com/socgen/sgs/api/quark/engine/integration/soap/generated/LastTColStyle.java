/**
 * LastTColStyle.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class LastTColStyle  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String color;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftGrid leftGrid;

    private java.lang.String maxWidth;

    private java.lang.String minWidth;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RightGrid rightGrid;

    private java.lang.String shade;

    private java.lang.String width;

    public LastTColStyle() {
    }

    public LastTColStyle(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String color,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftGrid leftGrid,
           java.lang.String maxWidth,
           java.lang.String minWidth,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RightGrid rightGrid,
           java.lang.String shade,
           java.lang.String width) {
        super(
            request);
        this.color = color;
        this.leftGrid = leftGrid;
        this.maxWidth = maxWidth;
        this.minWidth = minWidth;
        this.rightGrid = rightGrid;
        this.shade = shade;
        this.width = width;
    }


    /**
     * Gets the color value for this LastTColStyle.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this LastTColStyle.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the leftGrid value for this LastTColStyle.
     * 
     * @return leftGrid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftGrid getLeftGrid() {
        return leftGrid;
    }


    /**
     * Sets the leftGrid value for this LastTColStyle.
     * 
     * @param leftGrid
     */
    public void setLeftGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.LeftGrid leftGrid) {
        this.leftGrid = leftGrid;
    }


    /**
     * Gets the maxWidth value for this LastTColStyle.
     * 
     * @return maxWidth
     */
    public java.lang.String getMaxWidth() {
        return maxWidth;
    }


    /**
     * Sets the maxWidth value for this LastTColStyle.
     * 
     * @param maxWidth
     */
    public void setMaxWidth(java.lang.String maxWidth) {
        this.maxWidth = maxWidth;
    }


    /**
     * Gets the minWidth value for this LastTColStyle.
     * 
     * @return minWidth
     */
    public java.lang.String getMinWidth() {
        return minWidth;
    }


    /**
     * Sets the minWidth value for this LastTColStyle.
     * 
     * @param minWidth
     */
    public void setMinWidth(java.lang.String minWidth) {
        this.minWidth = minWidth;
    }


    /**
     * Gets the rightGrid value for this LastTColStyle.
     * 
     * @return rightGrid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RightGrid getRightGrid() {
        return rightGrid;
    }


    /**
     * Sets the rightGrid value for this LastTColStyle.
     * 
     * @param rightGrid
     */
    public void setRightGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.RightGrid rightGrid) {
        this.rightGrid = rightGrid;
    }


    /**
     * Gets the shade value for this LastTColStyle.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this LastTColStyle.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the width value for this LastTColStyle.
     * 
     * @return width
     */
    public java.lang.String getWidth() {
        return width;
    }


    /**
     * Sets the width value for this LastTColStyle.
     * 
     * @param width
     */
    public void setWidth(java.lang.String width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LastTColStyle)) return false;
        LastTColStyle other = (LastTColStyle) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.leftGrid==null && other.getLeftGrid()==null) || 
             (this.leftGrid!=null &&
              this.leftGrid.equals(other.getLeftGrid()))) &&
            ((this.maxWidth==null && other.getMaxWidth()==null) || 
             (this.maxWidth!=null &&
              this.maxWidth.equals(other.getMaxWidth()))) &&
            ((this.minWidth==null && other.getMinWidth()==null) || 
             (this.minWidth!=null &&
              this.minWidth.equals(other.getMinWidth()))) &&
            ((this.rightGrid==null && other.getRightGrid()==null) || 
             (this.rightGrid!=null &&
              this.rightGrid.equals(other.getRightGrid()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.width==null && other.getWidth()==null) || 
             (this.width!=null &&
              this.width.equals(other.getWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getLeftGrid() != null) {
            _hashCode += getLeftGrid().hashCode();
        }
        if (getMaxWidth() != null) {
            _hashCode += getMaxWidth().hashCode();
        }
        if (getMinWidth() != null) {
            _hashCode += getMinWidth().hashCode();
        }
        if (getRightGrid() != null) {
            _hashCode += getRightGrid().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getWidth() != null) {
            _hashCode += getWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LastTColStyle.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LastTColStyle"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftGrid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "leftGrid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LeftGrid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "maxWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "minWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightGrid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rightGrid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RightGrid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("width");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "width"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
