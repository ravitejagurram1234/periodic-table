/**
 * EMailPreferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class EMailPreferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private boolean SMTPConfiguration;

    private int SMTPPort;

    private java.lang.String SMTPServerIP;

    private java.lang.String emailFrom;

    private java.lang.String emailTo;

    public EMailPreferences() {
    }

    public EMailPreferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           boolean SMTPConfiguration,
           int SMTPPort,
           java.lang.String SMTPServerIP,
           java.lang.String emailFrom,
           java.lang.String emailTo) {
        super(
            request);
        this.SMTPConfiguration = SMTPConfiguration;
        this.SMTPPort = SMTPPort;
        this.SMTPServerIP = SMTPServerIP;
        this.emailFrom = emailFrom;
        this.emailTo = emailTo;
    }


    /**
     * Gets the SMTPConfiguration value for this EMailPreferences.
     * 
     * @return SMTPConfiguration
     */
    public boolean isSMTPConfiguration() {
        return SMTPConfiguration;
    }


    /**
     * Sets the SMTPConfiguration value for this EMailPreferences.
     * 
     * @param SMTPConfiguration
     */
    public void setSMTPConfiguration(boolean SMTPConfiguration) {
        this.SMTPConfiguration = SMTPConfiguration;
    }


    /**
     * Gets the SMTPPort value for this EMailPreferences.
     * 
     * @return SMTPPort
     */
    public int getSMTPPort() {
        return SMTPPort;
    }


    /**
     * Sets the SMTPPort value for this EMailPreferences.
     * 
     * @param SMTPPort
     */
    public void setSMTPPort(int SMTPPort) {
        this.SMTPPort = SMTPPort;
    }


    /**
     * Gets the SMTPServerIP value for this EMailPreferences.
     * 
     * @return SMTPServerIP
     */
    public java.lang.String getSMTPServerIP() {
        return SMTPServerIP;
    }


    /**
     * Sets the SMTPServerIP value for this EMailPreferences.
     * 
     * @param SMTPServerIP
     */
    public void setSMTPServerIP(java.lang.String SMTPServerIP) {
        this.SMTPServerIP = SMTPServerIP;
    }


    /**
     * Gets the emailFrom value for this EMailPreferences.
     * 
     * @return emailFrom
     */
    public java.lang.String getEmailFrom() {
        return emailFrom;
    }


    /**
     * Sets the emailFrom value for this EMailPreferences.
     * 
     * @param emailFrom
     */
    public void setEmailFrom(java.lang.String emailFrom) {
        this.emailFrom = emailFrom;
    }


    /**
     * Gets the emailTo value for this EMailPreferences.
     * 
     * @return emailTo
     */
    public java.lang.String getEmailTo() {
        return emailTo;
    }


    /**
     * Sets the emailTo value for this EMailPreferences.
     * 
     * @param emailTo
     */
    public void setEmailTo(java.lang.String emailTo) {
        this.emailTo = emailTo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EMailPreferences)) return false;
        EMailPreferences other = (EMailPreferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            this.SMTPConfiguration == other.isSMTPConfiguration() &&
            this.SMTPPort == other.getSMTPPort() &&
            ((this.SMTPServerIP==null && other.getSMTPServerIP()==null) || 
             (this.SMTPServerIP!=null &&
              this.SMTPServerIP.equals(other.getSMTPServerIP()))) &&
            ((this.emailFrom==null && other.getEmailFrom()==null) || 
             (this.emailFrom!=null &&
              this.emailFrom.equals(other.getEmailFrom()))) &&
            ((this.emailTo==null && other.getEmailTo()==null) || 
             (this.emailTo!=null &&
              this.emailTo.equals(other.getEmailTo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        _hashCode += (isSMTPConfiguration() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getSMTPPort();
        if (getSMTPServerIP() != null) {
            _hashCode += getSMTPServerIP().hashCode();
        }
        if (getEmailFrom() != null) {
            _hashCode += getEmailFrom().hashCode();
        }
        if (getEmailTo() != null) {
            _hashCode += getEmailTo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EMailPreferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "EMailPreferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SMTPConfiguration");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SMTPConfiguration"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SMTPPort");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SMTPPort"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SMTPServerIP");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SMTPServerIP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailFrom");
        elemField.setXmlName(new javax.xml.namespace.QName("", "emailFrom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailTo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "emailTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
