/**
 * EMailPreferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class EMailPreferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String emailFrom;

    private java.lang.String emailTo;

    private int smtpPort;

    private java.lang.String smtpServerIP;

    public EMailPreferences() {
    }

    public EMailPreferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String emailFrom,
           java.lang.String emailTo,
           int smtpPort,
           java.lang.String smtpServerIP) {
        super(
            request);
        this.emailFrom = emailFrom;
        this.emailTo = emailTo;
        this.smtpPort = smtpPort;
        this.smtpServerIP = smtpServerIP;
    }


    /**
     * Gets the emailFrom value for this EMailPreferences.
     * 
     * @return emailFrom
     */
    public java.lang.String getEmailFrom() {
        return emailFrom;
    }


    /**
     * Sets the emailFrom value for this EMailPreferences.
     * 
     * @param emailFrom
     */
    public void setEmailFrom(java.lang.String emailFrom) {
        this.emailFrom = emailFrom;
    }


    /**
     * Gets the emailTo value for this EMailPreferences.
     * 
     * @return emailTo
     */
    public java.lang.String getEmailTo() {
        return emailTo;
    }


    /**
     * Sets the emailTo value for this EMailPreferences.
     * 
     * @param emailTo
     */
    public void setEmailTo(java.lang.String emailTo) {
        this.emailTo = emailTo;
    }


    /**
     * Gets the smtpPort value for this EMailPreferences.
     * 
     * @return smtpPort
     */
    public int getSmtpPort() {
        return smtpPort;
    }


    /**
     * Sets the smtpPort value for this EMailPreferences.
     * 
     * @param smtpPort
     */
    public void setSmtpPort(int smtpPort) {
        this.smtpPort = smtpPort;
    }


    /**
     * Gets the smtpServerIP value for this EMailPreferences.
     * 
     * @return smtpServerIP
     */
    public java.lang.String getSmtpServerIP() {
        return smtpServerIP;
    }


    /**
     * Sets the smtpServerIP value for this EMailPreferences.
     * 
     * @param smtpServerIP
     */
    public void setSmtpServerIP(java.lang.String smtpServerIP) {
        this.smtpServerIP = smtpServerIP;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EMailPreferences)) return false;
        EMailPreferences other = (EMailPreferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.emailFrom==null && other.getEmailFrom()==null) || 
             (this.emailFrom!=null &&
              this.emailFrom.equals(other.getEmailFrom()))) &&
            ((this.emailTo==null && other.getEmailTo()==null) || 
             (this.emailTo!=null &&
              this.emailTo.equals(other.getEmailTo()))) &&
            this.smtpPort == other.getSmtpPort() &&
            ((this.smtpServerIP==null && other.getSmtpServerIP()==null) || 
             (this.smtpServerIP!=null &&
              this.smtpServerIP.equals(other.getSmtpServerIP())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getEmailFrom() != null) {
            _hashCode += getEmailFrom().hashCode();
        }
        if (getEmailTo() != null) {
            _hashCode += getEmailTo().hashCode();
        }
        _hashCode += getSmtpPort();
        if (getSmtpServerIP() != null) {
            _hashCode += getSmtpServerIP().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EMailPreferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "EMailPreferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailFrom");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "emailFrom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailTo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "emailTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("smtpPort");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "smtpPort"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("smtpServerIP");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "smtpServerIP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
