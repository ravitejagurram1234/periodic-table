package com.socgen.sgs.api.quark.engine.service;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;

import java.util.List;

public interface ProcessRunService {
    List<Integer> fetchActiveRunIds();

    /**
     * Process a run and return the executed {@link Run} (with its result), so a parent
     * compartiment run can read each child's generated output. Callers that don't need the
     * result (RabbitMQ listener, REST controller) may ignore the return value.
     */
    Run runProcessor(RunIdDto runIdDto);

    RunProperties getRunProperties(RunIdDto runIdDto);
}

