package com.socgen.sgs.api.quark.engine.service;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;

import java.util.List;

public interface ProcessRunService {
    List<Integer> fetchActiveRunIds();
    void runProcessor(RunIdDto runIdDto);

    RunProperties getRunProperties(RunIdDto runIdDto);
}


