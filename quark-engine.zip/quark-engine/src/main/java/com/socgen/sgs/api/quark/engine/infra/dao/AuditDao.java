package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.Run;

/**
 * DAO for run audit. Cross-reference: .NET Proxy_Audit.InsertAuditRun.
 */
public interface AuditDao {

    /**
     * Insert one audit row for a finished run (QXP_PK_AUDIT.InsertAuditRun).
     *
     * @param run     the finished run (id, suivi, run type, start/end dates, status)
     * @param message a short audit message (truncated to fit the VARCHAR2 column)
     */
    void insertAuditRun(Run run, String message);
}