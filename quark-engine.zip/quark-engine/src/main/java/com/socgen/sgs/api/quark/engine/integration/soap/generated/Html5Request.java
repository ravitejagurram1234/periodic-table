/**
 * Html5Request.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Html5Request  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String layouts;

    private java.lang.String outputstyle;

    private java.lang.String tocSection;

    private java.lang.String webreader;

    public Html5Request() {
    }

    public Html5Request(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String layouts,
           java.lang.String outputstyle,
           java.lang.String tocSection,
           java.lang.String webreader) {
        super(
            request);
        this.layouts = layouts;
        this.outputstyle = outputstyle;
        this.tocSection = tocSection;
        this.webreader = webreader;
    }


    /**
     * Gets the layouts value for this Html5Request.
     * 
     * @return layouts
     */
    public java.lang.String getLayouts() {
        return layouts;
    }


    /**
     * Sets the layouts value for this Html5Request.
     * 
     * @param layouts
     */
    public void setLayouts(java.lang.String layouts) {
        this.layouts = layouts;
    }


    /**
     * Gets the outputstyle value for this Html5Request.
     * 
     * @return outputstyle
     */
    public java.lang.String getOutputstyle() {
        return outputstyle;
    }


    /**
     * Sets the outputstyle value for this Html5Request.
     * 
     * @param outputstyle
     */
    public void setOutputstyle(java.lang.String outputstyle) {
        this.outputstyle = outputstyle;
    }


    /**
     * Gets the tocSection value for this Html5Request.
     * 
     * @return tocSection
     */
    public java.lang.String getTocSection() {
        return tocSection;
    }


    /**
     * Sets the tocSection value for this Html5Request.
     * 
     * @param tocSection
     */
    public void setTocSection(java.lang.String tocSection) {
        this.tocSection = tocSection;
    }


    /**
     * Gets the webreader value for this Html5Request.
     * 
     * @return webreader
     */
    public java.lang.String getWebreader() {
        return webreader;
    }


    /**
     * Sets the webreader value for this Html5Request.
     * 
     * @param webreader
     */
    public void setWebreader(java.lang.String webreader) {
        this.webreader = webreader;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Html5Request)) return false;
        Html5Request other = (Html5Request) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.layouts==null && other.getLayouts()==null) || 
             (this.layouts!=null &&
              this.layouts.equals(other.getLayouts()))) &&
            ((this.outputstyle==null && other.getOutputstyle()==null) || 
             (this.outputstyle!=null &&
              this.outputstyle.equals(other.getOutputstyle()))) &&
            ((this.tocSection==null && other.getTocSection()==null) || 
             (this.tocSection!=null &&
              this.tocSection.equals(other.getTocSection()))) &&
            ((this.webreader==null && other.getWebreader()==null) || 
             (this.webreader!=null &&
              this.webreader.equals(other.getWebreader())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLayouts() != null) {
            _hashCode += getLayouts().hashCode();
        }
        if (getOutputstyle() != null) {
            _hashCode += getOutputstyle().hashCode();
        }
        if (getTocSection() != null) {
            _hashCode += getTocSection().hashCode();
        }
        if (getWebreader() != null) {
            _hashCode += getWebreader().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Html5Request.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Html5Request"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layouts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layouts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputstyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "outputstyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tocSection");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tocSection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webreader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "webreader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
