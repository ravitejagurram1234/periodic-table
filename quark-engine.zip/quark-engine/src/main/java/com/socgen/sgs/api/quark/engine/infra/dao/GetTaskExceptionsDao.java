package com.socgen.sgs.api.quark.engine.infra.dao;

import java.util.List;
import java.util.Map;

public interface GetTaskExceptionsDao {
    List<Map<String, Object>> getTaskExceptions(int runId);
}

