package com.socgen.sgs.api.quark.engine.domain;

import lombok.Getter;

/**
 * Defines the type of data storage for a run.
 * Uses bitwise flags matching .NET [Flags] Store_Data_Type enum.
 */
@Getter
public enum StoreDataType {
    NONE(0x00),
    SQL(0x01),
    DOCUMENT(0x02),
    ALL(0xFF);

    private final int code;

    StoreDataType(int code) {
        this.code = code;
    }

    /**
     * Check if this store type includes the given flag.
     * Mirrors .NET: (storeType & flag) == flag
     */
    public boolean hasFlag(StoreDataType flag) {
        return (this.code & flag.code) == flag.code;
    }

    /**
     * Bit test against a raw store-type code. This is the .NET-faithful check
     * ({@code (Store_Type & flag) == flag}, Run_Base.cs:677/699) and — unlike a single-value
     * enum — correctly handles combined values such as 0x03 (SQL|DOCUMENT). The raw int code
     * must be carried through (RunProperties.storeDataTypeCode) rather than collapsed to an enum,
     * because a plain Java enum cannot represent a combined flag value.
     *
     * @param code the raw store_data_type value from the DB
     * @param flag the flag to test for
     * @return true if all bits of {@code flag} are set in {@code code}
     */
    public static boolean hasFlag(int code, StoreDataType flag) {
        return (code & flag.code) == flag.code;
    }

    public static StoreDataType fromCode(int code) {
        for (StoreDataType type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        return NONE;
    }
}