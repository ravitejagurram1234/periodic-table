package com.socgen.sgs.api.quark.engine.domain;

import lombok.Getter;

/**
 * Defines the type of data storage for a run.
 * Uses bitwise flags matching .NET [Flags] Store_Data_Type enum.
 */
@Getter
public enum StoreDataType {
    NONE(0x00),
    SQL(0x01),
    DOCUMENT(0x02),
    ALL(0xFF);

    private final int code;

    StoreDataType(int code) {
        this.code = code;
    }

    /**
     * Check if this store type includes the given flag.
     * Mirrors .NET: (storeType & flag) == flag
     */
    public boolean hasFlag(StoreDataType flag) {
        return (this.code & flag.code) == flag.code;
    }

    public static StoreDataType fromCode(int code) {
        for (StoreDataType type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        return NONE;
    }
}