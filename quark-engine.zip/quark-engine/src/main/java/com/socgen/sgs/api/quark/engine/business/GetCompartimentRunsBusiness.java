package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.infra.dao.GetCompartimentRunsDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.LinkedHashMap;

/**
 * Business component for retrieving compartment run IDs.
 * Delegates to GetCompartimentRunsDao.
 *
 * Cross-reference: .NET Proxy_Run.Get_Compartiment_Runs()
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class GetCompartimentRunsBusiness {

    private final GetCompartimentRunsDao getCompartimentRunsDao;

    /**
     * Get compartment run IDs for a given configuration.
     *
     * @param idGabaritTete parent gabarit ID
     * @param idStructure   fund code (structure identifier)
     * @param idGabaritFils child gabarit ID
     * @param idTypeRapport report type (4 = compartiment)
     * @param idLangue      language ID
     * @param dateEcheance  due date
     * @param toGenerate    true to generate new runs, false to retrieve previous
     * @return ordered map of fund code → run ID
     */
    public LinkedHashMap<String, Integer> execute(int idGabaritTete, String idStructure,
                                                  int idGabaritFils, int idTypeRapport,
                                                  int idLangue, LocalDate dateEcheance,
                                                  boolean toGenerate) {
        log.info("Business layer: fetching compartment runs for gabarit={}, fund={}",
                idGabaritTete, idStructure);
        return getCompartimentRunsDao.getCompartimentRuns(
                idGabaritTete, idStructure, idGabaritFils, idTypeRapport,
                idLangue, dateEcheance, toGenerate);
    }
}