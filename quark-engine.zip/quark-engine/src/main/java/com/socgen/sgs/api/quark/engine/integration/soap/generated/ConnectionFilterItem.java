/**
 * ConnectionFilterItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ConnectionFilterItem  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String address;

    private boolean allow;

    private int index;

    private java.lang.String mask;

    private boolean newItem;

    private boolean removeItem;

    public ConnectionFilterItem() {
    }

    public ConnectionFilterItem(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String address,
           boolean allow,
           int index,
           java.lang.String mask,
           boolean newItem,
           boolean removeItem) {
        super(
            request);
        this.address = address;
        this.allow = allow;
        this.index = index;
        this.mask = mask;
        this.newItem = newItem;
        this.removeItem = removeItem;
    }


    /**
     * Gets the address value for this ConnectionFilterItem.
     * 
     * @return address
     */
    public java.lang.String getAddress() {
        return address;
    }


    /**
     * Sets the address value for this ConnectionFilterItem.
     * 
     * @param address
     */
    public void setAddress(java.lang.String address) {
        this.address = address;
    }


    /**
     * Gets the allow value for this ConnectionFilterItem.
     * 
     * @return allow
     */
    public boolean isAllow() {
        return allow;
    }


    /**
     * Sets the allow value for this ConnectionFilterItem.
     * 
     * @param allow
     */
    public void setAllow(boolean allow) {
        this.allow = allow;
    }


    /**
     * Gets the index value for this ConnectionFilterItem.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this ConnectionFilterItem.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the mask value for this ConnectionFilterItem.
     * 
     * @return mask
     */
    public java.lang.String getMask() {
        return mask;
    }


    /**
     * Sets the mask value for this ConnectionFilterItem.
     * 
     * @param mask
     */
    public void setMask(java.lang.String mask) {
        this.mask = mask;
    }


    /**
     * Gets the newItem value for this ConnectionFilterItem.
     * 
     * @return newItem
     */
    public boolean isNewItem() {
        return newItem;
    }


    /**
     * Sets the newItem value for this ConnectionFilterItem.
     * 
     * @param newItem
     */
    public void setNewItem(boolean newItem) {
        this.newItem = newItem;
    }


    /**
     * Gets the removeItem value for this ConnectionFilterItem.
     * 
     * @return removeItem
     */
    public boolean isRemoveItem() {
        return removeItem;
    }


    /**
     * Sets the removeItem value for this ConnectionFilterItem.
     * 
     * @param removeItem
     */
    public void setRemoveItem(boolean removeItem) {
        this.removeItem = removeItem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConnectionFilterItem)) return false;
        ConnectionFilterItem other = (ConnectionFilterItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.address==null && other.getAddress()==null) || 
             (this.address!=null &&
              this.address.equals(other.getAddress()))) &&
            this.allow == other.isAllow() &&
            this.index == other.getIndex() &&
            ((this.mask==null && other.getMask()==null) || 
             (this.mask!=null &&
              this.mask.equals(other.getMask()))) &&
            this.newItem == other.isNewItem() &&
            this.removeItem == other.isRemoveItem();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAddress() != null) {
            _hashCode += getAddress().hashCode();
        }
        _hashCode += (isAllow() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getIndex();
        if (getMask() != null) {
            _hashCode += getMask().hashCode();
        }
        _hashCode += (isNewItem() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isRemoveItem() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConnectionFilterItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ConnectionFilterItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("address");
        elemField.setXmlName(new javax.xml.namespace.QName("", "address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allow");
        elemField.setXmlName(new javax.xml.namespace.QName("", "allow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mask");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mask"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("newItem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "newItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("removeItem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "removeItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
