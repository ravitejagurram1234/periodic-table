/**
 * BNStyle.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class BNStyle  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String minDistFromText;

    private java.lang.String name;

    private java.lang.String restartNumbering;

    private java.lang.String startAt;

    private java.lang.String type;

    public BNStyle() {
    }

    public BNStyle(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String minDistFromText,
           java.lang.String name,
           java.lang.String restartNumbering,
           java.lang.String startAt,
           java.lang.String type) {
        super(
            request);
        this.minDistFromText = minDistFromText;
        this.name = name;
        this.restartNumbering = restartNumbering;
        this.startAt = startAt;
        this.type = type;
    }


    /**
     * Gets the minDistFromText value for this BNStyle.
     * 
     * @return minDistFromText
     */
    public java.lang.String getMinDistFromText() {
        return minDistFromText;
    }


    /**
     * Sets the minDistFromText value for this BNStyle.
     * 
     * @param minDistFromText
     */
    public void setMinDistFromText(java.lang.String minDistFromText) {
        this.minDistFromText = minDistFromText;
    }


    /**
     * Gets the name value for this BNStyle.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this BNStyle.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the restartNumbering value for this BNStyle.
     * 
     * @return restartNumbering
     */
    public java.lang.String getRestartNumbering() {
        return restartNumbering;
    }


    /**
     * Sets the restartNumbering value for this BNStyle.
     * 
     * @param restartNumbering
     */
    public void setRestartNumbering(java.lang.String restartNumbering) {
        this.restartNumbering = restartNumbering;
    }


    /**
     * Gets the startAt value for this BNStyle.
     * 
     * @return startAt
     */
    public java.lang.String getStartAt() {
        return startAt;
    }


    /**
     * Sets the startAt value for this BNStyle.
     * 
     * @param startAt
     */
    public void setStartAt(java.lang.String startAt) {
        this.startAt = startAt;
    }


    /**
     * Gets the type value for this BNStyle.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this BNStyle.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BNStyle)) return false;
        BNStyle other = (BNStyle) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.minDistFromText==null && other.getMinDistFromText()==null) || 
             (this.minDistFromText!=null &&
              this.minDistFromText.equals(other.getMinDistFromText()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.restartNumbering==null && other.getRestartNumbering()==null) || 
             (this.restartNumbering!=null &&
              this.restartNumbering.equals(other.getRestartNumbering()))) &&
            ((this.startAt==null && other.getStartAt()==null) || 
             (this.startAt!=null &&
              this.startAt.equals(other.getStartAt()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getMinDistFromText() != null) {
            _hashCode += getMinDistFromText().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getRestartNumbering() != null) {
            _hashCode += getRestartNumbering().hashCode();
        }
        if (getStartAt() != null) {
            _hashCode += getStartAt().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BNStyle.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "BNStyle"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minDistFromText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "minDistFromText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("restartNumbering");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "restartNumbering"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startAt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "startAt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
