/**
 * ColumnSplit.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ColumnSplit  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String columnCount;

    private java.lang.String columnGap;

    private java.lang.String columnRuleColor;

    private java.lang.String columnRuleEnabled;

    private java.lang.String columnRuleOpacity;

    private java.lang.String columnRuleShade;

    private java.lang.String columnRuleStyle;

    private java.lang.String columnRuleWidth;

    private java.lang.String spaceAfter;

    private java.lang.String spaceBefore;

    public ColumnSplit() {
    }

    public ColumnSplit(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String columnCount,
           java.lang.String columnGap,
           java.lang.String columnRuleColor,
           java.lang.String columnRuleEnabled,
           java.lang.String columnRuleOpacity,
           java.lang.String columnRuleShade,
           java.lang.String columnRuleStyle,
           java.lang.String columnRuleWidth,
           java.lang.String spaceAfter,
           java.lang.String spaceBefore) {
        super(
            request);
        this.columnCount = columnCount;
        this.columnGap = columnGap;
        this.columnRuleColor = columnRuleColor;
        this.columnRuleEnabled = columnRuleEnabled;
        this.columnRuleOpacity = columnRuleOpacity;
        this.columnRuleShade = columnRuleShade;
        this.columnRuleStyle = columnRuleStyle;
        this.columnRuleWidth = columnRuleWidth;
        this.spaceAfter = spaceAfter;
        this.spaceBefore = spaceBefore;
    }


    /**
     * Gets the columnCount value for this ColumnSplit.
     * 
     * @return columnCount
     */
    public java.lang.String getColumnCount() {
        return columnCount;
    }


    /**
     * Sets the columnCount value for this ColumnSplit.
     * 
     * @param columnCount
     */
    public void setColumnCount(java.lang.String columnCount) {
        this.columnCount = columnCount;
    }


    /**
     * Gets the columnGap value for this ColumnSplit.
     * 
     * @return columnGap
     */
    public java.lang.String getColumnGap() {
        return columnGap;
    }


    /**
     * Sets the columnGap value for this ColumnSplit.
     * 
     * @param columnGap
     */
    public void setColumnGap(java.lang.String columnGap) {
        this.columnGap = columnGap;
    }


    /**
     * Gets the columnRuleColor value for this ColumnSplit.
     * 
     * @return columnRuleColor
     */
    public java.lang.String getColumnRuleColor() {
        return columnRuleColor;
    }


    /**
     * Sets the columnRuleColor value for this ColumnSplit.
     * 
     * @param columnRuleColor
     */
    public void setColumnRuleColor(java.lang.String columnRuleColor) {
        this.columnRuleColor = columnRuleColor;
    }


    /**
     * Gets the columnRuleEnabled value for this ColumnSplit.
     * 
     * @return columnRuleEnabled
     */
    public java.lang.String getColumnRuleEnabled() {
        return columnRuleEnabled;
    }


    /**
     * Sets the columnRuleEnabled value for this ColumnSplit.
     * 
     * @param columnRuleEnabled
     */
    public void setColumnRuleEnabled(java.lang.String columnRuleEnabled) {
        this.columnRuleEnabled = columnRuleEnabled;
    }


    /**
     * Gets the columnRuleOpacity value for this ColumnSplit.
     * 
     * @return columnRuleOpacity
     */
    public java.lang.String getColumnRuleOpacity() {
        return columnRuleOpacity;
    }


    /**
     * Sets the columnRuleOpacity value for this ColumnSplit.
     * 
     * @param columnRuleOpacity
     */
    public void setColumnRuleOpacity(java.lang.String columnRuleOpacity) {
        this.columnRuleOpacity = columnRuleOpacity;
    }


    /**
     * Gets the columnRuleShade value for this ColumnSplit.
     * 
     * @return columnRuleShade
     */
    public java.lang.String getColumnRuleShade() {
        return columnRuleShade;
    }


    /**
     * Sets the columnRuleShade value for this ColumnSplit.
     * 
     * @param columnRuleShade
     */
    public void setColumnRuleShade(java.lang.String columnRuleShade) {
        this.columnRuleShade = columnRuleShade;
    }


    /**
     * Gets the columnRuleStyle value for this ColumnSplit.
     * 
     * @return columnRuleStyle
     */
    public java.lang.String getColumnRuleStyle() {
        return columnRuleStyle;
    }


    /**
     * Sets the columnRuleStyle value for this ColumnSplit.
     * 
     * @param columnRuleStyle
     */
    public void setColumnRuleStyle(java.lang.String columnRuleStyle) {
        this.columnRuleStyle = columnRuleStyle;
    }


    /**
     * Gets the columnRuleWidth value for this ColumnSplit.
     * 
     * @return columnRuleWidth
     */
    public java.lang.String getColumnRuleWidth() {
        return columnRuleWidth;
    }


    /**
     * Sets the columnRuleWidth value for this ColumnSplit.
     * 
     * @param columnRuleWidth
     */
    public void setColumnRuleWidth(java.lang.String columnRuleWidth) {
        this.columnRuleWidth = columnRuleWidth;
    }


    /**
     * Gets the spaceAfter value for this ColumnSplit.
     * 
     * @return spaceAfter
     */
    public java.lang.String getSpaceAfter() {
        return spaceAfter;
    }


    /**
     * Sets the spaceAfter value for this ColumnSplit.
     * 
     * @param spaceAfter
     */
    public void setSpaceAfter(java.lang.String spaceAfter) {
        this.spaceAfter = spaceAfter;
    }


    /**
     * Gets the spaceBefore value for this ColumnSplit.
     * 
     * @return spaceBefore
     */
    public java.lang.String getSpaceBefore() {
        return spaceBefore;
    }


    /**
     * Sets the spaceBefore value for this ColumnSplit.
     * 
     * @param spaceBefore
     */
    public void setSpaceBefore(java.lang.String spaceBefore) {
        this.spaceBefore = spaceBefore;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ColumnSplit)) return false;
        ColumnSplit other = (ColumnSplit) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.columnCount==null && other.getColumnCount()==null) || 
             (this.columnCount!=null &&
              this.columnCount.equals(other.getColumnCount()))) &&
            ((this.columnGap==null && other.getColumnGap()==null) || 
             (this.columnGap!=null &&
              this.columnGap.equals(other.getColumnGap()))) &&
            ((this.columnRuleColor==null && other.getColumnRuleColor()==null) || 
             (this.columnRuleColor!=null &&
              this.columnRuleColor.equals(other.getColumnRuleColor()))) &&
            ((this.columnRuleEnabled==null && other.getColumnRuleEnabled()==null) || 
             (this.columnRuleEnabled!=null &&
              this.columnRuleEnabled.equals(other.getColumnRuleEnabled()))) &&
            ((this.columnRuleOpacity==null && other.getColumnRuleOpacity()==null) || 
             (this.columnRuleOpacity!=null &&
              this.columnRuleOpacity.equals(other.getColumnRuleOpacity()))) &&
            ((this.columnRuleShade==null && other.getColumnRuleShade()==null) || 
             (this.columnRuleShade!=null &&
              this.columnRuleShade.equals(other.getColumnRuleShade()))) &&
            ((this.columnRuleStyle==null && other.getColumnRuleStyle()==null) || 
             (this.columnRuleStyle!=null &&
              this.columnRuleStyle.equals(other.getColumnRuleStyle()))) &&
            ((this.columnRuleWidth==null && other.getColumnRuleWidth()==null) || 
             (this.columnRuleWidth!=null &&
              this.columnRuleWidth.equals(other.getColumnRuleWidth()))) &&
            ((this.spaceAfter==null && other.getSpaceAfter()==null) || 
             (this.spaceAfter!=null &&
              this.spaceAfter.equals(other.getSpaceAfter()))) &&
            ((this.spaceBefore==null && other.getSpaceBefore()==null) || 
             (this.spaceBefore!=null &&
              this.spaceBefore.equals(other.getSpaceBefore())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getColumnCount() != null) {
            _hashCode += getColumnCount().hashCode();
        }
        if (getColumnGap() != null) {
            _hashCode += getColumnGap().hashCode();
        }
        if (getColumnRuleColor() != null) {
            _hashCode += getColumnRuleColor().hashCode();
        }
        if (getColumnRuleEnabled() != null) {
            _hashCode += getColumnRuleEnabled().hashCode();
        }
        if (getColumnRuleOpacity() != null) {
            _hashCode += getColumnRuleOpacity().hashCode();
        }
        if (getColumnRuleShade() != null) {
            _hashCode += getColumnRuleShade().hashCode();
        }
        if (getColumnRuleStyle() != null) {
            _hashCode += getColumnRuleStyle().hashCode();
        }
        if (getColumnRuleWidth() != null) {
            _hashCode += getColumnRuleWidth().hashCode();
        }
        if (getSpaceAfter() != null) {
            _hashCode += getSpaceAfter().hashCode();
        }
        if (getSpaceBefore() != null) {
            _hashCode += getSpaceBefore().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ColumnSplit.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColumnSplit"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnGap");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnGap"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnRuleColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnRuleColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnRuleEnabled");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnRuleEnabled"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnRuleOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnRuleOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnRuleShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnRuleShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnRuleStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnRuleStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnRuleWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnRuleWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spaceAfter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spaceAfter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spaceBefore");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "spaceBefore"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
