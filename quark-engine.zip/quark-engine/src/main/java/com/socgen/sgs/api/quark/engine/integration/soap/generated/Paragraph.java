/**
 * Paragraph.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Paragraph  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] calloutAnchors;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnFlow columnFlow;

    private java.lang.String conditionalStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Content[] contents;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Deletion[] deletions;

    private java.lang.String fauxStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Format format;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData;

    private java.lang.String indentLevel;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Index[] indexes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] inlineItems;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] inlineTables;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Insertion[] insertions;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] lists;

    private java.lang.String merge;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Note[] notes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak[] pageBreaks;

    private java.lang.String paraStyle;

    private java.lang.String parachar;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote[] refNotes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule[] rules;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec[] tabspecs;

    private java.lang.String textTagType;

    private java.lang.String xrefLabel;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Xref[] xrefs;

    public Paragraph() {
    }

    public Paragraph(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] calloutAnchors,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnFlow columnFlow,
           java.lang.String conditionalStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Content[] contents,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Deletion[] deletions,
           java.lang.String fauxStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Format format,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData,
           java.lang.String indentLevel,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Index[] indexes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] inlineItems,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] inlineTables,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Insertion[] insertions,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] lists,
           java.lang.String merge,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Note[] notes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak[] pageBreaks,
           java.lang.String paraStyle,
           java.lang.String parachar,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote[] refNotes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule[] rules,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec[] tabspecs,
           java.lang.String textTagType,
           java.lang.String xrefLabel,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Xref[] xrefs) {
        super(
            request);
        this.anchoredBoxReferences = anchoredBoxReferences;
        this.calloutAnchors = calloutAnchors;
        this.columnFlow = columnFlow;
        this.conditionalStyle = conditionalStyle;
        this.contents = contents;
        this.deletions = deletions;
        this.fauxStyle = fauxStyle;
        this.format = format;
        this.groupCharacters = groupCharacters;
        this.hiddenData = hiddenData;
        this.indentLevel = indentLevel;
        this.index = index;
        this.indexTerms = indexTerms;
        this.indexes = indexes;
        this.inlineBoxes = inlineBoxes;
        this.inlineItems = inlineItems;
        this.inlineTables = inlineTables;
        this.insertions = insertions;
        this.lists = lists;
        this.merge = merge;
        this.notes = notes;
        this.pageBreaks = pageBreaks;
        this.paraStyle = paraStyle;
        this.parachar = parachar;
        this.refNotes = refNotes;
        this.richText = richText;
        this.rubi = rubi;
        this.rules = rules;
        this.tabspecs = tabspecs;
        this.textTagType = textTagType;
        this.xrefLabel = xrefLabel;
        this.xrefs = xrefs;
    }


    /**
     * Gets the anchoredBoxReferences value for this Paragraph.
     * 
     * @return anchoredBoxReferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] getAnchoredBoxReferences() {
        return anchoredBoxReferences;
    }


    /**
     * Sets the anchoredBoxReferences value for this Paragraph.
     * 
     * @param anchoredBoxReferences
     */
    public void setAnchoredBoxReferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences) {
        this.anchoredBoxReferences = anchoredBoxReferences;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference getAnchoredBoxReferences(int i) {
        return this.anchoredBoxReferences[i];
    }

    public void setAnchoredBoxReferences(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference _value) {
        this.anchoredBoxReferences[i] = _value;
    }


    /**
     * Gets the calloutAnchors value for this Paragraph.
     * 
     * @return calloutAnchors
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] getCalloutAnchors() {
        return calloutAnchors;
    }


    /**
     * Sets the calloutAnchors value for this Paragraph.
     * 
     * @param calloutAnchors
     */
    public void setCalloutAnchors(com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] calloutAnchors) {
        this.calloutAnchors = calloutAnchors;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor getCalloutAnchors(int i) {
        return this.calloutAnchors[i];
    }

    public void setCalloutAnchors(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor _value) {
        this.calloutAnchors[i] = _value;
    }


    /**
     * Gets the columnFlow value for this Paragraph.
     * 
     * @return columnFlow
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnFlow getColumnFlow() {
        return columnFlow;
    }


    /**
     * Sets the columnFlow value for this Paragraph.
     * 
     * @param columnFlow
     */
    public void setColumnFlow(com.socgen.sgs.api.quark.engine.integration.soap.generated.ColumnFlow columnFlow) {
        this.columnFlow = columnFlow;
    }


    /**
     * Gets the conditionalStyle value for this Paragraph.
     * 
     * @return conditionalStyle
     */
    public java.lang.String getConditionalStyle() {
        return conditionalStyle;
    }


    /**
     * Sets the conditionalStyle value for this Paragraph.
     * 
     * @param conditionalStyle
     */
    public void setConditionalStyle(java.lang.String conditionalStyle) {
        this.conditionalStyle = conditionalStyle;
    }


    /**
     * Gets the contents value for this Paragraph.
     * 
     * @return contents
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Content[] getContents() {
        return contents;
    }


    /**
     * Sets the contents value for this Paragraph.
     * 
     * @param contents
     */
    public void setContents(com.socgen.sgs.api.quark.engine.integration.soap.generated.Content[] contents) {
        this.contents = contents;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Content getContents(int i) {
        return this.contents[i];
    }

    public void setContents(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Content _value) {
        this.contents[i] = _value;
    }


    /**
     * Gets the deletions value for this Paragraph.
     * 
     * @return deletions
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Deletion[] getDeletions() {
        return deletions;
    }


    /**
     * Sets the deletions value for this Paragraph.
     * 
     * @param deletions
     */
    public void setDeletions(com.socgen.sgs.api.quark.engine.integration.soap.generated.Deletion[] deletions) {
        this.deletions = deletions;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Deletion getDeletions(int i) {
        return this.deletions[i];
    }

    public void setDeletions(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Deletion _value) {
        this.deletions[i] = _value;
    }


    /**
     * Gets the fauxStyle value for this Paragraph.
     * 
     * @return fauxStyle
     */
    public java.lang.String getFauxStyle() {
        return fauxStyle;
    }


    /**
     * Sets the fauxStyle value for this Paragraph.
     * 
     * @param fauxStyle
     */
    public void setFauxStyle(java.lang.String fauxStyle) {
        this.fauxStyle = fauxStyle;
    }


    /**
     * Gets the format value for this Paragraph.
     * 
     * @return format
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Format getFormat() {
        return format;
    }


    /**
     * Sets the format value for this Paragraph.
     * 
     * @param format
     */
    public void setFormat(com.socgen.sgs.api.quark.engine.integration.soap.generated.Format format) {
        this.format = format;
    }


    /**
     * Gets the groupCharacters value for this Paragraph.
     * 
     * @return groupCharacters
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] getGroupCharacters() {
        return groupCharacters;
    }


    /**
     * Sets the groupCharacters value for this Paragraph.
     * 
     * @param groupCharacters
     */
    public void setGroupCharacters(com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters) {
        this.groupCharacters = groupCharacters;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters getGroupCharacters(int i) {
        return this.groupCharacters[i];
    }

    public void setGroupCharacters(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters _value) {
        this.groupCharacters[i] = _value;
    }


    /**
     * Gets the hiddenData value for this Paragraph.
     * 
     * @return hiddenData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] getHiddenData() {
        return hiddenData;
    }


    /**
     * Sets the hiddenData value for this Paragraph.
     * 
     * @param hiddenData
     */
    public void setHiddenData(com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData) {
        this.hiddenData = hiddenData;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData getHiddenData(int i) {
        return this.hiddenData[i];
    }

    public void setHiddenData(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData _value) {
        this.hiddenData[i] = _value;
    }


    /**
     * Gets the indentLevel value for this Paragraph.
     * 
     * @return indentLevel
     */
    public java.lang.String getIndentLevel() {
        return indentLevel;
    }


    /**
     * Sets the indentLevel value for this Paragraph.
     * 
     * @param indentLevel
     */
    public void setIndentLevel(java.lang.String indentLevel) {
        this.indentLevel = indentLevel;
    }


    /**
     * Gets the index value for this Paragraph.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this Paragraph.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the indexTerms value for this Paragraph.
     * 
     * @return indexTerms
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] getIndexTerms() {
        return indexTerms;
    }


    /**
     * Sets the indexTerms value for this Paragraph.
     * 
     * @param indexTerms
     */
    public void setIndexTerms(com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms) {
        this.indexTerms = indexTerms;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm getIndexTerms(int i) {
        return this.indexTerms[i];
    }

    public void setIndexTerms(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm _value) {
        this.indexTerms[i] = _value;
    }


    /**
     * Gets the indexes value for this Paragraph.
     * 
     * @return indexes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Index[] getIndexes() {
        return indexes;
    }


    /**
     * Sets the indexes value for this Paragraph.
     * 
     * @param indexes
     */
    public void setIndexes(com.socgen.sgs.api.quark.engine.integration.soap.generated.Index[] indexes) {
        this.indexes = indexes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Index getIndexes(int i) {
        return this.indexes[i];
    }

    public void setIndexes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Index _value) {
        this.indexes[i] = _value;
    }


    /**
     * Gets the inlineBoxes value for this Paragraph.
     * 
     * @return inlineBoxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] getInlineBoxes() {
        return inlineBoxes;
    }


    /**
     * Sets the inlineBoxes value for this Paragraph.
     * 
     * @param inlineBoxes
     */
    public void setInlineBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes) {
        this.inlineBoxes = inlineBoxes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox getInlineBoxes(int i) {
        return this.inlineBoxes[i];
    }

    public void setInlineBoxes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox _value) {
        this.inlineBoxes[i] = _value;
    }


    /**
     * Gets the inlineItems value for this Paragraph.
     * 
     * @return inlineItems
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] getInlineItems() {
        return inlineItems;
    }


    /**
     * Sets the inlineItems value for this Paragraph.
     * 
     * @param inlineItems
     */
    public void setInlineItems(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] inlineItems) {
        this.inlineItems = inlineItems;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem getInlineItems(int i) {
        return this.inlineItems[i];
    }

    public void setInlineItems(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem _value) {
        this.inlineItems[i] = _value;
    }


    /**
     * Gets the inlineTables value for this Paragraph.
     * 
     * @return inlineTables
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] getInlineTables() {
        return inlineTables;
    }


    /**
     * Sets the inlineTables value for this Paragraph.
     * 
     * @param inlineTables
     */
    public void setInlineTables(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] inlineTables) {
        this.inlineTables = inlineTables;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable getInlineTables(int i) {
        return this.inlineTables[i];
    }

    public void setInlineTables(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable _value) {
        this.inlineTables[i] = _value;
    }


    /**
     * Gets the insertions value for this Paragraph.
     * 
     * @return insertions
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Insertion[] getInsertions() {
        return insertions;
    }


    /**
     * Sets the insertions value for this Paragraph.
     * 
     * @param insertions
     */
    public void setInsertions(com.socgen.sgs.api.quark.engine.integration.soap.generated.Insertion[] insertions) {
        this.insertions = insertions;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Insertion getInsertions(int i) {
        return this.insertions[i];
    }

    public void setInsertions(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Insertion _value) {
        this.insertions[i] = _value;
    }


    /**
     * Gets the lists value for this Paragraph.
     * 
     * @return lists
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] getLists() {
        return lists;
    }


    /**
     * Sets the lists value for this Paragraph.
     * 
     * @param lists
     */
    public void setLists(com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] lists) {
        this.lists = lists;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.List getLists(int i) {
        return this.lists[i];
    }

    public void setLists(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.List _value) {
        this.lists[i] = _value;
    }


    /**
     * Gets the merge value for this Paragraph.
     * 
     * @return merge
     */
    public java.lang.String getMerge() {
        return merge;
    }


    /**
     * Sets the merge value for this Paragraph.
     * 
     * @param merge
     */
    public void setMerge(java.lang.String merge) {
        this.merge = merge;
    }


    /**
     * Gets the notes value for this Paragraph.
     * 
     * @return notes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Note[] getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this Paragraph.
     * 
     * @param notes
     */
    public void setNotes(com.socgen.sgs.api.quark.engine.integration.soap.generated.Note[] notes) {
        this.notes = notes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Note getNotes(int i) {
        return this.notes[i];
    }

    public void setNotes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Note _value) {
        this.notes[i] = _value;
    }


    /**
     * Gets the pageBreaks value for this Paragraph.
     * 
     * @return pageBreaks
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak[] getPageBreaks() {
        return pageBreaks;
    }


    /**
     * Sets the pageBreaks value for this Paragraph.
     * 
     * @param pageBreaks
     */
    public void setPageBreaks(com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak[] pageBreaks) {
        this.pageBreaks = pageBreaks;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak getPageBreaks(int i) {
        return this.pageBreaks[i];
    }

    public void setPageBreaks(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak _value) {
        this.pageBreaks[i] = _value;
    }


    /**
     * Gets the paraStyle value for this Paragraph.
     * 
     * @return paraStyle
     */
    public java.lang.String getParaStyle() {
        return paraStyle;
    }


    /**
     * Sets the paraStyle value for this Paragraph.
     * 
     * @param paraStyle
     */
    public void setParaStyle(java.lang.String paraStyle) {
        this.paraStyle = paraStyle;
    }


    /**
     * Gets the parachar value for this Paragraph.
     * 
     * @return parachar
     */
    public java.lang.String getParachar() {
        return parachar;
    }


    /**
     * Sets the parachar value for this Paragraph.
     * 
     * @param parachar
     */
    public void setParachar(java.lang.String parachar) {
        this.parachar = parachar;
    }


    /**
     * Gets the refNotes value for this Paragraph.
     * 
     * @return refNotes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote[] getRefNotes() {
        return refNotes;
    }


    /**
     * Sets the refNotes value for this Paragraph.
     * 
     * @param refNotes
     */
    public void setRefNotes(com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote[] refNotes) {
        this.refNotes = refNotes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote getRefNotes(int i) {
        return this.refNotes[i];
    }

    public void setRefNotes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote _value) {
        this.refNotes[i] = _value;
    }


    /**
     * Gets the richText value for this Paragraph.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this Paragraph.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText getRichText(int i) {
        return this.richText[i];
    }

    public void setRichText(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText _value) {
        this.richText[i] = _value;
    }


    /**
     * Gets the rubi value for this Paragraph.
     * 
     * @return rubi
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] getRubi() {
        return rubi;
    }


    /**
     * Sets the rubi value for this Paragraph.
     * 
     * @param rubi
     */
    public void setRubi(com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi) {
        this.rubi = rubi;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi getRubi(int i) {
        return this.rubi[i];
    }

    public void setRubi(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi _value) {
        this.rubi[i] = _value;
    }


    /**
     * Gets the rules value for this Paragraph.
     * 
     * @return rules
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule[] getRules() {
        return rules;
    }


    /**
     * Sets the rules value for this Paragraph.
     * 
     * @param rules
     */
    public void setRules(com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule[] rules) {
        this.rules = rules;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule getRules(int i) {
        return this.rules[i];
    }

    public void setRules(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule _value) {
        this.rules[i] = _value;
    }


    /**
     * Gets the tabspecs value for this Paragraph.
     * 
     * @return tabspecs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec[] getTabspecs() {
        return tabspecs;
    }


    /**
     * Sets the tabspecs value for this Paragraph.
     * 
     * @param tabspecs
     */
    public void setTabspecs(com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec[] tabspecs) {
        this.tabspecs = tabspecs;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec getTabspecs(int i) {
        return this.tabspecs[i];
    }

    public void setTabspecs(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec _value) {
        this.tabspecs[i] = _value;
    }


    /**
     * Gets the textTagType value for this Paragraph.
     * 
     * @return textTagType
     */
    public java.lang.String getTextTagType() {
        return textTagType;
    }


    /**
     * Sets the textTagType value for this Paragraph.
     * 
     * @param textTagType
     */
    public void setTextTagType(java.lang.String textTagType) {
        this.textTagType = textTagType;
    }


    /**
     * Gets the xrefLabel value for this Paragraph.
     * 
     * @return xrefLabel
     */
    public java.lang.String getXrefLabel() {
        return xrefLabel;
    }


    /**
     * Sets the xrefLabel value for this Paragraph.
     * 
     * @param xrefLabel
     */
    public void setXrefLabel(java.lang.String xrefLabel) {
        this.xrefLabel = xrefLabel;
    }


    /**
     * Gets the xrefs value for this Paragraph.
     * 
     * @return xrefs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Xref[] getXrefs() {
        return xrefs;
    }


    /**
     * Sets the xrefs value for this Paragraph.
     * 
     * @param xrefs
     */
    public void setXrefs(com.socgen.sgs.api.quark.engine.integration.soap.generated.Xref[] xrefs) {
        this.xrefs = xrefs;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Xref getXrefs(int i) {
        return this.xrefs[i];
    }

    public void setXrefs(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Xref _value) {
        this.xrefs[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Paragraph)) return false;
        Paragraph other = (Paragraph) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.anchoredBoxReferences==null && other.getAnchoredBoxReferences()==null) || 
             (this.anchoredBoxReferences!=null &&
              java.util.Arrays.equals(this.anchoredBoxReferences, other.getAnchoredBoxReferences()))) &&
            ((this.calloutAnchors==null && other.getCalloutAnchors()==null) || 
             (this.calloutAnchors!=null &&
              java.util.Arrays.equals(this.calloutAnchors, other.getCalloutAnchors()))) &&
            ((this.columnFlow==null && other.getColumnFlow()==null) || 
             (this.columnFlow!=null &&
              this.columnFlow.equals(other.getColumnFlow()))) &&
            ((this.conditionalStyle==null && other.getConditionalStyle()==null) || 
             (this.conditionalStyle!=null &&
              this.conditionalStyle.equals(other.getConditionalStyle()))) &&
            ((this.contents==null && other.getContents()==null) || 
             (this.contents!=null &&
              java.util.Arrays.equals(this.contents, other.getContents()))) &&
            ((this.deletions==null && other.getDeletions()==null) || 
             (this.deletions!=null &&
              java.util.Arrays.equals(this.deletions, other.getDeletions()))) &&
            ((this.fauxStyle==null && other.getFauxStyle()==null) || 
             (this.fauxStyle!=null &&
              this.fauxStyle.equals(other.getFauxStyle()))) &&
            ((this.format==null && other.getFormat()==null) || 
             (this.format!=null &&
              this.format.equals(other.getFormat()))) &&
            ((this.groupCharacters==null && other.getGroupCharacters()==null) || 
             (this.groupCharacters!=null &&
              java.util.Arrays.equals(this.groupCharacters, other.getGroupCharacters()))) &&
            ((this.hiddenData==null && other.getHiddenData()==null) || 
             (this.hiddenData!=null &&
              java.util.Arrays.equals(this.hiddenData, other.getHiddenData()))) &&
            ((this.indentLevel==null && other.getIndentLevel()==null) || 
             (this.indentLevel!=null &&
              this.indentLevel.equals(other.getIndentLevel()))) &&
            this.index == other.getIndex() &&
            ((this.indexTerms==null && other.getIndexTerms()==null) || 
             (this.indexTerms!=null &&
              java.util.Arrays.equals(this.indexTerms, other.getIndexTerms()))) &&
            ((this.indexes==null && other.getIndexes()==null) || 
             (this.indexes!=null &&
              java.util.Arrays.equals(this.indexes, other.getIndexes()))) &&
            ((this.inlineBoxes==null && other.getInlineBoxes()==null) || 
             (this.inlineBoxes!=null &&
              java.util.Arrays.equals(this.inlineBoxes, other.getInlineBoxes()))) &&
            ((this.inlineItems==null && other.getInlineItems()==null) || 
             (this.inlineItems!=null &&
              java.util.Arrays.equals(this.inlineItems, other.getInlineItems()))) &&
            ((this.inlineTables==null && other.getInlineTables()==null) || 
             (this.inlineTables!=null &&
              java.util.Arrays.equals(this.inlineTables, other.getInlineTables()))) &&
            ((this.insertions==null && other.getInsertions()==null) || 
             (this.insertions!=null &&
              java.util.Arrays.equals(this.insertions, other.getInsertions()))) &&
            ((this.lists==null && other.getLists()==null) || 
             (this.lists!=null &&
              java.util.Arrays.equals(this.lists, other.getLists()))) &&
            ((this.merge==null && other.getMerge()==null) || 
             (this.merge!=null &&
              this.merge.equals(other.getMerge()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              java.util.Arrays.equals(this.notes, other.getNotes()))) &&
            ((this.pageBreaks==null && other.getPageBreaks()==null) || 
             (this.pageBreaks!=null &&
              java.util.Arrays.equals(this.pageBreaks, other.getPageBreaks()))) &&
            ((this.paraStyle==null && other.getParaStyle()==null) || 
             (this.paraStyle!=null &&
              this.paraStyle.equals(other.getParaStyle()))) &&
            ((this.parachar==null && other.getParachar()==null) || 
             (this.parachar!=null &&
              this.parachar.equals(other.getParachar()))) &&
            ((this.refNotes==null && other.getRefNotes()==null) || 
             (this.refNotes!=null &&
              java.util.Arrays.equals(this.refNotes, other.getRefNotes()))) &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText()))) &&
            ((this.rubi==null && other.getRubi()==null) || 
             (this.rubi!=null &&
              java.util.Arrays.equals(this.rubi, other.getRubi()))) &&
            ((this.rules==null && other.getRules()==null) || 
             (this.rules!=null &&
              java.util.Arrays.equals(this.rules, other.getRules()))) &&
            ((this.tabspecs==null && other.getTabspecs()==null) || 
             (this.tabspecs!=null &&
              java.util.Arrays.equals(this.tabspecs, other.getTabspecs()))) &&
            ((this.textTagType==null && other.getTextTagType()==null) || 
             (this.textTagType!=null &&
              this.textTagType.equals(other.getTextTagType()))) &&
            ((this.xrefLabel==null && other.getXrefLabel()==null) || 
             (this.xrefLabel!=null &&
              this.xrefLabel.equals(other.getXrefLabel()))) &&
            ((this.xrefs==null && other.getXrefs()==null) || 
             (this.xrefs!=null &&
              java.util.Arrays.equals(this.xrefs, other.getXrefs())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAnchoredBoxReferences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAnchoredBoxReferences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAnchoredBoxReferences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCalloutAnchors() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCalloutAnchors());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCalloutAnchors(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getColumnFlow() != null) {
            _hashCode += getColumnFlow().hashCode();
        }
        if (getConditionalStyle() != null) {
            _hashCode += getConditionalStyle().hashCode();
        }
        if (getContents() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getContents());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getContents(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDeletions() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDeletions());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDeletions(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFauxStyle() != null) {
            _hashCode += getFauxStyle().hashCode();
        }
        if (getFormat() != null) {
            _hashCode += getFormat().hashCode();
        }
        if (getGroupCharacters() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGroupCharacters());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGroupCharacters(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHiddenData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHiddenData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHiddenData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIndentLevel() != null) {
            _hashCode += getIndentLevel().hashCode();
        }
        _hashCode += getIndex();
        if (getIndexTerms() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIndexTerms());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIndexTerms(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIndexes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIndexes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIndexes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInlineBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInlineItems() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineItems());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineItems(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInlineTables() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineTables());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineTables(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInsertions() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInsertions());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInsertions(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLists() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLists());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLists(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMerge() != null) {
            _hashCode += getMerge().hashCode();
        }
        if (getNotes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNotes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNotes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPageBreaks() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPageBreaks());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPageBreaks(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getParaStyle() != null) {
            _hashCode += getParaStyle().hashCode();
        }
        if (getParachar() != null) {
            _hashCode += getParachar().hashCode();
        }
        if (getRefNotes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRefNotes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRefNotes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRubi() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRubi());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRubi(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRules() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRules());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRules(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTabspecs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTabspecs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTabspecs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTextTagType() != null) {
            _hashCode += getTextTagType().hashCode();
        }
        if (getXrefLabel() != null) {
            _hashCode += getXrefLabel().hashCode();
        }
        if (getXrefs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getXrefs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getXrefs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Paragraph.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Paragraph"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredBoxReferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredBoxReferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AnchoredBoxReference"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("calloutAnchors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "calloutAnchors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CalloutAnchor"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columnFlow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "columnFlow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColumnFlow"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conditionalStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "conditionalStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contents");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "contents"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Content"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deletions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "deletions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Deletion"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fauxStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fauxStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("format");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "format"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Format"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupCharacters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "groupCharacters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "GroupCharacters"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hiddenData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hiddenData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HiddenData"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indentLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "indentLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indexTerms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "indexTerms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexTerm"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indexes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "indexes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Index"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineBoxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineBoxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineBox"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineItems");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineItem"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineTables");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineTables"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineTable"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insertions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "insertions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Insertion"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lists");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "lists"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "List"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("merge");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "merge"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Note"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageBreaks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pageBreaks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageBreak"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paraStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "paraStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parachar");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "parachar"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refNotes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "refNotes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RefNote"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RichText"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rubi");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rubi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Rubi"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rules");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rules"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Rule"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tabspecs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tabspecs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TabSpec"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textTagType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "textTagType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xrefLabel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "xrefLabel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("xrefs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "xrefs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Xref"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
