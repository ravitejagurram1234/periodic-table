/**
 * Paragraph.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Paragraph  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences;

    private java.lang.String fauxStyle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Format format;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData;

    private int index;

    private java.lang.String merge;

    private java.lang.String paraStyle;

    private java.lang.String parachar;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule[] rules;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec[] tabspecs;

    public Paragraph() {
    }

    public Paragraph(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences,
           java.lang.String fauxStyle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Format format,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData,
           int index,
           java.lang.String merge,
           java.lang.String paraStyle,
           java.lang.String parachar,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule[] rules,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec[] tabspecs) {
        super(
            request);
        this.anchoredBoxReferences = anchoredBoxReferences;
        this.fauxStyle = fauxStyle;
        this.format = format;
        this.groupCharacters = groupCharacters;
        this.hiddenData = hiddenData;
        this.index = index;
        this.merge = merge;
        this.paraStyle = paraStyle;
        this.parachar = parachar;
        this.richText = richText;
        this.rubi = rubi;
        this.rules = rules;
        this.tabspecs = tabspecs;
    }


    /**
     * Gets the anchoredBoxReferences value for this Paragraph.
     * 
     * @return anchoredBoxReferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] getAnchoredBoxReferences() {
        return anchoredBoxReferences;
    }


    /**
     * Sets the anchoredBoxReferences value for this Paragraph.
     * 
     * @param anchoredBoxReferences
     */
    public void setAnchoredBoxReferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences) {
        this.anchoredBoxReferences = anchoredBoxReferences;
    }


    /**
     * Gets the fauxStyle value for this Paragraph.
     * 
     * @return fauxStyle
     */
    public java.lang.String getFauxStyle() {
        return fauxStyle;
    }


    /**
     * Sets the fauxStyle value for this Paragraph.
     * 
     * @param fauxStyle
     */
    public void setFauxStyle(java.lang.String fauxStyle) {
        this.fauxStyle = fauxStyle;
    }


    /**
     * Gets the format value for this Paragraph.
     * 
     * @return format
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Format getFormat() {
        return format;
    }


    /**
     * Sets the format value for this Paragraph.
     * 
     * @param format
     */
    public void setFormat(com.socgen.sgs.api.quark.engine.integration.soap.generated.Format format) {
        this.format = format;
    }


    /**
     * Gets the groupCharacters value for this Paragraph.
     * 
     * @return groupCharacters
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] getGroupCharacters() {
        return groupCharacters;
    }


    /**
     * Sets the groupCharacters value for this Paragraph.
     * 
     * @param groupCharacters
     */
    public void setGroupCharacters(com.socgen.sgs.api.quark.engine.integration.soap.generated.GroupCharacters[] groupCharacters) {
        this.groupCharacters = groupCharacters;
    }


    /**
     * Gets the hiddenData value for this Paragraph.
     * 
     * @return hiddenData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] getHiddenData() {
        return hiddenData;
    }


    /**
     * Sets the hiddenData value for this Paragraph.
     * 
     * @param hiddenData
     */
    public void setHiddenData(com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData) {
        this.hiddenData = hiddenData;
    }


    /**
     * Gets the index value for this Paragraph.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this Paragraph.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the merge value for this Paragraph.
     * 
     * @return merge
     */
    public java.lang.String getMerge() {
        return merge;
    }


    /**
     * Sets the merge value for this Paragraph.
     * 
     * @param merge
     */
    public void setMerge(java.lang.String merge) {
        this.merge = merge;
    }


    /**
     * Gets the paraStyle value for this Paragraph.
     * 
     * @return paraStyle
     */
    public java.lang.String getParaStyle() {
        return paraStyle;
    }


    /**
     * Sets the paraStyle value for this Paragraph.
     * 
     * @param paraStyle
     */
    public void setParaStyle(java.lang.String paraStyle) {
        this.paraStyle = paraStyle;
    }


    /**
     * Gets the parachar value for this Paragraph.
     * 
     * @return parachar
     */
    public java.lang.String getParachar() {
        return parachar;
    }


    /**
     * Sets the parachar value for this Paragraph.
     * 
     * @param parachar
     */
    public void setParachar(java.lang.String parachar) {
        this.parachar = parachar;
    }


    /**
     * Gets the richText value for this Paragraph.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this Paragraph.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }


    /**
     * Gets the rubi value for this Paragraph.
     * 
     * @return rubi
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] getRubi() {
        return rubi;
    }


    /**
     * Sets the rubi value for this Paragraph.
     * 
     * @param rubi
     */
    public void setRubi(com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi) {
        this.rubi = rubi;
    }


    /**
     * Gets the rules value for this Paragraph.
     * 
     * @return rules
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule[] getRules() {
        return rules;
    }


    /**
     * Sets the rules value for this Paragraph.
     * 
     * @param rules
     */
    public void setRules(com.socgen.sgs.api.quark.engine.integration.soap.generated.Rule[] rules) {
        this.rules = rules;
    }


    /**
     * Gets the tabspecs value for this Paragraph.
     * 
     * @return tabspecs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec[] getTabspecs() {
        return tabspecs;
    }


    /**
     * Sets the tabspecs value for this Paragraph.
     * 
     * @param tabspecs
     */
    public void setTabspecs(com.socgen.sgs.api.quark.engine.integration.soap.generated.TabSpec[] tabspecs) {
        this.tabspecs = tabspecs;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Paragraph)) return false;
        Paragraph other = (Paragraph) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.anchoredBoxReferences==null && other.getAnchoredBoxReferences()==null) || 
             (this.anchoredBoxReferences!=null &&
              java.util.Arrays.equals(this.anchoredBoxReferences, other.getAnchoredBoxReferences()))) &&
            ((this.fauxStyle==null && other.getFauxStyle()==null) || 
             (this.fauxStyle!=null &&
              this.fauxStyle.equals(other.getFauxStyle()))) &&
            ((this.format==null && other.getFormat()==null) || 
             (this.format!=null &&
              this.format.equals(other.getFormat()))) &&
            ((this.groupCharacters==null && other.getGroupCharacters()==null) || 
             (this.groupCharacters!=null &&
              java.util.Arrays.equals(this.groupCharacters, other.getGroupCharacters()))) &&
            ((this.hiddenData==null && other.getHiddenData()==null) || 
             (this.hiddenData!=null &&
              java.util.Arrays.equals(this.hiddenData, other.getHiddenData()))) &&
            this.index == other.getIndex() &&
            ((this.merge==null && other.getMerge()==null) || 
             (this.merge!=null &&
              this.merge.equals(other.getMerge()))) &&
            ((this.paraStyle==null && other.getParaStyle()==null) || 
             (this.paraStyle!=null &&
              this.paraStyle.equals(other.getParaStyle()))) &&
            ((this.parachar==null && other.getParachar()==null) || 
             (this.parachar!=null &&
              this.parachar.equals(other.getParachar()))) &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText()))) &&
            ((this.rubi==null && other.getRubi()==null) || 
             (this.rubi!=null &&
              java.util.Arrays.equals(this.rubi, other.getRubi()))) &&
            ((this.rules==null && other.getRules()==null) || 
             (this.rules!=null &&
              java.util.Arrays.equals(this.rules, other.getRules()))) &&
            ((this.tabspecs==null && other.getTabspecs()==null) || 
             (this.tabspecs!=null &&
              java.util.Arrays.equals(this.tabspecs, other.getTabspecs())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAnchoredBoxReferences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAnchoredBoxReferences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAnchoredBoxReferences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFauxStyle() != null) {
            _hashCode += getFauxStyle().hashCode();
        }
        if (getFormat() != null) {
            _hashCode += getFormat().hashCode();
        }
        if (getGroupCharacters() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGroupCharacters());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGroupCharacters(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHiddenData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHiddenData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHiddenData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getIndex();
        if (getMerge() != null) {
            _hashCode += getMerge().hashCode();
        }
        if (getParaStyle() != null) {
            _hashCode += getParaStyle().hashCode();
        }
        if (getParachar() != null) {
            _hashCode += getParachar().hashCode();
        }
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRubi() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRubi());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRubi(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRules() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRules());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRules(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTabspecs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTabspecs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTabspecs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Paragraph.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Paragraph"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredBoxReferences");
        elemField.setXmlName(new javax.xml.namespace.QName("", "anchoredBoxReferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AnchoredBoxReference"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fauxStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fauxStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("format");
        elemField.setXmlName(new javax.xml.namespace.QName("", "format"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Format"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupCharacters");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupCharacters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GroupCharacters"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hiddenData");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hiddenData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "HiddenData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("merge");
        elemField.setXmlName(new javax.xml.namespace.QName("", "merge"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paraStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paraStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parachar");
        elemField.setXmlName(new javax.xml.namespace.QName("", "parachar"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RichText"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rubi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rubi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Rubi"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rules");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rules"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Rule"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tabspecs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tabspecs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TabSpec"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
