package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * QXPS GET message for rendering the document as PDF.
 *
 * URL: {baseUrl}/pdf/{documentName}?colorimagedownsample=X&colorcompression=Y&...
 *
 * Cross-reference: .NET QXPS_Message_PDF
 */
@Getter
@Setter
public class PdfRenderMessage implements QxpsMessage {

    private static final String MESSAGE_PATH = "pdf";

    private String colorImageDownSample;
    private String grayscaleImageDownSample;
    private String monochromeImageDownSample;
    private String colorCompression;
    private String grayscaleCompression;
    private String monochromeCompression;

    public PdfRenderMessage() {
    }

    @Override
    public String getCommandPath() {
        return MESSAGE_PATH;
    }

    @Override
    public String getCommandQuery() {
        List<String> args = new ArrayList<>();
        if (colorImageDownSample != null && !colorImageDownSample.isEmpty()) {
            args.add("colorimagedownsample=" + colorImageDownSample);
        }
        if (grayscaleImageDownSample != null && !grayscaleImageDownSample.isEmpty()) {
            args.add("grayscaleimagedownsample=" + grayscaleImageDownSample);
        }
        if (monochromeImageDownSample != null && !monochromeImageDownSample.isEmpty()) {
            args.add("monochromeImagedownSample=" + monochromeImageDownSample);
        }
        if (colorCompression != null && !colorCompression.isEmpty()) {
            args.add("colorcompression=" + colorCompression);
        }
        if (grayscaleCompression != null && !grayscaleCompression.isEmpty()) {
            args.add("grayscalecompression=" + grayscaleCompression);
        }
        if (monochromeCompression != null && !monochromeCompression.isEmpty()) {
            args.add("monochromecompression=" + monochromeCompression);
        }
        return args.isEmpty() ? null : String.join("&", args);
    }

    @Override
    public byte[] getData() {
        return null;
    }

    @Override
    public boolean isPost() {
        return false;
    }
}

