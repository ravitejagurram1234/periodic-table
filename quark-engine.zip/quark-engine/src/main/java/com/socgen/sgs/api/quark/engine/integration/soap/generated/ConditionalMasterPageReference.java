/**
 * ConditionalMasterPageReference.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ConditionalMasterPageReference  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String blankOrNotBlank;

    private java.lang.String name;

    private java.lang.String oddOrEven;

    private java.lang.String position;

    public ConditionalMasterPageReference() {
    }

    public ConditionalMasterPageReference(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String blankOrNotBlank,
           java.lang.String name,
           java.lang.String oddOrEven,
           java.lang.String position) {
        super(
            request);
        this.blankOrNotBlank = blankOrNotBlank;
        this.name = name;
        this.oddOrEven = oddOrEven;
        this.position = position;
    }


    /**
     * Gets the blankOrNotBlank value for this ConditionalMasterPageReference.
     * 
     * @return blankOrNotBlank
     */
    public java.lang.String getBlankOrNotBlank() {
        return blankOrNotBlank;
    }


    /**
     * Sets the blankOrNotBlank value for this ConditionalMasterPageReference.
     * 
     * @param blankOrNotBlank
     */
    public void setBlankOrNotBlank(java.lang.String blankOrNotBlank) {
        this.blankOrNotBlank = blankOrNotBlank;
    }


    /**
     * Gets the name value for this ConditionalMasterPageReference.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this ConditionalMasterPageReference.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the oddOrEven value for this ConditionalMasterPageReference.
     * 
     * @return oddOrEven
     */
    public java.lang.String getOddOrEven() {
        return oddOrEven;
    }


    /**
     * Sets the oddOrEven value for this ConditionalMasterPageReference.
     * 
     * @param oddOrEven
     */
    public void setOddOrEven(java.lang.String oddOrEven) {
        this.oddOrEven = oddOrEven;
    }


    /**
     * Gets the position value for this ConditionalMasterPageReference.
     * 
     * @return position
     */
    public java.lang.String getPosition() {
        return position;
    }


    /**
     * Sets the position value for this ConditionalMasterPageReference.
     * 
     * @param position
     */
    public void setPosition(java.lang.String position) {
        this.position = position;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConditionalMasterPageReference)) return false;
        ConditionalMasterPageReference other = (ConditionalMasterPageReference) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.blankOrNotBlank==null && other.getBlankOrNotBlank()==null) || 
             (this.blankOrNotBlank!=null &&
              this.blankOrNotBlank.equals(other.getBlankOrNotBlank()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.oddOrEven==null && other.getOddOrEven()==null) || 
             (this.oddOrEven!=null &&
              this.oddOrEven.equals(other.getOddOrEven()))) &&
            ((this.position==null && other.getPosition()==null) || 
             (this.position!=null &&
              this.position.equals(other.getPosition())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBlankOrNotBlank() != null) {
            _hashCode += getBlankOrNotBlank().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOddOrEven() != null) {
            _hashCode += getOddOrEven().hashCode();
        }
        if (getPosition() != null) {
            _hashCode += getPosition().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConditionalMasterPageReference.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ConditionalMasterPageReference"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blankOrNotBlank");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blankOrNotBlank"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oddOrEven");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "oddOrEven"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("position");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "position"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
