package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a table-like structure in a dynamic report where elements
 * are positioned relatively to each other.
 *
 * Cross-reference: QXP.Engine.Core.DTable
 */
@Getter
@Setter
public class DTable {

    /** Rows contained in this table. */
    private final List<DRow> rows = new ArrayList<>();

    /** Spatial information for this table. */
    private final DTableInfo info = new DTableInfo();

    /** Whether this table starts on a new page (not used currently). */
    private boolean newPage = false;

    public DTable() {
    }
}