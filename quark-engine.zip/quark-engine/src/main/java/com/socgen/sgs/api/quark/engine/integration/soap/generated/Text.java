/**
 * Text.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Text  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String angle;

    private java.lang.String columns;

    private java.lang.String firstBaseLineMin;

    private java.lang.String flipHorizontal;

    private java.lang.String flipText;

    private java.lang.String flipVertical;

    private java.lang.String gutterWidth;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset;

    private java.lang.String interParagraphMax;

    private java.lang.String offset;

    private java.lang.String runTextAroundAllSides;

    private java.lang.String skew;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Story story;

    private java.lang.String textAlign;

    private java.lang.String textAlignWithLine;

    private java.lang.String textOrientation;

    private java.lang.String verticalAlignment;

    public Text() {
    }

    public Text(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String angle,
           java.lang.String columns,
           java.lang.String firstBaseLineMin,
           java.lang.String flipHorizontal,
           java.lang.String flipText,
           java.lang.String flipVertical,
           java.lang.String gutterWidth,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset,
           java.lang.String interParagraphMax,
           java.lang.String offset,
           java.lang.String runTextAroundAllSides,
           java.lang.String skew,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Story story,
           java.lang.String textAlign,
           java.lang.String textAlignWithLine,
           java.lang.String textOrientation,
           java.lang.String verticalAlignment) {
        super(
            request);
        this.angle = angle;
        this.columns = columns;
        this.firstBaseLineMin = firstBaseLineMin;
        this.flipHorizontal = flipHorizontal;
        this.flipText = flipText;
        this.flipVertical = flipVertical;
        this.gutterWidth = gutterWidth;
        this.index = index;
        this.inset = inset;
        this.interParagraphMax = interParagraphMax;
        this.offset = offset;
        this.runTextAroundAllSides = runTextAroundAllSides;
        this.skew = skew;
        this.story = story;
        this.textAlign = textAlign;
        this.textAlignWithLine = textAlignWithLine;
        this.textOrientation = textOrientation;
        this.verticalAlignment = verticalAlignment;
    }


    /**
     * Gets the angle value for this Text.
     * 
     * @return angle
     */
    public java.lang.String getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this Text.
     * 
     * @param angle
     */
    public void setAngle(java.lang.String angle) {
        this.angle = angle;
    }


    /**
     * Gets the columns value for this Text.
     * 
     * @return columns
     */
    public java.lang.String getColumns() {
        return columns;
    }


    /**
     * Sets the columns value for this Text.
     * 
     * @param columns
     */
    public void setColumns(java.lang.String columns) {
        this.columns = columns;
    }


    /**
     * Gets the firstBaseLineMin value for this Text.
     * 
     * @return firstBaseLineMin
     */
    public java.lang.String getFirstBaseLineMin() {
        return firstBaseLineMin;
    }


    /**
     * Sets the firstBaseLineMin value for this Text.
     * 
     * @param firstBaseLineMin
     */
    public void setFirstBaseLineMin(java.lang.String firstBaseLineMin) {
        this.firstBaseLineMin = firstBaseLineMin;
    }


    /**
     * Gets the flipHorizontal value for this Text.
     * 
     * @return flipHorizontal
     */
    public java.lang.String getFlipHorizontal() {
        return flipHorizontal;
    }


    /**
     * Sets the flipHorizontal value for this Text.
     * 
     * @param flipHorizontal
     */
    public void setFlipHorizontal(java.lang.String flipHorizontal) {
        this.flipHorizontal = flipHorizontal;
    }


    /**
     * Gets the flipText value for this Text.
     * 
     * @return flipText
     */
    public java.lang.String getFlipText() {
        return flipText;
    }


    /**
     * Sets the flipText value for this Text.
     * 
     * @param flipText
     */
    public void setFlipText(java.lang.String flipText) {
        this.flipText = flipText;
    }


    /**
     * Gets the flipVertical value for this Text.
     * 
     * @return flipVertical
     */
    public java.lang.String getFlipVertical() {
        return flipVertical;
    }


    /**
     * Sets the flipVertical value for this Text.
     * 
     * @param flipVertical
     */
    public void setFlipVertical(java.lang.String flipVertical) {
        this.flipVertical = flipVertical;
    }


    /**
     * Gets the gutterWidth value for this Text.
     * 
     * @return gutterWidth
     */
    public java.lang.String getGutterWidth() {
        return gutterWidth;
    }


    /**
     * Sets the gutterWidth value for this Text.
     * 
     * @param gutterWidth
     */
    public void setGutterWidth(java.lang.String gutterWidth) {
        this.gutterWidth = gutterWidth;
    }


    /**
     * Gets the index value for this Text.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this Text.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the inset value for this Text.
     * 
     * @return inset
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset getInset() {
        return inset;
    }


    /**
     * Sets the inset value for this Text.
     * 
     * @param inset
     */
    public void setInset(com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset) {
        this.inset = inset;
    }


    /**
     * Gets the interParagraphMax value for this Text.
     * 
     * @return interParagraphMax
     */
    public java.lang.String getInterParagraphMax() {
        return interParagraphMax;
    }


    /**
     * Sets the interParagraphMax value for this Text.
     * 
     * @param interParagraphMax
     */
    public void setInterParagraphMax(java.lang.String interParagraphMax) {
        this.interParagraphMax = interParagraphMax;
    }


    /**
     * Gets the offset value for this Text.
     * 
     * @return offset
     */
    public java.lang.String getOffset() {
        return offset;
    }


    /**
     * Sets the offset value for this Text.
     * 
     * @param offset
     */
    public void setOffset(java.lang.String offset) {
        this.offset = offset;
    }


    /**
     * Gets the runTextAroundAllSides value for this Text.
     * 
     * @return runTextAroundAllSides
     */
    public java.lang.String getRunTextAroundAllSides() {
        return runTextAroundAllSides;
    }


    /**
     * Sets the runTextAroundAllSides value for this Text.
     * 
     * @param runTextAroundAllSides
     */
    public void setRunTextAroundAllSides(java.lang.String runTextAroundAllSides) {
        this.runTextAroundAllSides = runTextAroundAllSides;
    }


    /**
     * Gets the skew value for this Text.
     * 
     * @return skew
     */
    public java.lang.String getSkew() {
        return skew;
    }


    /**
     * Sets the skew value for this Text.
     * 
     * @param skew
     */
    public void setSkew(java.lang.String skew) {
        this.skew = skew;
    }


    /**
     * Gets the story value for this Text.
     * 
     * @return story
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Story getStory() {
        return story;
    }


    /**
     * Sets the story value for this Text.
     * 
     * @param story
     */
    public void setStory(com.socgen.sgs.api.quark.engine.integration.soap.generated.Story story) {
        this.story = story;
    }


    /**
     * Gets the textAlign value for this Text.
     * 
     * @return textAlign
     */
    public java.lang.String getTextAlign() {
        return textAlign;
    }


    /**
     * Sets the textAlign value for this Text.
     * 
     * @param textAlign
     */
    public void setTextAlign(java.lang.String textAlign) {
        this.textAlign = textAlign;
    }


    /**
     * Gets the textAlignWithLine value for this Text.
     * 
     * @return textAlignWithLine
     */
    public java.lang.String getTextAlignWithLine() {
        return textAlignWithLine;
    }


    /**
     * Sets the textAlignWithLine value for this Text.
     * 
     * @param textAlignWithLine
     */
    public void setTextAlignWithLine(java.lang.String textAlignWithLine) {
        this.textAlignWithLine = textAlignWithLine;
    }


    /**
     * Gets the textOrientation value for this Text.
     * 
     * @return textOrientation
     */
    public java.lang.String getTextOrientation() {
        return textOrientation;
    }


    /**
     * Sets the textOrientation value for this Text.
     * 
     * @param textOrientation
     */
    public void setTextOrientation(java.lang.String textOrientation) {
        this.textOrientation = textOrientation;
    }


    /**
     * Gets the verticalAlignment value for this Text.
     * 
     * @return verticalAlignment
     */
    public java.lang.String getVerticalAlignment() {
        return verticalAlignment;
    }


    /**
     * Sets the verticalAlignment value for this Text.
     * 
     * @param verticalAlignment
     */
    public void setVerticalAlignment(java.lang.String verticalAlignment) {
        this.verticalAlignment = verticalAlignment;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Text)) return false;
        Text other = (Text) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.angle==null && other.getAngle()==null) || 
             (this.angle!=null &&
              this.angle.equals(other.getAngle()))) &&
            ((this.columns==null && other.getColumns()==null) || 
             (this.columns!=null &&
              this.columns.equals(other.getColumns()))) &&
            ((this.firstBaseLineMin==null && other.getFirstBaseLineMin()==null) || 
             (this.firstBaseLineMin!=null &&
              this.firstBaseLineMin.equals(other.getFirstBaseLineMin()))) &&
            ((this.flipHorizontal==null && other.getFlipHorizontal()==null) || 
             (this.flipHorizontal!=null &&
              this.flipHorizontal.equals(other.getFlipHorizontal()))) &&
            ((this.flipText==null && other.getFlipText()==null) || 
             (this.flipText!=null &&
              this.flipText.equals(other.getFlipText()))) &&
            ((this.flipVertical==null && other.getFlipVertical()==null) || 
             (this.flipVertical!=null &&
              this.flipVertical.equals(other.getFlipVertical()))) &&
            ((this.gutterWidth==null && other.getGutterWidth()==null) || 
             (this.gutterWidth!=null &&
              this.gutterWidth.equals(other.getGutterWidth()))) &&
            this.index == other.getIndex() &&
            ((this.inset==null && other.getInset()==null) || 
             (this.inset!=null &&
              this.inset.equals(other.getInset()))) &&
            ((this.interParagraphMax==null && other.getInterParagraphMax()==null) || 
             (this.interParagraphMax!=null &&
              this.interParagraphMax.equals(other.getInterParagraphMax()))) &&
            ((this.offset==null && other.getOffset()==null) || 
             (this.offset!=null &&
              this.offset.equals(other.getOffset()))) &&
            ((this.runTextAroundAllSides==null && other.getRunTextAroundAllSides()==null) || 
             (this.runTextAroundAllSides!=null &&
              this.runTextAroundAllSides.equals(other.getRunTextAroundAllSides()))) &&
            ((this.skew==null && other.getSkew()==null) || 
             (this.skew!=null &&
              this.skew.equals(other.getSkew()))) &&
            ((this.story==null && other.getStory()==null) || 
             (this.story!=null &&
              this.story.equals(other.getStory()))) &&
            ((this.textAlign==null && other.getTextAlign()==null) || 
             (this.textAlign!=null &&
              this.textAlign.equals(other.getTextAlign()))) &&
            ((this.textAlignWithLine==null && other.getTextAlignWithLine()==null) || 
             (this.textAlignWithLine!=null &&
              this.textAlignWithLine.equals(other.getTextAlignWithLine()))) &&
            ((this.textOrientation==null && other.getTextOrientation()==null) || 
             (this.textOrientation!=null &&
              this.textOrientation.equals(other.getTextOrientation()))) &&
            ((this.verticalAlignment==null && other.getVerticalAlignment()==null) || 
             (this.verticalAlignment!=null &&
              this.verticalAlignment.equals(other.getVerticalAlignment())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAngle() != null) {
            _hashCode += getAngle().hashCode();
        }
        if (getColumns() != null) {
            _hashCode += getColumns().hashCode();
        }
        if (getFirstBaseLineMin() != null) {
            _hashCode += getFirstBaseLineMin().hashCode();
        }
        if (getFlipHorizontal() != null) {
            _hashCode += getFlipHorizontal().hashCode();
        }
        if (getFlipText() != null) {
            _hashCode += getFlipText().hashCode();
        }
        if (getFlipVertical() != null) {
            _hashCode += getFlipVertical().hashCode();
        }
        if (getGutterWidth() != null) {
            _hashCode += getGutterWidth().hashCode();
        }
        _hashCode += getIndex();
        if (getInset() != null) {
            _hashCode += getInset().hashCode();
        }
        if (getInterParagraphMax() != null) {
            _hashCode += getInterParagraphMax().hashCode();
        }
        if (getOffset() != null) {
            _hashCode += getOffset().hashCode();
        }
        if (getRunTextAroundAllSides() != null) {
            _hashCode += getRunTextAroundAllSides().hashCode();
        }
        if (getSkew() != null) {
            _hashCode += getSkew().hashCode();
        }
        if (getStory() != null) {
            _hashCode += getStory().hashCode();
        }
        if (getTextAlign() != null) {
            _hashCode += getTextAlign().hashCode();
        }
        if (getTextAlignWithLine() != null) {
            _hashCode += getTextAlignWithLine().hashCode();
        }
        if (getTextOrientation() != null) {
            _hashCode += getTextOrientation().hashCode();
        }
        if (getVerticalAlignment() != null) {
            _hashCode += getVerticalAlignment().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Text.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Text"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("angle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "angle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columns");
        elemField.setXmlName(new javax.xml.namespace.QName("", "columns"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstBaseLineMin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "firstBaseLineMin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flipHorizontal");
        elemField.setXmlName(new javax.xml.namespace.QName("", "flipHorizontal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flipText");
        elemField.setXmlName(new javax.xml.namespace.QName("", "flipText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flipVertical");
        elemField.setXmlName(new javax.xml.namespace.QName("", "flipVertical"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gutterWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("", "gutterWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inset");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Inset"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interParagraphMax");
        elemField.setXmlName(new javax.xml.namespace.QName("", "interParagraphMax"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offset");
        elemField.setXmlName(new javax.xml.namespace.QName("", "offset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("runTextAroundAllSides");
        elemField.setXmlName(new javax.xml.namespace.QName("", "runTextAroundAllSides"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("skew");
        elemField.setXmlName(new javax.xml.namespace.QName("", "skew"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("story");
        elemField.setXmlName(new javax.xml.namespace.QName("", "story"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Story"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textAlign");
        elemField.setXmlName(new javax.xml.namespace.QName("", "textAlign"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textAlignWithLine");
        elemField.setXmlName(new javax.xml.namespace.QName("", "textAlignWithLine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textOrientation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "textOrientation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verticalAlignment");
        elemField.setXmlName(new javax.xml.namespace.QName("", "verticalAlignment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
