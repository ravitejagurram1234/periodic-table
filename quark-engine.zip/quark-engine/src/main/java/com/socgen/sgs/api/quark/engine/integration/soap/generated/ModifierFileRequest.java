/**
 * ModifierFileRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ModifierFileRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String annotateErrors;

    private java.lang.String appendErrors;

    private java.lang.String file;

    private java.lang.String insertErrorPageAtLast;

    private java.lang.String suppressErrors;

    public ModifierFileRequest() {
    }

    public ModifierFileRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String annotateErrors,
           java.lang.String appendErrors,
           java.lang.String file,
           java.lang.String insertErrorPageAtLast,
           java.lang.String suppressErrors) {
        super(
            request);
        this.annotateErrors = annotateErrors;
        this.appendErrors = appendErrors;
        this.file = file;
        this.insertErrorPageAtLast = insertErrorPageAtLast;
        this.suppressErrors = suppressErrors;
    }


    /**
     * Gets the annotateErrors value for this ModifierFileRequest.
     * 
     * @return annotateErrors
     */
    public java.lang.String getAnnotateErrors() {
        return annotateErrors;
    }


    /**
     * Sets the annotateErrors value for this ModifierFileRequest.
     * 
     * @param annotateErrors
     */
    public void setAnnotateErrors(java.lang.String annotateErrors) {
        this.annotateErrors = annotateErrors;
    }


    /**
     * Gets the appendErrors value for this ModifierFileRequest.
     * 
     * @return appendErrors
     */
    public java.lang.String getAppendErrors() {
        return appendErrors;
    }


    /**
     * Sets the appendErrors value for this ModifierFileRequest.
     * 
     * @param appendErrors
     */
    public void setAppendErrors(java.lang.String appendErrors) {
        this.appendErrors = appendErrors;
    }


    /**
     * Gets the file value for this ModifierFileRequest.
     * 
     * @return file
     */
    public java.lang.String getFile() {
        return file;
    }


    /**
     * Sets the file value for this ModifierFileRequest.
     * 
     * @param file
     */
    public void setFile(java.lang.String file) {
        this.file = file;
    }


    /**
     * Gets the insertErrorPageAtLast value for this ModifierFileRequest.
     * 
     * @return insertErrorPageAtLast
     */
    public java.lang.String getInsertErrorPageAtLast() {
        return insertErrorPageAtLast;
    }


    /**
     * Sets the insertErrorPageAtLast value for this ModifierFileRequest.
     * 
     * @param insertErrorPageAtLast
     */
    public void setInsertErrorPageAtLast(java.lang.String insertErrorPageAtLast) {
        this.insertErrorPageAtLast = insertErrorPageAtLast;
    }


    /**
     * Gets the suppressErrors value for this ModifierFileRequest.
     * 
     * @return suppressErrors
     */
    public java.lang.String getSuppressErrors() {
        return suppressErrors;
    }


    /**
     * Sets the suppressErrors value for this ModifierFileRequest.
     * 
     * @param suppressErrors
     */
    public void setSuppressErrors(java.lang.String suppressErrors) {
        this.suppressErrors = suppressErrors;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ModifierFileRequest)) return false;
        ModifierFileRequest other = (ModifierFileRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.annotateErrors==null && other.getAnnotateErrors()==null) || 
             (this.annotateErrors!=null &&
              this.annotateErrors.equals(other.getAnnotateErrors()))) &&
            ((this.appendErrors==null && other.getAppendErrors()==null) || 
             (this.appendErrors!=null &&
              this.appendErrors.equals(other.getAppendErrors()))) &&
            ((this.file==null && other.getFile()==null) || 
             (this.file!=null &&
              this.file.equals(other.getFile()))) &&
            ((this.insertErrorPageAtLast==null && other.getInsertErrorPageAtLast()==null) || 
             (this.insertErrorPageAtLast!=null &&
              this.insertErrorPageAtLast.equals(other.getInsertErrorPageAtLast()))) &&
            ((this.suppressErrors==null && other.getSuppressErrors()==null) || 
             (this.suppressErrors!=null &&
              this.suppressErrors.equals(other.getSuppressErrors())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAnnotateErrors() != null) {
            _hashCode += getAnnotateErrors().hashCode();
        }
        if (getAppendErrors() != null) {
            _hashCode += getAppendErrors().hashCode();
        }
        if (getFile() != null) {
            _hashCode += getFile().hashCode();
        }
        if (getInsertErrorPageAtLast() != null) {
            _hashCode += getInsertErrorPageAtLast().hashCode();
        }
        if (getSuppressErrors() != null) {
            _hashCode += getSuppressErrors().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ModifierFileRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ModifierFileRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("annotateErrors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "annotateErrors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appendErrors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "appendErrors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "file"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insertErrorPageAtLast");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "insertErrorPageAtLast"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppressErrors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "suppressErrors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
