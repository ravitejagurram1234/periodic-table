/**
 * GroupCharacters.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class GroupCharacters  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    private java.lang.String scaleAmount;

    private java.lang.String scaleDirection;

    private java.lang.String sending;

    private java.lang.String trackAmount;

    public GroupCharacters() {
    }

    public GroupCharacters(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText,
           java.lang.String scaleAmount,
           java.lang.String scaleDirection,
           java.lang.String sending,
           java.lang.String trackAmount) {
        super(
            request);
        this.hiddenData = hiddenData;
        this.index = index;
        this.richText = richText;
        this.scaleAmount = scaleAmount;
        this.scaleDirection = scaleDirection;
        this.sending = sending;
        this.trackAmount = trackAmount;
    }


    /**
     * Gets the hiddenData value for this GroupCharacters.
     * 
     * @return hiddenData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] getHiddenData() {
        return hiddenData;
    }


    /**
     * Sets the hiddenData value for this GroupCharacters.
     * 
     * @param hiddenData
     */
    public void setHiddenData(com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData) {
        this.hiddenData = hiddenData;
    }


    /**
     * Gets the index value for this GroupCharacters.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this GroupCharacters.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the richText value for this GroupCharacters.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this GroupCharacters.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }


    /**
     * Gets the scaleAmount value for this GroupCharacters.
     * 
     * @return scaleAmount
     */
    public java.lang.String getScaleAmount() {
        return scaleAmount;
    }


    /**
     * Sets the scaleAmount value for this GroupCharacters.
     * 
     * @param scaleAmount
     */
    public void setScaleAmount(java.lang.String scaleAmount) {
        this.scaleAmount = scaleAmount;
    }


    /**
     * Gets the scaleDirection value for this GroupCharacters.
     * 
     * @return scaleDirection
     */
    public java.lang.String getScaleDirection() {
        return scaleDirection;
    }


    /**
     * Sets the scaleDirection value for this GroupCharacters.
     * 
     * @param scaleDirection
     */
    public void setScaleDirection(java.lang.String scaleDirection) {
        this.scaleDirection = scaleDirection;
    }


    /**
     * Gets the sending value for this GroupCharacters.
     * 
     * @return sending
     */
    public java.lang.String getSending() {
        return sending;
    }


    /**
     * Sets the sending value for this GroupCharacters.
     * 
     * @param sending
     */
    public void setSending(java.lang.String sending) {
        this.sending = sending;
    }


    /**
     * Gets the trackAmount value for this GroupCharacters.
     * 
     * @return trackAmount
     */
    public java.lang.String getTrackAmount() {
        return trackAmount;
    }


    /**
     * Sets the trackAmount value for this GroupCharacters.
     * 
     * @param trackAmount
     */
    public void setTrackAmount(java.lang.String trackAmount) {
        this.trackAmount = trackAmount;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GroupCharacters)) return false;
        GroupCharacters other = (GroupCharacters) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.hiddenData==null && other.getHiddenData()==null) || 
             (this.hiddenData!=null &&
              java.util.Arrays.equals(this.hiddenData, other.getHiddenData()))) &&
            this.index == other.getIndex() &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText()))) &&
            ((this.scaleAmount==null && other.getScaleAmount()==null) || 
             (this.scaleAmount!=null &&
              this.scaleAmount.equals(other.getScaleAmount()))) &&
            ((this.scaleDirection==null && other.getScaleDirection()==null) || 
             (this.scaleDirection!=null &&
              this.scaleDirection.equals(other.getScaleDirection()))) &&
            ((this.sending==null && other.getSending()==null) || 
             (this.sending!=null &&
              this.sending.equals(other.getSending()))) &&
            ((this.trackAmount==null && other.getTrackAmount()==null) || 
             (this.trackAmount!=null &&
              this.trackAmount.equals(other.getTrackAmount())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getHiddenData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHiddenData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHiddenData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getIndex();
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getScaleAmount() != null) {
            _hashCode += getScaleAmount().hashCode();
        }
        if (getScaleDirection() != null) {
            _hashCode += getScaleDirection().hashCode();
        }
        if (getSending() != null) {
            _hashCode += getSending().hashCode();
        }
        if (getTrackAmount() != null) {
            _hashCode += getTrackAmount().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GroupCharacters.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "GroupCharacters"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hiddenData");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hiddenData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "HiddenData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RichText"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "scaleAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleDirection");
        elemField.setXmlName(new javax.xml.namespace.QName("", "scaleDirection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sending");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sending"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trackAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "trackAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
