/**
 * AuthenticationPreferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class AuthenticationPreferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String confirmPassword;

    private java.lang.String requireAdminVerification;

    private java.lang.String verificationPassword;

    private java.lang.String verificationUsername;

    public AuthenticationPreferences() {
    }

    public AuthenticationPreferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String confirmPassword,
           java.lang.String requireAdminVerification,
           java.lang.String verificationPassword,
           java.lang.String verificationUsername) {
        super(
            request);
        this.confirmPassword = confirmPassword;
        this.requireAdminVerification = requireAdminVerification;
        this.verificationPassword = verificationPassword;
        this.verificationUsername = verificationUsername;
    }


    /**
     * Gets the confirmPassword value for this AuthenticationPreferences.
     * 
     * @return confirmPassword
     */
    public java.lang.String getConfirmPassword() {
        return confirmPassword;
    }


    /**
     * Sets the confirmPassword value for this AuthenticationPreferences.
     * 
     * @param confirmPassword
     */
    public void setConfirmPassword(java.lang.String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }


    /**
     * Gets the requireAdminVerification value for this AuthenticationPreferences.
     * 
     * @return requireAdminVerification
     */
    public java.lang.String getRequireAdminVerification() {
        return requireAdminVerification;
    }


    /**
     * Sets the requireAdminVerification value for this AuthenticationPreferences.
     * 
     * @param requireAdminVerification
     */
    public void setRequireAdminVerification(java.lang.String requireAdminVerification) {
        this.requireAdminVerification = requireAdminVerification;
    }


    /**
     * Gets the verificationPassword value for this AuthenticationPreferences.
     * 
     * @return verificationPassword
     */
    public java.lang.String getVerificationPassword() {
        return verificationPassword;
    }


    /**
     * Sets the verificationPassword value for this AuthenticationPreferences.
     * 
     * @param verificationPassword
     */
    public void setVerificationPassword(java.lang.String verificationPassword) {
        this.verificationPassword = verificationPassword;
    }


    /**
     * Gets the verificationUsername value for this AuthenticationPreferences.
     * 
     * @return verificationUsername
     */
    public java.lang.String getVerificationUsername() {
        return verificationUsername;
    }


    /**
     * Sets the verificationUsername value for this AuthenticationPreferences.
     * 
     * @param verificationUsername
     */
    public void setVerificationUsername(java.lang.String verificationUsername) {
        this.verificationUsername = verificationUsername;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AuthenticationPreferences)) return false;
        AuthenticationPreferences other = (AuthenticationPreferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.confirmPassword==null && other.getConfirmPassword()==null) || 
             (this.confirmPassword!=null &&
              this.confirmPassword.equals(other.getConfirmPassword()))) &&
            ((this.requireAdminVerification==null && other.getRequireAdminVerification()==null) || 
             (this.requireAdminVerification!=null &&
              this.requireAdminVerification.equals(other.getRequireAdminVerification()))) &&
            ((this.verificationPassword==null && other.getVerificationPassword()==null) || 
             (this.verificationPassword!=null &&
              this.verificationPassword.equals(other.getVerificationPassword()))) &&
            ((this.verificationUsername==null && other.getVerificationUsername()==null) || 
             (this.verificationUsername!=null &&
              this.verificationUsername.equals(other.getVerificationUsername())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getConfirmPassword() != null) {
            _hashCode += getConfirmPassword().hashCode();
        }
        if (getRequireAdminVerification() != null) {
            _hashCode += getRequireAdminVerification().hashCode();
        }
        if (getVerificationPassword() != null) {
            _hashCode += getVerificationPassword().hashCode();
        }
        if (getVerificationUsername() != null) {
            _hashCode += getVerificationUsername().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AuthenticationPreferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AuthenticationPreferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("confirmPassword");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "confirmPassword"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requireAdminVerification");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "requireAdminVerification"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verificationPassword");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "verificationPassword"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verificationUsername");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "verificationUsername"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
