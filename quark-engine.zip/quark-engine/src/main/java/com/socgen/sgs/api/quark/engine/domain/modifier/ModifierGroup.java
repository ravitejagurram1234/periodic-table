package com.socgen.sgs.api.quark.engine.domain.modifier;

import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import lombok.Getter;
import lombok.Setter;

/**
 * Represents a group of boxes in a modifier project hierarchy.
 *
 * Cross-reference: QXP.Engine.Core.Group (Modifier namespace)
 */
@Getter
@Setter
public class ModifierGroup {

    private String uid;
    private String name;
    private Box[] srcBoxes;
    private int pageId;
    private BlocActionEnum action = BlocActionEnum.NONE;

    public ModifierGroup() {
    }
}