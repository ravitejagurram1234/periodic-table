package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.domain.RunError;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBase;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DBlocInfo;
import com.socgen.sgs.api.quark.engine.domain.element.TBox;
import com.socgen.sgs.api.quark.engine.domain.helper.DocumentIdentityHelper;
import com.socgen.sgs.api.quark.engine.domain.helper.TElementHelper;
import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.domain.task.TaskDid;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.enums.StaticTElementNameEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import com.socgen.sgs.api.quark.engine.service.task.TaskPostProcessStrategy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * DID post-processing — chooses MOVE vs NAME_VALUE mode, builds the DID identity, and produces
 * the DID bloc by routing through the standard system bloc-creation path.
 *
 * <p>Cross-reference: .NET {@code Task_DID.PostProcess()} → {@code Business.Process_System.Process(this)}.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DidTaskPostProcessStrategy implements TaskPostProcessStrategy<TaskDid> {

    private static final String DID_BLOC_NAME = "DID";
    /** RunError categories: 1=Bloquante, 2=Critique, 3=Warning. */
    private static final int CRITIQUE = 2;

    /** Reused to actually create the bloc, exactly like .NET delegates to Process_System. */
    private final SystemTaskProcessStrategy systemTaskProcessStrategy;

    @Override
    public Class<TaskDid> getTaskType() {
        return TaskDid.class;
    }

    @Override
    public void postProcess(TaskDid task) {
        // 1. Choose update mode.
        // If any task produced a paginated modify bloc (page create/remove) it may shift the DID's
        // position, so the DID is repositioned + revalued via MOVE; otherwise just its value changes.
        // Cross-reference: .NET Task_DID.PostProcess() mode selection.
        boolean modifier = false;
        modeSelection:
        for (TaskBase other : task.getRun().getTasks().values()) {
            for (BlocBase bloc : other.getBlocsModify().values()) {
                if (bloc.isPagination()) {
                    modifier = true;
                    break modeSelection;
                }
            }
        }

        // 2. Build the new identity value.
        String didValue = DocumentIdentityHelper.getNewIdentity(task.getRun());
        log.debug("New DID identity for run [{}]: {}", task.getRun().getId(), didValue);

        if (modifier) {
            // MOVE mode — keep the DID box on the page where it currently is, with the new value.
            task.setAction(BlocActionEnum.MOVE);
            task.setPagination(true);

            DBlocInfo didInfo = task.getRun().getGabarit().getQxpXml().getBlocInfo(DID_BLOC_NAME);

            // A box with no UID does not exist (every Quark box, even unnamed, has a UID).
            if (didInfo == null || didInfo.getUid() == null || didInfo.getUid().isBlank()) {
                task.getRun().getErrors().add(new RunError(CRITIQUE,
                        "DID introuvable dans le document (UID manquant) pour le bloc " + DID_BLOC_NAME));
                log.warn("Missing DID box (no UID) for run [{}] — DID not updated", task.getRun().getId());
                return;
            }

            // To move a box, QuarkXPress needs at least its position + UID (the page is set later in
            // the modifier). Cross-reference: .NET TElement_Helper.Get_TElement(MOVE_BLOC_VALUE, dest).
            TBox tBox = (TBox) TElementHelper.getTElement(
                    StaticTElementNameEnum.MOVE_BLOC_VALUE, task.getDestinationBlocName());
            Box box = tBox.getSrcBox();
            box.getGeometry().getPosition().setLeft(didInfo.getLeft().toString());
            box.getGeometry().getPosition().setTop(didInfo.getTop().toString());
            box.getGeometry().getPosition().setRight(didInfo.getRight().toString());
            box.getGeometry().getPosition().setBottom(didInfo.getBottom().toString());
            box.setUID(didInfo.getUid());
            box.getContent().setValue(didValue);

            // Drives SystemTaskProcessStrategy BOX mode → a MOVE bloc in blocsModify.
            task.setTBoxSrcBox(box);
            log.info("DID update mode: MOVE for run [{}]", task.getRun().getId());

        } else {
            // NAME_VALUE mode — update the DID value only.
            String didUid = task.getRun().getGabarit().getQxpXml().getUID(DID_BLOC_NAME);
            if (didUid == null || didUid.isBlank()) {
                task.getRun().getErrors().add(new RunError(CRITIQUE,
                        "DID introuvable dans le document (UID manquant) pour le bloc " + DID_BLOC_NAME));
                log.warn("Missing DID box (no UID) for run [{}] — DID not updated", task.getRun().getId());
                return;
            }
            // tBoxSrcBox stays null → SystemTaskProcessStrategy VALUE mode → an UPDATE bloc in blocsUpdate.
            task.setValue(didValue);
            log.info("DID update mode: NAME_VALUE for run [{}]", task.getRun().getId());
        }

        // 3. Create the actual bloc as a standard system task.
        // Cross-reference: .NET Task_DID.PostProcess() → Business.Process_System.Process(this).
        systemTaskProcessStrategy.process(task);

        log.info("DID task post-process completed for run [{}]", task.getRun().getId());
    }
}