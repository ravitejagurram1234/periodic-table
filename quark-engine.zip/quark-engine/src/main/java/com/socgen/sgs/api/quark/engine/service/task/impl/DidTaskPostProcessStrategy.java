package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.domain.task.TaskDid;
import com.socgen.sgs.api.quark.engine.service.task.TaskPostProcessStrategy;
import org.springframework.stereotype.Component;

/** DID post-processing: determines MOVE vs NAME_VALUE mode and builds the DID bloc. */
@Component
public class DidTaskPostProcessStrategy implements TaskPostProcessStrategy<TaskDid> {

    @Override
    public Class<TaskDid> getTaskType() {
        return TaskDid.class;
    }

    @Override
    public void postProcess(TaskDid task) {
        task.executePostProcess();
    }
}

