package com.socgen.sgs.api.quark.engine.domain;

import lombok.Getter;

/**
 * Represents an error that occurred during run execution.
 *
 * Cross-reference: .NET Error (Type + Message)
 */
@Getter
public class RunError {

    /**
     * Error severity codes, matching .NET {@code Error_Type} EXACTLY (these are persisted to the DB
     * via {@code QXP_PK_RUN.Insert_Run_Errors}, so the numeric value is load-bearing):
     * <ul>
     *   <li>{@link #UNSPECIFIED} = 1 — Non spécifiée</li>
     *   <li>{@link #CRITIQUE} = 2 — Critique (interrupts the current task)</li>
     *   <li>{@link #BLOQUANTE} = 3 — Bloquante (interrupts the whole run)</li>
     * </ul>
     */
    public static final int UNSPECIFIED = 1;
    public static final int CRITIQUE = 2;
    public static final int BLOQUANTE = 3;

    /** Severity code — see {@link #UNSPECIFIED}/{@link #CRITIQUE}/{@link #BLOQUANTE}. */
    private final int category;
    private final String message;

    public RunError(int category, String message) {
        this.category = category;
        this.message = message != null && !message.isBlank() ? message : "aucun";
    }
}