package com.socgen.sgs.api.quark.engine.domain;

import lombok.Getter;

/**
 * Represents an error that occurred during run execution.
 *
 * Cross-reference: .NET Error (Type + Message)
 */
@Getter
public class RunError {

    /** 1=Bloquante, 2=Critique, 3=Warning */
    private final int category;
    private final String message;

    public RunError(int category, String message) {
        this.category = category;
        this.message = message != null && !message.isBlank() ? message : "aucun";
    }
}