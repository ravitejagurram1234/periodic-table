package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.project.QxpProject;
import com.socgen.sgs.api.quark.engine.infra.interop.qxpsm.QxpsmSoapClient;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Project;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Bridge for fetching a pooled document's QuarkXPress DOM (project) via QXPSM getXPressDOM
 * (service → business → infra). Used by compartiment incorporation to read a child run's
 * generated QXP structure.
 *
 * <p>Cross-reference: .NET Document.QXPProject (lazy QXPS_File_Manager.Get_Project).
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class GetDocumentProjectBusiness {

    private final QxpsmSoapClient qxpsmSoapClient;

    /**
     * Fetch the QXP project (DOM) of a pooled document. Returns {@link QxpProject#EMPTY} when the
     * document has no project or the call fails (so the caller can report an empty-child error).
     *
     * @param documentName the pool path / document name
     * @return the parsed QxpProject, or QxpProject.EMPTY
     */
    public QxpProject getProject(String documentName) {
        try {
            Project project = qxpsmSoapClient.getProject(documentName);
            return project != null ? new QxpProject(project) : QxpProject.EMPTY;
        } catch (Exception e) {
            log.error("Failed to get project for document [{}]: {}", documentName, e.getMessage(), e);
            return QxpProject.EMPTY;
        }
    }
}