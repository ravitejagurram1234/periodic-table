/**
 * Content.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Content  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String boundingBox;

    private java.lang.String convertQuotes;

    private java.lang.String fontName;

    private java.lang.String includeStyleSheets;

    private int index;

    private java.lang.String pageToImport;

    private java.lang.String value;

    public Content() {
    }

    public Content(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String boundingBox,
           java.lang.String convertQuotes,
           java.lang.String fontName,
           java.lang.String includeStyleSheets,
           int index,
           java.lang.String pageToImport,
           java.lang.String value) {
        super(
            request);
        this.boundingBox = boundingBox;
        this.convertQuotes = convertQuotes;
        this.fontName = fontName;
        this.includeStyleSheets = includeStyleSheets;
        this.index = index;
        this.pageToImport = pageToImport;
        this.value = value;
    }


    /**
     * Gets the boundingBox value for this Content.
     * 
     * @return boundingBox
     */
    public java.lang.String getBoundingBox() {
        return boundingBox;
    }


    /**
     * Sets the boundingBox value for this Content.
     * 
     * @param boundingBox
     */
    public void setBoundingBox(java.lang.String boundingBox) {
        this.boundingBox = boundingBox;
    }


    /**
     * Gets the convertQuotes value for this Content.
     * 
     * @return convertQuotes
     */
    public java.lang.String getConvertQuotes() {
        return convertQuotes;
    }


    /**
     * Sets the convertQuotes value for this Content.
     * 
     * @param convertQuotes
     */
    public void setConvertQuotes(java.lang.String convertQuotes) {
        this.convertQuotes = convertQuotes;
    }


    /**
     * Gets the fontName value for this Content.
     * 
     * @return fontName
     */
    public java.lang.String getFontName() {
        return fontName;
    }


    /**
     * Sets the fontName value for this Content.
     * 
     * @param fontName
     */
    public void setFontName(java.lang.String fontName) {
        this.fontName = fontName;
    }


    /**
     * Gets the includeStyleSheets value for this Content.
     * 
     * @return includeStyleSheets
     */
    public java.lang.String getIncludeStyleSheets() {
        return includeStyleSheets;
    }


    /**
     * Sets the includeStyleSheets value for this Content.
     * 
     * @param includeStyleSheets
     */
    public void setIncludeStyleSheets(java.lang.String includeStyleSheets) {
        this.includeStyleSheets = includeStyleSheets;
    }


    /**
     * Gets the index value for this Content.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this Content.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the pageToImport value for this Content.
     * 
     * @return pageToImport
     */
    public java.lang.String getPageToImport() {
        return pageToImport;
    }


    /**
     * Sets the pageToImport value for this Content.
     * 
     * @param pageToImport
     */
    public void setPageToImport(java.lang.String pageToImport) {
        this.pageToImport = pageToImport;
    }


    /**
     * Gets the value value for this Content.
     * 
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }


    /**
     * Sets the value value for this Content.
     * 
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Content)) return false;
        Content other = (Content) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.boundingBox==null && other.getBoundingBox()==null) || 
             (this.boundingBox!=null &&
              this.boundingBox.equals(other.getBoundingBox()))) &&
            ((this.convertQuotes==null && other.getConvertQuotes()==null) || 
             (this.convertQuotes!=null &&
              this.convertQuotes.equals(other.getConvertQuotes()))) &&
            ((this.fontName==null && other.getFontName()==null) || 
             (this.fontName!=null &&
              this.fontName.equals(other.getFontName()))) &&
            ((this.includeStyleSheets==null && other.getIncludeStyleSheets()==null) || 
             (this.includeStyleSheets!=null &&
              this.includeStyleSheets.equals(other.getIncludeStyleSheets()))) &&
            this.index == other.getIndex() &&
            ((this.pageToImport==null && other.getPageToImport()==null) || 
             (this.pageToImport!=null &&
              this.pageToImport.equals(other.getPageToImport()))) &&
            ((this.value==null && other.getValue()==null) || 
             (this.value!=null &&
              this.value.equals(other.getValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBoundingBox() != null) {
            _hashCode += getBoundingBox().hashCode();
        }
        if (getConvertQuotes() != null) {
            _hashCode += getConvertQuotes().hashCode();
        }
        if (getFontName() != null) {
            _hashCode += getFontName().hashCode();
        }
        if (getIncludeStyleSheets() != null) {
            _hashCode += getIncludeStyleSheets().hashCode();
        }
        _hashCode += getIndex();
        if (getPageToImport() != null) {
            _hashCode += getPageToImport().hashCode();
        }
        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Content.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Content"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boundingBox");
        elemField.setXmlName(new javax.xml.namespace.QName("", "boundingBox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("convertQuotes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "convertQuotes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fontName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fontName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeStyleSheets");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeStyleSheets"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageToImport");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pageToImport"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("", "value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
