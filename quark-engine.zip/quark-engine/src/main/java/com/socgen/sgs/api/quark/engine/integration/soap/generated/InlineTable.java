/**
 * InlineTable.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class InlineTable  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String blendMode;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border;

    private java.lang.String breakRowAcrossPages;

    private java.lang.String breakable;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ColGroup colGroup;

    private java.lang.String color;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Excel excel;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData;

    private java.lang.String offset;

    private java.lang.String opacity;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround runaround;

    private java.lang.String shade;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow;

    private java.lang.String span;

    private java.lang.String tableStyleRef;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TBody tbody;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TFoot tfoot;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.THead thead;

    private java.lang.String width;

    public InlineTable() {
    }

    public InlineTable(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String blendMode,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border,
           java.lang.String breakRowAcrossPages,
           java.lang.String breakable,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ColGroup colGroup,
           java.lang.String color,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Excel excel,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData,
           java.lang.String offset,
           java.lang.String opacity,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround runaround,
           java.lang.String shade,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow,
           java.lang.String span,
           java.lang.String tableStyleRef,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TBody tbody,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TFoot tfoot,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.THead thead,
           java.lang.String width) {
        super(
            request);
        this.blendMode = blendMode;
        this.border = border;
        this.breakRowAcrossPages = breakRowAcrossPages;
        this.breakable = breakable;
        this.colGroup = colGroup;
        this.color = color;
        this.excel = excel;
        this.frame = frame;
        this.index = index;
        this.metaData = metaData;
        this.offset = offset;
        this.opacity = opacity;
        this.runaround = runaround;
        this.shade = shade;
        this.shadow = shadow;
        this.span = span;
        this.tableStyleRef = tableStyleRef;
        this.tbody = tbody;
        this.tfoot = tfoot;
        this.thead = thead;
        this.width = width;
    }


    /**
     * Gets the blendMode value for this InlineTable.
     * 
     * @return blendMode
     */
    public java.lang.String getBlendMode() {
        return blendMode;
    }


    /**
     * Sets the blendMode value for this InlineTable.
     * 
     * @param blendMode
     */
    public void setBlendMode(java.lang.String blendMode) {
        this.blendMode = blendMode;
    }


    /**
     * Gets the border value for this InlineTable.
     * 
     * @return border
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Border getBorder() {
        return border;
    }


    /**
     * Sets the border value for this InlineTable.
     * 
     * @param border
     */
    public void setBorder(com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border) {
        this.border = border;
    }


    /**
     * Gets the breakRowAcrossPages value for this InlineTable.
     * 
     * @return breakRowAcrossPages
     */
    public java.lang.String getBreakRowAcrossPages() {
        return breakRowAcrossPages;
    }


    /**
     * Sets the breakRowAcrossPages value for this InlineTable.
     * 
     * @param breakRowAcrossPages
     */
    public void setBreakRowAcrossPages(java.lang.String breakRowAcrossPages) {
        this.breakRowAcrossPages = breakRowAcrossPages;
    }


    /**
     * Gets the breakable value for this InlineTable.
     * 
     * @return breakable
     */
    public java.lang.String getBreakable() {
        return breakable;
    }


    /**
     * Sets the breakable value for this InlineTable.
     * 
     * @param breakable
     */
    public void setBreakable(java.lang.String breakable) {
        this.breakable = breakable;
    }


    /**
     * Gets the colGroup value for this InlineTable.
     * 
     * @return colGroup
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ColGroup getColGroup() {
        return colGroup;
    }


    /**
     * Sets the colGroup value for this InlineTable.
     * 
     * @param colGroup
     */
    public void setColGroup(com.socgen.sgs.api.quark.engine.integration.soap.generated.ColGroup colGroup) {
        this.colGroup = colGroup;
    }


    /**
     * Gets the color value for this InlineTable.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this InlineTable.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the excel value for this InlineTable.
     * 
     * @return excel
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Excel getExcel() {
        return excel;
    }


    /**
     * Sets the excel value for this InlineTable.
     * 
     * @param excel
     */
    public void setExcel(com.socgen.sgs.api.quark.engine.integration.soap.generated.Excel excel) {
        this.excel = excel;
    }


    /**
     * Gets the frame value for this InlineTable.
     * 
     * @return frame
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame getFrame() {
        return frame;
    }


    /**
     * Sets the frame value for this InlineTable.
     * 
     * @param frame
     */
    public void setFrame(com.socgen.sgs.api.quark.engine.integration.soap.generated.Frame frame) {
        this.frame = frame;
    }


    /**
     * Gets the index value for this InlineTable.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this InlineTable.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the metaData value for this InlineTable.
     * 
     * @return metaData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData getMetaData() {
        return metaData;
    }


    /**
     * Sets the metaData value for this InlineTable.
     * 
     * @param metaData
     */
    public void setMetaData(com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData) {
        this.metaData = metaData;
    }


    /**
     * Gets the offset value for this InlineTable.
     * 
     * @return offset
     */
    public java.lang.String getOffset() {
        return offset;
    }


    /**
     * Sets the offset value for this InlineTable.
     * 
     * @param offset
     */
    public void setOffset(java.lang.String offset) {
        this.offset = offset;
    }


    /**
     * Gets the opacity value for this InlineTable.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this InlineTable.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the runaround value for this InlineTable.
     * 
     * @return runaround
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround getRunaround() {
        return runaround;
    }


    /**
     * Sets the runaround value for this InlineTable.
     * 
     * @param runaround
     */
    public void setRunaround(com.socgen.sgs.api.quark.engine.integration.soap.generated.Runaround runaround) {
        this.runaround = runaround;
    }


    /**
     * Gets the shade value for this InlineTable.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this InlineTable.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the shadow value for this InlineTable.
     * 
     * @return shadow
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow getShadow() {
        return shadow;
    }


    /**
     * Sets the shadow value for this InlineTable.
     * 
     * @param shadow
     */
    public void setShadow(com.socgen.sgs.api.quark.engine.integration.soap.generated.Shadow shadow) {
        this.shadow = shadow;
    }


    /**
     * Gets the span value for this InlineTable.
     * 
     * @return span
     */
    public java.lang.String getSpan() {
        return span;
    }


    /**
     * Sets the span value for this InlineTable.
     * 
     * @param span
     */
    public void setSpan(java.lang.String span) {
        this.span = span;
    }


    /**
     * Gets the tableStyleRef value for this InlineTable.
     * 
     * @return tableStyleRef
     */
    public java.lang.String getTableStyleRef() {
        return tableStyleRef;
    }


    /**
     * Sets the tableStyleRef value for this InlineTable.
     * 
     * @param tableStyleRef
     */
    public void setTableStyleRef(java.lang.String tableStyleRef) {
        this.tableStyleRef = tableStyleRef;
    }


    /**
     * Gets the tbody value for this InlineTable.
     * 
     * @return tbody
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TBody getTbody() {
        return tbody;
    }


    /**
     * Sets the tbody value for this InlineTable.
     * 
     * @param tbody
     */
    public void setTbody(com.socgen.sgs.api.quark.engine.integration.soap.generated.TBody tbody) {
        this.tbody = tbody;
    }


    /**
     * Gets the tfoot value for this InlineTable.
     * 
     * @return tfoot
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TFoot getTfoot() {
        return tfoot;
    }


    /**
     * Sets the tfoot value for this InlineTable.
     * 
     * @param tfoot
     */
    public void setTfoot(com.socgen.sgs.api.quark.engine.integration.soap.generated.TFoot tfoot) {
        this.tfoot = tfoot;
    }


    /**
     * Gets the thead value for this InlineTable.
     * 
     * @return thead
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.THead getThead() {
        return thead;
    }


    /**
     * Sets the thead value for this InlineTable.
     * 
     * @param thead
     */
    public void setThead(com.socgen.sgs.api.quark.engine.integration.soap.generated.THead thead) {
        this.thead = thead;
    }


    /**
     * Gets the width value for this InlineTable.
     * 
     * @return width
     */
    public java.lang.String getWidth() {
        return width;
    }


    /**
     * Sets the width value for this InlineTable.
     * 
     * @param width
     */
    public void setWidth(java.lang.String width) {
        this.width = width;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof InlineTable)) return false;
        InlineTable other = (InlineTable) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.blendMode==null && other.getBlendMode()==null) || 
             (this.blendMode!=null &&
              this.blendMode.equals(other.getBlendMode()))) &&
            ((this.border==null && other.getBorder()==null) || 
             (this.border!=null &&
              this.border.equals(other.getBorder()))) &&
            ((this.breakRowAcrossPages==null && other.getBreakRowAcrossPages()==null) || 
             (this.breakRowAcrossPages!=null &&
              this.breakRowAcrossPages.equals(other.getBreakRowAcrossPages()))) &&
            ((this.breakable==null && other.getBreakable()==null) || 
             (this.breakable!=null &&
              this.breakable.equals(other.getBreakable()))) &&
            ((this.colGroup==null && other.getColGroup()==null) || 
             (this.colGroup!=null &&
              this.colGroup.equals(other.getColGroup()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.excel==null && other.getExcel()==null) || 
             (this.excel!=null &&
              this.excel.equals(other.getExcel()))) &&
            ((this.frame==null && other.getFrame()==null) || 
             (this.frame!=null &&
              this.frame.equals(other.getFrame()))) &&
            this.index == other.getIndex() &&
            ((this.metaData==null && other.getMetaData()==null) || 
             (this.metaData!=null &&
              this.metaData.equals(other.getMetaData()))) &&
            ((this.offset==null && other.getOffset()==null) || 
             (this.offset!=null &&
              this.offset.equals(other.getOffset()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.runaround==null && other.getRunaround()==null) || 
             (this.runaround!=null &&
              this.runaround.equals(other.getRunaround()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.shadow==null && other.getShadow()==null) || 
             (this.shadow!=null &&
              this.shadow.equals(other.getShadow()))) &&
            ((this.span==null && other.getSpan()==null) || 
             (this.span!=null &&
              this.span.equals(other.getSpan()))) &&
            ((this.tableStyleRef==null && other.getTableStyleRef()==null) || 
             (this.tableStyleRef!=null &&
              this.tableStyleRef.equals(other.getTableStyleRef()))) &&
            ((this.tbody==null && other.getTbody()==null) || 
             (this.tbody!=null &&
              this.tbody.equals(other.getTbody()))) &&
            ((this.tfoot==null && other.getTfoot()==null) || 
             (this.tfoot!=null &&
              this.tfoot.equals(other.getTfoot()))) &&
            ((this.thead==null && other.getThead()==null) || 
             (this.thead!=null &&
              this.thead.equals(other.getThead()))) &&
            ((this.width==null && other.getWidth()==null) || 
             (this.width!=null &&
              this.width.equals(other.getWidth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBlendMode() != null) {
            _hashCode += getBlendMode().hashCode();
        }
        if (getBorder() != null) {
            _hashCode += getBorder().hashCode();
        }
        if (getBreakRowAcrossPages() != null) {
            _hashCode += getBreakRowAcrossPages().hashCode();
        }
        if (getBreakable() != null) {
            _hashCode += getBreakable().hashCode();
        }
        if (getColGroup() != null) {
            _hashCode += getColGroup().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getExcel() != null) {
            _hashCode += getExcel().hashCode();
        }
        if (getFrame() != null) {
            _hashCode += getFrame().hashCode();
        }
        _hashCode += getIndex();
        if (getMetaData() != null) {
            _hashCode += getMetaData().hashCode();
        }
        if (getOffset() != null) {
            _hashCode += getOffset().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getRunaround() != null) {
            _hashCode += getRunaround().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getShadow() != null) {
            _hashCode += getShadow().hashCode();
        }
        if (getSpan() != null) {
            _hashCode += getSpan().hashCode();
        }
        if (getTableStyleRef() != null) {
            _hashCode += getTableStyleRef().hashCode();
        }
        if (getTbody() != null) {
            _hashCode += getTbody().hashCode();
        }
        if (getTfoot() != null) {
            _hashCode += getTfoot().hashCode();
        }
        if (getThead() != null) {
            _hashCode += getThead().hashCode();
        }
        if (getWidth() != null) {
            _hashCode += getWidth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InlineTable.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineTable"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("border");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "border"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Border"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("breakRowAcrossPages");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "breakRowAcrossPages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("breakable");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "breakable"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("colGroup");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "colGroup"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ColGroup"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("excel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "excel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Excel"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frame");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "frame"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Frame"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metaData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "metaData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "MetaData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "offset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("runaround");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "runaround"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Runaround"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shadow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Shadow"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("span");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "span"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tableStyleRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tableStyleRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tbody");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tbody"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TBody"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tfoot");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tfoot"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TFoot"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thead");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "thead"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "THead"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("width");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "width"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
