package com.socgen.sgs.api.quark.engine.integration.soap.client;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * SOAP client for the Quark QManagerSDKSvc service (qxpsmsdk.wsdl).
 *
 * <p>This client wraps the Axis-generated stub
 * ({@code com.socgen.sgs.api.quark.engine.integration.soap.generated.QxpsmsdkSoapBindingStub})
 * and exposes a clean interface to the rest of the application.
 *
 * <p>Populated with actual method calls once classes are generated
 * by running {@code mvn generate-sources}.
 */
@Component
@Slf4j
public class EngineSoapClient {
    // Inject the generated service locator via SoapConfig and delegate calls here.
}

