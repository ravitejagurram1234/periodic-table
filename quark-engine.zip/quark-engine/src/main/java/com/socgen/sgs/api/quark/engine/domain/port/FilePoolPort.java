package com.socgen.sgs.api.quark.engine.domain.port;

/** Port for uploading files to the QuarkXPress Server document pool. */
public interface FilePoolPort {
    void addFile(String documentName, byte[] data);

    /**
     * Registers a pool file as already present without uploading it.
     * Cross-reference: .NET QXPS_File_Manager.Addfile_Inform(poolName).
     */
    void inform(String documentName);
}
