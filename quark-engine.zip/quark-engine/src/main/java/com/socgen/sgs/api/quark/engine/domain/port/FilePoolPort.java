package com.socgen.sgs.api.quark.engine.domain.port;

/** Port for uploading files to the QuarkXPress Server document pool. */
public interface FilePoolPort {
    void addFile(String documentName, byte[] data);
}

