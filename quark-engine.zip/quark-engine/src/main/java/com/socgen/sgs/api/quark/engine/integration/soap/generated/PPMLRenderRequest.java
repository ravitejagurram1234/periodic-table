/**
 * PPMLRenderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class PPMLRenderRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String afterPage;

    private java.lang.String exportPath;

    private java.lang.String includeFont;

    private java.lang.String layout;

    private java.lang.String movePages;

    private java.lang.String outputStyle;

    private java.lang.String updateFullRes;

    private java.lang.String updateImage;

    public PPMLRenderRequest() {
    }

    public PPMLRenderRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String afterPage,
           java.lang.String exportPath,
           java.lang.String includeFont,
           java.lang.String layout,
           java.lang.String movePages,
           java.lang.String outputStyle,
           java.lang.String updateFullRes,
           java.lang.String updateImage) {
        super(
            request);
        this.afterPage = afterPage;
        this.exportPath = exportPath;
        this.includeFont = includeFont;
        this.layout = layout;
        this.movePages = movePages;
        this.outputStyle = outputStyle;
        this.updateFullRes = updateFullRes;
        this.updateImage = updateImage;
    }


    /**
     * Gets the afterPage value for this PPMLRenderRequest.
     * 
     * @return afterPage
     */
    public java.lang.String getAfterPage() {
        return afterPage;
    }


    /**
     * Sets the afterPage value for this PPMLRenderRequest.
     * 
     * @param afterPage
     */
    public void setAfterPage(java.lang.String afterPage) {
        this.afterPage = afterPage;
    }


    /**
     * Gets the exportPath value for this PPMLRenderRequest.
     * 
     * @return exportPath
     */
    public java.lang.String getExportPath() {
        return exportPath;
    }


    /**
     * Sets the exportPath value for this PPMLRenderRequest.
     * 
     * @param exportPath
     */
    public void setExportPath(java.lang.String exportPath) {
        this.exportPath = exportPath;
    }


    /**
     * Gets the includeFont value for this PPMLRenderRequest.
     * 
     * @return includeFont
     */
    public java.lang.String getIncludeFont() {
        return includeFont;
    }


    /**
     * Sets the includeFont value for this PPMLRenderRequest.
     * 
     * @param includeFont
     */
    public void setIncludeFont(java.lang.String includeFont) {
        this.includeFont = includeFont;
    }


    /**
     * Gets the layout value for this PPMLRenderRequest.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this PPMLRenderRequest.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the movePages value for this PPMLRenderRequest.
     * 
     * @return movePages
     */
    public java.lang.String getMovePages() {
        return movePages;
    }


    /**
     * Sets the movePages value for this PPMLRenderRequest.
     * 
     * @param movePages
     */
    public void setMovePages(java.lang.String movePages) {
        this.movePages = movePages;
    }


    /**
     * Gets the outputStyle value for this PPMLRenderRequest.
     * 
     * @return outputStyle
     */
    public java.lang.String getOutputStyle() {
        return outputStyle;
    }


    /**
     * Sets the outputStyle value for this PPMLRenderRequest.
     * 
     * @param outputStyle
     */
    public void setOutputStyle(java.lang.String outputStyle) {
        this.outputStyle = outputStyle;
    }


    /**
     * Gets the updateFullRes value for this PPMLRenderRequest.
     * 
     * @return updateFullRes
     */
    public java.lang.String getUpdateFullRes() {
        return updateFullRes;
    }


    /**
     * Sets the updateFullRes value for this PPMLRenderRequest.
     * 
     * @param updateFullRes
     */
    public void setUpdateFullRes(java.lang.String updateFullRes) {
        this.updateFullRes = updateFullRes;
    }


    /**
     * Gets the updateImage value for this PPMLRenderRequest.
     * 
     * @return updateImage
     */
    public java.lang.String getUpdateImage() {
        return updateImage;
    }


    /**
     * Sets the updateImage value for this PPMLRenderRequest.
     * 
     * @param updateImage
     */
    public void setUpdateImage(java.lang.String updateImage) {
        this.updateImage = updateImage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PPMLRenderRequest)) return false;
        PPMLRenderRequest other = (PPMLRenderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.afterPage==null && other.getAfterPage()==null) || 
             (this.afterPage!=null &&
              this.afterPage.equals(other.getAfterPage()))) &&
            ((this.exportPath==null && other.getExportPath()==null) || 
             (this.exportPath!=null &&
              this.exportPath.equals(other.getExportPath()))) &&
            ((this.includeFont==null && other.getIncludeFont()==null) || 
             (this.includeFont!=null &&
              this.includeFont.equals(other.getIncludeFont()))) &&
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.movePages==null && other.getMovePages()==null) || 
             (this.movePages!=null &&
              this.movePages.equals(other.getMovePages()))) &&
            ((this.outputStyle==null && other.getOutputStyle()==null) || 
             (this.outputStyle!=null &&
              this.outputStyle.equals(other.getOutputStyle()))) &&
            ((this.updateFullRes==null && other.getUpdateFullRes()==null) || 
             (this.updateFullRes!=null &&
              this.updateFullRes.equals(other.getUpdateFullRes()))) &&
            ((this.updateImage==null && other.getUpdateImage()==null) || 
             (this.updateImage!=null &&
              this.updateImage.equals(other.getUpdateImage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAfterPage() != null) {
            _hashCode += getAfterPage().hashCode();
        }
        if (getExportPath() != null) {
            _hashCode += getExportPath().hashCode();
        }
        if (getIncludeFont() != null) {
            _hashCode += getIncludeFont().hashCode();
        }
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getMovePages() != null) {
            _hashCode += getMovePages().hashCode();
        }
        if (getOutputStyle() != null) {
            _hashCode += getOutputStyle().hashCode();
        }
        if (getUpdateFullRes() != null) {
            _hashCode += getUpdateFullRes().hashCode();
        }
        if (getUpdateImage() != null) {
            _hashCode += getUpdateImage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PPMLRenderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "PPMLRenderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("afterPage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "afterPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exportPath");
        elemField.setXmlName(new javax.xml.namespace.QName("", "exportPath"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeFont");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeFont"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("movePages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "movePages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "outputStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateFullRes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateFullRes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateImage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateImage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
