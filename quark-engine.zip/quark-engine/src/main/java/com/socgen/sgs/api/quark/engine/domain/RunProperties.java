package com.socgen.sgs.api.quark.engine.domain;

import com.socgen.sgs.api.quark.engine.enums.GabaritSourceEnum;
import com.socgen.sgs.api.quark.engine.enums.TypeRapportEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

/**
 * Represents the properties of a Run object.
 * This class encapsulates all the configuration and metadata for a run.
 */
@Getter
@Setter
@NoArgsConstructor
public class RunProperties {
    /*sup bro - by ananymous */
    // Constants for pagination
    public static final int PAGINATION_SIMPLE = 1;
    public static final int PAGINATION_DOUBLE = 2;

    // Run identification
    private TypeRapportEnum typeRapport = TypeRapportEnum.UNKNOWN;
    private String idFndCode;
    private String idUnitCode;
    private int idSuivi;

    // Company and language
    private LocalDate dateEcheance;
    private int idLangue;
    private String societe;
    private String codeLangue;

    // Template and document settings
    private GabaritSourceEnum gabaritSource = GabaritSourceEnum.DOCUMENT_COURANT;
    private int idSuiviGabaritSource = Integer.MIN_VALUE;
    private int idGabarit = Integer.MIN_VALUE;
    private int idGabaritTemplate = Integer.MIN_VALUE;

    // Run configuration
    private boolean integrerN1 = true;
    private TaskCompartimentMode compartimentMode = TaskCompartimentMode.UNKNOWN;
    private String runType;
    private boolean generateToWord = false;

    // Mode degrade flag (set when gabarit exceeds size limit)
    private boolean modeDegrade = false;

    // Generated files tracking
    private int idLastPdf = Integer.MIN_VALUE;
    private int idLastQxp = Integer.MIN_VALUE;
    private int idLastDoc = Integer.MIN_VALUE;

    // Pagination settings
    private int nbPageBySpread = PAGINATION_SIMPLE;

    // Storage type — raw [Flags] code from store_data_type (0x00 NONE, 0x01 SQL, 0x02 DOCUMENT,
    // 0x03 SQL|DOCUMENT, 0xFF ALL). Stored as an int (not the StoreDataType enum) so combined
    // values survive; test bits via StoreDataType.hasFlag(code, flag). Parity: .NET Run_Properties
    // .Store_Type holds the raw [Flags] value (Proxy_Run.cs:151-153). Finding #1.
    private int storeDataTypeCode = 0;

    // Run ID for path generation
    private Integer runId;

    /**
     * Get the pool path for a given file name.
     * Returns a relative path in the format: R_runId/fileName
     *
     * @param fileName the file name
     * @return the pool path
     */
    public String getPoolPath(String fileName) {
        if (this.runId == null || fileName == null) {
            return fileName;
        }
        return String.format("R_%d/%s", this.runId, fileName);
    }

    /**
     * Get the absolute pool path for a given file name.
     * Returns an absolute path in the format: documentPoolBasePath/R_runId/fileName
     *
     * @param fileName the file name
     * @param documentPoolBasePath the base path for document pool (e.g., D:\Documents)
     * @return the absolute pool path
     */
    public String getPoolPathAbsolute(String fileName, String documentPoolBasePath) {
        if (this.runId == null || fileName == null || documentPoolBasePath == null) {
            return fileName;
        }
        // The Quark host is Windows: the SaveAs absolute path must use all-backslash separators,
        // matching .NET QXPS_File_Manager.GetPoolPathAbsolute/SetPoolPath which do .Replace("/","\\").
        // Strip any trailing separator on the base, then normalize every separator to '\'.
        String base = documentPoolBasePath.replaceAll("[/\\\\]+$", "");
        String raw = base + "/R_" + this.runId + "/" + fileName;
        return raw.replace("/", "\\");
    }
}