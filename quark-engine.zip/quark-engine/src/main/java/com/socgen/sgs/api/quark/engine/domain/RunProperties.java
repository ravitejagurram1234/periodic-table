package com.socgen.sgs.api.quark.engine.domain;

import com.socgen.sgs.api.quark.engine.enums.GabaritSourceEnum;
import com.socgen.sgs.api.quark.engine.enums.TypeRapportEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

/**
 * Represents the properties of a Run object.
 * This class encapsulates all the configuration and metadata for a run.
 */
@Getter
@Setter
@NoArgsConstructor
public class RunProperties {
/*sup bro - by ananymous */
    // Constants for pagination
    public static final int PAGINATION_SIMPLE = 1;
    public static final int PAGINATION_DOUBLE = 2;

    // Run identification
    private TypeRapportEnum typeRapport = TypeRapportEnum.UNKNOWN;
    private String idFndCode;
    private String idUnitCode;
    private int idSuivi;

    // Company and language
    private LocalDate dateEcheance;
    private int idLangue;
    private String societe;
    private String codeLangue;

    // Template and document settings
    private GabaritSourceEnum gabaritSource = GabaritSourceEnum.DOCUMENT_COURANT;
    private int idSuiviGabaritSource = Integer.MIN_VALUE;
    private int idGabarit = Integer.MIN_VALUE;
    private int idGabaritTemplate = Integer.MIN_VALUE;

    // Run configuration
    private boolean integrerN1 = true;
    private TaskCompartimentMode compartimentMode = TaskCompartimentMode.UNKNOWN;
    private String runType;
    private boolean generateToWord = false;

    // Mode degrade flag (set when gabarit exceeds size limit)
    private boolean modeDegrade = false;

    // Generated files tracking
    private int idLastPdf = Integer.MIN_VALUE;
    private int idLastQxp = Integer.MIN_VALUE;
    private int idLastDoc = Integer.MIN_VALUE;

    // Pagination settings
    private int nbPageBySpread = PAGINATION_SIMPLE;

    // Storage type
    private StoreDataType storeDataType = StoreDataType.NONE;

    // Run ID for path generation
    private Integer runId;

    /**
     * Get the pool path for a given file name.
     * Returns a relative path in the format: R_runId/fileName
     *
     * @param fileName the file name
     * @return the pool path
     */
    public String getPoolPath(String fileName) {
        if (this.runId == null || fileName == null) {
            return fileName;
        }
        return String.format("R_%d/%s", this.runId, fileName);
    }

    /**
     * Get the absolute pool path for a given file name.
     * Returns an absolute path in the format: documentPoolBasePath/R_runId/fileName
     *
     * @param fileName the file name
     * @param documentPoolBasePath the base path for document pool (e.g., D:\Documents)
     * @return the absolute pool path
     */
    public String getPoolPathAbsolute(String fileName, String documentPoolBasePath) {
        if (this.runId == null || fileName == null || documentPoolBasePath == null) {
            return fileName;
        }
        return String.format("%s/R_%d/%s", documentPoolBasePath, this.runId, fileName);
    }
}






