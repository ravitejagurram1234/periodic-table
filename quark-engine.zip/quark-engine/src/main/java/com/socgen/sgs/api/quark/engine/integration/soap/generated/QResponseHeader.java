/**
 * QResponseHeader.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class QResponseHeader  implements java.io.Serializable {
    private java.lang.String headerName;

    private java.lang.String headerValue;

    public QResponseHeader() {
    }

    public QResponseHeader(
           java.lang.String headerName,
           java.lang.String headerValue) {
           this.headerName = headerName;
           this.headerValue = headerValue;
    }


    /**
     * Gets the headerName value for this QResponseHeader.
     * 
     * @return headerName
     */
    public java.lang.String getHeaderName() {
        return headerName;
    }


    /**
     * Sets the headerName value for this QResponseHeader.
     * 
     * @param headerName
     */
    public void setHeaderName(java.lang.String headerName) {
        this.headerName = headerName;
    }


    /**
     * Gets the headerValue value for this QResponseHeader.
     * 
     * @return headerValue
     */
    public java.lang.String getHeaderValue() {
        return headerValue;
    }


    /**
     * Sets the headerValue value for this QResponseHeader.
     * 
     * @param headerValue
     */
    public void setHeaderValue(java.lang.String headerValue) {
        this.headerValue = headerValue;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QResponseHeader)) return false;
        QResponseHeader other = (QResponseHeader) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.headerName==null && other.getHeaderName()==null) || 
             (this.headerName!=null &&
              this.headerName.equals(other.getHeaderName()))) &&
            ((this.headerValue==null && other.getHeaderValue()==null) || 
             (this.headerValue!=null &&
              this.headerValue.equals(other.getHeaderValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHeaderName() != null) {
            _hashCode += getHeaderName().hashCode();
        }
        if (getHeaderValue() != null) {
            _hashCode += getHeaderValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QResponseHeader.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "QResponseHeader"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headerName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "headerName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headerValue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "headerValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
