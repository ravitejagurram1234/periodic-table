/**
 * EPSRenderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class EPSRenderRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String EPSData;

    private java.lang.String EPSFormat;

    private java.lang.String EPSOPIImage;

    private java.lang.String EPSOPILowResolution;

    private java.lang.String EPSPreview;

    private java.lang.String EPSTransparent;

    private java.lang.String afterPage;

    private java.lang.String downloadImportedPDFEPSFonts;

    private java.lang.String downloadLayoutFonts;

    private java.lang.String layout;

    private java.lang.String movePages;

    private java.lang.String outputStyle;

    private java.lang.String page;

    private java.lang.String pasteboard;

    private java.lang.String scale;

    private java.lang.String spread;

    private java.lang.String updateFullRes;

    private java.lang.String updateImage;

    public EPSRenderRequest() {
    }

    public EPSRenderRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String EPSData,
           java.lang.String EPSFormat,
           java.lang.String EPSOPIImage,
           java.lang.String EPSOPILowResolution,
           java.lang.String EPSPreview,
           java.lang.String EPSTransparent,
           java.lang.String afterPage,
           java.lang.String downloadImportedPDFEPSFonts,
           java.lang.String downloadLayoutFonts,
           java.lang.String layout,
           java.lang.String movePages,
           java.lang.String outputStyle,
           java.lang.String page,
           java.lang.String pasteboard,
           java.lang.String scale,
           java.lang.String spread,
           java.lang.String updateFullRes,
           java.lang.String updateImage) {
        super(
            request);
        this.EPSData = EPSData;
        this.EPSFormat = EPSFormat;
        this.EPSOPIImage = EPSOPIImage;
        this.EPSOPILowResolution = EPSOPILowResolution;
        this.EPSPreview = EPSPreview;
        this.EPSTransparent = EPSTransparent;
        this.afterPage = afterPage;
        this.downloadImportedPDFEPSFonts = downloadImportedPDFEPSFonts;
        this.downloadLayoutFonts = downloadLayoutFonts;
        this.layout = layout;
        this.movePages = movePages;
        this.outputStyle = outputStyle;
        this.page = page;
        this.pasteboard = pasteboard;
        this.scale = scale;
        this.spread = spread;
        this.updateFullRes = updateFullRes;
        this.updateImage = updateImage;
    }


    /**
     * Gets the EPSData value for this EPSRenderRequest.
     * 
     * @return EPSData
     */
    public java.lang.String getEPSData() {
        return EPSData;
    }


    /**
     * Sets the EPSData value for this EPSRenderRequest.
     * 
     * @param EPSData
     */
    public void setEPSData(java.lang.String EPSData) {
        this.EPSData = EPSData;
    }


    /**
     * Gets the EPSFormat value for this EPSRenderRequest.
     * 
     * @return EPSFormat
     */
    public java.lang.String getEPSFormat() {
        return EPSFormat;
    }


    /**
     * Sets the EPSFormat value for this EPSRenderRequest.
     * 
     * @param EPSFormat
     */
    public void setEPSFormat(java.lang.String EPSFormat) {
        this.EPSFormat = EPSFormat;
    }


    /**
     * Gets the EPSOPIImage value for this EPSRenderRequest.
     * 
     * @return EPSOPIImage
     */
    public java.lang.String getEPSOPIImage() {
        return EPSOPIImage;
    }


    /**
     * Sets the EPSOPIImage value for this EPSRenderRequest.
     * 
     * @param EPSOPIImage
     */
    public void setEPSOPIImage(java.lang.String EPSOPIImage) {
        this.EPSOPIImage = EPSOPIImage;
    }


    /**
     * Gets the EPSOPILowResolution value for this EPSRenderRequest.
     * 
     * @return EPSOPILowResolution
     */
    public java.lang.String getEPSOPILowResolution() {
        return EPSOPILowResolution;
    }


    /**
     * Sets the EPSOPILowResolution value for this EPSRenderRequest.
     * 
     * @param EPSOPILowResolution
     */
    public void setEPSOPILowResolution(java.lang.String EPSOPILowResolution) {
        this.EPSOPILowResolution = EPSOPILowResolution;
    }


    /**
     * Gets the EPSPreview value for this EPSRenderRequest.
     * 
     * @return EPSPreview
     */
    public java.lang.String getEPSPreview() {
        return EPSPreview;
    }


    /**
     * Sets the EPSPreview value for this EPSRenderRequest.
     * 
     * @param EPSPreview
     */
    public void setEPSPreview(java.lang.String EPSPreview) {
        this.EPSPreview = EPSPreview;
    }


    /**
     * Gets the EPSTransparent value for this EPSRenderRequest.
     * 
     * @return EPSTransparent
     */
    public java.lang.String getEPSTransparent() {
        return EPSTransparent;
    }


    /**
     * Sets the EPSTransparent value for this EPSRenderRequest.
     * 
     * @param EPSTransparent
     */
    public void setEPSTransparent(java.lang.String EPSTransparent) {
        this.EPSTransparent = EPSTransparent;
    }


    /**
     * Gets the afterPage value for this EPSRenderRequest.
     * 
     * @return afterPage
     */
    public java.lang.String getAfterPage() {
        return afterPage;
    }


    /**
     * Sets the afterPage value for this EPSRenderRequest.
     * 
     * @param afterPage
     */
    public void setAfterPage(java.lang.String afterPage) {
        this.afterPage = afterPage;
    }


    /**
     * Gets the downloadImportedPDFEPSFonts value for this EPSRenderRequest.
     * 
     * @return downloadImportedPDFEPSFonts
     */
    public java.lang.String getDownloadImportedPDFEPSFonts() {
        return downloadImportedPDFEPSFonts;
    }


    /**
     * Sets the downloadImportedPDFEPSFonts value for this EPSRenderRequest.
     * 
     * @param downloadImportedPDFEPSFonts
     */
    public void setDownloadImportedPDFEPSFonts(java.lang.String downloadImportedPDFEPSFonts) {
        this.downloadImportedPDFEPSFonts = downloadImportedPDFEPSFonts;
    }


    /**
     * Gets the downloadLayoutFonts value for this EPSRenderRequest.
     * 
     * @return downloadLayoutFonts
     */
    public java.lang.String getDownloadLayoutFonts() {
        return downloadLayoutFonts;
    }


    /**
     * Sets the downloadLayoutFonts value for this EPSRenderRequest.
     * 
     * @param downloadLayoutFonts
     */
    public void setDownloadLayoutFonts(java.lang.String downloadLayoutFonts) {
        this.downloadLayoutFonts = downloadLayoutFonts;
    }


    /**
     * Gets the layout value for this EPSRenderRequest.
     * 
     * @return layout
     */
    public java.lang.String getLayout() {
        return layout;
    }


    /**
     * Sets the layout value for this EPSRenderRequest.
     * 
     * @param layout
     */
    public void setLayout(java.lang.String layout) {
        this.layout = layout;
    }


    /**
     * Gets the movePages value for this EPSRenderRequest.
     * 
     * @return movePages
     */
    public java.lang.String getMovePages() {
        return movePages;
    }


    /**
     * Sets the movePages value for this EPSRenderRequest.
     * 
     * @param movePages
     */
    public void setMovePages(java.lang.String movePages) {
        this.movePages = movePages;
    }


    /**
     * Gets the outputStyle value for this EPSRenderRequest.
     * 
     * @return outputStyle
     */
    public java.lang.String getOutputStyle() {
        return outputStyle;
    }


    /**
     * Sets the outputStyle value for this EPSRenderRequest.
     * 
     * @param outputStyle
     */
    public void setOutputStyle(java.lang.String outputStyle) {
        this.outputStyle = outputStyle;
    }


    /**
     * Gets the page value for this EPSRenderRequest.
     * 
     * @return page
     */
    public java.lang.String getPage() {
        return page;
    }


    /**
     * Sets the page value for this EPSRenderRequest.
     * 
     * @param page
     */
    public void setPage(java.lang.String page) {
        this.page = page;
    }


    /**
     * Gets the pasteboard value for this EPSRenderRequest.
     * 
     * @return pasteboard
     */
    public java.lang.String getPasteboard() {
        return pasteboard;
    }


    /**
     * Sets the pasteboard value for this EPSRenderRequest.
     * 
     * @param pasteboard
     */
    public void setPasteboard(java.lang.String pasteboard) {
        this.pasteboard = pasteboard;
    }


    /**
     * Gets the scale value for this EPSRenderRequest.
     * 
     * @return scale
     */
    public java.lang.String getScale() {
        return scale;
    }


    /**
     * Sets the scale value for this EPSRenderRequest.
     * 
     * @param scale
     */
    public void setScale(java.lang.String scale) {
        this.scale = scale;
    }


    /**
     * Gets the spread value for this EPSRenderRequest.
     * 
     * @return spread
     */
    public java.lang.String getSpread() {
        return spread;
    }


    /**
     * Sets the spread value for this EPSRenderRequest.
     * 
     * @param spread
     */
    public void setSpread(java.lang.String spread) {
        this.spread = spread;
    }


    /**
     * Gets the updateFullRes value for this EPSRenderRequest.
     * 
     * @return updateFullRes
     */
    public java.lang.String getUpdateFullRes() {
        return updateFullRes;
    }


    /**
     * Sets the updateFullRes value for this EPSRenderRequest.
     * 
     * @param updateFullRes
     */
    public void setUpdateFullRes(java.lang.String updateFullRes) {
        this.updateFullRes = updateFullRes;
    }


    /**
     * Gets the updateImage value for this EPSRenderRequest.
     * 
     * @return updateImage
     */
    public java.lang.String getUpdateImage() {
        return updateImage;
    }


    /**
     * Sets the updateImage value for this EPSRenderRequest.
     * 
     * @param updateImage
     */
    public void setUpdateImage(java.lang.String updateImage) {
        this.updateImage = updateImage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EPSRenderRequest)) return false;
        EPSRenderRequest other = (EPSRenderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.EPSData==null && other.getEPSData()==null) || 
             (this.EPSData!=null &&
              this.EPSData.equals(other.getEPSData()))) &&
            ((this.EPSFormat==null && other.getEPSFormat()==null) || 
             (this.EPSFormat!=null &&
              this.EPSFormat.equals(other.getEPSFormat()))) &&
            ((this.EPSOPIImage==null && other.getEPSOPIImage()==null) || 
             (this.EPSOPIImage!=null &&
              this.EPSOPIImage.equals(other.getEPSOPIImage()))) &&
            ((this.EPSOPILowResolution==null && other.getEPSOPILowResolution()==null) || 
             (this.EPSOPILowResolution!=null &&
              this.EPSOPILowResolution.equals(other.getEPSOPILowResolution()))) &&
            ((this.EPSPreview==null && other.getEPSPreview()==null) || 
             (this.EPSPreview!=null &&
              this.EPSPreview.equals(other.getEPSPreview()))) &&
            ((this.EPSTransparent==null && other.getEPSTransparent()==null) || 
             (this.EPSTransparent!=null &&
              this.EPSTransparent.equals(other.getEPSTransparent()))) &&
            ((this.afterPage==null && other.getAfterPage()==null) || 
             (this.afterPage!=null &&
              this.afterPage.equals(other.getAfterPage()))) &&
            ((this.downloadImportedPDFEPSFonts==null && other.getDownloadImportedPDFEPSFonts()==null) || 
             (this.downloadImportedPDFEPSFonts!=null &&
              this.downloadImportedPDFEPSFonts.equals(other.getDownloadImportedPDFEPSFonts()))) &&
            ((this.downloadLayoutFonts==null && other.getDownloadLayoutFonts()==null) || 
             (this.downloadLayoutFonts!=null &&
              this.downloadLayoutFonts.equals(other.getDownloadLayoutFonts()))) &&
            ((this.layout==null && other.getLayout()==null) || 
             (this.layout!=null &&
              this.layout.equals(other.getLayout()))) &&
            ((this.movePages==null && other.getMovePages()==null) || 
             (this.movePages!=null &&
              this.movePages.equals(other.getMovePages()))) &&
            ((this.outputStyle==null && other.getOutputStyle()==null) || 
             (this.outputStyle!=null &&
              this.outputStyle.equals(other.getOutputStyle()))) &&
            ((this.page==null && other.getPage()==null) || 
             (this.page!=null &&
              this.page.equals(other.getPage()))) &&
            ((this.pasteboard==null && other.getPasteboard()==null) || 
             (this.pasteboard!=null &&
              this.pasteboard.equals(other.getPasteboard()))) &&
            ((this.scale==null && other.getScale()==null) || 
             (this.scale!=null &&
              this.scale.equals(other.getScale()))) &&
            ((this.spread==null && other.getSpread()==null) || 
             (this.spread!=null &&
              this.spread.equals(other.getSpread()))) &&
            ((this.updateFullRes==null && other.getUpdateFullRes()==null) || 
             (this.updateFullRes!=null &&
              this.updateFullRes.equals(other.getUpdateFullRes()))) &&
            ((this.updateImage==null && other.getUpdateImage()==null) || 
             (this.updateImage!=null &&
              this.updateImage.equals(other.getUpdateImage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getEPSData() != null) {
            _hashCode += getEPSData().hashCode();
        }
        if (getEPSFormat() != null) {
            _hashCode += getEPSFormat().hashCode();
        }
        if (getEPSOPIImage() != null) {
            _hashCode += getEPSOPIImage().hashCode();
        }
        if (getEPSOPILowResolution() != null) {
            _hashCode += getEPSOPILowResolution().hashCode();
        }
        if (getEPSPreview() != null) {
            _hashCode += getEPSPreview().hashCode();
        }
        if (getEPSTransparent() != null) {
            _hashCode += getEPSTransparent().hashCode();
        }
        if (getAfterPage() != null) {
            _hashCode += getAfterPage().hashCode();
        }
        if (getDownloadImportedPDFEPSFonts() != null) {
            _hashCode += getDownloadImportedPDFEPSFonts().hashCode();
        }
        if (getDownloadLayoutFonts() != null) {
            _hashCode += getDownloadLayoutFonts().hashCode();
        }
        if (getLayout() != null) {
            _hashCode += getLayout().hashCode();
        }
        if (getMovePages() != null) {
            _hashCode += getMovePages().hashCode();
        }
        if (getOutputStyle() != null) {
            _hashCode += getOutputStyle().hashCode();
        }
        if (getPage() != null) {
            _hashCode += getPage().hashCode();
        }
        if (getPasteboard() != null) {
            _hashCode += getPasteboard().hashCode();
        }
        if (getScale() != null) {
            _hashCode += getScale().hashCode();
        }
        if (getSpread() != null) {
            _hashCode += getSpread().hashCode();
        }
        if (getUpdateFullRes() != null) {
            _hashCode += getUpdateFullRes().hashCode();
        }
        if (getUpdateImage() != null) {
            _hashCode += getUpdateImage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EPSRenderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "EPSRenderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EPSData");
        elemField.setXmlName(new javax.xml.namespace.QName("", "EPSData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EPSFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "EPSFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EPSOPIImage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "EPSOPIImage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EPSOPILowResolution");
        elemField.setXmlName(new javax.xml.namespace.QName("", "EPSOPILowResolution"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EPSPreview");
        elemField.setXmlName(new javax.xml.namespace.QName("", "EPSPreview"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EPSTransparent");
        elemField.setXmlName(new javax.xml.namespace.QName("", "EPSTransparent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("afterPage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "afterPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("downloadImportedPDFEPSFonts");
        elemField.setXmlName(new javax.xml.namespace.QName("", "downloadImportedPDFEPSFonts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("downloadLayoutFonts");
        elemField.setXmlName(new javax.xml.namespace.QName("", "downloadLayoutFonts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layout");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("movePages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "movePages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outputStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "outputStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("page");
        elemField.setXmlName(new javax.xml.namespace.QName("", "page"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pasteboard");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pasteboard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scale");
        elemField.setXmlName(new javax.xml.namespace.QName("", "scale"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spread");
        elemField.setXmlName(new javax.xml.namespace.QName("", "spread"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateFullRes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateFullRes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateImage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateImage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
