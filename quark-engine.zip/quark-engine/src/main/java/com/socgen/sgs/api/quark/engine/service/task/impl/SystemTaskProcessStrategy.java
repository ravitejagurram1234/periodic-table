package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox;
import com.socgen.sgs.api.quark.engine.domain.helper.DataTypeHelper;
import com.socgen.sgs.api.quark.engine.domain.task.TaskSystem;
import com.socgen.sgs.api.quark.engine.enums.SubTaskTypeEnum;
import com.socgen.sgs.api.quark.engine.service.task.TaskProcessStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Strategy for processing TaskSystem (system/template box updates).
 * Handles two modes: VALUE mode (text updates) and BOX mode (box copying from gabarit).
 *
 * Cross-reference: QXP.Engine.Core\Business\Task\Process_System.cs
 */
@Component
@Slf4j
public class SystemTaskProcessStrategy implements TaskProcessStrategy<TaskSystem> {

    @Override
    public Class<TaskSystem> getTaskType() {
        return TaskSystem.class;
    }

    @Override
    public void process(TaskSystem task) {
        // Step 1: Verify destination bloc name is set (required)
        if (task.getDestinationBlocName() == null || task.getDestinationBlocName().isBlank()) {
            log.warn("Missing destinationBlocName for task [{}], skipping", task.getId());
            return;
        }

        // Step 2: Determine mode based on tBoxSrcBox presence
        if (task.getTBoxSrcBox() != null) {
            processBoxMode(task);
        } else {
            processValueMode(task);
        }
    }

    /**
     * VALUE MODE: Format a text value and create UPDATE bloc.
     * Maps to .NET Process_System.cs lines 65-74.
     */
    private void processValueMode(TaskSystem task) {
        log.debug("SystemTaskProcessStrategy VALUE mode for task [{}]", task.getId());

        task.setSubTaskType(SubTaskTypeEnum.VALUE);

        String formattedValue = DataTypeHelper.outputToString(
                task.getValue(),
                task.getDataType(),
                task.getNbDecimal(),
                task.isShowZero(),
                task.getNullString(),
                task.isDecimalSignificative()
        );

        BlocBox bloc = new BlocBox(task, task.getDestinationBlocName(), formattedValue);
        task.getBlocsUpdate().put(bloc.getName(), bloc);

        log.debug("SystemTaskProcessStrategy VALUE: bloc [{}] = [{}]",
                task.getDestinationBlocName(), formattedValue);
    }

    /**
     * BOX MODE: Copy a box from gabarit template and create MODIFY bloc.
     * Maps to .NET Process_System.cs lines 52-62.
     */
    private void processBoxMode(TaskSystem task) {
        log.debug("SystemTaskProcessStrategy BOX mode for task [{}]", task.getId());

        task.setSubTaskType(SubTaskTypeEnum.BOX);

        String blocName = task.getTBoxSrcBox().getName();

        BlocBox bloc = new BlocBox(
                task,
                blocName,
                task.getTBoxSrcBox(),
                task.getTBoxSrcExtraBox()
        );

        bloc.setAction(task.getAction());
        bloc.setPagination(task.isPagination());

        task.getBlocsModify().put(bloc.getName(), bloc);

        log.debug("SystemTaskProcessStrategy BOX: bloc [{}], action={}, pagination={}",
                blocName, task.getAction(), task.isPagination());
    }
}

