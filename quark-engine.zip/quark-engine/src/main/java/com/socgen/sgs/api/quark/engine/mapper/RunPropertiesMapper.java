package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.domain.TaskCompartimentMode;
import com.socgen.sgs.api.quark.engine.enums.GabaritSourceEnum;
import com.socgen.sgs.api.quark.engine.enums.TypeRapportEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Mapper class for converting database ResultSet or column maps to {@link RunProperties}.
 * This mapper can be reused for DTO conversions and other transformations.
 */
@Component
@Slf4j
public class RunPropertiesMapper {

    /**
     * Maps a ResultSet row to a RunProperties domain object.
     * Used by returningResultSet RowMapper in SimpleJdbcCall.
     *
     * @param rs the ResultSet positioned at the current row
     * @return a populated RunProperties object
     * @throws SQLException if a database access error occurs
     */
    public RunProperties mapFromResultSet(ResultSet rs) throws SQLException {
        RunProperties props = new RunProperties();
        int intVal;

        intVal = rs.getInt("id_type_rapport");
        props.setTypeRapport(rs.wasNull() ? TypeRapportEnum.UNKNOWN : TypeRapportEnum.fromCode(intVal));

        props.setIdFndCode(rs.getString("id_fnd_code"));
        props.setIdUnitCode(rs.getString("id_unit_code"));

        java.sql.Date dateEcheance = rs.getDate("date_echeance");
        if (dateEcheance != null) {
            props.setDateEcheance(dateEcheance.toLocalDate());
        }

        props.setIdSuivi(rs.getInt("id_suivi"));
        props.setIdLangue(rs.getInt("id_langue"));
        props.setSociete(rs.getString("societe"));
        props.setCodeLangue(rs.getString("code_langue"));

        intVal = rs.getInt("gabarit_source");
        props.setGabaritSource(rs.wasNull() ? GabaritSourceEnum.UNKNOWN : GabaritSourceEnum.fromCode(intVal));

        intVal = rs.getInt("id_suivi_gabarit_source");
        props.setIdSuiviGabaritSource(rs.wasNull() ? Integer.MIN_VALUE : intVal);

        props.setIntegrerN1(rs.getInt("integrer_n1") != 0);

        intVal = rs.getInt("mode_compart");
        props.setCompartimentMode(rs.wasNull() ? TaskCompartimentMode.UNKNOWN
                : TaskCompartimentMode.fromCode(intVal));

        props.setRunType(rs.getString("runtype"));
        props.setGenerateToWord(rs.getInt("generate_to_word") != 0);

        intVal = rs.getInt("id_gabarit");
        props.setIdGabarit(rs.wasNull() ? Integer.MIN_VALUE : intVal);

        intVal = rs.getInt("id_gabarit_template");
        props.setIdGabaritTemplate(rs.wasNull() ? Integer.MIN_VALUE : intVal);

        intVal = rs.getInt("id_doc_pdf");
        props.setIdLastPdf(rs.wasNull() ? Integer.MIN_VALUE : intVal);

        intVal = rs.getInt("id_doc_qxp");
        props.setIdLastQxp(rs.wasNull() ? Integer.MIN_VALUE : intVal);

        intVal = rs.getInt("id_doc_doc");
        props.setIdLastDoc(rs.wasNull() ? Integer.MIN_VALUE : intVal);

        props.setNbPageBySpread(rs.getInt("pagination_double") != 0
                ? RunProperties.PAGINATION_DOUBLE
                : RunProperties.PAGINATION_SIMPLE);

        // Carry the raw [Flags] value so combined codes (e.g. 3 = SQL|DOCUMENT) survive — do NOT
        // collapse to an enum, which would silently drop combined values to NONE. Finding #1.
        intVal = rs.getInt("store_data_type");
        props.setStoreDataTypeCode(rs.wasNull() ? 0 : intVal);

        return props;
    }
}