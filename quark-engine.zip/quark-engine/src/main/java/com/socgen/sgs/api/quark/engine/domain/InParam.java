package com.socgen.sgs.api.quark.engine.domain;
import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;
import lombok.Getter;

/**
 * Immutable domain value object representing a typed input parameter for a run.
 * Mirrors QXPDataOracle.OraParameter from the .NET implementation.
 * The raw string value is stored as-is and passed directly to Oracle bind variables.
 * Oracle SQL handles type conversion (e.g., to_date(:param)) — no Java-side parsing needed.
 */
@Getter
public class InParam {

    private final String name;
    private final DataTypeEnum type;
    private final String stringValue;

    public InParam(String name, int type, String stringValue) {
        this(name, DataTypeEnum.fromCode(type), stringValue);
    }

    public InParam(String name, DataTypeEnum type, String stringValue) {
        this.name = name;
        this.type = type;
        this.stringValue = stringValue;
    }
}
