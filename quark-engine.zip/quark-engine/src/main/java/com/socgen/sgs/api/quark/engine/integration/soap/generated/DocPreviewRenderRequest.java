/**
 * DocPreviewRenderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class DocPreviewRenderRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String colorspace;

    private java.lang.String compression;

    private java.lang.String imageFormat;

    private java.lang.String resolution;

    private java.lang.String totalpages;

    public DocPreviewRenderRequest() {
    }

    public DocPreviewRenderRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String colorspace,
           java.lang.String compression,
           java.lang.String imageFormat,
           java.lang.String resolution,
           java.lang.String totalpages) {
        super(
            request);
        this.colorspace = colorspace;
        this.compression = compression;
        this.imageFormat = imageFormat;
        this.resolution = resolution;
        this.totalpages = totalpages;
    }


    /**
     * Gets the colorspace value for this DocPreviewRenderRequest.
     * 
     * @return colorspace
     */
    public java.lang.String getColorspace() {
        return colorspace;
    }


    /**
     * Sets the colorspace value for this DocPreviewRenderRequest.
     * 
     * @param colorspace
     */
    public void setColorspace(java.lang.String colorspace) {
        this.colorspace = colorspace;
    }


    /**
     * Gets the compression value for this DocPreviewRenderRequest.
     * 
     * @return compression
     */
    public java.lang.String getCompression() {
        return compression;
    }


    /**
     * Sets the compression value for this DocPreviewRenderRequest.
     * 
     * @param compression
     */
    public void setCompression(java.lang.String compression) {
        this.compression = compression;
    }


    /**
     * Gets the imageFormat value for this DocPreviewRenderRequest.
     * 
     * @return imageFormat
     */
    public java.lang.String getImageFormat() {
        return imageFormat;
    }


    /**
     * Sets the imageFormat value for this DocPreviewRenderRequest.
     * 
     * @param imageFormat
     */
    public void setImageFormat(java.lang.String imageFormat) {
        this.imageFormat = imageFormat;
    }


    /**
     * Gets the resolution value for this DocPreviewRenderRequest.
     * 
     * @return resolution
     */
    public java.lang.String getResolution() {
        return resolution;
    }


    /**
     * Sets the resolution value for this DocPreviewRenderRequest.
     * 
     * @param resolution
     */
    public void setResolution(java.lang.String resolution) {
        this.resolution = resolution;
    }


    /**
     * Gets the totalpages value for this DocPreviewRenderRequest.
     * 
     * @return totalpages
     */
    public java.lang.String getTotalpages() {
        return totalpages;
    }


    /**
     * Sets the totalpages value for this DocPreviewRenderRequest.
     * 
     * @param totalpages
     */
    public void setTotalpages(java.lang.String totalpages) {
        this.totalpages = totalpages;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DocPreviewRenderRequest)) return false;
        DocPreviewRenderRequest other = (DocPreviewRenderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.colorspace==null && other.getColorspace()==null) || 
             (this.colorspace!=null &&
              this.colorspace.equals(other.getColorspace()))) &&
            ((this.compression==null && other.getCompression()==null) || 
             (this.compression!=null &&
              this.compression.equals(other.getCompression()))) &&
            ((this.imageFormat==null && other.getImageFormat()==null) || 
             (this.imageFormat!=null &&
              this.imageFormat.equals(other.getImageFormat()))) &&
            ((this.resolution==null && other.getResolution()==null) || 
             (this.resolution!=null &&
              this.resolution.equals(other.getResolution()))) &&
            ((this.totalpages==null && other.getTotalpages()==null) || 
             (this.totalpages!=null &&
              this.totalpages.equals(other.getTotalpages())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getColorspace() != null) {
            _hashCode += getColorspace().hashCode();
        }
        if (getCompression() != null) {
            _hashCode += getCompression().hashCode();
        }
        if (getImageFormat() != null) {
            _hashCode += getImageFormat().hashCode();
        }
        if (getResolution() != null) {
            _hashCode += getResolution().hashCode();
        }
        if (getTotalpages() != null) {
            _hashCode += getTotalpages().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DocPreviewRenderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "DocPreviewRenderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("colorspace");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "colorspace"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compression");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "compression"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("imageFormat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "imageFormat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resolution");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "resolution"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalpages");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "totalpages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
