/**
 * TRowStyle.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class TRowStyle  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignment;

    private java.lang.String angle;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.BottomGrid bottomGrid;

    private java.lang.String color;

    private java.lang.String inset;

    private java.lang.String insetBottom;

    private java.lang.String insetLeft;

    private java.lang.String insetRight;

    private java.lang.String insetTop;

    private java.lang.String paraStyle;

    private java.lang.String shade;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TopGrid topGrid;

    private java.lang.String valign;

    public TRowStyle() {
    }

    public TRowStyle(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignment,
           java.lang.String angle,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.BottomGrid bottomGrid,
           java.lang.String color,
           java.lang.String inset,
           java.lang.String insetBottom,
           java.lang.String insetLeft,
           java.lang.String insetRight,
           java.lang.String insetTop,
           java.lang.String paraStyle,
           java.lang.String shade,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TopGrid topGrid,
           java.lang.String valign) {
        super(
            request);
        this.alignment = alignment;
        this.angle = angle;
        this.bottomGrid = bottomGrid;
        this.color = color;
        this.inset = inset;
        this.insetBottom = insetBottom;
        this.insetLeft = insetLeft;
        this.insetRight = insetRight;
        this.insetTop = insetTop;
        this.paraStyle = paraStyle;
        this.shade = shade;
        this.topGrid = topGrid;
        this.valign = valign;
    }


    /**
     * Gets the alignment value for this TRowStyle.
     * 
     * @return alignment
     */
    public java.lang.String getAlignment() {
        return alignment;
    }


    /**
     * Sets the alignment value for this TRowStyle.
     * 
     * @param alignment
     */
    public void setAlignment(java.lang.String alignment) {
        this.alignment = alignment;
    }


    /**
     * Gets the angle value for this TRowStyle.
     * 
     * @return angle
     */
    public java.lang.String getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this TRowStyle.
     * 
     * @param angle
     */
    public void setAngle(java.lang.String angle) {
        this.angle = angle;
    }


    /**
     * Gets the bottomGrid value for this TRowStyle.
     * 
     * @return bottomGrid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.BottomGrid getBottomGrid() {
        return bottomGrid;
    }


    /**
     * Sets the bottomGrid value for this TRowStyle.
     * 
     * @param bottomGrid
     */
    public void setBottomGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.BottomGrid bottomGrid) {
        this.bottomGrid = bottomGrid;
    }


    /**
     * Gets the color value for this TRowStyle.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this TRowStyle.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the inset value for this TRowStyle.
     * 
     * @return inset
     */
    public java.lang.String getInset() {
        return inset;
    }


    /**
     * Sets the inset value for this TRowStyle.
     * 
     * @param inset
     */
    public void setInset(java.lang.String inset) {
        this.inset = inset;
    }


    /**
     * Gets the insetBottom value for this TRowStyle.
     * 
     * @return insetBottom
     */
    public java.lang.String getInsetBottom() {
        return insetBottom;
    }


    /**
     * Sets the insetBottom value for this TRowStyle.
     * 
     * @param insetBottom
     */
    public void setInsetBottom(java.lang.String insetBottom) {
        this.insetBottom = insetBottom;
    }


    /**
     * Gets the insetLeft value for this TRowStyle.
     * 
     * @return insetLeft
     */
    public java.lang.String getInsetLeft() {
        return insetLeft;
    }


    /**
     * Sets the insetLeft value for this TRowStyle.
     * 
     * @param insetLeft
     */
    public void setInsetLeft(java.lang.String insetLeft) {
        this.insetLeft = insetLeft;
    }


    /**
     * Gets the insetRight value for this TRowStyle.
     * 
     * @return insetRight
     */
    public java.lang.String getInsetRight() {
        return insetRight;
    }


    /**
     * Sets the insetRight value for this TRowStyle.
     * 
     * @param insetRight
     */
    public void setInsetRight(java.lang.String insetRight) {
        this.insetRight = insetRight;
    }


    /**
     * Gets the insetTop value for this TRowStyle.
     * 
     * @return insetTop
     */
    public java.lang.String getInsetTop() {
        return insetTop;
    }


    /**
     * Sets the insetTop value for this TRowStyle.
     * 
     * @param insetTop
     */
    public void setInsetTop(java.lang.String insetTop) {
        this.insetTop = insetTop;
    }


    /**
     * Gets the paraStyle value for this TRowStyle.
     * 
     * @return paraStyle
     */
    public java.lang.String getParaStyle() {
        return paraStyle;
    }


    /**
     * Sets the paraStyle value for this TRowStyle.
     * 
     * @param paraStyle
     */
    public void setParaStyle(java.lang.String paraStyle) {
        this.paraStyle = paraStyle;
    }


    /**
     * Gets the shade value for this TRowStyle.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this TRowStyle.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the topGrid value for this TRowStyle.
     * 
     * @return topGrid
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TopGrid getTopGrid() {
        return topGrid;
    }


    /**
     * Sets the topGrid value for this TRowStyle.
     * 
     * @param topGrid
     */
    public void setTopGrid(com.socgen.sgs.api.quark.engine.integration.soap.generated.TopGrid topGrid) {
        this.topGrid = topGrid;
    }


    /**
     * Gets the valign value for this TRowStyle.
     * 
     * @return valign
     */
    public java.lang.String getValign() {
        return valign;
    }


    /**
     * Sets the valign value for this TRowStyle.
     * 
     * @param valign
     */
    public void setValign(java.lang.String valign) {
        this.valign = valign;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TRowStyle)) return false;
        TRowStyle other = (TRowStyle) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignment==null && other.getAlignment()==null) || 
             (this.alignment!=null &&
              this.alignment.equals(other.getAlignment()))) &&
            ((this.angle==null && other.getAngle()==null) || 
             (this.angle!=null &&
              this.angle.equals(other.getAngle()))) &&
            ((this.bottomGrid==null && other.getBottomGrid()==null) || 
             (this.bottomGrid!=null &&
              this.bottomGrid.equals(other.getBottomGrid()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.inset==null && other.getInset()==null) || 
             (this.inset!=null &&
              this.inset.equals(other.getInset()))) &&
            ((this.insetBottom==null && other.getInsetBottom()==null) || 
             (this.insetBottom!=null &&
              this.insetBottom.equals(other.getInsetBottom()))) &&
            ((this.insetLeft==null && other.getInsetLeft()==null) || 
             (this.insetLeft!=null &&
              this.insetLeft.equals(other.getInsetLeft()))) &&
            ((this.insetRight==null && other.getInsetRight()==null) || 
             (this.insetRight!=null &&
              this.insetRight.equals(other.getInsetRight()))) &&
            ((this.insetTop==null && other.getInsetTop()==null) || 
             (this.insetTop!=null &&
              this.insetTop.equals(other.getInsetTop()))) &&
            ((this.paraStyle==null && other.getParaStyle()==null) || 
             (this.paraStyle!=null &&
              this.paraStyle.equals(other.getParaStyle()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.topGrid==null && other.getTopGrid()==null) || 
             (this.topGrid!=null &&
              this.topGrid.equals(other.getTopGrid()))) &&
            ((this.valign==null && other.getValign()==null) || 
             (this.valign!=null &&
              this.valign.equals(other.getValign())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignment() != null) {
            _hashCode += getAlignment().hashCode();
        }
        if (getAngle() != null) {
            _hashCode += getAngle().hashCode();
        }
        if (getBottomGrid() != null) {
            _hashCode += getBottomGrid().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getInset() != null) {
            _hashCode += getInset().hashCode();
        }
        if (getInsetBottom() != null) {
            _hashCode += getInsetBottom().hashCode();
        }
        if (getInsetLeft() != null) {
            _hashCode += getInsetLeft().hashCode();
        }
        if (getInsetRight() != null) {
            _hashCode += getInsetRight().hashCode();
        }
        if (getInsetTop() != null) {
            _hashCode += getInsetTop().hashCode();
        }
        if (getParaStyle() != null) {
            _hashCode += getParaStyle().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getTopGrid() != null) {
            _hashCode += getTopGrid().hashCode();
        }
        if (getValign() != null) {
            _hashCode += getValign().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TRowStyle.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TRowStyle"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("angle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "angle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bottomGrid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "bottomGrid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "BottomGrid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insetBottom");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "insetBottom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insetLeft");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "insetLeft"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insetRight");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "insetRight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("insetTop");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "insetTop"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paraStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "paraStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topGrid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "topGrid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TopGrid"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valign");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "valign"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
