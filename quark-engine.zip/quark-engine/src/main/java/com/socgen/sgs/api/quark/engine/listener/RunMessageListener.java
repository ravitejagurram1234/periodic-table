package com.socgen.sgs.api.quark.engine.listener;

import com.socgen.sgs.api.quark.engine.dto.RunIdDto;
import com.socgen.sgs.api.quark.engine.service.ProcessRunService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class RunMessageListener {

    private final ProcessRunService processRunService;

    @RabbitListener(queues = "${queue.runqueue}")
    public void receiveMessage(RunIdDto runIdDto) {
        log.info("Received message from queue with runId: {}", runIdDto.getRunId());
        try {
            processRunService.runProcessor(runIdDto);
            log.info("Successfully processed runId: {}", runIdDto.getRunId());
        } catch (Exception e) {
            log.error("Error processing runId: {}", runIdDto.getRunId(), e);
            throw e;
        }
    }
}
