/**
 * Project.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Project  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Content[] contents;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink[] hyperlinks;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexSpecifications indexSpecifications;

    private java.lang.String jobJacket;

    private java.lang.String jobTicket;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout[] layouts;

    private java.lang.String projectName;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Publication[] publications;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs saveAs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Story[] stories;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TableStyle[] tablestyles;

    private java.lang.String XMLVersion;

    public Project() {
    }

    public Project(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Content[] contents,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink[] hyperlinks,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexSpecifications indexSpecifications,
           java.lang.String jobJacket,
           java.lang.String jobTicket,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout[] layouts,
           java.lang.String projectName,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Publication[] publications,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs saveAs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Story[] stories,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TableStyle[] tablestyles,
           java.lang.String XMLVersion) {
        super(
            request);
        this.contents = contents;
        this.hyperlinks = hyperlinks;
        this.indexSpecifications = indexSpecifications;
        this.jobJacket = jobJacket;
        this.jobTicket = jobTicket;
        this.layouts = layouts;
        this.projectName = projectName;
        this.publications = publications;
        this.saveAs = saveAs;
        this.stories = stories;
        this.tablestyles = tablestyles;
        this.XMLVersion = XMLVersion;
    }


    /**
     * Gets the contents value for this Project.
     * 
     * @return contents
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Content[] getContents() {
        return contents;
    }


    /**
     * Sets the contents value for this Project.
     * 
     * @param contents
     */
    public void setContents(com.socgen.sgs.api.quark.engine.integration.soap.generated.Content[] contents) {
        this.contents = contents;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Content getContents(int i) {
        return this.contents[i];
    }

    public void setContents(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Content _value) {
        this.contents[i] = _value;
    }


    /**
     * Gets the hyperlinks value for this Project.
     * 
     * @return hyperlinks
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink[] getHyperlinks() {
        return hyperlinks;
    }


    /**
     * Sets the hyperlinks value for this Project.
     * 
     * @param hyperlinks
     */
    public void setHyperlinks(com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink[] hyperlinks) {
        this.hyperlinks = hyperlinks;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink getHyperlinks(int i) {
        return this.hyperlinks[i];
    }

    public void setHyperlinks(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Hyperlink _value) {
        this.hyperlinks[i] = _value;
    }


    /**
     * Gets the indexSpecifications value for this Project.
     * 
     * @return indexSpecifications
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexSpecifications getIndexSpecifications() {
        return indexSpecifications;
    }


    /**
     * Sets the indexSpecifications value for this Project.
     * 
     * @param indexSpecifications
     */
    public void setIndexSpecifications(com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexSpecifications indexSpecifications) {
        this.indexSpecifications = indexSpecifications;
    }


    /**
     * Gets the jobJacket value for this Project.
     * 
     * @return jobJacket
     */
    public java.lang.String getJobJacket() {
        return jobJacket;
    }


    /**
     * Sets the jobJacket value for this Project.
     * 
     * @param jobJacket
     */
    public void setJobJacket(java.lang.String jobJacket) {
        this.jobJacket = jobJacket;
    }


    /**
     * Gets the jobTicket value for this Project.
     * 
     * @return jobTicket
     */
    public java.lang.String getJobTicket() {
        return jobTicket;
    }


    /**
     * Sets the jobTicket value for this Project.
     * 
     * @param jobTicket
     */
    public void setJobTicket(java.lang.String jobTicket) {
        this.jobTicket = jobTicket;
    }


    /**
     * Gets the layouts value for this Project.
     * 
     * @return layouts
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout[] getLayouts() {
        return layouts;
    }


    /**
     * Sets the layouts value for this Project.
     * 
     * @param layouts
     */
    public void setLayouts(com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout[] layouts) {
        this.layouts = layouts;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout getLayouts(int i) {
        return this.layouts[i];
    }

    public void setLayouts(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout _value) {
        this.layouts[i] = _value;
    }


    /**
     * Gets the projectName value for this Project.
     * 
     * @return projectName
     */
    public java.lang.String getProjectName() {
        return projectName;
    }


    /**
     * Sets the projectName value for this Project.
     * 
     * @param projectName
     */
    public void setProjectName(java.lang.String projectName) {
        this.projectName = projectName;
    }


    /**
     * Gets the publications value for this Project.
     * 
     * @return publications
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Publication[] getPublications() {
        return publications;
    }


    /**
     * Sets the publications value for this Project.
     * 
     * @param publications
     */
    public void setPublications(com.socgen.sgs.api.quark.engine.integration.soap.generated.Publication[] publications) {
        this.publications = publications;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Publication getPublications(int i) {
        return this.publications[i];
    }

    public void setPublications(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Publication _value) {
        this.publications[i] = _value;
    }


    /**
     * Gets the saveAs value for this Project.
     * 
     * @return saveAs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs getSaveAs() {
        return saveAs;
    }


    /**
     * Sets the saveAs value for this Project.
     * 
     * @param saveAs
     */
    public void setSaveAs(com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs saveAs) {
        this.saveAs = saveAs;
    }


    /**
     * Gets the stories value for this Project.
     * 
     * @return stories
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Story[] getStories() {
        return stories;
    }


    /**
     * Sets the stories value for this Project.
     * 
     * @param stories
     */
    public void setStories(com.socgen.sgs.api.quark.engine.integration.soap.generated.Story[] stories) {
        this.stories = stories;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Story getStories(int i) {
        return this.stories[i];
    }

    public void setStories(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Story _value) {
        this.stories[i] = _value;
    }


    /**
     * Gets the tablestyles value for this Project.
     * 
     * @return tablestyles
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TableStyle[] getTablestyles() {
        return tablestyles;
    }


    /**
     * Sets the tablestyles value for this Project.
     * 
     * @param tablestyles
     */
    public void setTablestyles(com.socgen.sgs.api.quark.engine.integration.soap.generated.TableStyle[] tablestyles) {
        this.tablestyles = tablestyles;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TableStyle getTablestyles(int i) {
        return this.tablestyles[i];
    }

    public void setTablestyles(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.TableStyle _value) {
        this.tablestyles[i] = _value;
    }


    /**
     * Gets the XMLVersion value for this Project.
     * 
     * @return XMLVersion
     */
    public java.lang.String getXMLVersion() {
        return XMLVersion;
    }


    /**
     * Sets the XMLVersion value for this Project.
     * 
     * @param XMLVersion
     */
    public void setXMLVersion(java.lang.String XMLVersion) {
        this.XMLVersion = XMLVersion;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Project)) return false;
        Project other = (Project) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.contents==null && other.getContents()==null) || 
             (this.contents!=null &&
              java.util.Arrays.equals(this.contents, other.getContents()))) &&
            ((this.hyperlinks==null && other.getHyperlinks()==null) || 
             (this.hyperlinks!=null &&
              java.util.Arrays.equals(this.hyperlinks, other.getHyperlinks()))) &&
            ((this.indexSpecifications==null && other.getIndexSpecifications()==null) || 
             (this.indexSpecifications!=null &&
              this.indexSpecifications.equals(other.getIndexSpecifications()))) &&
            ((this.jobJacket==null && other.getJobJacket()==null) || 
             (this.jobJacket!=null &&
              this.jobJacket.equals(other.getJobJacket()))) &&
            ((this.jobTicket==null && other.getJobTicket()==null) || 
             (this.jobTicket!=null &&
              this.jobTicket.equals(other.getJobTicket()))) &&
            ((this.layouts==null && other.getLayouts()==null) || 
             (this.layouts!=null &&
              java.util.Arrays.equals(this.layouts, other.getLayouts()))) &&
            ((this.projectName==null && other.getProjectName()==null) || 
             (this.projectName!=null &&
              this.projectName.equals(other.getProjectName()))) &&
            ((this.publications==null && other.getPublications()==null) || 
             (this.publications!=null &&
              java.util.Arrays.equals(this.publications, other.getPublications()))) &&
            ((this.saveAs==null && other.getSaveAs()==null) || 
             (this.saveAs!=null &&
              this.saveAs.equals(other.getSaveAs()))) &&
            ((this.stories==null && other.getStories()==null) || 
             (this.stories!=null &&
              java.util.Arrays.equals(this.stories, other.getStories()))) &&
            ((this.tablestyles==null && other.getTablestyles()==null) || 
             (this.tablestyles!=null &&
              java.util.Arrays.equals(this.tablestyles, other.getTablestyles()))) &&
            ((this.XMLVersion==null && other.getXMLVersion()==null) || 
             (this.XMLVersion!=null &&
              this.XMLVersion.equals(other.getXMLVersion())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getContents() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getContents());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getContents(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHyperlinks() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHyperlinks());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHyperlinks(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIndexSpecifications() != null) {
            _hashCode += getIndexSpecifications().hashCode();
        }
        if (getJobJacket() != null) {
            _hashCode += getJobJacket().hashCode();
        }
        if (getJobTicket() != null) {
            _hashCode += getJobTicket().hashCode();
        }
        if (getLayouts() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLayouts());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLayouts(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProjectName() != null) {
            _hashCode += getProjectName().hashCode();
        }
        if (getPublications() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPublications());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPublications(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSaveAs() != null) {
            _hashCode += getSaveAs().hashCode();
        }
        if (getStories() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getStories());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getStories(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTablestyles() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTablestyles());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTablestyles(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getXMLVersion() != null) {
            _hashCode += getXMLVersion().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Project.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Project"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contents");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "contents"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Content"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hyperlinks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hyperlinks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Hyperlink"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indexSpecifications");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "indexSpecifications"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexSpecifications"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jobJacket");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "jobJacket"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jobTicket");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "jobTicket"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layouts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "layouts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Layout"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "projectName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publications");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "publications"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Publication"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saveAs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "saveAs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "SaveAs"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stories");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "stories"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Story"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tablestyles");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "tablestyles"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TableStyle"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("XMLVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "XMLVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
