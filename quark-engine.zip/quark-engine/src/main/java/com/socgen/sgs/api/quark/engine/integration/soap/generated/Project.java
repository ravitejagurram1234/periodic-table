/**
 * Project.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Project  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String XMLVersion;

    private java.lang.String jobJacket;

    private java.lang.String jobTicket;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout[] layouts;

    private java.lang.String projectName;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs saveAs;

    public Project() {
    }

    public Project(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String XMLVersion,
           java.lang.String jobJacket,
           java.lang.String jobTicket,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout[] layouts,
           java.lang.String projectName,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs saveAs) {
        super(
            request);
        this.XMLVersion = XMLVersion;
        this.jobJacket = jobJacket;
        this.jobTicket = jobTicket;
        this.layouts = layouts;
        this.projectName = projectName;
        this.saveAs = saveAs;
    }


    /**
     * Gets the XMLVersion value for this Project.
     * 
     * @return XMLVersion
     */
    public java.lang.String getXMLVersion() {
        return XMLVersion;
    }


    /**
     * Sets the XMLVersion value for this Project.
     * 
     * @param XMLVersion
     */
    public void setXMLVersion(java.lang.String XMLVersion) {
        this.XMLVersion = XMLVersion;
    }


    /**
     * Gets the jobJacket value for this Project.
     * 
     * @return jobJacket
     */
    public java.lang.String getJobJacket() {
        return jobJacket;
    }


    /**
     * Sets the jobJacket value for this Project.
     * 
     * @param jobJacket
     */
    public void setJobJacket(java.lang.String jobJacket) {
        this.jobJacket = jobJacket;
    }


    /**
     * Gets the jobTicket value for this Project.
     * 
     * @return jobTicket
     */
    public java.lang.String getJobTicket() {
        return jobTicket;
    }


    /**
     * Sets the jobTicket value for this Project.
     * 
     * @param jobTicket
     */
    public void setJobTicket(java.lang.String jobTicket) {
        this.jobTicket = jobTicket;
    }


    /**
     * Gets the layouts value for this Project.
     * 
     * @return layouts
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout[] getLayouts() {
        return layouts;
    }


    /**
     * Sets the layouts value for this Project.
     * 
     * @param layouts
     */
    public void setLayouts(com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout[] layouts) {
        this.layouts = layouts;
    }


    /**
     * Gets the projectName value for this Project.
     * 
     * @return projectName
     */
    public java.lang.String getProjectName() {
        return projectName;
    }


    /**
     * Sets the projectName value for this Project.
     * 
     * @param projectName
     */
    public void setProjectName(java.lang.String projectName) {
        this.projectName = projectName;
    }


    /**
     * Gets the saveAs value for this Project.
     * 
     * @return saveAs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs getSaveAs() {
        return saveAs;
    }


    /**
     * Sets the saveAs value for this Project.
     * 
     * @param saveAs
     */
    public void setSaveAs(com.socgen.sgs.api.quark.engine.integration.soap.generated.SaveAs saveAs) {
        this.saveAs = saveAs;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Project)) return false;
        Project other = (Project) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.XMLVersion==null && other.getXMLVersion()==null) || 
             (this.XMLVersion!=null &&
              this.XMLVersion.equals(other.getXMLVersion()))) &&
            ((this.jobJacket==null && other.getJobJacket()==null) || 
             (this.jobJacket!=null &&
              this.jobJacket.equals(other.getJobJacket()))) &&
            ((this.jobTicket==null && other.getJobTicket()==null) || 
             (this.jobTicket!=null &&
              this.jobTicket.equals(other.getJobTicket()))) &&
            ((this.layouts==null && other.getLayouts()==null) || 
             (this.layouts!=null &&
              java.util.Arrays.equals(this.layouts, other.getLayouts()))) &&
            ((this.projectName==null && other.getProjectName()==null) || 
             (this.projectName!=null &&
              this.projectName.equals(other.getProjectName()))) &&
            ((this.saveAs==null && other.getSaveAs()==null) || 
             (this.saveAs!=null &&
              this.saveAs.equals(other.getSaveAs())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getXMLVersion() != null) {
            _hashCode += getXMLVersion().hashCode();
        }
        if (getJobJacket() != null) {
            _hashCode += getJobJacket().hashCode();
        }
        if (getJobTicket() != null) {
            _hashCode += getJobTicket().hashCode();
        }
        if (getLayouts() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLayouts());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLayouts(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProjectName() != null) {
            _hashCode += getProjectName().hashCode();
        }
        if (getSaveAs() != null) {
            _hashCode += getSaveAs().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Project.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Project"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("XMLVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("", "XMLVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jobJacket");
        elemField.setXmlName(new javax.xml.namespace.QName("", "jobJacket"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jobTicket");
        elemField.setXmlName(new javax.xml.namespace.QName("", "jobTicket"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layouts");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layouts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Layout"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "projectName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saveAs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "saveAs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "SaveAs"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
