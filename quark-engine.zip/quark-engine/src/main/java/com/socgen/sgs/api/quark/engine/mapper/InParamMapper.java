package com.socgen.sgs.api.quark.engine.mapper;
import com.socgen.sgs.api.quark.engine.domain.InParam;
import org.springframework.stereotype.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
@Component
public class InParamMapper {
    public InParam mapFromResultSet(ResultSet rs) throws SQLException {
        return new InParam(
                rs.getString("nom_parametre"),
                rs.getInt("input_data_type"),
                rs.getString("valeur")
        );
    }
}
