/**
 * NameValueParam.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class NameValueParam  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String contentType;

    private java.lang.String paramName;

    private byte[] streamValue;

    private java.lang.String textValue;

    public NameValueParam() {
    }

    public NameValueParam(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String contentType,
           java.lang.String paramName,
           byte[] streamValue,
           java.lang.String textValue) {
        super(
            request);
        this.contentType = contentType;
        this.paramName = paramName;
        this.streamValue = streamValue;
        this.textValue = textValue;
    }


    /**
     * Gets the contentType value for this NameValueParam.
     * 
     * @return contentType
     */
    public java.lang.String getContentType() {
        return contentType;
    }


    /**
     * Sets the contentType value for this NameValueParam.
     * 
     * @param contentType
     */
    public void setContentType(java.lang.String contentType) {
        this.contentType = contentType;
    }


    /**
     * Gets the paramName value for this NameValueParam.
     * 
     * @return paramName
     */
    public java.lang.String getParamName() {
        return paramName;
    }


    /**
     * Sets the paramName value for this NameValueParam.
     * 
     * @param paramName
     */
    public void setParamName(java.lang.String paramName) {
        this.paramName = paramName;
    }


    /**
     * Gets the streamValue value for this NameValueParam.
     * 
     * @return streamValue
     */
    public byte[] getStreamValue() {
        return streamValue;
    }


    /**
     * Sets the streamValue value for this NameValueParam.
     * 
     * @param streamValue
     */
    public void setStreamValue(byte[] streamValue) {
        this.streamValue = streamValue;
    }


    /**
     * Gets the textValue value for this NameValueParam.
     * 
     * @return textValue
     */
    public java.lang.String getTextValue() {
        return textValue;
    }


    /**
     * Sets the textValue value for this NameValueParam.
     * 
     * @param textValue
     */
    public void setTextValue(java.lang.String textValue) {
        this.textValue = textValue;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NameValueParam)) return false;
        NameValueParam other = (NameValueParam) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.contentType==null && other.getContentType()==null) || 
             (this.contentType!=null &&
              this.contentType.equals(other.getContentType()))) &&
            ((this.paramName==null && other.getParamName()==null) || 
             (this.paramName!=null &&
              this.paramName.equals(other.getParamName()))) &&
            ((this.streamValue==null && other.getStreamValue()==null) || 
             (this.streamValue!=null &&
              java.util.Arrays.equals(this.streamValue, other.getStreamValue()))) &&
            ((this.textValue==null && other.getTextValue()==null) || 
             (this.textValue!=null &&
              this.textValue.equals(other.getTextValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getContentType() != null) {
            _hashCode += getContentType().hashCode();
        }
        if (getParamName() != null) {
            _hashCode += getParamName().hashCode();
        }
        if (getStreamValue() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getStreamValue());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getStreamValue(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTextValue() != null) {
            _hashCode += getTextValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NameValueParam.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "NameValueParam"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contentType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paramName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paramName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("streamValue");
        elemField.setXmlName(new javax.xml.namespace.QName("", "streamValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textValue");
        elemField.setXmlName(new javax.xml.namespace.QName("", "textValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
