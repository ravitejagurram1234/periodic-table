package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;

import java.time.LocalDate;

/**
 * DAO for inserting generated documents into QXP_DOCUMENT.
 *
 * Cross-reference: .NET Proxy_Document.Insert_Document
 * Oracle: QXP_PK_RUN.Insert_Document
 */
public interface InsertDocumentDao {

    /**
     * Insert a document into the database.
     *
     * @param document       the document to insert
     * @param idSousCategorie sub-category (6=QXP, 7=PDF, 8=DOC)
     * @param idFndCode      fund code
     * @param idUnitCode     unit/part code
     * @param dateEcheance   maturity date
     * @param idRun          run ID
     * @return the generated document ID
     */
    int insertDocument(DocumentDomain document, int idSousCategorie,
                       String idFndCode, String idUnitCode,
                       LocalDate dateEcheance, int idRun);
}