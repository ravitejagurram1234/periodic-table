package com.socgen.sgs.api.quark.engine.enums;

/**
 * Type of template TBox (box content type).
 *
 * Cross-reference: QXP.Engine.Core.TBox_Type
 */
public enum TBoxTypeEnum {

    /** Unknown box type. */
    CT_UNKNOWN,

    /** Presentation box (e.g., rule/line — no content). */
    CT_NONE,

    /** Text content box. */
    CT_TEXT,

    /** Picture/image content box. */
    CT_PICT;

    /**
     * Parse a string to TBoxTypeEnum (case-insensitive).
     *
     * @param value the string value (e.g., "CT_TEXT")
     * @return the matching enum, or CT_UNKNOWN if not found
     */
    public static TBoxTypeEnum fromString(String value) {
        if (value == null || value.isBlank()) {
            return CT_UNKNOWN;
        }
        try {
            return valueOf(value.toUpperCase());
        } catch (IllegalArgumentException e) {
            return CT_UNKNOWN;
        }
    }
}