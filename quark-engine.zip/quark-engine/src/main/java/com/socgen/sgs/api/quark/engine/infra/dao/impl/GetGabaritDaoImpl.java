package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritDao;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

/**
 * DAO implementation that calls the Oracle function QXP_PK_RUN.Get_Gabarit
 * to retrieve template documents.
 */
@Repository
@Slf4j
public class GetGabaritDaoImpl implements GetGabaritDao {

    private static final String RESULT_KEY = "result_cursor";
    private final SimpleJdbcCall getGabaritCall;

    @Autowired
    public GetGabaritDaoImpl(DataSource dataSource) {
        // Get_Gabarit is a FUNCTION in QXP_PK_RUN package that returns a REF CURSOR
        this.getGabaritCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withFunctionName("Get_Gabarit")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR,
                                (rs, rowNum) -> mapFromResultSet(rs)),
                        new SqlParameter("p_id_gabarit", Types.NUMERIC)
                );
    }

    @Override
    public DocumentDomain getGabarit(Integer idGabarit) {
        log.info("Fetching gabarit for idGabarit: {}", idGabarit);

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_gabarit", idGabarit);

        try {
            Map<String, Object> result = getGabaritCall.execute(params);

            @SuppressWarnings("unchecked")
            List<DocumentDomain> rows = (List<DocumentDomain>) result.get(RESULT_KEY);

            if (rows == null || rows.isEmpty()) {
                log.error("No gabarit found for idGabarit: {}", idGabarit);
                throw new IllegalArgumentException(
                        "No gabarit found for idGabarit: " + idGabarit);
            }

            DocumentDomain gabarit = rows.get(0);
            log.info("Successfully retrieved gabarit for idGabarit: {}", idGabarit);
            return gabarit;

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error fetching gabarit for idGabarit: {}", idGabarit, e);
            throw new RuntimeException("Failed to fetch gabarit for idGabarit: " + idGabarit, e);
        }
    }

    /**
     * Maps a ResultSet row to a DocumentDomain object.
     */
    private DocumentDomain mapFromResultSet(ResultSet rs) throws SQLException {
        DocumentDomain doc = new DocumentDomain();

        doc.setId(rs.getInt("id_gabarit"));
        doc.setName(rs.getString("nom"));
        doc.setFormat("QXP");
        doc.setPrefix(DocumentDomain.FILE_GABARIT_PREFIX);
        doc.setData(rs.getBytes("contenu"));
        doc.setIdLangue(rs.getInt("id_langue"));
        doc.setGabarit(true);

        // Generate file names
        if (doc.getId() != null && doc.getPrefix() != null && doc.getFormat() != null) {
            doc.setFileName(String.format("%s_%d.%s", doc.getPrefix(), doc.getId(), doc.getFormat()));
        }

        return doc;
    }
}

