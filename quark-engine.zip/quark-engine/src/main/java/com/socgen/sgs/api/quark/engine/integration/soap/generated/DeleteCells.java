/**
 * DeleteCells.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class DeleteCells  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String baseIndex;

    private java.lang.String deleteCount;

    private java.lang.String type;

    public DeleteCells() {
    }

    public DeleteCells(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String baseIndex,
           java.lang.String deleteCount,
           java.lang.String type) {
        super(
            request);
        this.baseIndex = baseIndex;
        this.deleteCount = deleteCount;
        this.type = type;
    }


    /**
     * Gets the baseIndex value for this DeleteCells.
     * 
     * @return baseIndex
     */
    public java.lang.String getBaseIndex() {
        return baseIndex;
    }


    /**
     * Sets the baseIndex value for this DeleteCells.
     * 
     * @param baseIndex
     */
    public void setBaseIndex(java.lang.String baseIndex) {
        this.baseIndex = baseIndex;
    }


    /**
     * Gets the deleteCount value for this DeleteCells.
     * 
     * @return deleteCount
     */
    public java.lang.String getDeleteCount() {
        return deleteCount;
    }


    /**
     * Sets the deleteCount value for this DeleteCells.
     * 
     * @param deleteCount
     */
    public void setDeleteCount(java.lang.String deleteCount) {
        this.deleteCount = deleteCount;
    }


    /**
     * Gets the type value for this DeleteCells.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this DeleteCells.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DeleteCells)) return false;
        DeleteCells other = (DeleteCells) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.baseIndex==null && other.getBaseIndex()==null) || 
             (this.baseIndex!=null &&
              this.baseIndex.equals(other.getBaseIndex()))) &&
            ((this.deleteCount==null && other.getDeleteCount()==null) || 
             (this.deleteCount!=null &&
              this.deleteCount.equals(other.getDeleteCount()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBaseIndex() != null) {
            _hashCode += getBaseIndex().hashCode();
        }
        if (getDeleteCount() != null) {
            _hashCode += getDeleteCount().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DeleteCells.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "DeleteCells"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("baseIndex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "baseIndex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deleteCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "deleteCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
