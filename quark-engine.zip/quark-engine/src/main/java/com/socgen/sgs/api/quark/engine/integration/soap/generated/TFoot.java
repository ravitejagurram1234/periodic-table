/**
 * TFoot.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class TFoot  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TRow[] trows;

    public TFoot() {
    }

    public TFoot(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TRow[] trows) {
        super(
            request);
        this.trows = trows;
    }


    /**
     * Gets the trows value for this TFoot.
     * 
     * @return trows
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TRow[] getTrows() {
        return trows;
    }


    /**
     * Sets the trows value for this TFoot.
     * 
     * @param trows
     */
    public void setTrows(com.socgen.sgs.api.quark.engine.integration.soap.generated.TRow[] trows) {
        this.trows = trows;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TRow getTrows(int i) {
        return this.trows[i];
    }

    public void setTrows(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.TRow _value) {
        this.trows[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TFoot)) return false;
        TFoot other = (TFoot) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.trows==null && other.getTrows()==null) || 
             (this.trows!=null &&
              java.util.Arrays.equals(this.trows, other.getTrows())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getTrows() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTrows());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTrows(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TFoot.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TFoot"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trows");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "trows"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TRow"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
