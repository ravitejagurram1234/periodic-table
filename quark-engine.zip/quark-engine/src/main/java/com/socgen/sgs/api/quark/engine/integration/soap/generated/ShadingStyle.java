/**
 * ShadingStyle.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class ShadingStyle  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String borderBottomPadding;

    private java.lang.String borderCapacity;

    private java.lang.String borderColor;

    private java.lang.String borderLeftPadding;

    private java.lang.String borderRightPadding;

    private java.lang.String borderShade;

    private java.lang.String borderStyle;

    private java.lang.String borderTopPadding;

    private java.lang.String borderWidth;

    private java.lang.String bottomBorder;

    private java.lang.String bottomPadding;

    private java.lang.String clipToBox;

    private java.lang.String color;

    private java.lang.String leftBorder;

    private java.lang.String leftPadding;

    private java.lang.String length;

    private java.lang.String name;

    private java.lang.String opacity;

    private java.lang.String rightBorder;

    private java.lang.String rightPadding;

    private java.lang.String shade;

    private java.lang.String topBorder;

    private java.lang.String topPadding;

    public ShadingStyle() {
    }

    public ShadingStyle(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String borderBottomPadding,
           java.lang.String borderCapacity,
           java.lang.String borderColor,
           java.lang.String borderLeftPadding,
           java.lang.String borderRightPadding,
           java.lang.String borderShade,
           java.lang.String borderStyle,
           java.lang.String borderTopPadding,
           java.lang.String borderWidth,
           java.lang.String bottomBorder,
           java.lang.String bottomPadding,
           java.lang.String clipToBox,
           java.lang.String color,
           java.lang.String leftBorder,
           java.lang.String leftPadding,
           java.lang.String length,
           java.lang.String name,
           java.lang.String opacity,
           java.lang.String rightBorder,
           java.lang.String rightPadding,
           java.lang.String shade,
           java.lang.String topBorder,
           java.lang.String topPadding) {
        super(
            request);
        this.borderBottomPadding = borderBottomPadding;
        this.borderCapacity = borderCapacity;
        this.borderColor = borderColor;
        this.borderLeftPadding = borderLeftPadding;
        this.borderRightPadding = borderRightPadding;
        this.borderShade = borderShade;
        this.borderStyle = borderStyle;
        this.borderTopPadding = borderTopPadding;
        this.borderWidth = borderWidth;
        this.bottomBorder = bottomBorder;
        this.bottomPadding = bottomPadding;
        this.clipToBox = clipToBox;
        this.color = color;
        this.leftBorder = leftBorder;
        this.leftPadding = leftPadding;
        this.length = length;
        this.name = name;
        this.opacity = opacity;
        this.rightBorder = rightBorder;
        this.rightPadding = rightPadding;
        this.shade = shade;
        this.topBorder = topBorder;
        this.topPadding = topPadding;
    }


    /**
     * Gets the borderBottomPadding value for this ShadingStyle.
     * 
     * @return borderBottomPadding
     */
    public java.lang.String getBorderBottomPadding() {
        return borderBottomPadding;
    }


    /**
     * Sets the borderBottomPadding value for this ShadingStyle.
     * 
     * @param borderBottomPadding
     */
    public void setBorderBottomPadding(java.lang.String borderBottomPadding) {
        this.borderBottomPadding = borderBottomPadding;
    }


    /**
     * Gets the borderCapacity value for this ShadingStyle.
     * 
     * @return borderCapacity
     */
    public java.lang.String getBorderCapacity() {
        return borderCapacity;
    }


    /**
     * Sets the borderCapacity value for this ShadingStyle.
     * 
     * @param borderCapacity
     */
    public void setBorderCapacity(java.lang.String borderCapacity) {
        this.borderCapacity = borderCapacity;
    }


    /**
     * Gets the borderColor value for this ShadingStyle.
     * 
     * @return borderColor
     */
    public java.lang.String getBorderColor() {
        return borderColor;
    }


    /**
     * Sets the borderColor value for this ShadingStyle.
     * 
     * @param borderColor
     */
    public void setBorderColor(java.lang.String borderColor) {
        this.borderColor = borderColor;
    }


    /**
     * Gets the borderLeftPadding value for this ShadingStyle.
     * 
     * @return borderLeftPadding
     */
    public java.lang.String getBorderLeftPadding() {
        return borderLeftPadding;
    }


    /**
     * Sets the borderLeftPadding value for this ShadingStyle.
     * 
     * @param borderLeftPadding
     */
    public void setBorderLeftPadding(java.lang.String borderLeftPadding) {
        this.borderLeftPadding = borderLeftPadding;
    }


    /**
     * Gets the borderRightPadding value for this ShadingStyle.
     * 
     * @return borderRightPadding
     */
    public java.lang.String getBorderRightPadding() {
        return borderRightPadding;
    }


    /**
     * Sets the borderRightPadding value for this ShadingStyle.
     * 
     * @param borderRightPadding
     */
    public void setBorderRightPadding(java.lang.String borderRightPadding) {
        this.borderRightPadding = borderRightPadding;
    }


    /**
     * Gets the borderShade value for this ShadingStyle.
     * 
     * @return borderShade
     */
    public java.lang.String getBorderShade() {
        return borderShade;
    }


    /**
     * Sets the borderShade value for this ShadingStyle.
     * 
     * @param borderShade
     */
    public void setBorderShade(java.lang.String borderShade) {
        this.borderShade = borderShade;
    }


    /**
     * Gets the borderStyle value for this ShadingStyle.
     * 
     * @return borderStyle
     */
    public java.lang.String getBorderStyle() {
        return borderStyle;
    }


    /**
     * Sets the borderStyle value for this ShadingStyle.
     * 
     * @param borderStyle
     */
    public void setBorderStyle(java.lang.String borderStyle) {
        this.borderStyle = borderStyle;
    }


    /**
     * Gets the borderTopPadding value for this ShadingStyle.
     * 
     * @return borderTopPadding
     */
    public java.lang.String getBorderTopPadding() {
        return borderTopPadding;
    }


    /**
     * Sets the borderTopPadding value for this ShadingStyle.
     * 
     * @param borderTopPadding
     */
    public void setBorderTopPadding(java.lang.String borderTopPadding) {
        this.borderTopPadding = borderTopPadding;
    }


    /**
     * Gets the borderWidth value for this ShadingStyle.
     * 
     * @return borderWidth
     */
    public java.lang.String getBorderWidth() {
        return borderWidth;
    }


    /**
     * Sets the borderWidth value for this ShadingStyle.
     * 
     * @param borderWidth
     */
    public void setBorderWidth(java.lang.String borderWidth) {
        this.borderWidth = borderWidth;
    }


    /**
     * Gets the bottomBorder value for this ShadingStyle.
     * 
     * @return bottomBorder
     */
    public java.lang.String getBottomBorder() {
        return bottomBorder;
    }


    /**
     * Sets the bottomBorder value for this ShadingStyle.
     * 
     * @param bottomBorder
     */
    public void setBottomBorder(java.lang.String bottomBorder) {
        this.bottomBorder = bottomBorder;
    }


    /**
     * Gets the bottomPadding value for this ShadingStyle.
     * 
     * @return bottomPadding
     */
    public java.lang.String getBottomPadding() {
        return bottomPadding;
    }


    /**
     * Sets the bottomPadding value for this ShadingStyle.
     * 
     * @param bottomPadding
     */
    public void setBottomPadding(java.lang.String bottomPadding) {
        this.bottomPadding = bottomPadding;
    }


    /**
     * Gets the clipToBox value for this ShadingStyle.
     * 
     * @return clipToBox
     */
    public java.lang.String getClipToBox() {
        return clipToBox;
    }


    /**
     * Sets the clipToBox value for this ShadingStyle.
     * 
     * @param clipToBox
     */
    public void setClipToBox(java.lang.String clipToBox) {
        this.clipToBox = clipToBox;
    }


    /**
     * Gets the color value for this ShadingStyle.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this ShadingStyle.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the leftBorder value for this ShadingStyle.
     * 
     * @return leftBorder
     */
    public java.lang.String getLeftBorder() {
        return leftBorder;
    }


    /**
     * Sets the leftBorder value for this ShadingStyle.
     * 
     * @param leftBorder
     */
    public void setLeftBorder(java.lang.String leftBorder) {
        this.leftBorder = leftBorder;
    }


    /**
     * Gets the leftPadding value for this ShadingStyle.
     * 
     * @return leftPadding
     */
    public java.lang.String getLeftPadding() {
        return leftPadding;
    }


    /**
     * Sets the leftPadding value for this ShadingStyle.
     * 
     * @param leftPadding
     */
    public void setLeftPadding(java.lang.String leftPadding) {
        this.leftPadding = leftPadding;
    }


    /**
     * Gets the length value for this ShadingStyle.
     * 
     * @return length
     */
    public java.lang.String getLength() {
        return length;
    }


    /**
     * Sets the length value for this ShadingStyle.
     * 
     * @param length
     */
    public void setLength(java.lang.String length) {
        this.length = length;
    }


    /**
     * Gets the name value for this ShadingStyle.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this ShadingStyle.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the opacity value for this ShadingStyle.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this ShadingStyle.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the rightBorder value for this ShadingStyle.
     * 
     * @return rightBorder
     */
    public java.lang.String getRightBorder() {
        return rightBorder;
    }


    /**
     * Sets the rightBorder value for this ShadingStyle.
     * 
     * @param rightBorder
     */
    public void setRightBorder(java.lang.String rightBorder) {
        this.rightBorder = rightBorder;
    }


    /**
     * Gets the rightPadding value for this ShadingStyle.
     * 
     * @return rightPadding
     */
    public java.lang.String getRightPadding() {
        return rightPadding;
    }


    /**
     * Sets the rightPadding value for this ShadingStyle.
     * 
     * @param rightPadding
     */
    public void setRightPadding(java.lang.String rightPadding) {
        this.rightPadding = rightPadding;
    }


    /**
     * Gets the shade value for this ShadingStyle.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this ShadingStyle.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the topBorder value for this ShadingStyle.
     * 
     * @return topBorder
     */
    public java.lang.String getTopBorder() {
        return topBorder;
    }


    /**
     * Sets the topBorder value for this ShadingStyle.
     * 
     * @param topBorder
     */
    public void setTopBorder(java.lang.String topBorder) {
        this.topBorder = topBorder;
    }


    /**
     * Gets the topPadding value for this ShadingStyle.
     * 
     * @return topPadding
     */
    public java.lang.String getTopPadding() {
        return topPadding;
    }


    /**
     * Sets the topPadding value for this ShadingStyle.
     * 
     * @param topPadding
     */
    public void setTopPadding(java.lang.String topPadding) {
        this.topPadding = topPadding;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ShadingStyle)) return false;
        ShadingStyle other = (ShadingStyle) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.borderBottomPadding==null && other.getBorderBottomPadding()==null) || 
             (this.borderBottomPadding!=null &&
              this.borderBottomPadding.equals(other.getBorderBottomPadding()))) &&
            ((this.borderCapacity==null && other.getBorderCapacity()==null) || 
             (this.borderCapacity!=null &&
              this.borderCapacity.equals(other.getBorderCapacity()))) &&
            ((this.borderColor==null && other.getBorderColor()==null) || 
             (this.borderColor!=null &&
              this.borderColor.equals(other.getBorderColor()))) &&
            ((this.borderLeftPadding==null && other.getBorderLeftPadding()==null) || 
             (this.borderLeftPadding!=null &&
              this.borderLeftPadding.equals(other.getBorderLeftPadding()))) &&
            ((this.borderRightPadding==null && other.getBorderRightPadding()==null) || 
             (this.borderRightPadding!=null &&
              this.borderRightPadding.equals(other.getBorderRightPadding()))) &&
            ((this.borderShade==null && other.getBorderShade()==null) || 
             (this.borderShade!=null &&
              this.borderShade.equals(other.getBorderShade()))) &&
            ((this.borderStyle==null && other.getBorderStyle()==null) || 
             (this.borderStyle!=null &&
              this.borderStyle.equals(other.getBorderStyle()))) &&
            ((this.borderTopPadding==null && other.getBorderTopPadding()==null) || 
             (this.borderTopPadding!=null &&
              this.borderTopPadding.equals(other.getBorderTopPadding()))) &&
            ((this.borderWidth==null && other.getBorderWidth()==null) || 
             (this.borderWidth!=null &&
              this.borderWidth.equals(other.getBorderWidth()))) &&
            ((this.bottomBorder==null && other.getBottomBorder()==null) || 
             (this.bottomBorder!=null &&
              this.bottomBorder.equals(other.getBottomBorder()))) &&
            ((this.bottomPadding==null && other.getBottomPadding()==null) || 
             (this.bottomPadding!=null &&
              this.bottomPadding.equals(other.getBottomPadding()))) &&
            ((this.clipToBox==null && other.getClipToBox()==null) || 
             (this.clipToBox!=null &&
              this.clipToBox.equals(other.getClipToBox()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.leftBorder==null && other.getLeftBorder()==null) || 
             (this.leftBorder!=null &&
              this.leftBorder.equals(other.getLeftBorder()))) &&
            ((this.leftPadding==null && other.getLeftPadding()==null) || 
             (this.leftPadding!=null &&
              this.leftPadding.equals(other.getLeftPadding()))) &&
            ((this.length==null && other.getLength()==null) || 
             (this.length!=null &&
              this.length.equals(other.getLength()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.rightBorder==null && other.getRightBorder()==null) || 
             (this.rightBorder!=null &&
              this.rightBorder.equals(other.getRightBorder()))) &&
            ((this.rightPadding==null && other.getRightPadding()==null) || 
             (this.rightPadding!=null &&
              this.rightPadding.equals(other.getRightPadding()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.topBorder==null && other.getTopBorder()==null) || 
             (this.topBorder!=null &&
              this.topBorder.equals(other.getTopBorder()))) &&
            ((this.topPadding==null && other.getTopPadding()==null) || 
             (this.topPadding!=null &&
              this.topPadding.equals(other.getTopPadding())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBorderBottomPadding() != null) {
            _hashCode += getBorderBottomPadding().hashCode();
        }
        if (getBorderCapacity() != null) {
            _hashCode += getBorderCapacity().hashCode();
        }
        if (getBorderColor() != null) {
            _hashCode += getBorderColor().hashCode();
        }
        if (getBorderLeftPadding() != null) {
            _hashCode += getBorderLeftPadding().hashCode();
        }
        if (getBorderRightPadding() != null) {
            _hashCode += getBorderRightPadding().hashCode();
        }
        if (getBorderShade() != null) {
            _hashCode += getBorderShade().hashCode();
        }
        if (getBorderStyle() != null) {
            _hashCode += getBorderStyle().hashCode();
        }
        if (getBorderTopPadding() != null) {
            _hashCode += getBorderTopPadding().hashCode();
        }
        if (getBorderWidth() != null) {
            _hashCode += getBorderWidth().hashCode();
        }
        if (getBottomBorder() != null) {
            _hashCode += getBottomBorder().hashCode();
        }
        if (getBottomPadding() != null) {
            _hashCode += getBottomPadding().hashCode();
        }
        if (getClipToBox() != null) {
            _hashCode += getClipToBox().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getLeftBorder() != null) {
            _hashCode += getLeftBorder().hashCode();
        }
        if (getLeftPadding() != null) {
            _hashCode += getLeftPadding().hashCode();
        }
        if (getLength() != null) {
            _hashCode += getLength().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getRightBorder() != null) {
            _hashCode += getRightBorder().hashCode();
        }
        if (getRightPadding() != null) {
            _hashCode += getRightPadding().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getTopBorder() != null) {
            _hashCode += getTopBorder().hashCode();
        }
        if (getTopPadding() != null) {
            _hashCode += getTopPadding().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ShadingStyle.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ShadingStyle"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderBottomPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderBottomPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderCapacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderCapacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderColor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderColor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderLeftPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderLeftPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderRightPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderRightPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderShade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderShade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderTopPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderTopPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("borderWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "borderWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bottomBorder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "bottomBorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bottomPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "bottomPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clipToBox");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "clipToBox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftBorder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "leftBorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leftPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "leftPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("length");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "length"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightBorder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rightBorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rightPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rightPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topBorder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "topBorder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topPadding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "topPadding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
