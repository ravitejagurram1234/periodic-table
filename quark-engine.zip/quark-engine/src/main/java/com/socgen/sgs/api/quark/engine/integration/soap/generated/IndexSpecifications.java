/**
 * IndexSpecifications.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class IndexSpecifications  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexStyle[] indexStyles;

    public IndexSpecifications() {
    }

    public IndexSpecifications(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexStyle[] indexStyles) {
        super(
            request);
        this.indexStyles = indexStyles;
    }


    /**
     * Gets the indexStyles value for this IndexSpecifications.
     * 
     * @return indexStyles
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexStyle[] getIndexStyles() {
        return indexStyles;
    }


    /**
     * Sets the indexStyles value for this IndexSpecifications.
     * 
     * @param indexStyles
     */
    public void setIndexStyles(com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexStyle[] indexStyles) {
        this.indexStyles = indexStyles;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexStyle getIndexStyles(int i) {
        return this.indexStyles[i];
    }

    public void setIndexStyles(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexStyle _value) {
        this.indexStyles[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IndexSpecifications)) return false;
        IndexSpecifications other = (IndexSpecifications) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.indexStyles==null && other.getIndexStyles()==null) || 
             (this.indexStyles!=null &&
              java.util.Arrays.equals(this.indexStyles, other.getIndexStyles())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getIndexStyles() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIndexStyles());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIndexStyles(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IndexSpecifications.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexSpecifications"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indexStyles");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "indexStyles"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexStyle"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
