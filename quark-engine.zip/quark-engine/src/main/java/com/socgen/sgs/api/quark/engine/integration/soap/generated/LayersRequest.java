/**
 * LayersRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class LayersRequest  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String addLayer;

    private java.lang.String allLayers;

    private java.lang.String deleteLayer;

    private java.lang.String keepRunaround;

    private java.lang.String layer;

    private java.lang.String layerAttribute;

    private java.lang.String locked;

    private java.lang.String name;

    private java.lang.String suppressOutput;

    private java.lang.String visible;

    public LayersRequest() {
    }

    public LayersRequest(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String addLayer,
           java.lang.String allLayers,
           java.lang.String deleteLayer,
           java.lang.String keepRunaround,
           java.lang.String layer,
           java.lang.String layerAttribute,
           java.lang.String locked,
           java.lang.String name,
           java.lang.String suppressOutput,
           java.lang.String visible) {
        super(
            request);
        this.addLayer = addLayer;
        this.allLayers = allLayers;
        this.deleteLayer = deleteLayer;
        this.keepRunaround = keepRunaround;
        this.layer = layer;
        this.layerAttribute = layerAttribute;
        this.locked = locked;
        this.name = name;
        this.suppressOutput = suppressOutput;
        this.visible = visible;
    }


    /**
     * Gets the addLayer value for this LayersRequest.
     * 
     * @return addLayer
     */
    public java.lang.String getAddLayer() {
        return addLayer;
    }


    /**
     * Sets the addLayer value for this LayersRequest.
     * 
     * @param addLayer
     */
    public void setAddLayer(java.lang.String addLayer) {
        this.addLayer = addLayer;
    }


    /**
     * Gets the allLayers value for this LayersRequest.
     * 
     * @return allLayers
     */
    public java.lang.String getAllLayers() {
        return allLayers;
    }


    /**
     * Sets the allLayers value for this LayersRequest.
     * 
     * @param allLayers
     */
    public void setAllLayers(java.lang.String allLayers) {
        this.allLayers = allLayers;
    }


    /**
     * Gets the deleteLayer value for this LayersRequest.
     * 
     * @return deleteLayer
     */
    public java.lang.String getDeleteLayer() {
        return deleteLayer;
    }


    /**
     * Sets the deleteLayer value for this LayersRequest.
     * 
     * @param deleteLayer
     */
    public void setDeleteLayer(java.lang.String deleteLayer) {
        this.deleteLayer = deleteLayer;
    }


    /**
     * Gets the keepRunaround value for this LayersRequest.
     * 
     * @return keepRunaround
     */
    public java.lang.String getKeepRunaround() {
        return keepRunaround;
    }


    /**
     * Sets the keepRunaround value for this LayersRequest.
     * 
     * @param keepRunaround
     */
    public void setKeepRunaround(java.lang.String keepRunaround) {
        this.keepRunaround = keepRunaround;
    }


    /**
     * Gets the layer value for this LayersRequest.
     * 
     * @return layer
     */
    public java.lang.String getLayer() {
        return layer;
    }


    /**
     * Sets the layer value for this LayersRequest.
     * 
     * @param layer
     */
    public void setLayer(java.lang.String layer) {
        this.layer = layer;
    }


    /**
     * Gets the layerAttribute value for this LayersRequest.
     * 
     * @return layerAttribute
     */
    public java.lang.String getLayerAttribute() {
        return layerAttribute;
    }


    /**
     * Sets the layerAttribute value for this LayersRequest.
     * 
     * @param layerAttribute
     */
    public void setLayerAttribute(java.lang.String layerAttribute) {
        this.layerAttribute = layerAttribute;
    }


    /**
     * Gets the locked value for this LayersRequest.
     * 
     * @return locked
     */
    public java.lang.String getLocked() {
        return locked;
    }


    /**
     * Sets the locked value for this LayersRequest.
     * 
     * @param locked
     */
    public void setLocked(java.lang.String locked) {
        this.locked = locked;
    }


    /**
     * Gets the name value for this LayersRequest.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this LayersRequest.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the suppressOutput value for this LayersRequest.
     * 
     * @return suppressOutput
     */
    public java.lang.String getSuppressOutput() {
        return suppressOutput;
    }


    /**
     * Sets the suppressOutput value for this LayersRequest.
     * 
     * @param suppressOutput
     */
    public void setSuppressOutput(java.lang.String suppressOutput) {
        this.suppressOutput = suppressOutput;
    }


    /**
     * Gets the visible value for this LayersRequest.
     * 
     * @return visible
     */
    public java.lang.String getVisible() {
        return visible;
    }


    /**
     * Sets the visible value for this LayersRequest.
     * 
     * @param visible
     */
    public void setVisible(java.lang.String visible) {
        this.visible = visible;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LayersRequest)) return false;
        LayersRequest other = (LayersRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.addLayer==null && other.getAddLayer()==null) || 
             (this.addLayer!=null &&
              this.addLayer.equals(other.getAddLayer()))) &&
            ((this.allLayers==null && other.getAllLayers()==null) || 
             (this.allLayers!=null &&
              this.allLayers.equals(other.getAllLayers()))) &&
            ((this.deleteLayer==null && other.getDeleteLayer()==null) || 
             (this.deleteLayer!=null &&
              this.deleteLayer.equals(other.getDeleteLayer()))) &&
            ((this.keepRunaround==null && other.getKeepRunaround()==null) || 
             (this.keepRunaround!=null &&
              this.keepRunaround.equals(other.getKeepRunaround()))) &&
            ((this.layer==null && other.getLayer()==null) || 
             (this.layer!=null &&
              this.layer.equals(other.getLayer()))) &&
            ((this.layerAttribute==null && other.getLayerAttribute()==null) || 
             (this.layerAttribute!=null &&
              this.layerAttribute.equals(other.getLayerAttribute()))) &&
            ((this.locked==null && other.getLocked()==null) || 
             (this.locked!=null &&
              this.locked.equals(other.getLocked()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.suppressOutput==null && other.getSuppressOutput()==null) || 
             (this.suppressOutput!=null &&
              this.suppressOutput.equals(other.getSuppressOutput()))) &&
            ((this.visible==null && other.getVisible()==null) || 
             (this.visible!=null &&
              this.visible.equals(other.getVisible())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAddLayer() != null) {
            _hashCode += getAddLayer().hashCode();
        }
        if (getAllLayers() != null) {
            _hashCode += getAllLayers().hashCode();
        }
        if (getDeleteLayer() != null) {
            _hashCode += getDeleteLayer().hashCode();
        }
        if (getKeepRunaround() != null) {
            _hashCode += getKeepRunaround().hashCode();
        }
        if (getLayer() != null) {
            _hashCode += getLayer().hashCode();
        }
        if (getLayerAttribute() != null) {
            _hashCode += getLayerAttribute().hashCode();
        }
        if (getLocked() != null) {
            _hashCode += getLocked().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getSuppressOutput() != null) {
            _hashCode += getSuppressOutput().hashCode();
        }
        if (getVisible() != null) {
            _hashCode += getVisible().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LayersRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LayersRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addLayer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "addLayer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allLayers");
        elemField.setXmlName(new javax.xml.namespace.QName("", "allLayers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deleteLayer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "deleteLayer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keepRunaround");
        elemField.setXmlName(new javax.xml.namespace.QName("", "keepRunaround"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("layerAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "layerAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locked");
        elemField.setXmlName(new javax.xml.namespace.QName("", "locked"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppressOutput");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suppressOutput"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("visible");
        elemField.setXmlName(new javax.xml.namespace.QName("", "visible"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
