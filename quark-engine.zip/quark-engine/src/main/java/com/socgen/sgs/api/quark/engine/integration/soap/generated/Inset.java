/**
 * Inset.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Inset  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String allEdges;

    private java.lang.String bottom;

    private java.lang.String left;

    private java.lang.String multipleInsets;

    private java.lang.String right;

    private java.lang.String top;

    public Inset() {
    }

    public Inset(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String allEdges,
           java.lang.String bottom,
           java.lang.String left,
           java.lang.String multipleInsets,
           java.lang.String right,
           java.lang.String top) {
        super(
            request);
        this.allEdges = allEdges;
        this.bottom = bottom;
        this.left = left;
        this.multipleInsets = multipleInsets;
        this.right = right;
        this.top = top;
    }


    /**
     * Gets the allEdges value for this Inset.
     * 
     * @return allEdges
     */
    public java.lang.String getAllEdges() {
        return allEdges;
    }


    /**
     * Sets the allEdges value for this Inset.
     * 
     * @param allEdges
     */
    public void setAllEdges(java.lang.String allEdges) {
        this.allEdges = allEdges;
    }


    /**
     * Gets the bottom value for this Inset.
     * 
     * @return bottom
     */
    public java.lang.String getBottom() {
        return bottom;
    }


    /**
     * Sets the bottom value for this Inset.
     * 
     * @param bottom
     */
    public void setBottom(java.lang.String bottom) {
        this.bottom = bottom;
    }


    /**
     * Gets the left value for this Inset.
     * 
     * @return left
     */
    public java.lang.String getLeft() {
        return left;
    }


    /**
     * Sets the left value for this Inset.
     * 
     * @param left
     */
    public void setLeft(java.lang.String left) {
        this.left = left;
    }


    /**
     * Gets the multipleInsets value for this Inset.
     * 
     * @return multipleInsets
     */
    public java.lang.String getMultipleInsets() {
        return multipleInsets;
    }


    /**
     * Sets the multipleInsets value for this Inset.
     * 
     * @param multipleInsets
     */
    public void setMultipleInsets(java.lang.String multipleInsets) {
        this.multipleInsets = multipleInsets;
    }


    /**
     * Gets the right value for this Inset.
     * 
     * @return right
     */
    public java.lang.String getRight() {
        return right;
    }


    /**
     * Sets the right value for this Inset.
     * 
     * @param right
     */
    public void setRight(java.lang.String right) {
        this.right = right;
    }


    /**
     * Gets the top value for this Inset.
     * 
     * @return top
     */
    public java.lang.String getTop() {
        return top;
    }


    /**
     * Sets the top value for this Inset.
     * 
     * @param top
     */
    public void setTop(java.lang.String top) {
        this.top = top;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Inset)) return false;
        Inset other = (Inset) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.allEdges==null && other.getAllEdges()==null) || 
             (this.allEdges!=null &&
              this.allEdges.equals(other.getAllEdges()))) &&
            ((this.bottom==null && other.getBottom()==null) || 
             (this.bottom!=null &&
              this.bottom.equals(other.getBottom()))) &&
            ((this.left==null && other.getLeft()==null) || 
             (this.left!=null &&
              this.left.equals(other.getLeft()))) &&
            ((this.multipleInsets==null && other.getMultipleInsets()==null) || 
             (this.multipleInsets!=null &&
              this.multipleInsets.equals(other.getMultipleInsets()))) &&
            ((this.right==null && other.getRight()==null) || 
             (this.right!=null &&
              this.right.equals(other.getRight()))) &&
            ((this.top==null && other.getTop()==null) || 
             (this.top!=null &&
              this.top.equals(other.getTop())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAllEdges() != null) {
            _hashCode += getAllEdges().hashCode();
        }
        if (getBottom() != null) {
            _hashCode += getBottom().hashCode();
        }
        if (getLeft() != null) {
            _hashCode += getLeft().hashCode();
        }
        if (getMultipleInsets() != null) {
            _hashCode += getMultipleInsets().hashCode();
        }
        if (getRight() != null) {
            _hashCode += getRight().hashCode();
        }
        if (getTop() != null) {
            _hashCode += getTop().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Inset.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Inset"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allEdges");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "allEdges"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bottom");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "bottom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("left");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "left"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("multipleInsets");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "multipleInsets"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("right");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "right"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("top");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "top"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
