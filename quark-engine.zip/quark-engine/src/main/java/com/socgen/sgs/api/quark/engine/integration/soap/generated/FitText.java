/**
 * FitText.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class FitText  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String allowTextToGrow;

    private java.lang.String maxFontSize;

    private java.lang.String minFontSize;

    private java.lang.String scaleBaselineShift;

    private java.lang.String scaleSpaceAfter;

    private java.lang.String scaleSpaceBefore;

    private java.lang.String scaleTextScaling;

    private java.lang.String scaleTracking;

    private java.lang.String scalingIncrement;

    public FitText() {
    }

    public FitText(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String allowTextToGrow,
           java.lang.String maxFontSize,
           java.lang.String minFontSize,
           java.lang.String scaleBaselineShift,
           java.lang.String scaleSpaceAfter,
           java.lang.String scaleSpaceBefore,
           java.lang.String scaleTextScaling,
           java.lang.String scaleTracking,
           java.lang.String scalingIncrement) {
        super(
            request);
        this.allowTextToGrow = allowTextToGrow;
        this.maxFontSize = maxFontSize;
        this.minFontSize = minFontSize;
        this.scaleBaselineShift = scaleBaselineShift;
        this.scaleSpaceAfter = scaleSpaceAfter;
        this.scaleSpaceBefore = scaleSpaceBefore;
        this.scaleTextScaling = scaleTextScaling;
        this.scaleTracking = scaleTracking;
        this.scalingIncrement = scalingIncrement;
    }


    /**
     * Gets the allowTextToGrow value for this FitText.
     * 
     * @return allowTextToGrow
     */
    public java.lang.String getAllowTextToGrow() {
        return allowTextToGrow;
    }


    /**
     * Sets the allowTextToGrow value for this FitText.
     * 
     * @param allowTextToGrow
     */
    public void setAllowTextToGrow(java.lang.String allowTextToGrow) {
        this.allowTextToGrow = allowTextToGrow;
    }


    /**
     * Gets the maxFontSize value for this FitText.
     * 
     * @return maxFontSize
     */
    public java.lang.String getMaxFontSize() {
        return maxFontSize;
    }


    /**
     * Sets the maxFontSize value for this FitText.
     * 
     * @param maxFontSize
     */
    public void setMaxFontSize(java.lang.String maxFontSize) {
        this.maxFontSize = maxFontSize;
    }


    /**
     * Gets the minFontSize value for this FitText.
     * 
     * @return minFontSize
     */
    public java.lang.String getMinFontSize() {
        return minFontSize;
    }


    /**
     * Sets the minFontSize value for this FitText.
     * 
     * @param minFontSize
     */
    public void setMinFontSize(java.lang.String minFontSize) {
        this.minFontSize = minFontSize;
    }


    /**
     * Gets the scaleBaselineShift value for this FitText.
     * 
     * @return scaleBaselineShift
     */
    public java.lang.String getScaleBaselineShift() {
        return scaleBaselineShift;
    }


    /**
     * Sets the scaleBaselineShift value for this FitText.
     * 
     * @param scaleBaselineShift
     */
    public void setScaleBaselineShift(java.lang.String scaleBaselineShift) {
        this.scaleBaselineShift = scaleBaselineShift;
    }


    /**
     * Gets the scaleSpaceAfter value for this FitText.
     * 
     * @return scaleSpaceAfter
     */
    public java.lang.String getScaleSpaceAfter() {
        return scaleSpaceAfter;
    }


    /**
     * Sets the scaleSpaceAfter value for this FitText.
     * 
     * @param scaleSpaceAfter
     */
    public void setScaleSpaceAfter(java.lang.String scaleSpaceAfter) {
        this.scaleSpaceAfter = scaleSpaceAfter;
    }


    /**
     * Gets the scaleSpaceBefore value for this FitText.
     * 
     * @return scaleSpaceBefore
     */
    public java.lang.String getScaleSpaceBefore() {
        return scaleSpaceBefore;
    }


    /**
     * Sets the scaleSpaceBefore value for this FitText.
     * 
     * @param scaleSpaceBefore
     */
    public void setScaleSpaceBefore(java.lang.String scaleSpaceBefore) {
        this.scaleSpaceBefore = scaleSpaceBefore;
    }


    /**
     * Gets the scaleTextScaling value for this FitText.
     * 
     * @return scaleTextScaling
     */
    public java.lang.String getScaleTextScaling() {
        return scaleTextScaling;
    }


    /**
     * Sets the scaleTextScaling value for this FitText.
     * 
     * @param scaleTextScaling
     */
    public void setScaleTextScaling(java.lang.String scaleTextScaling) {
        this.scaleTextScaling = scaleTextScaling;
    }


    /**
     * Gets the scaleTracking value for this FitText.
     * 
     * @return scaleTracking
     */
    public java.lang.String getScaleTracking() {
        return scaleTracking;
    }


    /**
     * Sets the scaleTracking value for this FitText.
     * 
     * @param scaleTracking
     */
    public void setScaleTracking(java.lang.String scaleTracking) {
        this.scaleTracking = scaleTracking;
    }


    /**
     * Gets the scalingIncrement value for this FitText.
     * 
     * @return scalingIncrement
     */
    public java.lang.String getScalingIncrement() {
        return scalingIncrement;
    }


    /**
     * Sets the scalingIncrement value for this FitText.
     * 
     * @param scalingIncrement
     */
    public void setScalingIncrement(java.lang.String scalingIncrement) {
        this.scalingIncrement = scalingIncrement;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FitText)) return false;
        FitText other = (FitText) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.allowTextToGrow==null && other.getAllowTextToGrow()==null) || 
             (this.allowTextToGrow!=null &&
              this.allowTextToGrow.equals(other.getAllowTextToGrow()))) &&
            ((this.maxFontSize==null && other.getMaxFontSize()==null) || 
             (this.maxFontSize!=null &&
              this.maxFontSize.equals(other.getMaxFontSize()))) &&
            ((this.minFontSize==null && other.getMinFontSize()==null) || 
             (this.minFontSize!=null &&
              this.minFontSize.equals(other.getMinFontSize()))) &&
            ((this.scaleBaselineShift==null && other.getScaleBaselineShift()==null) || 
             (this.scaleBaselineShift!=null &&
              this.scaleBaselineShift.equals(other.getScaleBaselineShift()))) &&
            ((this.scaleSpaceAfter==null && other.getScaleSpaceAfter()==null) || 
             (this.scaleSpaceAfter!=null &&
              this.scaleSpaceAfter.equals(other.getScaleSpaceAfter()))) &&
            ((this.scaleSpaceBefore==null && other.getScaleSpaceBefore()==null) || 
             (this.scaleSpaceBefore!=null &&
              this.scaleSpaceBefore.equals(other.getScaleSpaceBefore()))) &&
            ((this.scaleTextScaling==null && other.getScaleTextScaling()==null) || 
             (this.scaleTextScaling!=null &&
              this.scaleTextScaling.equals(other.getScaleTextScaling()))) &&
            ((this.scaleTracking==null && other.getScaleTracking()==null) || 
             (this.scaleTracking!=null &&
              this.scaleTracking.equals(other.getScaleTracking()))) &&
            ((this.scalingIncrement==null && other.getScalingIncrement()==null) || 
             (this.scalingIncrement!=null &&
              this.scalingIncrement.equals(other.getScalingIncrement())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAllowTextToGrow() != null) {
            _hashCode += getAllowTextToGrow().hashCode();
        }
        if (getMaxFontSize() != null) {
            _hashCode += getMaxFontSize().hashCode();
        }
        if (getMinFontSize() != null) {
            _hashCode += getMinFontSize().hashCode();
        }
        if (getScaleBaselineShift() != null) {
            _hashCode += getScaleBaselineShift().hashCode();
        }
        if (getScaleSpaceAfter() != null) {
            _hashCode += getScaleSpaceAfter().hashCode();
        }
        if (getScaleSpaceBefore() != null) {
            _hashCode += getScaleSpaceBefore().hashCode();
        }
        if (getScaleTextScaling() != null) {
            _hashCode += getScaleTextScaling().hashCode();
        }
        if (getScaleTracking() != null) {
            _hashCode += getScaleTracking().hashCode();
        }
        if (getScalingIncrement() != null) {
            _hashCode += getScalingIncrement().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FitText.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "FitText"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowTextToGrow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "allowTextToGrow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxFontSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "maxFontSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minFontSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "minFontSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleBaselineShift");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scaleBaselineShift"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleSpaceAfter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scaleSpaceAfter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleSpaceBefore");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scaleSpaceBefore"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleTextScaling");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scaleTextScaling"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scaleTracking");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scaleTracking"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scalingIncrement");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "scalingIncrement"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
