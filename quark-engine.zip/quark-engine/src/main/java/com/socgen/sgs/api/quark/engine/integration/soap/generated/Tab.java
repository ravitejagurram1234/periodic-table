/**
 * Tab.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Tab  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignOn;

    private java.lang.String alignment;

    private java.lang.String enabled;

    private java.lang.String fill;

    private java.lang.String position;

    public Tab() {
    }

    public Tab(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignOn,
           java.lang.String alignment,
           java.lang.String enabled,
           java.lang.String fill,
           java.lang.String position) {
        super(
            request);
        this.alignOn = alignOn;
        this.alignment = alignment;
        this.enabled = enabled;
        this.fill = fill;
        this.position = position;
    }


    /**
     * Gets the alignOn value for this Tab.
     * 
     * @return alignOn
     */
    public java.lang.String getAlignOn() {
        return alignOn;
    }


    /**
     * Sets the alignOn value for this Tab.
     * 
     * @param alignOn
     */
    public void setAlignOn(java.lang.String alignOn) {
        this.alignOn = alignOn;
    }


    /**
     * Gets the alignment value for this Tab.
     * 
     * @return alignment
     */
    public java.lang.String getAlignment() {
        return alignment;
    }


    /**
     * Sets the alignment value for this Tab.
     * 
     * @param alignment
     */
    public void setAlignment(java.lang.String alignment) {
        this.alignment = alignment;
    }


    /**
     * Gets the enabled value for this Tab.
     * 
     * @return enabled
     */
    public java.lang.String getEnabled() {
        return enabled;
    }


    /**
     * Sets the enabled value for this Tab.
     * 
     * @param enabled
     */
    public void setEnabled(java.lang.String enabled) {
        this.enabled = enabled;
    }


    /**
     * Gets the fill value for this Tab.
     * 
     * @return fill
     */
    public java.lang.String getFill() {
        return fill;
    }


    /**
     * Sets the fill value for this Tab.
     * 
     * @param fill
     */
    public void setFill(java.lang.String fill) {
        this.fill = fill;
    }


    /**
     * Gets the position value for this Tab.
     * 
     * @return position
     */
    public java.lang.String getPosition() {
        return position;
    }


    /**
     * Sets the position value for this Tab.
     * 
     * @param position
     */
    public void setPosition(java.lang.String position) {
        this.position = position;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Tab)) return false;
        Tab other = (Tab) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignOn==null && other.getAlignOn()==null) || 
             (this.alignOn!=null &&
              this.alignOn.equals(other.getAlignOn()))) &&
            ((this.alignment==null && other.getAlignment()==null) || 
             (this.alignment!=null &&
              this.alignment.equals(other.getAlignment()))) &&
            ((this.enabled==null && other.getEnabled()==null) || 
             (this.enabled!=null &&
              this.enabled.equals(other.getEnabled()))) &&
            ((this.fill==null && other.getFill()==null) || 
             (this.fill!=null &&
              this.fill.equals(other.getFill()))) &&
            ((this.position==null && other.getPosition()==null) || 
             (this.position!=null &&
              this.position.equals(other.getPosition())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignOn() != null) {
            _hashCode += getAlignOn().hashCode();
        }
        if (getAlignment() != null) {
            _hashCode += getAlignment().hashCode();
        }
        if (getEnabled() != null) {
            _hashCode += getEnabled().hashCode();
        }
        if (getFill() != null) {
            _hashCode += getFill().hashCode();
        }
        if (getPosition() != null) {
            _hashCode += getPosition().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Tab.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Tab"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignOn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignOn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enabled");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "enabled"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fill");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fill"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("position");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "position"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
