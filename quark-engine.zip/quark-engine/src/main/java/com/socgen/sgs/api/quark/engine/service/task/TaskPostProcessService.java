package com.socgen.sgs.api.quark.engine.service.task;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;

/** Post-processes a single task after all tasks have been processed. */
public interface TaskPostProcessService {
    void postProcess(TaskBase task);
}

