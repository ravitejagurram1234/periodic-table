package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.infra.dao.InsertDataStorageDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Oracle implementation: QXP_PK_DATA_STORAGE.Insert_Data
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class InsertDataStorageDaoImpl implements InsertDataStorageDao {

    private final DataSource dataSource;

    @Override
    public void insertData(int idSuivi, int idRun, LocalDateTime dateGeneration,
                           int storeType, String[] names, String[] values,
                           String[] descriptifs, String[] infos,
                           boolean historisationDifferentielle) {
        if (names == null || names.length == 0) return;

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_DATA_STORAGE")
                .withProcedureName("Insert_Data")
                .declareParameters(
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_id_run", Types.NUMERIC),
                        new SqlParameter("p_date_generation", Types.TIMESTAMP),
                        new SqlParameter("p_store_type", Types.NUMERIC),
                        new SqlParameter("p_names", OracleTypes.ARRAY, "QXP_PK_COMMON.VARCHARARRAY"),
                        new SqlParameter("p_values", OracleTypes.ARRAY, "QXP_PK_COMMON.VARCHARARRAY"),
                        new SqlParameter("p_descriptifs", OracleTypes.ARRAY, "QXP_PK_COMMON.VARCHARARRAY"),
                        new SqlParameter("p_infos", OracleTypes.ARRAY, "QXP_PK_COMMON.VARCHARARRAY"),
                        new SqlParameter("p_historisation_differentielle", Types.NUMERIC)
                );

        Map<String, Object> params = new HashMap<>();
        params.put("p_id_suivi", idSuivi);
        params.put("p_id_run", idRun);
        params.put("p_date_generation", Timestamp.valueOf(dateGeneration));
        params.put("p_store_type", storeType);
        params.put("p_names", names);
        params.put("p_values", values);
        params.put("p_descriptifs", descriptifs);
        params.put("p_infos", infos);
        params.put("p_historisation_differentielle", historisationDifferentielle ? 1 : 0);

        jdbcCall.execute(params);
        log.info("Inserted {} data storage entries (type={}) for run [{}]",
                names.length, storeType, idRun);
    }
}