package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.infra.dao.InsertDataStorageDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleTypes;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Oracle implementation: QXP_PK_DATA_STORAGE.Insert_Data
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class InsertDataStorageDaoImpl implements InsertDataStorageDao {

    private final DataSource dataSource;

    @Override
    public void insertData(int idSuivi, int idRun, LocalDateTime dateGeneration,
                           int storeType, String[] names, String[] values,
                           String[] descriptifs, String[] infos,
                           boolean historisationDifferentielle) {
        if (names == null || names.length == 0) return;

        // p_names/p_values/p_descriptifs/p_infos are PL/SQL associative arrays
        // (QXP_PK_COMMON.VarCharArray = "TABLE OF VARCHAR2(4000) INDEX BY BINARY_INTEGER"). These
        // cannot be bound via SimpleJdbcCall + OracleTypes.ARRAY (raised ORA-00902/PLS-00306 at
        // runtime, so storeData persistence always threw). Bind them with the Oracle index-table API
        // setPlsqlIndexTable, mirroring .NET ODP.NET (Proxy_Store/Insert_Data). Finding #20 (C6).
        new JdbcTemplate(dataSource).execute((ConnectionCallback<Void>) con -> {
            try (CallableStatement cs = con.prepareCall(
                    "{ call QXP_PK_DATA_STORAGE.Insert_Data(?, ?, ?, ?, ?, ?, ?, ?, ?) }")) {
                OraclePreparedStatement ops = cs.unwrap(OraclePreparedStatement.class);
                ops.setInt(1, idSuivi);
                ops.setInt(2, idRun);
                ops.setTimestamp(3, Timestamp.valueOf(dateGeneration));
                ops.setInt(4, storeType);
                // setPlsqlIndexTable(paramIndex, data, maxLen, curLen, elemSqlType, elemMaxLen)
                ops.setPlsqlIndexTable(5, names, names.length, names.length, OracleTypes.VARCHAR, 4000);
                ops.setPlsqlIndexTable(6, values, values.length, values.length, OracleTypes.VARCHAR, 4000);
                ops.setPlsqlIndexTable(7, descriptifs, descriptifs.length, descriptifs.length,
                        OracleTypes.VARCHAR, 4000);
                ops.setPlsqlIndexTable(8, infos, infos.length, infos.length, OracleTypes.VARCHAR, 4000);
                ops.setInt(9, historisationDifferentielle ? 1 : 0);
                ops.execute();
            }
            return null;
        });
        log.info("Inserted {} data storage entries (type={}) for run [{}]",
                names.length, storeType, idRun);
    }
}