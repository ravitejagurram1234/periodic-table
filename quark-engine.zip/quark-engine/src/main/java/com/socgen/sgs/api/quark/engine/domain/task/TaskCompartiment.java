package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.domain.Run;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/** Represents a compartment task that generates/incorporates child runs. */
@Getter
@Setter
public class TaskCompartiment extends TaskAnchor {

    private final List<Run> childRuns = new ArrayList<>();
    private int idGabaritFils;
    private boolean evaluateRuns = true;

    public TaskCompartiment(int id, Run run) {
        super(id, run);
    }

    @Override
    public void prepare() {
        // Nothing to do for this task type
    }
}

