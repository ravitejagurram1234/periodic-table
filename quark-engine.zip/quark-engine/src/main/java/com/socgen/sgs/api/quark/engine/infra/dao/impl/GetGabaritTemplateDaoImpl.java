package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.infra.dao.GetGabaritTemplateDao;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Calls Oracle functions QXP_PK_TEMPLATE.Get_Gabarit_Template and Get_Templates.
 */
@Repository
@Slf4j
public class GetGabaritTemplateDaoImpl implements GetGabaritTemplateDao {

    private static final String RESULT_KEY = "result_cursor";
    private static final String PACKAGE     = "QXP_PK_TEMPLATE";

    private final SimpleJdbcCall getGabaritTemplateCall;
    private final SimpleJdbcCall getTemplatesCall;

    @Autowired
    public GetGabaritTemplateDaoImpl(DataSource dataSource) {
        this.getGabaritTemplateCall = new SimpleJdbcCall(dataSource)
                .withCatalogName(PACKAGE)
                .withFunctionName("Get_Gabarit_Template")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR,
                                (rs, rowNum) -> DocumentDomain.builder()
                                        .id(rs.getInt("id_gabarit_template"))
                                        .name(rs.getString("nom"))
                                        .data(rs.getBytes("contenu"))
                                        .format("QXP")
                                        .prefix(DocumentDomain.FILE_GABARIT_TEMPLATE_PREFIX)
                                        .gabarit(true)
                                        .fileName(String.format("%s_%d.%s",
                                                DocumentDomain.FILE_GABARIT_TEMPLATE_PREFIX,
                                                rs.getInt("id_gabarit_template"),
                                                "qxp"))
                                        .build()),
                        new SqlParameter("p_id_gabarit_template", Types.NUMERIC)
                );

        this.getTemplatesCall = new SimpleJdbcCall(dataSource)
                .withCatalogName(PACKAGE)
                .withFunctionName("Get_Templates")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter(RESULT_KEY, OracleTypes.CURSOR, new ColumnMapRowMapper()),
                        new SqlParameter("p_id_gabarit_template", Types.NUMERIC)
                );
    }

    @Override
    public DocumentDomain getGabaritTemplate(int idGabaritTemplate) {
        log.info("Fetching gabarit template for idGabaritTemplate: {}", idGabaritTemplate);

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_gabarit_template", idGabaritTemplate);

        Map<String, Object> result = getGabaritTemplateCall.execute(params);

        @SuppressWarnings("unchecked")
        List<DocumentDomain> rows = (List<DocumentDomain>) result.get(RESULT_KEY);

        if (rows == null || rows.isEmpty()) {
            log.error("No gabarit template found for idGabaritTemplate: {}", idGabaritTemplate);
            throw new IllegalArgumentException(
                    "No gabarit template found for idGabaritTemplate: " + idGabaritTemplate);
        }

        log.info("Successfully retrieved gabarit template for idGabaritTemplate: {}", idGabaritTemplate);
        return rows.get(0);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getTemplates(int idGabaritTemplate) {
        log.info("Fetching templates for idGabaritTemplate: {}", idGabaritTemplate);

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_gabarit_template", idGabaritTemplate);

        Map<String, Object> result = getTemplatesCall.execute(params);
        List<Map<String, Object>> rows = (List<Map<String, Object>>) result.get(RESULT_KEY);

        if (rows == null) {
            log.warn("No templates returned for idGabaritTemplate: {}", idGabaritTemplate);
            return Collections.emptyList();
        }

        log.info("Fetched {} template rows for idGabaritTemplate: {}", rows.size(), idGabaritTemplate);
        return rows;
    }
}

