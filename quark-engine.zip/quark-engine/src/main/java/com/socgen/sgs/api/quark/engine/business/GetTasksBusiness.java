package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.infra.dao.GetTasksDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/** Orchestrates retrieval of tasks for a run. */
@Component
@RequiredArgsConstructor
@Slf4j
public class GetTasksBusiness {

    private final GetTasksDao getTasksDao;

    /**
     * Retrieves the raw task rows for the given run ID.
     *
     * @param runId the run identifier
     * @return list of task row maps
     */
    public List<Map<String, Object>> execute(int runId) {
        log.info("Business layer: loading tasks for runId: {}", runId);
        return getTasksDao.getTasks(runId);
    }
}

