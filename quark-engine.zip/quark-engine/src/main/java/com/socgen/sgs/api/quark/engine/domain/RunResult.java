package com.socgen.sgs.api.quark.engine.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * Holds the final rendered documents after run execution.
 *
 * Cross-reference: .NET Run_Result
 */
@Getter
@Setter
public class RunResult {

    private DocumentDomain finalJpg;
    private DocumentDomain finalPdf;
    private DocumentDomain finalQxp;

    public RunResult() {
    }
}