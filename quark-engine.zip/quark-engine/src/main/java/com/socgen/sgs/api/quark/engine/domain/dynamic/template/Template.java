package com.socgen.sgs.api.quark.engine.domain.dynamic.template;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Represents a layout template that maps a named element (box or group of boxes)
 * from a QuarkXPress gabarit to a position and sizing definition in the final document.
 * Supports both relative and absolute positioning, with configurable page-break,
 * column-break and multi-page repetition behaviour for absolute blocs.
 */
@Getter
@Setter
public class Template {


    /** Shared default template instance. */
    public static final Template DEFAULT = new Template();

    /** Logical name of the template (defaults to "Default"). */
    private String name = "Default";

    /**
     * When {@code true} the template is positioned absolutely on the page;
     * when {@code false} (default) it flows relatively with the content.
     */
    private boolean absolute = false;

    /**
     * Defines how this absolute bloc is repeated across pages, as a raw [Flags] bit-field
     * (.NET Absolute_Repeat_Type: Default=0x00, First_Page=0x01, Other_Page=0x02, Last_Page=0x04,
     * All=0xFF). Stored as an int — not the enum — so combined values (e.g. 0x03) are preserved.
     * Test the bits via {@code AbsoluteRepeatType.hasFirstPage/hasOtherPage/hasLastPage(int)}.
     * Ignored when {@link #absolute} is {@code false}.
     */
    private int absoluteRepeat = 0;

    /**
     * When {@code true} this template is rendered only on page breaks.
     */
    private boolean pageBreak = false;

    /**
     * When {@code true} this template is rendered only on column breaks.
     */
    private boolean columnBreak = false;

    /**
     * Name of the element (box or group of boxes) associated with this template
     * in the gabarit template for the normal (non-overflow) case.
     */
    private String srcName = null;

    /**
     * Name of the element (box or group of boxes) associated with this template
     * in the gabarit template when the content overflows.
     * If not set, falls back to {@link #srcName}.
     */
    private String srcNameOverflow = null;

    /** Left position of the template in the final document. */
    private BigDecimal left = BigDecimal.ZERO;

    /** Top position of the template in the final document. */
    private BigDecimal top = BigDecimal.ZERO;

    /** Final width of the template. */
    private BigDecimal width = BigDecimal.ZERO;

    /** Final height of the template. */
    private BigDecimal height = BigDecimal.ZERO;

    /** Final height of the template expressed as a percentage (default 100 %). */
    private BigDecimal heightPercent = BigDecimal.valueOf(100);

    /** Creates a new Template instance with all default values. */
    public Template() {
    }

    /**
     * Returns the overflow source name. If it has not been explicitly set,
     * falls back to the standard {@link #srcName}.
     */
    public String getSrcNameOverflow() {
        if (srcNameOverflow == null || srcNameOverflow.isBlank()) {
            return srcName;
        }
        return srcNameOverflow;
    }
}