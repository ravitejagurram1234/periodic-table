package com.socgen.sgs.api.quark.engine.service;

import com.socgen.sgs.api.quark.engine.domain.Run;

/** Orchestrates process, post-process, and verification of all tasks in a run. */
public interface ProcessTasksService {
    void processTasks(Run run);
}

