package com.socgen.sgs.api.quark.engine.service;

import com.socgen.sgs.api.quark.engine.domain.Run;

/** Orchestrates prepare, process, post-process, and verification of all tasks in a run. */
public interface ProcessTasksService {

    /**
     * Prepare phase: calls {@code prepare()} on every task before processing.
     * Cross-reference: .NET Run_Base.Launch_Prepare() / Run_Base.Prepare().
     */
    void prepareTasks(Run run);

    void processTasks(Run run);
}
