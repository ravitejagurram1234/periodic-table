package com.socgen.sgs.api.quark.engine.infra.interop.qxps.exception;

import com.socgen.sgs.api.quark.engine.infra.interop.qxps.model.QxpsRequestInfo;
import lombok.Getter;

@Getter
public class QxpsException extends RuntimeException {

    private final QxpsRequestInfo requestInfo;

    public QxpsException(QxpsRequestInfo requestInfo, Throwable cause) {
        super("QXPS call failed: " + requestInfo.getUri(), cause);
        this.requestInfo = requestInfo;
    }

    public QxpsException(QxpsRequestInfo requestInfo, String message) {
        super("QXPS call failed: " + requestInfo.getUri() + " - " + message);
        this.requestInfo = requestInfo;
    }
}

