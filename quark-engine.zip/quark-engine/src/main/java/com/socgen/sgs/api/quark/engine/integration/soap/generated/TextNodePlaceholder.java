/**
 * TextNodePlaceholder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class TextNodePlaceholder  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData;

    private int index;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData;

    private java.lang.String name;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter;

    private java.lang.String owner;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] textNodePlaceholders;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] textPlaceholders;

    public TextNodePlaceholder() {
    }

    public TextNodePlaceholder(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData,
           int index,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData,
           java.lang.String name,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter,
           java.lang.String owner,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] textNodePlaceholders,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] textPlaceholders) {
        super(
            request);
        this.hiddenData = hiddenData;
        this.index = index;
        this.metaData = metaData;
        this.name = name;
        this.overMatter = overMatter;
        this.owner = owner;
        this.paragraphs = paragraphs;
        this.richText = richText;
        this.textNodePlaceholders = textNodePlaceholders;
        this.textPlaceholders = textPlaceholders;
    }


    /**
     * Gets the hiddenData value for this TextNodePlaceholder.
     * 
     * @return hiddenData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] getHiddenData() {
        return hiddenData;
    }


    /**
     * Sets the hiddenData value for this TextNodePlaceholder.
     * 
     * @param hiddenData
     */
    public void setHiddenData(com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData) {
        this.hiddenData = hiddenData;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData getHiddenData(int i) {
        return this.hiddenData[i];
    }

    public void setHiddenData(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData _value) {
        this.hiddenData[i] = _value;
    }


    /**
     * Gets the index value for this TextNodePlaceholder.
     * 
     * @return index
     */
    public int getIndex() {
        return index;
    }


    /**
     * Sets the index value for this TextNodePlaceholder.
     * 
     * @param index
     */
    public void setIndex(int index) {
        this.index = index;
    }


    /**
     * Gets the metaData value for this TextNodePlaceholder.
     * 
     * @return metaData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData getMetaData() {
        return metaData;
    }


    /**
     * Sets the metaData value for this TextNodePlaceholder.
     * 
     * @param metaData
     */
    public void setMetaData(com.socgen.sgs.api.quark.engine.integration.soap.generated.MetaData metaData) {
        this.metaData = metaData;
    }


    /**
     * Gets the name value for this TextNodePlaceholder.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this TextNodePlaceholder.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the overMatter value for this TextNodePlaceholder.
     * 
     * @return overMatter
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter getOverMatter() {
        return overMatter;
    }


    /**
     * Sets the overMatter value for this TextNodePlaceholder.
     * 
     * @param overMatter
     */
    public void setOverMatter(com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter) {
        this.overMatter = overMatter;
    }


    /**
     * Gets the owner value for this TextNodePlaceholder.
     * 
     * @return owner
     */
    public java.lang.String getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this TextNodePlaceholder.
     * 
     * @param owner
     */
    public void setOwner(java.lang.String owner) {
        this.owner = owner;
    }


    /**
     * Gets the paragraphs value for this TextNodePlaceholder.
     * 
     * @return paragraphs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] getParagraphs() {
        return paragraphs;
    }


    /**
     * Sets the paragraphs value for this TextNodePlaceholder.
     * 
     * @param paragraphs
     */
    public void setParagraphs(com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs) {
        this.paragraphs = paragraphs;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph getParagraphs(int i) {
        return this.paragraphs[i];
    }

    public void setParagraphs(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph _value) {
        this.paragraphs[i] = _value;
    }


    /**
     * Gets the richText value for this TextNodePlaceholder.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this TextNodePlaceholder.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText getRichText(int i) {
        return this.richText[i];
    }

    public void setRichText(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText _value) {
        this.richText[i] = _value;
    }


    /**
     * Gets the textNodePlaceholders value for this TextNodePlaceholder.
     * 
     * @return textNodePlaceholders
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] getTextNodePlaceholders() {
        return textNodePlaceholders;
    }


    /**
     * Sets the textNodePlaceholders value for this TextNodePlaceholder.
     * 
     * @param textNodePlaceholders
     */
    public void setTextNodePlaceholders(com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] textNodePlaceholders) {
        this.textNodePlaceholders = textNodePlaceholders;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder getTextNodePlaceholders(int i) {
        return this.textNodePlaceholders[i];
    }

    public void setTextNodePlaceholders(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder _value) {
        this.textNodePlaceholders[i] = _value;
    }


    /**
     * Gets the textPlaceholders value for this TextNodePlaceholder.
     * 
     * @return textPlaceholders
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] getTextPlaceholders() {
        return textPlaceholders;
    }


    /**
     * Sets the textPlaceholders value for this TextNodePlaceholder.
     * 
     * @param textPlaceholders
     */
    public void setTextPlaceholders(com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] textPlaceholders) {
        this.textPlaceholders = textPlaceholders;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder getTextPlaceholders(int i) {
        return this.textPlaceholders[i];
    }

    public void setTextPlaceholders(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder _value) {
        this.textPlaceholders[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TextNodePlaceholder)) return false;
        TextNodePlaceholder other = (TextNodePlaceholder) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.hiddenData==null && other.getHiddenData()==null) || 
             (this.hiddenData!=null &&
              java.util.Arrays.equals(this.hiddenData, other.getHiddenData()))) &&
            this.index == other.getIndex() &&
            ((this.metaData==null && other.getMetaData()==null) || 
             (this.metaData!=null &&
              this.metaData.equals(other.getMetaData()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.overMatter==null && other.getOverMatter()==null) || 
             (this.overMatter!=null &&
              this.overMatter.equals(other.getOverMatter()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.paragraphs==null && other.getParagraphs()==null) || 
             (this.paragraphs!=null &&
              java.util.Arrays.equals(this.paragraphs, other.getParagraphs()))) &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText()))) &&
            ((this.textNodePlaceholders==null && other.getTextNodePlaceholders()==null) || 
             (this.textNodePlaceholders!=null &&
              java.util.Arrays.equals(this.textNodePlaceholders, other.getTextNodePlaceholders()))) &&
            ((this.textPlaceholders==null && other.getTextPlaceholders()==null) || 
             (this.textPlaceholders!=null &&
              java.util.Arrays.equals(this.textPlaceholders, other.getTextPlaceholders())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getHiddenData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHiddenData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHiddenData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getIndex();
        if (getMetaData() != null) {
            _hashCode += getMetaData().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOverMatter() != null) {
            _hashCode += getOverMatter().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getParagraphs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParagraphs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParagraphs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTextNodePlaceholders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTextNodePlaceholders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTextNodePlaceholders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTextPlaceholders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTextPlaceholders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTextPlaceholders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TextNodePlaceholder.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TextNodePlaceholder"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hiddenData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hiddenData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HiddenData"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("index");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "index"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metaData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "metaData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "MetaData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overMatter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "overMatter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OverMatter"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paragraphs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "paragraphs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Paragraph"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RichText"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textNodePlaceholders");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "textNodePlaceholders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TextNodePlaceholder"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textPlaceholders");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "textPlaceholders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TextPlaceholder"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
