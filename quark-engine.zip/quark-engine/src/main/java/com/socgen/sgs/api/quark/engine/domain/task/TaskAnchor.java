package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DBlocInfo;
import com.socgen.sgs.api.quark.engine.enums.SubTaskTypeEnum;
import lombok.Setter;

/** Abstract base for tasks that manipulate start/end anchors in the document. */
@Setter
public abstract class TaskAnchor extends TaskBase {

    private static final String START_ANCHOR_PATTERN = "%s_START";
    private static final String END_ANCHOR_PATTERN   = "%s_END";

    private DBlocInfo startAnchor;
    private DBlocInfo endAnchor;

    protected TaskAnchor(int id, Run run) {
        super(id, run);
        this.setSubTaskType(SubTaskTypeEnum.FILE_QXP_DATA);
    }

    /** Returns the anchor bloc name (start or end) derived from the destinationBlocName. */
    public String getAnchorName(boolean start) {
        String pattern = start ? START_ANCHOR_PATTERN : END_ANCHOR_PATTERN;
        return String.format(pattern, this.getDestinationBlocName());
    }

    /**
     * Fetches anchor info for the given anchor name via getBlocInfo.
     * Throws IllegalStateException if the anchor UID is not found in the document.
     */
    public DBlocInfo getAnchorInfo(boolean start) {
        String anchorName  = this.getAnchorName(start);
        DBlocInfo dblocInfo = this.getBlocInfo(anchorName);

        if (dblocInfo == null || dblocInfo.getUid() == null || dblocInfo.getUid().isBlank()) {
            throw new IllegalStateException("Anchor not found in document: " + anchorName);
        }
        return dblocInfo;
    }

    /** Override in subclasses to resolve bloc info from QXP server. */
    @SuppressWarnings("unused")
    protected DBlocInfo getBlocInfo(String blocName) {
        return new DBlocInfo();
    }

    /** Evaluates pageNum and layoutName from the start anchor — resolved via gabarit XML in the business layer. */
    @Override
    public void evaluateInfo() {
        // pageNum and layoutName are set by the business layer using getAnchorName(true)
    }

    @Override
    public void resetProcess() {
        super.resetProcess();
        this.startAnchor = null;
        this.endAnchor   = null;
    }

    /** Lazily loads and returns the start anchor info. */
    public DBlocInfo getStartAnchor() {
        if (this.startAnchor == null) {
            this.startAnchor = this.getAnchorInfo(true);
        }
        return this.startAnchor;
    }

    /** Lazily loads and returns the end anchor info. */
    public DBlocInfo getEndAnchor() {
        if (this.endAnchor == null) {
            this.endAnchor = this.getAnchorInfo(false);
        }
        return this.endAnchor;
    }

    /** Returns the number of existing pages between the two anchors. */
    public int getNbAnciennePage() {
        return this.getEndAnchor().getPage() - this.getStartAnchor().getPage() + 1;
    }
}


