package com.socgen.sgs.api.quark.engine.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Value object representing a Run ID
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RunId {
    private Integer runId;
}