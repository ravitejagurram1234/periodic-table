/**
 * Shadow.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Shadow  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String angle;

    private java.lang.String blur;

    private java.lang.String color;

    private java.lang.String distance;

    private java.lang.String inheritOpacity;

    private java.lang.String knockoutShadow;

    private java.lang.String multiplyShadow;

    private java.lang.String opacity;

    private java.lang.String runaroundShadow;

    private java.lang.String scale;

    private java.lang.String shade;

    private java.lang.String skew;

    private java.lang.String synchronizeAngle;

    public Shadow() {
    }

    public Shadow(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String angle,
           java.lang.String blur,
           java.lang.String color,
           java.lang.String distance,
           java.lang.String inheritOpacity,
           java.lang.String knockoutShadow,
           java.lang.String multiplyShadow,
           java.lang.String opacity,
           java.lang.String runaroundShadow,
           java.lang.String scale,
           java.lang.String shade,
           java.lang.String skew,
           java.lang.String synchronizeAngle) {
        super(
            request);
        this.angle = angle;
        this.blur = blur;
        this.color = color;
        this.distance = distance;
        this.inheritOpacity = inheritOpacity;
        this.knockoutShadow = knockoutShadow;
        this.multiplyShadow = multiplyShadow;
        this.opacity = opacity;
        this.runaroundShadow = runaroundShadow;
        this.scale = scale;
        this.shade = shade;
        this.skew = skew;
        this.synchronizeAngle = synchronizeAngle;
    }


    /**
     * Gets the angle value for this Shadow.
     * 
     * @return angle
     */
    public java.lang.String getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this Shadow.
     * 
     * @param angle
     */
    public void setAngle(java.lang.String angle) {
        this.angle = angle;
    }


    /**
     * Gets the blur value for this Shadow.
     * 
     * @return blur
     */
    public java.lang.String getBlur() {
        return blur;
    }


    /**
     * Sets the blur value for this Shadow.
     * 
     * @param blur
     */
    public void setBlur(java.lang.String blur) {
        this.blur = blur;
    }


    /**
     * Gets the color value for this Shadow.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this Shadow.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the distance value for this Shadow.
     * 
     * @return distance
     */
    public java.lang.String getDistance() {
        return distance;
    }


    /**
     * Sets the distance value for this Shadow.
     * 
     * @param distance
     */
    public void setDistance(java.lang.String distance) {
        this.distance = distance;
    }


    /**
     * Gets the inheritOpacity value for this Shadow.
     * 
     * @return inheritOpacity
     */
    public java.lang.String getInheritOpacity() {
        return inheritOpacity;
    }


    /**
     * Sets the inheritOpacity value for this Shadow.
     * 
     * @param inheritOpacity
     */
    public void setInheritOpacity(java.lang.String inheritOpacity) {
        this.inheritOpacity = inheritOpacity;
    }


    /**
     * Gets the knockoutShadow value for this Shadow.
     * 
     * @return knockoutShadow
     */
    public java.lang.String getKnockoutShadow() {
        return knockoutShadow;
    }


    /**
     * Sets the knockoutShadow value for this Shadow.
     * 
     * @param knockoutShadow
     */
    public void setKnockoutShadow(java.lang.String knockoutShadow) {
        this.knockoutShadow = knockoutShadow;
    }


    /**
     * Gets the multiplyShadow value for this Shadow.
     * 
     * @return multiplyShadow
     */
    public java.lang.String getMultiplyShadow() {
        return multiplyShadow;
    }


    /**
     * Sets the multiplyShadow value for this Shadow.
     * 
     * @param multiplyShadow
     */
    public void setMultiplyShadow(java.lang.String multiplyShadow) {
        this.multiplyShadow = multiplyShadow;
    }


    /**
     * Gets the opacity value for this Shadow.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this Shadow.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the runaroundShadow value for this Shadow.
     * 
     * @return runaroundShadow
     */
    public java.lang.String getRunaroundShadow() {
        return runaroundShadow;
    }


    /**
     * Sets the runaroundShadow value for this Shadow.
     * 
     * @param runaroundShadow
     */
    public void setRunaroundShadow(java.lang.String runaroundShadow) {
        this.runaroundShadow = runaroundShadow;
    }


    /**
     * Gets the scale value for this Shadow.
     * 
     * @return scale
     */
    public java.lang.String getScale() {
        return scale;
    }


    /**
     * Sets the scale value for this Shadow.
     * 
     * @param scale
     */
    public void setScale(java.lang.String scale) {
        this.scale = scale;
    }


    /**
     * Gets the shade value for this Shadow.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this Shadow.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the skew value for this Shadow.
     * 
     * @return skew
     */
    public java.lang.String getSkew() {
        return skew;
    }


    /**
     * Sets the skew value for this Shadow.
     * 
     * @param skew
     */
    public void setSkew(java.lang.String skew) {
        this.skew = skew;
    }


    /**
     * Gets the synchronizeAngle value for this Shadow.
     * 
     * @return synchronizeAngle
     */
    public java.lang.String getSynchronizeAngle() {
        return synchronizeAngle;
    }


    /**
     * Sets the synchronizeAngle value for this Shadow.
     * 
     * @param synchronizeAngle
     */
    public void setSynchronizeAngle(java.lang.String synchronizeAngle) {
        this.synchronizeAngle = synchronizeAngle;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Shadow)) return false;
        Shadow other = (Shadow) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.angle==null && other.getAngle()==null) || 
             (this.angle!=null &&
              this.angle.equals(other.getAngle()))) &&
            ((this.blur==null && other.getBlur()==null) || 
             (this.blur!=null &&
              this.blur.equals(other.getBlur()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.distance==null && other.getDistance()==null) || 
             (this.distance!=null &&
              this.distance.equals(other.getDistance()))) &&
            ((this.inheritOpacity==null && other.getInheritOpacity()==null) || 
             (this.inheritOpacity!=null &&
              this.inheritOpacity.equals(other.getInheritOpacity()))) &&
            ((this.knockoutShadow==null && other.getKnockoutShadow()==null) || 
             (this.knockoutShadow!=null &&
              this.knockoutShadow.equals(other.getKnockoutShadow()))) &&
            ((this.multiplyShadow==null && other.getMultiplyShadow()==null) || 
             (this.multiplyShadow!=null &&
              this.multiplyShadow.equals(other.getMultiplyShadow()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.runaroundShadow==null && other.getRunaroundShadow()==null) || 
             (this.runaroundShadow!=null &&
              this.runaroundShadow.equals(other.getRunaroundShadow()))) &&
            ((this.scale==null && other.getScale()==null) || 
             (this.scale!=null &&
              this.scale.equals(other.getScale()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.skew==null && other.getSkew()==null) || 
             (this.skew!=null &&
              this.skew.equals(other.getSkew()))) &&
            ((this.synchronizeAngle==null && other.getSynchronizeAngle()==null) || 
             (this.synchronizeAngle!=null &&
              this.synchronizeAngle.equals(other.getSynchronizeAngle())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAngle() != null) {
            _hashCode += getAngle().hashCode();
        }
        if (getBlur() != null) {
            _hashCode += getBlur().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getDistance() != null) {
            _hashCode += getDistance().hashCode();
        }
        if (getInheritOpacity() != null) {
            _hashCode += getInheritOpacity().hashCode();
        }
        if (getKnockoutShadow() != null) {
            _hashCode += getKnockoutShadow().hashCode();
        }
        if (getMultiplyShadow() != null) {
            _hashCode += getMultiplyShadow().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getRunaroundShadow() != null) {
            _hashCode += getRunaroundShadow().hashCode();
        }
        if (getScale() != null) {
            _hashCode += getScale().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getSkew() != null) {
            _hashCode += getSkew().hashCode();
        }
        if (getSynchronizeAngle() != null) {
            _hashCode += getSynchronizeAngle().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Shadow.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Shadow"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("angle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "angle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blur");
        elemField.setXmlName(new javax.xml.namespace.QName("", "blur"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("distance");
        elemField.setXmlName(new javax.xml.namespace.QName("", "distance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inheritOpacity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inheritOpacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("knockoutShadow");
        elemField.setXmlName(new javax.xml.namespace.QName("", "knockoutShadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("multiplyShadow");
        elemField.setXmlName(new javax.xml.namespace.QName("", "multiplyShadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("runaroundShadow");
        elemField.setXmlName(new javax.xml.namespace.QName("", "runaroundShadow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scale");
        elemField.setXmlName(new javax.xml.namespace.QName("", "scale"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("skew");
        elemField.setXmlName(new javax.xml.namespace.QName("", "skew"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("synchronizeAngle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "synchronizeAngle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
