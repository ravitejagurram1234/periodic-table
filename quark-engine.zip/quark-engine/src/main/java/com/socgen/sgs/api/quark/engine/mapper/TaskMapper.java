package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DBreakRules;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DMasterPage;
import com.socgen.sgs.api.quark.engine.domain.task.*;
import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;
import com.socgen.sgs.api.quark.engine.enums.TaskTypeEnum;
import com.socgen.sgs.api.quark.engine.domain.port.FilePoolPort;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

@Component
@Slf4j
@RequiredArgsConstructor
public class TaskMapper {

    private final FilePoolPort filePoolPort;

    public TaskBase mapToTask(Map<String, Object> row, Run run) {
        int idTache = getInt(row, "ID_TACHE");
        int idTypeTache = getInt(row, "ID_TYPE_TACHE");
        TaskTypeEnum taskType = TaskTypeEnum.fromCode(idTypeTache); // it's a single time used variable, pass it directly

        TaskBase task = createTaskByType(taskType, idTache, run, row);
        if (task != null) {
            mapCommonFields(row, task);
        }
        return task;
    }

    private TaskBase createTaskByType(TaskTypeEnum taskType, int idTache, Run run, Map<String, Object> row) {
        switch (taskType) {
            case SQL:
                TaskSql taskSql = new TaskSql(idTache, run);
                mapTaskSql(row, taskSql);
                return taskSql;
            case DOC_EOS:
                TaskDocument taskDoc = new TaskDocument(idTache, run);
                mapTaskDocument(row, taskDoc);
                return taskDoc;
            case DOC_QXP:
                TaskQxpPrevious taskQxp = new TaskQxpPrevious(idTache, run);
                mapTaskQxpPrevious(row, taskQxp);
                return taskQxp;
            case SQL_DYNAMIQUE:
                TaskDynamique taskDyn = new TaskDynamique(idTache, run);
                taskDyn.setFilePoolService(filePoolPort);
                mapTaskDynamique(row, taskDyn);
                return taskDyn;
            case COMPARTIMENTS:
                TaskCompartiment taskComp = new TaskCompartiment(idTache, run);
                mapTaskCompartiment(row, taskComp);
                return taskComp;
            default:
                log.warn("Unknown task type code: {} for taskId: {}", taskType, idTache);
                return null;
        }
    }

    private void mapTaskSql(Map<String, Object> row, TaskSql task) {
        task.setSql(getString(row, "SQL"));
        task.setShowZero(getBoolean(row, "AFFICHER_ZERO"));
        task.setNbDecimal(getInt(row, "NB_DECIMAL"));
        task.setDecimalSignificative(getBoolean(row, "DECIMAL_SIGNIFICATIVE"));
        task.setStoreData(getBoolean(row, "STORE_DATA"));

        int idDataType = getInt(row, "OUTPUT_DATA_TYPE");
        try {
            task.setDataType(DataTypeEnum.fromCode(idDataType));
        } catch (Exception e) {
            log.error("Invalid data type {} for task {}", idDataType, task.getDebugInfo());
        }
    }

    private void mapTaskDocument(Map<String, Object> row, TaskDocument task) {
        task.setFormatDocument(getString(row, "FORMAT"));
        task.setRotationImage(getBoolean(row, "ROTATION_IMAGE"));
        task.setIdSousCategorie(getInt(row, "ID_SOUS_CATEGORIE"));
        task.setOffsetValues(getString(row, "CROP_IMAGE_VALUES"));
        task.setConserverStyle(getBoolean(row, "CONSERVER_STYLE"));
        task.setSourceBlocName(getString(row, "BLOC_SOURCE"));
        task.setDestinationBlocName(getString(row, "BLOC_DESTINATION"));
        task.setPositionValues(getString(row, "POSITION_IMAGE"));
    }

    private void mapTaskQxpPrevious(Map<String, Object> row, TaskQxpPrevious task) {
        task.setConserverStyle(getBoolean(row, "CONSERVER_STYLE"));
        task.setPreviousTypeRapport(getString(row, "PREVIOUS_TYPE_RAPPORT"));
        task.setSourceBlocName(getString(row, "BLOC_SOURCE"));
        task.setDestinationBlocName(getString(row, "BLOC_DESTINATION"));
    }

    private void mapTaskDynamique(Map<String, Object> row, TaskDynamique task) {
        task.setSql(getString(row, "SQL"));
        task.setDestinationBlocName(getString(row, "BLOC_DESTINATION"));
        task.setControlOverflow(getBoolean(row, "CONTROL_OVERFLOW"));
        task.setNewPageTable(getBoolean(row, "NEW_PAGE_TABLE"));
        task.setNbColumn(getInt(row, "NB_COLUMN"));
        task.setStoreData(getBoolean(row, "STORE_DATA"));

        BigDecimal colSpace = getBigDecimal(row, "COLUMN_SPACE");
        if (colSpace != null) {
            task.setColumnSpace(colSpace);
        }

        String codeMasterPage = getString(row, "CODE_MASTER_PAGE");
        task.setMasterPage(isSet(codeMasterPage) ? new DMasterPage(codeMasterPage) : DMasterPage.DEFAULT);

        String pageBreakRules = getString(row, "PAGE_BREAK_RULES");
        task.setPageBreakRules(isSet(pageBreakRules) ? new DBreakRules(pageBreakRules) : DBreakRules.DEFAULT);

        String columnBreakRules = getString(row, "COLUMN_BREAK_RULES");
        task.setColumnBreakRules(isSet(columnBreakRules) ? new DBreakRules(columnBreakRules) : DBreakRules.DEFAULT);
    }

    private void mapTaskCompartiment(Map<String, Object> row, TaskCompartiment task) {
        task.setDestinationBlocName(getString(row, "BLOC_DESTINATION"));
        task.setIdGabaritFils(getInt(row, "ID_GABARIT_FILS"));

        String codeMasterPage = getString(row, "CODE_MASTER_PAGE");
        task.setMasterPage(isSet(codeMasterPage) ? new DMasterPage(codeMasterPage) : DMasterPage.DEFAULT);
    }

    private void mapCommonFields(Map<String, Object> row, TaskBase task) {
        String nullString = getString(row, "CHAMPS_VIDE");
        if (isSet(nullString)) {
            task.setNullString(nullString);
        }
        task.setTodo(getBoolean(row, "TODO"));
        task.setCommentaire(getString(row, "COMMENTAIRE"));
    }

    // --- Utility extraction methods ---

    private String getString(Map<String, Object> row, String key) {
        Object val = row.get(key);
        return val != null ? val.toString() : null;
    }

    private int getInt(Map<String, Object> row, String key) {
        Object val = row.get(key);
        if (val instanceof Number) {
            return ((Number) val).intValue();
        }
        return 0;
    }

    private boolean getBoolean(Map<String, Object> row, String key) {
        Object val = row.get(key);
        if (val instanceof Number) {
            return ((Number) val).intValue() != 0;
        }
        if (val instanceof Boolean) {
            return (Boolean) val;
        }
        return false;
    }

    private BigDecimal getBigDecimal(Map<String, Object> row, String key) {
        Object val = row.get(key);
        if (val instanceof BigDecimal) {
            return (BigDecimal) val;
        }
        if (val instanceof Number) {
            return BigDecimal.valueOf(((Number) val).doubleValue());
        }
        return null;
    }

    private boolean isSet(String value) {
        return value != null && !value.isBlank();
    }
}

