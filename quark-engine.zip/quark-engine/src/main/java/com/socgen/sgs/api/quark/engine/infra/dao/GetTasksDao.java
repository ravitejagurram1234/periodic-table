package com.socgen.sgs.api.quark.engine.infra.dao;

import java.util.List;
import java.util.Map;

public interface GetTasksDao {
    List<Map<String, Object>> getTasks(int runId);
}

