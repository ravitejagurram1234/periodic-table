package com.socgen.sgs.api.quark.engine.enums;
public enum TaskActionTypeEnum {
    NONE,
    UPDATE,
    CREATE,
    REMOVE;
    public static TaskActionTypeEnum fromName(String name) {
        if (name == null) {
            return NONE;
        }
        try {
            return valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return NONE;
        }
    }
}
