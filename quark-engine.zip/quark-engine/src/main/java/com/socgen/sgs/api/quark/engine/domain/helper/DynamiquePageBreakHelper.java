package com.socgen.sgs.api.quark.engine.domain.helper;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DBreakRule;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DBreakRules;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DCell;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DReport;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DRow;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.PrepareReportParameters;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles page/column break row evaluation during dynamic report preparation.
 * When a row causes a page or column overflow, this helper determines:
 * <ul>
 *   <li>Which previous rows should be "brought along" to the new page (via break rules)</li>
 *   <li>Which header rows (page break rows) should be repeated on the new page</li>
 *   <li>Position updates for all affected rows and cells</li>
 * </ul>
 *
 * Cross-reference: QXP.Engine.Core.Dynamique_Page_Break_Helper
 */
@Slf4j
public final class DynamiquePageBreakHelper {

    private DynamiquePageBreakHelper() {
    }

    /**
     * Update rows when a page or column break occurs.
     * Handles both rule-based row retrieval and break row (header) duplication.
     *
     * @param report    the report being prepared
     * @param tableRows the rows of the current table
     * @param currentRow the row that triggered the break
     * @param prp       the prepare report parameters (page, column, cursor state)
     * @param pageBreak true for page break, false for column break
     * @param left      left position offset (0 for page break, accumulated width for column break)
     */
    public static void updateRows(DReport report, List<DRow> tableRows, DRow currentRow,
                                  PrepareReportParameters prp, boolean pageBreak, BigDecimal left) {

        // Get applicable break rules
        DBreakRule rules;
        int previousPageColumn;

        if (pageBreak) {
            rules = report.getPageBreakRules().getRule(currentRow.getLevel());
            previousPageColumn = prp.getPage() - 1;
        } else {
            rules = report.getColumnBreakRules().getRule(currentRow.getLevel());
            previousPageColumn = prp.getColumn() - 1;
        }

        // Row retrieval counters
        int nbRowsRetrieves = -1; // Start at -1 because currentRow is in the loop but shouldn't count
        int nbRowsMinRetrieves = 0;

        // Check for negative values in bring levels (means "bring N rows regardless of level")
        for (int val : rules.getBringLevels()) {
            if (val < 0) {
                nbRowsMinRetrieves = Math.max(nbRowsMinRetrieves, -val);
            }
        }

        // Heights and widths tracking
        BigDecimal breakHeight = BigDecimal.ZERO;
        BigDecimal breakWidth = BigDecimal.ZERO;
        BigDecimal retrievesRowsHeight = BigDecimal.ZERO;
        BigDecimal retrievesRowsWidth = currentRow.getInfo().getWidth();

        // Lists for processing
        List<DRow> retrievedRows = new ArrayList<>();
        DRow firstRow = currentRow;
        List<DRow> breakRows;
        List<Integer> rowlevelRemoveBreak = new ArrayList<>();
        boolean activeRules = true;

        // ====================================================================
        // Phase 1: Rules — retrieve previous rows based on break rules
        // ====================================================================

        int currentRowIndex = tableRows.indexOf(currentRow);

        // Reverse iterate from currentRow upward
        for (int i = currentRowIndex; i >= 0; i--) {
            DRow row = tableRows.get(i);

            // Skip break rows (header repetition rows)
            if (isRowBreak(row)) {
                continue;
            }

            int currentPageColumn;
            if (pageBreak) {
                currentPageColumn = currentRow.getInfo().getPage();
            } else {
                currentPageColumn = currentRow.getInfo().getColumn();
            }

            List<DRow> currentBreakRows = pageBreak ? row.getPageBreakRows() : row.getColumnBreakRows();

            // Retrieve row if:
            // 1. It's the current row (always included)
            // 2. Rules are active AND its level matches bring_levels AND it's on the previous page
            // 3. We haven't yet retrieved the minimum number of rows
            boolean isCurrentRow = (row == currentRow);
            boolean matchesRules = activeRules
                    && rules.getBringLevels().contains(row.getLevel())
                    && (currentPageColumn == previousPageColumn);
            boolean belowMinimum = (nbRowsRetrieves < nbRowsMinRetrieves);

            if (isCurrentRow || matchesRules || belowMinimum) {
                firstRow = row;
                retrievedRows.add(row);
                retrievesRowsHeight = retrievesRowsHeight.add(row.getInfo().getHeight());
                retrievesRowsWidth = retrievesRowsWidth.max(row.getInfo().getWidth());
                nbRowsRetrieves++;

                int indexBreak = indexRowTypeBreak(currentBreakRows, row.getLevel());
                if (indexBreak >= 0 && !rowlevelRemoveBreak.contains(row.getLevel())) {
                    rowlevelRemoveBreak.add(row.getLevel());
                }
            } else {
                int indexBreak = indexRowTypeBreak(currentBreakRows, row.getLevel());
                activeRules = false;

                // If this row matches a break row level, still retrieve it
                if (indexBreak >= 0) {
                    firstRow = row;
                    retrievedRows.add(row);
                    retrievesRowsHeight = retrievesRowsHeight.add(row.getInfo().getHeight());
                    retrievesRowsWidth = retrievesRowsWidth.max(row.getInfo().getWidth());
                    nbRowsRetrieves++;

                    if (!rowlevelRemoveBreak.contains(row.getLevel())) {
                        rowlevelRemoveBreak.add(row.getLevel());
                    }
                } else {
                    // No more rules apply — stop
                    break;
                }
            }
        }

        // ====================================================================
        // Phase 2: Pre-process — check rows AFTER currentRow for break duplicates
        // ====================================================================

        List<DRow> currentBreakRowsForCheck = pageBreak
                ? currentRow.getPageBreakRows()
                : currentRow.getColumnBreakRows();

        for (int i = currentRowIndex + 1; i < tableRows.size(); i++) {
            DRow row = tableRows.get(i);
            if (!isRowBreak(row)) {
                int indexBreak = indexRowTypeBreak(currentBreakRowsForCheck, row.getLevel());
                if (indexBreak >= 0) {
                    if (!rowlevelRemoveBreak.contains(row.getLevel())) {
                        rowlevelRemoveBreak.add(row.getLevel());
                    }
                } else {
                    break;
                }
            }
        }

        // ====================================================================
        // Phase 3: Breaks — duplicate and insert header rows on new page/column
        // ====================================================================

        List<DRow> firstRowBreakRows = pageBreak
                ? new ArrayList<>(firstRow.getPageBreakRows())
                : new ArrayList<>(firstRow.getColumnBreakRows());

        // Remove break rows whose level conflicts with retrieved rows
        firstRowBreakRows.removeIf(row -> rowlevelRemoveBreak.contains(row.getLevel()));

        breakRows = firstRowBreakRows;

        if (!breakRows.isEmpty()) {
            int firstNewRowIndex = tableRows.indexOf(firstRow);

            for (DRow breakRow : breakRows) {
                DRow duplicateRow = duplicateUpdateDRow(breakRow, prp.getPage(), prp.getColumn());

                // Update cell positions for the duplicated break row
                BigDecimal anchorBottom = prp.getTask().getStartAnchor().getBottom();
                BigDecimal anchorRight = prp.getTask().getStartAnchor().getRight();

                for (DCell cell : duplicateRow.getCells()) {
                    cell.getInfo().getZone().setTop(
                            breakHeight.add(anchorBottom).add(cell.getTemplate().getTop()));
                    cell.getInfo().getZone().setLeft(
                            left.add(anchorRight).add(cell.getTemplate().getLeft()));
                    cell.getInfo().setPage(prp.getPage());
                    cell.getInfo().setColumn(prp.getColumn());
                }

                // Insert at the correct position
                tableRows.add(firstNewRowIndex, duplicateRow);

                breakHeight = breakHeight.add(breakRow.getInfo().getHeight());
                breakWidth = breakWidth.max(breakRow.getInfo().getWidth());
            }
        }

        // ====================================================================
        // Phase 4: Update positions of retrieved rows on new page
        // ====================================================================

        BigDecimal top = breakHeight;
        BigDecimal anchorBottom = prp.getTask().getStartAnchor().getBottom();
        BigDecimal anchorRight = prp.getTask().getStartAnchor().getRight();

        // Check if there's enough space on the new page for all retrieved rows
        BigDecimal totalNeeded = retrievesRowsHeight.add(top).add(currentRow.getInfo().getHeight());

        if (totalNeeded.compareTo(prp.getAvailableHeight()) < 0) {
            // Enough space — update all retrieved rows (reverse order → top to bottom)
            for (int i = retrievedRows.size() - 1; i >= 0; i--) {
                DRow row = retrievedRows.get(i);
                row.getInfo().setPage(prp.getPage());
                row.getInfo().setColumn(prp.getColumn());

                for (DCell cell : row.getCells()) {
                    cell.getInfo().getZone().setTop(
                            top.add(anchorBottom).add(cell.getTemplate().getTop()));
                    cell.getInfo().getZone().setLeft(
                            left.add(anchorRight).add(cell.getTemplate().getLeft()));
                    cell.getInfo().setPage(prp.getPage());
                    cell.getInfo().setColumn(prp.getColumn());
                }
                top = top.add(row.getInfo().getHeight());
            }
        } else {
            // Not enough space — only update the current row that triggered the break
            currentRow.getInfo().setPage(prp.getPage());
            currentRow.getInfo().setColumn(prp.getColumn());

            for (DCell cell : currentRow.getCells()) {
                cell.getInfo().getZone().setTop(
                        top.add(anchorBottom).add(cell.getTemplate().getTop()));
                cell.getInfo().getZone().setLeft(
                        left.add(anchorRight).add(cell.getTemplate().getLeft()));
                cell.getInfo().setPage(prp.getPage());
                cell.getInfo().setColumn(prp.getColumn());
            }
            top = top.add(currentRow.getInfo().getHeight());

            log.warn("Break rule ignored — not enough space on page {} column {} for task [{}]",
                    prp.getPage(), prp.getColumn(), prp.getTask().getId());
        }

        // ====================================================================
        // Update results
        // ====================================================================

        prp.setCurrentTableHeight(top);
        prp.setCurrentTableWidth(breakWidth.max(retrievesRowsWidth));
        prp.setNbRowsAdded(breakRows.size());
    }

    // ========================================================================
    // Private helpers
    // ========================================================================

    /**
     * Check if a row's level matches any of the break rows' levels.
     *
     * @param breakRows the list of break rows
     * @param rowLevel  the level to check
     * @return the index of the matching break row, or -1 if not found
     */
    private static int indexRowTypeBreak(List<DRow> breakRows, int rowLevel) {
        if (breakRows == null) {
            return -1;
        }
        for (int i = 0; i < breakRows.size(); i++) {
            if (breakRows.get(i).getLevel() == rowLevel) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Check if a row is a break row (page break or column break).
     *
     * @param row the row to check
     * @return true if the row has page break or column break behavior
     */
    private static boolean isRowBreak(DRow row) {
        return row.isPageBreak() || row.isColumnBreak();
    }

    /**
     * Duplicate a break row with updated page and column info.
     *
     * @param row    the row to clone
     * @param page   the new page number
     * @param column the new column number
     * @return a cloned row with updated page/column
     */
    private static DRow duplicateUpdateDRow(DRow row, int page, int column) {
        DRow newRow = row.cloneRow();
        newRow.getInfo().setPage(page);
        newRow.getInfo().setColumn(column);
        for (DCell cell : newRow.getCells()) {
            cell.getInfo().setPage(page);
            cell.getInfo().setColumn(column);
        }
        return newRow;
    }
}