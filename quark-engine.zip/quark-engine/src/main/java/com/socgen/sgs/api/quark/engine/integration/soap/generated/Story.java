/**
 * Story.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Story  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences;

    private java.lang.String clearOldText;

    private java.lang.String convertQuotes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit copyFit;

    private java.lang.String file;

    private java.lang.String fitTextToBox;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData;

    private java.lang.String includeStylesheets;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox[] linkedBoxes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] lists;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi;

    private java.lang.String storyDirection;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] textNodePlaceholders;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] textPlaceholders;

    public Story() {
    }

    public Story(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences,
           java.lang.String clearOldText,
           java.lang.String convertQuotes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit copyFit,
           java.lang.String file,
           java.lang.String fitTextToBox,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData,
           java.lang.String includeStylesheets,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox[] linkedBoxes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] lists,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi,
           java.lang.String storyDirection,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] textNodePlaceholders,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] textPlaceholders) {
        super(
            request);
        this.anchoredBoxReferences = anchoredBoxReferences;
        this.clearOldText = clearOldText;
        this.convertQuotes = convertQuotes;
        this.copyFit = copyFit;
        this.file = file;
        this.fitTextToBox = fitTextToBox;
        this.hiddenData = hiddenData;
        this.includeStylesheets = includeStylesheets;
        this.linkedBoxes = linkedBoxes;
        this.lists = lists;
        this.overMatter = overMatter;
        this.paragraphs = paragraphs;
        this.richText = richText;
        this.rubi = rubi;
        this.storyDirection = storyDirection;
        this.textNodePlaceholders = textNodePlaceholders;
        this.textPlaceholders = textPlaceholders;
    }


    /**
     * Gets the anchoredBoxReferences value for this Story.
     * 
     * @return anchoredBoxReferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] getAnchoredBoxReferences() {
        return anchoredBoxReferences;
    }


    /**
     * Sets the anchoredBoxReferences value for this Story.
     * 
     * @param anchoredBoxReferences
     */
    public void setAnchoredBoxReferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences) {
        this.anchoredBoxReferences = anchoredBoxReferences;
    }


    /**
     * Gets the clearOldText value for this Story.
     * 
     * @return clearOldText
     */
    public java.lang.String getClearOldText() {
        return clearOldText;
    }


    /**
     * Sets the clearOldText value for this Story.
     * 
     * @param clearOldText
     */
    public void setClearOldText(java.lang.String clearOldText) {
        this.clearOldText = clearOldText;
    }


    /**
     * Gets the convertQuotes value for this Story.
     * 
     * @return convertQuotes
     */
    public java.lang.String getConvertQuotes() {
        return convertQuotes;
    }


    /**
     * Sets the convertQuotes value for this Story.
     * 
     * @param convertQuotes
     */
    public void setConvertQuotes(java.lang.String convertQuotes) {
        this.convertQuotes = convertQuotes;
    }


    /**
     * Gets the copyFit value for this Story.
     * 
     * @return copyFit
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit getCopyFit() {
        return copyFit;
    }


    /**
     * Sets the copyFit value for this Story.
     * 
     * @param copyFit
     */
    public void setCopyFit(com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit copyFit) {
        this.copyFit = copyFit;
    }


    /**
     * Gets the file value for this Story.
     * 
     * @return file
     */
    public java.lang.String getFile() {
        return file;
    }


    /**
     * Sets the file value for this Story.
     * 
     * @param file
     */
    public void setFile(java.lang.String file) {
        this.file = file;
    }


    /**
     * Gets the fitTextToBox value for this Story.
     * 
     * @return fitTextToBox
     */
    public java.lang.String getFitTextToBox() {
        return fitTextToBox;
    }


    /**
     * Sets the fitTextToBox value for this Story.
     * 
     * @param fitTextToBox
     */
    public void setFitTextToBox(java.lang.String fitTextToBox) {
        this.fitTextToBox = fitTextToBox;
    }


    /**
     * Gets the hiddenData value for this Story.
     * 
     * @return hiddenData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] getHiddenData() {
        return hiddenData;
    }


    /**
     * Sets the hiddenData value for this Story.
     * 
     * @param hiddenData
     */
    public void setHiddenData(com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData) {
        this.hiddenData = hiddenData;
    }


    /**
     * Gets the includeStylesheets value for this Story.
     * 
     * @return includeStylesheets
     */
    public java.lang.String getIncludeStylesheets() {
        return includeStylesheets;
    }


    /**
     * Sets the includeStylesheets value for this Story.
     * 
     * @param includeStylesheets
     */
    public void setIncludeStylesheets(java.lang.String includeStylesheets) {
        this.includeStylesheets = includeStylesheets;
    }


    /**
     * Gets the linkedBoxes value for this Story.
     * 
     * @return linkedBoxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox[] getLinkedBoxes() {
        return linkedBoxes;
    }


    /**
     * Sets the linkedBoxes value for this Story.
     * 
     * @param linkedBoxes
     */
    public void setLinkedBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox[] linkedBoxes) {
        this.linkedBoxes = linkedBoxes;
    }


    /**
     * Gets the lists value for this Story.
     * 
     * @return lists
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] getLists() {
        return lists;
    }


    /**
     * Sets the lists value for this Story.
     * 
     * @param lists
     */
    public void setLists(com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] lists) {
        this.lists = lists;
    }


    /**
     * Gets the overMatter value for this Story.
     * 
     * @return overMatter
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter getOverMatter() {
        return overMatter;
    }


    /**
     * Sets the overMatter value for this Story.
     * 
     * @param overMatter
     */
    public void setOverMatter(com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter) {
        this.overMatter = overMatter;
    }


    /**
     * Gets the paragraphs value for this Story.
     * 
     * @return paragraphs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] getParagraphs() {
        return paragraphs;
    }


    /**
     * Sets the paragraphs value for this Story.
     * 
     * @param paragraphs
     */
    public void setParagraphs(com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs) {
        this.paragraphs = paragraphs;
    }


    /**
     * Gets the richText value for this Story.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this Story.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }


    /**
     * Gets the rubi value for this Story.
     * 
     * @return rubi
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] getRubi() {
        return rubi;
    }


    /**
     * Sets the rubi value for this Story.
     * 
     * @param rubi
     */
    public void setRubi(com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi) {
        this.rubi = rubi;
    }


    /**
     * Gets the storyDirection value for this Story.
     * 
     * @return storyDirection
     */
    public java.lang.String getStoryDirection() {
        return storyDirection;
    }


    /**
     * Sets the storyDirection value for this Story.
     * 
     * @param storyDirection
     */
    public void setStoryDirection(java.lang.String storyDirection) {
        this.storyDirection = storyDirection;
    }


    /**
     * Gets the textNodePlaceholders value for this Story.
     * 
     * @return textNodePlaceholders
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] getTextNodePlaceholders() {
        return textNodePlaceholders;
    }


    /**
     * Sets the textNodePlaceholders value for this Story.
     * 
     * @param textNodePlaceholders
     */
    public void setTextNodePlaceholders(com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] textNodePlaceholders) {
        this.textNodePlaceholders = textNodePlaceholders;
    }


    /**
     * Gets the textPlaceholders value for this Story.
     * 
     * @return textPlaceholders
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] getTextPlaceholders() {
        return textPlaceholders;
    }


    /**
     * Sets the textPlaceholders value for this Story.
     * 
     * @param textPlaceholders
     */
    public void setTextPlaceholders(com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] textPlaceholders) {
        this.textPlaceholders = textPlaceholders;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Story)) return false;
        Story other = (Story) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.anchoredBoxReferences==null && other.getAnchoredBoxReferences()==null) || 
             (this.anchoredBoxReferences!=null &&
              java.util.Arrays.equals(this.anchoredBoxReferences, other.getAnchoredBoxReferences()))) &&
            ((this.clearOldText==null && other.getClearOldText()==null) || 
             (this.clearOldText!=null &&
              this.clearOldText.equals(other.getClearOldText()))) &&
            ((this.convertQuotes==null && other.getConvertQuotes()==null) || 
             (this.convertQuotes!=null &&
              this.convertQuotes.equals(other.getConvertQuotes()))) &&
            ((this.copyFit==null && other.getCopyFit()==null) || 
             (this.copyFit!=null &&
              this.copyFit.equals(other.getCopyFit()))) &&
            ((this.file==null && other.getFile()==null) || 
             (this.file!=null &&
              this.file.equals(other.getFile()))) &&
            ((this.fitTextToBox==null && other.getFitTextToBox()==null) || 
             (this.fitTextToBox!=null &&
              this.fitTextToBox.equals(other.getFitTextToBox()))) &&
            ((this.hiddenData==null && other.getHiddenData()==null) || 
             (this.hiddenData!=null &&
              java.util.Arrays.equals(this.hiddenData, other.getHiddenData()))) &&
            ((this.includeStylesheets==null && other.getIncludeStylesheets()==null) || 
             (this.includeStylesheets!=null &&
              this.includeStylesheets.equals(other.getIncludeStylesheets()))) &&
            ((this.linkedBoxes==null && other.getLinkedBoxes()==null) || 
             (this.linkedBoxes!=null &&
              java.util.Arrays.equals(this.linkedBoxes, other.getLinkedBoxes()))) &&
            ((this.lists==null && other.getLists()==null) || 
             (this.lists!=null &&
              java.util.Arrays.equals(this.lists, other.getLists()))) &&
            ((this.overMatter==null && other.getOverMatter()==null) || 
             (this.overMatter!=null &&
              this.overMatter.equals(other.getOverMatter()))) &&
            ((this.paragraphs==null && other.getParagraphs()==null) || 
             (this.paragraphs!=null &&
              java.util.Arrays.equals(this.paragraphs, other.getParagraphs()))) &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText()))) &&
            ((this.rubi==null && other.getRubi()==null) || 
             (this.rubi!=null &&
              java.util.Arrays.equals(this.rubi, other.getRubi()))) &&
            ((this.storyDirection==null && other.getStoryDirection()==null) || 
             (this.storyDirection!=null &&
              this.storyDirection.equals(other.getStoryDirection()))) &&
            ((this.textNodePlaceholders==null && other.getTextNodePlaceholders()==null) || 
             (this.textNodePlaceholders!=null &&
              java.util.Arrays.equals(this.textNodePlaceholders, other.getTextNodePlaceholders()))) &&
            ((this.textPlaceholders==null && other.getTextPlaceholders()==null) || 
             (this.textPlaceholders!=null &&
              java.util.Arrays.equals(this.textPlaceholders, other.getTextPlaceholders())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAnchoredBoxReferences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAnchoredBoxReferences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAnchoredBoxReferences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getClearOldText() != null) {
            _hashCode += getClearOldText().hashCode();
        }
        if (getConvertQuotes() != null) {
            _hashCode += getConvertQuotes().hashCode();
        }
        if (getCopyFit() != null) {
            _hashCode += getCopyFit().hashCode();
        }
        if (getFile() != null) {
            _hashCode += getFile().hashCode();
        }
        if (getFitTextToBox() != null) {
            _hashCode += getFitTextToBox().hashCode();
        }
        if (getHiddenData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHiddenData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHiddenData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIncludeStylesheets() != null) {
            _hashCode += getIncludeStylesheets().hashCode();
        }
        if (getLinkedBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLinkedBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLinkedBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLists() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLists());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLists(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOverMatter() != null) {
            _hashCode += getOverMatter().hashCode();
        }
        if (getParagraphs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParagraphs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParagraphs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRubi() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRubi());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRubi(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getStoryDirection() != null) {
            _hashCode += getStoryDirection().hashCode();
        }
        if (getTextNodePlaceholders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTextNodePlaceholders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTextNodePlaceholders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTextPlaceholders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTextPlaceholders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTextPlaceholders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Story.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Story"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredBoxReferences");
        elemField.setXmlName(new javax.xml.namespace.QName("", "anchoredBoxReferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "AnchoredBoxReference"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clearOldText");
        elemField.setXmlName(new javax.xml.namespace.QName("", "clearOldText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("convertQuotes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "convertQuotes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("copyFit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "copyFit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "CopyFit"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file");
        elemField.setXmlName(new javax.xml.namespace.QName("", "file"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fitTextToBox");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fitTextToBox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hiddenData");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hiddenData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "HiddenData"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeStylesheets");
        elemField.setXmlName(new javax.xml.namespace.QName("", "includeStylesheets"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("linkedBoxes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "linkedBoxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LinkedBox"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lists");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lists"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "List"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overMatter");
        elemField.setXmlName(new javax.xml.namespace.QName("", "overMatter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "OverMatter"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paragraphs");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paragraphs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Paragraph"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "RichText"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rubi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rubi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Rubi"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("storyDirection");
        elemField.setXmlName(new javax.xml.namespace.QName("", "storyDirection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textNodePlaceholders");
        elemField.setXmlName(new javax.xml.namespace.QName("", "textNodePlaceholders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TextNodePlaceholder"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textPlaceholders");
        elemField.setXmlName(new javax.xml.namespace.QName("", "textPlaceholders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "TextPlaceholder"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
