/**
 * Story.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Story  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences;

    private java.lang.String annotateTextOverflow;

    private java.lang.String boxName;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] calloutAnchors;

    private java.lang.String clearOldText;

    private java.lang.String convertQuotes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit copyFit;

    private java.lang.String file;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.FitText fitText;

    private java.lang.String fitTextToBox;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData;

    private java.lang.String includeStylesheets;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Index[] indexes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] inlineItems;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] inlineTables;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox[] linkedBoxes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] lists;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak[] pageBreaks;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence[] pageSequences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote[] refNotes;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi;

    private java.lang.String storyDirection;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] textNodePlaceholders;

    private java.lang.String textOverflow;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] textPlaceholders;

    private java.lang.String UID;

    public Story() {
    }

    public Story(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences,
           java.lang.String annotateTextOverflow,
           java.lang.String boxName,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] calloutAnchors,
           java.lang.String clearOldText,
           java.lang.String convertQuotes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit copyFit,
           java.lang.String file,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.FitText fitText,
           java.lang.String fitTextToBox,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData,
           java.lang.String includeStylesheets,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Index[] indexes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] inlineItems,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] inlineTables,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox[] linkedBoxes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] lists,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak[] pageBreaks,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence[] pageSequences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote[] refNotes,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi,
           java.lang.String storyDirection,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] textNodePlaceholders,
           java.lang.String textOverflow,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] textPlaceholders,
           java.lang.String UID) {
        super(
            request);
        this.anchoredBoxReferences = anchoredBoxReferences;
        this.annotateTextOverflow = annotateTextOverflow;
        this.boxName = boxName;
        this.calloutAnchors = calloutAnchors;
        this.clearOldText = clearOldText;
        this.convertQuotes = convertQuotes;
        this.copyFit = copyFit;
        this.file = file;
        this.fitText = fitText;
        this.fitTextToBox = fitTextToBox;
        this.hiddenData = hiddenData;
        this.includeStylesheets = includeStylesheets;
        this.indexTerms = indexTerms;
        this.indexes = indexes;
        this.inlineBoxes = inlineBoxes;
        this.inlineItems = inlineItems;
        this.inlineTables = inlineTables;
        this.linkedBoxes = linkedBoxes;
        this.lists = lists;
        this.overMatter = overMatter;
        this.pageBreaks = pageBreaks;
        this.pageSequences = pageSequences;
        this.paragraphs = paragraphs;
        this.refNotes = refNotes;
        this.richText = richText;
        this.rubi = rubi;
        this.storyDirection = storyDirection;
        this.textNodePlaceholders = textNodePlaceholders;
        this.textOverflow = textOverflow;
        this.textPlaceholders = textPlaceholders;
        this.UID = UID;
    }


    /**
     * Gets the anchoredBoxReferences value for this Story.
     * 
     * @return anchoredBoxReferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] getAnchoredBoxReferences() {
        return anchoredBoxReferences;
    }


    /**
     * Sets the anchoredBoxReferences value for this Story.
     * 
     * @param anchoredBoxReferences
     */
    public void setAnchoredBoxReferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference[] anchoredBoxReferences) {
        this.anchoredBoxReferences = anchoredBoxReferences;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference getAnchoredBoxReferences(int i) {
        return this.anchoredBoxReferences[i];
    }

    public void setAnchoredBoxReferences(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.AnchoredBoxReference _value) {
        this.anchoredBoxReferences[i] = _value;
    }


    /**
     * Gets the annotateTextOverflow value for this Story.
     * 
     * @return annotateTextOverflow
     */
    public java.lang.String getAnnotateTextOverflow() {
        return annotateTextOverflow;
    }


    /**
     * Sets the annotateTextOverflow value for this Story.
     * 
     * @param annotateTextOverflow
     */
    public void setAnnotateTextOverflow(java.lang.String annotateTextOverflow) {
        this.annotateTextOverflow = annotateTextOverflow;
    }


    /**
     * Gets the boxName value for this Story.
     * 
     * @return boxName
     */
    public java.lang.String getBoxName() {
        return boxName;
    }


    /**
     * Sets the boxName value for this Story.
     * 
     * @param boxName
     */
    public void setBoxName(java.lang.String boxName) {
        this.boxName = boxName;
    }


    /**
     * Gets the calloutAnchors value for this Story.
     * 
     * @return calloutAnchors
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] getCalloutAnchors() {
        return calloutAnchors;
    }


    /**
     * Sets the calloutAnchors value for this Story.
     * 
     * @param calloutAnchors
     */
    public void setCalloutAnchors(com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor[] calloutAnchors) {
        this.calloutAnchors = calloutAnchors;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor getCalloutAnchors(int i) {
        return this.calloutAnchors[i];
    }

    public void setCalloutAnchors(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.CalloutAnchor _value) {
        this.calloutAnchors[i] = _value;
    }


    /**
     * Gets the clearOldText value for this Story.
     * 
     * @return clearOldText
     */
    public java.lang.String getClearOldText() {
        return clearOldText;
    }


    /**
     * Sets the clearOldText value for this Story.
     * 
     * @param clearOldText
     */
    public void setClearOldText(java.lang.String clearOldText) {
        this.clearOldText = clearOldText;
    }


    /**
     * Gets the convertQuotes value for this Story.
     * 
     * @return convertQuotes
     */
    public java.lang.String getConvertQuotes() {
        return convertQuotes;
    }


    /**
     * Sets the convertQuotes value for this Story.
     * 
     * @param convertQuotes
     */
    public void setConvertQuotes(java.lang.String convertQuotes) {
        this.convertQuotes = convertQuotes;
    }


    /**
     * Gets the copyFit value for this Story.
     * 
     * @return copyFit
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit getCopyFit() {
        return copyFit;
    }


    /**
     * Sets the copyFit value for this Story.
     * 
     * @param copyFit
     */
    public void setCopyFit(com.socgen.sgs.api.quark.engine.integration.soap.generated.CopyFit copyFit) {
        this.copyFit = copyFit;
    }


    /**
     * Gets the file value for this Story.
     * 
     * @return file
     */
    public java.lang.String getFile() {
        return file;
    }


    /**
     * Sets the file value for this Story.
     * 
     * @param file
     */
    public void setFile(java.lang.String file) {
        this.file = file;
    }


    /**
     * Gets the fitText value for this Story.
     * 
     * @return fitText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.FitText getFitText() {
        return fitText;
    }


    /**
     * Sets the fitText value for this Story.
     * 
     * @param fitText
     */
    public void setFitText(com.socgen.sgs.api.quark.engine.integration.soap.generated.FitText fitText) {
        this.fitText = fitText;
    }


    /**
     * Gets the fitTextToBox value for this Story.
     * 
     * @return fitTextToBox
     */
    public java.lang.String getFitTextToBox() {
        return fitTextToBox;
    }


    /**
     * Sets the fitTextToBox value for this Story.
     * 
     * @param fitTextToBox
     */
    public void setFitTextToBox(java.lang.String fitTextToBox) {
        this.fitTextToBox = fitTextToBox;
    }


    /**
     * Gets the hiddenData value for this Story.
     * 
     * @return hiddenData
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] getHiddenData() {
        return hiddenData;
    }


    /**
     * Sets the hiddenData value for this Story.
     * 
     * @param hiddenData
     */
    public void setHiddenData(com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData[] hiddenData) {
        this.hiddenData = hiddenData;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData getHiddenData(int i) {
        return this.hiddenData[i];
    }

    public void setHiddenData(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.HiddenData _value) {
        this.hiddenData[i] = _value;
    }


    /**
     * Gets the includeStylesheets value for this Story.
     * 
     * @return includeStylesheets
     */
    public java.lang.String getIncludeStylesheets() {
        return includeStylesheets;
    }


    /**
     * Sets the includeStylesheets value for this Story.
     * 
     * @param includeStylesheets
     */
    public void setIncludeStylesheets(java.lang.String includeStylesheets) {
        this.includeStylesheets = includeStylesheets;
    }


    /**
     * Gets the indexTerms value for this Story.
     * 
     * @return indexTerms
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] getIndexTerms() {
        return indexTerms;
    }


    /**
     * Sets the indexTerms value for this Story.
     * 
     * @param indexTerms
     */
    public void setIndexTerms(com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms) {
        this.indexTerms = indexTerms;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm getIndexTerms(int i) {
        return this.indexTerms[i];
    }

    public void setIndexTerms(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm _value) {
        this.indexTerms[i] = _value;
    }


    /**
     * Gets the indexes value for this Story.
     * 
     * @return indexes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Index[] getIndexes() {
        return indexes;
    }


    /**
     * Sets the indexes value for this Story.
     * 
     * @param indexes
     */
    public void setIndexes(com.socgen.sgs.api.quark.engine.integration.soap.generated.Index[] indexes) {
        this.indexes = indexes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Index getIndexes(int i) {
        return this.indexes[i];
    }

    public void setIndexes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Index _value) {
        this.indexes[i] = _value;
    }


    /**
     * Gets the inlineBoxes value for this Story.
     * 
     * @return inlineBoxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] getInlineBoxes() {
        return inlineBoxes;
    }


    /**
     * Sets the inlineBoxes value for this Story.
     * 
     * @param inlineBoxes
     */
    public void setInlineBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox[] inlineBoxes) {
        this.inlineBoxes = inlineBoxes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox getInlineBoxes(int i) {
        return this.inlineBoxes[i];
    }

    public void setInlineBoxes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineBox _value) {
        this.inlineBoxes[i] = _value;
    }


    /**
     * Gets the inlineItems value for this Story.
     * 
     * @return inlineItems
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] getInlineItems() {
        return inlineItems;
    }


    /**
     * Sets the inlineItems value for this Story.
     * 
     * @param inlineItems
     */
    public void setInlineItems(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem[] inlineItems) {
        this.inlineItems = inlineItems;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem getInlineItems(int i) {
        return this.inlineItems[i];
    }

    public void setInlineItems(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineItem _value) {
        this.inlineItems[i] = _value;
    }


    /**
     * Gets the inlineTables value for this Story.
     * 
     * @return inlineTables
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] getInlineTables() {
        return inlineTables;
    }


    /**
     * Sets the inlineTables value for this Story.
     * 
     * @param inlineTables
     */
    public void setInlineTables(com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable[] inlineTables) {
        this.inlineTables = inlineTables;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable getInlineTables(int i) {
        return this.inlineTables[i];
    }

    public void setInlineTables(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.InlineTable _value) {
        this.inlineTables[i] = _value;
    }


    /**
     * Gets the linkedBoxes value for this Story.
     * 
     * @return linkedBoxes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox[] getLinkedBoxes() {
        return linkedBoxes;
    }


    /**
     * Sets the linkedBoxes value for this Story.
     * 
     * @param linkedBoxes
     */
    public void setLinkedBoxes(com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox[] linkedBoxes) {
        this.linkedBoxes = linkedBoxes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox getLinkedBoxes(int i) {
        return this.linkedBoxes[i];
    }

    public void setLinkedBoxes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.LinkedBox _value) {
        this.linkedBoxes[i] = _value;
    }


    /**
     * Gets the lists value for this Story.
     * 
     * @return lists
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] getLists() {
        return lists;
    }


    /**
     * Sets the lists value for this Story.
     * 
     * @param lists
     */
    public void setLists(com.socgen.sgs.api.quark.engine.integration.soap.generated.List[] lists) {
        this.lists = lists;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.List getLists(int i) {
        return this.lists[i];
    }

    public void setLists(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.List _value) {
        this.lists[i] = _value;
    }


    /**
     * Gets the overMatter value for this Story.
     * 
     * @return overMatter
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter getOverMatter() {
        return overMatter;
    }


    /**
     * Sets the overMatter value for this Story.
     * 
     * @param overMatter
     */
    public void setOverMatter(com.socgen.sgs.api.quark.engine.integration.soap.generated.OverMatter overMatter) {
        this.overMatter = overMatter;
    }


    /**
     * Gets the pageBreaks value for this Story.
     * 
     * @return pageBreaks
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak[] getPageBreaks() {
        return pageBreaks;
    }


    /**
     * Sets the pageBreaks value for this Story.
     * 
     * @param pageBreaks
     */
    public void setPageBreaks(com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak[] pageBreaks) {
        this.pageBreaks = pageBreaks;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak getPageBreaks(int i) {
        return this.pageBreaks[i];
    }

    public void setPageBreaks(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.PageBreak _value) {
        this.pageBreaks[i] = _value;
    }


    /**
     * Gets the pageSequences value for this Story.
     * 
     * @return pageSequences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence[] getPageSequences() {
        return pageSequences;
    }


    /**
     * Sets the pageSequences value for this Story.
     * 
     * @param pageSequences
     */
    public void setPageSequences(com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence[] pageSequences) {
        this.pageSequences = pageSequences;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence getPageSequences(int i) {
        return this.pageSequences[i];
    }

    public void setPageSequences(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.PageSequence _value) {
        this.pageSequences[i] = _value;
    }


    /**
     * Gets the paragraphs value for this Story.
     * 
     * @return paragraphs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] getParagraphs() {
        return paragraphs;
    }


    /**
     * Sets the paragraphs value for this Story.
     * 
     * @param paragraphs
     */
    public void setParagraphs(com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs) {
        this.paragraphs = paragraphs;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph getParagraphs(int i) {
        return this.paragraphs[i];
    }

    public void setParagraphs(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph _value) {
        this.paragraphs[i] = _value;
    }


    /**
     * Gets the refNotes value for this Story.
     * 
     * @return refNotes
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote[] getRefNotes() {
        return refNotes;
    }


    /**
     * Sets the refNotes value for this Story.
     * 
     * @param refNotes
     */
    public void setRefNotes(com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote[] refNotes) {
        this.refNotes = refNotes;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote getRefNotes(int i) {
        return this.refNotes[i];
    }

    public void setRefNotes(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RefNote _value) {
        this.refNotes[i] = _value;
    }


    /**
     * Gets the richText value for this Story.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this Story.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText getRichText(int i) {
        return this.richText[i];
    }

    public void setRichText(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText _value) {
        this.richText[i] = _value;
    }


    /**
     * Gets the rubi value for this Story.
     * 
     * @return rubi
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] getRubi() {
        return rubi;
    }


    /**
     * Sets the rubi value for this Story.
     * 
     * @param rubi
     */
    public void setRubi(com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi[] rubi) {
        this.rubi = rubi;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi getRubi(int i) {
        return this.rubi[i];
    }

    public void setRubi(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Rubi _value) {
        this.rubi[i] = _value;
    }


    /**
     * Gets the storyDirection value for this Story.
     * 
     * @return storyDirection
     */
    public java.lang.String getStoryDirection() {
        return storyDirection;
    }


    /**
     * Sets the storyDirection value for this Story.
     * 
     * @param storyDirection
     */
    public void setStoryDirection(java.lang.String storyDirection) {
        this.storyDirection = storyDirection;
    }


    /**
     * Gets the textNodePlaceholders value for this Story.
     * 
     * @return textNodePlaceholders
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] getTextNodePlaceholders() {
        return textNodePlaceholders;
    }


    /**
     * Sets the textNodePlaceholders value for this Story.
     * 
     * @param textNodePlaceholders
     */
    public void setTextNodePlaceholders(com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder[] textNodePlaceholders) {
        this.textNodePlaceholders = textNodePlaceholders;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder getTextNodePlaceholders(int i) {
        return this.textNodePlaceholders[i];
    }

    public void setTextNodePlaceholders(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.TextNodePlaceholder _value) {
        this.textNodePlaceholders[i] = _value;
    }


    /**
     * Gets the textOverflow value for this Story.
     * 
     * @return textOverflow
     */
    public java.lang.String getTextOverflow() {
        return textOverflow;
    }


    /**
     * Sets the textOverflow value for this Story.
     * 
     * @param textOverflow
     */
    public void setTextOverflow(java.lang.String textOverflow) {
        this.textOverflow = textOverflow;
    }


    /**
     * Gets the textPlaceholders value for this Story.
     * 
     * @return textPlaceholders
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] getTextPlaceholders() {
        return textPlaceholders;
    }


    /**
     * Sets the textPlaceholders value for this Story.
     * 
     * @param textPlaceholders
     */
    public void setTextPlaceholders(com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder[] textPlaceholders) {
        this.textPlaceholders = textPlaceholders;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder getTextPlaceholders(int i) {
        return this.textPlaceholders[i];
    }

    public void setTextPlaceholders(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.TextPlaceholder _value) {
        this.textPlaceholders[i] = _value;
    }


    /**
     * Gets the UID value for this Story.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this Story.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Story)) return false;
        Story other = (Story) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.anchoredBoxReferences==null && other.getAnchoredBoxReferences()==null) || 
             (this.anchoredBoxReferences!=null &&
              java.util.Arrays.equals(this.anchoredBoxReferences, other.getAnchoredBoxReferences()))) &&
            ((this.annotateTextOverflow==null && other.getAnnotateTextOverflow()==null) || 
             (this.annotateTextOverflow!=null &&
              this.annotateTextOverflow.equals(other.getAnnotateTextOverflow()))) &&
            ((this.boxName==null && other.getBoxName()==null) || 
             (this.boxName!=null &&
              this.boxName.equals(other.getBoxName()))) &&
            ((this.calloutAnchors==null && other.getCalloutAnchors()==null) || 
             (this.calloutAnchors!=null &&
              java.util.Arrays.equals(this.calloutAnchors, other.getCalloutAnchors()))) &&
            ((this.clearOldText==null && other.getClearOldText()==null) || 
             (this.clearOldText!=null &&
              this.clearOldText.equals(other.getClearOldText()))) &&
            ((this.convertQuotes==null && other.getConvertQuotes()==null) || 
             (this.convertQuotes!=null &&
              this.convertQuotes.equals(other.getConvertQuotes()))) &&
            ((this.copyFit==null && other.getCopyFit()==null) || 
             (this.copyFit!=null &&
              this.copyFit.equals(other.getCopyFit()))) &&
            ((this.file==null && other.getFile()==null) || 
             (this.file!=null &&
              this.file.equals(other.getFile()))) &&
            ((this.fitText==null && other.getFitText()==null) || 
             (this.fitText!=null &&
              this.fitText.equals(other.getFitText()))) &&
            ((this.fitTextToBox==null && other.getFitTextToBox()==null) || 
             (this.fitTextToBox!=null &&
              this.fitTextToBox.equals(other.getFitTextToBox()))) &&
            ((this.hiddenData==null && other.getHiddenData()==null) || 
             (this.hiddenData!=null &&
              java.util.Arrays.equals(this.hiddenData, other.getHiddenData()))) &&
            ((this.includeStylesheets==null && other.getIncludeStylesheets()==null) || 
             (this.includeStylesheets!=null &&
              this.includeStylesheets.equals(other.getIncludeStylesheets()))) &&
            ((this.indexTerms==null && other.getIndexTerms()==null) || 
             (this.indexTerms!=null &&
              java.util.Arrays.equals(this.indexTerms, other.getIndexTerms()))) &&
            ((this.indexes==null && other.getIndexes()==null) || 
             (this.indexes!=null &&
              java.util.Arrays.equals(this.indexes, other.getIndexes()))) &&
            ((this.inlineBoxes==null && other.getInlineBoxes()==null) || 
             (this.inlineBoxes!=null &&
              java.util.Arrays.equals(this.inlineBoxes, other.getInlineBoxes()))) &&
            ((this.inlineItems==null && other.getInlineItems()==null) || 
             (this.inlineItems!=null &&
              java.util.Arrays.equals(this.inlineItems, other.getInlineItems()))) &&
            ((this.inlineTables==null && other.getInlineTables()==null) || 
             (this.inlineTables!=null &&
              java.util.Arrays.equals(this.inlineTables, other.getInlineTables()))) &&
            ((this.linkedBoxes==null && other.getLinkedBoxes()==null) || 
             (this.linkedBoxes!=null &&
              java.util.Arrays.equals(this.linkedBoxes, other.getLinkedBoxes()))) &&
            ((this.lists==null && other.getLists()==null) || 
             (this.lists!=null &&
              java.util.Arrays.equals(this.lists, other.getLists()))) &&
            ((this.overMatter==null && other.getOverMatter()==null) || 
             (this.overMatter!=null &&
              this.overMatter.equals(other.getOverMatter()))) &&
            ((this.pageBreaks==null && other.getPageBreaks()==null) || 
             (this.pageBreaks!=null &&
              java.util.Arrays.equals(this.pageBreaks, other.getPageBreaks()))) &&
            ((this.pageSequences==null && other.getPageSequences()==null) || 
             (this.pageSequences!=null &&
              java.util.Arrays.equals(this.pageSequences, other.getPageSequences()))) &&
            ((this.paragraphs==null && other.getParagraphs()==null) || 
             (this.paragraphs!=null &&
              java.util.Arrays.equals(this.paragraphs, other.getParagraphs()))) &&
            ((this.refNotes==null && other.getRefNotes()==null) || 
             (this.refNotes!=null &&
              java.util.Arrays.equals(this.refNotes, other.getRefNotes()))) &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText()))) &&
            ((this.rubi==null && other.getRubi()==null) || 
             (this.rubi!=null &&
              java.util.Arrays.equals(this.rubi, other.getRubi()))) &&
            ((this.storyDirection==null && other.getStoryDirection()==null) || 
             (this.storyDirection!=null &&
              this.storyDirection.equals(other.getStoryDirection()))) &&
            ((this.textNodePlaceholders==null && other.getTextNodePlaceholders()==null) || 
             (this.textNodePlaceholders!=null &&
              java.util.Arrays.equals(this.textNodePlaceholders, other.getTextNodePlaceholders()))) &&
            ((this.textOverflow==null && other.getTextOverflow()==null) || 
             (this.textOverflow!=null &&
              this.textOverflow.equals(other.getTextOverflow()))) &&
            ((this.textPlaceholders==null && other.getTextPlaceholders()==null) || 
             (this.textPlaceholders!=null &&
              java.util.Arrays.equals(this.textPlaceholders, other.getTextPlaceholders()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAnchoredBoxReferences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAnchoredBoxReferences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAnchoredBoxReferences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAnnotateTextOverflow() != null) {
            _hashCode += getAnnotateTextOverflow().hashCode();
        }
        if (getBoxName() != null) {
            _hashCode += getBoxName().hashCode();
        }
        if (getCalloutAnchors() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCalloutAnchors());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCalloutAnchors(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getClearOldText() != null) {
            _hashCode += getClearOldText().hashCode();
        }
        if (getConvertQuotes() != null) {
            _hashCode += getConvertQuotes().hashCode();
        }
        if (getCopyFit() != null) {
            _hashCode += getCopyFit().hashCode();
        }
        if (getFile() != null) {
            _hashCode += getFile().hashCode();
        }
        if (getFitText() != null) {
            _hashCode += getFitText().hashCode();
        }
        if (getFitTextToBox() != null) {
            _hashCode += getFitTextToBox().hashCode();
        }
        if (getHiddenData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHiddenData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHiddenData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIncludeStylesheets() != null) {
            _hashCode += getIncludeStylesheets().hashCode();
        }
        if (getIndexTerms() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIndexTerms());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIndexTerms(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIndexes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIndexes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIndexes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInlineBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInlineItems() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineItems());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineItems(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInlineTables() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInlineTables());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInlineTables(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLinkedBoxes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLinkedBoxes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLinkedBoxes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLists() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLists());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLists(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOverMatter() != null) {
            _hashCode += getOverMatter().hashCode();
        }
        if (getPageBreaks() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPageBreaks());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPageBreaks(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPageSequences() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPageSequences());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPageSequences(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getParagraphs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParagraphs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParagraphs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRefNotes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRefNotes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRefNotes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRubi() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRubi());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRubi(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getStoryDirection() != null) {
            _hashCode += getStoryDirection().hashCode();
        }
        if (getTextNodePlaceholders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTextNodePlaceholders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTextNodePlaceholders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTextOverflow() != null) {
            _hashCode += getTextOverflow().hashCode();
        }
        if (getTextPlaceholders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTextPlaceholders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTextPlaceholders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Story.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Story"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anchoredBoxReferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "anchoredBoxReferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AnchoredBoxReference"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("annotateTextOverflow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "annotateTextOverflow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("boxName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "boxName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("calloutAnchors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "calloutAnchors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CalloutAnchor"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clearOldText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "clearOldText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("convertQuotes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "convertQuotes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("copyFit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "copyFit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "CopyFit"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "file"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fitText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fitText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "FitText"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fitTextToBox");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "fitTextToBox"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hiddenData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "hiddenData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "HiddenData"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeStylesheets");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "includeStylesheets"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indexTerms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "indexTerms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexTerm"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indexes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "indexes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Index"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineBoxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineBoxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineBox"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineItems");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineItem"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inlineTables");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inlineTables"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "InlineTable"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("linkedBoxes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "linkedBoxes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LinkedBox"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lists");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "lists"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "List"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("overMatter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "overMatter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "OverMatter"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageBreaks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pageBreaks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageBreak"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageSequences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "pageSequences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "PageSequence"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paragraphs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "paragraphs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Paragraph"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refNotes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "refNotes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RefNote"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RichText"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rubi");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rubi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Rubi"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("storyDirection");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "storyDirection"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textNodePlaceholders");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "textNodePlaceholders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TextNodePlaceholder"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textOverflow");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "textOverflow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textPlaceholders");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "textPlaceholders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TextPlaceholder"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
