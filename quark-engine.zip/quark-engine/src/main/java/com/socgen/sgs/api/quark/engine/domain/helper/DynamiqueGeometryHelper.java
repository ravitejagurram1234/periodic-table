package com.socgen.sgs.api.quark.engine.domain.helper;

import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DCell;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DPoint;
import com.socgen.sgs.api.quark.engine.domain.dynamic.report.DZone;
import com.socgen.sgs.api.quark.engine.domain.dynamic.template.Template;

import java.math.BigDecimal;

/**
 * Provides geometry calculations for positioning elements in a dynamic report.
 * Computes zones (left, top, width, height) for cells based on cursor position
 * and template dimensions.
 *
 * Cross-reference: QXP.Engine.Core.Dynamique_Geometry_Helper
 */
public final class DynamiqueGeometryHelper {

    private DynamiqueGeometryHelper() {
    }

    /**
     * Calculate a DZone for a cell and update the cursor position.
     * After calculation, the cursor's left is advanced by (zone.width + template.left).
     *
     * @param cursor the current cursor position (updated in place)
     * @param cell   the cell to calculate the zone for
     * @return a new DZone representing the cell's position and dimensions
     */
    public static DZone getZoneAndUpdateCursor(DPoint cursor, DCell cell) {
        DZone zone = getZone(cursor, cell);
        if (cursor != null) {
            cursor.setLeft(cursor.getLeft().add(zone.getWidth()).add(cell.getTemplate().getLeft()));
        }
        return zone;
    }

    /**
     * Calculate a DZone for a cell without updating the cursor.
     *
     * @param cursor the current cursor position (may be null for absolute cells)
     * @param cell   the cell to calculate the zone for
     * @return a new DZone representing the cell's position and dimensions
     */
    public static DZone getZone(DPoint cursor, DCell cell) {
        Template template = cell.getTemplate();
        BigDecimal left = template.getLeft();
        BigDecimal top = template.getTop();
        BigDecimal width = getCellWidthWithoutLeft(cell);
        BigDecimal height = getCellHeightWithoutTop(cell);

        if (cursor == null) {
            return new DZone(left, top, width, height);
        } else {
            return new DZone(
                    left.add(cursor.getLeft()),
                    top.add(cursor.getTop()),
                    width,
                    height
            );
        }
    }

    /**
     * Get the absolute height of a cell including top margin.
     * Uses template height if set, otherwise uses TElement height.
     * Adds template.top for non-absolute cells.
     *
     * @param cell the cell
     * @return the total height including top margin
     */
    public static BigDecimal getCellHeightWithTop(DCell cell) {
        BigDecimal height = getCellHeightWithoutTop(cell);
        if (!cell.getTemplate().isAbsolute()) {
            height = height.add(cell.getTemplate().getTop());
        }
        return height;
    }

    /**
     * Get the height of a cell without top margin.
     * Uses template height if set (> 0), otherwise uses TElement height.
     *
     * @param cell the cell
     * @return the height without top margin
     */
    public static BigDecimal getCellHeightWithoutTop(DCell cell) {
        BigDecimal templateHeight = cell.getTemplate().getHeight();
        if (templateHeight != null && templateHeight.compareTo(BigDecimal.ZERO) != 0) {
            return templateHeight;
        }
        if (cell.getTElement() != null) {
            return cell.getTElement().getHeight();
        }
        return BigDecimal.ZERO;
    }

    /**
     * Get the absolute width of a cell including left margin.
     * Uses template width if set, otherwise uses TElement width.
     * Adds template.left for non-absolute cells.
     *
     * @param cell the cell
     * @return the total width including left margin
     */
    public static BigDecimal getCellWidthWithLeft(DCell cell) {
        BigDecimal width = getCellWidthWithoutLeft(cell);
        if (!cell.getTemplate().isAbsolute()) {
            width = width.add(cell.getTemplate().getLeft());
        }
        return width;
    }

    /**
     * Get the width of a cell without left margin.
     * Uses template width if set (> 0), otherwise uses TElement width.
     *
     * @param cell the cell
     * @return the width without left margin
     */
    public static BigDecimal getCellWidthWithoutLeft(DCell cell) {
        BigDecimal templateWidth = cell.getTemplate().getWidth();
        if (templateWidth != null && templateWidth.compareTo(BigDecimal.ZERO) != 0) {
            return templateWidth;
        }
        if (cell.getTElement() != null) {
            return cell.getTElement().getWidth();
        }
        return BigDecimal.ZERO;
    }
}