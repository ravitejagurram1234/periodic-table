package com.socgen.sgs.api.quark.engine.domain;

import lombok.Getter;

/**
 * Defines the execution mode of compartment-type tasks.
 */
@Getter
public enum TaskCompartimentMode {

    /** Unknown mode */
    UNKNOWN(0),

    /** Generate the runs for the task */
    GENERATE(1),

    /** Incorporate data from previous runs of the task */
    INCORPORATE(2),

    /** Generate and incorporate runs of the task */
    GENERATE_AND_INCORPORATE(3);

    private final int code;

    TaskCompartimentMode(int code) {
        this.code = code;
    }

    public static TaskCompartimentMode fromCode(int code) {
        for (TaskCompartimentMode mode : values()) {
            if (mode.code == code) {
                return mode;
            }
        }
        return UNKNOWN;
    }
}

