package com.socgen.sgs.api.quark.engine.enums;
public enum SubTaskTypeEnum {
    UNKNOWN,
    VALUE,
    FILE_IMG,
    FILE_XTG,
    FILE_DOC,
    FILE_RTF,
    FILE_PDF,
    FILE_UPLOAD,
    FILE_DELETE,
    FILE_QXP_PREVIOUS,
    FILE_QXP_DATA,
    SQL,
    BOX,
    TABLE,
    PAGE;
    public static SubTaskTypeEnum fromName(String name) {
        if (name == null) {
            return UNKNOWN;
        }
        try {
            return valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return UNKNOWN;
        }
    }
}
