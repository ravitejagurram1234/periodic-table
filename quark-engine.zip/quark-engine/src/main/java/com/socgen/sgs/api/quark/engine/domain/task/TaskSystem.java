package com.socgen.sgs.api.quark.engine.domain.task;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Box;
import lombok.Getter;
import lombok.Setter;

/** Represents a system task that performs actions on TBox template boxes. */
@Getter
@Setter
public class TaskSystem extends TaskBase {

    private boolean showZero = false;
    private int nbDecimal = 0;
    private boolean decimalSignificative = true;
    private DataTypeEnum dataType = DataTypeEnum.UNSPECIFIED;
    private Object value = null;
    private boolean pagination = false;
    private BlocActionEnum action = BlocActionEnum.NONE;

    // Box mode fields (for copying/moving box from gabarit template)
    /** Source box reference from the gabarit template. */
    private Box tBoxSrcBox;
    /** Extra box reference (e.g., for linked boxes). */
    private Box tBoxSrcExtraBox;

    public TaskSystem(int id, Run run) {
        super(id, run);
    }

    @Override
    public void prepare() {
    }
}



