package com.socgen.sgs.api.quark.engine.infra.interop.qxps.message;

import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 * QXPS GET message for saving the document with a new name.
 *
 * URL: {baseUrl}/saveas/{documentName}?newname={name}&path={path}
 * NOTE: replace and savetopool default to true — only added to query when false.
 *
 * Cross-reference: .NET QXPS_Message_SaveAs
 */
@Getter
public class SaveAsMessage implements QxpsMessage {

    private static final String MESSAGE_PATH = "saveas";

    private final String newName;
    private final String path;
    private final boolean replace;
    private final boolean saveToPool;

    public SaveAsMessage(String path, String newName, boolean replace, boolean saveToPool) {
        this.path = path;
        this.newName = newName;
        this.replace = replace;
        this.saveToPool = saveToPool;
    }

    /** Convenience constructor with defaults: replace=true, saveToPool=true */
    public SaveAsMessage(String path, String newName) {
        this(path, newName, true, true);
    }

    @Override
    public String getCommandPath() {
        return MESSAGE_PATH;
    }

    @Override
    public String getCommandQuery() {
        List<String> args = new ArrayList<>();
        if (newName != null && !newName.isEmpty()) {
            args.add("newname=" + newName);
        }
        // Only add when false (default is true on server side)
        if (!replace) {
            args.add("replace=false");
        }
        if (!saveToPool) {
            args.add("savetopool=false");
        }
        if (path != null && !path.isEmpty()) {
            args.add("path=" + path);
        }
        return args.isEmpty() ? null : String.join("&", args);
    }

    @Override
    public byte[] getData() {
        return null;
    }

    @Override
    public boolean isPost() {
        return false;
    }

    @Override
    public MessagePriority getPriority() {
        return MessagePriority.BELOW_NORMAL;
    }
}