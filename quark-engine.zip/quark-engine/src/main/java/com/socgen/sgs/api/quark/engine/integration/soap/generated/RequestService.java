/**
 * RequestService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public interface RequestService extends javax.xml.rpc.Service {
    public java.lang.String getRequestServiceHttpSoap11EndpointAddress();

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RequestServicePortType getRequestServiceHttpSoap11Endpoint() throws javax.xml.rpc.ServiceException;

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RequestServicePortType getRequestServiceHttpSoap11Endpoint(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
