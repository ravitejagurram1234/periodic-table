package com.socgen.sgs.api.quark.engine.infra.dao;

import java.util.List;
import java.util.Map;

public interface TaskSqlDao {
    List<Map<String, Object>> executeSql(String sql, Map<String, Object> parameters);
}

