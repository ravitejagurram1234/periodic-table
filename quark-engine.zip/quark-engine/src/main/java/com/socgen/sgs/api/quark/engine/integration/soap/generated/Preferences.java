/**
 * Preferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Preferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.AuthenticationPreferences authenticationPreferences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences emailPreferences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences loggingPreferences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences serverPreferences;

    public Preferences() {
    }

    public Preferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.AuthenticationPreferences authenticationPreferences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences emailPreferences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences loggingPreferences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences serverPreferences) {
        super(
            request);
        this.authenticationPreferences = authenticationPreferences;
        this.emailPreferences = emailPreferences;
        this.loggingPreferences = loggingPreferences;
        this.serverPreferences = serverPreferences;
    }


    /**
     * Gets the authenticationPreferences value for this Preferences.
     * 
     * @return authenticationPreferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.AuthenticationPreferences getAuthenticationPreferences() {
        return authenticationPreferences;
    }


    /**
     * Sets the authenticationPreferences value for this Preferences.
     * 
     * @param authenticationPreferences
     */
    public void setAuthenticationPreferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.AuthenticationPreferences authenticationPreferences) {
        this.authenticationPreferences = authenticationPreferences;
    }


    /**
     * Gets the emailPreferences value for this Preferences.
     * 
     * @return emailPreferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences getEmailPreferences() {
        return emailPreferences;
    }


    /**
     * Sets the emailPreferences value for this Preferences.
     * 
     * @param emailPreferences
     */
    public void setEmailPreferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences emailPreferences) {
        this.emailPreferences = emailPreferences;
    }


    /**
     * Gets the loggingPreferences value for this Preferences.
     * 
     * @return loggingPreferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences getLoggingPreferences() {
        return loggingPreferences;
    }


    /**
     * Sets the loggingPreferences value for this Preferences.
     * 
     * @param loggingPreferences
     */
    public void setLoggingPreferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences loggingPreferences) {
        this.loggingPreferences = loggingPreferences;
    }


    /**
     * Gets the serverPreferences value for this Preferences.
     * 
     * @return serverPreferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences getServerPreferences() {
        return serverPreferences;
    }


    /**
     * Sets the serverPreferences value for this Preferences.
     * 
     * @param serverPreferences
     */
    public void setServerPreferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences serverPreferences) {
        this.serverPreferences = serverPreferences;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Preferences)) return false;
        Preferences other = (Preferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.authenticationPreferences==null && other.getAuthenticationPreferences()==null) || 
             (this.authenticationPreferences!=null &&
              this.authenticationPreferences.equals(other.getAuthenticationPreferences()))) &&
            ((this.emailPreferences==null && other.getEmailPreferences()==null) || 
             (this.emailPreferences!=null &&
              this.emailPreferences.equals(other.getEmailPreferences()))) &&
            ((this.loggingPreferences==null && other.getLoggingPreferences()==null) || 
             (this.loggingPreferences!=null &&
              this.loggingPreferences.equals(other.getLoggingPreferences()))) &&
            ((this.serverPreferences==null && other.getServerPreferences()==null) || 
             (this.serverPreferences!=null &&
              this.serverPreferences.equals(other.getServerPreferences())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAuthenticationPreferences() != null) {
            _hashCode += getAuthenticationPreferences().hashCode();
        }
        if (getEmailPreferences() != null) {
            _hashCode += getEmailPreferences().hashCode();
        }
        if (getLoggingPreferences() != null) {
            _hashCode += getLoggingPreferences().hashCode();
        }
        if (getServerPreferences() != null) {
            _hashCode += getServerPreferences().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Preferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Preferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authenticationPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "authenticationPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "AuthenticationPreferences"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "emailPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "EMailPreferences"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loggingPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "loggingPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "LoggingPreferences"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "serverPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ServerPreferences"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
