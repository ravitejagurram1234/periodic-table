/**
 * Preferences.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Preferences  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences emailPreferences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.HTTPPreferences httpPreferences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences loggingPreferences;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences serverPreferences;

    private boolean statusMonitorOpenOption;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonitorPosition statusMonitorPosition;

    private java.lang.String version;

    public Preferences() {
    }

    public Preferences(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences emailPreferences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.HTTPPreferences httpPreferences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences loggingPreferences,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences serverPreferences,
           boolean statusMonitorOpenOption,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonitorPosition statusMonitorPosition,
           java.lang.String version) {
        super(
            request);
        this.emailPreferences = emailPreferences;
        this.httpPreferences = httpPreferences;
        this.loggingPreferences = loggingPreferences;
        this.serverPreferences = serverPreferences;
        this.statusMonitorOpenOption = statusMonitorOpenOption;
        this.statusMonitorPosition = statusMonitorPosition;
        this.version = version;
    }


    /**
     * Gets the emailPreferences value for this Preferences.
     * 
     * @return emailPreferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences getEmailPreferences() {
        return emailPreferences;
    }


    /**
     * Sets the emailPreferences value for this Preferences.
     * 
     * @param emailPreferences
     */
    public void setEmailPreferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.EMailPreferences emailPreferences) {
        this.emailPreferences = emailPreferences;
    }


    /**
     * Gets the httpPreferences value for this Preferences.
     * 
     * @return httpPreferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.HTTPPreferences getHttpPreferences() {
        return httpPreferences;
    }


    /**
     * Sets the httpPreferences value for this Preferences.
     * 
     * @param httpPreferences
     */
    public void setHttpPreferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.HTTPPreferences httpPreferences) {
        this.httpPreferences = httpPreferences;
    }


    /**
     * Gets the loggingPreferences value for this Preferences.
     * 
     * @return loggingPreferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences getLoggingPreferences() {
        return loggingPreferences;
    }


    /**
     * Sets the loggingPreferences value for this Preferences.
     * 
     * @param loggingPreferences
     */
    public void setLoggingPreferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.LoggingPreferences loggingPreferences) {
        this.loggingPreferences = loggingPreferences;
    }


    /**
     * Gets the serverPreferences value for this Preferences.
     * 
     * @return serverPreferences
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences getServerPreferences() {
        return serverPreferences;
    }


    /**
     * Sets the serverPreferences value for this Preferences.
     * 
     * @param serverPreferences
     */
    public void setServerPreferences(com.socgen.sgs.api.quark.engine.integration.soap.generated.ServerPreferences serverPreferences) {
        this.serverPreferences = serverPreferences;
    }


    /**
     * Gets the statusMonitorOpenOption value for this Preferences.
     * 
     * @return statusMonitorOpenOption
     */
    public boolean isStatusMonitorOpenOption() {
        return statusMonitorOpenOption;
    }


    /**
     * Sets the statusMonitorOpenOption value for this Preferences.
     * 
     * @param statusMonitorOpenOption
     */
    public void setStatusMonitorOpenOption(boolean statusMonitorOpenOption) {
        this.statusMonitorOpenOption = statusMonitorOpenOption;
    }


    /**
     * Gets the statusMonitorPosition value for this Preferences.
     * 
     * @return statusMonitorPosition
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonitorPosition getStatusMonitorPosition() {
        return statusMonitorPosition;
    }


    /**
     * Sets the statusMonitorPosition value for this Preferences.
     * 
     * @param statusMonitorPosition
     */
    public void setStatusMonitorPosition(com.socgen.sgs.api.quark.engine.integration.soap.generated.StatusMonitorPosition statusMonitorPosition) {
        this.statusMonitorPosition = statusMonitorPosition;
    }


    /**
     * Gets the version value for this Preferences.
     * 
     * @return version
     */
    public java.lang.String getVersion() {
        return version;
    }


    /**
     * Sets the version value for this Preferences.
     * 
     * @param version
     */
    public void setVersion(java.lang.String version) {
        this.version = version;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Preferences)) return false;
        Preferences other = (Preferences) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.emailPreferences==null && other.getEmailPreferences()==null) || 
             (this.emailPreferences!=null &&
              this.emailPreferences.equals(other.getEmailPreferences()))) &&
            ((this.httpPreferences==null && other.getHttpPreferences()==null) || 
             (this.httpPreferences!=null &&
              this.httpPreferences.equals(other.getHttpPreferences()))) &&
            ((this.loggingPreferences==null && other.getLoggingPreferences()==null) || 
             (this.loggingPreferences!=null &&
              this.loggingPreferences.equals(other.getLoggingPreferences()))) &&
            ((this.serverPreferences==null && other.getServerPreferences()==null) || 
             (this.serverPreferences!=null &&
              this.serverPreferences.equals(other.getServerPreferences()))) &&
            this.statusMonitorOpenOption == other.isStatusMonitorOpenOption() &&
            ((this.statusMonitorPosition==null && other.getStatusMonitorPosition()==null) || 
             (this.statusMonitorPosition!=null &&
              this.statusMonitorPosition.equals(other.getStatusMonitorPosition()))) &&
            ((this.version==null && other.getVersion()==null) || 
             (this.version!=null &&
              this.version.equals(other.getVersion())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getEmailPreferences() != null) {
            _hashCode += getEmailPreferences().hashCode();
        }
        if (getHttpPreferences() != null) {
            _hashCode += getHttpPreferences().hashCode();
        }
        if (getLoggingPreferences() != null) {
            _hashCode += getLoggingPreferences().hashCode();
        }
        if (getServerPreferences() != null) {
            _hashCode += getServerPreferences().hashCode();
        }
        _hashCode += (isStatusMonitorOpenOption() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getStatusMonitorPosition() != null) {
            _hashCode += getStatusMonitorPosition().hashCode();
        }
        if (getVersion() != null) {
            _hashCode += getVersion().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Preferences.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "Preferences"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("", "emailPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "EMailPreferences"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("httpPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("", "httpPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "HTTPPreferences"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loggingPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("", "loggingPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "LoggingPreferences"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("", "serverPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "ServerPreferences"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusMonitorOpenOption");
        elemField.setXmlName(new javax.xml.namespace.QName("", "statusMonitorOpenOption"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusMonitorPosition");
        elemField.setXmlName(new javax.xml.namespace.QName("", "statusMonitorPosition"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ro.clientsdk.manager.quark.com", "StatusMonitorPosition"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
