package com.socgen.sgs.api.quark.engine.domain;
import lombok.Getter;
/** Immutable value object representing a data pair with name, value, description and info. */
@Getter
public class DataNameValue {
    private final String name;
    private final String value;
    private final String descriptif;
    private final String info;
    public DataNameValue(String name, String value) {
        this(name, value, "", "");
    }
    public DataNameValue(String name, String value, String descriptif, String info) {
        this.name       = name;
        this.value      = value;
        this.descriptif = descriptif != null ? descriptif : "";
        this.info       = info != null ? info : "";
    }
    @Override
    public String toString() {
        return "DataNameValue{" +
                "name='" + name + '\'' +
                ", value='" + value + '\'' +
                ", descriptif='" + descriptif + '\'' +
                ", info='" + info + '\'' +
                '}';
    }
}
