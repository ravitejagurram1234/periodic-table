package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.RunError;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocTable;
import com.socgen.sgs.api.quark.engine.domain.element.TBox;
import com.socgen.sgs.api.quark.engine.domain.element.TElement;
import com.socgen.sgs.api.quark.engine.domain.element.TTable;
import com.socgen.sgs.api.quark.engine.domain.helper.TElementHelper;
import com.socgen.sgs.api.quark.engine.domain.task.TaskQxpPrevious;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.service.task.TaskProcessStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Strategy for TaskQxpPrevious (DOC_QXP) — copy blocs from a previously certified QXP into the
 * current template, either as values or with their styles.
 *
 * <p>Two modes:
 * <ul>
 *   <li><b>Explicit</b> — source/destination bloc names given, '|'-separated. The destination may
 *       carry a position hint after a '¤' (U+00A4) used to resolve a TTable's spread/layout.</li>
 *   <li><b>Hierarchy</b> — no names given: walk source blocs ending with {@code .N0}, {@code .N1}, …
 *       and write each to the next level ({@code .N{level+1}}).</li>
 * </ul>
 *
 * <p>The source document is loaded + pool-uploaded (and its XML/project fetched) beforehand by
 * {@code LoadTaskDocumentsBusiness}. Cross-reference: QXP.Engine.Core.Business.Process_QXP_Previous.
 */
@Component
@Slf4j
public class QxpPreviousTaskProcessStrategy implements TaskProcessStrategy<TaskQxpPrevious> {

    /** Suffix marking source blocs in hierarchy mode (e.g. ".N0", ".N1"). */
    private static final String BLOC_N_SUFFIX = ".N";
    /** Position separator inside the destination field (U+00A4 ¤), matching .NET Split('¤'). */
    private static final String POSITION_SEPARATOR = "¤";
    private static final int N_SUFFIX_LEN = 3; // ".N" + single-digit level

    @Override
    public Class<TaskQxpPrevious> getTaskType() {
        return TaskQxpPrevious.class;
    }

    @Override
    public void process(TaskQxpPrevious task) {
        DocumentDomain doc = task.getDocument();
        if (doc == null) {
            // The document load failed/was empty — the loader already recorded the error.
            log.warn("QXP_Previous task [{}] has no source document, skipping", task.getId());
            return;
        }

        if (isSet(task.getSourceBlocName()) && isSet(task.getDestinationBlocName())) {
            // Explicit mode — '|'-separated source/destination names.
            String[] listSource = task.getSourceBlocName().split("\\|", -1);

            // The destination may encode "names¤positionName" (used to locate a TTable's spread/layout).
            String[] positionParts = task.getDestinationBlocName().split(POSITION_SEPARATOR, -1);
            String[] listDest;
            if (positionParts.length == 2) {
                listDest = positionParts[0].split("\\|", -1);
                task.setPositionBlocName(positionParts[1]);
            } else {
                listDest = task.getDestinationBlocName().split("\\|", -1);
            }

            if (listSource.length != listDest.length) {
                // .NET Errors.Add(Invalid_List_Count, ...) → Unspecified.
                task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                        "Invalid_List_Count: " + listSource.length + " source(s) vs " + listDest.length
                                + " destination(s) pour la tache " + task.getId()));
            }

            if (task.isConserverStyle()) {
                doc.getQxpProject().analyse(task, false);
            }

            addBlocsExplicit(task, doc, listSource, listDest);
        } else {
            // Hierarchy mode — collect source blocs by level (.N0, .N1, …) until a level is empty.
            SortedMap<Integer, List<String>> byLevels = new TreeMap<>();
            int level = 0;
            while (true) {
                List<String> names = doc.getQxpXml().getListBoxNameEndWith(BLOC_N_SUFFIX + level);
                if (names != null && !names.isEmpty()) {
                    byLevels.put(level, names);
                    level++;
                } else {
                    break;
                }
            }
            if (!byLevels.isEmpty()) {
                addBlocsByLevels(task, doc, byLevels);
            }
        }
    }

    // ------------------------------------------------------------------
    // Explicit mode — Cross-reference: Process_QXP_Previous.AddBlocs(task, source[], dest[])
    // ------------------------------------------------------------------

    private void addBlocsExplicit(TaskQxpPrevious task, DocumentDomain doc,
                                  String[] listSource, String[] listDest) {
        // .NET iterates source.Length and indexes dest[i] (would throw on a shorter dest). We iterate
        // the safe overlap after recording Invalid_List_Count above — consistent with the approved
        // Document-task count-mismatch handling.
        int count = Math.min(listSource.length, listDest.length);
        for (int i = 0; i < count; i++) {
            String source = listSource[i];
            String dest = listDest[i];

            if (task.getBlocsUpdate().containsKey(dest) || task.getBlocsModify().containsKey(dest)) {
                task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                        "ErrorDuplicateBlocInTask: bloc [" + dest + "] deja present dans la tache " + task.getId()));
                continue;
            }

            if (task.isConserverStyle()) {
                Map<String, TElement> elements = doc.getQxpProject().getElements();
                if (elements != null && elements.containsKey(source)) {
                    TElement element = elements.get(source);
                    if (element instanceof TBox) {
                        addStyleBox(task, (TBox) element, dest);
                    } else if (element instanceof TTable) {
                        addStyleTable(task, (TTable) element, dest);
                    } else {
                        task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                                "Invalid_TElement_Type: [" + source + "] (tache " + task.getId() + ")"));
                    }
                } else {
                    task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                            "Missing_TElement: [" + source + "] (tache " + task.getId() + ")"));
                }
            } else {
                // Value only.
                BlocBox bloc = new BlocBox(task, dest, doc.getQxpXml().getValue(source));
                bloc.setAction(BlocActionEnum.UPDATE);
                task.getBlocsUpdate().put(dest, bloc);
            }
        }
    }

    // ------------------------------------------------------------------
    // Hierarchy mode — Cross-reference: Process_QXP_Previous.AddBlocs(task, byLevels)
    // ------------------------------------------------------------------

    private void addBlocsByLevels(TaskQxpPrevious task, DocumentDomain doc,
                                  SortedMap<Integer, List<String>> byLevels) {
        for (Map.Entry<Integer, List<String>> entry : byLevels.entrySet()) {
            int level = entry.getKey();
            for (String source : entry.getValue()) {
                if (source == null || source.length() < N_SUFFIX_LEN) {
                    continue;
                }
                // dest = <source without its ".Nx" suffix> + ".N" + (level+1)
                String dest = source.substring(0, source.length() - N_SUFFIX_LEN)
                        + BLOC_N_SUFFIX + (level + 1);
                try {
                    if (task.getBlocsUpdate().containsKey(dest)) {
                        task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                                "ErrorDuplicateBlocInTask: bloc [" + dest + "] deja present dans la tache " + task.getId()));
                    } else {
                        String value = doc.getQxpXml().getValue(source);
                        // Quark rejects empty strings at save time → substitute the task NullString.
                        if (value == null || value.isBlank()) {
                            value = task.getNullString();
                        }
                        BlocBox bloc = new BlocBox(task, dest, value);
                        bloc.setAction(BlocActionEnum.UPDATE);
                        task.getBlocsUpdate().put(dest, bloc);
                    }
                } catch (Exception e) {
                    task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                            "ErrorAddingBlocInTask: source [" + source + "] dest [" + dest + "] (tache "
                                    + task.getId() + ")"));
                    log.warn("Error adding bloc {}->{} for task {}: {}", source, dest, task.getId(), e.getMessage());
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Style copy helpers — Cross-reference: Process_QXP_Previous.AddBloc(TBox/TTable)
    // ------------------------------------------------------------------

    private void addStyleBox(TaskQxpPrevious task, TBox tBox, String newName) {
        TBox destTBox = TElementHelper.getNewTBoxStyleValueFromTBox(tBox, newName);
        if (destTBox == null) {
            task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                    "ErrorAddingBlocInTask: impossible de copier le style TBox vers [" + newName + "]"));
            return;
        }
        BlocBox bloc = new BlocBox(task, newName, destTBox.getSrcBox(), destTBox.getSrcExtraBox());
        bloc.setAction(BlocActionEnum.UPDATE);
        task.getBlocsModify().put(newName, bloc);
    }

    private void addStyleTable(TaskQxpPrevious task, TTable tTable, String newName) {
        TTable destTTable = TElementHelper.getNewTTableStyleValueFromTTable(tTable, newName);
        if (destTTable == null) {
            task.getRun().getErrors().add(new RunError(RunError.UNSPECIFIED,
                    "ErrorAddingBlocInTask: impossible de copier le style TTable vers [" + newName + "]"));
            return;
        }
        BlocTable bloc = new BlocTable(task, newName, destTTable.getSrcTable());
        bloc.setAction(BlocActionEnum.UPDATE);
        task.getBlocsModify().put(newName, bloc);
    }

    private boolean isSet(String value) {
        return value != null && !value.isBlank();
    }
}