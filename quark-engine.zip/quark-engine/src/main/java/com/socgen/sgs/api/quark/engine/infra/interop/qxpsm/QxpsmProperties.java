package com.socgen.sgs.api.quark.engine.infra.interop.qxpsm;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration properties for QXPSM SOAP endpoint.
 */
@Configuration
@ConfigurationProperties(prefix = "qxpsm.soap")
@Getter
@Setter
public class QxpsmProperties {

    private String endpoint;
    private int timeout = 30000;
    private int maxRetries = 0;
}