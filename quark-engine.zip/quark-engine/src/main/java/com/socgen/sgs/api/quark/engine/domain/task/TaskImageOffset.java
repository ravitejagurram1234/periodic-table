package com.socgen.sgs.api.quark.engine.domain.task;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaskImageOffset {

    private static final int NO_VALUES = -1;

    private String[] values;
    private int valuesMax;

    public TaskImageOffset(String offsetValues) {
        if (offsetValues != null && !offsetValues.isEmpty()) {
            this.values = offsetValues.split("\\|");
            this.valuesMax = this.values.length - 1;
        } else {
            this.values = new String[0];
            this.valuesMax = NO_VALUES;
        }
    }

    public String getOffset(int imageNumber) {
        if (valuesMax == NO_VALUES) {
            return "";
        }
        if (imageNumber < 0 || imageNumber > valuesMax) {
            return values[valuesMax];
        }
        return values[imageNumber];
    }
}

