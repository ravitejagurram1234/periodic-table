/**
 * Entry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class Entry  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String alignment;

    private java.lang.String angle;

    private java.lang.String blendMode;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border;

    private java.lang.String colSpan;

    private java.lang.String color;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Gradient gradient;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset;

    private java.lang.String opacity;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText;

    private java.lang.String rowSpan;

    private java.lang.String shade;

    private java.lang.String valign;

    private java.lang.String value;

    public Entry() {
    }

    public Entry(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String alignment,
           java.lang.String angle,
           java.lang.String blendMode,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border,
           java.lang.String colSpan,
           java.lang.String color,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Gradient gradient,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset,
           java.lang.String opacity,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText,
           java.lang.String rowSpan,
           java.lang.String shade,
           java.lang.String valign,
           java.lang.String value) {
        super(
            request);
        this.alignment = alignment;
        this.angle = angle;
        this.blendMode = blendMode;
        this.border = border;
        this.colSpan = colSpan;
        this.color = color;
        this.content = content;
        this.gradient = gradient;
        this.indexTerms = indexTerms;
        this.inset = inset;
        this.opacity = opacity;
        this.paragraphs = paragraphs;
        this.picture = picture;
        this.richText = richText;
        this.rowSpan = rowSpan;
        this.shade = shade;
        this.valign = valign;
        this.value = value;
    }


    /**
     * Gets the alignment value for this Entry.
     * 
     * @return alignment
     */
    public java.lang.String getAlignment() {
        return alignment;
    }


    /**
     * Sets the alignment value for this Entry.
     * 
     * @param alignment
     */
    public void setAlignment(java.lang.String alignment) {
        this.alignment = alignment;
    }


    /**
     * Gets the angle value for this Entry.
     * 
     * @return angle
     */
    public java.lang.String getAngle() {
        return angle;
    }


    /**
     * Sets the angle value for this Entry.
     * 
     * @param angle
     */
    public void setAngle(java.lang.String angle) {
        this.angle = angle;
    }


    /**
     * Gets the blendMode value for this Entry.
     * 
     * @return blendMode
     */
    public java.lang.String getBlendMode() {
        return blendMode;
    }


    /**
     * Sets the blendMode value for this Entry.
     * 
     * @param blendMode
     */
    public void setBlendMode(java.lang.String blendMode) {
        this.blendMode = blendMode;
    }


    /**
     * Gets the border value for this Entry.
     * 
     * @return border
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Border getBorder() {
        return border;
    }


    /**
     * Sets the border value for this Entry.
     * 
     * @param border
     */
    public void setBorder(com.socgen.sgs.api.quark.engine.integration.soap.generated.Border border) {
        this.border = border;
    }


    /**
     * Gets the colSpan value for this Entry.
     * 
     * @return colSpan
     */
    public java.lang.String getColSpan() {
        return colSpan;
    }


    /**
     * Sets the colSpan value for this Entry.
     * 
     * @param colSpan
     */
    public void setColSpan(java.lang.String colSpan) {
        this.colSpan = colSpan;
    }


    /**
     * Gets the color value for this Entry.
     * 
     * @return color
     */
    public java.lang.String getColor() {
        return color;
    }


    /**
     * Sets the color value for this Entry.
     * 
     * @param color
     */
    public void setColor(java.lang.String color) {
        this.color = color;
    }


    /**
     * Gets the content value for this Entry.
     * 
     * @return content
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Content getContent() {
        return content;
    }


    /**
     * Sets the content value for this Entry.
     * 
     * @param content
     */
    public void setContent(com.socgen.sgs.api.quark.engine.integration.soap.generated.Content content) {
        this.content = content;
    }


    /**
     * Gets the gradient value for this Entry.
     * 
     * @return gradient
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Gradient getGradient() {
        return gradient;
    }


    /**
     * Sets the gradient value for this Entry.
     * 
     * @param gradient
     */
    public void setGradient(com.socgen.sgs.api.quark.engine.integration.soap.generated.Gradient gradient) {
        this.gradient = gradient;
    }


    /**
     * Gets the indexTerms value for this Entry.
     * 
     * @return indexTerms
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] getIndexTerms() {
        return indexTerms;
    }


    /**
     * Sets the indexTerms value for this Entry.
     * 
     * @param indexTerms
     */
    public void setIndexTerms(com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm[] indexTerms) {
        this.indexTerms = indexTerms;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm getIndexTerms(int i) {
        return this.indexTerms[i];
    }

    public void setIndexTerms(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.IndexTerm _value) {
        this.indexTerms[i] = _value;
    }


    /**
     * Gets the inset value for this Entry.
     * 
     * @return inset
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset getInset() {
        return inset;
    }


    /**
     * Sets the inset value for this Entry.
     * 
     * @param inset
     */
    public void setInset(com.socgen.sgs.api.quark.engine.integration.soap.generated.Inset inset) {
        this.inset = inset;
    }


    /**
     * Gets the opacity value for this Entry.
     * 
     * @return opacity
     */
    public java.lang.String getOpacity() {
        return opacity;
    }


    /**
     * Sets the opacity value for this Entry.
     * 
     * @param opacity
     */
    public void setOpacity(java.lang.String opacity) {
        this.opacity = opacity;
    }


    /**
     * Gets the paragraphs value for this Entry.
     * 
     * @return paragraphs
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] getParagraphs() {
        return paragraphs;
    }


    /**
     * Sets the paragraphs value for this Entry.
     * 
     * @param paragraphs
     */
    public void setParagraphs(com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph[] paragraphs) {
        this.paragraphs = paragraphs;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph getParagraphs(int i) {
        return this.paragraphs[i];
    }

    public void setParagraphs(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.Paragraph _value) {
        this.paragraphs[i] = _value;
    }


    /**
     * Gets the picture value for this Entry.
     * 
     * @return picture
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture getPicture() {
        return picture;
    }


    /**
     * Sets the picture value for this Entry.
     * 
     * @param picture
     */
    public void setPicture(com.socgen.sgs.api.quark.engine.integration.soap.generated.Picture picture) {
        this.picture = picture;
    }


    /**
     * Gets the richText value for this Entry.
     * 
     * @return richText
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] getRichText() {
        return richText;
    }


    /**
     * Sets the richText value for this Entry.
     * 
     * @param richText
     */
    public void setRichText(com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText[] richText) {
        this.richText = richText;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText getRichText(int i) {
        return this.richText[i];
    }

    public void setRichText(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.RichText _value) {
        this.richText[i] = _value;
    }


    /**
     * Gets the rowSpan value for this Entry.
     * 
     * @return rowSpan
     */
    public java.lang.String getRowSpan() {
        return rowSpan;
    }


    /**
     * Sets the rowSpan value for this Entry.
     * 
     * @param rowSpan
     */
    public void setRowSpan(java.lang.String rowSpan) {
        this.rowSpan = rowSpan;
    }


    /**
     * Gets the shade value for this Entry.
     * 
     * @return shade
     */
    public java.lang.String getShade() {
        return shade;
    }


    /**
     * Sets the shade value for this Entry.
     * 
     * @param shade
     */
    public void setShade(java.lang.String shade) {
        this.shade = shade;
    }


    /**
     * Gets the valign value for this Entry.
     * 
     * @return valign
     */
    public java.lang.String getValign() {
        return valign;
    }


    /**
     * Sets the valign value for this Entry.
     * 
     * @param valign
     */
    public void setValign(java.lang.String valign) {
        this.valign = valign;
    }


    /**
     * Gets the value value for this Entry.
     * 
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }


    /**
     * Sets the value value for this Entry.
     * 
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Entry)) return false;
        Entry other = (Entry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.alignment==null && other.getAlignment()==null) || 
             (this.alignment!=null &&
              this.alignment.equals(other.getAlignment()))) &&
            ((this.angle==null && other.getAngle()==null) || 
             (this.angle!=null &&
              this.angle.equals(other.getAngle()))) &&
            ((this.blendMode==null && other.getBlendMode()==null) || 
             (this.blendMode!=null &&
              this.blendMode.equals(other.getBlendMode()))) &&
            ((this.border==null && other.getBorder()==null) || 
             (this.border!=null &&
              this.border.equals(other.getBorder()))) &&
            ((this.colSpan==null && other.getColSpan()==null) || 
             (this.colSpan!=null &&
              this.colSpan.equals(other.getColSpan()))) &&
            ((this.color==null && other.getColor()==null) || 
             (this.color!=null &&
              this.color.equals(other.getColor()))) &&
            ((this.content==null && other.getContent()==null) || 
             (this.content!=null &&
              this.content.equals(other.getContent()))) &&
            ((this.gradient==null && other.getGradient()==null) || 
             (this.gradient!=null &&
              this.gradient.equals(other.getGradient()))) &&
            ((this.indexTerms==null && other.getIndexTerms()==null) || 
             (this.indexTerms!=null &&
              java.util.Arrays.equals(this.indexTerms, other.getIndexTerms()))) &&
            ((this.inset==null && other.getInset()==null) || 
             (this.inset!=null &&
              this.inset.equals(other.getInset()))) &&
            ((this.opacity==null && other.getOpacity()==null) || 
             (this.opacity!=null &&
              this.opacity.equals(other.getOpacity()))) &&
            ((this.paragraphs==null && other.getParagraphs()==null) || 
             (this.paragraphs!=null &&
              java.util.Arrays.equals(this.paragraphs, other.getParagraphs()))) &&
            ((this.picture==null && other.getPicture()==null) || 
             (this.picture!=null &&
              this.picture.equals(other.getPicture()))) &&
            ((this.richText==null && other.getRichText()==null) || 
             (this.richText!=null &&
              java.util.Arrays.equals(this.richText, other.getRichText()))) &&
            ((this.rowSpan==null && other.getRowSpan()==null) || 
             (this.rowSpan!=null &&
              this.rowSpan.equals(other.getRowSpan()))) &&
            ((this.shade==null && other.getShade()==null) || 
             (this.shade!=null &&
              this.shade.equals(other.getShade()))) &&
            ((this.valign==null && other.getValign()==null) || 
             (this.valign!=null &&
              this.valign.equals(other.getValign()))) &&
            ((this.value==null && other.getValue()==null) || 
             (this.value!=null &&
              this.value.equals(other.getValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAlignment() != null) {
            _hashCode += getAlignment().hashCode();
        }
        if (getAngle() != null) {
            _hashCode += getAngle().hashCode();
        }
        if (getBlendMode() != null) {
            _hashCode += getBlendMode().hashCode();
        }
        if (getBorder() != null) {
            _hashCode += getBorder().hashCode();
        }
        if (getColSpan() != null) {
            _hashCode += getColSpan().hashCode();
        }
        if (getColor() != null) {
            _hashCode += getColor().hashCode();
        }
        if (getContent() != null) {
            _hashCode += getContent().hashCode();
        }
        if (getGradient() != null) {
            _hashCode += getGradient().hashCode();
        }
        if (getIndexTerms() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIndexTerms());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIndexTerms(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInset() != null) {
            _hashCode += getInset().hashCode();
        }
        if (getOpacity() != null) {
            _hashCode += getOpacity().hashCode();
        }
        if (getParagraphs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParagraphs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParagraphs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getPicture() != null) {
            _hashCode += getPicture().hashCode();
        }
        if (getRichText() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRichText());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRichText(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRowSpan() != null) {
            _hashCode += getRowSpan().hashCode();
        }
        if (getShade() != null) {
            _hashCode += getShade().hashCode();
        }
        if (getValign() != null) {
            _hashCode += getValign().hashCode();
        }
        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Entry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Entry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alignment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "alignment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("angle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "angle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blendMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "blendMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("border");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "border"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Border"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("colSpan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "colSpan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("color");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "color"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("content");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "content"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Content"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gradient");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "gradient"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Gradient"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indexTerms");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "indexTerms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexTerm"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "inset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Inset"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opacity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "opacity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paragraphs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "paragraphs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Paragraph"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picture");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "picture"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Picture"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("richText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "richText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "RichText"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rowSpan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "rowSpan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "shade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valign");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "valign"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
