package com.socgen.sgs.api.quark.engine.domain.modifier;

import com.socgen.sgs.api.quark.engine.integration.soap.generated.Layout;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.Project;
import lombok.Getter;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Root of the modifier project hierarchy.
 *
 * Cross-reference: QXP.Engine.Core.Projet (Modifier namespace)
 */
@Getter
public class ModifierProjet {

    private final Map<String, ModifierLayout> layouts = new LinkedHashMap<>();

    public ModifierProjet() {
    }

    /**
     * Convert to SDK Project.
     * Cross-reference: .NET Projet.GetSDKProject()
     */
    public Project getSdkProject() {
        Project project = new Project();
        List<Layout> sdkLayouts = new ArrayList<>();

        for (ModifierLayout la : layouts.values()) {
            Layout layout = new Layout();
            layout.setName(la.getName());
            layout.setSpreads(la.getSdkSpreads());
            sdkLayouts.add(layout);
        }

        project.setLayouts(sdkLayouts.toArray(new Layout[0]));
        return project;
    }
}