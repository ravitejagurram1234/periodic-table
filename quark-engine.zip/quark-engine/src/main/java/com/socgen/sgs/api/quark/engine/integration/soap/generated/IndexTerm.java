/**
 * IndexTerm.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class IndexTerm  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String addAll;

    private java.lang.String id;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.MainTerm mainTerm;

    private java.lang.String range;

    private java.lang.String referenceStyle;

    private java.lang.String sortAs;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm1 subTerm1;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm2 subTerm2;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm3 subTerm3;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm4 subTerm4;

    private java.lang.String suppressPage;

    private java.lang.String value;

    public IndexTerm() {
    }

    public IndexTerm(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String addAll,
           java.lang.String id,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.MainTerm mainTerm,
           java.lang.String range,
           java.lang.String referenceStyle,
           java.lang.String sortAs,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm1 subTerm1,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm2 subTerm2,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm3 subTerm3,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm4 subTerm4,
           java.lang.String suppressPage,
           java.lang.String value) {
        super(
            request);
        this.addAll = addAll;
        this.id = id;
        this.mainTerm = mainTerm;
        this.range = range;
        this.referenceStyle = referenceStyle;
        this.sortAs = sortAs;
        this.subTerm1 = subTerm1;
        this.subTerm2 = subTerm2;
        this.subTerm3 = subTerm3;
        this.subTerm4 = subTerm4;
        this.suppressPage = suppressPage;
        this.value = value;
    }


    /**
     * Gets the addAll value for this IndexTerm.
     * 
     * @return addAll
     */
    public java.lang.String getAddAll() {
        return addAll;
    }


    /**
     * Sets the addAll value for this IndexTerm.
     * 
     * @param addAll
     */
    public void setAddAll(java.lang.String addAll) {
        this.addAll = addAll;
    }


    /**
     * Gets the id value for this IndexTerm.
     * 
     * @return id
     */
    public java.lang.String getId() {
        return id;
    }


    /**
     * Sets the id value for this IndexTerm.
     * 
     * @param id
     */
    public void setId(java.lang.String id) {
        this.id = id;
    }


    /**
     * Gets the mainTerm value for this IndexTerm.
     * 
     * @return mainTerm
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.MainTerm getMainTerm() {
        return mainTerm;
    }


    /**
     * Sets the mainTerm value for this IndexTerm.
     * 
     * @param mainTerm
     */
    public void setMainTerm(com.socgen.sgs.api.quark.engine.integration.soap.generated.MainTerm mainTerm) {
        this.mainTerm = mainTerm;
    }


    /**
     * Gets the range value for this IndexTerm.
     * 
     * @return range
     */
    public java.lang.String getRange() {
        return range;
    }


    /**
     * Sets the range value for this IndexTerm.
     * 
     * @param range
     */
    public void setRange(java.lang.String range) {
        this.range = range;
    }


    /**
     * Gets the referenceStyle value for this IndexTerm.
     * 
     * @return referenceStyle
     */
    public java.lang.String getReferenceStyle() {
        return referenceStyle;
    }


    /**
     * Sets the referenceStyle value for this IndexTerm.
     * 
     * @param referenceStyle
     */
    public void setReferenceStyle(java.lang.String referenceStyle) {
        this.referenceStyle = referenceStyle;
    }


    /**
     * Gets the sortAs value for this IndexTerm.
     * 
     * @return sortAs
     */
    public java.lang.String getSortAs() {
        return sortAs;
    }


    /**
     * Sets the sortAs value for this IndexTerm.
     * 
     * @param sortAs
     */
    public void setSortAs(java.lang.String sortAs) {
        this.sortAs = sortAs;
    }


    /**
     * Gets the subTerm1 value for this IndexTerm.
     * 
     * @return subTerm1
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm1 getSubTerm1() {
        return subTerm1;
    }


    /**
     * Sets the subTerm1 value for this IndexTerm.
     * 
     * @param subTerm1
     */
    public void setSubTerm1(com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm1 subTerm1) {
        this.subTerm1 = subTerm1;
    }


    /**
     * Gets the subTerm2 value for this IndexTerm.
     * 
     * @return subTerm2
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm2 getSubTerm2() {
        return subTerm2;
    }


    /**
     * Sets the subTerm2 value for this IndexTerm.
     * 
     * @param subTerm2
     */
    public void setSubTerm2(com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm2 subTerm2) {
        this.subTerm2 = subTerm2;
    }


    /**
     * Gets the subTerm3 value for this IndexTerm.
     * 
     * @return subTerm3
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm3 getSubTerm3() {
        return subTerm3;
    }


    /**
     * Sets the subTerm3 value for this IndexTerm.
     * 
     * @param subTerm3
     */
    public void setSubTerm3(com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm3 subTerm3) {
        this.subTerm3 = subTerm3;
    }


    /**
     * Gets the subTerm4 value for this IndexTerm.
     * 
     * @return subTerm4
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm4 getSubTerm4() {
        return subTerm4;
    }


    /**
     * Sets the subTerm4 value for this IndexTerm.
     * 
     * @param subTerm4
     */
    public void setSubTerm4(com.socgen.sgs.api.quark.engine.integration.soap.generated.SubTerm4 subTerm4) {
        this.subTerm4 = subTerm4;
    }


    /**
     * Gets the suppressPage value for this IndexTerm.
     * 
     * @return suppressPage
     */
    public java.lang.String getSuppressPage() {
        return suppressPage;
    }


    /**
     * Sets the suppressPage value for this IndexTerm.
     * 
     * @param suppressPage
     */
    public void setSuppressPage(java.lang.String suppressPage) {
        this.suppressPage = suppressPage;
    }


    /**
     * Gets the value value for this IndexTerm.
     * 
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }


    /**
     * Sets the value value for this IndexTerm.
     * 
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IndexTerm)) return false;
        IndexTerm other = (IndexTerm) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.addAll==null && other.getAddAll()==null) || 
             (this.addAll!=null &&
              this.addAll.equals(other.getAddAll()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.mainTerm==null && other.getMainTerm()==null) || 
             (this.mainTerm!=null &&
              this.mainTerm.equals(other.getMainTerm()))) &&
            ((this.range==null && other.getRange()==null) || 
             (this.range!=null &&
              this.range.equals(other.getRange()))) &&
            ((this.referenceStyle==null && other.getReferenceStyle()==null) || 
             (this.referenceStyle!=null &&
              this.referenceStyle.equals(other.getReferenceStyle()))) &&
            ((this.sortAs==null && other.getSortAs()==null) || 
             (this.sortAs!=null &&
              this.sortAs.equals(other.getSortAs()))) &&
            ((this.subTerm1==null && other.getSubTerm1()==null) || 
             (this.subTerm1!=null &&
              this.subTerm1.equals(other.getSubTerm1()))) &&
            ((this.subTerm2==null && other.getSubTerm2()==null) || 
             (this.subTerm2!=null &&
              this.subTerm2.equals(other.getSubTerm2()))) &&
            ((this.subTerm3==null && other.getSubTerm3()==null) || 
             (this.subTerm3!=null &&
              this.subTerm3.equals(other.getSubTerm3()))) &&
            ((this.subTerm4==null && other.getSubTerm4()==null) || 
             (this.subTerm4!=null &&
              this.subTerm4.equals(other.getSubTerm4()))) &&
            ((this.suppressPage==null && other.getSuppressPage()==null) || 
             (this.suppressPage!=null &&
              this.suppressPage.equals(other.getSuppressPage()))) &&
            ((this.value==null && other.getValue()==null) || 
             (this.value!=null &&
              this.value.equals(other.getValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAddAll() != null) {
            _hashCode += getAddAll().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getMainTerm() != null) {
            _hashCode += getMainTerm().hashCode();
        }
        if (getRange() != null) {
            _hashCode += getRange().hashCode();
        }
        if (getReferenceStyle() != null) {
            _hashCode += getReferenceStyle().hashCode();
        }
        if (getSortAs() != null) {
            _hashCode += getSortAs().hashCode();
        }
        if (getSubTerm1() != null) {
            _hashCode += getSubTerm1().hashCode();
        }
        if (getSubTerm2() != null) {
            _hashCode += getSubTerm2().hashCode();
        }
        if (getSubTerm3() != null) {
            _hashCode += getSubTerm3().hashCode();
        }
        if (getSubTerm4() != null) {
            _hashCode += getSubTerm4().hashCode();
        }
        if (getSuppressPage() != null) {
            _hashCode += getSuppressPage().hashCode();
        }
        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IndexTerm.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "IndexTerm"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addAll");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "addAll"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mainTerm");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "mainTerm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "MainTerm"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("range");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "range"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referenceStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "referenceStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sortAs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "sortAs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subTerm1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "subTerm1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "SubTerm1"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subTerm2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "subTerm2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "SubTerm2"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subTerm3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "subTerm3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "SubTerm3"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subTerm4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "subTerm4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "SubTerm4"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppressPage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "suppressPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
