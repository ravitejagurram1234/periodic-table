/**
 * QManagerSDKSvc.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public interface QManagerSDKSvc extends java.rmi.Remote {
    public java.lang.String createSession(long timeout) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QException getErrorObject(java.lang.String errorString) throws java.rmi.RemoteException;
    public void closeAllDocs(java.lang.String sessionId) throws java.rmi.RemoteException;
    public void closeDoc(java.lang.String docName, java.lang.String sessionId) throws java.rmi.RemoteException;
    public void closeSession(java.lang.String sessionId) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QOpenDocData[] getOpenDocs(java.lang.String sessionId) throws java.rmi.RemoteException;
    public java.lang.String[] getOpenSessions() throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences getPreferences(java.lang.String server, int port, java.lang.String user, java.lang.String password) throws java.rmi.RemoteException;
    public java.lang.String getXMLFromXPressDOM(com.socgen.sgs.api.quark.engine.integration.soap.generated.Project dom) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOM(java.lang.String documentName) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOMEx(java.lang.String documentName, com.socgen.sgs.api.quark.engine.integration.soap.generated.QXPressDOMOptions options) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Project getXPressDOMFromXML(java.lang.String documentXML) throws java.rmi.RemoteException;
    public void newDoc(java.lang.String docName, java.lang.String jobJacketName, java.lang.String jobTicketName, java.lang.String host, int port, java.lang.String sessionId) throws java.rmi.RemoteException;
    public void openDoc(java.lang.String docName, java.lang.String host, int port, java.lang.String sessionId) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData processRequest(com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext requestCmd) throws java.rmi.RemoteException;
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QContentData processRequestEx(com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequestContext reqContextObj, java.lang.String sessionId) throws java.rmi.RemoteException;
    public void saveAllDocs(java.lang.String relativePath, java.lang.String sessionId) throws java.rmi.RemoteException;
    public void saveDoc(java.lang.String docName, java.lang.String newName, java.lang.String relativePath, java.lang.String sessionId) throws java.rmi.RemoteException;
    public void setPreferences(java.lang.String server, int port, java.lang.String user, java.lang.String password, com.socgen.sgs.api.quark.engine.integration.soap.generated.Preferences prefs) throws java.rmi.RemoteException;
}
