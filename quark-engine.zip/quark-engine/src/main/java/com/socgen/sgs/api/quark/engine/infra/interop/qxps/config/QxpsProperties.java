package com.socgen.sgs.api.quark.engine.infra.interop.qxps.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "qxps")
public class QxpsProperties {

    private Server server = new Server();
    private Pool pool = new Pool();

    @Getter
    @Setter
    public static class Server {
        private String url;
        private int timeout = 3600000;
        // Max bytes buffered for a single QXPS response (full document XML / rendered PDF / literal QXP binary).
        // The operative value is set in application.yaml (qxps.server.max-in-memory-size-bytes); this initializer
        // is only a safety fallback. QXPS /xml responses can be several times the QXP binary size, so size it large.
        private int maxInMemorySizeBytes = 524288000;
    }

    @Getter
    @Setter
    public static class Pool {
        private String defaultPath = "D:\\Documents\\";
        private String currentPath = "";
    }
}
