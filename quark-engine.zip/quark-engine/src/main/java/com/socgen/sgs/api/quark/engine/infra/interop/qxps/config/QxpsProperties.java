package com.socgen.sgs.api.quark.engine.infra.interop.qxps.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "qxps")
public class QxpsProperties {

    private Server server = new Server();
    private Pool pool = new Pool();

    @Getter
    @Setter
    public static class Server {
        private String url;
        private int timeout = 3600000;
    }

    @Getter
    @Setter
    public static class Pool {
        private String defaultPath = "D:\\Documents\\";
        private String currentPath = "";
    }
}

