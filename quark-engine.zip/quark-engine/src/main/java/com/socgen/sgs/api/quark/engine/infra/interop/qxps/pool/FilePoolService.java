package com.socgen.sgs.api.quark.engine.infra.interop.qxps.pool;

import com.socgen.sgs.api.quark.engine.domain.port.FilePoolPort;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.helper.QxpsHelper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class FilePoolService implements FilePoolPort {

    private final QxpsHelper qxpsHelper;
    private final Set<String> addedFiles = ConcurrentHashMap.newKeySet();

    public void addFile(String documentName, byte[] data) {
        if (addedFiles.contains(documentName)) {
            log.debug("File already added to pool, skipping: {}", documentName);
            return;
        }

        qxpsHelper.addFile(documentName, data);
        addedFiles.add(documentName);
        log.info("File added to pool: {}", documentName);
    }

    /**
     * Registers a pool file as already known WITHOUT uploading it.
     * Used after a SaveAs/Change_Document so a later addFile() for the same name is skipped.
     *
     * Cross-reference: .NET QXPS_File_Manager.Addfile_Inform(poolName).
     */
    @Override
    public void inform(String documentName) {
        addedFiles.add(documentName);
    }

    public void clear() {
        addedFiles.clear();
    }
}

