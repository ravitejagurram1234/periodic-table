package com.socgen.sgs.api.quark.engine.infra.interop.qxps.pool;

import com.socgen.sgs.api.quark.engine.domain.port.FilePoolPort;
import com.socgen.sgs.api.quark.engine.infra.interop.qxps.helper.QxpsHelper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class FilePoolService implements FilePoolPort {

    private final QxpsHelper qxpsHelper;
    private final Set<String> addedFiles = ConcurrentHashMap.newKeySet();

    public void addFile(String documentName, byte[] data) {
        if (addedFiles.contains(documentName)) {
            log.debug("File already added to pool, skipping: {}", documentName);
            return;
        }

        qxpsHelper.addFile(documentName, data);
        addedFiles.add(documentName);
        log.info("File added to pool: {}", documentName);
    }

    public void clear() {
        addedFiles.clear();
    }
}


