package com.socgen.sgs.api.quark.engine.enums;

public enum BlocActionEnum {
    NONE,
    UPDATE,
    CREATE,
    REMOVE,
    MOVE;

    public static BlocActionEnum fromName(String name) {
        if (name == null) {
            return NONE;
        }
        try {
            return valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return NONE;
        }
    }
}

