package com.socgen.sgs.api.quark.engine.infra.dao;

import com.socgen.sgs.api.quark.engine.domain.RunProperties;
import com.socgen.sgs.api.quark.engine.dto.RunIdDto;

public interface GetRunPropertiesDao {
    RunProperties getRunProperties(RunIdDto runIdDto);
}
