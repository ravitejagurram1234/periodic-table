package com.socgen.sgs.api.quark.engine.service;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.dto.QxpsCallerResult;

/**
 * Service for executing modification steps and rendering final outputs
 * against QuarkXPress Server (QXPS) and QuarkXPress Server Manager (QXPSM).
 */
public interface QxpsCallerService {

    /**
     * Execute all modification steps on the document.
     *
     * @param run the run containing the RunTask with steps
     */
    void process(Run run);

    /**
     * Execute final renders (PDF, JPEG, QXP) on the completed document.
     *
     * @param run          the run
     * @param renderPdf    whether to render PDF
     * @param renderJpg    whether to render JPEG
     * @param renderQxp    whether to render QXP
     * @param compression  PDF compression mode
     * @param downsample   PDF downsample value (DPI)
     * @return render result containing byte arrays for each format
     */
    QxpsCallerResult render(Run run, boolean renderPdf, boolean renderJpg, boolean renderQxp,
                            String compression, String downsample);
}