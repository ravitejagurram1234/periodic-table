/**
 * TableBreak.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class TableBreak  extends com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest  implements java.io.Serializable {
    private java.lang.String breakHeight;

    private java.lang.String breakWhenAnchored;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.ChildID[] childIds;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Footer footer;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.Header header;

    private java.lang.String maintainLink;

    public TableBreak() {
    }

    public TableBreak(
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           java.lang.String breakHeight,
           java.lang.String breakWhenAnchored,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.ChildID[] childIds,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Footer footer,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.Header header,
           java.lang.String maintainLink) {
        super(
            request);
        this.breakHeight = breakHeight;
        this.breakWhenAnchored = breakWhenAnchored;
        this.childIds = childIds;
        this.footer = footer;
        this.header = header;
        this.maintainLink = maintainLink;
    }


    /**
     * Gets the breakHeight value for this TableBreak.
     * 
     * @return breakHeight
     */
    public java.lang.String getBreakHeight() {
        return breakHeight;
    }


    /**
     * Sets the breakHeight value for this TableBreak.
     * 
     * @param breakHeight
     */
    public void setBreakHeight(java.lang.String breakHeight) {
        this.breakHeight = breakHeight;
    }


    /**
     * Gets the breakWhenAnchored value for this TableBreak.
     * 
     * @return breakWhenAnchored
     */
    public java.lang.String getBreakWhenAnchored() {
        return breakWhenAnchored;
    }


    /**
     * Sets the breakWhenAnchored value for this TableBreak.
     * 
     * @param breakWhenAnchored
     */
    public void setBreakWhenAnchored(java.lang.String breakWhenAnchored) {
        this.breakWhenAnchored = breakWhenAnchored;
    }


    /**
     * Gets the childIds value for this TableBreak.
     * 
     * @return childIds
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ChildID[] getChildIds() {
        return childIds;
    }


    /**
     * Sets the childIds value for this TableBreak.
     * 
     * @param childIds
     */
    public void setChildIds(com.socgen.sgs.api.quark.engine.integration.soap.generated.ChildID[] childIds) {
        this.childIds = childIds;
    }

    public com.socgen.sgs.api.quark.engine.integration.soap.generated.ChildID getChildIds(int i) {
        return this.childIds[i];
    }

    public void setChildIds(int i, com.socgen.sgs.api.quark.engine.integration.soap.generated.ChildID _value) {
        this.childIds[i] = _value;
    }


    /**
     * Gets the footer value for this TableBreak.
     * 
     * @return footer
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Footer getFooter() {
        return footer;
    }


    /**
     * Sets the footer value for this TableBreak.
     * 
     * @param footer
     */
    public void setFooter(com.socgen.sgs.api.quark.engine.integration.soap.generated.Footer footer) {
        this.footer = footer;
    }


    /**
     * Gets the header value for this TableBreak.
     * 
     * @return header
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.Header getHeader() {
        return header;
    }


    /**
     * Sets the header value for this TableBreak.
     * 
     * @param header
     */
    public void setHeader(com.socgen.sgs.api.quark.engine.integration.soap.generated.Header header) {
        this.header = header;
    }


    /**
     * Gets the maintainLink value for this TableBreak.
     * 
     * @return maintainLink
     */
    public java.lang.String getMaintainLink() {
        return maintainLink;
    }


    /**
     * Sets the maintainLink value for this TableBreak.
     * 
     * @param maintainLink
     */
    public void setMaintainLink(java.lang.String maintainLink) {
        this.maintainLink = maintainLink;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TableBreak)) return false;
        TableBreak other = (TableBreak) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.breakHeight==null && other.getBreakHeight()==null) || 
             (this.breakHeight!=null &&
              this.breakHeight.equals(other.getBreakHeight()))) &&
            ((this.breakWhenAnchored==null && other.getBreakWhenAnchored()==null) || 
             (this.breakWhenAnchored!=null &&
              this.breakWhenAnchored.equals(other.getBreakWhenAnchored()))) &&
            ((this.childIds==null && other.getChildIds()==null) || 
             (this.childIds!=null &&
              java.util.Arrays.equals(this.childIds, other.getChildIds()))) &&
            ((this.footer==null && other.getFooter()==null) || 
             (this.footer!=null &&
              this.footer.equals(other.getFooter()))) &&
            ((this.header==null && other.getHeader()==null) || 
             (this.header!=null &&
              this.header.equals(other.getHeader()))) &&
            ((this.maintainLink==null && other.getMaintainLink()==null) || 
             (this.maintainLink!=null &&
              this.maintainLink.equals(other.getMaintainLink())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBreakHeight() != null) {
            _hashCode += getBreakHeight().hashCode();
        }
        if (getBreakWhenAnchored() != null) {
            _hashCode += getBreakWhenAnchored().hashCode();
        }
        if (getChildIds() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getChildIds());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getChildIds(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFooter() != null) {
            _hashCode += getFooter().hashCode();
        }
        if (getHeader() != null) {
            _hashCode += getHeader().hashCode();
        }
        if (getMaintainLink() != null) {
            _hashCode += getMaintainLink().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TableBreak.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "TableBreak"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("breakHeight");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "breakHeight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("breakWhenAnchored");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "breakWhenAnchored"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("childIds");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "childIds"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "ChildID"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("footer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "footer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Footer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("header");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "header"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "Header"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maintainLink");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "maintainLink"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
