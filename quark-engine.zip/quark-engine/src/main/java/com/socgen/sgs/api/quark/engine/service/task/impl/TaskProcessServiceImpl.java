package com.socgen.sgs.api.quark.engine.service.task.impl;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.service.task.TaskProcessService;
import com.socgen.sgs.api.quark.engine.service.task.TaskProcessStrategy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/** Dispatches task processing to the matching strategy bean. */
@Service
@Slf4j
public class TaskProcessServiceImpl implements TaskProcessService {

    @SuppressWarnings("rawtypes")
    private final Map<Class, TaskProcessStrategy> strategyMap;

    @SuppressWarnings("rawtypes")
    public TaskProcessServiceImpl(List<TaskProcessStrategy> strategies) {
        this.strategyMap = strategies.stream()
                .collect(Collectors.toMap(TaskProcessStrategy::getTaskType, Function.identity()));
        log.info("Registered {} task process strategies: {}", strategyMap.size(), strategyMap.keySet());
    }

    @Override
    @SuppressWarnings("unchecked")
    public void process(TaskBase task) {
        TaskProcessStrategy strategy = strategyMap.get(task.getClass());
        if (strategy != null) {
            strategy.process(task);
        } else {
            log.warn("No process strategy registered for task type: {}", task.getClass().getSimpleName());
        }
    }
}

