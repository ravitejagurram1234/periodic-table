package com.socgen.sgs.api.quark.engine.domain.modifier;

import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import lombok.Getter;
import lombok.Setter;

/**
 * Represents a page in a modifier project hierarchy.
 *
 * Cross-reference: QXP.Engine.Core.Page (Modifier namespace)
 */
@Getter
@Setter
public class ModifierPage {

    private String uid;
    private String name;
    private String position;
    private int indexPosition;
    private TaskBase task;
    private boolean createDummyNextPage = false;
    private BlocActionEnum action = BlocActionEnum.NONE;

    public ModifierPage() {
    }
}