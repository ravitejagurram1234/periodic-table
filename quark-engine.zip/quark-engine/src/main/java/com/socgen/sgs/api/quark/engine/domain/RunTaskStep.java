package com.socgen.sgs.api.quark.engine.domain;

import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBase;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocBox;
import com.socgen.sgs.api.quark.engine.domain.bloc.BlocPage;
import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.enums.BlocActionEnum;
import com.socgen.sgs.api.quark.engine.integration.soap.generated.NameValueParam;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Defines one execution step for modifying a QuarkXPress document.
 * Tasks are grouped into steps based on type:
 * - UPDATE step: text value changes (via SOAP/ParamsValue)
 * - PAGINATION step: page create/remove operations (via HTTP/Modify)
 * - MODIFY steps: structural changes split at N blocs per step (via HTTP/Modify)
 *
 * Cross-reference: QXP.Engine.Core.Run_Task_Step
 */
@Getter
@Setter
@Slf4j
public class RunTaskStep {

    private static final int PAGE_PAIRE = 0;
    private static final int PAGE_IMPAIRE = 1;
    private static final int OFFSET_PAGE = 1;

    private int index = 0;
    private boolean directCall = true;
    private boolean pagination = false;

    private final List<BlocBase> blocsUpdate = new ArrayList<>();
    private final List<BlocBase> blocsModify = new ArrayList<>();
    private final List<NameValueParam> nameValues = new ArrayList<>();

    /** Tasks whose evaluateInfo() should be called before this step executes. */
    private final List<TaskBase> evaluateInfoTasks = new ArrayList<>();

    /** Optional preparation step (for double-page pagination edge cases). */
    private RunTaskStep prepareStep = null;

    private int nbBoxAdded = 0;
    private int nbBoxUpdate = 0;
    private int nbBoxExcluded = 0;
    private int nbBoxDoc = 0;

    private final Run run;

    public RunTaskStep(Run run) {
        this.run = run;
    }

    // ========================================================================
    // Prepare — called by Step 5 before execution
    // Cross-reference: Run_Task_Step.Prepare()
    // ========================================================================

    /**
     * Prepare this step for execution:
     * 1. Call evaluateInfo() on all associated tasks (re-evaluates page/layout from latest gabarit)
     * 2. Evaluate modifier and name-values
     * 3. Evaluate box count limitations
     *
     * @param ignoreStep if true, force-exclude all blocs in this step
     */
    public void prepare(boolean ignoreStep) {
        // Re-evaluate task info (page numbers, layout names) from latest gabarit version
        for (TaskBase task : evaluateInfoTasks) {
            task.evaluateInfo();
        }

        evaluateModifierAndValues();
        evaluateLimitation(ignoreStep);
    }

    /**
     * Evaluate pages for modify blocs and build name-value pairs for update blocs.
     *
     * Cross-reference: Run_Task_Step.Evaluate_Modifier_And_Values()
     */
    private void evaluateModifierAndValues() {
        // Evaluate pages for modify blocs
        for (BlocBase bloc : blocsModify) {
            bloc.evaluatePage();
        }

        // Handle pagination step page renumbering
        if (!blocsModify.isEmpty() && this.pagination) {
            updateBlocPagination(blocsModify);
        }

        // Build name-value pairs from update blocs
        for (BlocBase bloc : blocsUpdate) {
            if (bloc instanceof BlocBox) {
                BlocBox blocBox = (BlocBox) bloc;
                NameValueParam nv = new NameValueParam();
                nv.setParamName(bloc.getName());
                nv.setTextValue(blocBox.getValue());
                nameValues.add(nv);
            }
        }
        nbBoxUpdate += nameValues.size();
    }

    /**
     * Evaluate box count limitations to prevent exceeding QuarkXPress capacity.
     *
     * Cross-reference: Run_Task_Step.Evaluate_Limitation()
     */
    private void evaluateLimitation(boolean ignoreStep) {
        if (run.getGabarit() != null && run.getGabarit().getQxpXml() != null) {
            nbBoxDoc = run.getGabarit().getQxpXml().getProjectInfo().getNbBox();
        }

        // Evaluate modify blocs
        for (BlocBase bloc : blocsModify) {
            int nbBoxBloc = bloc.getNbBox();

            // Pagination steps don't check limitations (they may remove pages)
            if (!this.pagination && (nbBoxDoc > getNbMaxBoxes() || ignoreStep)) {
                bloc.setExclude(true);
                nbBoxExcluded += nbBoxBloc;
            } else {
                if (bloc.getAction() == BlocActionEnum.CREATE) {
                    nbBoxAdded += nbBoxBloc;
                    nbBoxDoc += nbBoxBloc;
                } else {
                    nbBoxUpdate += nbBoxBloc;
                }
            }
        }

        // If too many boxes, clear update blocs
        if (nbBoxDoc > getNbMaxBoxes()) {
            blocsUpdate.clear();
        }
    }

    /**
     * Get the maximum number of boxes this document can contain.
     * Based on document complexity ratio.
     *
     * Cross-reference: Run_Task_Step.NbMaxBoxes property
     */
    public int getNbMaxBoxes() {
        // Default large value if not calculable
        return Integer.MAX_VALUE;
    }

    /** Whether this step is fully excluded (no boxes added or updated). */
    public boolean isFullExclude() {
        return nbBoxAdded == 0 && nbBoxUpdate == 0;
    }

    /** Whether at least one box was excluded due to limitations. */
    public boolean isPartialExclude() {
        return nbBoxExcluded > 0;
    }

    // ========================================================================
    // Pagination — page renumbering for multi-task page operations
    // Cross-reference: Run_Task_Step.Update_Bloc_Pagination()
    // ========================================================================

    /**
     * Update page numbers across tasks when multiple tasks create/remove pages.
     * Handles both single-page and double-page (vis-à-vis) layouts.
     *
     * Cross-reference: Run_Task_Step.Update_Bloc_Pagination() lines 185-460
     */
    private void updateBlocPagination(List<BlocBase> blocs) {
        // Step 1: Group blocs by task
        Map<TaskBase, List<BlocBase>> taskBlocs = new LinkedHashMap<>();
        List<TaskBase> tasks = new ArrayList<>();

        for (BlocBase bloc : blocs) {
            taskBlocs.computeIfAbsent(bloc.getTask(), k -> new ArrayList<>()).add(bloc);
        }
        tasks.addAll(taskBlocs.keySet());

        // Sort tasks by starting page number
        tasks.sort((t1, t2) -> Integer.compare(
                t1.getProperties().getPageNum(),
                t2.getProperties().getPageNum()));

        boolean lagSpread = false;
        RunTaskStep localPrepareStep = new RunTaskStep(run);

        // Step 2: Analyse each task's page operations and update other tasks
        for (TaskBase task : tasks) {
            int nbPageCreer = 0;
            int nbPageSupprimer = 0;
            int minPageId = Integer.MAX_VALUE;
            int minCreationPageId = Integer.MAX_VALUE;
            int minCreationPageIdOriginale = Integer.MAX_VALUE;
            int maxCreationPageId = Integer.MIN_VALUE;
            BlocPage maxCreationPage = null;

            // Count page creates and removes for this task
            for (BlocBase bloc : taskBlocs.get(task)) {
                if (bloc instanceof BlocPage) {
                    switch (bloc.getAction()) {
                        case CREATE:
                            nbPageCreer++;
                            if (bloc.getPageId() > maxCreationPageId) {
                                maxCreationPageId = bloc.getPageId();
                                maxCreationPage = (BlocPage) bloc;
                            }
                            minCreationPageId = Math.min(minCreationPageId, bloc.getPageId());
                            minCreationPageIdOriginale = Math.min(
                                    minCreationPageIdOriginale, bloc.getPageIdOriginale());
                            break;
                        case REMOVE:
                            nbPageSupprimer++;
                            break;
                        default:
                            break;
                    }
                    minPageId = Math.min(minPageId, bloc.getPageId());
                }
            }

            // If pages were created, update other tasks' page numbers
            if (nbPageCreer > 0) {

                // Handle double-page (vis-à-vis) layout
                if (run.getRunProperties().getNbPageBySpread() == RunProperties.PAGINATION_DOUBLE) {
                    int checkPremiereCreation = lagSpread ? PAGE_PAIRE : PAGE_IMPAIRE;

                    // First creation page is on wrong side — needs reordering
                    if ((minCreationPageId % 2) == checkPremiereCreation) {
                        if (minCreationPageId > 1 && nbPageSupprimer > 0) {
                            int posPremiereSupp = maxCreationPageId + 1;
                            for (BlocBase bloc : taskBlocs.get(task)) {
                                if (bloc.getPageId() == posPremiereSupp) {
                                    bloc.setPageId(minCreationPageId);
                                } else if (bloc.getPageId() < posPremiereSupp
                                        && bloc.getPageId() >= minCreationPageId) {
                                    bloc.setPageId(bloc.getPageId() + OFFSET_PAGE);
                                }
                            }
                            maxCreationPageId += OFFSET_PAGE;
                        } else if (minCreationPageId == 1 && maxCreationPageId == 1) {
                            lagSpread = true;
                            for (BlocBase bloc : taskBlocs.get(task)) {
                                if (bloc.getPageId() > 1) {
                                    bloc.setLagSpread(true);
                                }
                            }
                        }
                    }

                    // Last creation page is even — needs dummy page for spread alignment
                    if (maxCreationPage != null
                            && (maxCreationPageId % 2) != checkPremiereCreation) {
                        maxCreationPage.setCreateNextDummyPage(true);
                        for (BlocBase bloc : taskBlocs.get(task)) {
                            if (bloc.getPageId() > maxCreationPageId) {
                                bloc.setPageId(bloc.getPageId() + OFFSET_PAGE);
                            }
                        }
                        nbPageCreer++;
                    }
                }

                // Update all other tasks' page numbers
                for (TaskBase taskSub : taskBlocs.keySet()) {
                    if (taskSub != task) {
                        for (BlocBase bloc : taskBlocs.get(taskSub)) {
                            if (bloc.getPageId() >= minPageId && bloc.getPageId() > 1) {
                                bloc.setPageId(bloc.getPageId() + nbPageCreer);
                            }
                            if (bloc.getPageId() > 1) {
                                bloc.setLagSpread(lagSpread);
                            }
                        }
                    }
                }
            }
        }

        // Store prepare step if needed
        if (localPrepareStep != this.prepareStep) {
            // prepareStep is set during complex double-page handling (simplified here)
        }
    }

    /**
     * Register a task for evaluateInfo callback during prepare().
     */
    public void addEvaluateInfoTask(TaskBase task) {
        if (!evaluateInfoTasks.contains(task)) {
            evaluateInfoTasks.add(task);
        }
    }

    /**
     * Remove a task from the evaluateInfo list (used when rebuilding steps).
     */
    public void removeEvaluateInfoTask(TaskBase task) {
        evaluateInfoTasks.remove(task);
    }
}