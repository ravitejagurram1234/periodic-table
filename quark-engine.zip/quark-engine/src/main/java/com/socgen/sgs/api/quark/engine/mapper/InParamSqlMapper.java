package com.socgen.sgs.api.quark.engine.mapper;

import com.socgen.sgs.api.quark.engine.domain.InParam;
import com.socgen.sgs.api.quark.engine.enums.DataTypeEnum;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Maps run InParams to a flat parameter map suitable for JDBC named parameters.
 * For DATE/DATE_TIME params, converts the string to java.sql.Date so Oracle receives
 * a native DATE bind variable — matching the quark_dynamic_sql_executor approach.
 */
@Component
public class InParamSqlMapper {

    /** Format the date value arrives in from Oracle Get_In_Params (M/d/yyyy HH:mm:ss) */
    private static final DateTimeFormatter INPUT_FORMAT = DateTimeFormatter.ofPattern("M/d/yyyy HH:mm:ss");

    public Map<String, Object> toParameterMap(Map<String, InParam> inParams) {
        Map<String, Object> params = new LinkedHashMap<>();
        for (Map.Entry<String, InParam> entry : inParams.entrySet()) {
            InParam inParam = entry.getValue();
            if ((inParam.getType() == DataTypeEnum.DATE || inParam.getType() == DataTypeEnum.DATE_TIME)
                    && inParam.getStringValue() != null && !inParam.getStringValue().isEmpty()) {
                params.put(entry.getKey(), toSqlDate(inParam.getStringValue()));
            } else {
                params.put(entry.getKey(), inParam.getStringValue());
            }
        }
        return params;
    }

    /**
     * Converts the date string from Get_In_Params (e.g., "12/29/2023 00:00:00")
     * to java.sql.Date. Oracle JDBC driver will bind it as a native DATE type.
     * When SQL uses to_date(:param), Oracle's to_date on a DATE is a no-op.
     */
    private Date toSqlDate(String dateValue) {
        try {
            LocalDate date = LocalDate.parse(dateValue.trim(), INPUT_FORMAT);
            return Date.valueOf(date);
        } catch (Exception e) {
            // Fallback: try ISO format (yyyy-MM-dd) in case value is already formatted
            try {
                return Date.valueOf(LocalDate.parse(dateValue.trim()));
            } catch (Exception e2) {
                throw new IllegalArgumentException(
                        "Unable to parse date parameter value: '" + dateValue + "'. Expected format: M/d/yyyy HH:mm:ss or yyyy-MM-dd", e2);
            }
        }
    }
}

