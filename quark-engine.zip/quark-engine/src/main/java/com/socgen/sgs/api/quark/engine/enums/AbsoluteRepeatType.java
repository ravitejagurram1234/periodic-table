package com.socgen.sgs.api.quark.engine.enums;

/**
 * Defines how an absolute bloc is repeated across pages.
 * Uses bit flags for combinable values (matching .NET [Flags] Absolute_Repeat_Type).
 *
 * Cross-reference: QXP.Engine.Core.Absolute_Repeat_Type
 */
public enum AbsoluteRepeatType {

    /** By default, the absolute bloc appears only on the first page. */
    DEFAULT(0x00),

    /** The absolute bloc appears on the first page. */
    FIRST_PAGE(0x01),

    /** The absolute bloc appears on other pages (but not the first). */
    OTHER_PAGE(0x02),

    /** The absolute bloc appears on the last page. */
    LAST_PAGE(0x04),

    /** The absolute bloc appears on all pages. */
    ALL(0xFF);

    private final int value;

    AbsoluteRepeatType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    /**
     * Check if this repeat type includes FIRST_PAGE behavior.
     * Matches .NET: (type & Absolute_Repeat_Type.First_Page) == Absolute_Repeat_Type.First_Page
     */
    public boolean hasFirstPage() {
        return (this.value & FIRST_PAGE.value) == FIRST_PAGE.value;
    }

    /**
     * Check if this repeat type includes OTHER_PAGE behavior.
     * Matches .NET: (type & Absolute_Repeat_Type.Other_Page) == Absolute_Repeat_Type.Other_Page
     */
    public boolean hasOtherPage() {
        return (this.value & OTHER_PAGE.value) == OTHER_PAGE.value;
    }

    /**
     * Check if this repeat type includes LAST_PAGE behavior.
     * Matches .NET: (type & Absolute_Repeat_Type.Last_Page) == Absolute_Repeat_Type.Last_Page
     */
    public boolean hasLastPage() {
        return (this.value & LAST_PAGE.value) == LAST_PAGE.value;
    }

    /**
     * Bit test against a raw absolute-repeat code, the .NET-faithful check
     * ({@code (Absolute_Repeat & First_Page) == First_Page}). Unlike a single-value enum, this
     * correctly handles combined values (e.g. 0x03 = First_Page|Other_Page, 0x05, 0x06, 0xFF).
     * The raw int must be carried (Template.absoluteRepeat is an int) because a plain Java enum
     * cannot represent a combined flag value — that is why {@code fromValue} was removed.
     */
    public static boolean hasFirstPage(int code) {
        return (code & FIRST_PAGE.value) == FIRST_PAGE.value;
    }

    public static boolean hasOtherPage(int code) {
        return (code & OTHER_PAGE.value) == OTHER_PAGE.value;
    }

    public static boolean hasLastPage(int code) {
        return (code & LAST_PAGE.value) == LAST_PAGE.value;
    }
}