/**
 * QRequestContext.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.socgen.sgs.api.quark.engine.integration.soap.generated;

public class QRequestContext  implements java.io.Serializable {
    private boolean bypassFileInfo;

    private java.lang.String context;

    private java.lang.String documentName;

    private int maxRetries;

    private com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request;

    private int requestTimeout;

    private boolean responseAsURL;

    private java.lang.String serverName;

    private int serverPort;

    private boolean useCache;

    private java.lang.String userName;

    private java.lang.String userPassword;

    public QRequestContext() {
    }

    public QRequestContext(
           boolean bypassFileInfo,
           java.lang.String context,
           java.lang.String documentName,
           int maxRetries,
           com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request,
           int requestTimeout,
           boolean responseAsURL,
           java.lang.String serverName,
           int serverPort,
           boolean useCache,
           java.lang.String userName,
           java.lang.String userPassword) {
           this.bypassFileInfo = bypassFileInfo;
           this.context = context;
           this.documentName = documentName;
           this.maxRetries = maxRetries;
           this.request = request;
           this.requestTimeout = requestTimeout;
           this.responseAsURL = responseAsURL;
           this.serverName = serverName;
           this.serverPort = serverPort;
           this.useCache = useCache;
           this.userName = userName;
           this.userPassword = userPassword;
    }


    /**
     * Gets the bypassFileInfo value for this QRequestContext.
     * 
     * @return bypassFileInfo
     */
    public boolean isBypassFileInfo() {
        return bypassFileInfo;
    }


    /**
     * Sets the bypassFileInfo value for this QRequestContext.
     * 
     * @param bypassFileInfo
     */
    public void setBypassFileInfo(boolean bypassFileInfo) {
        this.bypassFileInfo = bypassFileInfo;
    }


    /**
     * Gets the context value for this QRequestContext.
     * 
     * @return context
     */
    public java.lang.String getContext() {
        return context;
    }


    /**
     * Sets the context value for this QRequestContext.
     * 
     * @param context
     */
    public void setContext(java.lang.String context) {
        this.context = context;
    }


    /**
     * Gets the documentName value for this QRequestContext.
     * 
     * @return documentName
     */
    public java.lang.String getDocumentName() {
        return documentName;
    }


    /**
     * Sets the documentName value for this QRequestContext.
     * 
     * @param documentName
     */
    public void setDocumentName(java.lang.String documentName) {
        this.documentName = documentName;
    }


    /**
     * Gets the maxRetries value for this QRequestContext.
     * 
     * @return maxRetries
     */
    public int getMaxRetries() {
        return maxRetries;
    }


    /**
     * Sets the maxRetries value for this QRequestContext.
     * 
     * @param maxRetries
     */
    public void setMaxRetries(int maxRetries) {
        this.maxRetries = maxRetries;
    }


    /**
     * Gets the request value for this QRequestContext.
     * 
     * @return request
     */
    public com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest getRequest() {
        return request;
    }


    /**
     * Sets the request value for this QRequestContext.
     * 
     * @param request
     */
    public void setRequest(com.socgen.sgs.api.quark.engine.integration.soap.generated.QRequest request) {
        this.request = request;
    }


    /**
     * Gets the requestTimeout value for this QRequestContext.
     * 
     * @return requestTimeout
     */
    public int getRequestTimeout() {
        return requestTimeout;
    }


    /**
     * Sets the requestTimeout value for this QRequestContext.
     * 
     * @param requestTimeout
     */
    public void setRequestTimeout(int requestTimeout) {
        this.requestTimeout = requestTimeout;
    }


    /**
     * Gets the responseAsURL value for this QRequestContext.
     * 
     * @return responseAsURL
     */
    public boolean isResponseAsURL() {
        return responseAsURL;
    }


    /**
     * Sets the responseAsURL value for this QRequestContext.
     * 
     * @param responseAsURL
     */
    public void setResponseAsURL(boolean responseAsURL) {
        this.responseAsURL = responseAsURL;
    }


    /**
     * Gets the serverName value for this QRequestContext.
     * 
     * @return serverName
     */
    public java.lang.String getServerName() {
        return serverName;
    }


    /**
     * Sets the serverName value for this QRequestContext.
     * 
     * @param serverName
     */
    public void setServerName(java.lang.String serverName) {
        this.serverName = serverName;
    }


    /**
     * Gets the serverPort value for this QRequestContext.
     * 
     * @return serverPort
     */
    public int getServerPort() {
        return serverPort;
    }


    /**
     * Sets the serverPort value for this QRequestContext.
     * 
     * @param serverPort
     */
    public void setServerPort(int serverPort) {
        this.serverPort = serverPort;
    }


    /**
     * Gets the useCache value for this QRequestContext.
     * 
     * @return useCache
     */
    public boolean isUseCache() {
        return useCache;
    }


    /**
     * Sets the useCache value for this QRequestContext.
     * 
     * @param useCache
     */
    public void setUseCache(boolean useCache) {
        this.useCache = useCache;
    }


    /**
     * Gets the userName value for this QRequestContext.
     * 
     * @return userName
     */
    public java.lang.String getUserName() {
        return userName;
    }


    /**
     * Sets the userName value for this QRequestContext.
     * 
     * @param userName
     */
    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }


    /**
     * Gets the userPassword value for this QRequestContext.
     * 
     * @return userPassword
     */
    public java.lang.String getUserPassword() {
        return userPassword;
    }


    /**
     * Sets the userPassword value for this QRequestContext.
     * 
     * @param userPassword
     */
    public void setUserPassword(java.lang.String userPassword) {
        this.userPassword = userPassword;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QRequestContext)) return false;
        QRequestContext other = (QRequestContext) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.bypassFileInfo == other.isBypassFileInfo() &&
            ((this.context==null && other.getContext()==null) || 
             (this.context!=null &&
              this.context.equals(other.getContext()))) &&
            ((this.documentName==null && other.getDocumentName()==null) || 
             (this.documentName!=null &&
              this.documentName.equals(other.getDocumentName()))) &&
            this.maxRetries == other.getMaxRetries() &&
            ((this.request==null && other.getRequest()==null) || 
             (this.request!=null &&
              this.request.equals(other.getRequest()))) &&
            this.requestTimeout == other.getRequestTimeout() &&
            this.responseAsURL == other.isResponseAsURL() &&
            ((this.serverName==null && other.getServerName()==null) || 
             (this.serverName!=null &&
              this.serverName.equals(other.getServerName()))) &&
            this.serverPort == other.getServerPort() &&
            this.useCache == other.isUseCache() &&
            ((this.userName==null && other.getUserName()==null) || 
             (this.userName!=null &&
              this.userName.equals(other.getUserName()))) &&
            ((this.userPassword==null && other.getUserPassword()==null) || 
             (this.userPassword!=null &&
              this.userPassword.equals(other.getUserPassword())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isBypassFileInfo() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getContext() != null) {
            _hashCode += getContext().hashCode();
        }
        if (getDocumentName() != null) {
            _hashCode += getDocumentName().hashCode();
        }
        _hashCode += getMaxRetries();
        if (getRequest() != null) {
            _hashCode += getRequest().hashCode();
        }
        _hashCode += getRequestTimeout();
        _hashCode += (isResponseAsURL() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getServerName() != null) {
            _hashCode += getServerName().hashCode();
        }
        _hashCode += getServerPort();
        _hashCode += (isUseCache() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getUserName() != null) {
            _hashCode += getUserName().hashCode();
        }
        if (getUserPassword() != null) {
            _hashCode += getUserPassword().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QRequestContext.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "QRequestContext"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bypassFileInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "bypassFileInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("context");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "context"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "documentName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxRetries");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "maxRetries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("request");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "request"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://com.quark.qxpsm", "QRequest"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestTimeout");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "requestTimeout"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseAsURL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "responseAsURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "serverName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverPort");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "serverPort"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("useCache");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "useCache"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "userName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userPassword");
        elemField.setXmlName(new javax.xml.namespace.QName("http://com.quark.qxpsm", "userPassword"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
