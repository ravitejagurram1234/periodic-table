package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.infra.dao.EndRunDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleTypes;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Oracle implementation for run finalization.
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class EndRunDaoImpl implements EndRunDao {

    private final DataSource dataSource;

    @Override
    public void endRun(int idRun, int runStatus, int idSuivi, int suiviStatus,
                       LocalDateTime dateFin, String logTrace,
                       int idDocPdf, int idDocQxp, int idDocDoc) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withProcedureName("End_Run")
                .withoutProcedureColumnMetaDataAccess() // deterministic binding from declareParameters. #91
                .declareParameters(
                        new SqlParameter("p_id_run", Types.NUMERIC),
                        new SqlParameter("p_run_status", Types.NUMERIC),
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_suivi_status", Types.NUMERIC),
                        new SqlParameter("p_date_fin", Types.TIMESTAMP),
                        new SqlParameter("p_log_trace", Types.CLOB),
                        new SqlParameter("p_id_doc_pdf", Types.NUMERIC),
                        new SqlParameter("p_id_doc_qxp", Types.NUMERIC),
                        new SqlParameter("p_id_doc_doc", Types.NUMERIC)
                );

        Map<String, Object> params = new HashMap<>();
        params.put("p_id_run", idRun);
        params.put("p_run_status", runStatus);
        params.put("p_id_suivi", idSuivi);
        params.put("p_suivi_status", suiviStatus);
        params.put("p_date_fin", dateFin != null ? Timestamp.valueOf(dateFin) : null);
        params.put("p_log_trace", logTrace);
        params.put("p_id_doc_pdf", idDocPdf);
        params.put("p_id_doc_qxp", idDocQxp);
        params.put("p_id_doc_doc", idDocDoc);

        jdbcCall.execute(params);
        log.info("End_Run executed for run [{}]", idRun);
    }

    @Override
    public void updateStatusRun(int idRun, int runStatus, int suiviStatus,
                                LocalDateTime dateFin, String logTrace) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_RUN")
                .withProcedureName("Update_Status_Run")
                .withoutProcedureColumnMetaDataAccess() // deterministic binding from declareParameters. #91
                .declareParameters(
                        new SqlParameter("p_id_run", Types.NUMERIC),
                        new SqlParameter("p_run_status", Types.NUMERIC),
                        new SqlParameter("p_suivi_status", Types.NUMERIC),
                        new SqlParameter("p_date_fin", Types.TIMESTAMP),
                        new SqlParameter("p_log_trace", Types.CLOB)
                );

        Map<String, Object> params = new HashMap<>();
        params.put("p_id_run", idRun);
        params.put("p_run_status", runStatus);
        params.put("p_suivi_status", suiviStatus);
        params.put("p_date_fin", dateFin != null ? Timestamp.valueOf(dateFin) : null);
        params.put("p_log_trace", logTrace);

        jdbcCall.execute(params);
        log.info("Update_Status_Run executed for run [{}] with status [{}]", idRun, runStatus);
    }

    @Override
    public void insertRunErrors(int idRun, String[] messages, int[] categories) {
        if (messages == null || messages.length == 0) return;

        // p_messages / p_categories are PL/SQL associative arrays (QXP_PK_COMMON.VarCharArray /
        // NumberArray = "TABLE OF ... INDEX BY BINARY_INTEGER"). These CANNOT be bound as a SQL
        // collection via SimpleJdbcCall + OracleTypes.ARRAY (the previous code raised ORA-00902 /
        // PLS-00306 at runtime, so EVERY error-persistence call threw, masking the original failure).
        // They must be bound with the Oracle index-table API setPlsqlIndexTable, mirroring how .NET
        // ODP.NET binds the same VarCharArray/NumberArray params (Proxy_Error.cs:127-129). Finding #4.
        new JdbcTemplate(dataSource).execute((ConnectionCallback<Void>) con -> {
            try (CallableStatement cs = con.prepareCall("{ call QXP_PK_RUN.Insert_Run_Errors(?, ?, ?) }")) {
                OraclePreparedStatement ops = cs.unwrap(OraclePreparedStatement.class);
                ops.setInt(1, idRun);
                // setPlsqlIndexTable(paramIndex, data, maxLen, curLen, elemSqlType, elemMaxLen)
                ops.setPlsqlIndexTable(2, messages, messages.length, messages.length,
                        OracleTypes.VARCHAR, 4000);
                ops.setPlsqlIndexTable(3, categories, categories.length, categories.length,
                        OracleTypes.NUMBER, 0);
                ops.execute();
            }
            return null;
        });
        log.info("Inserted {} errors for run [{}]", messages.length, idRun);
    }
}