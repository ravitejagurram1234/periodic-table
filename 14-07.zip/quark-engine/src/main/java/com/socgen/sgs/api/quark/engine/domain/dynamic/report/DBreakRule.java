package com.socgen.sgs.api.quark.engine.domain.dynamic.report;

import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/** A single break rule defining which row-levels trigger a page/column break and which levels to bring along. */
@Getter
public class DBreakRule {

    public static final DBreakRule DEFAULT = new DBreakRule(Integer.MIN_VALUE);

    private final List<Integer> levels = new ArrayList<>();
    private final List<Integer> bringLevels = new ArrayList<>();

    public DBreakRule(int... levels) {
        for (int level : levels) {
            this.levels.add(level);
        }
    }

    public DBreakRule(String rule) {
        analyseRule(rule);
    }

    public DBreakRule(int level, List<Integer> bringLevels) {
        this.levels.add(level);
        this.bringLevels.addAll(bringLevels);
    }

    /**
     * Parses a rule string in the format "X:Y" where X = levels triggering break, Y = levels to bring.
     * X and Y can be comma-separated values, ranges (e.g. 1-3), or LZ notation (bring Z lines).
     */
    private void analyseRule(String rule) {
        String[] ruleInfos = rule.split(":");
        if (ruleInfos.length == 2) {
            levels.addAll(parseRuleValues(ruleInfos[0]));
            bringLevels.addAll(parseRuleValues(ruleInfos[1]));
        }
    }

    private List<Integer> parseRuleValues(String input) {
        List<Integer> values = new ArrayList<>();
        String[] parts = input.split(",");

        for (String part : parts) {
            String[] rangeParts = part.split("-");

            if (rangeParts.length == 2 && !part.startsWith("L")) {
                int start = toInt(rangeParts[0].trim());
                int end = toInt(rangeParts[1].trim());
                for (int i = start; i <= end; i++) {
                    values.add(i);
                }
            } else {
                String level = rangeParts[0].trim();
                if (level.startsWith("L")) {
                    // LZ notation: negative value means "bring Z lines above regardless of row_level"
                    int nbLigne = toInt(level.substring(1));
                    values.add(-nbLigne);
                } else {
                    values.add(toInt(level));
                }
            }
        }
        return values;
    }

    /**
     * Lenient string-to-int conversion. A non-numeric or malformed break-rule token
     * (e.g. "5L1") yields Integer.MIN_VALUE (the wildcard level) instead of throwing,
     * so a bad rule degrades gracefully rather than failing the whole run. Spaces are
     * stripped and decimals are truncated toward zero.
     */
    private static int toInt(String value) {
        if (value == null) {
            return Integer.MIN_VALUE;
        }
        String v = value.replace(" ", "").trim();
        if (v.isEmpty()) {
            return Integer.MIN_VALUE;
        }
        try {
            return new java.math.BigDecimal(v).intValue();
        } catch (NumberFormatException e) {
            return Integer.MIN_VALUE;
        }
    }
}