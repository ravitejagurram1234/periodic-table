# Execution Plan: ProcessTasksServiceImpl FIX

## 1. Current Code Analysis

```java
// Pass 1: Reset + Process each task
for (TaskBase task : run.getTasks().values()) {
    if (task.isInError()) continue;                    // [ISSUE-1] Missing isTodo() check before this
    try {
        if (task.isModeDegrade()) {                    // [ISSUE-2] resetProcess() called AFTER this check
            log.warn("Task {} is in degraded mode, skipping", task.getId());
            continue;
        }
        task.resetProcess();
        taskProcessService.process(task);
    } catch (Exception ex) { ... }
}

// Pass 2: Post-process each task
for (TaskBase task : run.getTasks().values()) {
    if (task.isInError() || task.isModeDegrade()) continue;  // [ISSUE-1] Missing isTodo() check
    try {
        taskPostProcessService.postProcess(task);
    } catch (Exception ex) { ... }
}

// Pass 3: Verify
for (TaskBase task : run.getTasks().values()) {
    if (task.isInError() || task.isModeDegrade()) continue;  // [ISSUE-1] Missing isTodo() check
    if (task.getBlocsUpdate().isEmpty() && task.getBlocsModify().isEmpty()) {
        log.warn("Task {} has no blocs after processing", task.getDebugInfo());
    }
    // [ISSUE-3] Missing: else { run.getRunTask().addTask(task); }
}
```

## 2. Fixed Code Design

### Issue 1: Add `if (!task.isTodo()) continue;` at START of each pass
- Pass 1: Add as FIRST check inside loop, before `if (task.isInError())`
- Pass 2: Add as FIRST check inside loop, before `if (task.isInError() || task.isModeDegrade())`
- Pass 3: Add as FIRST check inside loop, before `if (task.isInError() || task.isModeDegrade())`

### Issue 2: resetProcess() ordering
- **Decision:** Move `task.resetProcess()` to immediately after the try block opening, BEFORE the `isModeDegrade()` check.
- **Reasoning:** In .NET `Run_Base.cs Process()`, resetProcess() is called unconditionally for non-error tasks before mode checks. If a task later exits degraded mode in a subsequent run, its state should already be clean.
- **Alternative considered:** Remove entirely (comment says "should be removed if no use") — but keeping it and moving it up is safer to match .NET behavior.

### Issue 3: Add `run.getRunTask().addTask(task)` in Verify phase
- After checking blocs are NOT empty, call `run.getRunTask().addTask(task)` to register the task for Step 5 processing.

## 3. Verification Against .NET

| Issue | .NET Behavior (Run_Base.cs) | Java Fix |
|-------|----------------------------|----------|
| Issue 1 | .NET checks `task.Todo` before processing | Add `if (!task.isTodo()) continue;` |
| Issue 2 | .NET calls resetProcess() before modeDegrade check | Move resetProcess() before modeDegrade check |
| Issue 3 | .NET Verify() adds tasks with blocs to RunTask | Add `run.getRunTask().addTask(task)` in else branch |

## 4. Cross-Reference Checklist

- ✓ All 3 passes have `if (!task.isTodo()) continue;` at the START
- ✓ resetProcess() timing matches .NET implementation (before modeDegrade check)
- ✓ Verify phase calls `run.getRunTask().addTask(task)` for tasks with blocs
- ✓ Task.isModeDegrade() check is correct (skips entire task)
- ✓ Task.isInError() check is correct (skips entire task)
- ✓ Exception handling is per-task, non-aborting
- ✓ All 3 phases complete even if errors occur in earlier phases

## 5. Code Location

- **File:** `src/main/java/com/socgen/sgs/api/quark/engine/service/impl/ProcessTasksServiceImpl.java`
- **Class:** `ProcessTasksServiceImpl`
- **Method:** `processTasks(Run run)`

