# Execution Plan: Strategy Dispatchers Logging Fix

## 1. Current Code Analysis

### TaskProcessServiceImpl.java (line 36)
```java
if (strategy != null) {
    strategy.process(task);
} else {
    log.warn("No process strategy registered for task type: {}", task.getClass().getSimpleName());  // [LOGGING-INCONSISTENCY] WARN
}
```

### TaskPostProcessServiceImpl.java (line 36)
```java
if (strategy != null) {
    strategy.postProcess(task);
} else {
    log.debug("No post-process strategy for task type: {}", task.getClass().getSimpleName());  // [LOGGING-INCONSISTENCY] DEBUG
}
```

## 2. Decision on Severity

**Selected: Option C — Keep as-is (ProcessService WARN, PostProcessService DEBUG)**

**Reasoning:**
- In the .NET implementation, every task type is expected to have a Process handler — a missing one indicates a configuration/registration error (WARN-worthy).
- Post-processing is optional — not all task types require post-processing logic. In .NET, the post-process delegate is simply not invoked if absent, with no error/warning logged.
- Therefore the current severity levels correctly reflect the semantic intent:
  - Missing **process** strategy = unexpected misconfiguration → `WARN`
  - Missing **post-process** strategy = normal/expected for many task types → `DEBUG`

**Conclusion: No code change required.** The logging is intentionally different and matches .NET behavior.

## 3. Files (No Modification Needed)

- File 1: `src/main/java/com/socgen/sgs/api/quark/engine/service/task/impl/TaskProcessServiceImpl.java` — **No change**
- File 2: `src/main/java/com/socgen/sgs/api/quark/engine/service/task/impl/TaskPostProcessServiceImpl.java` — **No change**

## 4. Verification Checklist

- ✓ Process dispatcher uses WARN for missing strategy (configuration error)
- ✓ PostProcess dispatcher uses DEBUG for missing strategy (optional by design)
- ✓ Severity matches .NET implementation pattern (process = required, post-process = optional)
- ✓ No other logging inconsistencies exist in dispatcher files
- ✓ Both files use consistent structure, naming, and formatting

