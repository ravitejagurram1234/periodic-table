# XML Parsing and Template Infrastructure Analysis

**Date:** June 3, 2026  
**Status:** Complete codebase search and analysis

---

## EXECUTIVE SUMMARY

The Java codebase has **minimal XML parsing infrastructure** compared to .NET expectations. Key findings:

1. **No dedicated XML parsing class** — XML parsing is inline using standard Java `DocumentBuilder`
2. **No TElement/TBox/TTable templates** — Uses generic `Template` class for layout mapping
3. **No QXPProject class** — QuarkXPress project parsing is abstracted via `DocumentIdentityPort`
4. **No gabarit bloc lookup methods** — Bloc page/layout info must be resolved via QXPS server calls
5. **DocumentDomain is metadata-only** — Does NOT contain XML parsing or bloc querying capabilities

---

## TASK 1: XML-RELATED CLASSES

### Search Results

| # | Class | Location | Status |
|---|-------|----------|--------|
| 1 | `DocumentIdentityService` | infra/interop/qxps/identity/ | FOUND ✅ |
| 2 | `FetchXmlMessage` | infra/interop/qxps/message/ | FOUND ✅ |
| 3 | Dedicated XML parser | — | NOT FOUND ❌ |
| 4 | DOM/SAX utilities | — | NOT FOUND ❌ |

### 1. DocumentIdentityService

**File:** `src/main/java/com/socgen/sgs/api/quark/engine/infra/interop/qxps/identity/DocumentIdentityService.java`

**Package:** `com.socgen.sgs.api.quark.engine.infra.interop.qxps.identity`

**Implements:** `DocumentIdentityPort`

**Annotations:** `@Slf4j`, `@Service`, `@RequiredArgsConstructor`

**Key Methods:**
```java
public String fetchXmlForBox(String documentName, String boxName)
    // Calls QXPS server to fetch XML for a specific box
    // Returns: raw XML string

public String getElementValueByIdName(String xmlContent, String idName)
    // Parses XML, searches for ID element with NAME attribute matching idName
    // Uses DocumentBuilder from javax.xml.parsers
    // Returns: text content of matching element

public DocumentIdentity parseDocumentIdentity(String identityString)
    // Parses pipe-separated identity string
    // Format: ID_Fnd_Code|ID_Suivi|ID_Run|ID_Langue|Due_Date|Generation_DateTime|ID_Unit_Code(optional)
    // Returns: DocumentIdentity domain object
```

**Dependencies:** `QxpsHttpClient`, XML DOM parsing utilities

**Key Fields:**
```java
private final QxpsHttpClient qxpsHttpClient;  // HTTP client for QXPS calls
```

### 2. FetchXmlMessage

**File:** `src/main/java/com/socgen/sgs/api/quark/engine/infra/interop/qxps/message/FetchXmlMessage.java`

**Status:** Simple message class for QXPS XML fetch requests (not detailed XML parsing)

---

## TASK 2: ELEMENT/TEMPLATE-RELATED CLASSES

### Search Results

| # | Class | Location | Status |
|---|-------|----------|--------|
| 1 | `Template` | domain/dynamic/template/ | FOUND ✅ |
| 2 | `TElement` | — | NOT FOUND ❌ |
| 3 | `TBox` | — | NOT FOUND ❌ |
| 4 | `TTable` | — | NOT FOUND ❌ |
| 5 | Generic `Element` | — | NOT FOUND ❌ |

### 1. Template Class

**File:** `src/main/java/com/socgen/sgs/api/quark/engine/domain/dynamic/template/Template.java`

**Package:** `com.socgen.sgs.api.quark.engine.domain.dynamic.template`

**Extends:** (None)

**Implements:** (None)

**Annotations:** `@Getter`, `@Setter`

**Purpose:** Represents a layout template that maps a named element from QuarkXPress gabarit to positioning/sizing in the final document.

**Key Fields:**
```java
private String name = "Default";                          // Template logical name
private boolean absolute = false;                         // Absolute vs relative positioning
private AbsoluteRepeatType absoluteRepeat = DEFAULT;     // Multi-page repetition behavior
private boolean pageBreak = false;                        // Render only on page breaks
private boolean columnBreak = false;                      // Render only on column breaks
private String srcName = null;                            // Element name in gabarit (normal case)
private String srcNameOverflow = null;                    // Element name in gabarit (overflow case)
private BigDecimal left = BigDecimal.ZERO;               // Left position
private BigDecimal top = BigDecimal.ZERO;                // Top position
private BigDecimal width = BigDecimal.ZERO;              // Width
private BigDecimal height = BigDecimal.ZERO;             // Height
private BigDecimal heightPercent = BigDecimal.valueOf(100); // Height as percentage
```

**Key Methods:**
```java
public String getSrcNameOverflow()
    // Returns overflow source name, falls back to srcName if not set
    // Returns: String (source element name or fallback)
```

**Notable:** `srcName` maps to .NET `TBox.name` concept, but there's NO actual TBox class in Java.

---

## TASK 3: QXPPROJECT-RELATED CLASSES

### Search Results

| Class | Status | Notes |
|-------|--------|-------|
| `QXPProject` | NOT FOUND ❌ | No equivalent in Java |
| `Project` | NOT FOUND ❌ | No general project class |
| `Analyse()`/`Analysis` | NOT FOUND ❌ | No analysis/parsing class |
| `QXPDocument` | NOT FOUND ❌ | Document parsing abstracted to port pattern |

**Reason:** Java uses the Port/Adapter pattern (`DocumentIdentityPort`, `FilePoolPort`) instead of direct project/document parsing classes.

---

## TASK 4: DOCUMENTDOMAIN METHODS

### File: DocumentDomain.java

**Package:** `com.socgen.sgs.api.quark.engine.domain`

**Annotations:** `@Getter`, `@Setter`, `@NoArgsConstructor`, `@AllArgsConstructor`, `@Builder`

**Extends:** (None)

**Methods (Non-Lombok generated):**
```java
/**
 * Constructor with full details
 * @param id Document ID
 * @param name Document name
 * @param format Document format (QXP, PDF)
 * @param prefix File prefix
 * @param data Document content bytes
 */
public DocumentDomain(Integer id, String name, String format, String prefix, byte[] data)

/**
 * Generates file names from document properties.
 * Private method, called by constructor.
 */
private void generateFileNames()
```

**All Other Methods:** Generated by Lombok (`@Getter` and `@Setter`)

**Key Fields:**
```java
private Integer id;                               // Document ID
private byte[] data;                              // Document content (raw bytes)
private String name;                              // Document name
private String format;                            // Format (QXP, PDF, etc.)
private String prefix;                            // File prefix (D, G, DG, etc.)
private Integer idLangue;                         // Language ID (default 1)
private String fileName;                          // Generated file name
private String filePoolPath;                      // Path in document pool (relative)
private String fileFullPath;                      // Absolute path
private boolean gabarit;                          // Is this a gabarit/template?
private boolean modeDegrade;                      // Degraded mode flag
private DocumentIdentity documentIdentity;        // Parsed identity info (DID)
```

### **CRITICAL FINDING:** DocumentDomain Does NOT Have:

❌ `getXML()` or `getXmlContent()`  
❌ `getBlocs()` or `getBlocNames()`  
❌ `getExistingBlocs()`  
❌ `getElements()`  
❌ Any methods to query bloc structure, page numbers, or layout names  
❌ Any XML parsing or element hierarchy information  

---

## TASK 5: GABARIT XML STRUCTURE ACCESS

### How .NET Code Works (Cross-Reference)

```csharp
// .NET: Task_Document.cs line 178-179
this.Properties.PageNum = this.Run.Gabarit.XML.GetPageNum(__blocName);
this.Properties.LayoutName = this.Run.Gabarit.XML.GetLayoutName(__blocName);
```

The .NET gabarit object has an `.XML` property with methods like `GetPageNum()` and `GetLayoutName()` to query bloc information from the document's internal XML structure.

### How Java Code Works

**No equivalent direct access.** The Java approach requires:

1. **DocumentIdentityPort interface** — Port for QXPS interaction
   - File: `src/main/java/com/socgen/sgs/api/quark/engine/domain/port/DocumentIdentityPort.java`
   - Methods:
     ```java
     String fetchXmlForBox(String documentName, String boxName);
     String getElementValueByIdName(String xmlContent, String idName);
     DocumentIdentity parseDocumentIdentity(String identityString);
     ```

2. **DocumentIdentityService** — Implementation via QXPS HTTP calls
   - File: `src/main/java/com/socgen/sgs/api/quark/engine/infra/interop/qxps/identity/DocumentIdentityService.java`
   - Uses: `QxpsHttpClient` to call QXPS server to fetch XML

3. **Run.prepareGabarit()** — Loads gabarit and parses DID
   - File: `src/main/java/com/socgen/sgs/api/quark/engine/domain/Run.java` (lines 78-134)
   - Fetches XML for "DID" box: `documentIdentityPort.fetchXmlForBox(gabaritFileName, "DID")`
   - Parses identity: `documentIdentityPort.parseDocumentIdentity(didValue)`

### **CRITICAL LIMITATION:**

**Java has NO way to query arbitrary bloc page numbers or layout names from gabarit XML.**

The only XML information extracted is:
- Document identity from the "DID" box (fundCode, suivi, run ID, language, due date, datetime, unit code)

Bloc-level information (page numbers, layout names) would require:
- Either extending `DocumentIdentityPort` with new methods like `getPageNumForBloc()`
- Or adding XML parsing to `DocumentDomain` to maintain element hierarchy

---

## DIRECTORY STRUCTURE

```
domain/
├── DocumentDomain.java                     ✅ Metadata only
├── DocumentIdentity.java                   ✅ Parsed DID info
├── Run.java                                ✅ Gabarit is DocumentDomain
├── RunProperties.java                      ✅ Run configuration
├── dynamic/
│   ├── report/
│   │   ├── DBlocInfo.java                 (bloc metadata)
│   │   ├── DMasterPage.java
│   │   ├── DBreakRule.java
│   │   └── DBreakRules.java
│   └── template/
│       └── Template.java                   ✅ Layout template mapping
├── port/
│   ├── DocumentIdentityPort.java          ✅ Port for XML fetching
│   └── FilePoolPort.java
└── helper/
    └── DocumentIdentityHelper.java         ✅ Helper for identity extraction

infra/interop/qxps/identity/
└── DocumentIdentityService.java            ✅ QXPS XML fetching + parsing

integration/soap/generated/
└── Box.java                                ✅ SOAP-generated box definition
```

---

## CLASSES TO EXPLICITLY CHECK

| Class | Status | Location | Notes |
|-------|--------|----------|-------|
| ✅ XML parsing class | EXISTS | DocumentIdentityService (inline DOM parsing) | Uses javax.xml.parsers.DocumentBuilder |
| ❌ TElement class | NOT FOUND | — | No template element class |
| ❌ TBox class | NOT FOUND | — | No template box class (use Template instead) |
| ❌ TTable class | NOT FOUND | — | No template table class |
| ❌ QXPProject class | NOT FOUND | — | Project parsing abstracted to ports |
| ❌ Bloc lookup in gabarit | NOT FOUND | — | No built-in method; requires QXPS server call |

---

## BLOCBASE CLASS (Related to bloc storage)

**File:** `src/main/java/com/socgen/sgs/api/quark/engine/domain/bloc/BlocBase.java`

**Has fields for bloc metadata** (name, action, pageId, layoutName) but is NOT for parsing gabarit — it's for storing generated blocs during task processing.

---

## SUMMARY: MISSING INFRASTRUCTURE

For the QXP_DATA STYLE mode implementation, the following is **NOT AVAILABLE** in Java:

1. ❌ Direct XML parsing of gabarit structure (TElement/TBox hierarchy)
2. ❌ Method to get page number for a bloc name from gabarit
3. ❌ Method to get layout name for a bloc name from gabarit
4. ❌ Project-level element cloning infrastructure
5. ❌ Element/Box metadata (geometry, styling, content type)

**Workaround Options:**

1. **QXPS Query approach:** Extend `DocumentIdentityPort` to add methods like:
   ```java
   String getPageNumForBloc(String documentName, String blocName);
   String getLayoutNameForBloc(String documentName, String blocName);
   ```

2. **Simplified approach:** Use `taskProperties.getPageNum()` and `taskProperties.getLayoutName()` which are already set by the framework during task evaluation.

3. **Stub approach:** For QXP_Data style mode, create blocs but leave layout/page resolution to later evaluation stages.

---

## INTEGRATION PATTERN

The Java codebase uses a **clean Port/Adapter pattern** instead of direct parsing:

```
Run (domain)
  └── gabarit: DocumentDomain (metadata only)
         └── documentIdentity: DocumentIdentity (parsed DID info)

DocumentIdentityPort (interface)
  └── DocumentIdentityService (infra implementation)
         └── QxpsHttpClient (QXPS HTTP calls)
              └── QXPS Server (actual XML parsing happens here)
```

This means **XML parsing of gabarit structure is deferred to the QXPS server**, not done locally in Java.

