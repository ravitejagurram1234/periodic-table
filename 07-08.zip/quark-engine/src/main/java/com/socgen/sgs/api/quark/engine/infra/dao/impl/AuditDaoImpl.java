package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.infra.dao.AuditDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.Duration;

/**
 * Calls QXP_PK_AUDIT.InsertAuditRun (PROCEDURE, 8 IN params).
 * Cross-reference: .NET Proxy_Audit.InsertAuditRun.
 */
@Repository
@Slf4j
public class AuditDaoImpl implements AuditDao {

    /** p_message is VARCHAR2 — keep within Oracle's standard VARCHAR2 limit. */
    private static final int MAX_MESSAGE_SIZE = 4000;

    private final SimpleJdbcCall insertAuditRunCall;

    @Autowired
    public AuditDaoImpl(DataSource dataSource) {
        this.insertAuditRunCall = new SimpleJdbcCall(dataSource)
                .withCatalogName("QXP_PK_AUDIT")
                .withProcedureName("InsertAuditRun")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_id_run", Types.NUMERIC),
                        new SqlParameter("p_id_suivi", Types.NUMERIC),
                        new SqlParameter("p_run_type", Types.VARCHAR),
                        new SqlParameter("p_start_date", Types.TIMESTAMP),
                        new SqlParameter("p_end_date", Types.TIMESTAMP),
                        new SqlParameter("p_duration", Types.NUMERIC),
                        new SqlParameter("p_end_status", Types.VARCHAR),
                        new SqlParameter("p_message", Types.VARCHAR)
                );
    }

    @Override
    public void insertAuditRun(Run run, String message) {
        // p_duration stores only the SUB-SECOND millisecond COMPONENT (0-999), NOT total elapsed time —
        // this matches the existing QXP_AUDIT_RUN.DURATION contract.
        // ⚠️ Quirk: the stored DURATION is only the 0-999 ms part, not the total duration.
        int durationMs = 0;
        if (run.getStartDate() != null && run.getEndDate() != null) {
            durationMs = Duration.between(run.getStartDate(), run.getEndDate()).toMillisPart();
        }

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_id_run", run.getId())
                // ID_SUIVI is NOT NULL. When a run fails before its properties are loaded there is no
                // suivi id, so bind the neutral 0 (the field's default) rather than SQL NULL — otherwise
                // the audit insert violates the constraint and rolls back the whole finalize.
                .addValue("p_id_suivi", run.getRunProperties() != null ? run.getRunProperties().getIdSuivi() : 0)
                .addValue("p_run_type", run.getRunProperties() != null ? run.getRunProperties().getRunType() : null)
                .addValue("p_start_date", run.getStartDate() != null ? Timestamp.valueOf(run.getStartDate()) : null)
                .addValue("p_end_date", run.getEndDate() != null ? Timestamp.valueOf(run.getEndDate()) : null)
                .addValue("p_duration", durationMs)
                // Bind the stable PascalCase status label (Generated/Error/...) that END_STATUS expects,
                // not the Java enum name() (TO_GENERATE/...). The spelling is a persistence contract.
                .addValue("p_end_status", run.getStatus() != null ? run.getStatus().getAuditStatusLabel() : null)
                .addValue("p_message", truncate(message, MAX_MESSAGE_SIZE));

        try {
            insertAuditRunCall.execute(params);
            log.info("Audit row inserted for run [{}]", run.getId());
        } catch (Exception e) {
            log.error("Failed to insert audit row for run [{}]: {}", run.getId(), e.getMessage(), e);
            throw new RuntimeException("Failed to insert audit row for run: " + run.getId(), e);
        }
    }

    private static String truncate(String value, int maxLength) {
        if (value == null) {
            return null;
        }
        return value.length() > maxLength ? value.substring(0, maxLength) : value;
    }
}