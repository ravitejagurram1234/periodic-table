package com.socgen.sgs.api.quark.engine.infra.dao.impl;

import com.socgen.sgs.api.quark.engine.infra.dao.TaskSqlDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;
import java.util.Map;

/**
 * Executes gabarit/task SQL, binding the run in-params into the statement.
 *
 * <p>Gabarit SQL comes in two placeholder styles across tasks:
 * <ul>
 *   <li><b>{@code ?} positional markers</b> — bound BY POSITION: the i-th {@code ?} takes the i-th
 *       in-param. The in-param map preserves the {@code Get_In_Params} cursor order, so its
 *       {@code values()} are already in placeholder order. A value reused across several {@code ?}
 *       appears as several consecutive in-param rows (same value, distinct names).</li>
 *   <li><b>{@code :name} / {@code :number} markers</b> — bound BY NAME.</li>
 * </ul>
 */
@Repository
@Slf4j
public class TaskSqlDaoImpl implements TaskSqlDao {

    private final NamedParameterJdbcTemplate namedJdbcTemplate;
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public TaskSqlDaoImpl(DataSource dataSource) {
        this.namedJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public List<Map<String, Object>> executeSql(String sql, Map<String, Object> parameters) {
        int placeholders = countPositionalPlaceholders(sql);

        if (placeholders > 0) {
            // Positional binding: values in Get_In_Params order map left-to-right onto the ? markers.
            Object[] args = parameters.values().toArray();
            if (placeholders != args.length) {
                log.warn("SQL uses {} positional (?) placeholders but {} in-params were provided; "
                        + "positional binding requires an exact match", placeholders, args.length);
            }
            log.debug("Executing task SQL with {} positional (?) parameters", args.length);
            return jdbcTemplate.queryForList(sql, args);
        }

        log.debug("Executing task SQL with {} named parameters", parameters.size());
        return namedJdbcTemplate.queryForList(sql, parameters);
    }

    /** Count {@code ?} bind markers, ignoring string literals and comments so a literal/comment
     *  {@code ?} is not mistaken for a placeholder. Zero means the SQL uses named ({@code :x}) binds. */
    private static int countPositionalPlaceholders(String sql) {
        String stripped = sql
                .replaceAll("'(?:[^']|'')*'", "")   // single-quoted string literals
                .replaceAll("--[^\r\n]*", "")        // line comments
                .replaceAll("(?s)/\\*.*?\\*/", "");  // block comments
        return (int) stripped.chars().filter(c -> c == '?').count();
    }
}