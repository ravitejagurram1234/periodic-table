package com.socgen.sgs.api.quark.engine.business;

import com.socgen.sgs.api.quark.engine.domain.DataNameValue;
import com.socgen.sgs.api.quark.engine.domain.DocumentDomain;
import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunError;
import com.socgen.sgs.api.quark.engine.domain.RunResult;
import com.socgen.sgs.api.quark.engine.domain.RunStatus;
import com.socgen.sgs.api.quark.engine.domain.StoreDataType;
import com.socgen.sgs.api.quark.engine.infra.dao.AuditDao;
import com.socgen.sgs.api.quark.engine.infra.dao.EndRunDao;
import com.socgen.sgs.api.quark.engine.infra.dao.InsertDataStorageDao;
import com.socgen.sgs.api.quark.engine.infra.dao.InsertDocumentDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Orchestrates run finalization within a single transaction.
 * Inserts generated documents, updates run status, stores errors and data.
 *
 * Cross-reference: .NET Proxy_Run.End_Run()
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class EndRunBusiness {

    private static final int ID_SOUS_CATEGORIE_QXP = 6;
    private static final int ID_SOUS_CATEGORIE_PDF = 7;
    private static final int ID_SOUS_CATEGORIE_DOC = 8;

    private final EndRunDao endRunDao;
    private final InsertDocumentDao insertDocumentDao;
    private final InsertDataStorageDao insertDataStorageDao;
    private final AuditDao auditDao;

    /**
     * Finalize a run — insert documents, errors, data, and update status.
     * All operations within a single transaction.
     *
     * @param run the run to finalize
     */
    @Transactional
    public void execute(Run run) {
        log.info("Finalizing run [{}] with status [{}]", run.getId(), run.getStatus());

        run.setEndDate(LocalDateTime.now());
        int statusCode = run.getStatus().getCode();

        // Accumulated run trace persisted to the p_log_trace CLOB. Cross-reference: .NET Run.Trace_Context.All_Logs.
        String traceLog = run.getTraceLog();

        if (run.getStatus() == RunStatus.ERROR) {
            // Error case: just update status
            endRunDao.updateStatusRun(
                    run.getId(), statusCode, statusCode,
                    run.getEndDate(), traceLog);

        } else {
            // Success case: insert documents then end run
            int idQxp = insertGeneratedDocument(run, run.getResult().getFinalQxp(), ID_SOUS_CATEGORIE_QXP);
            int idPdf = insertGeneratedDocument(run, run.getResult().getFinalPdf(), ID_SOUS_CATEGORIE_PDF);
            int idDoc = Integer.MIN_VALUE; // Word not generated (skipped in .NET too)

            endRunDao.endRun(
                    run.getId(), statusCode,
                    run.getRunProperties().getIdSuivi(), statusCode,
                    run.getEndDate(), traceLog,
                    idPdf, idQxp, idDoc);
        }

        // Always insert errors
        insertErrors(run);

        // Always insert the audit row (matches .NET End_Run order: status/end -> errors -> audit -> data).
        auditDao.insertAuditRun(run, buildAuditMessage(run));

        // Store data only if not in error
        if (run.getStatus() != RunStatus.ERROR) {
            insertDataStorage(run);
        }

        log.info("Run [{}] finalized successfully", run.getId());
    }

    private int insertGeneratedDocument(Run run, DocumentDomain document, int idSousCategorie) {
        String kind = documentKind(idSousCategorie);
        if (document == null || document.getData() == null) {
            log.info("No {} generated for run [{}] — nothing stored in QXP_DOCUMENT", kind, run.getId());
            return Integer.MIN_VALUE;
        }
        int idDocument = insertDocumentDao.insertDocument(
                document, idSousCategorie,
                run.getRunProperties().getIdFndCode(),
                run.getRunProperties().getIdUnitCode(),
                run.getRunProperties().getDateEcheance(),
                run.getId());
        log.info("Stored {} document [id={}, {} bytes] in QXP_DOCUMENT for run [{}] (pool file: {})",
                kind, idDocument, document.getData().length, run.getId(), document.getFilePoolPath());
        return idDocument;
    }

    private static String documentKind(int idSousCategorie) {
        switch (idSousCategorie) {
            case ID_SOUS_CATEGORIE_QXP: return "QXP";
            case ID_SOUS_CATEGORIE_PDF: return "PDF";
            case ID_SOUS_CATEGORIE_DOC: return "Word";
            default: return "document(cat=" + idSousCategorie + ")";
        }
    }

    /** Short audit message: status + error summary (the DAO truncates to the column size). */
    private String buildAuditMessage(Run run) {
        List<RunError> errors = run.getErrors();
        if (errors.isEmpty()) {
            return "Run " + run.getId() + " " + run.getStatus();
        }
        return "Run " + run.getId() + " " + run.getStatus()
                + " - " + errors.size() + " error(s): " + errors.get(0).getMessage();
    }

    private void insertErrors(Run run) {
        List<RunError> errors = run.getErrors();
        if (errors.isEmpty()) return;

        String[] messages = new String[errors.size()];
        int[] categories = new int[errors.size()];

        for (int i = 0; i < errors.size(); i++) {
            // Parity: .NET Proxy_Error replaces a blank message with the "aucun" sentinel
            // (Proxy_Error.cs:115-118, MessageVide = "aucun") before binding.
            String message = errors.get(i).getMessage();
            messages[i] = (message == null || message.isBlank()) ? "aucun" : message;
            categories[i] = errors.get(i).getCategory();
        }

        endRunDao.insertRunErrors(run.getId(), messages, categories);
    }

    /**
     * Insert data storage entries for SQL and DOCUMENT types.
     * SQL data uses simple historisation (0), DOCUMENT uses differential (1).
     *
     * Cross-reference: .NET Proxy_Store.Insert_Data_Storage
     */
    private void insertDataStorage(Run run) {
        // Bitwise tests on the raw store-type code so a combined value (0x03) persists BOTH SQL and
        // DOCUMENT storage. (.NET Run_Base.cs:677/699.) Finding #1.
        int storeCode = run.getRunProperties().getStoreDataTypeCode();

        // SQL data storage (historisation_differentielle = false)
        if (StoreDataType.hasFlag(storeCode, StoreDataType.SQL) && !run.getSqlDataNamesValues().isEmpty()) {
            String[][] arrays = toArrays(run.getSqlDataNamesValues());
            insertDataStorageDao.insertData(
                    run.getRunProperties().getIdSuivi(),
                    run.getId(),
                    run.getEndDate(),
                    StoreDataType.SQL.getCode(),
                    arrays[0], arrays[1], arrays[2], arrays[3],
                    false);
        }

        // Document data storage (historisation_differentielle = true)
        if (StoreDataType.hasFlag(storeCode, StoreDataType.DOCUMENT) && !run.getDocDataNamesValues().isEmpty()) {
            String[][] arrays = toArrays(run.getDocDataNamesValues());
            insertDataStorageDao.insertData(
                    run.getRunProperties().getIdSuivi(),
                    run.getId(),
                    run.getEndDate(),
                    StoreDataType.DOCUMENT.getCode(),
                    arrays[0], arrays[1], arrays[2], arrays[3],
                    true);
        }
    }

    /**
     * Convert DataNameValue list to parallel arrays.
     * Cross-reference: .NET DataNamesValues.ToArrays()
     *
     * @return [0]=names, [1]=values, [2]=descriptifs, [3]=infos
     */
    private String[][] toArrays(List<DataNameValue> dataList) {
        int maxNameSize = 30;
        int maxValueSize = 500;
        int maxDescriptifSize = 250;
        int maxInfoSize = 4000;

        String[] names = new String[dataList.size()];
        String[] values = new String[dataList.size()];
        String[] descriptifs = new String[dataList.size()];
        String[] infos = new String[dataList.size()];

        for (int i = 0; i < dataList.size(); i++) {
            DataNameValue dnv = dataList.get(i);
            names[i] = truncate(dnv.getName(), maxNameSize);
            values[i] = truncate(dnv.getValue(), maxValueSize);
            descriptifs[i] = truncate(dnv.getDescriptif(), maxDescriptifSize);
            infos[i] = truncate(dnv.getInfo(), maxInfoSize);
        }

        return new String[][]{names, values, descriptifs, infos};
    }

    private String truncate(String value, int maxLength) {
        if (value == null) return "";
        return value.length() > maxLength ? value.substring(0, maxLength) : value;
    }
}