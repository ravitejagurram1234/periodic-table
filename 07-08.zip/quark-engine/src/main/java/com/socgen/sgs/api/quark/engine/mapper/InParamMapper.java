package com.socgen.sgs.api.quark.engine.mapper;
import com.socgen.sgs.api.quark.engine.domain.InParam;
import org.springframework.stereotype.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
@Component
public class InParamMapper {
    public InParam mapFromResultSet(ResultSet rs) throws SQLException {
        // Null-tolerant read matching the legacy engine's data reader: a NULL type code resolves to an
        // unset sentinel (→ DataTypeEnum.UNSPECIFIED → the param binds as its raw string), and a NULL
        // name or value normalizes to an empty string rather than a Java null.
        int typeCode = rs.getInt("input_data_type");
        if (rs.wasNull()) {
            typeCode = Integer.MIN_VALUE;
        }
        return new InParam(
                emptyIfNull(rs.getString("nom_parametre")),
                typeCode,
                emptyIfNull(rs.getString("valeur"))
        );
    }

    private static String emptyIfNull(String value) {
        return value != null ? value : "";
    }
}