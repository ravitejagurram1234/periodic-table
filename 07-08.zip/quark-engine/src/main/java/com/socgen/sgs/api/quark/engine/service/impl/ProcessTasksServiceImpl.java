package com.socgen.sgs.api.quark.engine.service.impl;

import com.socgen.sgs.api.quark.engine.domain.Run;
import com.socgen.sgs.api.quark.engine.domain.RunError;
import com.socgen.sgs.api.quark.engine.domain.RunTask;
import com.socgen.sgs.api.quark.engine.domain.task.TaskBase;
import com.socgen.sgs.api.quark.engine.service.ProcessTasksService;
import com.socgen.sgs.api.quark.engine.service.task.TaskPostProcessService;
import com.socgen.sgs.api.quark.engine.service.task.TaskProcessService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Implements the Prepare phase and the 3-pass task processing loop.
 * Cross-reference: .NET Run_Base.Prepare() and Run_Base.Process().
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ProcessTasksServiceImpl implements ProcessTasksService {

    /** RunError categories, matching .NET Error_Type: 1=Unspecified, 2=Critique, 3=Bloquante. */
    private static final int CRITIQUE = RunError.CRITIQUE;

    private final TaskProcessService taskProcessService;
    private final TaskPostProcessService taskPostProcessService;

    /** Max blocs per modify step (.NET EngineCoreSetting Step_Limit). Configurable via application.yaml. */
    @Value("${engine.step-limit:5000}")
    private int stepLimit;

    /**
     * Prepare phase — call prepare() on EVERY task (not just todo), before processing.
     * Per-task failures are recorded as Critique errors and flag the task in error.
     * Cross-reference: .NET Run_Base.Prepare() (iterates _tasks.Values).
     */
    @Override
    public void prepareTasks(Run run) {
        log.info("Preparing tasks for runId: {}", run.getId());

        for (TaskBase task : run.getTasks().values()) {
            try {
                log.debug("Preparing task {}", task.getId());
                task.prepare();
            } catch (Exception ex) {
                task.setInError(true);
                run.getErrors().add(new RunError(CRITIQUE,
                        "Erreur lors de la preparation de la tache " + task.getId() + " : " + ex.getMessage()));
                log.error("Error preparing task {}: {}", task.getId(), ex.getMessage());
                log.debug("Task {} preparation failure detail", task.getId(), ex);
            }
        }

        log.info("Task preparation completed for runId: {}", run.getId());
    }

    @Override
    public void processTasks(Run run) {
        log.info("Processing tasks for runId: {}", run.getId());

        // Fresh step aggregator for this processing pass.
        // Cross-reference: .NET Run_Base.Process() — `_run_Task = new Run_Task(this)`.
        RunTask runTask = new RunTask(run);
        runTask.setSplitStepBoxNumber(stepLimit); // configurable step limit
        run.setRunTask(runTask);

        // Pass 1: Reset + Process each task
        for (TaskBase task : run.getTasks().values()) {
            if (!task.isTodo()) continue;
            if (task.isInError()) continue;
            try {
                // A task in degraded mode is NOT reset/processed; it is reported as a fail-soft error.
                // Cross-reference: .NET Process() — Errors.Add(Critique, TaskFailSoftMode) and skip.
                if (task.isModeDegrade()) {
                    run.getErrors().add(new RunError(CRITIQUE,
                            "Tache " + task.getId() + " en mode degrade (fail-soft) : non traitee"));
                    log.warn("Task {} is in degraded mode (fail-soft), not processed", task.getId());
                    continue;
                }
                log.debug("Processing task {}", task.getId());
                task.resetProcess();
                taskProcessService.process(task);
                log.debug("Task {} produced {} blocsUpdate, {} blocsModify",
                        task.getId(), task.getBlocsUpdate().size(), task.getBlocsModify().size());
            } catch (Exception ex) {
                task.setInError(true);
                run.getErrors().add(new RunError(CRITIQUE,
                        "Erreur lors du traitement de la tache " + task.getId() + " : " + ex.getMessage()));
                log.error("Error processing task {}: {}", task.getId(), ex.getMessage());
                log.debug("Task {} processing failure detail", task.getId(), ex);
            }
        }

        // Pass 2: Post-process each task (e.g. DID, which needs all other tasks done first)
        for (TaskBase task : run.getTasks().values()) {
            if (!task.isTodo()) continue;
            if (task.isInError() || task.isModeDegrade()) continue;
            try {
                log.debug("Post-processing task {}", task.getId());
                taskPostProcessService.postProcess(task);
                log.debug("Task {} post-process: {} blocsUpdate, {} blocsModify",
                        task.getId(), task.getBlocsUpdate().size(), task.getBlocsModify().size());
            } catch (Exception ex) {
                task.setInError(true);
                run.getErrors().add(new RunError(CRITIQUE,
                        "Erreur lors du post-traitement de la tache " + task.getId() + " : " + ex.getMessage()));
                log.error("Error post-processing task {}: {}", task.getId(), ex.getMessage());
                log.debug("Task {} post-processing failure detail", task.getId(), ex);
            }
        }

        // Pass 3: Verify — a task with no blocs is an error; otherwise register its blocs
        for (TaskBase task : run.getTasks().values()) {
            if (!task.isTodo()) continue;
            if (task.isInError() || task.isModeDegrade()) continue;
            if (task.getBlocsUpdate().isEmpty() && task.getBlocsModify().isEmpty()) {
                // .NET Run_Base.Process pass 3: Errors.Add(TaskSansBloc, ...) → Unspecified (1), not Critique.
                run.getErrors().add(new RunError(RunError.UNSPECIFIED,
                        "La tache " + task.getId() + " ne genere aucun bloc"));
                log.warn("Task {} has no blocs after processing", task.getDebugInfo());
            } else {
                run.getRunTask().addTask(task);
                log.debug("Task {} added to RunTask with {} blocsUpdate, {} blocsModify",
                        task.getId(), task.getBlocsUpdate().size(), task.getBlocsModify().size());
            }
        }

        log.info("Task processing completed for runId: {}", run.getId());
    }
}